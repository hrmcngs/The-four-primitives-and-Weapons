execute in minecraft:overworld run fill 227 68 11 227 69 11 dirt
execute in minecraft:overworld run setblock 227 70 11 coarse_dirt
execute in minecraft:overworld run fill 227 71 11 227 144 11 air
execute in minecraft:overworld run fill 227 58 12 227 67 12 stone
execute in minecraft:overworld run fill 227 68 12 227 69 12 dirt
execute in minecraft:overworld run setblock 227 70 12 coarse_dirt
execute in minecraft:overworld run fill 227 71 12 227 144 12 air
execute in minecraft:overworld run fill 227 58 13 227 68 13 stone
execute in minecraft:overworld run fill 227 69 13 227 70 13 dirt
execute in minecraft:overworld run setblock 227 71 13 coarse_dirt
execute in minecraft:overworld run fill 227 72 13 227 144 13 air
execute in minecraft:overworld run fill 227 58 14 227 68 14 stone
execute in minecraft:overworld run fill 227 69 14 227 70 14 dirt
execute in minecraft:overworld run setblock 227 71 14 coarse_dirt
execute in minecraft:overworld run fill 227 72 14 227 144 14 air
execute in minecraft:overworld run fill 227 58 15 227 69 15 stone
execute in minecraft:overworld run fill 227 70 15 227 71 15 dirt
execute in minecraft:overworld run setblock 227 72 15 coarse_dirt
execute in minecraft:overworld run fill 227 73 15 227 144 15 air
execute in minecraft:overworld run fill 227 58 16 227 69 16 stone
execute in minecraft:overworld run fill 227 70 16 227 71 16 dirt
execute in minecraft:overworld run setblock 227 72 16 coarse_dirt
execute in minecraft:overworld run fill 227 73 16 227 144 16 air
execute in minecraft:overworld run fill 227 58 17 227 69 17 stone
execute in minecraft:overworld run fill 227 70 17 227 71 17 dirt
execute in minecraft:overworld run setblock 227 72 17 grass_block
execute in minecraft:overworld run fill 227 73 17 227 144 17 air
execute in minecraft:overworld run fill 227 58 18 227 69 18 stone
execute in minecraft:overworld run fill 227 70 18 227 71 18 dirt
execute in minecraft:overworld run setblock 227 72 18 coarse_dirt
execute in minecraft:overworld run fill 227 73 18 227 144 18 air
execute in minecraft:overworld run fill 227 58 19 227 70 19 stone
execute in minecraft:overworld run fill 227 71 19 227 72 19 dirt
execute in minecraft:overworld run setblock 227 73 19 coarse_dirt
execute in minecraft:overworld run fill 227 74 19 227 144 19 air
execute in minecraft:overworld run fill 227 58 20 227 70 20 stone
execute in minecraft:overworld run fill 227 71 20 227 72 20 dirt
execute in minecraft:overworld run setblock 227 73 20 coarse_dirt
execute in minecraft:overworld run fill 227 74 20 227 144 20 air
execute in minecraft:overworld run fill 227 58 21 227 70 21 stone
execute in minecraft:overworld run fill 227 71 21 227 72 21 dirt
execute in minecraft:overworld run setblock 227 73 21 coarse_dirt
execute in minecraft:overworld run fill 227 74 21 227 144 21 air
execute in minecraft:overworld run fill 227 58 22 227 70 22 stone
execute in minecraft:overworld run fill 227 71 22 227 72 22 dirt
execute in minecraft:overworld run setblock 227 73 22 coarse_dirt
execute in minecraft:overworld run fill 227 74 22 227 144 22 air
execute in minecraft:overworld run fill 227 58 23 227 70 23 stone
execute in minecraft:overworld run fill 227 71 23 227 72 23 dirt
execute in minecraft:overworld run setblock 227 73 23 grass_block
execute in minecraft:overworld run fill 227 74 23 227 144 23 air
execute in minecraft:overworld run fill 227 58 24 227 70 24 stone
execute in minecraft:overworld run fill 227 71 24 227 72 24 dirt
execute in minecraft:overworld run setblock 227 73 24 coarse_dirt
execute in minecraft:overworld run fill 227 74 24 227 144 24 air
execute in minecraft:overworld run setblock 227 74 24 grass
execute in minecraft:overworld run fill 227 58 25 227 70 25 stone
execute in minecraft:overworld run fill 227 71 25 227 72 25 dirt
execute in minecraft:overworld run setblock 227 73 25 grass_block
execute in minecraft:overworld run fill 227 74 25 227 144 25 air
execute in minecraft:overworld run setblock 227 74 25 mossy_cobblestone
execute in minecraft:overworld run fill 227 58 26 227 70 26 stone
execute in minecraft:overworld run fill 227 71 26 227 72 26 dirt
execute in minecraft:overworld run setblock 227 73 26 grass_block
execute in minecraft:overworld run fill 227 74 26 227 144 26 air
execute in minecraft:overworld run fill 227 58 27 227 70 27 stone
execute in minecraft:overworld run fill 227 71 27 227 72 27 dirt
execute in minecraft:overworld run setblock 227 73 27 coarse_dirt
execute in minecraft:overworld run fill 227 74 27 227 144 27 air
execute in minecraft:overworld run fill 227 58 28 227 70 28 stone
execute in minecraft:overworld run fill 227 71 28 227 72 28 dirt
execute in minecraft:overworld run setblock 227 73 28 grass_block
execute in minecraft:overworld run fill 227 74 28 227 144 28 air
execute in minecraft:overworld run fill 227 58 29 227 70 29 stone
execute in minecraft:overworld run fill 227 71 29 227 72 29 dirt
execute in minecraft:overworld run setblock 227 73 29 grass_block
execute in minecraft:overworld run fill 227 74 29 227 144 29 air
execute in minecraft:overworld run fill 227 58 30 227 70 30 stone
execute in minecraft:overworld run fill 227 71 30 227 72 30 dirt
execute in minecraft:overworld run setblock 227 73 30 coarse_dirt
execute in minecraft:overworld run fill 227 74 30 227 144 30 air
execute in minecraft:overworld run fill 227 58 31 227 70 31 stone
execute in minecraft:overworld run fill 227 71 31 227 72 31 dirt
execute in minecraft:overworld run setblock 227 73 31 coarse_dirt
execute in minecraft:overworld run fill 227 74 31 227 144 31 air
execute in minecraft:overworld run fill 227 58 32 227 70 32 stone
execute in minecraft:overworld run fill 227 71 32 227 72 32 dirt
execute in minecraft:overworld run setblock 227 73 32 coarse_dirt
execute in minecraft:overworld run fill 227 74 32 227 144 32 air
execute in minecraft:overworld run fill 227 58 33 227 70 33 stone
execute in minecraft:overworld run fill 227 71 33 227 72 33 dirt
execute in minecraft:overworld run setblock 227 73 33 grass_block
execute in minecraft:overworld run fill 227 74 33 227 144 33 air
execute in minecraft:overworld run fill 227 58 34 227 69 34 stone
execute in minecraft:overworld run fill 227 70 34 227 71 34 dirt
execute in minecraft:overworld run setblock 227 72 34 coarse_dirt
execute in minecraft:overworld run fill 227 73 34 227 144 34 air
execute in minecraft:overworld run fill 227 58 35 227 69 35 stone
execute in minecraft:overworld run fill 227 70 35 227 71 35 dirt
execute in minecraft:overworld run setblock 227 72 35 grass_block
execute in minecraft:overworld run fill 227 73 35 227 144 35 air
execute in minecraft:overworld run fill 227 58 36 227 69 36 stone
execute in minecraft:overworld run fill 227 70 36 227 71 36 dirt
execute in minecraft:overworld run setblock 227 72 36 coarse_dirt
execute in minecraft:overworld run fill 227 73 36 227 144 36 air
execute in minecraft:overworld run fill 227 58 37 227 68 37 stone
execute in minecraft:overworld run fill 227 69 37 227 70 37 dirt
execute in minecraft:overworld run setblock 227 71 37 grass_block
execute in minecraft:overworld run fill 227 72 37 227 144 37 air
execute in minecraft:overworld run fill 227 58 38 227 68 38 stone
execute in minecraft:overworld run fill 227 69 38 227 70 38 dirt
execute in minecraft:overworld run setblock 227 71 38 coarse_dirt
execute in minecraft:overworld run fill 227 72 38 227 144 38 air
execute in minecraft:overworld run fill 227 58 39 227 67 39 stone
execute in minecraft:overworld run fill 227 68 39 227 69 39 dirt
execute in minecraft:overworld run setblock 227 70 39 coarse_dirt
execute in minecraft:overworld run fill 227 71 39 227 144 39 air
execute in minecraft:overworld run fill 227 58 40 227 66 40 stone
execute in minecraft:overworld run fill 227 67 40 227 68 40 dirt
execute in minecraft:overworld run setblock 227 69 40 grass_block
execute in minecraft:overworld run fill 227 70 40 227 144 40 air
execute in minecraft:overworld run fill 227 58 41 227 65 41 stone
execute in minecraft:overworld run fill 227 66 41 227 67 41 dirt
execute in minecraft:overworld run setblock 227 68 41 coarse_dirt
execute in minecraft:overworld run fill 227 69 41 227 144 41 air
execute in minecraft:overworld run fill 227 58 42 227 64 42 stone
execute in minecraft:overworld run fill 227 65 42 227 66 42 dirt
execute in minecraft:overworld run setblock 227 67 42 coarse_dirt
execute in minecraft:overworld run fill 227 68 42 227 144 42 air
execute in minecraft:overworld run fill 227 58 43 227 63 43 stone
execute in minecraft:overworld run fill 227 64 43 227 65 43 dirt
execute in minecraft:overworld run setblock 227 66 43 coarse_dirt
execute in minecraft:overworld run fill 227 67 43 227 144 43 air
execute in minecraft:overworld run fill 227 58 44 227 62 44 stone
execute in minecraft:overworld run fill 227 63 44 227 64 44 dirt
execute in minecraft:overworld run setblock 227 65 44 coarse_dirt
execute in minecraft:overworld run fill 227 66 44 227 144 44 air
execute in minecraft:overworld run fill 227 58 45 227 62 45 stone
execute in minecraft:overworld run fill 227 63 45 227 64 45 dirt
execute in minecraft:overworld run setblock 227 65 45 coarse_dirt
execute in minecraft:overworld run fill 227 66 45 227 144 45 air
execute in minecraft:overworld run fill 227 58 46 227 62 46 stone
execute in minecraft:overworld run fill 227 63 46 227 64 46 dirt
execute in minecraft:overworld run setblock 227 65 46 grass_block
execute in minecraft:overworld run fill 227 66 46 227 144 46 air
execute in minecraft:overworld run fill 227 58 47 227 61 47 stone
execute in minecraft:overworld run fill 227 62 47 227 63 47 dirt
execute in minecraft:overworld run setblock 227 64 47 coarse_dirt
execute in minecraft:overworld run fill 227 65 47 227 144 47 air
execute in minecraft:overworld run fill 228 58 -48 228 61 -48 stone
execute in minecraft:overworld run fill 228 62 -48 228 63 -48 dirt
execute in minecraft:overworld run setblock 228 64 -48 grass_block
execute in minecraft:overworld run fill 228 65 -48 228 144 -48 air
execute in minecraft:overworld run fill 228 58 -47 228 63 -47 stone
execute in minecraft:overworld run fill 228 64 -47 228 65 -47 dirt
execute in minecraft:overworld run setblock 228 66 -47 grass_block
execute in minecraft:overworld run fill 228 67 -47 228 144 -47 air
execute in minecraft:overworld run fill 228 58 -46 228 64 -46 stone
execute in minecraft:overworld run fill 228 65 -46 228 66 -46 dirt
execute in minecraft:overworld run setblock 228 67 -46 grass_block
execute in minecraft:overworld run fill 228 68 -46 228 144 -46 air
execute in minecraft:overworld run fill 228 58 -45 228 66 -45 stone
execute in minecraft:overworld run fill 228 67 -45 228 68 -45 dirt
execute in minecraft:overworld run setblock 228 69 -45 coarse_dirt
execute in minecraft:overworld run fill 228 70 -45 228 144 -45 air
execute in minecraft:overworld run fill 228 58 -44 228 67 -44 stone
execute in minecraft:overworld run fill 228 68 -44 228 69 -44 dirt
execute in minecraft:overworld run setblock 228 70 -44 coarse_dirt
execute in minecraft:overworld run fill 228 71 -44 228 144 -44 air
execute in minecraft:overworld run fill 228 58 -43 228 68 -43 stone
execute in minecraft:overworld run fill 228 69 -43 228 70 -43 dirt
execute in minecraft:overworld run setblock 228 71 -43 grass_block
execute in minecraft:overworld run fill 228 72 -43 228 144 -43 air
execute in minecraft:overworld run fill 228 58 -42 228 69 -42 stone
execute in minecraft:overworld run fill 228 70 -42 228 71 -42 dirt
execute in minecraft:overworld run setblock 228 72 -42 coarse_dirt
execute in minecraft:overworld run fill 228 73 -42 228 144 -42 air
execute in minecraft:overworld run fill 228 58 -41 228 70 -41 stone
execute in minecraft:overworld run fill 228 71 -41 228 72 -41 dirt
execute in minecraft:overworld run setblock 228 73 -41 coarse_dirt
execute in minecraft:overworld run fill 228 74 -41 228 144 -41 air
execute in minecraft:overworld run fill 228 58 -40 228 71 -40 stone
execute in minecraft:overworld run fill 228 72 -40 228 73 -40 dirt
execute in minecraft:overworld run setblock 228 74 -40 coarse_dirt
execute in minecraft:overworld run fill 228 75 -40 228 144 -40 air
execute in minecraft:overworld run fill 228 58 -39 228 71 -39 stone
execute in minecraft:overworld run fill 228 72 -39 228 73 -39 dirt
execute in minecraft:overworld run setblock 228 74 -39 coarse_dirt
execute in minecraft:overworld run fill 228 75 -39 228 144 -39 air
execute in minecraft:overworld run fill 228 58 -38 228 72 -38 stone
execute in minecraft:overworld run fill 228 73 -38 228 74 -38 dirt
execute in minecraft:overworld run setblock 228 75 -38 coarse_dirt
execute in minecraft:overworld run fill 228 76 -38 228 144 -38 air
execute in minecraft:overworld run fill 228 58 -37 228 71 -37 stone
execute in minecraft:overworld run fill 228 72 -37 228 73 -37 dirt
execute in minecraft:overworld run setblock 228 74 -37 coarse_dirt
execute in minecraft:overworld run fill 228 75 -37 228 144 -37 air
execute in minecraft:overworld run fill 228 58 -36 228 71 -36 stone
execute in minecraft:overworld run fill 228 72 -36 228 73 -36 dirt
execute in minecraft:overworld run setblock 228 74 -36 grass_block
execute in minecraft:overworld run fill 228 75 -36 228 144 -36 air
execute in minecraft:overworld run fill 228 58 -35 228 70 -35 stone
execute in minecraft:overworld run fill 228 71 -35 228 72 -35 dirt
execute in minecraft:overworld run setblock 228 73 -35 coarse_dirt
execute in minecraft:overworld run fill 228 74 -35 228 144 -35 air
execute in minecraft:overworld run fill 228 58 -34 228 69 -34 stone
execute in minecraft:overworld run fill 228 70 -34 228 71 -34 dirt
execute in minecraft:overworld run setblock 228 72 -34 coarse_dirt
execute in minecraft:overworld run fill 228 73 -34 228 144 -34 air
execute in minecraft:overworld run fill 228 58 -33 228 69 -33 stone
execute in minecraft:overworld run fill 228 70 -33 228 71 -33 dirt
execute in minecraft:overworld run setblock 228 72 -33 coarse_dirt
execute in minecraft:overworld run fill 228 73 -33 228 144 -33 air
execute in minecraft:overworld run fill 228 58 -32 228 68 -32 stone
execute in minecraft:overworld run fill 228 69 -32 228 70 -32 dirt
execute in minecraft:overworld run setblock 228 71 -32 coarse_dirt
execute in minecraft:overworld run fill 228 72 -32 228 144 -32 air
execute in minecraft:overworld run setblock 228 72 -32 mossy_cobblestone
execute in minecraft:overworld run fill 228 58 -31 228 68 -31 stone
execute in minecraft:overworld run fill 228 69 -31 228 70 -31 dirt
execute in minecraft:overworld run setblock 228 71 -31 coarse_dirt
execute in minecraft:overworld run fill 228 72 -31 228 144 -31 air
execute in minecraft:overworld run fill 228 58 -30 228 68 -30 stone
execute in minecraft:overworld run fill 228 69 -30 228 70 -30 dirt
execute in minecraft:overworld run setblock 228 71 -30 coarse_dirt
execute in minecraft:overworld run fill 228 72 -30 228 144 -30 air
execute in minecraft:overworld run fill 228 58 -29 228 67 -29 stone
execute in minecraft:overworld run fill 228 68 -29 228 69 -29 dirt
execute in minecraft:overworld run setblock 228 70 -29 coarse_dirt
execute in minecraft:overworld run fill 228 71 -29 228 144 -29 air
execute in minecraft:overworld run fill 228 58 -28 228 67 -28 stone
execute in minecraft:overworld run fill 228 68 -28 228 69 -28 dirt
execute in minecraft:overworld run setblock 228 70 -28 coarse_dirt
execute in minecraft:overworld run fill 228 71 -28 228 144 -28 air
execute in minecraft:overworld run fill 228 58 -27 228 67 -27 stone
execute in minecraft:overworld run fill 228 68 -27 228 69 -27 dirt
execute in minecraft:overworld run setblock 228 70 -27 grass_block
execute in minecraft:overworld run fill 228 71 -27 228 144 -27 air
execute in minecraft:overworld run fill 228 58 -26 228 66 -26 stone
execute in minecraft:overworld run fill 228 67 -26 228 68 -26 dirt
execute in minecraft:overworld run setblock 228 69 -26 coarse_dirt
execute in minecraft:overworld run fill 228 70 -26 228 144 -26 air
execute in minecraft:overworld run fill 228 58 -25 228 66 -25 stone
execute in minecraft:overworld run fill 228 67 -25 228 68 -25 dirt
execute in minecraft:overworld run setblock 228 69 -25 coarse_dirt
execute in minecraft:overworld run fill 228 70 -25 228 144 -25 air
execute in minecraft:overworld run setblock 228 70 -25 grass
execute in minecraft:overworld run fill 228 58 -24 228 66 -24 stone
execute in minecraft:overworld run fill 228 67 -24 228 68 -24 dirt
execute in minecraft:overworld run setblock 228 69 -24 coarse_dirt
execute in minecraft:overworld run fill 228 70 -24 228 144 -24 air
execute in minecraft:overworld run fill 228 58 -23 228 66 -23 stone
execute in minecraft:overworld run fill 228 67 -23 228 68 -23 dirt
execute in minecraft:overworld run setblock 228 69 -23 coarse_dirt
execute in minecraft:overworld run fill 228 70 -23 228 144 -23 air
execute in minecraft:overworld run fill 228 58 -22 228 66 -22 stone
schedule function blade_gallery:random/burned/part_31 1t replace
