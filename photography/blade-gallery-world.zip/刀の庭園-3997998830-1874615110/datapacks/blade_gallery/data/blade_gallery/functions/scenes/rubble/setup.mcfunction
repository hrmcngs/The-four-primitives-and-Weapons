execute unless data storage blade_gallery:state random_busy run function blade_gallery:random/rubble/start
