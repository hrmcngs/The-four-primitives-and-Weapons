execute in minecraft:overworld run setblock 395 62 -11 gravel
execute in minecraft:overworld run fill 395 63 -11 395 144 -11 air
execute in minecraft:overworld run fill 395 63 -11 395 64 -11 water
execute in minecraft:overworld run fill 395 58 -10 395 58 -10 stone
execute in minecraft:overworld run fill 395 59 -10 395 60 -10 dirt
execute in minecraft:overworld run setblock 395 61 -10 gravel
execute in minecraft:overworld run fill 395 62 -10 395 144 -10 air
execute in minecraft:overworld run fill 395 62 -10 395 64 -10 water
execute in minecraft:overworld run fill 395 58 -9 395 58 -9 stone
execute in minecraft:overworld run fill 395 59 -9 395 60 -9 dirt
execute in minecraft:overworld run setblock 395 61 -9 gravel
execute in minecraft:overworld run fill 395 62 -9 395 144 -9 air
execute in minecraft:overworld run fill 395 62 -9 395 64 -9 water
execute in minecraft:overworld run fill 395 58 -8 395 57 -8 stone
execute in minecraft:overworld run fill 395 58 -8 395 59 -8 dirt
execute in minecraft:overworld run setblock 395 60 -8 gravel
execute in minecraft:overworld run fill 395 61 -8 395 144 -8 air
execute in minecraft:overworld run fill 395 61 -8 395 64 -8 water
execute in minecraft:overworld run fill 395 58 -7 395 57 -7 stone
execute in minecraft:overworld run fill 395 58 -7 395 59 -7 dirt
execute in minecraft:overworld run setblock 395 60 -7 gravel
execute in minecraft:overworld run fill 395 61 -7 395 144 -7 air
execute in minecraft:overworld run fill 395 61 -7 395 64 -7 water
execute in minecraft:overworld run fill 395 58 -6 395 56 -6 stone
execute in minecraft:overworld run fill 395 57 -6 395 58 -6 dirt
execute in minecraft:overworld run setblock 395 59 -6 gravel
execute in minecraft:overworld run fill 395 60 -6 395 144 -6 air
execute in minecraft:overworld run fill 395 60 -6 395 64 -6 water
execute in minecraft:overworld run fill 395 58 -5 395 56 -5 stone
execute in minecraft:overworld run fill 395 57 -5 395 58 -5 dirt
execute in minecraft:overworld run setblock 395 59 -5 gravel
execute in minecraft:overworld run fill 395 60 -5 395 144 -5 air
execute in minecraft:overworld run fill 395 60 -5 395 64 -5 water
execute in minecraft:overworld run fill 395 58 -4 395 55 -4 stone
execute in minecraft:overworld run fill 395 56 -4 395 57 -4 dirt
execute in minecraft:overworld run setblock 395 58 -4 gravel
execute in minecraft:overworld run fill 395 59 -4 395 144 -4 air
execute in minecraft:overworld run fill 395 59 -4 395 64 -4 water
execute in minecraft:overworld run fill 395 58 -3 395 54 -3 stone
execute in minecraft:overworld run fill 395 55 -3 395 56 -3 dirt
execute in minecraft:overworld run setblock 395 57 -3 gravel
execute in minecraft:overworld run fill 395 58 -3 395 144 -3 air
execute in minecraft:overworld run fill 395 58 -3 395 64 -3 water
execute in minecraft:overworld run fill 395 58 -2 395 54 -2 stone
execute in minecraft:overworld run fill 395 55 -2 395 56 -2 dirt
execute in minecraft:overworld run setblock 395 57 -2 gravel
execute in minecraft:overworld run fill 395 58 -2 395 144 -2 air
execute in minecraft:overworld run fill 395 58 -2 395 64 -2 water
execute in minecraft:overworld run fill 395 58 -1 395 54 -1 stone
execute in minecraft:overworld run fill 395 55 -1 395 56 -1 dirt
execute in minecraft:overworld run setblock 395 57 -1 gravel
execute in minecraft:overworld run fill 395 58 -1 395 144 -1 air
execute in minecraft:overworld run fill 395 58 -1 395 64 -1 water
execute in minecraft:overworld run fill 395 58 0 395 54 0 stone
execute in minecraft:overworld run fill 395 55 0 395 56 0 dirt
execute in minecraft:overworld run setblock 395 57 0 gravel
execute in minecraft:overworld run fill 395 58 0 395 144 0 air
execute in minecraft:overworld run fill 395 58 0 395 64 0 water
execute in minecraft:overworld run fill 395 58 1 395 54 1 stone
execute in minecraft:overworld run fill 395 55 1 395 56 1 dirt
execute in minecraft:overworld run setblock 395 57 1 gravel
execute in minecraft:overworld run fill 395 58 1 395 144 1 air
execute in minecraft:overworld run fill 395 58 1 395 64 1 water
execute in minecraft:overworld run fill 395 58 2 395 54 2 stone
execute in minecraft:overworld run fill 395 55 2 395 56 2 dirt
execute in minecraft:overworld run setblock 395 57 2 gravel
execute in minecraft:overworld run fill 395 58 2 395 144 2 air
execute in minecraft:overworld run fill 395 58 2 395 64 2 water
execute in minecraft:overworld run fill 395 58 3 395 54 3 stone
execute in minecraft:overworld run fill 395 55 3 395 56 3 dirt
execute in minecraft:overworld run setblock 395 57 3 gravel
execute in minecraft:overworld run fill 395 58 3 395 144 3 air
execute in minecraft:overworld run fill 395 58 3 395 64 3 water
execute in minecraft:overworld run fill 395 58 4 395 54 4 stone
execute in minecraft:overworld run fill 395 55 4 395 56 4 dirt
execute in minecraft:overworld run setblock 395 57 4 gravel
execute in minecraft:overworld run fill 395 58 4 395 144 4 air
execute in minecraft:overworld run fill 395 58 4 395 64 4 water
execute in minecraft:overworld run fill 395 58 5 395 54 5 stone
execute in minecraft:overworld run fill 395 55 5 395 56 5 dirt
execute in minecraft:overworld run setblock 395 57 5 gravel
execute in minecraft:overworld run fill 395 58 5 395 144 5 air
execute in minecraft:overworld run fill 395 58 5 395 64 5 water
execute in minecraft:overworld run fill 395 58 6 395 54 6 stone
execute in minecraft:overworld run fill 395 55 6 395 56 6 dirt
execute in minecraft:overworld run setblock 395 57 6 gravel
execute in minecraft:overworld run fill 395 58 6 395 144 6 air
execute in minecraft:overworld run fill 395 58 6 395 64 6 water
execute in minecraft:overworld run fill 395 58 7 395 54 7 stone
execute in minecraft:overworld run fill 395 55 7 395 56 7 dirt
execute in minecraft:overworld run setblock 395 57 7 gravel
execute in minecraft:overworld run fill 395 58 7 395 144 7 air
execute in minecraft:overworld run fill 395 58 7 395 64 7 water
execute in minecraft:overworld run fill 395 58 8 395 54 8 stone
execute in minecraft:overworld run fill 395 55 8 395 56 8 dirt
execute in minecraft:overworld run setblock 395 57 8 gravel
execute in minecraft:overworld run fill 395 58 8 395 144 8 air
execute in minecraft:overworld run fill 395 58 8 395 64 8 water
execute in minecraft:overworld run fill 395 58 9 395 54 9 stone
execute in minecraft:overworld run fill 395 55 9 395 56 9 dirt
execute in minecraft:overworld run setblock 395 57 9 gravel
execute in minecraft:overworld run fill 395 58 9 395 144 9 air
execute in minecraft:overworld run fill 395 58 9 395 64 9 water
execute in minecraft:overworld run fill 395 58 10 395 55 10 stone
execute in minecraft:overworld run fill 395 56 10 395 57 10 dirt
execute in minecraft:overworld run setblock 395 58 10 gravel
execute in minecraft:overworld run fill 395 59 10 395 144 10 air
execute in minecraft:overworld run fill 395 59 10 395 64 10 water
execute in minecraft:overworld run fill 395 58 11 395 55 11 stone
execute in minecraft:overworld run fill 395 56 11 395 57 11 dirt
execute in minecraft:overworld run setblock 395 58 11 gravel
execute in minecraft:overworld run fill 395 59 11 395 144 11 air
execute in minecraft:overworld run fill 395 59 11 395 64 11 water
execute in minecraft:overworld run fill 395 58 12 395 55 12 stone
execute in minecraft:overworld run fill 395 56 12 395 57 12 dirt
execute in minecraft:overworld run setblock 395 58 12 gravel
execute in minecraft:overworld run fill 395 59 12 395 144 12 air
execute in minecraft:overworld run fill 395 59 12 395 64 12 water
execute in minecraft:overworld run fill 395 58 13 395 56 13 stone
execute in minecraft:overworld run fill 395 57 13 395 58 13 dirt
execute in minecraft:overworld run setblock 395 59 13 gravel
execute in minecraft:overworld run fill 395 60 13 395 144 13 air
execute in minecraft:overworld run fill 395 60 13 395 64 13 water
execute in minecraft:overworld run fill 395 58 14 395 56 14 stone
execute in minecraft:overworld run fill 395 57 14 395 58 14 dirt
execute in minecraft:overworld run setblock 395 59 14 gravel
execute in minecraft:overworld run fill 395 60 14 395 144 14 air
execute in minecraft:overworld run fill 395 60 14 395 64 14 water
execute in minecraft:overworld run fill 395 58 15 395 57 15 stone
execute in minecraft:overworld run fill 395 58 15 395 59 15 dirt
execute in minecraft:overworld run setblock 395 60 15 gravel
execute in minecraft:overworld run fill 395 61 15 395 144 15 air
execute in minecraft:overworld run fill 395 61 15 395 64 15 water
execute in minecraft:overworld run fill 395 58 16 395 57 16 stone
execute in minecraft:overworld run fill 395 58 16 395 59 16 dirt
execute in minecraft:overworld run setblock 395 60 16 gravel
execute in minecraft:overworld run fill 395 61 16 395 144 16 air
execute in minecraft:overworld run fill 395 61 16 395 64 16 water
execute in minecraft:overworld run fill 395 58 17 395 57 17 stone
execute in minecraft:overworld run fill 395 58 17 395 59 17 dirt
execute in minecraft:overworld run setblock 395 60 17 gravel
execute in minecraft:overworld run fill 395 61 17 395 144 17 air
execute in minecraft:overworld run fill 395 61 17 395 64 17 water
execute in minecraft:overworld run fill 395 58 18 395 57 18 stone
execute in minecraft:overworld run fill 395 58 18 395 59 18 dirt
execute in minecraft:overworld run setblock 395 60 18 gravel
execute in minecraft:overworld run fill 395 61 18 395 144 18 air
execute in minecraft:overworld run fill 395 61 18 395 64 18 water
execute in minecraft:overworld run fill 395 58 19 395 58 19 stone
execute in minecraft:overworld run fill 395 59 19 395 60 19 dirt
execute in minecraft:overworld run setblock 395 61 19 gravel
execute in minecraft:overworld run fill 395 62 19 395 144 19 air
execute in minecraft:overworld run fill 395 62 19 395 64 19 water
execute in minecraft:overworld run fill 395 58 20 395 58 20 stone
execute in minecraft:overworld run fill 395 59 20 395 60 20 dirt
execute in minecraft:overworld run setblock 395 61 20 gravel
execute in minecraft:overworld run fill 395 62 20 395 144 20 air
execute in minecraft:overworld run fill 395 62 20 395 64 20 water
execute in minecraft:overworld run fill 395 58 21 395 58 21 stone
execute in minecraft:overworld run fill 395 59 21 395 60 21 dirt
execute in minecraft:overworld run setblock 395 61 21 gravel
execute in minecraft:overworld run fill 395 62 21 395 144 21 air
execute in minecraft:overworld run fill 395 62 21 395 64 21 water
execute in minecraft:overworld run fill 395 58 22 395 58 22 stone
execute in minecraft:overworld run fill 395 59 22 395 60 22 dirt
execute in minecraft:overworld run setblock 395 61 22 gravel
execute in minecraft:overworld run fill 395 62 22 395 144 22 air
execute in minecraft:overworld run fill 395 62 22 395 64 22 water
execute in minecraft:overworld run fill 395 58 23 395 58 23 stone
execute in minecraft:overworld run fill 395 59 23 395 60 23 dirt
execute in minecraft:overworld run setblock 395 61 23 gravel
execute in minecraft:overworld run fill 395 62 23 395 144 23 air
execute in minecraft:overworld run fill 395 62 23 395 64 23 water
execute in minecraft:overworld run fill 395 58 24 395 58 24 stone
execute in minecraft:overworld run fill 395 59 24 395 60 24 dirt
execute in minecraft:overworld run setblock 395 61 24 gravel
execute in minecraft:overworld run fill 395 62 24 395 144 24 air
execute in minecraft:overworld run fill 395 62 24 395 64 24 water
execute in minecraft:overworld run fill 395 58 25 395 58 25 stone
execute in minecraft:overworld run fill 395 59 25 395 60 25 dirt
execute in minecraft:overworld run setblock 395 61 25 gravel
execute in minecraft:overworld run fill 395 62 25 395 144 25 air
execute in minecraft:overworld run fill 395 62 25 395 64 25 water
execute in minecraft:overworld run fill 395 58 26 395 58 26 stone
execute in minecraft:overworld run fill 395 59 26 395 60 26 dirt
execute in minecraft:overworld run setblock 395 61 26 gravel
execute in minecraft:overworld run fill 395 62 26 395 144 26 air
execute in minecraft:overworld run fill 395 62 26 395 64 26 water
execute in minecraft:overworld run fill 395 58 27 395 58 27 stone
execute in minecraft:overworld run fill 395 59 27 395 60 27 dirt
execute in minecraft:overworld run setblock 395 61 27 gravel
execute in minecraft:overworld run fill 395 62 27 395 144 27 air
execute in minecraft:overworld run fill 395 62 27 395 64 27 water
execute in minecraft:overworld run fill 395 58 28 395 58 28 stone
execute in minecraft:overworld run fill 395 59 28 395 60 28 dirt
execute in minecraft:overworld run setblock 395 61 28 gravel
execute in minecraft:overworld run fill 395 62 28 395 144 28 air
execute in minecraft:overworld run fill 395 62 28 395 64 28 water
execute in minecraft:overworld run fill 395 58 29 395 58 29 stone
execute in minecraft:overworld run fill 395 59 29 395 60 29 dirt
execute in minecraft:overworld run setblock 395 61 29 gravel
execute in minecraft:overworld run fill 395 62 29 395 144 29 air
execute in minecraft:overworld run fill 395 62 29 395 64 29 water
execute in minecraft:overworld run fill 395 58 30 395 58 30 stone
execute in minecraft:overworld run fill 395 59 30 395 60 30 dirt
execute in minecraft:overworld run setblock 395 61 30 gravel
execute in minecraft:overworld run fill 395 62 30 395 144 30 air
execute in minecraft:overworld run fill 395 62 30 395 64 30 water
execute in minecraft:overworld run fill 395 58 31 395 59 31 stone
execute in minecraft:overworld run fill 395 60 31 395 61 31 dirt
execute in minecraft:overworld run setblock 395 62 31 gravel
execute in minecraft:overworld run fill 395 63 31 395 144 31 air
execute in minecraft:overworld run fill 395 63 31 395 64 31 water
execute in minecraft:overworld run fill 395 58 32 395 59 32 stone
execute in minecraft:overworld run fill 395 60 32 395 61 32 dirt
execute in minecraft:overworld run setblock 395 62 32 gravel
execute in minecraft:overworld run fill 395 63 32 395 144 32 air
execute in minecraft:overworld run fill 395 63 32 395 64 32 water
execute in minecraft:overworld run fill 395 58 33 395 60 33 stone
execute in minecraft:overworld run fill 395 61 33 395 62 33 dirt
execute in minecraft:overworld run setblock 395 63 33 gravel
execute in minecraft:overworld run fill 395 64 33 395 144 33 air
execute in minecraft:overworld run fill 395 64 33 395 64 33 water
execute in minecraft:overworld run fill 395 58 34 395 60 34 stone
execute in minecraft:overworld run fill 395 61 34 395 62 34 dirt
execute in minecraft:overworld run setblock 395 63 34 gravel
execute in minecraft:overworld run fill 395 64 34 395 144 34 air
execute in minecraft:overworld run fill 395 64 34 395 64 34 water
execute in minecraft:overworld run fill 395 58 35 395 61 35 stone
execute in minecraft:overworld run fill 395 62 35 395 63 35 dirt
execute in minecraft:overworld run setblock 395 64 35 coarse_dirt
execute in minecraft:overworld run fill 395 65 35 395 144 35 air
execute in minecraft:overworld run fill 395 58 36 395 61 36 stone
execute in minecraft:overworld run fill 395 62 36 395 63 36 dirt
execute in minecraft:overworld run setblock 395 64 36 coarse_dirt
execute in minecraft:overworld run fill 395 65 36 395 144 36 air
execute in minecraft:overworld run fill 395 58 37 395 62 37 stone
execute in minecraft:overworld run fill 395 63 37 395 64 37 dirt
execute in minecraft:overworld run setblock 395 65 37 coarse_dirt
execute in minecraft:overworld run fill 395 66 37 395 144 37 air
execute in minecraft:overworld run setblock 395 66 37 grass
execute in minecraft:overworld run fill 395 58 38 395 63 38 stone
execute in minecraft:overworld run fill 395 64 38 395 65 38 dirt
execute in minecraft:overworld run setblock 395 66 38 coarse_dirt
execute in minecraft:overworld run fill 395 67 38 395 144 38 air
execute in minecraft:overworld run fill 395 58 39 395 63 39 stone
execute in minecraft:overworld run fill 395 64 39 395 65 39 dirt
execute in minecraft:overworld run setblock 395 66 39 grass_block
execute in minecraft:overworld run fill 395 67 39 395 144 39 air
execute in minecraft:overworld run fill 395 58 40 395 64 40 stone
execute in minecraft:overworld run fill 395 65 40 395 66 40 dirt
execute in minecraft:overworld run setblock 395 67 40 grass_block
execute in minecraft:overworld run fill 395 68 40 395 144 40 air
execute in minecraft:overworld run fill 395 58 41 395 64 41 stone
execute in minecraft:overworld run fill 395 65 41 395 66 41 dirt
execute in minecraft:overworld run setblock 395 67 41 grass_block
schedule function blade_gallery:random/battlefield/part_94 1t replace
