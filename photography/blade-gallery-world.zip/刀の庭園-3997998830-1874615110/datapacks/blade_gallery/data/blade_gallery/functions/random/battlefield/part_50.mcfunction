execute in minecraft:overworld run setblock 368 70 15 coarse_dirt
execute in minecraft:overworld run fill 368 71 15 368 144 15 air
execute in minecraft:overworld run fill 368 58 16 368 67 16 stone
execute in minecraft:overworld run fill 368 68 16 368 69 16 dirt
execute in minecraft:overworld run setblock 368 70 16 coarse_dirt
execute in minecraft:overworld run fill 368 71 16 368 144 16 air
execute in minecraft:overworld run fill 368 58 17 368 67 17 stone
execute in minecraft:overworld run fill 368 68 17 368 69 17 dirt
execute in minecraft:overworld run setblock 368 70 17 coarse_dirt
execute in minecraft:overworld run fill 368 71 17 368 144 17 air
execute in minecraft:overworld run fill 368 58 18 368 68 18 stone
execute in minecraft:overworld run fill 368 69 18 368 70 18 dirt
execute in minecraft:overworld run setblock 368 71 18 coarse_dirt
execute in minecraft:overworld run fill 368 72 18 368 144 18 air
execute in minecraft:overworld run fill 368 58 19 368 68 19 stone
execute in minecraft:overworld run fill 368 69 19 368 70 19 dirt
execute in minecraft:overworld run setblock 368 71 19 coarse_dirt
execute in minecraft:overworld run fill 368 72 19 368 144 19 air
execute in minecraft:overworld run fill 368 58 20 368 68 20 stone
execute in minecraft:overworld run fill 368 69 20 368 70 20 dirt
execute in minecraft:overworld run setblock 368 71 20 coarse_dirt
execute in minecraft:overworld run fill 368 72 20 368 144 20 air
execute in minecraft:overworld run fill 368 58 21 368 68 21 stone
execute in minecraft:overworld run fill 368 69 21 368 70 21 dirt
execute in minecraft:overworld run setblock 368 71 21 grass_block
execute in minecraft:overworld run fill 368 72 21 368 144 21 air
execute in minecraft:overworld run fill 368 58 22 368 68 22 stone
execute in minecraft:overworld run fill 368 69 22 368 70 22 dirt
execute in minecraft:overworld run setblock 368 71 22 grass_block
execute in minecraft:overworld run fill 368 72 22 368 144 22 air
execute in minecraft:overworld run fill 368 58 23 368 68 23 stone
execute in minecraft:overworld run fill 368 69 23 368 70 23 dirt
execute in minecraft:overworld run setblock 368 71 23 coarse_dirt
execute in minecraft:overworld run fill 368 72 23 368 144 23 air
execute in minecraft:overworld run setblock 368 72 23 grass
execute in minecraft:overworld run fill 368 58 24 368 68 24 stone
execute in minecraft:overworld run fill 368 69 24 368 70 24 dirt
execute in minecraft:overworld run setblock 368 71 24 coarse_dirt
execute in minecraft:overworld run fill 368 72 24 368 144 24 air
execute in minecraft:overworld run fill 368 58 25 368 68 25 stone
execute in minecraft:overworld run fill 368 69 25 368 70 25 dirt
execute in minecraft:overworld run setblock 368 71 25 coarse_dirt
execute in minecraft:overworld run fill 368 72 25 368 144 25 air
execute in minecraft:overworld run fill 368 58 26 368 68 26 stone
execute in minecraft:overworld run fill 368 69 26 368 70 26 dirt
execute in minecraft:overworld run setblock 368 71 26 grass_block
execute in minecraft:overworld run fill 368 72 26 368 144 26 air
execute in minecraft:overworld run fill 368 58 27 368 68 27 stone
execute in minecraft:overworld run fill 368 69 27 368 70 27 dirt
execute in minecraft:overworld run setblock 368 71 27 coarse_dirt
execute in minecraft:overworld run fill 368 72 27 368 144 27 air
execute in minecraft:overworld run fill 368 58 28 368 68 28 stone
execute in minecraft:overworld run fill 368 69 28 368 70 28 dirt
execute in minecraft:overworld run setblock 368 71 28 coarse_dirt
execute in minecraft:overworld run fill 368 72 28 368 144 28 air
execute in minecraft:overworld run fill 368 58 29 368 68 29 stone
execute in minecraft:overworld run fill 368 69 29 368 70 29 dirt
execute in minecraft:overworld run setblock 368 71 29 coarse_dirt
execute in minecraft:overworld run fill 368 72 29 368 144 29 air
execute in minecraft:overworld run setblock 368 72 29 grass
execute in minecraft:overworld run fill 368 58 30 368 69 30 stone
execute in minecraft:overworld run fill 368 70 30 368 71 30 dirt
execute in minecraft:overworld run setblock 368 72 30 grass_block
execute in minecraft:overworld run fill 368 73 30 368 144 30 air
execute in minecraft:overworld run fill 368 58 31 368 69 31 stone
execute in minecraft:overworld run fill 368 70 31 368 71 31 dirt
execute in minecraft:overworld run setblock 368 72 31 coarse_dirt
execute in minecraft:overworld run fill 368 73 31 368 144 31 air
execute in minecraft:overworld run fill 368 58 32 368 69 32 stone
execute in minecraft:overworld run fill 368 70 32 368 71 32 dirt
execute in minecraft:overworld run setblock 368 72 32 coarse_dirt
execute in minecraft:overworld run fill 368 73 32 368 144 32 air
execute in minecraft:overworld run fill 368 58 33 368 70 33 stone
execute in minecraft:overworld run fill 368 71 33 368 72 33 dirt
execute in minecraft:overworld run setblock 368 73 33 coarse_dirt
execute in minecraft:overworld run fill 368 74 33 368 144 33 air
execute in minecraft:overworld run fill 368 58 34 368 70 34 stone
execute in minecraft:overworld run fill 368 71 34 368 72 34 dirt
execute in minecraft:overworld run setblock 368 73 34 coarse_dirt
execute in minecraft:overworld run fill 368 74 34 368 144 34 air
execute in minecraft:overworld run fill 368 58 35 368 70 35 stone
execute in minecraft:overworld run fill 368 71 35 368 72 35 dirt
execute in minecraft:overworld run setblock 368 73 35 coarse_dirt
execute in minecraft:overworld run fill 368 74 35 368 144 35 air
execute in minecraft:overworld run setblock 368 74 35 grass
execute in minecraft:overworld run fill 368 58 36 368 71 36 stone
execute in minecraft:overworld run fill 368 72 36 368 73 36 dirt
execute in minecraft:overworld run setblock 368 74 36 coarse_dirt
execute in minecraft:overworld run fill 368 75 36 368 144 36 air
execute in minecraft:overworld run fill 368 58 37 368 71 37 stone
execute in minecraft:overworld run fill 368 72 37 368 73 37 dirt
execute in minecraft:overworld run setblock 368 74 37 grass_block
execute in minecraft:overworld run fill 368 75 37 368 144 37 air
execute in minecraft:overworld run fill 368 58 38 368 71 38 stone
execute in minecraft:overworld run fill 368 72 38 368 73 38 dirt
execute in minecraft:overworld run setblock 368 74 38 coarse_dirt
execute in minecraft:overworld run fill 368 75 38 368 144 38 air
execute in minecraft:overworld run fill 368 58 39 368 70 39 stone
execute in minecraft:overworld run fill 368 71 39 368 72 39 dirt
execute in minecraft:overworld run setblock 368 73 39 coarse_dirt
execute in minecraft:overworld run fill 368 74 39 368 144 39 air
execute in minecraft:overworld run fill 368 58 40 368 69 40 stone
execute in minecraft:overworld run fill 368 70 40 368 71 40 dirt
execute in minecraft:overworld run setblock 368 72 40 coarse_dirt
execute in minecraft:overworld run fill 368 73 40 368 144 40 air
execute in minecraft:overworld run fill 368 58 41 368 68 41 stone
execute in minecraft:overworld run fill 368 69 41 368 70 41 dirt
execute in minecraft:overworld run setblock 368 71 41 coarse_dirt
execute in minecraft:overworld run fill 368 72 41 368 144 41 air
execute in minecraft:overworld run setblock 368 72 41 grass
execute in minecraft:overworld run fill 368 58 42 368 67 42 stone
execute in minecraft:overworld run fill 368 68 42 368 69 42 dirt
execute in minecraft:overworld run setblock 368 70 42 grass_block
execute in minecraft:overworld run fill 368 71 42 368 144 42 air
execute in minecraft:overworld run fill 368 58 43 368 66 43 stone
execute in minecraft:overworld run fill 368 67 43 368 68 43 dirt
execute in minecraft:overworld run setblock 368 69 43 coarse_dirt
execute in minecraft:overworld run fill 368 70 43 368 144 43 air
execute in minecraft:overworld run fill 368 58 44 368 65 44 stone
execute in minecraft:overworld run fill 368 66 44 368 67 44 dirt
execute in minecraft:overworld run setblock 368 68 44 grass_block
execute in minecraft:overworld run fill 368 69 44 368 144 44 air
execute in minecraft:overworld run fill 368 58 45 368 64 45 stone
execute in minecraft:overworld run fill 368 65 45 368 66 45 dirt
execute in minecraft:overworld run setblock 368 67 45 coarse_dirt
execute in minecraft:overworld run fill 368 68 45 368 144 45 air
execute in minecraft:overworld run fill 368 58 46 368 63 46 stone
execute in minecraft:overworld run fill 368 64 46 368 65 46 dirt
execute in minecraft:overworld run setblock 368 66 46 coarse_dirt
execute in minecraft:overworld run fill 368 67 46 368 144 46 air
execute in minecraft:overworld run fill 368 58 47 368 62 47 stone
execute in minecraft:overworld run fill 368 63 47 368 64 47 dirt
execute in minecraft:overworld run setblock 368 65 47 grass_block
execute in minecraft:overworld run fill 368 66 47 368 144 47 air
execute in minecraft:overworld run fill 369 58 -48 369 61 -48 stone
execute in minecraft:overworld run fill 369 62 -48 369 63 -48 dirt
execute in minecraft:overworld run setblock 369 64 -48 grass_block
execute in minecraft:overworld run fill 369 65 -48 369 144 -48 air
execute in minecraft:overworld run fill 369 58 -47 369 62 -47 stone
execute in minecraft:overworld run fill 369 63 -47 369 64 -47 dirt
execute in minecraft:overworld run setblock 369 65 -47 coarse_dirt
execute in minecraft:overworld run fill 369 66 -47 369 144 -47 air
execute in minecraft:overworld run fill 369 58 -46 369 63 -46 stone
execute in minecraft:overworld run fill 369 64 -46 369 65 -46 dirt
execute in minecraft:overworld run setblock 369 66 -46 coarse_dirt
execute in minecraft:overworld run fill 369 67 -46 369 144 -46 air
execute in minecraft:overworld run fill 369 58 -45 369 64 -45 stone
execute in minecraft:overworld run fill 369 65 -45 369 66 -45 dirt
execute in minecraft:overworld run setblock 369 67 -45 coarse_dirt
execute in minecraft:overworld run fill 369 68 -45 369 144 -45 air
execute in minecraft:overworld run fill 369 58 -44 369 65 -44 stone
execute in minecraft:overworld run fill 369 66 -44 369 67 -44 dirt
execute in minecraft:overworld run setblock 369 68 -44 coarse_dirt
execute in minecraft:overworld run fill 369 69 -44 369 144 -44 air
execute in minecraft:overworld run fill 369 58 -43 369 66 -43 stone
execute in minecraft:overworld run fill 369 67 -43 369 68 -43 dirt
execute in minecraft:overworld run setblock 369 69 -43 coarse_dirt
execute in minecraft:overworld run fill 369 70 -43 369 144 -43 air
execute in minecraft:overworld run fill 369 58 -42 369 67 -42 stone
execute in minecraft:overworld run fill 369 68 -42 369 69 -42 dirt
execute in minecraft:overworld run setblock 369 70 -42 coarse_dirt
execute in minecraft:overworld run fill 369 71 -42 369 144 -42 air
execute in minecraft:overworld run fill 369 58 -41 369 68 -41 stone
execute in minecraft:overworld run fill 369 69 -41 369 70 -41 dirt
execute in minecraft:overworld run setblock 369 71 -41 coarse_dirt
execute in minecraft:overworld run fill 369 72 -41 369 144 -41 air
execute in minecraft:overworld run fill 369 58 -40 369 69 -40 stone
execute in minecraft:overworld run fill 369 70 -40 369 71 -40 dirt
execute in minecraft:overworld run setblock 369 72 -40 coarse_dirt
execute in minecraft:overworld run fill 369 73 -40 369 144 -40 air
execute in minecraft:overworld run fill 369 58 -39 369 70 -39 stone
execute in minecraft:overworld run fill 369 71 -39 369 72 -39 dirt
execute in minecraft:overworld run setblock 369 73 -39 coarse_dirt
execute in minecraft:overworld run fill 369 74 -39 369 144 -39 air
execute in minecraft:overworld run fill 369 58 -38 369 71 -38 stone
execute in minecraft:overworld run fill 369 72 -38 369 73 -38 dirt
execute in minecraft:overworld run setblock 369 74 -38 coarse_dirt
execute in minecraft:overworld run fill 369 75 -38 369 144 -38 air
execute in minecraft:overworld run fill 369 58 -37 369 71 -37 stone
execute in minecraft:overworld run fill 369 72 -37 369 73 -37 dirt
execute in minecraft:overworld run setblock 369 74 -37 grass_block
execute in minecraft:overworld run fill 369 75 -37 369 144 -37 air
execute in minecraft:overworld run fill 369 58 -36 369 72 -36 stone
execute in minecraft:overworld run fill 369 73 -36 369 74 -36 dirt
execute in minecraft:overworld run setblock 369 75 -36 grass_block
execute in minecraft:overworld run fill 369 76 -36 369 144 -36 air
execute in minecraft:overworld run fill 369 58 -35 369 72 -35 stone
execute in minecraft:overworld run fill 369 73 -35 369 74 -35 dirt
execute in minecraft:overworld run setblock 369 75 -35 grass_block
execute in minecraft:overworld run fill 369 76 -35 369 144 -35 air
execute in minecraft:overworld run fill 369 58 -34 369 72 -34 stone
execute in minecraft:overworld run fill 369 73 -34 369 74 -34 dirt
execute in minecraft:overworld run setblock 369 75 -34 grass_block
execute in minecraft:overworld run fill 369 76 -34 369 144 -34 air
execute in minecraft:overworld run fill 369 58 -33 369 71 -33 stone
execute in minecraft:overworld run fill 369 72 -33 369 73 -33 dirt
execute in minecraft:overworld run setblock 369 74 -33 coarse_dirt
execute in minecraft:overworld run fill 369 75 -33 369 144 -33 air
execute in minecraft:overworld run fill 369 58 -32 369 71 -32 stone
execute in minecraft:overworld run fill 369 72 -32 369 73 -32 dirt
execute in minecraft:overworld run setblock 369 74 -32 coarse_dirt
execute in minecraft:overworld run fill 369 75 -32 369 144 -32 air
execute in minecraft:overworld run setblock 369 75 -32 grass
execute in minecraft:overworld run fill 369 58 -31 369 71 -31 stone
execute in minecraft:overworld run fill 369 72 -31 369 73 -31 dirt
execute in minecraft:overworld run setblock 369 74 -31 grass_block
execute in minecraft:overworld run fill 369 75 -31 369 144 -31 air
execute in minecraft:overworld run fill 369 58 -30 369 71 -30 stone
execute in minecraft:overworld run fill 369 72 -30 369 73 -30 dirt
execute in minecraft:overworld run setblock 369 74 -30 coarse_dirt
execute in minecraft:overworld run fill 369 75 -30 369 144 -30 air
execute in minecraft:overworld run fill 369 58 -29 369 71 -29 stone
execute in minecraft:overworld run fill 369 72 -29 369 73 -29 dirt
execute in minecraft:overworld run setblock 369 74 -29 grass_block
execute in minecraft:overworld run fill 369 75 -29 369 144 -29 air
execute in minecraft:overworld run fill 369 58 -28 369 71 -28 stone
execute in minecraft:overworld run fill 369 72 -28 369 73 -28 dirt
execute in minecraft:overworld run setblock 369 74 -28 grass_block
execute in minecraft:overworld run fill 369 75 -28 369 144 -28 air
execute in minecraft:overworld run fill 369 58 -27 369 70 -27 stone
execute in minecraft:overworld run fill 369 71 -27 369 72 -27 dirt
execute in minecraft:overworld run setblock 369 73 -27 coarse_dirt
execute in minecraft:overworld run fill 369 74 -27 369 144 -27 air
execute in minecraft:overworld run setblock 369 74 -27 grass
execute in minecraft:overworld run fill 369 58 -26 369 70 -26 stone
execute in minecraft:overworld run fill 369 71 -26 369 72 -26 dirt
execute in minecraft:overworld run setblock 369 73 -26 coarse_dirt
execute in minecraft:overworld run fill 369 74 -26 369 144 -26 air
execute in minecraft:overworld run setblock 369 74 -26 grass
execute in minecraft:overworld run fill 369 58 -25 369 70 -25 stone
execute in minecraft:overworld run fill 369 71 -25 369 72 -25 dirt
execute in minecraft:overworld run setblock 369 73 -25 coarse_dirt
execute in minecraft:overworld run fill 369 74 -25 369 144 -25 air
execute in minecraft:overworld run fill 369 58 -24 369 70 -24 stone
execute in minecraft:overworld run fill 369 71 -24 369 72 -24 dirt
execute in minecraft:overworld run setblock 369 73 -24 grass_block
execute in minecraft:overworld run fill 369 74 -24 369 144 -24 air
execute in minecraft:overworld run fill 369 58 -23 369 69 -23 stone
execute in minecraft:overworld run fill 369 70 -23 369 71 -23 dirt
execute in minecraft:overworld run setblock 369 72 -23 coarse_dirt
execute in minecraft:overworld run fill 369 73 -23 369 144 -23 air
execute in minecraft:overworld run setblock 369 73 -23 grass
execute in minecraft:overworld run fill 369 58 -22 369 69 -22 stone
execute in minecraft:overworld run fill 369 70 -22 369 71 -22 dirt
execute in minecraft:overworld run setblock 369 72 -22 coarse_dirt
execute in minecraft:overworld run fill 369 73 -22 369 144 -22 air
execute in minecraft:overworld run fill 369 58 -21 369 69 -21 stone
execute in minecraft:overworld run fill 369 70 -21 369 71 -21 dirt
execute in minecraft:overworld run setblock 369 72 -21 coarse_dirt
execute in minecraft:overworld run fill 369 73 -21 369 144 -21 air
execute in minecraft:overworld run fill 369 58 -20 369 68 -20 stone
execute in minecraft:overworld run fill 369 69 -20 369 70 -20 dirt
execute in minecraft:overworld run setblock 369 71 -20 grass_block
execute in minecraft:overworld run fill 369 72 -20 369 144 -20 air
execute in minecraft:overworld run fill 369 58 -19 369 68 -19 stone
execute in minecraft:overworld run fill 369 69 -19 369 70 -19 dirt
schedule function blade_gallery:random/battlefield/part_51 1t replace
