execute in minecraft:overworld run fill 298 73 -39 298 74 -39 dirt
execute in minecraft:overworld run setblock 298 75 -39 coarse_dirt
execute in minecraft:overworld run fill 298 76 -39 298 144 -39 air
execute in minecraft:overworld run fill 298 58 -38 298 72 -38 stone
execute in minecraft:overworld run fill 298 73 -38 298 74 -38 dirt
execute in minecraft:overworld run setblock 298 75 -38 grass_block
execute in minecraft:overworld run fill 298 76 -38 298 144 -38 air
execute in minecraft:overworld run fill 298 58 -37 298 72 -37 stone
execute in minecraft:overworld run fill 298 73 -37 298 74 -37 dirt
execute in minecraft:overworld run setblock 298 75 -37 grass_block
execute in minecraft:overworld run fill 298 76 -37 298 144 -37 air
execute in minecraft:overworld run fill 298 58 -36 298 72 -36 stone
execute in minecraft:overworld run fill 298 73 -36 298 74 -36 dirt
execute in minecraft:overworld run setblock 298 75 -36 grass_block
execute in minecraft:overworld run fill 298 76 -36 298 144 -36 air
execute in minecraft:overworld run fill 298 58 -35 298 71 -35 stone
execute in minecraft:overworld run fill 298 72 -35 298 73 -35 dirt
execute in minecraft:overworld run setblock 298 74 -35 grass_block
execute in minecraft:overworld run fill 298 75 -35 298 144 -35 air
execute in minecraft:overworld run fill 298 58 -34 298 71 -34 stone
execute in minecraft:overworld run fill 298 72 -34 298 73 -34 dirt
execute in minecraft:overworld run setblock 298 74 -34 grass_block
execute in minecraft:overworld run fill 298 75 -34 298 144 -34 air
execute in minecraft:overworld run fill 298 58 -33 298 71 -33 stone
execute in minecraft:overworld run fill 298 72 -33 298 73 -33 dirt
execute in minecraft:overworld run setblock 298 74 -33 coarse_dirt
execute in minecraft:overworld run fill 298 75 -33 298 144 -33 air
execute in minecraft:overworld run fill 298 58 -32 298 71 -32 stone
execute in minecraft:overworld run fill 298 72 -32 298 73 -32 dirt
execute in minecraft:overworld run setblock 298 74 -32 grass_block
execute in minecraft:overworld run fill 298 75 -32 298 144 -32 air
execute in minecraft:overworld run fill 298 58 -31 298 71 -31 stone
execute in minecraft:overworld run fill 298 72 -31 298 73 -31 dirt
execute in minecraft:overworld run setblock 298 74 -31 coarse_dirt
execute in minecraft:overworld run fill 298 75 -31 298 144 -31 air
execute in minecraft:overworld run fill 298 58 -30 298 70 -30 stone
execute in minecraft:overworld run fill 298 71 -30 298 72 -30 dirt
execute in minecraft:overworld run setblock 298 73 -30 coarse_dirt
execute in minecraft:overworld run fill 298 74 -30 298 144 -30 air
execute in minecraft:overworld run fill 298 58 -29 298 70 -29 stone
execute in minecraft:overworld run fill 298 71 -29 298 72 -29 dirt
execute in minecraft:overworld run setblock 298 73 -29 grass_block
execute in minecraft:overworld run fill 298 74 -29 298 144 -29 air
execute in minecraft:overworld run fill 298 58 -28 298 70 -28 stone
execute in minecraft:overworld run fill 298 71 -28 298 72 -28 dirt
execute in minecraft:overworld run setblock 298 73 -28 grass_block
execute in minecraft:overworld run fill 298 74 -28 298 144 -28 air
execute in minecraft:overworld run fill 298 58 -27 298 70 -27 stone
execute in minecraft:overworld run fill 298 71 -27 298 72 -27 dirt
execute in minecraft:overworld run setblock 298 73 -27 grass_block
execute in minecraft:overworld run fill 298 74 -27 298 144 -27 air
execute in minecraft:overworld run fill 298 58 -26 298 69 -26 stone
execute in minecraft:overworld run fill 298 70 -26 298 71 -26 dirt
execute in minecraft:overworld run setblock 298 72 -26 coarse_dirt
execute in minecraft:overworld run fill 298 73 -26 298 144 -26 air
execute in minecraft:overworld run fill 298 58 -25 298 69 -25 stone
execute in minecraft:overworld run fill 298 70 -25 298 71 -25 dirt
execute in minecraft:overworld run setblock 298 72 -25 coarse_dirt
execute in minecraft:overworld run fill 298 73 -25 298 144 -25 air
execute in minecraft:overworld run fill 298 58 -24 298 69 -24 stone
execute in minecraft:overworld run fill 298 70 -24 298 71 -24 dirt
execute in minecraft:overworld run setblock 298 72 -24 coarse_dirt
execute in minecraft:overworld run fill 298 73 -24 298 144 -24 air
execute in minecraft:overworld run fill 298 58 -23 298 68 -23 stone
execute in minecraft:overworld run fill 298 69 -23 298 70 -23 dirt
execute in minecraft:overworld run setblock 298 71 -23 coarse_dirt
execute in minecraft:overworld run fill 298 72 -23 298 144 -23 air
execute in minecraft:overworld run fill 298 58 -22 298 68 -22 stone
execute in minecraft:overworld run fill 298 69 -22 298 70 -22 dirt
execute in minecraft:overworld run setblock 298 71 -22 grass_block
execute in minecraft:overworld run fill 298 72 -22 298 144 -22 air
execute in minecraft:overworld run fill 298 58 -21 298 68 -21 stone
execute in minecraft:overworld run fill 298 69 -21 298 70 -21 dirt
execute in minecraft:overworld run setblock 298 71 -21 coarse_dirt
execute in minecraft:overworld run fill 298 72 -21 298 144 -21 air
execute in minecraft:overworld run fill 298 58 -20 298 67 -20 stone
execute in minecraft:overworld run fill 298 68 -20 298 69 -20 dirt
execute in minecraft:overworld run setblock 298 70 -20 coarse_dirt
execute in minecraft:overworld run fill 298 71 -20 298 144 -20 air
execute in minecraft:overworld run fill 298 58 -19 298 67 -19 stone
execute in minecraft:overworld run fill 298 68 -19 298 69 -19 dirt
execute in minecraft:overworld run setblock 298 70 -19 coarse_dirt
execute in minecraft:overworld run fill 298 71 -19 298 144 -19 air
execute in minecraft:overworld run fill 298 58 -18 298 67 -18 stone
execute in minecraft:overworld run fill 298 68 -18 298 69 -18 dirt
execute in minecraft:overworld run setblock 298 70 -18 grass_block
execute in minecraft:overworld run fill 298 71 -18 298 144 -18 air
execute in minecraft:overworld run fill 298 58 -17 298 66 -17 stone
execute in minecraft:overworld run fill 298 67 -17 298 68 -17 dirt
execute in minecraft:overworld run setblock 298 69 -17 grass_block
execute in minecraft:overworld run fill 298 70 -17 298 144 -17 air
execute in minecraft:overworld run fill 298 58 -16 298 66 -16 stone
execute in minecraft:overworld run fill 298 67 -16 298 68 -16 dirt
execute in minecraft:overworld run setblock 298 69 -16 grass_block
execute in minecraft:overworld run fill 298 70 -16 298 144 -16 air
execute in minecraft:overworld run fill 298 58 -15 298 66 -15 stone
execute in minecraft:overworld run fill 298 67 -15 298 68 -15 dirt
execute in minecraft:overworld run setblock 298 69 -15 coarse_dirt
execute in minecraft:overworld run fill 298 70 -15 298 144 -15 air
execute in minecraft:overworld run fill 298 58 -14 298 66 -14 stone
execute in minecraft:overworld run fill 298 67 -14 298 68 -14 dirt
execute in minecraft:overworld run setblock 298 69 -14 coarse_dirt
execute in minecraft:overworld run fill 298 70 -14 298 144 -14 air
execute in minecraft:overworld run fill 298 58 -13 298 65 -13 stone
execute in minecraft:overworld run fill 298 66 -13 298 67 -13 dirt
execute in minecraft:overworld run setblock 298 68 -13 grass_block
execute in minecraft:overworld run fill 298 69 -13 298 144 -13 air
execute in minecraft:overworld run fill 298 58 -12 298 65 -12 stone
execute in minecraft:overworld run fill 298 66 -12 298 67 -12 dirt
execute in minecraft:overworld run setblock 298 68 -12 coarse_dirt
execute in minecraft:overworld run fill 298 69 -12 298 144 -12 air
execute in minecraft:overworld run fill 298 58 -11 298 65 -11 stone
execute in minecraft:overworld run fill 298 66 -11 298 67 -11 dirt
execute in minecraft:overworld run setblock 298 68 -11 grass_block
execute in minecraft:overworld run fill 298 69 -11 298 144 -11 air
execute in minecraft:overworld run fill 298 58 -10 298 65 -10 stone
execute in minecraft:overworld run fill 298 66 -10 298 67 -10 dirt
execute in minecraft:overworld run setblock 298 68 -10 coarse_dirt
execute in minecraft:overworld run fill 298 69 -10 298 144 -10 air
execute in minecraft:overworld run fill 298 58 -9 298 65 -9 stone
execute in minecraft:overworld run fill 298 66 -9 298 67 -9 dirt
execute in minecraft:overworld run setblock 298 68 -9 grass_block
execute in minecraft:overworld run fill 298 69 -9 298 144 -9 air
execute in minecraft:overworld run fill 298 58 -8 298 65 -8 stone
execute in minecraft:overworld run fill 298 66 -8 298 67 -8 dirt
execute in minecraft:overworld run setblock 298 68 -8 coarse_dirt
execute in minecraft:overworld run fill 298 69 -8 298 144 -8 air
execute in minecraft:overworld run fill 298 58 -7 298 65 -7 stone
execute in minecraft:overworld run fill 298 66 -7 298 67 -7 dirt
execute in minecraft:overworld run setblock 298 68 -7 coarse_dirt
execute in minecraft:overworld run fill 298 69 -7 298 144 -7 air
execute in minecraft:overworld run fill 298 58 -6 298 65 -6 stone
execute in minecraft:overworld run fill 298 66 -6 298 67 -6 dirt
execute in minecraft:overworld run setblock 298 68 -6 coarse_dirt
execute in minecraft:overworld run fill 298 69 -6 298 144 -6 air
execute in minecraft:overworld run fill 298 58 -5 298 65 -5 stone
execute in minecraft:overworld run fill 298 66 -5 298 67 -5 dirt
execute in minecraft:overworld run setblock 298 68 -5 coarse_dirt
execute in minecraft:overworld run fill 298 69 -5 298 144 -5 air
execute in minecraft:overworld run fill 298 58 -4 298 66 -4 stone
execute in minecraft:overworld run fill 298 67 -4 298 68 -4 dirt
execute in minecraft:overworld run setblock 298 69 -4 coarse_dirt
execute in minecraft:overworld run fill 298 70 -4 298 144 -4 air
execute in minecraft:overworld run fill 298 58 -3 298 66 -3 stone
execute in minecraft:overworld run fill 298 67 -3 298 68 -3 dirt
execute in minecraft:overworld run setblock 298 69 -3 coarse_dirt
execute in minecraft:overworld run fill 298 70 -3 298 144 -3 air
execute in minecraft:overworld run fill 298 58 -2 298 66 -2 stone
execute in minecraft:overworld run fill 298 67 -2 298 68 -2 dirt
execute in minecraft:overworld run setblock 298 69 -2 grass_block
execute in minecraft:overworld run fill 298 70 -2 298 144 -2 air
execute in minecraft:overworld run fill 298 58 -1 298 66 -1 stone
execute in minecraft:overworld run fill 298 67 -1 298 68 -1 dirt
execute in minecraft:overworld run setblock 298 69 -1 coarse_dirt
execute in minecraft:overworld run fill 298 70 -1 298 144 -1 air
execute in minecraft:overworld run fill 298 58 0 298 66 0 stone
execute in minecraft:overworld run fill 298 67 0 298 68 0 dirt
execute in minecraft:overworld run setblock 298 69 0 coarse_dirt
execute in minecraft:overworld run fill 298 70 0 298 144 0 air
execute in minecraft:overworld run fill 298 58 1 298 66 1 stone
execute in minecraft:overworld run fill 298 67 1 298 68 1 dirt
execute in minecraft:overworld run setblock 298 69 1 coarse_dirt
execute in minecraft:overworld run fill 298 70 1 298 144 1 air
execute in minecraft:overworld run fill 298 58 2 298 66 2 stone
execute in minecraft:overworld run fill 298 67 2 298 68 2 dirt
execute in minecraft:overworld run setblock 298 69 2 coarse_dirt
execute in minecraft:overworld run fill 298 70 2 298 144 2 air
execute in minecraft:overworld run fill 298 58 3 298 66 3 stone
execute in minecraft:overworld run fill 298 67 3 298 68 3 dirt
execute in minecraft:overworld run setblock 298 69 3 grass_block
execute in minecraft:overworld run fill 298 70 3 298 144 3 air
execute in minecraft:overworld run fill 298 58 4 298 66 4 stone
execute in minecraft:overworld run fill 298 67 4 298 68 4 dirt
execute in minecraft:overworld run setblock 298 69 4 grass_block
execute in minecraft:overworld run fill 298 70 4 298 144 4 air
execute in minecraft:overworld run fill 298 58 5 298 65 5 stone
execute in minecraft:overworld run fill 298 66 5 298 67 5 dirt
execute in minecraft:overworld run setblock 298 68 5 coarse_dirt
execute in minecraft:overworld run fill 298 69 5 298 144 5 air
execute in minecraft:overworld run fill 298 58 6 298 65 6 stone
execute in minecraft:overworld run fill 298 66 6 298 67 6 dirt
execute in minecraft:overworld run setblock 298 68 6 grass_block
execute in minecraft:overworld run fill 298 69 6 298 144 6 air
execute in minecraft:overworld run fill 298 58 7 298 65 7 stone
execute in minecraft:overworld run fill 298 66 7 298 67 7 dirt
execute in minecraft:overworld run setblock 298 68 7 grass_block
execute in minecraft:overworld run fill 298 69 7 298 144 7 air
execute in minecraft:overworld run fill 298 58 8 298 65 8 stone
execute in minecraft:overworld run fill 298 66 8 298 67 8 dirt
execute in minecraft:overworld run setblock 298 68 8 coarse_dirt
execute in minecraft:overworld run fill 298 69 8 298 144 8 air
execute in minecraft:overworld run fill 298 58 9 298 65 9 stone
execute in minecraft:overworld run fill 298 66 9 298 67 9 dirt
execute in minecraft:overworld run setblock 298 68 9 coarse_dirt
execute in minecraft:overworld run fill 298 69 9 298 144 9 air
execute in minecraft:overworld run fill 298 58 10 298 65 10 stone
execute in minecraft:overworld run fill 298 66 10 298 67 10 dirt
execute in minecraft:overworld run setblock 298 68 10 coarse_dirt
execute in minecraft:overworld run fill 298 69 10 298 144 10 air
execute in minecraft:overworld run fill 298 58 11 298 64 11 stone
execute in minecraft:overworld run fill 298 65 11 298 66 11 dirt
execute in minecraft:overworld run setblock 298 67 11 grass_block
execute in minecraft:overworld run fill 298 68 11 298 144 11 air
execute in minecraft:overworld run fill 298 58 12 298 64 12 stone
execute in minecraft:overworld run fill 298 65 12 298 66 12 dirt
execute in minecraft:overworld run setblock 298 67 12 coarse_dirt
execute in minecraft:overworld run fill 298 68 12 298 144 12 air
execute in minecraft:overworld run fill 298 58 13 298 64 13 stone
execute in minecraft:overworld run fill 298 65 13 298 66 13 dirt
execute in minecraft:overworld run setblock 298 67 13 grass_block
execute in minecraft:overworld run fill 298 68 13 298 144 13 air
execute in minecraft:overworld run fill 298 58 14 298 64 14 stone
execute in minecraft:overworld run fill 298 65 14 298 66 14 dirt
execute in minecraft:overworld run setblock 298 67 14 coarse_dirt
execute in minecraft:overworld run fill 298 68 14 298 144 14 air
execute in minecraft:overworld run fill 298 58 15 298 64 15 stone
execute in minecraft:overworld run fill 298 65 15 298 66 15 dirt
execute in minecraft:overworld run setblock 298 67 15 grass_block
execute in minecraft:overworld run fill 298 68 15 298 144 15 air
execute in minecraft:overworld run fill 298 58 16 298 64 16 stone
execute in minecraft:overworld run fill 298 65 16 298 66 16 dirt
execute in minecraft:overworld run setblock 298 67 16 grass_block
execute in minecraft:overworld run fill 298 68 16 298 144 16 air
execute in minecraft:overworld run fill 298 58 17 298 64 17 stone
execute in minecraft:overworld run fill 298 65 17 298 66 17 dirt
execute in minecraft:overworld run setblock 298 67 17 grass_block
execute in minecraft:overworld run fill 298 68 17 298 144 17 air
execute in minecraft:overworld run fill 298 58 18 298 64 18 stone
execute in minecraft:overworld run fill 298 65 18 298 66 18 dirt
execute in minecraft:overworld run setblock 298 67 18 grass_block
execute in minecraft:overworld run fill 298 68 18 298 144 18 air
execute in minecraft:overworld run fill 298 58 19 298 64 19 stone
execute in minecraft:overworld run fill 298 65 19 298 66 19 dirt
execute in minecraft:overworld run setblock 298 67 19 coarse_dirt
execute in minecraft:overworld run fill 298 68 19 298 144 19 air
execute in minecraft:overworld run fill 298 58 20 298 64 20 stone
execute in minecraft:overworld run fill 298 65 20 298 66 20 dirt
execute in minecraft:overworld run setblock 298 67 20 coarse_dirt
execute in minecraft:overworld run fill 298 68 20 298 144 20 air
execute in minecraft:overworld run fill 298 58 21 298 64 21 stone
execute in minecraft:overworld run fill 298 65 21 298 66 21 dirt
execute in minecraft:overworld run setblock 298 67 21 coarse_dirt
execute in minecraft:overworld run fill 298 68 21 298 144 21 air
execute in minecraft:overworld run fill 298 58 22 298 64 22 stone
execute in minecraft:overworld run fill 298 65 22 298 66 22 dirt
execute in minecraft:overworld run setblock 298 67 22 grass_block
execute in minecraft:overworld run fill 298 68 22 298 144 22 air
execute in minecraft:overworld run fill 298 58 23 298 64 23 stone
execute in minecraft:overworld run fill 298 65 23 298 66 23 dirt
execute in minecraft:overworld run setblock 298 67 23 coarse_dirt
execute in minecraft:overworld run fill 298 68 23 298 144 23 air
execute in minecraft:overworld run fill 298 58 24 298 64 24 stone
execute in minecraft:overworld run fill 298 65 24 298 66 24 dirt
execute in minecraft:overworld run setblock 298 67 24 coarse_dirt
execute in minecraft:overworld run fill 298 68 24 298 144 24 air
execute in minecraft:overworld run fill 298 58 25 298 64 25 stone
schedule function blade_gallery:random/burned/part_143 1t replace
