execute in minecraft:overworld run fill 379 68 15 379 69 15 dirt
execute in minecraft:overworld run setblock 379 70 15 coarse_dirt
execute in minecraft:overworld run fill 379 71 15 379 144 15 air
execute in minecraft:overworld run fill 379 58 16 379 67 16 stone
execute in minecraft:overworld run fill 379 68 16 379 69 16 dirt
execute in minecraft:overworld run setblock 379 70 16 grass_block
execute in minecraft:overworld run fill 379 71 16 379 144 16 air
execute in minecraft:overworld run setblock 379 71 16 mossy_cobblestone
execute in minecraft:overworld run fill 379 58 17 379 67 17 stone
execute in minecraft:overworld run fill 379 68 17 379 69 17 dirt
execute in minecraft:overworld run setblock 379 70 17 coarse_dirt
execute in minecraft:overworld run fill 379 71 17 379 144 17 air
execute in minecraft:overworld run fill 379 58 18 379 68 18 stone
execute in minecraft:overworld run fill 379 69 18 379 70 18 dirt
execute in minecraft:overworld run setblock 379 71 18 grass_block
execute in minecraft:overworld run fill 379 72 18 379 144 18 air
execute in minecraft:overworld run fill 379 58 19 379 68 19 stone
execute in minecraft:overworld run fill 379 69 19 379 70 19 dirt
execute in minecraft:overworld run setblock 379 71 19 grass_block
execute in minecraft:overworld run fill 379 72 19 379 144 19 air
execute in minecraft:overworld run setblock 379 72 19 grass
execute in minecraft:overworld run fill 379 58 20 379 68 20 stone
execute in minecraft:overworld run fill 379 69 20 379 70 20 dirt
execute in minecraft:overworld run setblock 379 71 20 grass_block
execute in minecraft:overworld run fill 379 72 20 379 144 20 air
execute in minecraft:overworld run fill 379 58 21 379 67 21 stone
execute in minecraft:overworld run fill 379 68 21 379 69 21 dirt
execute in minecraft:overworld run setblock 379 70 21 coarse_dirt
execute in minecraft:overworld run fill 379 71 21 379 144 21 air
execute in minecraft:overworld run fill 379 58 22 379 67 22 stone
execute in minecraft:overworld run fill 379 68 22 379 69 22 dirt
execute in minecraft:overworld run setblock 379 70 22 coarse_dirt
execute in minecraft:overworld run fill 379 71 22 379 144 22 air
execute in minecraft:overworld run fill 379 58 23 379 67 23 stone
execute in minecraft:overworld run fill 379 68 23 379 69 23 dirt
execute in minecraft:overworld run setblock 379 70 23 coarse_dirt
execute in minecraft:overworld run fill 379 71 23 379 144 23 air
execute in minecraft:overworld run fill 379 58 24 379 67 24 stone
execute in minecraft:overworld run fill 379 68 24 379 69 24 dirt
execute in minecraft:overworld run setblock 379 70 24 coarse_dirt
execute in minecraft:overworld run fill 379 71 24 379 144 24 air
execute in minecraft:overworld run fill 379 58 25 379 66 25 stone
execute in minecraft:overworld run fill 379 67 25 379 68 25 dirt
execute in minecraft:overworld run setblock 379 69 25 coarse_dirt
execute in minecraft:overworld run fill 379 70 25 379 144 25 air
execute in minecraft:overworld run setblock 379 70 25 grass
execute in minecraft:overworld run fill 379 58 26 379 66 26 stone
execute in minecraft:overworld run fill 379 67 26 379 68 26 dirt
execute in minecraft:overworld run setblock 379 69 26 grass_block
execute in minecraft:overworld run fill 379 70 26 379 144 26 air
execute in minecraft:overworld run fill 379 58 27 379 66 27 stone
execute in minecraft:overworld run fill 379 67 27 379 68 27 dirt
execute in minecraft:overworld run setblock 379 69 27 coarse_dirt
execute in minecraft:overworld run fill 379 70 27 379 144 27 air
execute in minecraft:overworld run fill 379 58 28 379 66 28 stone
execute in minecraft:overworld run fill 379 67 28 379 68 28 dirt
execute in minecraft:overworld run setblock 379 69 28 coarse_dirt
execute in minecraft:overworld run fill 379 70 28 379 144 28 air
execute in minecraft:overworld run fill 379 58 29 379 66 29 stone
execute in minecraft:overworld run fill 379 67 29 379 68 29 dirt
execute in minecraft:overworld run setblock 379 69 29 coarse_dirt
execute in minecraft:overworld run fill 379 70 29 379 144 29 air
execute in minecraft:overworld run fill 379 58 30 379 66 30 stone
execute in minecraft:overworld run fill 379 67 30 379 68 30 dirt
execute in minecraft:overworld run setblock 379 69 30 coarse_dirt
execute in minecraft:overworld run fill 379 70 30 379 144 30 air
execute in minecraft:overworld run fill 379 58 31 379 66 31 stone
execute in minecraft:overworld run fill 379 67 31 379 68 31 dirt
execute in minecraft:overworld run setblock 379 69 31 coarse_dirt
execute in minecraft:overworld run fill 379 70 31 379 144 31 air
execute in minecraft:overworld run fill 379 58 32 379 66 32 stone
execute in minecraft:overworld run fill 379 67 32 379 68 32 dirt
execute in minecraft:overworld run setblock 379 69 32 grass_block
execute in minecraft:overworld run fill 379 70 32 379 144 32 air
execute in minecraft:overworld run fill 379 58 33 379 66 33 stone
execute in minecraft:overworld run fill 379 67 33 379 68 33 dirt
execute in minecraft:overworld run setblock 379 69 33 grass_block
execute in minecraft:overworld run fill 379 70 33 379 144 33 air
execute in minecraft:overworld run fill 379 58 34 379 66 34 stone
execute in minecraft:overworld run fill 379 67 34 379 68 34 dirt
execute in minecraft:overworld run setblock 379 69 34 coarse_dirt
execute in minecraft:overworld run fill 379 70 34 379 144 34 air
execute in minecraft:overworld run fill 379 58 35 379 66 35 stone
execute in minecraft:overworld run fill 379 67 35 379 68 35 dirt
execute in minecraft:overworld run setblock 379 69 35 coarse_dirt
execute in minecraft:overworld run fill 379 70 35 379 144 35 air
execute in minecraft:overworld run fill 379 58 36 379 66 36 stone
execute in minecraft:overworld run fill 379 67 36 379 68 36 dirt
execute in minecraft:overworld run setblock 379 69 36 coarse_dirt
execute in minecraft:overworld run fill 379 70 36 379 144 36 air
execute in minecraft:overworld run fill 379 58 37 379 66 37 stone
execute in minecraft:overworld run fill 379 67 37 379 68 37 dirt
execute in minecraft:overworld run setblock 379 69 37 coarse_dirt
execute in minecraft:overworld run fill 379 70 37 379 144 37 air
execute in minecraft:overworld run fill 379 58 38 379 66 38 stone
execute in minecraft:overworld run fill 379 67 38 379 68 38 dirt
execute in minecraft:overworld run setblock 379 69 38 coarse_dirt
execute in minecraft:overworld run fill 379 70 38 379 144 38 air
execute in minecraft:overworld run fill 379 58 39 379 65 39 stone
execute in minecraft:overworld run fill 379 66 39 379 67 39 dirt
execute in minecraft:overworld run setblock 379 68 39 coarse_dirt
execute in minecraft:overworld run fill 379 69 39 379 144 39 air
execute in minecraft:overworld run fill 379 58 40 379 64 40 stone
execute in minecraft:overworld run fill 379 65 40 379 66 40 dirt
execute in minecraft:overworld run setblock 379 67 40 coarse_dirt
execute in minecraft:overworld run fill 379 68 40 379 144 40 air
execute in minecraft:overworld run fill 379 58 41 379 64 41 stone
execute in minecraft:overworld run fill 379 65 41 379 66 41 dirt
execute in minecraft:overworld run setblock 379 67 41 coarse_dirt
execute in minecraft:overworld run fill 379 68 41 379 144 41 air
execute in minecraft:overworld run fill 379 58 42 379 63 42 stone
execute in minecraft:overworld run fill 379 64 42 379 65 42 dirt
execute in minecraft:overworld run setblock 379 66 42 grass_block
execute in minecraft:overworld run fill 379 67 42 379 144 42 air
execute in minecraft:overworld run fill 379 58 43 379 63 43 stone
execute in minecraft:overworld run fill 379 64 43 379 65 43 dirt
execute in minecraft:overworld run setblock 379 66 43 coarse_dirt
execute in minecraft:overworld run fill 379 67 43 379 144 43 air
execute in minecraft:overworld run fill 379 58 44 379 62 44 stone
execute in minecraft:overworld run fill 379 63 44 379 64 44 dirt
execute in minecraft:overworld run setblock 379 65 44 coarse_dirt
execute in minecraft:overworld run fill 379 66 44 379 144 44 air
execute in minecraft:overworld run fill 379 58 45 379 62 45 stone
execute in minecraft:overworld run fill 379 63 45 379 64 45 dirt
execute in minecraft:overworld run setblock 379 65 45 coarse_dirt
execute in minecraft:overworld run fill 379 66 45 379 144 45 air
execute in minecraft:overworld run fill 379 58 46 379 61 46 stone
execute in minecraft:overworld run fill 379 62 46 379 63 46 dirt
execute in minecraft:overworld run setblock 379 64 46 coarse_dirt
execute in minecraft:overworld run fill 379 65 46 379 144 46 air
execute in minecraft:overworld run fill 379 58 47 379 61 47 stone
execute in minecraft:overworld run fill 379 62 47 379 63 47 dirt
execute in minecraft:overworld run setblock 379 64 47 coarse_dirt
execute in minecraft:overworld run fill 379 65 47 379 144 47 air
execute in minecraft:overworld run fill 380 58 -48 380 61 -48 stone
execute in minecraft:overworld run fill 380 62 -48 380 63 -48 dirt
execute in minecraft:overworld run setblock 380 64 -48 coarse_dirt
execute in minecraft:overworld run fill 380 65 -48 380 144 -48 air
execute in minecraft:overworld run fill 380 58 -47 380 62 -47 stone
execute in minecraft:overworld run fill 380 63 -47 380 64 -47 dirt
execute in minecraft:overworld run setblock 380 65 -47 grass_block
execute in minecraft:overworld run fill 380 66 -47 380 144 -47 air
execute in minecraft:overworld run fill 380 58 -46 380 63 -46 stone
execute in minecraft:overworld run fill 380 64 -46 380 65 -46 dirt
execute in minecraft:overworld run setblock 380 66 -46 coarse_dirt
execute in minecraft:overworld run fill 380 67 -46 380 144 -46 air
execute in minecraft:overworld run fill 380 58 -45 380 64 -45 stone
execute in minecraft:overworld run fill 380 65 -45 380 66 -45 dirt
execute in minecraft:overworld run setblock 380 67 -45 coarse_dirt
execute in minecraft:overworld run fill 380 68 -45 380 144 -45 air
execute in minecraft:overworld run fill 380 58 -44 380 65 -44 stone
execute in minecraft:overworld run fill 380 66 -44 380 67 -44 dirt
execute in minecraft:overworld run setblock 380 68 -44 grass_block
execute in minecraft:overworld run fill 380 69 -44 380 144 -44 air
execute in minecraft:overworld run fill 380 58 -43 380 66 -43 stone
execute in minecraft:overworld run fill 380 67 -43 380 68 -43 dirt
execute in minecraft:overworld run setblock 380 69 -43 grass_block
execute in minecraft:overworld run fill 380 70 -43 380 144 -43 air
execute in minecraft:overworld run fill 380 58 -42 380 66 -42 stone
execute in minecraft:overworld run fill 380 67 -42 380 68 -42 dirt
execute in minecraft:overworld run setblock 380 69 -42 grass_block
execute in minecraft:overworld run fill 380 70 -42 380 144 -42 air
execute in minecraft:overworld run fill 380 58 -41 380 67 -41 stone
execute in minecraft:overworld run fill 380 68 -41 380 69 -41 dirt
execute in minecraft:overworld run setblock 380 70 -41 coarse_dirt
execute in minecraft:overworld run fill 380 71 -41 380 144 -41 air
execute in minecraft:overworld run setblock 380 71 -41 grass
execute in minecraft:overworld run fill 380 58 -40 380 67 -40 stone
execute in minecraft:overworld run fill 380 68 -40 380 69 -40 dirt
execute in minecraft:overworld run setblock 380 70 -40 coarse_dirt
execute in minecraft:overworld run fill 380 71 -40 380 144 -40 air
execute in minecraft:overworld run fill 380 58 -39 380 67 -39 stone
execute in minecraft:overworld run fill 380 68 -39 380 69 -39 dirt
execute in minecraft:overworld run setblock 380 70 -39 coarse_dirt
execute in minecraft:overworld run fill 380 71 -39 380 144 -39 air
execute in minecraft:overworld run fill 380 58 -38 380 67 -38 stone
execute in minecraft:overworld run fill 380 68 -38 380 69 -38 dirt
execute in minecraft:overworld run setblock 380 70 -38 grass_block
execute in minecraft:overworld run fill 380 71 -38 380 144 -38 air
execute in minecraft:overworld run fill 380 58 -37 380 66 -37 stone
execute in minecraft:overworld run fill 380 67 -37 380 68 -37 dirt
execute in minecraft:overworld run setblock 380 69 -37 grass_block
execute in minecraft:overworld run fill 380 70 -37 380 144 -37 air
execute in minecraft:overworld run fill 380 58 -36 380 66 -36 stone
execute in minecraft:overworld run fill 380 67 -36 380 68 -36 dirt
execute in minecraft:overworld run setblock 380 69 -36 coarse_dirt
execute in minecraft:overworld run fill 380 70 -36 380 144 -36 air
execute in minecraft:overworld run fill 380 58 -35 380 65 -35 stone
execute in minecraft:overworld run fill 380 66 -35 380 67 -35 dirt
execute in minecraft:overworld run setblock 380 68 -35 coarse_dirt
execute in minecraft:overworld run fill 380 69 -35 380 144 -35 air
execute in minecraft:overworld run fill 380 58 -34 380 65 -34 stone
execute in minecraft:overworld run fill 380 66 -34 380 67 -34 dirt
execute in minecraft:overworld run setblock 380 68 -34 coarse_dirt
execute in minecraft:overworld run fill 380 69 -34 380 144 -34 air
execute in minecraft:overworld run fill 380 58 -33 380 65 -33 stone
execute in minecraft:overworld run fill 380 66 -33 380 67 -33 dirt
execute in minecraft:overworld run setblock 380 68 -33 grass_block
execute in minecraft:overworld run fill 380 69 -33 380 144 -33 air
execute in minecraft:overworld run fill 380 58 -32 380 65 -32 stone
execute in minecraft:overworld run fill 380 66 -32 380 67 -32 dirt
execute in minecraft:overworld run setblock 380 68 -32 coarse_dirt
execute in minecraft:overworld run fill 380 69 -32 380 144 -32 air
execute in minecraft:overworld run fill 380 58 -31 380 64 -31 stone
execute in minecraft:overworld run fill 380 65 -31 380 66 -31 dirt
execute in minecraft:overworld run setblock 380 67 -31 grass_block
execute in minecraft:overworld run fill 380 68 -31 380 144 -31 air
execute in minecraft:overworld run fill 380 58 -30 380 64 -30 stone
execute in minecraft:overworld run fill 380 65 -30 380 66 -30 dirt
execute in minecraft:overworld run setblock 380 67 -30 coarse_dirt
execute in minecraft:overworld run fill 380 68 -30 380 144 -30 air
execute in minecraft:overworld run fill 380 58 -29 380 64 -29 stone
execute in minecraft:overworld run fill 380 65 -29 380 66 -29 dirt
execute in minecraft:overworld run setblock 380 67 -29 grass_block
execute in minecraft:overworld run fill 380 68 -29 380 144 -29 air
execute in minecraft:overworld run fill 380 58 -28 380 64 -28 stone
execute in minecraft:overworld run fill 380 65 -28 380 66 -28 dirt
execute in minecraft:overworld run setblock 380 67 -28 grass_block
execute in minecraft:overworld run fill 380 68 -28 380 144 -28 air
execute in minecraft:overworld run fill 380 58 -27 380 64 -27 stone
execute in minecraft:overworld run fill 380 65 -27 380 66 -27 dirt
execute in minecraft:overworld run setblock 380 67 -27 grass_block
execute in minecraft:overworld run fill 380 68 -27 380 144 -27 air
execute in minecraft:overworld run fill 380 58 -26 380 64 -26 stone
execute in minecraft:overworld run fill 380 65 -26 380 66 -26 dirt
execute in minecraft:overworld run setblock 380 67 -26 grass_block
execute in minecraft:overworld run fill 380 68 -26 380 144 -26 air
execute in minecraft:overworld run fill 380 58 -25 380 63 -25 stone
execute in minecraft:overworld run fill 380 64 -25 380 65 -25 dirt
execute in minecraft:overworld run setblock 380 66 -25 grass_block
execute in minecraft:overworld run fill 380 67 -25 380 144 -25 air
execute in minecraft:overworld run setblock 380 67 -25 grass
execute in minecraft:overworld run fill 380 58 -24 380 63 -24 stone
execute in minecraft:overworld run fill 380 64 -24 380 65 -24 dirt
execute in minecraft:overworld run setblock 380 66 -24 coarse_dirt
execute in minecraft:overworld run fill 380 67 -24 380 144 -24 air
execute in minecraft:overworld run fill 380 58 -23 380 63 -23 stone
execute in minecraft:overworld run fill 380 64 -23 380 65 -23 dirt
execute in minecraft:overworld run setblock 380 66 -23 coarse_dirt
execute in minecraft:overworld run fill 380 67 -23 380 144 -23 air
execute in minecraft:overworld run fill 380 58 -22 380 62 -22 stone
execute in minecraft:overworld run fill 380 63 -22 380 64 -22 dirt
execute in minecraft:overworld run setblock 380 65 -22 grass_block
execute in minecraft:overworld run fill 380 66 -22 380 144 -22 air
execute in minecraft:overworld run fill 380 58 -21 380 62 -21 stone
execute in minecraft:overworld run fill 380 63 -21 380 64 -21 dirt
execute in minecraft:overworld run setblock 380 65 -21 coarse_dirt
execute in minecraft:overworld run fill 380 66 -21 380 144 -21 air
execute in minecraft:overworld run setblock 380 66 -21 mossy_cobblestone
execute in minecraft:overworld run fill 380 58 -20 380 62 -20 stone
execute in minecraft:overworld run fill 380 63 -20 380 64 -20 dirt
execute in minecraft:overworld run setblock 380 65 -20 coarse_dirt
execute in minecraft:overworld run fill 380 66 -20 380 144 -20 air
execute in minecraft:overworld run fill 380 58 -19 380 62 -19 stone
execute in minecraft:overworld run fill 380 63 -19 380 64 -19 dirt
execute in minecraft:overworld run setblock 380 65 -19 coarse_dirt
schedule function blade_gallery:random/battlefield/part_68 1t replace
