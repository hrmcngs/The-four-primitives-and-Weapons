execute in minecraft:overworld run fill 343 63 45 343 64 45 dirt
execute in minecraft:overworld run setblock 343 65 45 coarse_dirt
execute in minecraft:overworld run fill 343 66 45 343 144 45 air
execute in minecraft:overworld run fill 343 58 46 343 62 46 stone
execute in minecraft:overworld run fill 343 63 46 343 64 46 dirt
execute in minecraft:overworld run setblock 343 65 46 coarse_dirt
execute in minecraft:overworld run fill 343 66 46 343 144 46 air
execute in minecraft:overworld run fill 343 58 47 343 61 47 stone
execute in minecraft:overworld run fill 343 62 47 343 63 47 dirt
execute in minecraft:overworld run setblock 343 64 47 grass_block
execute in minecraft:overworld run fill 343 65 47 343 144 47 air
execute in minecraft:overworld run fill 344 58 -48 344 61 -48 stone
execute in minecraft:overworld run fill 344 62 -48 344 63 -48 dirt
execute in minecraft:overworld run setblock 344 64 -48 grass_block
execute in minecraft:overworld run fill 344 65 -48 344 144 -48 air
execute in minecraft:overworld run fill 344 58 -47 344 63 -47 stone
execute in minecraft:overworld run fill 344 64 -47 344 65 -47 dirt
execute in minecraft:overworld run setblock 344 66 -47 grass_block
execute in minecraft:overworld run fill 344 67 -47 344 144 -47 air
execute in minecraft:overworld run fill 344 58 -46 344 65 -46 stone
execute in minecraft:overworld run fill 344 66 -46 344 67 -46 dirt
execute in minecraft:overworld run setblock 344 68 -46 grass_block
execute in minecraft:overworld run fill 344 69 -46 344 144 -46 air
execute in minecraft:overworld run fill 344 58 -45 344 66 -45 stone
execute in minecraft:overworld run fill 344 67 -45 344 68 -45 dirt
execute in minecraft:overworld run setblock 344 69 -45 coarse_dirt
execute in minecraft:overworld run fill 344 70 -45 344 144 -45 air
execute in minecraft:overworld run fill 344 58 -44 344 68 -44 stone
execute in minecraft:overworld run fill 344 69 -44 344 70 -44 dirt
execute in minecraft:overworld run setblock 344 71 -44 coarse_dirt
execute in minecraft:overworld run fill 344 72 -44 344 144 -44 air
execute in minecraft:overworld run fill 344 58 -43 344 70 -43 stone
execute in minecraft:overworld run fill 344 71 -43 344 72 -43 dirt
execute in minecraft:overworld run setblock 344 73 -43 coarse_dirt
execute in minecraft:overworld run fill 344 74 -43 344 144 -43 air
execute in minecraft:overworld run fill 344 58 -42 344 71 -42 stone
execute in minecraft:overworld run fill 344 72 -42 344 73 -42 dirt
execute in minecraft:overworld run setblock 344 74 -42 coarse_dirt
execute in minecraft:overworld run fill 344 75 -42 344 144 -42 air
execute in minecraft:overworld run fill 344 58 -41 344 73 -41 stone
execute in minecraft:overworld run fill 344 74 -41 344 75 -41 dirt
execute in minecraft:overworld run setblock 344 76 -41 grass_block
execute in minecraft:overworld run fill 344 77 -41 344 144 -41 air
execute in minecraft:overworld run fill 344 58 -40 344 74 -40 stone
execute in minecraft:overworld run fill 344 75 -40 344 76 -40 dirt
execute in minecraft:overworld run setblock 344 77 -40 coarse_dirt
execute in minecraft:overworld run fill 344 78 -40 344 144 -40 air
execute in minecraft:overworld run fill 344 58 -39 344 74 -39 stone
execute in minecraft:overworld run fill 344 75 -39 344 76 -39 dirt
execute in minecraft:overworld run setblock 344 77 -39 coarse_dirt
execute in minecraft:overworld run fill 344 78 -39 344 144 -39 air
execute in minecraft:overworld run fill 344 58 -38 344 74 -38 stone
execute in minecraft:overworld run fill 344 75 -38 344 76 -38 dirt
execute in minecraft:overworld run setblock 344 77 -38 grass_block
execute in minecraft:overworld run fill 344 78 -38 344 144 -38 air
execute in minecraft:overworld run fill 344 58 -37 344 74 -37 stone
execute in minecraft:overworld run fill 344 75 -37 344 76 -37 dirt
execute in minecraft:overworld run setblock 344 77 -37 coarse_dirt
execute in minecraft:overworld run fill 344 78 -37 344 144 -37 air
execute in minecraft:overworld run setblock 344 78 -37 grass
execute in minecraft:overworld run fill 344 58 -36 344 74 -36 stone
execute in minecraft:overworld run fill 344 75 -36 344 76 -36 dirt
execute in minecraft:overworld run setblock 344 77 -36 coarse_dirt
execute in minecraft:overworld run fill 344 78 -36 344 144 -36 air
execute in minecraft:overworld run fill 344 58 -35 344 73 -35 stone
execute in minecraft:overworld run fill 344 74 -35 344 75 -35 dirt
execute in minecraft:overworld run setblock 344 76 -35 coarse_dirt
execute in minecraft:overworld run fill 344 77 -35 344 144 -35 air
execute in minecraft:overworld run fill 344 58 -34 344 73 -34 stone
execute in minecraft:overworld run fill 344 74 -34 344 75 -34 dirt
execute in minecraft:overworld run setblock 344 76 -34 grass_block
execute in minecraft:overworld run fill 344 77 -34 344 144 -34 air
execute in minecraft:overworld run fill 344 58 -33 344 73 -33 stone
execute in minecraft:overworld run fill 344 74 -33 344 75 -33 dirt
execute in minecraft:overworld run setblock 344 76 -33 coarse_dirt
execute in minecraft:overworld run fill 344 77 -33 344 144 -33 air
execute in minecraft:overworld run fill 344 58 -32 344 73 -32 stone
execute in minecraft:overworld run fill 344 74 -32 344 75 -32 dirt
execute in minecraft:overworld run setblock 344 76 -32 coarse_dirt
execute in minecraft:overworld run fill 344 77 -32 344 144 -32 air
execute in minecraft:overworld run fill 344 58 -31 344 72 -31 stone
execute in minecraft:overworld run fill 344 73 -31 344 74 -31 dirt
execute in minecraft:overworld run setblock 344 75 -31 coarse_dirt
execute in minecraft:overworld run fill 344 76 -31 344 144 -31 air
execute in minecraft:overworld run fill 344 58 -30 344 72 -30 stone
execute in minecraft:overworld run fill 344 73 -30 344 74 -30 dirt
execute in minecraft:overworld run setblock 344 75 -30 coarse_dirt
execute in minecraft:overworld run fill 344 76 -30 344 144 -30 air
execute in minecraft:overworld run fill 344 58 -29 344 72 -29 stone
execute in minecraft:overworld run fill 344 73 -29 344 74 -29 dirt
execute in minecraft:overworld run setblock 344 75 -29 coarse_dirt
execute in minecraft:overworld run fill 344 76 -29 344 144 -29 air
execute in minecraft:overworld run fill 344 58 -28 344 71 -28 stone
execute in minecraft:overworld run fill 344 72 -28 344 73 -28 dirt
execute in minecraft:overworld run setblock 344 74 -28 coarse_dirt
execute in minecraft:overworld run fill 344 75 -28 344 144 -28 air
execute in minecraft:overworld run fill 344 58 -27 344 71 -27 stone
execute in minecraft:overworld run fill 344 72 -27 344 73 -27 dirt
execute in minecraft:overworld run setblock 344 74 -27 grass_block
execute in minecraft:overworld run fill 344 75 -27 344 144 -27 air
execute in minecraft:overworld run setblock 344 75 -27 grass
execute in minecraft:overworld run fill 344 58 -26 344 71 -26 stone
execute in minecraft:overworld run fill 344 72 -26 344 73 -26 dirt
execute in minecraft:overworld run setblock 344 74 -26 coarse_dirt
execute in minecraft:overworld run fill 344 75 -26 344 144 -26 air
execute in minecraft:overworld run fill 344 58 -25 344 71 -25 stone
execute in minecraft:overworld run fill 344 72 -25 344 73 -25 dirt
execute in minecraft:overworld run setblock 344 74 -25 coarse_dirt
execute in minecraft:overworld run fill 344 75 -25 344 144 -25 air
execute in minecraft:overworld run fill 344 58 -24 344 70 -24 stone
execute in minecraft:overworld run fill 344 71 -24 344 72 -24 dirt
execute in minecraft:overworld run setblock 344 73 -24 coarse_dirt
execute in minecraft:overworld run fill 344 74 -24 344 144 -24 air
execute in minecraft:overworld run fill 344 58 -23 344 70 -23 stone
execute in minecraft:overworld run fill 344 71 -23 344 72 -23 dirt
execute in minecraft:overworld run setblock 344 73 -23 coarse_dirt
execute in minecraft:overworld run fill 344 74 -23 344 144 -23 air
execute in minecraft:overworld run fill 344 58 -22 344 70 -22 stone
execute in minecraft:overworld run fill 344 71 -22 344 72 -22 dirt
execute in minecraft:overworld run setblock 344 73 -22 grass_block
execute in minecraft:overworld run fill 344 74 -22 344 144 -22 air
execute in minecraft:overworld run setblock 344 74 -22 grass
execute in minecraft:overworld run fill 344 58 -21 344 70 -21 stone
execute in minecraft:overworld run fill 344 71 -21 344 72 -21 dirt
execute in minecraft:overworld run setblock 344 73 -21 coarse_dirt
execute in minecraft:overworld run fill 344 74 -21 344 144 -21 air
execute in minecraft:overworld run fill 344 58 -20 344 69 -20 stone
execute in minecraft:overworld run fill 344 70 -20 344 71 -20 dirt
execute in minecraft:overworld run setblock 344 72 -20 coarse_dirt
execute in minecraft:overworld run fill 344 73 -20 344 144 -20 air
execute in minecraft:overworld run fill 344 58 -19 344 69 -19 stone
execute in minecraft:overworld run fill 344 70 -19 344 71 -19 dirt
execute in minecraft:overworld run setblock 344 72 -19 coarse_dirt
execute in minecraft:overworld run fill 344 73 -19 344 144 -19 air
execute in minecraft:overworld run fill 344 58 -18 344 69 -18 stone
execute in minecraft:overworld run fill 344 70 -18 344 71 -18 dirt
execute in minecraft:overworld run setblock 344 72 -18 coarse_dirt
execute in minecraft:overworld run fill 344 73 -18 344 144 -18 air
execute in minecraft:overworld run fill 344 58 -17 344 69 -17 stone
execute in minecraft:overworld run fill 344 70 -17 344 71 -17 dirt
execute in minecraft:overworld run setblock 344 72 -17 coarse_dirt
execute in minecraft:overworld run fill 344 73 -17 344 144 -17 air
execute in minecraft:overworld run setblock 344 73 -17 mossy_cobblestone
execute in minecraft:overworld run fill 344 58 -16 344 68 -16 stone
execute in minecraft:overworld run fill 344 69 -16 344 70 -16 dirt
execute in minecraft:overworld run setblock 344 71 -16 coarse_dirt
execute in minecraft:overworld run fill 344 72 -16 344 144 -16 air
execute in minecraft:overworld run fill 344 58 -15 344 68 -15 stone
execute in minecraft:overworld run fill 344 69 -15 344 70 -15 dirt
execute in minecraft:overworld run setblock 344 71 -15 grass_block
execute in minecraft:overworld run fill 344 72 -15 344 144 -15 air
execute in minecraft:overworld run fill 344 58 -14 344 67 -14 stone
execute in minecraft:overworld run fill 344 68 -14 344 69 -14 dirt
execute in minecraft:overworld run setblock 344 70 -14 coarse_dirt
execute in minecraft:overworld run fill 344 71 -14 344 144 -14 air
execute in minecraft:overworld run setblock 344 71 -14 grass
execute in minecraft:overworld run fill 344 58 -13 344 66 -13 stone
execute in minecraft:overworld run fill 344 67 -13 344 68 -13 dirt
execute in minecraft:overworld run setblock 344 69 -13 grass_block
execute in minecraft:overworld run fill 344 70 -13 344 144 -13 air
execute in minecraft:overworld run fill 344 58 -12 344 66 -12 stone
execute in minecraft:overworld run fill 344 67 -12 344 68 -12 dirt
execute in minecraft:overworld run setblock 344 69 -12 coarse_dirt
execute in minecraft:overworld run fill 344 70 -12 344 144 -12 air
execute in minecraft:overworld run setblock 344 70 -12 grass
execute in minecraft:overworld run fill 344 58 -11 344 66 -11 stone
execute in minecraft:overworld run fill 344 67 -11 344 68 -11 dirt
execute in minecraft:overworld run setblock 344 69 -11 grass_block
execute in minecraft:overworld run fill 344 70 -11 344 144 -11 air
execute in minecraft:overworld run setblock 344 70 -11 grass
execute in minecraft:overworld run fill 344 58 -10 344 65 -10 stone
execute in minecraft:overworld run fill 344 66 -10 344 67 -10 dirt
execute in minecraft:overworld run setblock 344 68 -10 grass_block
execute in minecraft:overworld run fill 344 69 -10 344 144 -10 air
execute in minecraft:overworld run fill 344 58 -9 344 65 -9 stone
execute in minecraft:overworld run fill 344 66 -9 344 67 -9 dirt
execute in minecraft:overworld run setblock 344 68 -9 coarse_dirt
execute in minecraft:overworld run fill 344 69 -9 344 144 -9 air
execute in minecraft:overworld run fill 344 58 -8 344 65 -8 stone
execute in minecraft:overworld run fill 344 66 -8 344 67 -8 dirt
execute in minecraft:overworld run setblock 344 68 -8 coarse_dirt
execute in minecraft:overworld run fill 344 69 -8 344 144 -8 air
execute in minecraft:overworld run fill 344 58 -7 344 65 -7 stone
execute in minecraft:overworld run fill 344 66 -7 344 67 -7 dirt
execute in minecraft:overworld run setblock 344 68 -7 coarse_dirt
execute in minecraft:overworld run fill 344 69 -7 344 144 -7 air
execute in minecraft:overworld run fill 344 58 -6 344 65 -6 stone
execute in minecraft:overworld run fill 344 66 -6 344 67 -6 dirt
execute in minecraft:overworld run setblock 344 68 -6 grass_block
execute in minecraft:overworld run fill 344 69 -6 344 144 -6 air
execute in minecraft:overworld run fill 344 58 -5 344 66 -5 stone
execute in minecraft:overworld run fill 344 67 -5 344 68 -5 dirt
execute in minecraft:overworld run setblock 344 69 -5 coarse_dirt
execute in minecraft:overworld run fill 344 70 -5 344 144 -5 air
execute in minecraft:overworld run setblock 344 70 -5 grass
execute in minecraft:overworld run fill 344 58 -4 344 66 -4 stone
execute in minecraft:overworld run fill 344 67 -4 344 68 -4 dirt
execute in minecraft:overworld run setblock 344 69 -4 grass_block
execute in minecraft:overworld run fill 344 70 -4 344 144 -4 air
execute in minecraft:overworld run fill 344 58 -3 344 66 -3 stone
execute in minecraft:overworld run fill 344 67 -3 344 68 -3 dirt
execute in minecraft:overworld run setblock 344 69 -3 coarse_dirt
execute in minecraft:overworld run fill 344 70 -3 344 144 -3 air
execute in minecraft:overworld run setblock 344 70 -3 grass
execute in minecraft:overworld run fill 344 58 -2 344 66 -2 stone
execute in minecraft:overworld run fill 344 67 -2 344 68 -2 dirt
execute in minecraft:overworld run setblock 344 69 -2 grass_block
execute in minecraft:overworld run fill 344 70 -2 344 144 -2 air
execute in minecraft:overworld run fill 344 58 -1 344 66 -1 stone
execute in minecraft:overworld run fill 344 67 -1 344 68 -1 dirt
execute in minecraft:overworld run setblock 344 69 -1 grass_block
execute in minecraft:overworld run fill 344 70 -1 344 144 -1 air
execute in minecraft:overworld run fill 344 58 0 344 66 0 stone
execute in minecraft:overworld run fill 344 67 0 344 68 0 dirt
execute in minecraft:overworld run setblock 344 69 0 coarse_dirt
execute in minecraft:overworld run fill 344 70 0 344 144 0 air
execute in minecraft:overworld run fill 344 58 1 344 66 1 stone
execute in minecraft:overworld run fill 344 67 1 344 68 1 dirt
execute in minecraft:overworld run setblock 344 69 1 coarse_dirt
execute in minecraft:overworld run fill 344 70 1 344 144 1 air
execute in minecraft:overworld run fill 344 58 2 344 66 2 stone
execute in minecraft:overworld run fill 344 67 2 344 68 2 dirt
execute in minecraft:overworld run setblock 344 69 2 grass_block
execute in minecraft:overworld run fill 344 70 2 344 144 2 air
execute in minecraft:overworld run fill 344 58 3 344 66 3 stone
execute in minecraft:overworld run fill 344 67 3 344 68 3 dirt
execute in minecraft:overworld run setblock 344 69 3 grass_block
execute in minecraft:overworld run fill 344 70 3 344 144 3 air
execute in minecraft:overworld run fill 344 58 4 344 66 4 stone
execute in minecraft:overworld run fill 344 67 4 344 68 4 dirt
execute in minecraft:overworld run setblock 344 69 4 grass_block
execute in minecraft:overworld run fill 344 70 4 344 144 4 air
execute in minecraft:overworld run fill 344 58 5 344 66 5 stone
execute in minecraft:overworld run fill 344 67 5 344 68 5 dirt
execute in minecraft:overworld run setblock 344 69 5 coarse_dirt
execute in minecraft:overworld run fill 344 70 5 344 144 5 air
execute in minecraft:overworld run fill 344 58 6 344 66 6 stone
execute in minecraft:overworld run fill 344 67 6 344 68 6 dirt
execute in minecraft:overworld run setblock 344 69 6 grass_block
execute in minecraft:overworld run fill 344 70 6 344 144 6 air
execute in minecraft:overworld run fill 344 58 7 344 66 7 stone
execute in minecraft:overworld run fill 344 67 7 344 68 7 dirt
execute in minecraft:overworld run setblock 344 69 7 coarse_dirt
execute in minecraft:overworld run fill 344 70 7 344 144 7 air
execute in minecraft:overworld run fill 344 58 8 344 66 8 stone
execute in minecraft:overworld run fill 344 67 8 344 68 8 dirt
execute in minecraft:overworld run setblock 344 69 8 coarse_dirt
execute in minecraft:overworld run fill 344 70 8 344 144 8 air
execute in minecraft:overworld run fill 344 58 9 344 65 9 stone
execute in minecraft:overworld run fill 344 66 9 344 67 9 dirt
execute in minecraft:overworld run setblock 344 68 9 coarse_dirt
execute in minecraft:overworld run fill 344 69 9 344 144 9 air
execute in minecraft:overworld run fill 344 58 10 344 65 10 stone
execute in minecraft:overworld run fill 344 66 10 344 67 10 dirt
execute in minecraft:overworld run setblock 344 68 10 coarse_dirt
execute in minecraft:overworld run fill 344 69 10 344 144 10 air
schedule function blade_gallery:random/battlefield/part_13 1t replace
