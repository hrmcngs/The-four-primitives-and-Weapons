execute in minecraft:overworld run fill 219 71 32 219 72 32 dirt
execute in minecraft:overworld run setblock 219 73 32 coarse_dirt
execute in minecraft:overworld run fill 219 74 32 219 144 32 air
execute in minecraft:overworld run fill 219 58 33 219 70 33 stone
execute in minecraft:overworld run fill 219 71 33 219 72 33 dirt
execute in minecraft:overworld run setblock 219 73 33 coarse_dirt
execute in minecraft:overworld run fill 219 74 33 219 144 33 air
execute in minecraft:overworld run fill 219 58 34 219 70 34 stone
execute in minecraft:overworld run fill 219 71 34 219 72 34 dirt
execute in minecraft:overworld run setblock 219 73 34 grass_block
execute in minecraft:overworld run fill 219 74 34 219 144 34 air
execute in minecraft:overworld run fill 219 58 35 219 69 35 stone
execute in minecraft:overworld run fill 219 70 35 219 71 35 dirt
execute in minecraft:overworld run setblock 219 72 35 grass_block
execute in minecraft:overworld run fill 219 73 35 219 144 35 air
execute in minecraft:overworld run fill 219 58 36 219 69 36 stone
execute in minecraft:overworld run fill 219 70 36 219 71 36 dirt
execute in minecraft:overworld run setblock 219 72 36 coarse_dirt
execute in minecraft:overworld run fill 219 73 36 219 144 36 air
execute in minecraft:overworld run fill 219 58 37 219 69 37 stone
execute in minecraft:overworld run fill 219 70 37 219 71 37 dirt
execute in minecraft:overworld run setblock 219 72 37 coarse_dirt
execute in minecraft:overworld run fill 219 73 37 219 144 37 air
execute in minecraft:overworld run setblock 219 73 37 grass
execute in minecraft:overworld run fill 219 58 38 219 68 38 stone
execute in minecraft:overworld run fill 219 69 38 219 70 38 dirt
execute in minecraft:overworld run setblock 219 71 38 grass_block
execute in minecraft:overworld run fill 219 72 38 219 144 38 air
execute in minecraft:overworld run fill 219 58 39 219 67 39 stone
execute in minecraft:overworld run fill 219 68 39 219 69 39 dirt
execute in minecraft:overworld run setblock 219 70 39 grass_block
execute in minecraft:overworld run fill 219 71 39 219 144 39 air
execute in minecraft:overworld run fill 219 58 40 219 66 40 stone
execute in minecraft:overworld run fill 219 67 40 219 68 40 dirt
execute in minecraft:overworld run setblock 219 69 40 grass_block
execute in minecraft:overworld run fill 219 70 40 219 144 40 air
execute in minecraft:overworld run fill 219 58 41 219 65 41 stone
execute in minecraft:overworld run fill 219 66 41 219 67 41 dirt
execute in minecraft:overworld run setblock 219 68 41 coarse_dirt
execute in minecraft:overworld run fill 219 69 41 219 144 41 air
execute in minecraft:overworld run fill 219 58 42 219 64 42 stone
execute in minecraft:overworld run fill 219 65 42 219 66 42 dirt
execute in minecraft:overworld run setblock 219 67 42 coarse_dirt
execute in minecraft:overworld run fill 219 68 42 219 144 42 air
execute in minecraft:overworld run fill 219 58 43 219 63 43 stone
execute in minecraft:overworld run fill 219 64 43 219 65 43 dirt
execute in minecraft:overworld run setblock 219 66 43 grass_block
execute in minecraft:overworld run fill 219 67 43 219 144 43 air
execute in minecraft:overworld run fill 219 58 44 219 63 44 stone
execute in minecraft:overworld run fill 219 64 44 219 65 44 dirt
execute in minecraft:overworld run setblock 219 66 44 coarse_dirt
execute in minecraft:overworld run fill 219 67 44 219 144 44 air
execute in minecraft:overworld run fill 219 58 45 219 62 45 stone
execute in minecraft:overworld run fill 219 63 45 219 64 45 dirt
execute in minecraft:overworld run setblock 219 65 45 coarse_dirt
execute in minecraft:overworld run fill 219 66 45 219 144 45 air
execute in minecraft:overworld run fill 219 58 46 219 62 46 stone
execute in minecraft:overworld run fill 219 63 46 219 64 46 dirt
execute in minecraft:overworld run setblock 219 65 46 coarse_dirt
execute in minecraft:overworld run fill 219 66 46 219 144 46 air
execute in minecraft:overworld run fill 219 58 47 219 61 47 stone
execute in minecraft:overworld run fill 219 62 47 219 63 47 dirt
execute in minecraft:overworld run setblock 219 64 47 coarse_dirt
execute in minecraft:overworld run fill 219 65 47 219 144 47 air
execute in minecraft:overworld run fill 220 58 -48 220 61 -48 stone
execute in minecraft:overworld run fill 220 62 -48 220 63 -48 dirt
execute in minecraft:overworld run setblock 220 64 -48 grass_block
execute in minecraft:overworld run fill 220 65 -48 220 144 -48 air
execute in minecraft:overworld run fill 220 58 -47 220 63 -47 stone
execute in minecraft:overworld run fill 220 64 -47 220 65 -47 dirt
execute in minecraft:overworld run setblock 220 66 -47 coarse_dirt
execute in minecraft:overworld run fill 220 67 -47 220 144 -47 air
execute in minecraft:overworld run fill 220 58 -46 220 64 -46 stone
execute in minecraft:overworld run fill 220 65 -46 220 66 -46 dirt
execute in minecraft:overworld run setblock 220 67 -46 coarse_dirt
execute in minecraft:overworld run fill 220 68 -46 220 144 -46 air
execute in minecraft:overworld run fill 220 58 -45 220 66 -45 stone
execute in minecraft:overworld run fill 220 67 -45 220 68 -45 dirt
execute in minecraft:overworld run setblock 220 69 -45 coarse_dirt
execute in minecraft:overworld run fill 220 70 -45 220 144 -45 air
execute in minecraft:overworld run fill 220 58 -44 220 67 -44 stone
execute in minecraft:overworld run fill 220 68 -44 220 69 -44 dirt
execute in minecraft:overworld run setblock 220 70 -44 grass_block
execute in minecraft:overworld run fill 220 71 -44 220 144 -44 air
execute in minecraft:overworld run fill 220 58 -43 220 68 -43 stone
execute in minecraft:overworld run fill 220 69 -43 220 70 -43 dirt
execute in minecraft:overworld run setblock 220 71 -43 grass_block
execute in minecraft:overworld run fill 220 72 -43 220 144 -43 air
execute in minecraft:overworld run fill 220 58 -42 220 69 -42 stone
execute in minecraft:overworld run fill 220 70 -42 220 71 -42 dirt
execute in minecraft:overworld run setblock 220 72 -42 coarse_dirt
execute in minecraft:overworld run fill 220 73 -42 220 144 -42 air
execute in minecraft:overworld run fill 220 58 -41 220 70 -41 stone
execute in minecraft:overworld run fill 220 71 -41 220 72 -41 dirt
execute in minecraft:overworld run setblock 220 73 -41 coarse_dirt
execute in minecraft:overworld run fill 220 74 -41 220 144 -41 air
execute in minecraft:overworld run fill 220 58 -40 220 71 -40 stone
execute in minecraft:overworld run fill 220 72 -40 220 73 -40 dirt
execute in minecraft:overworld run setblock 220 74 -40 grass_block
execute in minecraft:overworld run fill 220 75 -40 220 144 -40 air
execute in minecraft:overworld run fill 220 58 -39 220 71 -39 stone
execute in minecraft:overworld run fill 220 72 -39 220 73 -39 dirt
execute in minecraft:overworld run setblock 220 74 -39 grass_block
execute in minecraft:overworld run fill 220 75 -39 220 144 -39 air
execute in minecraft:overworld run setblock 220 75 -39 grass
execute in minecraft:overworld run fill 220 58 -38 220 71 -38 stone
execute in minecraft:overworld run fill 220 72 -38 220 73 -38 dirt
execute in minecraft:overworld run setblock 220 74 -38 coarse_dirt
execute in minecraft:overworld run fill 220 75 -38 220 144 -38 air
execute in minecraft:overworld run fill 220 58 -37 220 71 -37 stone
execute in minecraft:overworld run fill 220 72 -37 220 73 -37 dirt
execute in minecraft:overworld run setblock 220 74 -37 coarse_dirt
execute in minecraft:overworld run fill 220 75 -37 220 144 -37 air
execute in minecraft:overworld run fill 220 58 -36 220 70 -36 stone
execute in minecraft:overworld run fill 220 71 -36 220 72 -36 dirt
execute in minecraft:overworld run setblock 220 73 -36 coarse_dirt
execute in minecraft:overworld run fill 220 74 -36 220 144 -36 air
execute in minecraft:overworld run fill 220 58 -35 220 69 -35 stone
execute in minecraft:overworld run fill 220 70 -35 220 71 -35 dirt
execute in minecraft:overworld run setblock 220 72 -35 grass_block
execute in minecraft:overworld run fill 220 73 -35 220 144 -35 air
execute in minecraft:overworld run fill 220 58 -34 220 69 -34 stone
execute in minecraft:overworld run fill 220 70 -34 220 71 -34 dirt
execute in minecraft:overworld run setblock 220 72 -34 coarse_dirt
execute in minecraft:overworld run fill 220 73 -34 220 144 -34 air
execute in minecraft:overworld run fill 220 58 -33 220 68 -33 stone
execute in minecraft:overworld run fill 220 69 -33 220 70 -33 dirt
execute in minecraft:overworld run setblock 220 71 -33 coarse_dirt
execute in minecraft:overworld run fill 220 72 -33 220 144 -33 air
execute in minecraft:overworld run fill 220 58 -32 220 68 -32 stone
execute in minecraft:overworld run fill 220 69 -32 220 70 -32 dirt
execute in minecraft:overworld run setblock 220 71 -32 grass_block
execute in minecraft:overworld run fill 220 72 -32 220 144 -32 air
execute in minecraft:overworld run fill 220 58 -31 220 67 -31 stone
execute in minecraft:overworld run fill 220 68 -31 220 69 -31 dirt
execute in minecraft:overworld run setblock 220 70 -31 coarse_dirt
execute in minecraft:overworld run fill 220 71 -31 220 144 -31 air
execute in minecraft:overworld run setblock 220 71 -31 grass
execute in minecraft:overworld run fill 220 58 -30 220 67 -30 stone
execute in minecraft:overworld run fill 220 68 -30 220 69 -30 dirt
execute in minecraft:overworld run setblock 220 70 -30 coarse_dirt
execute in minecraft:overworld run fill 220 71 -30 220 144 -30 air
execute in minecraft:overworld run fill 220 58 -29 220 66 -29 stone
execute in minecraft:overworld run fill 220 67 -29 220 68 -29 dirt
execute in minecraft:overworld run setblock 220 69 -29 coarse_dirt
execute in minecraft:overworld run fill 220 70 -29 220 144 -29 air
execute in minecraft:overworld run fill 220 58 -28 220 66 -28 stone
execute in minecraft:overworld run fill 220 67 -28 220 68 -28 dirt
execute in minecraft:overworld run setblock 220 69 -28 grass_block
execute in minecraft:overworld run fill 220 70 -28 220 144 -28 air
execute in minecraft:overworld run fill 220 58 -27 220 66 -27 stone
execute in minecraft:overworld run fill 220 67 -27 220 68 -27 dirt
execute in minecraft:overworld run setblock 220 69 -27 coarse_dirt
execute in minecraft:overworld run fill 220 70 -27 220 144 -27 air
execute in minecraft:overworld run fill 220 58 -26 220 65 -26 stone
execute in minecraft:overworld run fill 220 66 -26 220 67 -26 dirt
execute in minecraft:overworld run setblock 220 68 -26 grass_block
execute in minecraft:overworld run fill 220 69 -26 220 144 -26 air
execute in minecraft:overworld run fill 220 58 -25 220 65 -25 stone
execute in minecraft:overworld run fill 220 66 -25 220 67 -25 dirt
execute in minecraft:overworld run setblock 220 68 -25 coarse_dirt
execute in minecraft:overworld run fill 220 69 -25 220 144 -25 air
execute in minecraft:overworld run fill 220 58 -24 220 65 -24 stone
execute in minecraft:overworld run fill 220 66 -24 220 67 -24 dirt
execute in minecraft:overworld run setblock 220 68 -24 coarse_dirt
execute in minecraft:overworld run fill 220 69 -24 220 144 -24 air
execute in minecraft:overworld run setblock 220 69 -24 grass
execute in minecraft:overworld run fill 220 58 -23 220 65 -23 stone
execute in minecraft:overworld run fill 220 66 -23 220 67 -23 dirt
execute in minecraft:overworld run setblock 220 68 -23 grass_block
execute in minecraft:overworld run fill 220 69 -23 220 144 -23 air
execute in minecraft:overworld run setblock 220 69 -23 grass
execute in minecraft:overworld run fill 220 58 -22 220 66 -22 stone
execute in minecraft:overworld run fill 220 67 -22 220 68 -22 dirt
execute in minecraft:overworld run setblock 220 69 -22 coarse_dirt
execute in minecraft:overworld run fill 220 70 -22 220 144 -22 air
execute in minecraft:overworld run fill 220 58 -21 220 66 -21 stone
execute in minecraft:overworld run fill 220 67 -21 220 68 -21 dirt
execute in minecraft:overworld run setblock 220 69 -21 coarse_dirt
execute in minecraft:overworld run fill 220 70 -21 220 144 -21 air
execute in minecraft:overworld run setblock 220 70 -21 grass
execute in minecraft:overworld run fill 220 58 -20 220 66 -20 stone
execute in minecraft:overworld run fill 220 67 -20 220 68 -20 dirt
execute in minecraft:overworld run setblock 220 69 -20 grass_block
execute in minecraft:overworld run fill 220 70 -20 220 144 -20 air
execute in minecraft:overworld run fill 220 58 -19 220 66 -19 stone
execute in minecraft:overworld run fill 220 67 -19 220 68 -19 dirt
execute in minecraft:overworld run setblock 220 69 -19 grass_block
execute in minecraft:overworld run fill 220 70 -19 220 144 -19 air
execute in minecraft:overworld run fill 220 58 -18 220 66 -18 stone
execute in minecraft:overworld run fill 220 67 -18 220 68 -18 dirt
execute in minecraft:overworld run setblock 220 69 -18 coarse_dirt
execute in minecraft:overworld run fill 220 70 -18 220 144 -18 air
execute in minecraft:overworld run fill 220 58 -17 220 66 -17 stone
execute in minecraft:overworld run fill 220 67 -17 220 68 -17 dirt
execute in minecraft:overworld run setblock 220 69 -17 grass_block
execute in minecraft:overworld run fill 220 70 -17 220 144 -17 air
execute in minecraft:overworld run setblock 220 70 -17 grass
execute in minecraft:overworld run fill 220 58 -16 220 66 -16 stone
execute in minecraft:overworld run fill 220 67 -16 220 68 -16 dirt
execute in minecraft:overworld run setblock 220 69 -16 coarse_dirt
execute in minecraft:overworld run fill 220 70 -16 220 144 -16 air
execute in minecraft:overworld run setblock 220 70 -16 grass
execute in minecraft:overworld run fill 220 58 -15 220 66 -15 stone
execute in minecraft:overworld run fill 220 67 -15 220 68 -15 dirt
execute in minecraft:overworld run setblock 220 69 -15 coarse_dirt
execute in minecraft:overworld run fill 220 70 -15 220 144 -15 air
execute in minecraft:overworld run fill 220 58 -14 220 65 -14 stone
execute in minecraft:overworld run fill 220 66 -14 220 67 -14 dirt
execute in minecraft:overworld run setblock 220 68 -14 grass_block
execute in minecraft:overworld run fill 220 69 -14 220 144 -14 air
execute in minecraft:overworld run fill 220 58 -13 220 65 -13 stone
execute in minecraft:overworld run fill 220 66 -13 220 67 -13 dirt
execute in minecraft:overworld run setblock 220 68 -13 grass_block
execute in minecraft:overworld run fill 220 69 -13 220 144 -13 air
execute in minecraft:overworld run fill 220 58 -12 220 65 -12 stone
execute in minecraft:overworld run fill 220 66 -12 220 67 -12 dirt
execute in minecraft:overworld run setblock 220 68 -12 coarse_dirt
execute in minecraft:overworld run fill 220 69 -12 220 144 -12 air
execute in minecraft:overworld run fill 220 58 -11 220 65 -11 stone
execute in minecraft:overworld run fill 220 66 -11 220 67 -11 dirt
execute in minecraft:overworld run setblock 220 68 -11 grass_block
execute in minecraft:overworld run fill 220 69 -11 220 144 -11 air
execute in minecraft:overworld run fill 220 58 -10 220 65 -10 stone
execute in minecraft:overworld run fill 220 66 -10 220 67 -10 dirt
execute in minecraft:overworld run setblock 220 68 -10 coarse_dirt
execute in minecraft:overworld run fill 220 69 -10 220 144 -10 air
execute in minecraft:overworld run fill 220 58 -9 220 65 -9 stone
execute in minecraft:overworld run fill 220 66 -9 220 67 -9 dirt
execute in minecraft:overworld run setblock 220 68 -9 grass_block
execute in minecraft:overworld run fill 220 69 -9 220 144 -9 air
execute in minecraft:overworld run fill 220 58 -8 220 66 -8 stone
execute in minecraft:overworld run fill 220 67 -8 220 68 -8 dirt
execute in minecraft:overworld run setblock 220 69 -8 coarse_dirt
execute in minecraft:overworld run fill 220 70 -8 220 144 -8 air
execute in minecraft:overworld run fill 220 58 -7 220 66 -7 stone
execute in minecraft:overworld run fill 220 67 -7 220 68 -7 dirt
execute in minecraft:overworld run setblock 220 69 -7 coarse_dirt
execute in minecraft:overworld run fill 220 70 -7 220 144 -7 air
execute in minecraft:overworld run fill 220 58 -6 220 66 -6 stone
execute in minecraft:overworld run fill 220 67 -6 220 68 -6 dirt
execute in minecraft:overworld run setblock 220 69 -6 coarse_dirt
execute in minecraft:overworld run fill 220 70 -6 220 144 -6 air
execute in minecraft:overworld run fill 220 58 -5 220 67 -5 stone
execute in minecraft:overworld run fill 220 68 -5 220 69 -5 dirt
execute in minecraft:overworld run setblock 220 70 -5 grass_block
execute in minecraft:overworld run fill 220 71 -5 220 144 -5 air
execute in minecraft:overworld run fill 220 58 -4 220 67 -4 stone
execute in minecraft:overworld run fill 220 68 -4 220 69 -4 dirt
execute in minecraft:overworld run setblock 220 70 -4 coarse_dirt
execute in minecraft:overworld run fill 220 71 -4 220 144 -4 air
execute in minecraft:overworld run fill 220 58 -3 220 67 -3 stone
execute in minecraft:overworld run fill 220 68 -3 220 69 -3 dirt
execute in minecraft:overworld run setblock 220 70 -3 coarse_dirt
execute in minecraft:overworld run fill 220 71 -3 220 144 -3 air
execute in minecraft:overworld run setblock 220 71 -3 grass
schedule function blade_gallery:random/burned/part_19 1t replace
