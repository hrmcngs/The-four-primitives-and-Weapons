execute in minecraft:overworld run setblock 375 69 -35 grass_block
execute in minecraft:overworld run fill 375 70 -35 375 144 -35 air
execute in minecraft:overworld run fill 375 58 -34 375 66 -34 stone
execute in minecraft:overworld run fill 375 67 -34 375 68 -34 dirt
execute in minecraft:overworld run setblock 375 69 -34 grass_block
execute in minecraft:overworld run fill 375 70 -34 375 144 -34 air
execute in minecraft:overworld run fill 375 58 -33 375 66 -33 stone
execute in minecraft:overworld run fill 375 67 -33 375 68 -33 dirt
execute in minecraft:overworld run setblock 375 69 -33 grass_block
execute in minecraft:overworld run fill 375 70 -33 375 144 -33 air
execute in minecraft:overworld run fill 375 58 -32 375 66 -32 stone
execute in minecraft:overworld run fill 375 67 -32 375 68 -32 dirt
execute in minecraft:overworld run setblock 375 69 -32 coarse_dirt
execute in minecraft:overworld run fill 375 70 -32 375 144 -32 air
execute in minecraft:overworld run fill 375 58 -31 375 66 -31 stone
execute in minecraft:overworld run fill 375 67 -31 375 68 -31 dirt
execute in minecraft:overworld run setblock 375 69 -31 coarse_dirt
execute in minecraft:overworld run fill 375 70 -31 375 144 -31 air
execute in minecraft:overworld run fill 375 58 -30 375 67 -30 stone
execute in minecraft:overworld run fill 375 68 -30 375 69 -30 dirt
execute in minecraft:overworld run setblock 375 70 -30 coarse_dirt
execute in minecraft:overworld run fill 375 71 -30 375 144 -30 air
execute in minecraft:overworld run fill 375 58 -29 375 67 -29 stone
execute in minecraft:overworld run fill 375 68 -29 375 69 -29 dirt
execute in minecraft:overworld run setblock 375 70 -29 coarse_dirt
execute in minecraft:overworld run fill 375 71 -29 375 144 -29 air
execute in minecraft:overworld run fill 375 58 -28 375 67 -28 stone
execute in minecraft:overworld run fill 375 68 -28 375 69 -28 dirt
execute in minecraft:overworld run setblock 375 70 -28 coarse_dirt
execute in minecraft:overworld run fill 375 71 -28 375 144 -28 air
execute in minecraft:overworld run fill 375 58 -27 375 67 -27 stone
execute in minecraft:overworld run fill 375 68 -27 375 69 -27 dirt
execute in minecraft:overworld run setblock 375 70 -27 grass_block
execute in minecraft:overworld run fill 375 71 -27 375 144 -27 air
execute in minecraft:overworld run fill 375 58 -26 375 67 -26 stone
execute in minecraft:overworld run fill 375 68 -26 375 69 -26 dirt
execute in minecraft:overworld run setblock 375 70 -26 coarse_dirt
execute in minecraft:overworld run fill 375 71 -26 375 144 -26 air
execute in minecraft:overworld run fill 375 58 -25 375 67 -25 stone
execute in minecraft:overworld run fill 375 68 -25 375 69 -25 dirt
execute in minecraft:overworld run setblock 375 70 -25 coarse_dirt
execute in minecraft:overworld run fill 375 71 -25 375 144 -25 air
execute in minecraft:overworld run fill 375 58 -24 375 67 -24 stone
execute in minecraft:overworld run fill 375 68 -24 375 69 -24 dirt
execute in minecraft:overworld run setblock 375 70 -24 coarse_dirt
execute in minecraft:overworld run fill 375 71 -24 375 144 -24 air
execute in minecraft:overworld run fill 375 58 -23 375 67 -23 stone
execute in minecraft:overworld run fill 375 68 -23 375 69 -23 dirt
execute in minecraft:overworld run setblock 375 70 -23 coarse_dirt
execute in minecraft:overworld run fill 375 71 -23 375 144 -23 air
execute in minecraft:overworld run fill 375 58 -22 375 67 -22 stone
execute in minecraft:overworld run fill 375 68 -22 375 69 -22 dirt
execute in minecraft:overworld run setblock 375 70 -22 grass_block
execute in minecraft:overworld run fill 375 71 -22 375 144 -22 air
execute in minecraft:overworld run fill 375 58 -21 375 66 -21 stone
execute in minecraft:overworld run fill 375 67 -21 375 68 -21 dirt
execute in minecraft:overworld run setblock 375 69 -21 coarse_dirt
execute in minecraft:overworld run fill 375 70 -21 375 144 -21 air
execute in minecraft:overworld run fill 375 58 -20 375 66 -20 stone
execute in minecraft:overworld run fill 375 67 -20 375 68 -20 dirt
execute in minecraft:overworld run setblock 375 69 -20 grass_block
execute in minecraft:overworld run fill 375 70 -20 375 144 -20 air
execute in minecraft:overworld run fill 375 58 -19 375 66 -19 stone
execute in minecraft:overworld run fill 375 67 -19 375 68 -19 dirt
execute in minecraft:overworld run setblock 375 69 -19 coarse_dirt
execute in minecraft:overworld run fill 375 70 -19 375 144 -19 air
execute in minecraft:overworld run fill 375 58 -18 375 66 -18 stone
execute in minecraft:overworld run fill 375 67 -18 375 68 -18 dirt
execute in minecraft:overworld run setblock 375 69 -18 coarse_dirt
execute in minecraft:overworld run fill 375 70 -18 375 144 -18 air
execute in minecraft:overworld run fill 375 58 -17 375 65 -17 stone
execute in minecraft:overworld run fill 375 66 -17 375 67 -17 dirt
execute in minecraft:overworld run setblock 375 68 -17 coarse_dirt
execute in minecraft:overworld run fill 375 69 -17 375 144 -17 air
execute in minecraft:overworld run fill 375 58 -16 375 65 -16 stone
execute in minecraft:overworld run fill 375 66 -16 375 67 -16 dirt
execute in minecraft:overworld run setblock 375 68 -16 coarse_dirt
execute in minecraft:overworld run fill 375 69 -16 375 144 -16 air
execute in minecraft:overworld run fill 375 58 -15 375 65 -15 stone
execute in minecraft:overworld run fill 375 66 -15 375 67 -15 dirt
execute in minecraft:overworld run setblock 375 68 -15 coarse_dirt
execute in minecraft:overworld run fill 375 69 -15 375 144 -15 air
execute in minecraft:overworld run fill 375 58 -14 375 65 -14 stone
execute in minecraft:overworld run fill 375 66 -14 375 67 -14 dirt
execute in minecraft:overworld run setblock 375 68 -14 coarse_dirt
execute in minecraft:overworld run fill 375 69 -14 375 144 -14 air
execute in minecraft:overworld run setblock 375 69 -14 grass
execute in minecraft:overworld run fill 375 58 -13 375 65 -13 stone
execute in minecraft:overworld run fill 375 66 -13 375 67 -13 dirt
execute in minecraft:overworld run setblock 375 68 -13 coarse_dirt
execute in minecraft:overworld run fill 375 69 -13 375 144 -13 air
execute in minecraft:overworld run fill 375 58 -12 375 65 -12 stone
execute in minecraft:overworld run fill 375 66 -12 375 67 -12 dirt
execute in minecraft:overworld run setblock 375 68 -12 coarse_dirt
execute in minecraft:overworld run fill 375 69 -12 375 144 -12 air
execute in minecraft:overworld run fill 375 58 -11 375 65 -11 stone
execute in minecraft:overworld run fill 375 66 -11 375 67 -11 dirt
execute in minecraft:overworld run setblock 375 68 -11 grass_block
execute in minecraft:overworld run fill 375 69 -11 375 144 -11 air
execute in minecraft:overworld run fill 375 58 -10 375 65 -10 stone
execute in minecraft:overworld run fill 375 66 -10 375 67 -10 dirt
execute in minecraft:overworld run setblock 375 68 -10 grass_block
execute in minecraft:overworld run fill 375 69 -10 375 144 -10 air
execute in minecraft:overworld run fill 375 58 -9 375 65 -9 stone
execute in minecraft:overworld run fill 375 66 -9 375 67 -9 dirt
execute in minecraft:overworld run setblock 375 68 -9 coarse_dirt
execute in minecraft:overworld run fill 375 69 -9 375 144 -9 air
execute in minecraft:overworld run fill 375 58 -8 375 65 -8 stone
execute in minecraft:overworld run fill 375 66 -8 375 67 -8 dirt
execute in minecraft:overworld run setblock 375 68 -8 coarse_dirt
execute in minecraft:overworld run fill 375 69 -8 375 144 -8 air
execute in minecraft:overworld run fill 375 58 -7 375 65 -7 stone
execute in minecraft:overworld run fill 375 66 -7 375 67 -7 dirt
execute in minecraft:overworld run setblock 375 68 -7 coarse_dirt
execute in minecraft:overworld run fill 375 69 -7 375 144 -7 air
execute in minecraft:overworld run fill 375 58 -6 375 65 -6 stone
execute in minecraft:overworld run fill 375 66 -6 375 67 -6 dirt
execute in minecraft:overworld run setblock 375 68 -6 grass_block
execute in minecraft:overworld run fill 375 69 -6 375 144 -6 air
execute in minecraft:overworld run setblock 375 69 -6 grass
execute in minecraft:overworld run fill 375 58 -5 375 65 -5 stone
execute in minecraft:overworld run fill 375 66 -5 375 67 -5 dirt
execute in minecraft:overworld run setblock 375 68 -5 coarse_dirt
execute in minecraft:overworld run fill 375 69 -5 375 144 -5 air
execute in minecraft:overworld run fill 375 58 -4 375 65 -4 stone
execute in minecraft:overworld run fill 375 66 -4 375 67 -4 dirt
execute in minecraft:overworld run setblock 375 68 -4 coarse_dirt
execute in minecraft:overworld run fill 375 69 -4 375 144 -4 air
execute in minecraft:overworld run fill 375 58 -3 375 65 -3 stone
execute in minecraft:overworld run fill 375 66 -3 375 67 -3 dirt
execute in minecraft:overworld run setblock 375 68 -3 coarse_dirt
execute in minecraft:overworld run fill 375 69 -3 375 144 -3 air
execute in minecraft:overworld run fill 375 58 -2 375 65 -2 stone
execute in minecraft:overworld run fill 375 66 -2 375 67 -2 dirt
execute in minecraft:overworld run setblock 375 68 -2 coarse_dirt
execute in minecraft:overworld run fill 375 69 -2 375 144 -2 air
execute in minecraft:overworld run fill 375 58 -1 375 65 -1 stone
execute in minecraft:overworld run fill 375 66 -1 375 67 -1 dirt
execute in minecraft:overworld run setblock 375 68 -1 coarse_dirt
execute in minecraft:overworld run fill 375 69 -1 375 144 -1 air
execute in minecraft:overworld run fill 375 58 0 375 65 0 stone
execute in minecraft:overworld run fill 375 66 0 375 67 0 dirt
execute in minecraft:overworld run setblock 375 68 0 grass_block
execute in minecraft:overworld run fill 375 69 0 375 144 0 air
execute in minecraft:overworld run fill 375 58 1 375 65 1 stone
execute in minecraft:overworld run fill 375 66 1 375 67 1 dirt
execute in minecraft:overworld run setblock 375 68 1 coarse_dirt
execute in minecraft:overworld run fill 375 69 1 375 144 1 air
execute in minecraft:overworld run fill 375 58 2 375 65 2 stone
execute in minecraft:overworld run fill 375 66 2 375 67 2 dirt
execute in minecraft:overworld run setblock 375 68 2 coarse_dirt
execute in minecraft:overworld run fill 375 69 2 375 144 2 air
execute in minecraft:overworld run fill 375 58 3 375 65 3 stone
execute in minecraft:overworld run fill 375 66 3 375 67 3 dirt
execute in minecraft:overworld run setblock 375 68 3 grass_block
execute in minecraft:overworld run fill 375 69 3 375 144 3 air
execute in minecraft:overworld run fill 375 58 4 375 65 4 stone
execute in minecraft:overworld run fill 375 66 4 375 67 4 dirt
execute in minecraft:overworld run setblock 375 68 4 coarse_dirt
execute in minecraft:overworld run fill 375 69 4 375 144 4 air
execute in minecraft:overworld run fill 375 58 5 375 65 5 stone
execute in minecraft:overworld run fill 375 66 5 375 67 5 dirt
execute in minecraft:overworld run setblock 375 68 5 coarse_dirt
execute in minecraft:overworld run fill 375 69 5 375 144 5 air
execute in minecraft:overworld run fill 375 58 6 375 65 6 stone
execute in minecraft:overworld run fill 375 66 6 375 67 6 dirt
execute in minecraft:overworld run setblock 375 68 6 coarse_dirt
execute in minecraft:overworld run fill 375 69 6 375 144 6 air
execute in minecraft:overworld run fill 375 58 7 375 65 7 stone
execute in minecraft:overworld run fill 375 66 7 375 67 7 dirt
execute in minecraft:overworld run setblock 375 68 7 coarse_dirt
execute in minecraft:overworld run fill 375 69 7 375 144 7 air
execute in minecraft:overworld run fill 375 58 8 375 65 8 stone
execute in minecraft:overworld run fill 375 66 8 375 67 8 dirt
execute in minecraft:overworld run setblock 375 68 8 grass_block
execute in minecraft:overworld run fill 375 69 8 375 144 8 air
execute in minecraft:overworld run fill 375 58 9 375 66 9 stone
execute in minecraft:overworld run fill 375 67 9 375 68 9 dirt
execute in minecraft:overworld run setblock 375 69 9 grass_block
execute in minecraft:overworld run fill 375 70 9 375 144 9 air
execute in minecraft:overworld run setblock 375 70 9 grass
execute in minecraft:overworld run fill 375 58 10 375 66 10 stone
execute in minecraft:overworld run fill 375 67 10 375 68 10 dirt
execute in minecraft:overworld run setblock 375 69 10 grass_block
execute in minecraft:overworld run fill 375 70 10 375 144 10 air
execute in minecraft:overworld run fill 375 58 11 375 66 11 stone
execute in minecraft:overworld run fill 375 67 11 375 68 11 dirt
execute in minecraft:overworld run setblock 375 69 11 grass_block
execute in minecraft:overworld run fill 375 70 11 375 144 11 air
execute in minecraft:overworld run fill 375 58 12 375 66 12 stone
execute in minecraft:overworld run fill 375 67 12 375 68 12 dirt
execute in minecraft:overworld run setblock 375 69 12 grass_block
execute in minecraft:overworld run fill 375 70 12 375 144 12 air
execute in minecraft:overworld run fill 375 58 13 375 67 13 stone
execute in minecraft:overworld run fill 375 68 13 375 69 13 dirt
execute in minecraft:overworld run setblock 375 70 13 grass_block
execute in minecraft:overworld run fill 375 71 13 375 144 13 air
execute in minecraft:overworld run fill 375 58 14 375 67 14 stone
execute in minecraft:overworld run fill 375 68 14 375 69 14 dirt
execute in minecraft:overworld run setblock 375 70 14 coarse_dirt
execute in minecraft:overworld run fill 375 71 14 375 144 14 air
execute in minecraft:overworld run fill 375 58 15 375 67 15 stone
execute in minecraft:overworld run fill 375 68 15 375 69 15 dirt
execute in minecraft:overworld run setblock 375 70 15 grass_block
execute in minecraft:overworld run fill 375 71 15 375 144 15 air
execute in minecraft:overworld run fill 375 58 16 375 68 16 stone
execute in minecraft:overworld run fill 375 69 16 375 70 16 dirt
execute in minecraft:overworld run setblock 375 71 16 grass_block
execute in minecraft:overworld run fill 375 72 16 375 144 16 air
execute in minecraft:overworld run setblock 375 72 16 grass
execute in minecraft:overworld run fill 375 58 17 375 68 17 stone
execute in minecraft:overworld run fill 375 69 17 375 70 17 dirt
execute in minecraft:overworld run setblock 375 71 17 coarse_dirt
execute in minecraft:overworld run fill 375 72 17 375 144 17 air
execute in minecraft:overworld run setblock 375 72 17 grass
execute in minecraft:overworld run fill 375 58 18 375 68 18 stone
execute in minecraft:overworld run fill 375 69 18 375 70 18 dirt
execute in minecraft:overworld run setblock 375 71 18 coarse_dirt
execute in minecraft:overworld run fill 375 72 18 375 144 18 air
execute in minecraft:overworld run fill 375 58 19 375 68 19 stone
execute in minecraft:overworld run fill 375 69 19 375 70 19 dirt
execute in minecraft:overworld run setblock 375 71 19 grass_block
execute in minecraft:overworld run fill 375 72 19 375 144 19 air
execute in minecraft:overworld run fill 375 58 20 375 68 20 stone
execute in minecraft:overworld run fill 375 69 20 375 70 20 dirt
execute in minecraft:overworld run setblock 375 71 20 coarse_dirt
execute in minecraft:overworld run fill 375 72 20 375 144 20 air
execute in minecraft:overworld run fill 375 58 21 375 68 21 stone
execute in minecraft:overworld run fill 375 69 21 375 70 21 dirt
execute in minecraft:overworld run setblock 375 71 21 coarse_dirt
execute in minecraft:overworld run fill 375 72 21 375 144 21 air
execute in minecraft:overworld run fill 375 58 22 375 68 22 stone
execute in minecraft:overworld run fill 375 69 22 375 70 22 dirt
execute in minecraft:overworld run setblock 375 71 22 coarse_dirt
execute in minecraft:overworld run fill 375 72 22 375 144 22 air
execute in minecraft:overworld run fill 375 58 23 375 68 23 stone
execute in minecraft:overworld run fill 375 69 23 375 70 23 dirt
execute in minecraft:overworld run setblock 375 71 23 coarse_dirt
execute in minecraft:overworld run fill 375 72 23 375 144 23 air
execute in minecraft:overworld run fill 375 58 24 375 68 24 stone
execute in minecraft:overworld run fill 375 69 24 375 70 24 dirt
execute in minecraft:overworld run setblock 375 71 24 coarse_dirt
execute in minecraft:overworld run fill 375 72 24 375 144 24 air
execute in minecraft:overworld run fill 375 58 25 375 67 25 stone
execute in minecraft:overworld run fill 375 68 25 375 69 25 dirt
execute in minecraft:overworld run setblock 375 70 25 coarse_dirt
execute in minecraft:overworld run fill 375 71 25 375 144 25 air
execute in minecraft:overworld run fill 375 58 26 375 67 26 stone
execute in minecraft:overworld run fill 375 68 26 375 69 26 dirt
execute in minecraft:overworld run setblock 375 70 26 coarse_dirt
execute in minecraft:overworld run fill 375 71 26 375 144 26 air
execute in minecraft:overworld run fill 375 58 27 375 67 27 stone
execute in minecraft:overworld run fill 375 68 27 375 69 27 dirt
execute in minecraft:overworld run setblock 375 70 27 grass_block
execute in minecraft:overworld run fill 375 71 27 375 144 27 air
execute in minecraft:overworld run setblock 375 71 27 grass
schedule function blade_gallery:random/battlefield/part_61 1t replace
