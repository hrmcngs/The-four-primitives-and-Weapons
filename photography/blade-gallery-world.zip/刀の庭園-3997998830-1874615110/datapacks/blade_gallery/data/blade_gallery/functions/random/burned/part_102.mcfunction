execute in minecraft:overworld run fill 272 75 -26 272 76 -26 dirt
execute in minecraft:overworld run setblock 272 77 -26 coarse_dirt
execute in minecraft:overworld run fill 272 78 -26 272 144 -26 air
execute in minecraft:overworld run fill 272 58 -25 272 73 -25 stone
execute in minecraft:overworld run fill 272 74 -25 272 75 -25 dirt
execute in minecraft:overworld run setblock 272 76 -25 coarse_dirt
execute in minecraft:overworld run fill 272 77 -25 272 144 -25 air
execute in minecraft:overworld run fill 272 58 -24 272 73 -24 stone
execute in minecraft:overworld run fill 272 74 -24 272 75 -24 dirt
execute in minecraft:overworld run setblock 272 76 -24 coarse_dirt
execute in minecraft:overworld run fill 272 77 -24 272 144 -24 air
execute in minecraft:overworld run fill 272 58 -23 272 73 -23 stone
execute in minecraft:overworld run fill 272 74 -23 272 75 -23 dirt
execute in minecraft:overworld run setblock 272 76 -23 grass_block
execute in minecraft:overworld run fill 272 77 -23 272 144 -23 air
execute in minecraft:overworld run fill 272 58 -22 272 72 -22 stone
execute in minecraft:overworld run fill 272 73 -22 272 74 -22 dirt
execute in minecraft:overworld run setblock 272 75 -22 coarse_dirt
execute in minecraft:overworld run fill 272 76 -22 272 144 -22 air
execute in minecraft:overworld run fill 272 58 -21 272 72 -21 stone
execute in minecraft:overworld run fill 272 73 -21 272 74 -21 dirt
execute in minecraft:overworld run setblock 272 75 -21 coarse_dirt
execute in minecraft:overworld run fill 272 76 -21 272 144 -21 air
execute in minecraft:overworld run fill 272 58 -20 272 71 -20 stone
execute in minecraft:overworld run fill 272 72 -20 272 73 -20 dirt
execute in minecraft:overworld run setblock 272 74 -20 coarse_dirt
execute in minecraft:overworld run fill 272 75 -20 272 144 -20 air
execute in minecraft:overworld run fill 272 58 -19 272 71 -19 stone
execute in minecraft:overworld run fill 272 72 -19 272 73 -19 dirt
execute in minecraft:overworld run setblock 272 74 -19 coarse_dirt
execute in minecraft:overworld run fill 272 75 -19 272 144 -19 air
execute in minecraft:overworld run fill 272 58 -18 272 70 -18 stone
execute in minecraft:overworld run fill 272 71 -18 272 72 -18 dirt
execute in minecraft:overworld run setblock 272 73 -18 coarse_dirt
execute in minecraft:overworld run fill 272 74 -18 272 144 -18 air
execute in minecraft:overworld run fill 272 58 -17 272 70 -17 stone
execute in minecraft:overworld run fill 272 71 -17 272 72 -17 dirt
execute in minecraft:overworld run setblock 272 73 -17 grass_block
execute in minecraft:overworld run fill 272 74 -17 272 144 -17 air
execute in minecraft:overworld run fill 272 58 -16 272 69 -16 stone
execute in minecraft:overworld run fill 272 70 -16 272 71 -16 dirt
execute in minecraft:overworld run setblock 272 72 -16 grass_block
execute in minecraft:overworld run fill 272 73 -16 272 144 -16 air
execute in minecraft:overworld run fill 272 58 -15 272 68 -15 stone
execute in minecraft:overworld run fill 272 69 -15 272 70 -15 dirt
execute in minecraft:overworld run setblock 272 71 -15 coarse_dirt
execute in minecraft:overworld run fill 272 72 -15 272 144 -15 air
execute in minecraft:overworld run fill 272 58 -14 272 67 -14 stone
execute in minecraft:overworld run fill 272 68 -14 272 69 -14 dirt
execute in minecraft:overworld run setblock 272 70 -14 coarse_dirt
execute in minecraft:overworld run fill 272 71 -14 272 144 -14 air
execute in minecraft:overworld run setblock 272 71 -14 grass
execute in minecraft:overworld run fill 272 58 -13 272 67 -13 stone
execute in minecraft:overworld run fill 272 68 -13 272 69 -13 dirt
execute in minecraft:overworld run setblock 272 70 -13 coarse_dirt
execute in minecraft:overworld run fill 272 71 -13 272 144 -13 air
execute in minecraft:overworld run fill 272 58 -12 272 66 -12 stone
execute in minecraft:overworld run fill 272 67 -12 272 68 -12 dirt
execute in minecraft:overworld run setblock 272 69 -12 coarse_dirt
execute in minecraft:overworld run fill 272 70 -12 272 144 -12 air
execute in minecraft:overworld run fill 272 58 -11 272 65 -11 stone
execute in minecraft:overworld run fill 272 66 -11 272 67 -11 dirt
execute in minecraft:overworld run setblock 272 68 -11 coarse_dirt
execute in minecraft:overworld run fill 272 69 -11 272 144 -11 air
execute in minecraft:overworld run fill 272 58 -10 272 65 -10 stone
execute in minecraft:overworld run fill 272 66 -10 272 67 -10 dirt
execute in minecraft:overworld run setblock 272 68 -10 coarse_dirt
execute in minecraft:overworld run fill 272 69 -10 272 144 -10 air
execute in minecraft:overworld run setblock 272 69 -10 grass
execute in minecraft:overworld run fill 272 58 -9 272 64 -9 stone
execute in minecraft:overworld run fill 272 65 -9 272 66 -9 dirt
execute in minecraft:overworld run setblock 272 67 -9 coarse_dirt
execute in minecraft:overworld run fill 272 68 -9 272 144 -9 air
execute in minecraft:overworld run fill 272 58 -8 272 64 -8 stone
execute in minecraft:overworld run fill 272 65 -8 272 66 -8 dirt
execute in minecraft:overworld run setblock 272 67 -8 coarse_dirt
execute in minecraft:overworld run fill 272 68 -8 272 144 -8 air
execute in minecraft:overworld run fill 272 58 -7 272 64 -7 stone
execute in minecraft:overworld run fill 272 65 -7 272 66 -7 dirt
execute in minecraft:overworld run setblock 272 67 -7 grass_block
execute in minecraft:overworld run fill 272 68 -7 272 144 -7 air
execute in minecraft:overworld run fill 272 58 -6 272 63 -6 stone
execute in minecraft:overworld run fill 272 64 -6 272 65 -6 dirt
execute in minecraft:overworld run setblock 272 66 -6 grass_block
execute in minecraft:overworld run fill 272 67 -6 272 144 -6 air
execute in minecraft:overworld run fill 272 58 -5 272 63 -5 stone
execute in minecraft:overworld run fill 272 64 -5 272 65 -5 dirt
execute in minecraft:overworld run setblock 272 66 -5 coarse_dirt
execute in minecraft:overworld run fill 272 67 -5 272 144 -5 air
execute in minecraft:overworld run fill 272 58 -4 272 62 -4 stone
execute in minecraft:overworld run fill 272 63 -4 272 64 -4 dirt
execute in minecraft:overworld run setblock 272 65 -4 coarse_dirt
execute in minecraft:overworld run fill 272 66 -4 272 144 -4 air
execute in minecraft:overworld run setblock 272 66 -4 grass
execute in minecraft:overworld run fill 272 58 -3 272 62 -3 stone
execute in minecraft:overworld run fill 272 63 -3 272 64 -3 dirt
execute in minecraft:overworld run setblock 272 65 -3 coarse_dirt
execute in minecraft:overworld run fill 272 66 -3 272 144 -3 air
execute in minecraft:overworld run fill 272 58 -2 272 61 -2 stone
execute in minecraft:overworld run fill 272 62 -2 272 63 -2 dirt
execute in minecraft:overworld run setblock 272 64 -2 coarse_dirt
execute in minecraft:overworld run fill 272 65 -2 272 144 -2 air
execute in minecraft:overworld run fill 272 58 -1 272 61 -1 stone
execute in minecraft:overworld run fill 272 62 -1 272 63 -1 dirt
execute in minecraft:overworld run setblock 272 64 -1 grass_block
execute in minecraft:overworld run fill 272 65 -1 272 144 -1 air
execute in minecraft:overworld run fill 272 58 0 272 61 0 stone
execute in minecraft:overworld run fill 272 62 0 272 63 0 dirt
execute in minecraft:overworld run setblock 272 64 0 coarse_dirt
execute in minecraft:overworld run fill 272 65 0 272 144 0 air
execute in minecraft:overworld run fill 272 58 1 272 61 1 stone
execute in minecraft:overworld run fill 272 62 1 272 63 1 dirt
execute in minecraft:overworld run setblock 272 64 1 coarse_dirt
execute in minecraft:overworld run fill 272 65 1 272 144 1 air
execute in minecraft:overworld run fill 272 58 2 272 60 2 stone
execute in minecraft:overworld run fill 272 61 2 272 62 2 dirt
execute in minecraft:overworld run setblock 272 63 2 gravel
execute in minecraft:overworld run fill 272 64 2 272 144 2 air
execute in minecraft:overworld run fill 272 64 2 272 64 2 water
execute in minecraft:overworld run fill 272 58 3 272 60 3 stone
execute in minecraft:overworld run fill 272 61 3 272 62 3 dirt
execute in minecraft:overworld run setblock 272 63 3 gravel
execute in minecraft:overworld run fill 272 64 3 272 144 3 air
execute in minecraft:overworld run fill 272 64 3 272 64 3 water
execute in minecraft:overworld run fill 272 58 4 272 60 4 stone
execute in minecraft:overworld run fill 272 61 4 272 62 4 dirt
execute in minecraft:overworld run setblock 272 63 4 gravel
execute in minecraft:overworld run fill 272 64 4 272 144 4 air
execute in minecraft:overworld run fill 272 64 4 272 64 4 water
execute in minecraft:overworld run fill 272 58 5 272 60 5 stone
execute in minecraft:overworld run fill 272 61 5 272 62 5 dirt
execute in minecraft:overworld run setblock 272 63 5 gravel
execute in minecraft:overworld run fill 272 64 5 272 144 5 air
execute in minecraft:overworld run fill 272 64 5 272 64 5 water
execute in minecraft:overworld run fill 272 58 6 272 60 6 stone
execute in minecraft:overworld run fill 272 61 6 272 62 6 dirt
execute in minecraft:overworld run setblock 272 63 6 gravel
execute in minecraft:overworld run fill 272 64 6 272 144 6 air
execute in minecraft:overworld run fill 272 64 6 272 64 6 water
execute in minecraft:overworld run fill 272 58 7 272 60 7 stone
execute in minecraft:overworld run fill 272 61 7 272 62 7 dirt
execute in minecraft:overworld run setblock 272 63 7 gravel
execute in minecraft:overworld run fill 272 64 7 272 144 7 air
execute in minecraft:overworld run fill 272 64 7 272 64 7 water
execute in minecraft:overworld run fill 272 58 8 272 60 8 stone
execute in minecraft:overworld run fill 272 61 8 272 62 8 dirt
execute in minecraft:overworld run setblock 272 63 8 gravel
execute in minecraft:overworld run fill 272 64 8 272 144 8 air
execute in minecraft:overworld run fill 272 64 8 272 64 8 water
execute in minecraft:overworld run fill 272 58 9 272 60 9 stone
execute in minecraft:overworld run fill 272 61 9 272 62 9 dirt
execute in minecraft:overworld run setblock 272 63 9 gravel
execute in minecraft:overworld run fill 272 64 9 272 144 9 air
execute in minecraft:overworld run fill 272 64 9 272 64 9 water
execute in minecraft:overworld run fill 272 58 10 272 59 10 stone
execute in minecraft:overworld run fill 272 60 10 272 61 10 dirt
execute in minecraft:overworld run setblock 272 62 10 gravel
execute in minecraft:overworld run fill 272 63 10 272 144 10 air
execute in minecraft:overworld run fill 272 63 10 272 64 10 water
execute in minecraft:overworld run fill 272 58 11 272 59 11 stone
execute in minecraft:overworld run fill 272 60 11 272 61 11 dirt
execute in minecraft:overworld run setblock 272 62 11 gravel
execute in minecraft:overworld run fill 272 63 11 272 144 11 air
execute in minecraft:overworld run fill 272 63 11 272 64 11 water
execute in minecraft:overworld run fill 272 58 12 272 59 12 stone
execute in minecraft:overworld run fill 272 60 12 272 61 12 dirt
execute in minecraft:overworld run setblock 272 62 12 gravel
execute in minecraft:overworld run fill 272 63 12 272 144 12 air
execute in minecraft:overworld run fill 272 63 12 272 64 12 water
execute in minecraft:overworld run fill 272 58 13 272 59 13 stone
execute in minecraft:overworld run fill 272 60 13 272 61 13 dirt
execute in minecraft:overworld run setblock 272 62 13 gravel
execute in minecraft:overworld run fill 272 63 13 272 144 13 air
execute in minecraft:overworld run fill 272 63 13 272 64 13 water
execute in minecraft:overworld run fill 272 58 14 272 58 14 stone
execute in minecraft:overworld run fill 272 59 14 272 60 14 dirt
execute in minecraft:overworld run setblock 272 61 14 gravel
execute in minecraft:overworld run fill 272 62 14 272 144 14 air
execute in minecraft:overworld run fill 272 62 14 272 64 14 water
execute in minecraft:overworld run fill 272 58 15 272 58 15 stone
execute in minecraft:overworld run fill 272 59 15 272 60 15 dirt
execute in minecraft:overworld run setblock 272 61 15 gravel
execute in minecraft:overworld run fill 272 62 15 272 144 15 air
execute in minecraft:overworld run fill 272 62 15 272 64 15 water
execute in minecraft:overworld run fill 272 58 16 272 58 16 stone
execute in minecraft:overworld run fill 272 59 16 272 60 16 dirt
execute in minecraft:overworld run setblock 272 61 16 gravel
execute in minecraft:overworld run fill 272 62 16 272 144 16 air
execute in minecraft:overworld run fill 272 62 16 272 64 16 water
execute in minecraft:overworld run fill 272 58 17 272 58 17 stone
execute in minecraft:overworld run fill 272 59 17 272 60 17 dirt
execute in minecraft:overworld run setblock 272 61 17 gravel
execute in minecraft:overworld run fill 272 62 17 272 144 17 air
execute in minecraft:overworld run fill 272 62 17 272 64 17 water
execute in minecraft:overworld run fill 272 58 18 272 58 18 stone
execute in minecraft:overworld run fill 272 59 18 272 60 18 dirt
execute in minecraft:overworld run setblock 272 61 18 gravel
execute in minecraft:overworld run fill 272 62 18 272 144 18 air
execute in minecraft:overworld run fill 272 62 18 272 64 18 water
execute in minecraft:overworld run fill 272 58 19 272 58 19 stone
execute in minecraft:overworld run fill 272 59 19 272 60 19 dirt
execute in minecraft:overworld run setblock 272 61 19 gravel
execute in minecraft:overworld run fill 272 62 19 272 144 19 air
execute in minecraft:overworld run fill 272 62 19 272 64 19 water
execute in minecraft:overworld run fill 272 58 20 272 58 20 stone
execute in minecraft:overworld run fill 272 59 20 272 60 20 dirt
execute in minecraft:overworld run setblock 272 61 20 gravel
execute in minecraft:overworld run fill 272 62 20 272 144 20 air
execute in minecraft:overworld run fill 272 62 20 272 64 20 water
execute in minecraft:overworld run fill 272 58 21 272 58 21 stone
execute in minecraft:overworld run fill 272 59 21 272 60 21 dirt
execute in minecraft:overworld run setblock 272 61 21 gravel
execute in minecraft:overworld run fill 272 62 21 272 144 21 air
execute in minecraft:overworld run fill 272 62 21 272 64 21 water
execute in minecraft:overworld run fill 272 58 22 272 58 22 stone
execute in minecraft:overworld run fill 272 59 22 272 60 22 dirt
execute in minecraft:overworld run setblock 272 61 22 gravel
execute in minecraft:overworld run fill 272 62 22 272 144 22 air
execute in minecraft:overworld run fill 272 62 22 272 64 22 water
execute in minecraft:overworld run fill 272 58 23 272 58 23 stone
execute in minecraft:overworld run fill 272 59 23 272 60 23 dirt
execute in minecraft:overworld run setblock 272 61 23 gravel
execute in minecraft:overworld run fill 272 62 23 272 144 23 air
execute in minecraft:overworld run fill 272 62 23 272 64 23 water
execute in minecraft:overworld run fill 272 58 24 272 58 24 stone
execute in minecraft:overworld run fill 272 59 24 272 60 24 dirt
execute in minecraft:overworld run setblock 272 61 24 gravel
execute in minecraft:overworld run fill 272 62 24 272 144 24 air
execute in minecraft:overworld run fill 272 62 24 272 64 24 water
execute in minecraft:overworld run fill 272 58 25 272 59 25 stone
execute in minecraft:overworld run fill 272 60 25 272 61 25 dirt
execute in minecraft:overworld run setblock 272 62 25 gravel
execute in minecraft:overworld run fill 272 63 25 272 144 25 air
execute in minecraft:overworld run fill 272 63 25 272 64 25 water
execute in minecraft:overworld run fill 272 58 26 272 59 26 stone
execute in minecraft:overworld run fill 272 60 26 272 61 26 dirt
execute in minecraft:overworld run setblock 272 62 26 gravel
execute in minecraft:overworld run fill 272 63 26 272 144 26 air
execute in minecraft:overworld run fill 272 63 26 272 64 26 water
execute in minecraft:overworld run fill 272 58 27 272 59 27 stone
execute in minecraft:overworld run fill 272 60 27 272 61 27 dirt
execute in minecraft:overworld run setblock 272 62 27 gravel
execute in minecraft:overworld run fill 272 63 27 272 144 27 air
execute in minecraft:overworld run fill 272 63 27 272 64 27 water
execute in minecraft:overworld run fill 272 58 28 272 60 28 stone
execute in minecraft:overworld run fill 272 61 28 272 62 28 dirt
execute in minecraft:overworld run setblock 272 63 28 gravel
execute in minecraft:overworld run fill 272 64 28 272 144 28 air
execute in minecraft:overworld run fill 272 64 28 272 64 28 water
execute in minecraft:overworld run fill 272 58 29 272 60 29 stone
execute in minecraft:overworld run fill 272 61 29 272 62 29 dirt
execute in minecraft:overworld run setblock 272 63 29 gravel
execute in minecraft:overworld run fill 272 64 29 272 144 29 air
execute in minecraft:overworld run fill 272 64 29 272 64 29 water
execute in minecraft:overworld run fill 272 58 30 272 60 30 stone
execute in minecraft:overworld run fill 272 61 30 272 62 30 dirt
schedule function blade_gallery:random/burned/part_103 1t replace
