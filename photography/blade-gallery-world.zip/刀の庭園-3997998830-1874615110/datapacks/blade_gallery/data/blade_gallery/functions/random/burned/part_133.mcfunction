execute in minecraft:overworld run setblock 292 77 -26 coarse_dirt
execute in minecraft:overworld run fill 292 78 -26 292 144 -26 air
execute in minecraft:overworld run fill 292 58 -25 292 73 -25 stone
execute in minecraft:overworld run fill 292 74 -25 292 75 -25 dirt
execute in minecraft:overworld run setblock 292 76 -25 coarse_dirt
execute in minecraft:overworld run fill 292 77 -25 292 144 -25 air
execute in minecraft:overworld run fill 292 58 -24 292 73 -24 stone
execute in minecraft:overworld run fill 292 74 -24 292 75 -24 dirt
execute in minecraft:overworld run setblock 292 76 -24 coarse_dirt
execute in minecraft:overworld run fill 292 77 -24 292 144 -24 air
execute in minecraft:overworld run fill 292 58 -23 292 73 -23 stone
execute in minecraft:overworld run fill 292 74 -23 292 75 -23 dirt
execute in minecraft:overworld run setblock 292 76 -23 coarse_dirt
execute in minecraft:overworld run fill 292 77 -23 292 144 -23 air
execute in minecraft:overworld run fill 292 58 -22 292 72 -22 stone
execute in minecraft:overworld run fill 292 73 -22 292 74 -22 dirt
execute in minecraft:overworld run setblock 292 75 -22 coarse_dirt
execute in minecraft:overworld run fill 292 76 -22 292 144 -22 air
execute in minecraft:overworld run fill 292 58 -21 292 72 -21 stone
execute in minecraft:overworld run fill 292 73 -21 292 74 -21 dirt
execute in minecraft:overworld run setblock 292 75 -21 coarse_dirt
execute in minecraft:overworld run fill 292 76 -21 292 144 -21 air
execute in minecraft:overworld run fill 292 58 -20 292 71 -20 stone
execute in minecraft:overworld run fill 292 72 -20 292 73 -20 dirt
execute in minecraft:overworld run setblock 292 74 -20 coarse_dirt
execute in minecraft:overworld run fill 292 75 -20 292 144 -20 air
execute in minecraft:overworld run setblock 292 75 -20 grass
execute in minecraft:overworld run fill 292 58 -19 292 71 -19 stone
execute in minecraft:overworld run fill 292 72 -19 292 73 -19 dirt
execute in minecraft:overworld run setblock 292 74 -19 coarse_dirt
execute in minecraft:overworld run fill 292 75 -19 292 144 -19 air
execute in minecraft:overworld run fill 292 58 -18 292 71 -18 stone
execute in minecraft:overworld run fill 292 72 -18 292 73 -18 dirt
execute in minecraft:overworld run setblock 292 74 -18 coarse_dirt
execute in minecraft:overworld run fill 292 75 -18 292 144 -18 air
execute in minecraft:overworld run fill 292 58 -17 292 70 -17 stone
execute in minecraft:overworld run fill 292 71 -17 292 72 -17 dirt
execute in minecraft:overworld run setblock 292 73 -17 coarse_dirt
execute in minecraft:overworld run fill 292 74 -17 292 144 -17 air
execute in minecraft:overworld run fill 292 58 -16 292 70 -16 stone
execute in minecraft:overworld run fill 292 71 -16 292 72 -16 dirt
execute in minecraft:overworld run setblock 292 73 -16 coarse_dirt
execute in minecraft:overworld run fill 292 74 -16 292 144 -16 air
execute in minecraft:overworld run fill 292 58 -15 292 70 -15 stone
execute in minecraft:overworld run fill 292 71 -15 292 72 -15 dirt
execute in minecraft:overworld run setblock 292 73 -15 coarse_dirt
execute in minecraft:overworld run fill 292 74 -15 292 144 -15 air
execute in minecraft:overworld run fill 292 58 -14 292 69 -14 stone
execute in minecraft:overworld run fill 292 70 -14 292 71 -14 dirt
execute in minecraft:overworld run setblock 292 72 -14 coarse_dirt
execute in minecraft:overworld run fill 292 73 -14 292 144 -14 air
execute in minecraft:overworld run fill 292 58 -13 292 69 -13 stone
execute in minecraft:overworld run fill 292 70 -13 292 71 -13 dirt
execute in minecraft:overworld run setblock 292 72 -13 coarse_dirt
execute in minecraft:overworld run fill 292 73 -13 292 144 -13 air
execute in minecraft:overworld run setblock 292 73 -13 grass
execute in minecraft:overworld run fill 292 58 -12 292 69 -12 stone
execute in minecraft:overworld run fill 292 70 -12 292 71 -12 dirt
execute in minecraft:overworld run setblock 292 72 -12 grass_block
execute in minecraft:overworld run fill 292 73 -12 292 144 -12 air
execute in minecraft:overworld run fill 292 58 -11 292 69 -11 stone
execute in minecraft:overworld run fill 292 70 -11 292 71 -11 dirt
execute in minecraft:overworld run setblock 292 72 -11 coarse_dirt
execute in minecraft:overworld run fill 292 73 -11 292 144 -11 air
execute in minecraft:overworld run fill 292 58 -10 292 69 -10 stone
execute in minecraft:overworld run fill 292 70 -10 292 71 -10 dirt
execute in minecraft:overworld run setblock 292 72 -10 grass_block
execute in minecraft:overworld run fill 292 73 -10 292 144 -10 air
execute in minecraft:overworld run fill 292 58 -9 292 69 -9 stone
execute in minecraft:overworld run fill 292 70 -9 292 71 -9 dirt
execute in minecraft:overworld run setblock 292 72 -9 coarse_dirt
execute in minecraft:overworld run fill 292 73 -9 292 144 -9 air
execute in minecraft:overworld run fill 292 58 -8 292 69 -8 stone
execute in minecraft:overworld run fill 292 70 -8 292 71 -8 dirt
execute in minecraft:overworld run setblock 292 72 -8 grass_block
execute in minecraft:overworld run fill 292 73 -8 292 144 -8 air
execute in minecraft:overworld run fill 292 58 -7 292 69 -7 stone
execute in minecraft:overworld run fill 292 70 -7 292 71 -7 dirt
execute in minecraft:overworld run setblock 292 72 -7 coarse_dirt
execute in minecraft:overworld run fill 292 73 -7 292 144 -7 air
execute in minecraft:overworld run fill 292 58 -6 292 69 -6 stone
execute in minecraft:overworld run fill 292 70 -6 292 71 -6 dirt
execute in minecraft:overworld run setblock 292 72 -6 coarse_dirt
execute in minecraft:overworld run fill 292 73 -6 292 144 -6 air
execute in minecraft:overworld run fill 292 58 -5 292 69 -5 stone
execute in minecraft:overworld run fill 292 70 -5 292 71 -5 dirt
execute in minecraft:overworld run setblock 292 72 -5 coarse_dirt
execute in minecraft:overworld run fill 292 73 -5 292 144 -5 air
execute in minecraft:overworld run fill 292 58 -4 292 69 -4 stone
execute in minecraft:overworld run fill 292 70 -4 292 71 -4 dirt
execute in minecraft:overworld run setblock 292 72 -4 coarse_dirt
execute in minecraft:overworld run fill 292 73 -4 292 144 -4 air
execute in minecraft:overworld run fill 292 58 -3 292 69 -3 stone
execute in minecraft:overworld run fill 292 70 -3 292 71 -3 dirt
execute in minecraft:overworld run setblock 292 72 -3 coarse_dirt
execute in minecraft:overworld run fill 292 73 -3 292 144 -3 air
execute in minecraft:overworld run setblock 292 73 -3 grass
execute in minecraft:overworld run fill 292 58 -2 292 69 -2 stone
execute in minecraft:overworld run fill 292 70 -2 292 71 -2 dirt
execute in minecraft:overworld run setblock 292 72 -2 coarse_dirt
execute in minecraft:overworld run fill 292 73 -2 292 144 -2 air
execute in minecraft:overworld run fill 292 58 -1 292 70 -1 stone
execute in minecraft:overworld run fill 292 71 -1 292 72 -1 dirt
execute in minecraft:overworld run setblock 292 73 -1 coarse_dirt
execute in minecraft:overworld run fill 292 74 -1 292 144 -1 air
execute in minecraft:overworld run fill 292 58 0 292 70 0 stone
execute in minecraft:overworld run fill 292 71 0 292 72 0 dirt
execute in minecraft:overworld run setblock 292 73 0 coarse_dirt
execute in minecraft:overworld run fill 292 74 0 292 144 0 air
execute in minecraft:overworld run setblock 292 74 0 grass
execute in minecraft:overworld run fill 292 58 1 292 70 1 stone
execute in minecraft:overworld run fill 292 71 1 292 72 1 dirt
execute in minecraft:overworld run setblock 292 73 1 coarse_dirt
execute in minecraft:overworld run fill 292 74 1 292 144 1 air
execute in minecraft:overworld run fill 292 58 2 292 69 2 stone
execute in minecraft:overworld run fill 292 70 2 292 71 2 dirt
execute in minecraft:overworld run setblock 292 72 2 grass_block
execute in minecraft:overworld run fill 292 73 2 292 144 2 air
execute in minecraft:overworld run fill 292 58 3 292 69 3 stone
execute in minecraft:overworld run fill 292 70 3 292 71 3 dirt
execute in minecraft:overworld run setblock 292 72 3 coarse_dirt
execute in minecraft:overworld run fill 292 73 3 292 144 3 air
execute in minecraft:overworld run fill 292 58 4 292 69 4 stone
execute in minecraft:overworld run fill 292 70 4 292 71 4 dirt
execute in minecraft:overworld run setblock 292 72 4 coarse_dirt
execute in minecraft:overworld run fill 292 73 4 292 144 4 air
execute in minecraft:overworld run fill 292 58 5 292 68 5 stone
execute in minecraft:overworld run fill 292 69 5 292 70 5 dirt
execute in minecraft:overworld run setblock 292 71 5 coarse_dirt
execute in minecraft:overworld run fill 292 72 5 292 144 5 air
execute in minecraft:overworld run fill 292 58 6 292 68 6 stone
execute in minecraft:overworld run fill 292 69 6 292 70 6 dirt
execute in minecraft:overworld run setblock 292 71 6 coarse_dirt
execute in minecraft:overworld run fill 292 72 6 292 144 6 air
execute in minecraft:overworld run setblock 292 72 6 grass
execute in minecraft:overworld run fill 292 58 7 292 67 7 stone
execute in minecraft:overworld run fill 292 68 7 292 69 7 dirt
execute in minecraft:overworld run setblock 292 70 7 grass_block
execute in minecraft:overworld run fill 292 71 7 292 144 7 air
execute in minecraft:overworld run setblock 292 71 7 mossy_cobblestone
execute in minecraft:overworld run fill 292 58 8 292 67 8 stone
execute in minecraft:overworld run fill 292 68 8 292 69 8 dirt
execute in minecraft:overworld run setblock 292 70 8 grass_block
execute in minecraft:overworld run fill 292 71 8 292 144 8 air
execute in minecraft:overworld run fill 292 58 9 292 67 9 stone
execute in minecraft:overworld run fill 292 68 9 292 69 9 dirt
execute in minecraft:overworld run setblock 292 70 9 grass_block
execute in minecraft:overworld run fill 292 71 9 292 144 9 air
execute in minecraft:overworld run fill 292 58 10 292 66 10 stone
execute in minecraft:overworld run fill 292 67 10 292 68 10 dirt
execute in minecraft:overworld run setblock 292 69 10 coarse_dirt
execute in minecraft:overworld run fill 292 70 10 292 144 10 air
execute in minecraft:overworld run setblock 292 70 10 grass
execute in minecraft:overworld run fill 292 58 11 292 66 11 stone
execute in minecraft:overworld run fill 292 67 11 292 68 11 dirt
execute in minecraft:overworld run setblock 292 69 11 coarse_dirt
execute in minecraft:overworld run fill 292 70 11 292 144 11 air
execute in minecraft:overworld run fill 292 58 12 292 66 12 stone
execute in minecraft:overworld run fill 292 67 12 292 68 12 dirt
execute in minecraft:overworld run setblock 292 69 12 coarse_dirt
execute in minecraft:overworld run fill 292 70 12 292 144 12 air
execute in minecraft:overworld run fill 292 58 13 292 66 13 stone
execute in minecraft:overworld run fill 292 67 13 292 68 13 dirt
execute in minecraft:overworld run setblock 292 69 13 grass_block
execute in minecraft:overworld run fill 292 70 13 292 144 13 air
execute in minecraft:overworld run fill 292 58 14 292 66 14 stone
execute in minecraft:overworld run fill 292 67 14 292 68 14 dirt
execute in minecraft:overworld run setblock 292 69 14 grass_block
execute in minecraft:overworld run fill 292 70 14 292 144 14 air
execute in minecraft:overworld run fill 292 58 15 292 66 15 stone
execute in minecraft:overworld run fill 292 67 15 292 68 15 dirt
execute in minecraft:overworld run setblock 292 69 15 coarse_dirt
execute in minecraft:overworld run fill 292 70 15 292 144 15 air
execute in minecraft:overworld run fill 292 58 16 292 65 16 stone
execute in minecraft:overworld run fill 292 66 16 292 67 16 dirt
execute in minecraft:overworld run setblock 292 68 16 coarse_dirt
execute in minecraft:overworld run fill 292 69 16 292 144 16 air
execute in minecraft:overworld run setblock 292 69 16 grass
execute in minecraft:overworld run fill 292 58 17 292 65 17 stone
execute in minecraft:overworld run fill 292 66 17 292 67 17 dirt
execute in minecraft:overworld run setblock 292 68 17 coarse_dirt
execute in minecraft:overworld run fill 292 69 17 292 144 17 air
execute in minecraft:overworld run fill 292 58 18 292 65 18 stone
execute in minecraft:overworld run fill 292 66 18 292 67 18 dirt
execute in minecraft:overworld run setblock 292 68 18 coarse_dirt
execute in minecraft:overworld run fill 292 69 18 292 144 18 air
execute in minecraft:overworld run setblock 292 69 18 mossy_cobblestone
execute in minecraft:overworld run fill 292 58 19 292 65 19 stone
execute in minecraft:overworld run fill 292 66 19 292 67 19 dirt
execute in minecraft:overworld run setblock 292 68 19 grass_block
execute in minecraft:overworld run fill 292 69 19 292 144 19 air
execute in minecraft:overworld run fill 292 58 20 292 65 20 stone
execute in minecraft:overworld run fill 292 66 20 292 67 20 dirt
execute in minecraft:overworld run setblock 292 68 20 coarse_dirt
execute in minecraft:overworld run fill 292 69 20 292 144 20 air
execute in minecraft:overworld run fill 292 58 21 292 65 21 stone
execute in minecraft:overworld run fill 292 66 21 292 67 21 dirt
execute in minecraft:overworld run setblock 292 68 21 coarse_dirt
execute in minecraft:overworld run fill 292 69 21 292 144 21 air
execute in minecraft:overworld run fill 292 58 22 292 65 22 stone
execute in minecraft:overworld run fill 292 66 22 292 67 22 dirt
execute in minecraft:overworld run setblock 292 68 22 coarse_dirt
execute in minecraft:overworld run fill 292 69 22 292 144 22 air
execute in minecraft:overworld run fill 292 58 23 292 65 23 stone
execute in minecraft:overworld run fill 292 66 23 292 67 23 dirt
execute in minecraft:overworld run setblock 292 68 23 coarse_dirt
execute in minecraft:overworld run fill 292 69 23 292 144 23 air
execute in minecraft:overworld run fill 292 58 24 292 65 24 stone
execute in minecraft:overworld run fill 292 66 24 292 67 24 dirt
execute in minecraft:overworld run setblock 292 68 24 grass_block
execute in minecraft:overworld run fill 292 69 24 292 144 24 air
execute in minecraft:overworld run fill 292 58 25 292 65 25 stone
execute in minecraft:overworld run fill 292 66 25 292 67 25 dirt
execute in minecraft:overworld run setblock 292 68 25 grass_block
execute in minecraft:overworld run fill 292 69 25 292 144 25 air
execute in minecraft:overworld run fill 292 58 26 292 65 26 stone
execute in minecraft:overworld run fill 292 66 26 292 67 26 dirt
execute in minecraft:overworld run setblock 292 68 26 coarse_dirt
execute in minecraft:overworld run fill 292 69 26 292 144 26 air
execute in minecraft:overworld run fill 292 58 27 292 65 27 stone
execute in minecraft:overworld run fill 292 66 27 292 67 27 dirt
execute in minecraft:overworld run setblock 292 68 27 grass_block
execute in minecraft:overworld run fill 292 69 27 292 144 27 air
execute in minecraft:overworld run fill 292 58 28 292 65 28 stone
execute in minecraft:overworld run fill 292 66 28 292 67 28 dirt
execute in minecraft:overworld run setblock 292 68 28 coarse_dirt
execute in minecraft:overworld run fill 292 69 28 292 144 28 air
execute in minecraft:overworld run fill 292 58 29 292 65 29 stone
execute in minecraft:overworld run fill 292 66 29 292 67 29 dirt
execute in minecraft:overworld run setblock 292 68 29 coarse_dirt
execute in minecraft:overworld run fill 292 69 29 292 144 29 air
execute in minecraft:overworld run fill 292 58 30 292 65 30 stone
execute in minecraft:overworld run fill 292 66 30 292 67 30 dirt
execute in minecraft:overworld run setblock 292 68 30 coarse_dirt
execute in minecraft:overworld run fill 292 69 30 292 144 30 air
execute in minecraft:overworld run fill 292 58 31 292 65 31 stone
execute in minecraft:overworld run fill 292 66 31 292 67 31 dirt
execute in minecraft:overworld run setblock 292 68 31 coarse_dirt
execute in minecraft:overworld run fill 292 69 31 292 144 31 air
execute in minecraft:overworld run fill 292 58 32 292 64 32 stone
execute in minecraft:overworld run fill 292 65 32 292 66 32 dirt
execute in minecraft:overworld run setblock 292 67 32 coarse_dirt
execute in minecraft:overworld run fill 292 68 32 292 144 32 air
execute in minecraft:overworld run fill 292 58 33 292 64 33 stone
execute in minecraft:overworld run fill 292 65 33 292 66 33 dirt
execute in minecraft:overworld run setblock 292 67 33 coarse_dirt
execute in minecraft:overworld run fill 292 68 33 292 144 33 air
execute in minecraft:overworld run fill 292 58 34 292 64 34 stone
execute in minecraft:overworld run fill 292 65 34 292 66 34 dirt
execute in minecraft:overworld run setblock 292 67 34 coarse_dirt
execute in minecraft:overworld run fill 292 68 34 292 144 34 air
execute in minecraft:overworld run fill 292 58 35 292 63 35 stone
execute in minecraft:overworld run fill 292 64 35 292 65 35 dirt
execute in minecraft:overworld run setblock 292 66 35 coarse_dirt
execute in minecraft:overworld run fill 292 67 35 292 144 35 air
execute in minecraft:overworld run fill 292 58 36 292 63 36 stone
schedule function blade_gallery:random/burned/part_134 1t replace
