execute in minecraft:overworld run setblock 257 79 -37 grass
execute in minecraft:overworld run fill 257 58 -36 257 74 -36 stone
execute in minecraft:overworld run fill 257 75 -36 257 76 -36 dirt
execute in minecraft:overworld run setblock 257 77 -36 coarse_dirt
execute in minecraft:overworld run fill 257 78 -36 257 144 -36 air
execute in minecraft:overworld run fill 257 58 -35 257 74 -35 stone
execute in minecraft:overworld run fill 257 75 -35 257 76 -35 dirt
execute in minecraft:overworld run setblock 257 77 -35 coarse_dirt
execute in minecraft:overworld run fill 257 78 -35 257 144 -35 air
execute in minecraft:overworld run fill 257 58 -34 257 73 -34 stone
execute in minecraft:overworld run fill 257 74 -34 257 75 -34 dirt
execute in minecraft:overworld run setblock 257 76 -34 coarse_dirt
execute in minecraft:overworld run fill 257 77 -34 257 144 -34 air
execute in minecraft:overworld run fill 257 58 -33 257 73 -33 stone
execute in minecraft:overworld run fill 257 74 -33 257 75 -33 dirt
execute in minecraft:overworld run setblock 257 76 -33 grass_block
execute in minecraft:overworld run fill 257 77 -33 257 144 -33 air
execute in minecraft:overworld run fill 257 58 -32 257 73 -32 stone
execute in minecraft:overworld run fill 257 74 -32 257 75 -32 dirt
execute in minecraft:overworld run setblock 257 76 -32 coarse_dirt
execute in minecraft:overworld run fill 257 77 -32 257 144 -32 air
execute in minecraft:overworld run fill 257 58 -31 257 72 -31 stone
execute in minecraft:overworld run fill 257 73 -31 257 74 -31 dirt
execute in minecraft:overworld run setblock 257 75 -31 coarse_dirt
execute in minecraft:overworld run fill 257 76 -31 257 144 -31 air
execute in minecraft:overworld run fill 257 58 -30 257 72 -30 stone
execute in minecraft:overworld run fill 257 73 -30 257 74 -30 dirt
execute in minecraft:overworld run setblock 257 75 -30 coarse_dirt
execute in minecraft:overworld run fill 257 76 -30 257 144 -30 air
execute in minecraft:overworld run fill 257 58 -29 257 71 -29 stone
execute in minecraft:overworld run fill 257 72 -29 257 73 -29 dirt
execute in minecraft:overworld run setblock 257 74 -29 grass_block
execute in minecraft:overworld run fill 257 75 -29 257 144 -29 air
execute in minecraft:overworld run fill 257 58 -28 257 70 -28 stone
execute in minecraft:overworld run fill 257 71 -28 257 72 -28 dirt
execute in minecraft:overworld run setblock 257 73 -28 coarse_dirt
execute in minecraft:overworld run fill 257 74 -28 257 144 -28 air
execute in minecraft:overworld run fill 257 58 -27 257 69 -27 stone
execute in minecraft:overworld run fill 257 70 -27 257 71 -27 dirt
execute in minecraft:overworld run setblock 257 72 -27 coarse_dirt
execute in minecraft:overworld run fill 257 73 -27 257 144 -27 air
execute in minecraft:overworld run fill 257 58 -26 257 69 -26 stone
execute in minecraft:overworld run fill 257 70 -26 257 71 -26 dirt
execute in minecraft:overworld run setblock 257 72 -26 grass_block
execute in minecraft:overworld run fill 257 73 -26 257 144 -26 air
execute in minecraft:overworld run fill 257 58 -25 257 68 -25 stone
execute in minecraft:overworld run fill 257 69 -25 257 70 -25 dirt
execute in minecraft:overworld run setblock 257 71 -25 coarse_dirt
execute in minecraft:overworld run fill 257 72 -25 257 144 -25 air
execute in minecraft:overworld run fill 257 58 -24 257 67 -24 stone
execute in minecraft:overworld run fill 257 68 -24 257 69 -24 dirt
execute in minecraft:overworld run setblock 257 70 -24 coarse_dirt
execute in minecraft:overworld run fill 257 71 -24 257 144 -24 air
execute in minecraft:overworld run fill 257 58 -23 257 66 -23 stone
execute in minecraft:overworld run fill 257 67 -23 257 68 -23 dirt
execute in minecraft:overworld run setblock 257 69 -23 coarse_dirt
execute in minecraft:overworld run fill 257 70 -23 257 144 -23 air
execute in minecraft:overworld run fill 257 58 -22 257 65 -22 stone
execute in minecraft:overworld run fill 257 66 -22 257 67 -22 dirt
execute in minecraft:overworld run setblock 257 68 -22 grass_block
execute in minecraft:overworld run fill 257 69 -22 257 144 -22 air
execute in minecraft:overworld run fill 257 58 -21 257 64 -21 stone
execute in minecraft:overworld run fill 257 65 -21 257 66 -21 dirt
execute in minecraft:overworld run setblock 257 67 -21 coarse_dirt
execute in minecraft:overworld run fill 257 68 -21 257 144 -21 air
execute in minecraft:overworld run setblock 257 68 -21 mossy_cobblestone
execute in minecraft:overworld run fill 257 58 -20 257 63 -20 stone
execute in minecraft:overworld run fill 257 64 -20 257 65 -20 dirt
execute in minecraft:overworld run setblock 257 66 -20 coarse_dirt
execute in minecraft:overworld run fill 257 67 -20 257 144 -20 air
execute in minecraft:overworld run fill 257 58 -19 257 62 -19 stone
execute in minecraft:overworld run fill 257 63 -19 257 64 -19 dirt
execute in minecraft:overworld run setblock 257 65 -19 grass_block
execute in minecraft:overworld run fill 257 66 -19 257 144 -19 air
execute in minecraft:overworld run fill 257 58 -18 257 61 -18 stone
execute in minecraft:overworld run fill 257 62 -18 257 63 -18 dirt
execute in minecraft:overworld run setblock 257 64 -18 coarse_dirt
execute in minecraft:overworld run fill 257 65 -18 257 144 -18 air
execute in minecraft:overworld run fill 257 58 -17 257 61 -17 stone
execute in minecraft:overworld run fill 257 62 -17 257 63 -17 dirt
execute in minecraft:overworld run setblock 257 64 -17 grass_block
execute in minecraft:overworld run fill 257 65 -17 257 144 -17 air
execute in minecraft:overworld run fill 257 58 -16 257 60 -16 stone
execute in minecraft:overworld run fill 257 61 -16 257 62 -16 dirt
execute in minecraft:overworld run setblock 257 63 -16 gravel
execute in minecraft:overworld run fill 257 64 -16 257 144 -16 air
execute in minecraft:overworld run fill 257 64 -16 257 64 -16 water
execute in minecraft:overworld run fill 257 58 -15 257 59 -15 stone
execute in minecraft:overworld run fill 257 60 -15 257 61 -15 dirt
execute in minecraft:overworld run setblock 257 62 -15 gravel
execute in minecraft:overworld run fill 257 63 -15 257 144 -15 air
execute in minecraft:overworld run fill 257 63 -15 257 64 -15 water
execute in minecraft:overworld run fill 257 58 -14 257 59 -14 stone
execute in minecraft:overworld run fill 257 60 -14 257 61 -14 dirt
execute in minecraft:overworld run setblock 257 62 -14 gravel
execute in minecraft:overworld run fill 257 63 -14 257 144 -14 air
execute in minecraft:overworld run fill 257 63 -14 257 64 -14 water
execute in minecraft:overworld run fill 257 58 -13 257 58 -13 stone
execute in minecraft:overworld run fill 257 59 -13 257 60 -13 dirt
execute in minecraft:overworld run setblock 257 61 -13 gravel
execute in minecraft:overworld run fill 257 62 -13 257 144 -13 air
execute in minecraft:overworld run fill 257 62 -13 257 64 -13 water
execute in minecraft:overworld run fill 257 58 -12 257 58 -12 stone
execute in minecraft:overworld run fill 257 59 -12 257 60 -12 dirt
execute in minecraft:overworld run setblock 257 61 -12 gravel
execute in minecraft:overworld run fill 257 62 -12 257 144 -12 air
execute in minecraft:overworld run fill 257 62 -12 257 64 -12 water
execute in minecraft:overworld run fill 257 58 -11 257 58 -11 stone
execute in minecraft:overworld run fill 257 59 -11 257 60 -11 dirt
execute in minecraft:overworld run setblock 257 61 -11 gravel
execute in minecraft:overworld run fill 257 62 -11 257 144 -11 air
execute in minecraft:overworld run fill 257 62 -11 257 64 -11 water
execute in minecraft:overworld run fill 257 58 -10 257 58 -10 stone
execute in minecraft:overworld run fill 257 59 -10 257 60 -10 dirt
execute in minecraft:overworld run setblock 257 61 -10 gravel
execute in minecraft:overworld run fill 257 62 -10 257 144 -10 air
execute in minecraft:overworld run fill 257 62 -10 257 64 -10 water
execute in minecraft:overworld run fill 257 58 -9 257 58 -9 stone
execute in minecraft:overworld run fill 257 59 -9 257 60 -9 dirt
execute in minecraft:overworld run setblock 257 61 -9 gravel
execute in minecraft:overworld run fill 257 62 -9 257 144 -9 air
execute in minecraft:overworld run fill 257 62 -9 257 64 -9 water
execute in minecraft:overworld run fill 257 58 -8 257 58 -8 stone
execute in minecraft:overworld run fill 257 59 -8 257 60 -8 dirt
execute in minecraft:overworld run setblock 257 61 -8 gravel
execute in minecraft:overworld run fill 257 62 -8 257 144 -8 air
execute in minecraft:overworld run fill 257 62 -8 257 64 -8 water
execute in minecraft:overworld run fill 257 58 -7 257 58 -7 stone
execute in minecraft:overworld run fill 257 59 -7 257 60 -7 dirt
execute in minecraft:overworld run setblock 257 61 -7 gravel
execute in minecraft:overworld run fill 257 62 -7 257 144 -7 air
execute in minecraft:overworld run fill 257 62 -7 257 64 -7 water
execute in minecraft:overworld run fill 257 58 -6 257 58 -6 stone
execute in minecraft:overworld run fill 257 59 -6 257 60 -6 dirt
execute in minecraft:overworld run setblock 257 61 -6 gravel
execute in minecraft:overworld run fill 257 62 -6 257 144 -6 air
execute in minecraft:overworld run fill 257 62 -6 257 64 -6 water
execute in minecraft:overworld run fill 257 58 -5 257 58 -5 stone
execute in minecraft:overworld run fill 257 59 -5 257 60 -5 dirt
execute in minecraft:overworld run setblock 257 61 -5 gravel
execute in minecraft:overworld run fill 257 62 -5 257 144 -5 air
execute in minecraft:overworld run fill 257 62 -5 257 64 -5 water
execute in minecraft:overworld run fill 257 58 -4 257 58 -4 stone
execute in minecraft:overworld run fill 257 59 -4 257 60 -4 dirt
execute in minecraft:overworld run setblock 257 61 -4 gravel
execute in minecraft:overworld run fill 257 62 -4 257 144 -4 air
execute in minecraft:overworld run fill 257 62 -4 257 64 -4 water
execute in minecraft:overworld run fill 257 58 -3 257 57 -3 stone
execute in minecraft:overworld run fill 257 58 -3 257 59 -3 dirt
execute in minecraft:overworld run setblock 257 60 -3 gravel
execute in minecraft:overworld run fill 257 61 -3 257 144 -3 air
execute in minecraft:overworld run fill 257 61 -3 257 64 -3 water
execute in minecraft:overworld run fill 257 58 -2 257 57 -2 stone
execute in minecraft:overworld run fill 257 58 -2 257 59 -2 dirt
execute in minecraft:overworld run setblock 257 60 -2 gravel
execute in minecraft:overworld run fill 257 61 -2 257 144 -2 air
execute in minecraft:overworld run fill 257 61 -2 257 64 -2 water
execute in minecraft:overworld run fill 257 58 -1 257 58 -1 stone
execute in minecraft:overworld run fill 257 59 -1 257 60 -1 dirt
execute in minecraft:overworld run setblock 257 61 -1 gravel
execute in minecraft:overworld run fill 257 62 -1 257 144 -1 air
execute in minecraft:overworld run fill 257 62 -1 257 64 -1 water
execute in minecraft:overworld run fill 257 58 0 257 58 0 stone
execute in minecraft:overworld run fill 257 59 0 257 60 0 dirt
execute in minecraft:overworld run setblock 257 61 0 gravel
execute in minecraft:overworld run fill 257 62 0 257 144 0 air
execute in minecraft:overworld run fill 257 62 0 257 64 0 water
execute in minecraft:overworld run fill 257 58 1 257 58 1 stone
execute in minecraft:overworld run fill 257 59 1 257 60 1 dirt
execute in minecraft:overworld run setblock 257 61 1 gravel
execute in minecraft:overworld run fill 257 62 1 257 144 1 air
execute in minecraft:overworld run fill 257 62 1 257 64 1 water
execute in minecraft:overworld run fill 257 58 2 257 58 2 stone
execute in minecraft:overworld run fill 257 59 2 257 60 2 dirt
execute in minecraft:overworld run setblock 257 61 2 gravel
execute in minecraft:overworld run fill 257 62 2 257 144 2 air
execute in minecraft:overworld run fill 257 62 2 257 64 2 water
execute in minecraft:overworld run fill 257 58 3 257 58 3 stone
execute in minecraft:overworld run fill 257 59 3 257 60 3 dirt
execute in minecraft:overworld run setblock 257 61 3 gravel
execute in minecraft:overworld run fill 257 62 3 257 144 3 air
execute in minecraft:overworld run fill 257 62 3 257 64 3 water
execute in minecraft:overworld run fill 257 58 4 257 59 4 stone
execute in minecraft:overworld run fill 257 60 4 257 61 4 dirt
execute in minecraft:overworld run setblock 257 62 4 gravel
execute in minecraft:overworld run fill 257 63 4 257 144 4 air
execute in minecraft:overworld run fill 257 63 4 257 64 4 water
execute in minecraft:overworld run fill 257 58 5 257 59 5 stone
execute in minecraft:overworld run fill 257 60 5 257 61 5 dirt
execute in minecraft:overworld run setblock 257 62 5 gravel
execute in minecraft:overworld run fill 257 63 5 257 144 5 air
execute in minecraft:overworld run fill 257 63 5 257 64 5 water
execute in minecraft:overworld run fill 257 58 6 257 59 6 stone
execute in minecraft:overworld run fill 257 60 6 257 61 6 dirt
execute in minecraft:overworld run setblock 257 62 6 gravel
execute in minecraft:overworld run fill 257 63 6 257 144 6 air
execute in minecraft:overworld run fill 257 63 6 257 64 6 water
execute in minecraft:overworld run fill 257 58 7 257 60 7 stone
execute in minecraft:overworld run fill 257 61 7 257 62 7 dirt
execute in minecraft:overworld run setblock 257 63 7 gravel
execute in minecraft:overworld run fill 257 64 7 257 144 7 air
execute in minecraft:overworld run fill 257 64 7 257 64 7 water
execute in minecraft:overworld run fill 257 58 8 257 60 8 stone
execute in minecraft:overworld run fill 257 61 8 257 62 8 dirt
execute in minecraft:overworld run setblock 257 63 8 gravel
execute in minecraft:overworld run fill 257 64 8 257 144 8 air
execute in minecraft:overworld run fill 257 64 8 257 64 8 water
execute in minecraft:overworld run fill 257 58 9 257 60 9 stone
execute in minecraft:overworld run fill 257 61 9 257 62 9 dirt
execute in minecraft:overworld run setblock 257 63 9 gravel
execute in minecraft:overworld run fill 257 64 9 257 144 9 air
execute in minecraft:overworld run fill 257 64 9 257 64 9 water
execute in minecraft:overworld run fill 257 58 10 257 60 10 stone
execute in minecraft:overworld run fill 257 61 10 257 62 10 dirt
execute in minecraft:overworld run setblock 257 63 10 gravel
execute in minecraft:overworld run fill 257 64 10 257 144 10 air
execute in minecraft:overworld run fill 257 64 10 257 64 10 water
execute in minecraft:overworld run fill 257 58 11 257 61 11 stone
execute in minecraft:overworld run fill 257 62 11 257 63 11 dirt
execute in minecraft:overworld run setblock 257 64 11 coarse_dirt
execute in minecraft:overworld run fill 257 65 11 257 144 11 air
execute in minecraft:overworld run fill 257 58 12 257 61 12 stone
execute in minecraft:overworld run fill 257 62 12 257 63 12 dirt
execute in minecraft:overworld run setblock 257 64 12 grass_block
execute in minecraft:overworld run fill 257 65 12 257 144 12 air
execute in minecraft:overworld run fill 257 58 13 257 62 13 stone
execute in minecraft:overworld run fill 257 63 13 257 64 13 dirt
execute in minecraft:overworld run setblock 257 65 13 coarse_dirt
execute in minecraft:overworld run fill 257 66 13 257 144 13 air
execute in minecraft:overworld run fill 257 58 14 257 62 14 stone
execute in minecraft:overworld run fill 257 63 14 257 64 14 dirt
execute in minecraft:overworld run setblock 257 65 14 coarse_dirt
execute in minecraft:overworld run fill 257 66 14 257 144 14 air
execute in minecraft:overworld run fill 257 58 15 257 62 15 stone
execute in minecraft:overworld run fill 257 63 15 257 64 15 dirt
execute in minecraft:overworld run setblock 257 65 15 grass_block
execute in minecraft:overworld run fill 257 66 15 257 144 15 air
execute in minecraft:overworld run setblock 257 66 15 grass
execute in minecraft:overworld run fill 257 58 16 257 63 16 stone
execute in minecraft:overworld run fill 257 64 16 257 65 16 dirt
execute in minecraft:overworld run setblock 257 66 16 grass_block
execute in minecraft:overworld run fill 257 67 16 257 144 16 air
execute in minecraft:overworld run fill 257 58 17 257 63 17 stone
execute in minecraft:overworld run fill 257 64 17 257 65 17 dirt
execute in minecraft:overworld run setblock 257 66 17 coarse_dirt
execute in minecraft:overworld run fill 257 67 17 257 144 17 air
execute in minecraft:overworld run fill 257 58 18 257 63 18 stone
execute in minecraft:overworld run fill 257 64 18 257 65 18 dirt
execute in minecraft:overworld run setblock 257 66 18 coarse_dirt
execute in minecraft:overworld run fill 257 67 18 257 144 18 air
execute in minecraft:overworld run fill 257 58 19 257 63 19 stone
execute in minecraft:overworld run fill 257 64 19 257 65 19 dirt
execute in minecraft:overworld run setblock 257 66 19 coarse_dirt
execute in minecraft:overworld run fill 257 67 19 257 144 19 air
execute in minecraft:overworld run setblock 257 67 19 grass
execute in minecraft:overworld run fill 257 58 20 257 63 20 stone
schedule function blade_gallery:random/burned/part_77 1t replace
