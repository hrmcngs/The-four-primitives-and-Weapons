execute in minecraft:overworld run setblock 211 64 47 coarse_dirt
execute in minecraft:overworld run fill 211 65 47 211 144 47 air
execute in minecraft:overworld run fill 212 58 -48 212 61 -48 stone
execute in minecraft:overworld run fill 212 62 -48 212 63 -48 dirt
execute in minecraft:overworld run setblock 212 64 -48 grass_block
execute in minecraft:overworld run fill 212 65 -48 212 144 -48 air
execute in minecraft:overworld run fill 212 58 -47 212 63 -47 stone
execute in minecraft:overworld run fill 212 64 -47 212 65 -47 dirt
execute in minecraft:overworld run setblock 212 66 -47 coarse_dirt
execute in minecraft:overworld run fill 212 67 -47 212 144 -47 air
execute in minecraft:overworld run fill 212 58 -46 212 64 -46 stone
execute in minecraft:overworld run fill 212 65 -46 212 66 -46 dirt
execute in minecraft:overworld run setblock 212 67 -46 coarse_dirt
execute in minecraft:overworld run fill 212 68 -46 212 144 -46 air
execute in minecraft:overworld run fill 212 58 -45 212 66 -45 stone
execute in minecraft:overworld run fill 212 67 -45 212 68 -45 dirt
execute in minecraft:overworld run setblock 212 69 -45 coarse_dirt
execute in minecraft:overworld run fill 212 70 -45 212 144 -45 air
execute in minecraft:overworld run fill 212 58 -44 212 67 -44 stone
execute in minecraft:overworld run fill 212 68 -44 212 69 -44 dirt
execute in minecraft:overworld run setblock 212 70 -44 grass_block
execute in minecraft:overworld run fill 212 71 -44 212 144 -44 air
execute in minecraft:overworld run fill 212 58 -43 212 67 -43 stone
execute in minecraft:overworld run fill 212 68 -43 212 69 -43 dirt
execute in minecraft:overworld run setblock 212 70 -43 grass_block
execute in minecraft:overworld run fill 212 71 -43 212 144 -43 air
execute in minecraft:overworld run fill 212 58 -42 212 67 -42 stone
execute in minecraft:overworld run fill 212 68 -42 212 69 -42 dirt
execute in minecraft:overworld run setblock 212 70 -42 coarse_dirt
execute in minecraft:overworld run fill 212 71 -42 212 144 -42 air
execute in minecraft:overworld run fill 212 58 -41 212 66 -41 stone
execute in minecraft:overworld run fill 212 67 -41 212 68 -41 dirt
execute in minecraft:overworld run setblock 212 69 -41 grass_block
execute in minecraft:overworld run fill 212 70 -41 212 144 -41 air
execute in minecraft:overworld run fill 212 58 -40 212 66 -40 stone
execute in minecraft:overworld run fill 212 67 -40 212 68 -40 dirt
execute in minecraft:overworld run setblock 212 69 -40 grass_block
execute in minecraft:overworld run fill 212 70 -40 212 144 -40 air
execute in minecraft:overworld run fill 212 58 -39 212 66 -39 stone
execute in minecraft:overworld run fill 212 67 -39 212 68 -39 dirt
execute in minecraft:overworld run setblock 212 69 -39 coarse_dirt
execute in minecraft:overworld run fill 212 70 -39 212 144 -39 air
execute in minecraft:overworld run fill 212 58 -38 212 66 -38 stone
execute in minecraft:overworld run fill 212 67 -38 212 68 -38 dirt
execute in minecraft:overworld run setblock 212 69 -38 grass_block
execute in minecraft:overworld run fill 212 70 -38 212 144 -38 air
execute in minecraft:overworld run fill 212 58 -37 212 65 -37 stone
execute in minecraft:overworld run fill 212 66 -37 212 67 -37 dirt
execute in minecraft:overworld run setblock 212 68 -37 coarse_dirt
execute in minecraft:overworld run fill 212 69 -37 212 144 -37 air
execute in minecraft:overworld run fill 212 58 -36 212 65 -36 stone
execute in minecraft:overworld run fill 212 66 -36 212 67 -36 dirt
execute in minecraft:overworld run setblock 212 68 -36 coarse_dirt
execute in minecraft:overworld run fill 212 69 -36 212 144 -36 air
execute in minecraft:overworld run fill 212 58 -35 212 65 -35 stone
execute in minecraft:overworld run fill 212 66 -35 212 67 -35 dirt
execute in minecraft:overworld run setblock 212 68 -35 grass_block
execute in minecraft:overworld run fill 212 69 -35 212 144 -35 air
execute in minecraft:overworld run fill 212 58 -34 212 65 -34 stone
execute in minecraft:overworld run fill 212 66 -34 212 67 -34 dirt
execute in minecraft:overworld run setblock 212 68 -34 coarse_dirt
execute in minecraft:overworld run fill 212 69 -34 212 144 -34 air
execute in minecraft:overworld run fill 212 58 -33 212 64 -33 stone
execute in minecraft:overworld run fill 212 65 -33 212 66 -33 dirt
execute in minecraft:overworld run setblock 212 67 -33 grass_block
execute in minecraft:overworld run fill 212 68 -33 212 144 -33 air
execute in minecraft:overworld run fill 212 58 -32 212 64 -32 stone
execute in minecraft:overworld run fill 212 65 -32 212 66 -32 dirt
execute in minecraft:overworld run setblock 212 67 -32 coarse_dirt
execute in minecraft:overworld run fill 212 68 -32 212 144 -32 air
execute in minecraft:overworld run fill 212 58 -31 212 64 -31 stone
execute in minecraft:overworld run fill 212 65 -31 212 66 -31 dirt
execute in minecraft:overworld run setblock 212 67 -31 coarse_dirt
execute in minecraft:overworld run fill 212 68 -31 212 144 -31 air
execute in minecraft:overworld run fill 212 58 -30 212 64 -30 stone
execute in minecraft:overworld run fill 212 65 -30 212 66 -30 dirt
execute in minecraft:overworld run setblock 212 67 -30 coarse_dirt
execute in minecraft:overworld run fill 212 68 -30 212 144 -30 air
execute in minecraft:overworld run fill 212 58 -29 212 64 -29 stone
execute in minecraft:overworld run fill 212 65 -29 212 66 -29 dirt
execute in minecraft:overworld run setblock 212 67 -29 coarse_dirt
execute in minecraft:overworld run fill 212 68 -29 212 144 -29 air
execute in minecraft:overworld run fill 212 58 -28 212 63 -28 stone
execute in minecraft:overworld run fill 212 64 -28 212 65 -28 dirt
execute in minecraft:overworld run setblock 212 66 -28 coarse_dirt
execute in minecraft:overworld run fill 212 67 -28 212 144 -28 air
execute in minecraft:overworld run fill 212 58 -27 212 63 -27 stone
execute in minecraft:overworld run fill 212 64 -27 212 65 -27 dirt
execute in minecraft:overworld run setblock 212 66 -27 coarse_dirt
execute in minecraft:overworld run fill 212 67 -27 212 144 -27 air
execute in minecraft:overworld run fill 212 58 -26 212 63 -26 stone
execute in minecraft:overworld run fill 212 64 -26 212 65 -26 dirt
execute in minecraft:overworld run setblock 212 66 -26 coarse_dirt
execute in minecraft:overworld run fill 212 67 -26 212 144 -26 air
execute in minecraft:overworld run fill 212 58 -25 212 63 -25 stone
execute in minecraft:overworld run fill 212 64 -25 212 65 -25 dirt
execute in minecraft:overworld run setblock 212 66 -25 coarse_dirt
execute in minecraft:overworld run fill 212 67 -25 212 144 -25 air
execute in minecraft:overworld run fill 212 58 -24 212 63 -24 stone
execute in minecraft:overworld run fill 212 64 -24 212 65 -24 dirt
execute in minecraft:overworld run setblock 212 66 -24 grass_block
execute in minecraft:overworld run fill 212 67 -24 212 144 -24 air
execute in minecraft:overworld run fill 212 58 -23 212 63 -23 stone
execute in minecraft:overworld run fill 212 64 -23 212 65 -23 dirt
execute in minecraft:overworld run setblock 212 66 -23 coarse_dirt
execute in minecraft:overworld run fill 212 67 -23 212 144 -23 air
execute in minecraft:overworld run fill 212 58 -22 212 63 -22 stone
execute in minecraft:overworld run fill 212 64 -22 212 65 -22 dirt
execute in minecraft:overworld run setblock 212 66 -22 grass_block
execute in minecraft:overworld run fill 212 67 -22 212 144 -22 air
execute in minecraft:overworld run fill 212 58 -21 212 63 -21 stone
execute in minecraft:overworld run fill 212 64 -21 212 65 -21 dirt
execute in minecraft:overworld run setblock 212 66 -21 coarse_dirt
execute in minecraft:overworld run fill 212 67 -21 212 144 -21 air
execute in minecraft:overworld run fill 212 58 -20 212 63 -20 stone
execute in minecraft:overworld run fill 212 64 -20 212 65 -20 dirt
execute in minecraft:overworld run setblock 212 66 -20 grass_block
execute in minecraft:overworld run fill 212 67 -20 212 144 -20 air
execute in minecraft:overworld run fill 212 58 -19 212 63 -19 stone
execute in minecraft:overworld run fill 212 64 -19 212 65 -19 dirt
execute in minecraft:overworld run setblock 212 66 -19 coarse_dirt
execute in minecraft:overworld run fill 212 67 -19 212 144 -19 air
execute in minecraft:overworld run fill 212 58 -18 212 63 -18 stone
execute in minecraft:overworld run fill 212 64 -18 212 65 -18 dirt
execute in minecraft:overworld run setblock 212 66 -18 coarse_dirt
execute in minecraft:overworld run fill 212 67 -18 212 144 -18 air
execute in minecraft:overworld run fill 212 58 -17 212 63 -17 stone
execute in minecraft:overworld run fill 212 64 -17 212 65 -17 dirt
execute in minecraft:overworld run setblock 212 66 -17 coarse_dirt
execute in minecraft:overworld run fill 212 67 -17 212 144 -17 air
execute in minecraft:overworld run fill 212 58 -16 212 63 -16 stone
execute in minecraft:overworld run fill 212 64 -16 212 65 -16 dirt
execute in minecraft:overworld run setblock 212 66 -16 grass_block
execute in minecraft:overworld run fill 212 67 -16 212 144 -16 air
execute in minecraft:overworld run fill 212 58 -15 212 63 -15 stone
execute in minecraft:overworld run fill 212 64 -15 212 65 -15 dirt
execute in minecraft:overworld run setblock 212 66 -15 grass_block
execute in minecraft:overworld run fill 212 67 -15 212 144 -15 air
execute in minecraft:overworld run fill 212 58 -14 212 63 -14 stone
execute in minecraft:overworld run fill 212 64 -14 212 65 -14 dirt
execute in minecraft:overworld run setblock 212 66 -14 grass_block
execute in minecraft:overworld run fill 212 67 -14 212 144 -14 air
execute in minecraft:overworld run fill 212 58 -13 212 63 -13 stone
execute in minecraft:overworld run fill 212 64 -13 212 65 -13 dirt
execute in minecraft:overworld run setblock 212 66 -13 coarse_dirt
execute in minecraft:overworld run fill 212 67 -13 212 144 -13 air
execute in minecraft:overworld run fill 212 58 -12 212 63 -12 stone
execute in minecraft:overworld run fill 212 64 -12 212 65 -12 dirt
execute in minecraft:overworld run setblock 212 66 -12 grass_block
execute in minecraft:overworld run fill 212 67 -12 212 144 -12 air
execute in minecraft:overworld run fill 212 58 -11 212 63 -11 stone
execute in minecraft:overworld run fill 212 64 -11 212 65 -11 dirt
execute in minecraft:overworld run setblock 212 66 -11 coarse_dirt
execute in minecraft:overworld run fill 212 67 -11 212 144 -11 air
execute in minecraft:overworld run fill 212 58 -10 212 63 -10 stone
execute in minecraft:overworld run fill 212 64 -10 212 65 -10 dirt
execute in minecraft:overworld run setblock 212 66 -10 coarse_dirt
execute in minecraft:overworld run fill 212 67 -10 212 144 -10 air
execute in minecraft:overworld run fill 212 58 -9 212 63 -9 stone
execute in minecraft:overworld run fill 212 64 -9 212 65 -9 dirt
execute in minecraft:overworld run setblock 212 66 -9 grass_block
execute in minecraft:overworld run fill 212 67 -9 212 144 -9 air
execute in minecraft:overworld run fill 212 58 -8 212 63 -8 stone
execute in minecraft:overworld run fill 212 64 -8 212 65 -8 dirt
execute in minecraft:overworld run setblock 212 66 -8 grass_block
execute in minecraft:overworld run fill 212 67 -8 212 144 -8 air
execute in minecraft:overworld run fill 212 58 -7 212 64 -7 stone
execute in minecraft:overworld run fill 212 65 -7 212 66 -7 dirt
execute in minecraft:overworld run setblock 212 67 -7 coarse_dirt
execute in minecraft:overworld run fill 212 68 -7 212 144 -7 air
execute in minecraft:overworld run fill 212 58 -6 212 64 -6 stone
execute in minecraft:overworld run fill 212 65 -6 212 66 -6 dirt
execute in minecraft:overworld run setblock 212 67 -6 grass_block
execute in minecraft:overworld run fill 212 68 -6 212 144 -6 air
execute in minecraft:overworld run fill 212 58 -5 212 64 -5 stone
execute in minecraft:overworld run fill 212 65 -5 212 66 -5 dirt
execute in minecraft:overworld run setblock 212 67 -5 coarse_dirt
execute in minecraft:overworld run fill 212 68 -5 212 144 -5 air
execute in minecraft:overworld run fill 212 58 -4 212 64 -4 stone
execute in minecraft:overworld run fill 212 65 -4 212 66 -4 dirt
execute in minecraft:overworld run setblock 212 67 -4 grass_block
execute in minecraft:overworld run fill 212 68 -4 212 144 -4 air
execute in minecraft:overworld run fill 212 58 -3 212 64 -3 stone
execute in minecraft:overworld run fill 212 65 -3 212 66 -3 dirt
execute in minecraft:overworld run setblock 212 67 -3 coarse_dirt
execute in minecraft:overworld run fill 212 68 -3 212 144 -3 air
execute in minecraft:overworld run fill 212 58 -2 212 64 -2 stone
execute in minecraft:overworld run fill 212 65 -2 212 66 -2 dirt
execute in minecraft:overworld run setblock 212 67 -2 coarse_dirt
execute in minecraft:overworld run fill 212 68 -2 212 144 -2 air
execute in minecraft:overworld run fill 212 58 -1 212 64 -1 stone
execute in minecraft:overworld run fill 212 65 -1 212 66 -1 dirt
execute in minecraft:overworld run setblock 212 67 -1 coarse_dirt
execute in minecraft:overworld run fill 212 68 -1 212 144 -1 air
execute in minecraft:overworld run fill 212 58 0 212 64 0 stone
execute in minecraft:overworld run fill 212 65 0 212 66 0 dirt
execute in minecraft:overworld run setblock 212 67 0 coarse_dirt
execute in minecraft:overworld run fill 212 68 0 212 144 0 air
execute in minecraft:overworld run fill 212 58 1 212 64 1 stone
execute in minecraft:overworld run fill 212 65 1 212 66 1 dirt
execute in minecraft:overworld run setblock 212 67 1 coarse_dirt
execute in minecraft:overworld run fill 212 68 1 212 144 1 air
execute in minecraft:overworld run fill 212 58 2 212 64 2 stone
execute in minecraft:overworld run fill 212 65 2 212 66 2 dirt
execute in minecraft:overworld run setblock 212 67 2 coarse_dirt
execute in minecraft:overworld run fill 212 68 2 212 144 2 air
execute in minecraft:overworld run fill 212 58 3 212 64 3 stone
execute in minecraft:overworld run fill 212 65 3 212 66 3 dirt
execute in minecraft:overworld run setblock 212 67 3 grass_block
execute in minecraft:overworld run fill 212 68 3 212 144 3 air
execute in minecraft:overworld run fill 212 58 4 212 64 4 stone
execute in minecraft:overworld run fill 212 65 4 212 66 4 dirt
execute in minecraft:overworld run setblock 212 67 4 grass_block
execute in minecraft:overworld run fill 212 68 4 212 144 4 air
execute in minecraft:overworld run fill 212 58 5 212 64 5 stone
execute in minecraft:overworld run fill 212 65 5 212 66 5 dirt
execute in minecraft:overworld run setblock 212 67 5 grass_block
execute in minecraft:overworld run fill 212 68 5 212 144 5 air
execute in minecraft:overworld run fill 212 58 6 212 64 6 stone
execute in minecraft:overworld run fill 212 65 6 212 66 6 dirt
execute in minecraft:overworld run setblock 212 67 6 grass_block
execute in minecraft:overworld run fill 212 68 6 212 144 6 air
execute in minecraft:overworld run fill 212 58 7 212 64 7 stone
execute in minecraft:overworld run fill 212 65 7 212 66 7 dirt
execute in minecraft:overworld run setblock 212 67 7 coarse_dirt
execute in minecraft:overworld run fill 212 68 7 212 144 7 air
execute in minecraft:overworld run fill 212 58 8 212 64 8 stone
execute in minecraft:overworld run fill 212 65 8 212 66 8 dirt
execute in minecraft:overworld run setblock 212 67 8 coarse_dirt
execute in minecraft:overworld run fill 212 68 8 212 144 8 air
execute in minecraft:overworld run fill 212 58 9 212 64 9 stone
execute in minecraft:overworld run fill 212 65 9 212 66 9 dirt
execute in minecraft:overworld run setblock 212 67 9 coarse_dirt
execute in minecraft:overworld run fill 212 68 9 212 144 9 air
execute in minecraft:overworld run fill 212 58 10 212 64 10 stone
execute in minecraft:overworld run fill 212 65 10 212 66 10 dirt
execute in minecraft:overworld run setblock 212 67 10 coarse_dirt
execute in minecraft:overworld run fill 212 68 10 212 144 10 air
execute in minecraft:overworld run fill 212 58 11 212 64 11 stone
execute in minecraft:overworld run fill 212 65 11 212 66 11 dirt
execute in minecraft:overworld run setblock 212 67 11 coarse_dirt
execute in minecraft:overworld run fill 212 68 11 212 144 11 air
execute in minecraft:overworld run fill 212 58 12 212 64 12 stone
execute in minecraft:overworld run fill 212 65 12 212 66 12 dirt
execute in minecraft:overworld run setblock 212 67 12 coarse_dirt
execute in minecraft:overworld run fill 212 68 12 212 144 12 air
execute in minecraft:overworld run fill 212 58 13 212 64 13 stone
execute in minecraft:overworld run fill 212 65 13 212 66 13 dirt
execute in minecraft:overworld run setblock 212 67 13 coarse_dirt
execute in minecraft:overworld run fill 212 68 13 212 144 13 air
execute in minecraft:overworld run fill 212 58 14 212 64 14 stone
execute in minecraft:overworld run fill 212 65 14 212 66 14 dirt
execute in minecraft:overworld run setblock 212 67 14 coarse_dirt
execute in minecraft:overworld run fill 212 68 14 212 144 14 air
execute in minecraft:overworld run fill 212 58 15 212 64 15 stone
execute in minecraft:overworld run fill 212 65 15 212 66 15 dirt
schedule function blade_gallery:random/burned/part_7 1t replace
