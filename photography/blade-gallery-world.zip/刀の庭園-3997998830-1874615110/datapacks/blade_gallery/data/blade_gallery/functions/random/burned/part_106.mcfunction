execute in minecraft:overworld run fill 274 64 20 274 64 20 water
execute in minecraft:overworld run fill 274 58 21 274 60 21 stone
execute in minecraft:overworld run fill 274 61 21 274 62 21 dirt
execute in minecraft:overworld run setblock 274 63 21 gravel
execute in minecraft:overworld run fill 274 64 21 274 144 21 air
execute in minecraft:overworld run fill 274 64 21 274 64 21 water
execute in minecraft:overworld run fill 274 58 22 274 60 22 stone
execute in minecraft:overworld run fill 274 61 22 274 62 22 dirt
execute in minecraft:overworld run setblock 274 63 22 gravel
execute in minecraft:overworld run fill 274 64 22 274 144 22 air
execute in minecraft:overworld run fill 274 64 22 274 64 22 water
execute in minecraft:overworld run fill 274 58 23 274 60 23 stone
execute in minecraft:overworld run fill 274 61 23 274 62 23 dirt
execute in minecraft:overworld run setblock 274 63 23 gravel
execute in minecraft:overworld run fill 274 64 23 274 144 23 air
execute in minecraft:overworld run fill 274 64 23 274 64 23 water
execute in minecraft:overworld run fill 274 58 24 274 60 24 stone
execute in minecraft:overworld run fill 274 61 24 274 62 24 dirt
execute in minecraft:overworld run setblock 274 63 24 gravel
execute in minecraft:overworld run fill 274 64 24 274 144 24 air
execute in minecraft:overworld run fill 274 64 24 274 64 24 water
execute in minecraft:overworld run fill 274 58 25 274 60 25 stone
execute in minecraft:overworld run fill 274 61 25 274 62 25 dirt
execute in minecraft:overworld run setblock 274 63 25 gravel
execute in minecraft:overworld run fill 274 64 25 274 144 25 air
execute in minecraft:overworld run fill 274 64 25 274 64 25 water
execute in minecraft:overworld run fill 274 58 26 274 60 26 stone
execute in minecraft:overworld run fill 274 61 26 274 62 26 dirt
execute in minecraft:overworld run setblock 274 63 26 gravel
execute in minecraft:overworld run fill 274 64 26 274 144 26 air
execute in minecraft:overworld run fill 274 64 26 274 64 26 water
execute in minecraft:overworld run fill 274 58 27 274 61 27 stone
execute in minecraft:overworld run fill 274 62 27 274 63 27 dirt
execute in minecraft:overworld run setblock 274 64 27 coarse_dirt
execute in minecraft:overworld run fill 274 65 27 274 144 27 air
execute in minecraft:overworld run fill 274 58 28 274 61 28 stone
execute in minecraft:overworld run fill 274 62 28 274 63 28 dirt
execute in minecraft:overworld run setblock 274 64 28 grass_block
execute in minecraft:overworld run fill 274 65 28 274 144 28 air
execute in minecraft:overworld run fill 274 58 29 274 61 29 stone
execute in minecraft:overworld run fill 274 62 29 274 63 29 dirt
execute in minecraft:overworld run setblock 274 64 29 coarse_dirt
execute in minecraft:overworld run fill 274 65 29 274 144 29 air
execute in minecraft:overworld run fill 274 58 30 274 61 30 stone
execute in minecraft:overworld run fill 274 62 30 274 63 30 dirt
execute in minecraft:overworld run setblock 274 64 30 coarse_dirt
execute in minecraft:overworld run fill 274 65 30 274 144 30 air
execute in minecraft:overworld run fill 274 58 31 274 61 31 stone
execute in minecraft:overworld run fill 274 62 31 274 63 31 dirt
execute in minecraft:overworld run setblock 274 64 31 coarse_dirt
execute in minecraft:overworld run fill 274 65 31 274 144 31 air
execute in minecraft:overworld run fill 274 58 32 274 61 32 stone
execute in minecraft:overworld run fill 274 62 32 274 63 32 dirt
execute in minecraft:overworld run setblock 274 64 32 coarse_dirt
execute in minecraft:overworld run fill 274 65 32 274 144 32 air
execute in minecraft:overworld run fill 274 58 33 274 61 33 stone
execute in minecraft:overworld run fill 274 62 33 274 63 33 dirt
execute in minecraft:overworld run setblock 274 64 33 coarse_dirt
execute in minecraft:overworld run fill 274 65 33 274 144 33 air
execute in minecraft:overworld run fill 274 58 34 274 61 34 stone
execute in minecraft:overworld run fill 274 62 34 274 63 34 dirt
execute in minecraft:overworld run setblock 274 64 34 grass_block
execute in minecraft:overworld run fill 274 65 34 274 144 34 air
execute in minecraft:overworld run fill 274 58 35 274 61 35 stone
execute in minecraft:overworld run fill 274 62 35 274 63 35 dirt
execute in minecraft:overworld run setblock 274 64 35 coarse_dirt
execute in minecraft:overworld run fill 274 65 35 274 144 35 air
execute in minecraft:overworld run fill 274 58 36 274 62 36 stone
execute in minecraft:overworld run fill 274 63 36 274 64 36 dirt
execute in minecraft:overworld run setblock 274 65 36 grass_block
execute in minecraft:overworld run fill 274 66 36 274 144 36 air
execute in minecraft:overworld run fill 274 58 37 274 62 37 stone
execute in minecraft:overworld run fill 274 63 37 274 64 37 dirt
execute in minecraft:overworld run setblock 274 65 37 coarse_dirt
execute in minecraft:overworld run fill 274 66 37 274 144 37 air
execute in minecraft:overworld run fill 274 58 38 274 62 38 stone
execute in minecraft:overworld run fill 274 63 38 274 64 38 dirt
execute in minecraft:overworld run setblock 274 65 38 grass_block
execute in minecraft:overworld run fill 274 66 38 274 144 38 air
execute in minecraft:overworld run fill 274 58 39 274 62 39 stone
execute in minecraft:overworld run fill 274 63 39 274 64 39 dirt
execute in minecraft:overworld run setblock 274 65 39 grass_block
execute in minecraft:overworld run fill 274 66 39 274 144 39 air
execute in minecraft:overworld run setblock 274 66 39 grass
execute in minecraft:overworld run fill 274 58 40 274 62 40 stone
execute in minecraft:overworld run fill 274 63 40 274 64 40 dirt
execute in minecraft:overworld run setblock 274 65 40 coarse_dirt
execute in minecraft:overworld run fill 274 66 40 274 144 40 air
execute in minecraft:overworld run setblock 274 66 40 grass
execute in minecraft:overworld run fill 274 58 41 274 62 41 stone
execute in minecraft:overworld run fill 274 63 41 274 64 41 dirt
execute in minecraft:overworld run setblock 274 65 41 coarse_dirt
execute in minecraft:overworld run fill 274 66 41 274 144 41 air
execute in minecraft:overworld run setblock 274 66 41 mossy_cobblestone
execute in minecraft:overworld run fill 274 58 42 274 61 42 stone
execute in minecraft:overworld run fill 274 62 42 274 63 42 dirt
execute in minecraft:overworld run setblock 274 64 42 coarse_dirt
execute in minecraft:overworld run fill 274 65 42 274 144 42 air
execute in minecraft:overworld run fill 274 58 43 274 61 43 stone
execute in minecraft:overworld run fill 274 62 43 274 63 43 dirt
execute in minecraft:overworld run setblock 274 64 43 coarse_dirt
execute in minecraft:overworld run fill 274 65 43 274 144 43 air
execute in minecraft:overworld run fill 274 58 44 274 61 44 stone
execute in minecraft:overworld run fill 274 62 44 274 63 44 dirt
execute in minecraft:overworld run setblock 274 64 44 coarse_dirt
execute in minecraft:overworld run fill 274 65 44 274 144 44 air
execute in minecraft:overworld run fill 274 58 45 274 61 45 stone
execute in minecraft:overworld run fill 274 62 45 274 63 45 dirt
execute in minecraft:overworld run setblock 274 64 45 coarse_dirt
execute in minecraft:overworld run fill 274 65 45 274 144 45 air
execute in minecraft:overworld run fill 274 58 46 274 61 46 stone
execute in minecraft:overworld run fill 274 62 46 274 63 46 dirt
execute in minecraft:overworld run setblock 274 64 46 coarse_dirt
execute in minecraft:overworld run fill 274 65 46 274 144 46 air
execute in minecraft:overworld run fill 274 58 47 274 61 47 stone
execute in minecraft:overworld run fill 274 62 47 274 63 47 dirt
execute in minecraft:overworld run setblock 274 64 47 grass_block
execute in minecraft:overworld run fill 274 65 47 274 144 47 air
execute in minecraft:overworld run fill 275 58 -48 275 61 -48 stone
execute in minecraft:overworld run fill 275 62 -48 275 63 -48 dirt
execute in minecraft:overworld run setblock 275 64 -48 grass_block
execute in minecraft:overworld run fill 275 65 -48 275 144 -48 air
execute in minecraft:overworld run fill 275 58 -47 275 63 -47 stone
execute in minecraft:overworld run fill 275 64 -47 275 65 -47 dirt
execute in minecraft:overworld run setblock 275 66 -47 coarse_dirt
execute in minecraft:overworld run fill 275 67 -47 275 144 -47 air
execute in minecraft:overworld run fill 275 58 -46 275 65 -46 stone
execute in minecraft:overworld run fill 275 66 -46 275 67 -46 dirt
execute in minecraft:overworld run setblock 275 68 -46 coarse_dirt
execute in minecraft:overworld run fill 275 69 -46 275 144 -46 air
execute in minecraft:overworld run fill 275 58 -45 275 67 -45 stone
execute in minecraft:overworld run fill 275 68 -45 275 69 -45 dirt
execute in minecraft:overworld run setblock 275 70 -45 coarse_dirt
execute in minecraft:overworld run fill 275 71 -45 275 144 -45 air
execute in minecraft:overworld run fill 275 58 -44 275 69 -44 stone
execute in minecraft:overworld run fill 275 70 -44 275 71 -44 dirt
execute in minecraft:overworld run setblock 275 72 -44 coarse_dirt
execute in minecraft:overworld run fill 275 73 -44 275 144 -44 air
execute in minecraft:overworld run fill 275 58 -43 275 71 -43 stone
execute in minecraft:overworld run fill 275 72 -43 275 73 -43 dirt
execute in minecraft:overworld run setblock 275 74 -43 grass_block
execute in minecraft:overworld run fill 275 75 -43 275 144 -43 air
execute in minecraft:overworld run fill 275 58 -42 275 73 -42 stone
execute in minecraft:overworld run fill 275 74 -42 275 75 -42 dirt
execute in minecraft:overworld run setblock 275 76 -42 coarse_dirt
execute in minecraft:overworld run fill 275 77 -42 275 144 -42 air
execute in minecraft:overworld run fill 275 58 -41 275 75 -41 stone
execute in minecraft:overworld run fill 275 76 -41 275 77 -41 dirt
execute in minecraft:overworld run setblock 275 78 -41 grass_block
execute in minecraft:overworld run fill 275 79 -41 275 144 -41 air
execute in minecraft:overworld run fill 275 58 -40 275 76 -40 stone
execute in minecraft:overworld run fill 275 77 -40 275 78 -40 dirt
execute in minecraft:overworld run setblock 275 79 -40 grass_block
execute in minecraft:overworld run fill 275 80 -40 275 144 -40 air
execute in minecraft:overworld run fill 275 58 -39 275 78 -39 stone
execute in minecraft:overworld run fill 275 79 -39 275 80 -39 dirt
execute in minecraft:overworld run setblock 275 81 -39 coarse_dirt
execute in minecraft:overworld run fill 275 82 -39 275 144 -39 air
execute in minecraft:overworld run fill 275 58 -38 275 79 -38 stone
execute in minecraft:overworld run fill 275 80 -38 275 81 -38 dirt
execute in minecraft:overworld run setblock 275 82 -38 grass_block
execute in minecraft:overworld run fill 275 83 -38 275 144 -38 air
execute in minecraft:overworld run fill 275 58 -37 275 78 -37 stone
execute in minecraft:overworld run fill 275 79 -37 275 80 -37 dirt
execute in minecraft:overworld run setblock 275 81 -37 grass_block
execute in minecraft:overworld run fill 275 82 -37 275 144 -37 air
execute in minecraft:overworld run fill 275 58 -36 275 78 -36 stone
execute in minecraft:overworld run fill 275 79 -36 275 80 -36 dirt
execute in minecraft:overworld run setblock 275 81 -36 coarse_dirt
execute in minecraft:overworld run fill 275 82 -36 275 144 -36 air
execute in minecraft:overworld run fill 275 58 -35 275 78 -35 stone
execute in minecraft:overworld run fill 275 79 -35 275 80 -35 dirt
execute in minecraft:overworld run setblock 275 81 -35 coarse_dirt
execute in minecraft:overworld run fill 275 82 -35 275 144 -35 air
execute in minecraft:overworld run fill 275 58 -34 275 77 -34 stone
execute in minecraft:overworld run fill 275 78 -34 275 79 -34 dirt
execute in minecraft:overworld run setblock 275 80 -34 grass_block
execute in minecraft:overworld run fill 275 81 -34 275 144 -34 air
execute in minecraft:overworld run setblock 275 81 -34 grass
execute in minecraft:overworld run fill 275 58 -33 275 77 -33 stone
execute in minecraft:overworld run fill 275 78 -33 275 79 -33 dirt
execute in minecraft:overworld run setblock 275 80 -33 coarse_dirt
execute in minecraft:overworld run fill 275 81 -33 275 144 -33 air
execute in minecraft:overworld run fill 275 58 -32 275 76 -32 stone
execute in minecraft:overworld run fill 275 77 -32 275 78 -32 dirt
execute in minecraft:overworld run setblock 275 79 -32 coarse_dirt
execute in minecraft:overworld run fill 275 80 -32 275 144 -32 air
execute in minecraft:overworld run fill 275 58 -31 275 76 -31 stone
execute in minecraft:overworld run fill 275 77 -31 275 78 -31 dirt
execute in minecraft:overworld run setblock 275 79 -31 coarse_dirt
execute in minecraft:overworld run fill 275 80 -31 275 144 -31 air
execute in minecraft:overworld run fill 275 58 -30 275 76 -30 stone
execute in minecraft:overworld run fill 275 77 -30 275 78 -30 dirt
execute in minecraft:overworld run setblock 275 79 -30 coarse_dirt
execute in minecraft:overworld run fill 275 80 -30 275 144 -30 air
execute in minecraft:overworld run fill 275 58 -29 275 75 -29 stone
execute in minecraft:overworld run fill 275 76 -29 275 77 -29 dirt
execute in minecraft:overworld run setblock 275 78 -29 grass_block
execute in minecraft:overworld run fill 275 79 -29 275 144 -29 air
execute in minecraft:overworld run setblock 275 79 -29 grass
execute in minecraft:overworld run fill 275 58 -28 275 75 -28 stone
execute in minecraft:overworld run fill 275 76 -28 275 77 -28 dirt
execute in minecraft:overworld run setblock 275 78 -28 coarse_dirt
execute in minecraft:overworld run fill 275 79 -28 275 144 -28 air
execute in minecraft:overworld run fill 275 58 -27 275 75 -27 stone
execute in minecraft:overworld run fill 275 76 -27 275 77 -27 dirt
execute in minecraft:overworld run setblock 275 78 -27 coarse_dirt
execute in minecraft:overworld run fill 275 79 -27 275 144 -27 air
execute in minecraft:overworld run fill 275 58 -26 275 74 -26 stone
execute in minecraft:overworld run fill 275 75 -26 275 76 -26 dirt
execute in minecraft:overworld run setblock 275 77 -26 coarse_dirt
execute in minecraft:overworld run fill 275 78 -26 275 144 -26 air
execute in minecraft:overworld run fill 275 58 -25 275 74 -25 stone
execute in minecraft:overworld run fill 275 75 -25 275 76 -25 dirt
execute in minecraft:overworld run setblock 275 77 -25 coarse_dirt
execute in minecraft:overworld run fill 275 78 -25 275 144 -25 air
execute in minecraft:overworld run fill 275 58 -24 275 74 -24 stone
execute in minecraft:overworld run fill 275 75 -24 275 76 -24 dirt
execute in minecraft:overworld run setblock 275 77 -24 coarse_dirt
execute in minecraft:overworld run fill 275 78 -24 275 144 -24 air
execute in minecraft:overworld run fill 275 58 -23 275 73 -23 stone
execute in minecraft:overworld run fill 275 74 -23 275 75 -23 dirt
execute in minecraft:overworld run setblock 275 76 -23 coarse_dirt
execute in minecraft:overworld run fill 275 77 -23 275 144 -23 air
execute in minecraft:overworld run fill 275 58 -22 275 73 -22 stone
execute in minecraft:overworld run fill 275 74 -22 275 75 -22 dirt
execute in minecraft:overworld run setblock 275 76 -22 grass_block
execute in minecraft:overworld run fill 275 77 -22 275 144 -22 air
execute in minecraft:overworld run fill 275 58 -21 275 73 -21 stone
execute in minecraft:overworld run fill 275 74 -21 275 75 -21 dirt
execute in minecraft:overworld run setblock 275 76 -21 coarse_dirt
execute in minecraft:overworld run fill 275 77 -21 275 144 -21 air
execute in minecraft:overworld run fill 275 58 -20 275 72 -20 stone
execute in minecraft:overworld run fill 275 73 -20 275 74 -20 dirt
execute in minecraft:overworld run setblock 275 75 -20 grass_block
execute in minecraft:overworld run fill 275 76 -20 275 144 -20 air
execute in minecraft:overworld run fill 275 58 -19 275 72 -19 stone
execute in minecraft:overworld run fill 275 73 -19 275 74 -19 dirt
execute in minecraft:overworld run setblock 275 75 -19 grass_block
execute in minecraft:overworld run fill 275 76 -19 275 144 -19 air
execute in minecraft:overworld run fill 275 58 -18 275 72 -18 stone
execute in minecraft:overworld run fill 275 73 -18 275 74 -18 dirt
execute in minecraft:overworld run setblock 275 75 -18 coarse_dirt
execute in minecraft:overworld run fill 275 76 -18 275 144 -18 air
execute in minecraft:overworld run fill 275 58 -17 275 71 -17 stone
execute in minecraft:overworld run fill 275 72 -17 275 73 -17 dirt
execute in minecraft:overworld run setblock 275 74 -17 coarse_dirt
execute in minecraft:overworld run fill 275 75 -17 275 144 -17 air
execute in minecraft:overworld run fill 275 58 -16 275 70 -16 stone
execute in minecraft:overworld run fill 275 71 -16 275 72 -16 dirt
execute in minecraft:overworld run setblock 275 73 -16 coarse_dirt
execute in minecraft:overworld run fill 275 74 -16 275 144 -16 air
execute in minecraft:overworld run fill 275 58 -15 275 70 -15 stone
execute in minecraft:overworld run fill 275 71 -15 275 72 -15 dirt
execute in minecraft:overworld run setblock 275 73 -15 coarse_dirt
execute in minecraft:overworld run fill 275 74 -15 275 144 -15 air
schedule function blade_gallery:random/burned/part_107 1t replace
