execute in minecraft:overworld run fill 270 58 -4 270 60 -4 stone
execute in minecraft:overworld run fill 270 61 -4 270 62 -4 dirt
execute in minecraft:overworld run setblock 270 63 -4 gravel
execute in minecraft:overworld run fill 270 64 -4 270 144 -4 air
execute in minecraft:overworld run fill 270 64 -4 270 64 -4 water
execute in minecraft:overworld run fill 270 58 -3 270 59 -3 stone
execute in minecraft:overworld run fill 270 60 -3 270 61 -3 dirt
execute in minecraft:overworld run setblock 270 62 -3 gravel
execute in minecraft:overworld run fill 270 63 -3 270 144 -3 air
execute in minecraft:overworld run fill 270 63 -3 270 64 -3 water
execute in minecraft:overworld run fill 270 58 -2 270 59 -2 stone
execute in minecraft:overworld run fill 270 60 -2 270 61 -2 dirt
execute in minecraft:overworld run setblock 270 62 -2 gravel
execute in minecraft:overworld run fill 270 63 -2 270 144 -2 air
execute in minecraft:overworld run fill 270 63 -2 270 64 -2 water
execute in minecraft:overworld run fill 270 58 -1 270 59 -1 stone
execute in minecraft:overworld run fill 270 60 -1 270 61 -1 dirt
execute in minecraft:overworld run setblock 270 62 -1 gravel
execute in minecraft:overworld run fill 270 63 -1 270 144 -1 air
execute in minecraft:overworld run fill 270 63 -1 270 64 -1 water
execute in minecraft:overworld run fill 270 58 0 270 58 0 stone
execute in minecraft:overworld run fill 270 59 0 270 60 0 dirt
execute in minecraft:overworld run setblock 270 61 0 gravel
execute in minecraft:overworld run fill 270 62 0 270 144 0 air
execute in minecraft:overworld run fill 270 62 0 270 64 0 water
execute in minecraft:overworld run fill 270 58 1 270 58 1 stone
execute in minecraft:overworld run fill 270 59 1 270 60 1 dirt
execute in minecraft:overworld run setblock 270 61 1 gravel
execute in minecraft:overworld run fill 270 62 1 270 144 1 air
execute in minecraft:overworld run fill 270 62 1 270 64 1 water
execute in minecraft:overworld run fill 270 58 2 270 58 2 stone
execute in minecraft:overworld run fill 270 59 2 270 60 2 dirt
execute in minecraft:overworld run setblock 270 61 2 gravel
execute in minecraft:overworld run fill 270 62 2 270 144 2 air
execute in minecraft:overworld run fill 270 62 2 270 64 2 water
execute in minecraft:overworld run fill 270 58 3 270 58 3 stone
execute in minecraft:overworld run fill 270 59 3 270 60 3 dirt
execute in minecraft:overworld run setblock 270 61 3 gravel
execute in minecraft:overworld run fill 270 62 3 270 144 3 air
execute in minecraft:overworld run fill 270 62 3 270 64 3 water
execute in minecraft:overworld run fill 270 58 4 270 58 4 stone
execute in minecraft:overworld run fill 270 59 4 270 60 4 dirt
execute in minecraft:overworld run setblock 270 61 4 gravel
execute in minecraft:overworld run fill 270 62 4 270 144 4 air
execute in minecraft:overworld run fill 270 62 4 270 64 4 water
execute in minecraft:overworld run fill 270 58 5 270 58 5 stone
execute in minecraft:overworld run fill 270 59 5 270 60 5 dirt
execute in minecraft:overworld run setblock 270 61 5 gravel
execute in minecraft:overworld run fill 270 62 5 270 144 5 air
execute in minecraft:overworld run fill 270 62 5 270 64 5 water
execute in minecraft:overworld run fill 270 58 6 270 58 6 stone
execute in minecraft:overworld run fill 270 59 6 270 60 6 dirt
execute in minecraft:overworld run setblock 270 61 6 gravel
execute in minecraft:overworld run fill 270 62 6 270 144 6 air
execute in minecraft:overworld run fill 270 62 6 270 64 6 water
execute in minecraft:overworld run fill 270 58 7 270 58 7 stone
execute in minecraft:overworld run fill 270 59 7 270 60 7 dirt
execute in minecraft:overworld run setblock 270 61 7 gravel
execute in minecraft:overworld run fill 270 62 7 270 144 7 air
execute in minecraft:overworld run fill 270 62 7 270 64 7 water
execute in minecraft:overworld run fill 270 58 8 270 58 8 stone
execute in minecraft:overworld run fill 270 59 8 270 60 8 dirt
execute in minecraft:overworld run setblock 270 61 8 gravel
execute in minecraft:overworld run fill 270 62 8 270 144 8 air
execute in minecraft:overworld run fill 270 62 8 270 64 8 water
execute in minecraft:overworld run fill 270 58 9 270 58 9 stone
execute in minecraft:overworld run fill 270 59 9 270 60 9 dirt
execute in minecraft:overworld run setblock 270 61 9 gravel
execute in minecraft:overworld run fill 270 62 9 270 144 9 air
execute in minecraft:overworld run fill 270 62 9 270 64 9 water
execute in minecraft:overworld run fill 270 58 10 270 58 10 stone
execute in minecraft:overworld run fill 270 59 10 270 60 10 dirt
execute in minecraft:overworld run setblock 270 61 10 gravel
execute in minecraft:overworld run fill 270 62 10 270 144 10 air
execute in minecraft:overworld run fill 270 62 10 270 64 10 water
execute in minecraft:overworld run fill 270 58 11 270 58 11 stone
execute in minecraft:overworld run fill 270 59 11 270 60 11 dirt
execute in minecraft:overworld run setblock 270 61 11 gravel
execute in minecraft:overworld run fill 270 62 11 270 144 11 air
execute in minecraft:overworld run fill 270 62 11 270 64 11 water
execute in minecraft:overworld run fill 270 58 12 270 57 12 stone
execute in minecraft:overworld run fill 270 58 12 270 59 12 dirt
execute in minecraft:overworld run setblock 270 60 12 gravel
execute in minecraft:overworld run fill 270 61 12 270 144 12 air
execute in minecraft:overworld run fill 270 61 12 270 64 12 water
execute in minecraft:overworld run fill 270 58 13 270 57 13 stone
execute in minecraft:overworld run fill 270 58 13 270 59 13 dirt
execute in minecraft:overworld run setblock 270 60 13 gravel
execute in minecraft:overworld run fill 270 61 13 270 144 13 air
execute in minecraft:overworld run fill 270 61 13 270 64 13 water
execute in minecraft:overworld run fill 270 58 14 270 57 14 stone
execute in minecraft:overworld run fill 270 58 14 270 59 14 dirt
execute in minecraft:overworld run setblock 270 60 14 gravel
execute in minecraft:overworld run fill 270 61 14 270 144 14 air
execute in minecraft:overworld run fill 270 61 14 270 64 14 water
execute in minecraft:overworld run fill 270 58 15 270 57 15 stone
execute in minecraft:overworld run fill 270 58 15 270 59 15 dirt
execute in minecraft:overworld run setblock 270 60 15 gravel
execute in minecraft:overworld run fill 270 61 15 270 144 15 air
execute in minecraft:overworld run fill 270 61 15 270 64 15 water
execute in minecraft:overworld run fill 270 58 16 270 57 16 stone
execute in minecraft:overworld run fill 270 58 16 270 59 16 dirt
execute in minecraft:overworld run setblock 270 60 16 gravel
execute in minecraft:overworld run fill 270 61 16 270 144 16 air
execute in minecraft:overworld run fill 270 61 16 270 64 16 water
execute in minecraft:overworld run fill 270 58 17 270 57 17 stone
execute in minecraft:overworld run fill 270 58 17 270 59 17 dirt
execute in minecraft:overworld run setblock 270 60 17 gravel
execute in minecraft:overworld run fill 270 61 17 270 144 17 air
execute in minecraft:overworld run fill 270 61 17 270 64 17 water
execute in minecraft:overworld run fill 270 58 18 270 56 18 stone
execute in minecraft:overworld run fill 270 57 18 270 58 18 dirt
execute in minecraft:overworld run setblock 270 59 18 gravel
execute in minecraft:overworld run fill 270 60 18 270 144 18 air
execute in minecraft:overworld run fill 270 60 18 270 64 18 water
execute in minecraft:overworld run fill 270 58 19 270 56 19 stone
execute in minecraft:overworld run fill 270 57 19 270 58 19 dirt
execute in minecraft:overworld run setblock 270 59 19 gravel
execute in minecraft:overworld run fill 270 60 19 270 144 19 air
execute in minecraft:overworld run fill 270 60 19 270 64 19 water
execute in minecraft:overworld run fill 270 58 20 270 56 20 stone
execute in minecraft:overworld run fill 270 57 20 270 58 20 dirt
execute in minecraft:overworld run setblock 270 59 20 gravel
execute in minecraft:overworld run fill 270 60 20 270 144 20 air
execute in minecraft:overworld run fill 270 60 20 270 64 20 water
execute in minecraft:overworld run fill 270 58 21 270 56 21 stone
execute in minecraft:overworld run fill 270 57 21 270 58 21 dirt
execute in minecraft:overworld run setblock 270 59 21 gravel
execute in minecraft:overworld run fill 270 60 21 270 144 21 air
execute in minecraft:overworld run fill 270 60 21 270 64 21 water
execute in minecraft:overworld run fill 270 58 22 270 57 22 stone
execute in minecraft:overworld run fill 270 58 22 270 59 22 dirt
execute in minecraft:overworld run setblock 270 60 22 gravel
execute in minecraft:overworld run fill 270 61 22 270 144 22 air
execute in minecraft:overworld run fill 270 61 22 270 64 22 water
execute in minecraft:overworld run fill 270 58 23 270 57 23 stone
execute in minecraft:overworld run fill 270 58 23 270 59 23 dirt
execute in minecraft:overworld run setblock 270 60 23 gravel
execute in minecraft:overworld run fill 270 61 23 270 144 23 air
execute in minecraft:overworld run fill 270 61 23 270 64 23 water
execute in minecraft:overworld run fill 270 58 24 270 57 24 stone
execute in minecraft:overworld run fill 270 58 24 270 59 24 dirt
execute in minecraft:overworld run setblock 270 60 24 gravel
execute in minecraft:overworld run fill 270 61 24 270 144 24 air
execute in minecraft:overworld run fill 270 61 24 270 64 24 water
execute in minecraft:overworld run fill 270 58 25 270 57 25 stone
execute in minecraft:overworld run fill 270 58 25 270 59 25 dirt
execute in minecraft:overworld run setblock 270 60 25 gravel
execute in minecraft:overworld run fill 270 61 25 270 144 25 air
execute in minecraft:overworld run fill 270 61 25 270 64 25 water
execute in minecraft:overworld run fill 270 58 26 270 58 26 stone
execute in minecraft:overworld run fill 270 59 26 270 60 26 dirt
execute in minecraft:overworld run setblock 270 61 26 gravel
execute in minecraft:overworld run fill 270 62 26 270 144 26 air
execute in minecraft:overworld run fill 270 62 26 270 64 26 water
execute in minecraft:overworld run fill 270 58 27 270 58 27 stone
execute in minecraft:overworld run fill 270 59 27 270 60 27 dirt
execute in minecraft:overworld run setblock 270 61 27 gravel
execute in minecraft:overworld run fill 270 62 27 270 144 27 air
execute in minecraft:overworld run fill 270 62 27 270 64 27 water
execute in minecraft:overworld run fill 270 58 28 270 58 28 stone
execute in minecraft:overworld run fill 270 59 28 270 60 28 dirt
execute in minecraft:overworld run setblock 270 61 28 gravel
execute in minecraft:overworld run fill 270 62 28 270 144 28 air
execute in minecraft:overworld run fill 270 62 28 270 64 28 water
execute in minecraft:overworld run fill 270 58 29 270 58 29 stone
execute in minecraft:overworld run fill 270 59 29 270 60 29 dirt
execute in minecraft:overworld run setblock 270 61 29 gravel
execute in minecraft:overworld run fill 270 62 29 270 144 29 air
execute in minecraft:overworld run fill 270 62 29 270 64 29 water
execute in minecraft:overworld run fill 270 58 30 270 59 30 stone
execute in minecraft:overworld run fill 270 60 30 270 61 30 dirt
execute in minecraft:overworld run setblock 270 62 30 gravel
execute in minecraft:overworld run fill 270 63 30 270 144 30 air
execute in minecraft:overworld run fill 270 63 30 270 64 30 water
execute in minecraft:overworld run fill 270 58 31 270 59 31 stone
execute in minecraft:overworld run fill 270 60 31 270 61 31 dirt
execute in minecraft:overworld run setblock 270 62 31 gravel
execute in minecraft:overworld run fill 270 63 31 270 144 31 air
execute in minecraft:overworld run fill 270 63 31 270 64 31 water
execute in minecraft:overworld run fill 270 58 32 270 59 32 stone
execute in minecraft:overworld run fill 270 60 32 270 61 32 dirt
execute in minecraft:overworld run setblock 270 62 32 gravel
execute in minecraft:overworld run fill 270 63 32 270 144 32 air
execute in minecraft:overworld run fill 270 63 32 270 64 32 water
execute in minecraft:overworld run fill 270 58 33 270 60 33 stone
execute in minecraft:overworld run fill 270 61 33 270 62 33 dirt
execute in minecraft:overworld run setblock 270 63 33 gravel
execute in minecraft:overworld run fill 270 64 33 270 144 33 air
execute in minecraft:overworld run fill 270 64 33 270 64 33 water
execute in minecraft:overworld run fill 270 58 34 270 60 34 stone
execute in minecraft:overworld run fill 270 61 34 270 62 34 dirt
execute in minecraft:overworld run setblock 270 63 34 gravel
execute in minecraft:overworld run fill 270 64 34 270 144 34 air
execute in minecraft:overworld run fill 270 64 34 270 64 34 water
execute in minecraft:overworld run fill 270 58 35 270 60 35 stone
execute in minecraft:overworld run fill 270 61 35 270 62 35 dirt
execute in minecraft:overworld run setblock 270 63 35 gravel
execute in minecraft:overworld run fill 270 64 35 270 144 35 air
execute in minecraft:overworld run fill 270 64 35 270 64 35 water
execute in minecraft:overworld run fill 270 58 36 270 60 36 stone
execute in minecraft:overworld run fill 270 61 36 270 62 36 dirt
execute in minecraft:overworld run setblock 270 63 36 gravel
execute in minecraft:overworld run fill 270 64 36 270 144 36 air
execute in minecraft:overworld run fill 270 64 36 270 64 36 water
execute in minecraft:overworld run fill 270 58 37 270 61 37 stone
execute in minecraft:overworld run fill 270 62 37 270 63 37 dirt
execute in minecraft:overworld run setblock 270 64 37 coarse_dirt
execute in minecraft:overworld run fill 270 65 37 270 144 37 air
execute in minecraft:overworld run fill 270 58 38 270 61 38 stone
execute in minecraft:overworld run fill 270 62 38 270 63 38 dirt
execute in minecraft:overworld run setblock 270 64 38 coarse_dirt
execute in minecraft:overworld run fill 270 65 38 270 144 38 air
execute in minecraft:overworld run fill 270 58 39 270 61 39 stone
execute in minecraft:overworld run fill 270 62 39 270 63 39 dirt
execute in minecraft:overworld run setblock 270 64 39 grass_block
execute in minecraft:overworld run fill 270 65 39 270 144 39 air
execute in minecraft:overworld run fill 270 58 40 270 61 40 stone
execute in minecraft:overworld run fill 270 62 40 270 63 40 dirt
execute in minecraft:overworld run setblock 270 64 40 coarse_dirt
execute in minecraft:overworld run fill 270 65 40 270 144 40 air
execute in minecraft:overworld run fill 270 58 41 270 61 41 stone
execute in minecraft:overworld run fill 270 62 41 270 63 41 dirt
execute in minecraft:overworld run setblock 270 64 41 grass_block
execute in minecraft:overworld run fill 270 65 41 270 144 41 air
execute in minecraft:overworld run fill 270 58 42 270 61 42 stone
execute in minecraft:overworld run fill 270 62 42 270 63 42 dirt
execute in minecraft:overworld run setblock 270 64 42 coarse_dirt
execute in minecraft:overworld run fill 270 65 42 270 144 42 air
execute in minecraft:overworld run fill 270 58 43 270 61 43 stone
execute in minecraft:overworld run fill 270 62 43 270 63 43 dirt
execute in minecraft:overworld run setblock 270 64 43 coarse_dirt
execute in minecraft:overworld run fill 270 65 43 270 144 43 air
execute in minecraft:overworld run fill 270 58 44 270 61 44 stone
execute in minecraft:overworld run fill 270 62 44 270 63 44 dirt
execute in minecraft:overworld run setblock 270 64 44 grass_block
execute in minecraft:overworld run fill 270 65 44 270 144 44 air
execute in minecraft:overworld run fill 270 58 45 270 61 45 stone
execute in minecraft:overworld run fill 270 62 45 270 63 45 dirt
execute in minecraft:overworld run setblock 270 64 45 grass_block
execute in minecraft:overworld run fill 270 65 45 270 144 45 air
execute in minecraft:overworld run fill 270 58 46 270 61 46 stone
execute in minecraft:overworld run fill 270 62 46 270 63 46 dirt
execute in minecraft:overworld run setblock 270 64 46 grass_block
execute in minecraft:overworld run fill 270 65 46 270 144 46 air
execute in minecraft:overworld run fill 270 58 47 270 61 47 stone
execute in minecraft:overworld run fill 270 62 47 270 63 47 dirt
execute in minecraft:overworld run setblock 270 64 47 coarse_dirt
execute in minecraft:overworld run fill 270 65 47 270 144 47 air
execute in minecraft:overworld run fill 271 58 -48 271 61 -48 stone
execute in minecraft:overworld run fill 271 62 -48 271 63 -48 dirt
execute in minecraft:overworld run setblock 271 64 -48 grass_block
execute in minecraft:overworld run fill 271 65 -48 271 144 -48 air
execute in minecraft:overworld run fill 271 58 -47 271 63 -47 stone
execute in minecraft:overworld run fill 271 64 -47 271 65 -47 dirt
execute in minecraft:overworld run setblock 271 66 -47 grass_block
schedule function blade_gallery:random/burned/part_100 1t replace
