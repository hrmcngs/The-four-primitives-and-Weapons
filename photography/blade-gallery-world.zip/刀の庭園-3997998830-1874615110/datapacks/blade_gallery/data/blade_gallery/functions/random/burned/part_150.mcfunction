execute in minecraft:overworld run fill 303 63 -7 303 64 -7 dirt
execute in minecraft:overworld run setblock 303 65 -7 grass_block
execute in minecraft:overworld run fill 303 66 -7 303 144 -7 air
execute in minecraft:overworld run fill 303 58 -6 303 62 -6 stone
execute in minecraft:overworld run fill 303 63 -6 303 64 -6 dirt
execute in minecraft:overworld run setblock 303 65 -6 grass_block
execute in minecraft:overworld run fill 303 66 -6 303 144 -6 air
execute in minecraft:overworld run fill 303 58 -5 303 62 -5 stone
execute in minecraft:overworld run fill 303 63 -5 303 64 -5 dirt
execute in minecraft:overworld run setblock 303 65 -5 grass_block
execute in minecraft:overworld run fill 303 66 -5 303 144 -5 air
execute in minecraft:overworld run fill 303 58 -4 303 62 -4 stone
execute in minecraft:overworld run fill 303 63 -4 303 64 -4 dirt
execute in minecraft:overworld run setblock 303 65 -4 coarse_dirt
execute in minecraft:overworld run fill 303 66 -4 303 144 -4 air
execute in minecraft:overworld run fill 303 58 -3 303 62 -3 stone
execute in minecraft:overworld run fill 303 63 -3 303 64 -3 dirt
execute in minecraft:overworld run setblock 303 65 -3 grass_block
execute in minecraft:overworld run fill 303 66 -3 303 144 -3 air
execute in minecraft:overworld run fill 303 58 -2 303 62 -2 stone
execute in minecraft:overworld run fill 303 63 -2 303 64 -2 dirt
execute in minecraft:overworld run setblock 303 65 -2 coarse_dirt
execute in minecraft:overworld run fill 303 66 -2 303 144 -2 air
execute in minecraft:overworld run fill 303 58 -1 303 62 -1 stone
execute in minecraft:overworld run fill 303 63 -1 303 64 -1 dirt
execute in minecraft:overworld run setblock 303 65 -1 coarse_dirt
execute in minecraft:overworld run fill 303 66 -1 303 144 -1 air
execute in minecraft:overworld run fill 303 58 0 303 62 0 stone
execute in minecraft:overworld run fill 303 63 0 303 64 0 dirt
execute in minecraft:overworld run setblock 303 65 0 coarse_dirt
execute in minecraft:overworld run fill 303 66 0 303 144 0 air
execute in minecraft:overworld run fill 303 58 1 303 62 1 stone
execute in minecraft:overworld run fill 303 63 1 303 64 1 dirt
execute in minecraft:overworld run setblock 303 65 1 grass_block
execute in minecraft:overworld run fill 303 66 1 303 144 1 air
execute in minecraft:overworld run fill 303 58 2 303 62 2 stone
execute in minecraft:overworld run fill 303 63 2 303 64 2 dirt
execute in minecraft:overworld run setblock 303 65 2 grass_block
execute in minecraft:overworld run fill 303 66 2 303 144 2 air
execute in minecraft:overworld run fill 303 58 3 303 62 3 stone
execute in minecraft:overworld run fill 303 63 3 303 64 3 dirt
execute in minecraft:overworld run setblock 303 65 3 grass_block
execute in minecraft:overworld run fill 303 66 3 303 144 3 air
execute in minecraft:overworld run fill 303 58 4 303 62 4 stone
execute in minecraft:overworld run fill 303 63 4 303 64 4 dirt
execute in minecraft:overworld run setblock 303 65 4 coarse_dirt
execute in minecraft:overworld run fill 303 66 4 303 144 4 air
execute in minecraft:overworld run fill 303 58 5 303 62 5 stone
execute in minecraft:overworld run fill 303 63 5 303 64 5 dirt
execute in minecraft:overworld run setblock 303 65 5 coarse_dirt
execute in minecraft:overworld run fill 303 66 5 303 144 5 air
execute in minecraft:overworld run fill 303 58 6 303 62 6 stone
execute in minecraft:overworld run fill 303 63 6 303 64 6 dirt
execute in minecraft:overworld run setblock 303 65 6 coarse_dirt
execute in minecraft:overworld run fill 303 66 6 303 144 6 air
execute in minecraft:overworld run fill 303 58 7 303 62 7 stone
execute in minecraft:overworld run fill 303 63 7 303 64 7 dirt
execute in minecraft:overworld run setblock 303 65 7 coarse_dirt
execute in minecraft:overworld run fill 303 66 7 303 144 7 air
execute in minecraft:overworld run fill 303 58 8 303 62 8 stone
execute in minecraft:overworld run fill 303 63 8 303 64 8 dirt
execute in minecraft:overworld run setblock 303 65 8 coarse_dirt
execute in minecraft:overworld run fill 303 66 8 303 144 8 air
execute in minecraft:overworld run fill 303 58 9 303 62 9 stone
execute in minecraft:overworld run fill 303 63 9 303 64 9 dirt
execute in minecraft:overworld run setblock 303 65 9 coarse_dirt
execute in minecraft:overworld run fill 303 66 9 303 144 9 air
execute in minecraft:overworld run fill 303 58 10 303 62 10 stone
execute in minecraft:overworld run fill 303 63 10 303 64 10 dirt
execute in minecraft:overworld run setblock 303 65 10 coarse_dirt
execute in minecraft:overworld run fill 303 66 10 303 144 10 air
execute in minecraft:overworld run fill 303 58 11 303 62 11 stone
execute in minecraft:overworld run fill 303 63 11 303 64 11 dirt
execute in minecraft:overworld run setblock 303 65 11 coarse_dirt
execute in minecraft:overworld run fill 303 66 11 303 144 11 air
execute in minecraft:overworld run fill 303 58 12 303 62 12 stone
execute in minecraft:overworld run fill 303 63 12 303 64 12 dirt
execute in minecraft:overworld run setblock 303 65 12 coarse_dirt
execute in minecraft:overworld run fill 303 66 12 303 144 12 air
execute in minecraft:overworld run fill 303 58 13 303 62 13 stone
execute in minecraft:overworld run fill 303 63 13 303 64 13 dirt
execute in minecraft:overworld run setblock 303 65 13 coarse_dirt
execute in minecraft:overworld run fill 303 66 13 303 144 13 air
execute in minecraft:overworld run fill 303 58 14 303 62 14 stone
execute in minecraft:overworld run fill 303 63 14 303 64 14 dirt
execute in minecraft:overworld run setblock 303 65 14 coarse_dirt
execute in minecraft:overworld run fill 303 66 14 303 144 14 air
execute in minecraft:overworld run fill 303 58 15 303 62 15 stone
execute in minecraft:overworld run fill 303 63 15 303 64 15 dirt
execute in minecraft:overworld run setblock 303 65 15 coarse_dirt
execute in minecraft:overworld run fill 303 66 15 303 144 15 air
execute in minecraft:overworld run fill 303 58 16 303 62 16 stone
execute in minecraft:overworld run fill 303 63 16 303 64 16 dirt
execute in minecraft:overworld run setblock 303 65 16 coarse_dirt
execute in minecraft:overworld run fill 303 66 16 303 144 16 air
execute in minecraft:overworld run fill 303 58 17 303 62 17 stone
execute in minecraft:overworld run fill 303 63 17 303 64 17 dirt
execute in minecraft:overworld run setblock 303 65 17 grass_block
execute in minecraft:overworld run fill 303 66 17 303 144 17 air
execute in minecraft:overworld run fill 303 58 18 303 62 18 stone
execute in minecraft:overworld run fill 303 63 18 303 64 18 dirt
execute in minecraft:overworld run setblock 303 65 18 coarse_dirt
execute in minecraft:overworld run fill 303 66 18 303 144 18 air
execute in minecraft:overworld run fill 303 58 19 303 62 19 stone
execute in minecraft:overworld run fill 303 63 19 303 64 19 dirt
execute in minecraft:overworld run setblock 303 65 19 coarse_dirt
execute in minecraft:overworld run fill 303 66 19 303 144 19 air
execute in minecraft:overworld run fill 303 58 20 303 62 20 stone
execute in minecraft:overworld run fill 303 63 20 303 64 20 dirt
execute in minecraft:overworld run setblock 303 65 20 grass_block
execute in minecraft:overworld run fill 303 66 20 303 144 20 air
execute in minecraft:overworld run fill 303 58 21 303 62 21 stone
execute in minecraft:overworld run fill 303 63 21 303 64 21 dirt
execute in minecraft:overworld run setblock 303 65 21 coarse_dirt
execute in minecraft:overworld run fill 303 66 21 303 144 21 air
execute in minecraft:overworld run fill 303 58 22 303 62 22 stone
execute in minecraft:overworld run fill 303 63 22 303 64 22 dirt
execute in minecraft:overworld run setblock 303 65 22 grass_block
execute in minecraft:overworld run fill 303 66 22 303 144 22 air
execute in minecraft:overworld run fill 303 58 23 303 62 23 stone
execute in minecraft:overworld run fill 303 63 23 303 64 23 dirt
execute in minecraft:overworld run setblock 303 65 23 grass_block
execute in minecraft:overworld run fill 303 66 23 303 144 23 air
execute in minecraft:overworld run fill 303 58 24 303 62 24 stone
execute in minecraft:overworld run fill 303 63 24 303 64 24 dirt
execute in minecraft:overworld run setblock 303 65 24 grass_block
execute in minecraft:overworld run fill 303 66 24 303 144 24 air
execute in minecraft:overworld run fill 303 58 25 303 62 25 stone
execute in minecraft:overworld run fill 303 63 25 303 64 25 dirt
execute in minecraft:overworld run setblock 303 65 25 grass_block
execute in minecraft:overworld run fill 303 66 25 303 144 25 air
execute in minecraft:overworld run fill 303 58 26 303 62 26 stone
execute in minecraft:overworld run fill 303 63 26 303 64 26 dirt
execute in minecraft:overworld run setblock 303 65 26 coarse_dirt
execute in minecraft:overworld run fill 303 66 26 303 144 26 air
execute in minecraft:overworld run fill 303 58 27 303 62 27 stone
execute in minecraft:overworld run fill 303 63 27 303 64 27 dirt
execute in minecraft:overworld run setblock 303 65 27 grass_block
execute in minecraft:overworld run fill 303 66 27 303 144 27 air
execute in minecraft:overworld run fill 303 58 28 303 62 28 stone
execute in minecraft:overworld run fill 303 63 28 303 64 28 dirt
execute in minecraft:overworld run setblock 303 65 28 grass_block
execute in minecraft:overworld run fill 303 66 28 303 144 28 air
execute in minecraft:overworld run fill 303 58 29 303 62 29 stone
execute in minecraft:overworld run fill 303 63 29 303 64 29 dirt
execute in minecraft:overworld run setblock 303 65 29 coarse_dirt
execute in minecraft:overworld run fill 303 66 29 303 144 29 air
execute in minecraft:overworld run fill 303 58 30 303 62 30 stone
execute in minecraft:overworld run fill 303 63 30 303 64 30 dirt
execute in minecraft:overworld run setblock 303 65 30 coarse_dirt
execute in minecraft:overworld run fill 303 66 30 303 144 30 air
execute in minecraft:overworld run fill 303 58 31 303 62 31 stone
execute in minecraft:overworld run fill 303 63 31 303 64 31 dirt
execute in minecraft:overworld run setblock 303 65 31 grass_block
execute in minecraft:overworld run fill 303 66 31 303 144 31 air
execute in minecraft:overworld run fill 303 58 32 303 62 32 stone
execute in minecraft:overworld run fill 303 63 32 303 64 32 dirt
execute in minecraft:overworld run setblock 303 65 32 grass_block
execute in minecraft:overworld run fill 303 66 32 303 144 32 air
execute in minecraft:overworld run fill 303 58 33 303 61 33 stone
execute in minecraft:overworld run fill 303 62 33 303 63 33 dirt
execute in minecraft:overworld run setblock 303 64 33 grass_block
execute in minecraft:overworld run fill 303 65 33 303 144 33 air
execute in minecraft:overworld run fill 303 58 34 303 61 34 stone
execute in minecraft:overworld run fill 303 62 34 303 63 34 dirt
execute in minecraft:overworld run setblock 303 64 34 coarse_dirt
execute in minecraft:overworld run fill 303 65 34 303 144 34 air
execute in minecraft:overworld run fill 303 58 35 303 61 35 stone
execute in minecraft:overworld run fill 303 62 35 303 63 35 dirt
execute in minecraft:overworld run setblock 303 64 35 coarse_dirt
execute in minecraft:overworld run fill 303 65 35 303 144 35 air
execute in minecraft:overworld run fill 303 58 36 303 61 36 stone
execute in minecraft:overworld run fill 303 62 36 303 63 36 dirt
execute in minecraft:overworld run setblock 303 64 36 coarse_dirt
execute in minecraft:overworld run fill 303 65 36 303 144 36 air
execute in minecraft:overworld run fill 303 58 37 303 61 37 stone
execute in minecraft:overworld run fill 303 62 37 303 63 37 dirt
execute in minecraft:overworld run setblock 303 64 37 grass_block
execute in minecraft:overworld run fill 303 65 37 303 144 37 air
execute in minecraft:overworld run fill 303 58 38 303 61 38 stone
execute in minecraft:overworld run fill 303 62 38 303 63 38 dirt
execute in minecraft:overworld run setblock 303 64 38 coarse_dirt
execute in minecraft:overworld run fill 303 65 38 303 144 38 air
execute in minecraft:overworld run fill 303 58 39 303 61 39 stone
execute in minecraft:overworld run fill 303 62 39 303 63 39 dirt
execute in minecraft:overworld run setblock 303 64 39 coarse_dirt
execute in minecraft:overworld run fill 303 65 39 303 144 39 air
execute in minecraft:overworld run fill 303 58 40 303 61 40 stone
execute in minecraft:overworld run fill 303 62 40 303 63 40 dirt
execute in minecraft:overworld run setblock 303 64 40 coarse_dirt
execute in minecraft:overworld run fill 303 65 40 303 144 40 air
execute in minecraft:overworld run fill 303 58 41 303 61 41 stone
execute in minecraft:overworld run fill 303 62 41 303 63 41 dirt
execute in minecraft:overworld run setblock 303 64 41 grass_block
execute in minecraft:overworld run fill 303 65 41 303 144 41 air
execute in minecraft:overworld run fill 303 58 42 303 61 42 stone
execute in minecraft:overworld run fill 303 62 42 303 63 42 dirt
execute in minecraft:overworld run setblock 303 64 42 coarse_dirt
execute in minecraft:overworld run fill 303 65 42 303 144 42 air
execute in minecraft:overworld run fill 303 58 43 303 61 43 stone
execute in minecraft:overworld run fill 303 62 43 303 63 43 dirt
execute in minecraft:overworld run setblock 303 64 43 grass_block
execute in minecraft:overworld run fill 303 65 43 303 144 43 air
execute in minecraft:overworld run fill 303 58 44 303 61 44 stone
execute in minecraft:overworld run fill 303 62 44 303 63 44 dirt
execute in minecraft:overworld run setblock 303 64 44 grass_block
execute in minecraft:overworld run fill 303 65 44 303 144 44 air
execute in minecraft:overworld run fill 303 58 45 303 61 45 stone
execute in minecraft:overworld run fill 303 62 45 303 63 45 dirt
execute in minecraft:overworld run setblock 303 64 45 coarse_dirt
execute in minecraft:overworld run fill 303 65 45 303 144 45 air
execute in minecraft:overworld run fill 303 58 46 303 61 46 stone
execute in minecraft:overworld run fill 303 62 46 303 63 46 dirt
execute in minecraft:overworld run setblock 303 64 46 grass_block
execute in minecraft:overworld run fill 303 65 46 303 144 46 air
execute in minecraft:overworld run fill 303 58 47 303 61 47 stone
execute in minecraft:overworld run fill 303 62 47 303 63 47 dirt
execute in minecraft:overworld run setblock 303 64 47 coarse_dirt
execute in minecraft:overworld run fill 303 65 47 303 144 47 air
execute in minecraft:overworld run fill 255 68 25 255 72 25 stripped_dark_oak_log
execute in minecraft:overworld run fill 242 75 -26 242 79 -26 stripped_dark_oak_log
execute in minecraft:overworld run fill 237 68 3 237 72 3 stripped_dark_oak_log
execute in minecraft:overworld run fill 233 73 19 233 77 19 stripped_dark_oak_log
execute in minecraft:overworld run fill 223 70 -22 223 74 -22 stripped_dark_oak_log
execute in minecraft:overworld run fill 220 72 -35 220 74 -35 stone_bricks
execute in minecraft:overworld run fill 220 72 -34 220 74 -34 stone_bricks
execute in minecraft:overworld run fill 220 71 -33 220 74 -33 stone_bricks
execute in minecraft:overworld run fill 220 71 -32 220 74 -32 stone_bricks
execute in minecraft:overworld run fill 220 70 -31 220 74 -31 stone_bricks
execute in minecraft:overworld run fill 220 70 -30 220 74 -30 stone_bricks
execute in minecraft:overworld run fill 220 69 -29 220 74 -29 stone_bricks
execute in minecraft:overworld run fill 220 69 -28 220 74 -28 stone_bricks
execute in minecraft:overworld run fill 220 69 -27 220 74 -27 stone_bricks
execute in minecraft:overworld run fill 221 72 -35 221 74 -35 stone_bricks
execute in minecraft:overworld run fill 221 72 -34 221 74 -34 stone_bricks
execute in minecraft:overworld run fill 221 71 -33 221 74 -33 stone_bricks
execute in minecraft:overworld run fill 221 70 -32 221 74 -32 stone_bricks
execute in minecraft:overworld run fill 221 70 -31 221 74 -31 stone_bricks
execute in minecraft:overworld run fill 221 70 -30 221 74 -30 stone_bricks
execute in minecraft:overworld run fill 221 69 -29 221 74 -29 stone_bricks
execute in minecraft:overworld run fill 221 69 -28 221 74 -28 stone_bricks
execute in minecraft:overworld run fill 221 69 -27 221 74 -27 stone_bricks
execute in minecraft:overworld run fill 222 72 -35 222 74 -35 stone_bricks
execute in minecraft:overworld run fill 222 71 -34 222 74 -34 stone_bricks
execute in minecraft:overworld run fill 222 71 -33 222 74 -33 stone_bricks
execute in minecraft:overworld run fill 222 70 -32 222 74 -32 stone_bricks
execute in minecraft:overworld run fill 222 70 -31 222 74 -31 stone_bricks
execute in minecraft:overworld run fill 222 70 -30 222 74 -30 stone_bricks
execute in minecraft:overworld run fill 222 69 -29 222 74 -29 stone_bricks
execute in minecraft:overworld run fill 222 69 -28 222 74 -28 stone_bricks
execute in minecraft:overworld run fill 222 69 -27 222 74 -27 stone_bricks
execute in minecraft:overworld run fill 223 72 -35 223 74 -35 stone_bricks
execute in minecraft:overworld run fill 223 71 -34 223 74 -34 stone_bricks
execute in minecraft:overworld run fill 223 71 -33 223 74 -33 stone_bricks
execute in minecraft:overworld run fill 223 70 -32 223 74 -32 stone_bricks
execute in minecraft:overworld run fill 223 70 -31 223 74 -31 stone_bricks
schedule function blade_gallery:random/burned/part_151 1t replace
