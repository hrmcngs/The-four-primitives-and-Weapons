execute in minecraft:overworld run setblock 380 65 44 coarse_dirt
execute in minecraft:overworld run fill 380 66 44 380 144 44 air
execute in minecraft:overworld run fill 380 58 45 380 61 45 stone
execute in minecraft:overworld run fill 380 62 45 380 63 45 dirt
execute in minecraft:overworld run setblock 380 64 45 coarse_dirt
execute in minecraft:overworld run fill 380 65 45 380 144 45 air
execute in minecraft:overworld run fill 380 58 46 380 61 46 stone
execute in minecraft:overworld run fill 380 62 46 380 63 46 dirt
execute in minecraft:overworld run setblock 380 64 46 grass_block
execute in minecraft:overworld run fill 380 65 46 380 144 46 air
execute in minecraft:overworld run fill 380 58 47 380 61 47 stone
execute in minecraft:overworld run fill 380 62 47 380 63 47 dirt
execute in minecraft:overworld run setblock 380 64 47 grass_block
execute in minecraft:overworld run fill 380 65 47 380 144 47 air
execute in minecraft:overworld run fill 381 58 -48 381 61 -48 stone
execute in minecraft:overworld run fill 381 62 -48 381 63 -48 dirt
execute in minecraft:overworld run setblock 381 64 -48 coarse_dirt
execute in minecraft:overworld run fill 381 65 -48 381 144 -48 air
execute in minecraft:overworld run fill 381 58 -47 381 62 -47 stone
execute in minecraft:overworld run fill 381 63 -47 381 64 -47 dirt
execute in minecraft:overworld run setblock 381 65 -47 grass_block
execute in minecraft:overworld run fill 381 66 -47 381 144 -47 air
execute in minecraft:overworld run fill 381 58 -46 381 63 -46 stone
execute in minecraft:overworld run fill 381 64 -46 381 65 -46 dirt
execute in minecraft:overworld run setblock 381 66 -46 coarse_dirt
execute in minecraft:overworld run fill 381 67 -46 381 144 -46 air
execute in minecraft:overworld run fill 381 58 -45 381 65 -45 stone
execute in minecraft:overworld run fill 381 66 -45 381 67 -45 dirt
execute in minecraft:overworld run setblock 381 68 -45 coarse_dirt
execute in minecraft:overworld run fill 381 69 -45 381 144 -45 air
execute in minecraft:overworld run fill 381 58 -44 381 66 -44 stone
execute in minecraft:overworld run fill 381 67 -44 381 68 -44 dirt
execute in minecraft:overworld run setblock 381 69 -44 coarse_dirt
execute in minecraft:overworld run fill 381 70 -44 381 144 -44 air
execute in minecraft:overworld run fill 381 58 -43 381 66 -43 stone
execute in minecraft:overworld run fill 381 67 -43 381 68 -43 dirt
execute in minecraft:overworld run setblock 381 69 -43 grass_block
execute in minecraft:overworld run fill 381 70 -43 381 144 -43 air
execute in minecraft:overworld run fill 381 58 -42 381 67 -42 stone
execute in minecraft:overworld run fill 381 68 -42 381 69 -42 dirt
execute in minecraft:overworld run setblock 381 70 -42 coarse_dirt
execute in minecraft:overworld run fill 381 71 -42 381 144 -42 air
execute in minecraft:overworld run fill 381 58 -41 381 67 -41 stone
execute in minecraft:overworld run fill 381 68 -41 381 69 -41 dirt
execute in minecraft:overworld run setblock 381 70 -41 grass_block
execute in minecraft:overworld run fill 381 71 -41 381 144 -41 air
execute in minecraft:overworld run fill 381 58 -40 381 68 -40 stone
execute in minecraft:overworld run fill 381 69 -40 381 70 -40 dirt
execute in minecraft:overworld run setblock 381 71 -40 coarse_dirt
execute in minecraft:overworld run fill 381 72 -40 381 144 -40 air
execute in minecraft:overworld run fill 381 58 -39 381 68 -39 stone
execute in minecraft:overworld run fill 381 69 -39 381 70 -39 dirt
execute in minecraft:overworld run setblock 381 71 -39 coarse_dirt
execute in minecraft:overworld run fill 381 72 -39 381 144 -39 air
execute in minecraft:overworld run fill 381 58 -38 381 68 -38 stone
execute in minecraft:overworld run fill 381 69 -38 381 70 -38 dirt
execute in minecraft:overworld run setblock 381 71 -38 coarse_dirt
execute in minecraft:overworld run fill 381 72 -38 381 144 -38 air
execute in minecraft:overworld run fill 381 58 -37 381 67 -37 stone
execute in minecraft:overworld run fill 381 68 -37 381 69 -37 dirt
execute in minecraft:overworld run setblock 381 70 -37 coarse_dirt
execute in minecraft:overworld run fill 381 71 -37 381 144 -37 air
execute in minecraft:overworld run fill 381 58 -36 381 67 -36 stone
execute in minecraft:overworld run fill 381 68 -36 381 69 -36 dirt
execute in minecraft:overworld run setblock 381 70 -36 grass_block
execute in minecraft:overworld run fill 381 71 -36 381 144 -36 air
execute in minecraft:overworld run fill 381 58 -35 381 66 -35 stone
execute in minecraft:overworld run fill 381 67 -35 381 68 -35 dirt
execute in minecraft:overworld run setblock 381 69 -35 coarse_dirt
execute in minecraft:overworld run fill 381 70 -35 381 144 -35 air
execute in minecraft:overworld run fill 381 58 -34 381 66 -34 stone
execute in minecraft:overworld run fill 381 67 -34 381 68 -34 dirt
execute in minecraft:overworld run setblock 381 69 -34 coarse_dirt
execute in minecraft:overworld run fill 381 70 -34 381 144 -34 air
execute in minecraft:overworld run fill 381 58 -33 381 65 -33 stone
execute in minecraft:overworld run fill 381 66 -33 381 67 -33 dirt
execute in minecraft:overworld run setblock 381 68 -33 coarse_dirt
execute in minecraft:overworld run fill 381 69 -33 381 144 -33 air
execute in minecraft:overworld run fill 381 58 -32 381 65 -32 stone
execute in minecraft:overworld run fill 381 66 -32 381 67 -32 dirt
execute in minecraft:overworld run setblock 381 68 -32 coarse_dirt
execute in minecraft:overworld run fill 381 69 -32 381 144 -32 air
execute in minecraft:overworld run fill 381 58 -31 381 65 -31 stone
execute in minecraft:overworld run fill 381 66 -31 381 67 -31 dirt
execute in minecraft:overworld run setblock 381 68 -31 grass_block
execute in minecraft:overworld run fill 381 69 -31 381 144 -31 air
execute in minecraft:overworld run setblock 381 69 -31 grass
execute in minecraft:overworld run fill 381 58 -30 381 65 -30 stone
execute in minecraft:overworld run fill 381 66 -30 381 67 -30 dirt
execute in minecraft:overworld run setblock 381 68 -30 coarse_dirt
execute in minecraft:overworld run fill 381 69 -30 381 144 -30 air
execute in minecraft:overworld run fill 381 58 -29 381 64 -29 stone
execute in minecraft:overworld run fill 381 65 -29 381 66 -29 dirt
execute in minecraft:overworld run setblock 381 67 -29 grass_block
execute in minecraft:overworld run fill 381 68 -29 381 144 -29 air
execute in minecraft:overworld run setblock 381 68 -29 grass
execute in minecraft:overworld run fill 381 58 -28 381 64 -28 stone
execute in minecraft:overworld run fill 381 65 -28 381 66 -28 dirt
execute in minecraft:overworld run setblock 381 67 -28 coarse_dirt
execute in minecraft:overworld run fill 381 68 -28 381 144 -28 air
execute in minecraft:overworld run fill 381 58 -27 381 64 -27 stone
execute in minecraft:overworld run fill 381 65 -27 381 66 -27 dirt
execute in minecraft:overworld run setblock 381 67 -27 grass_block
execute in minecraft:overworld run fill 381 68 -27 381 144 -27 air
execute in minecraft:overworld run fill 381 58 -26 381 63 -26 stone
execute in minecraft:overworld run fill 381 64 -26 381 65 -26 dirt
execute in minecraft:overworld run setblock 381 66 -26 grass_block
execute in minecraft:overworld run fill 381 67 -26 381 144 -26 air
execute in minecraft:overworld run fill 381 58 -25 381 63 -25 stone
execute in minecraft:overworld run fill 381 64 -25 381 65 -25 dirt
execute in minecraft:overworld run setblock 381 66 -25 coarse_dirt
execute in minecraft:overworld run fill 381 67 -25 381 144 -25 air
execute in minecraft:overworld run fill 381 58 -24 381 63 -24 stone
execute in minecraft:overworld run fill 381 64 -24 381 65 -24 dirt
execute in minecraft:overworld run setblock 381 66 -24 coarse_dirt
execute in minecraft:overworld run fill 381 67 -24 381 144 -24 air
execute in minecraft:overworld run fill 381 58 -23 381 62 -23 stone
execute in minecraft:overworld run fill 381 63 -23 381 64 -23 dirt
execute in minecraft:overworld run setblock 381 65 -23 coarse_dirt
execute in minecraft:overworld run fill 381 66 -23 381 144 -23 air
execute in minecraft:overworld run fill 381 58 -22 381 62 -22 stone
execute in minecraft:overworld run fill 381 63 -22 381 64 -22 dirt
execute in minecraft:overworld run setblock 381 65 -22 coarse_dirt
execute in minecraft:overworld run fill 381 66 -22 381 144 -22 air
execute in minecraft:overworld run fill 381 58 -21 381 61 -21 stone
execute in minecraft:overworld run fill 381 62 -21 381 63 -21 dirt
execute in minecraft:overworld run setblock 381 64 -21 coarse_dirt
execute in minecraft:overworld run fill 381 65 -21 381 144 -21 air
execute in minecraft:overworld run fill 381 58 -20 381 61 -20 stone
execute in minecraft:overworld run fill 381 62 -20 381 63 -20 dirt
execute in minecraft:overworld run setblock 381 64 -20 coarse_dirt
execute in minecraft:overworld run fill 381 65 -20 381 144 -20 air
execute in minecraft:overworld run fill 381 58 -19 381 61 -19 stone
execute in minecraft:overworld run fill 381 62 -19 381 63 -19 dirt
execute in minecraft:overworld run setblock 381 64 -19 coarse_dirt
execute in minecraft:overworld run fill 381 65 -19 381 144 -19 air
execute in minecraft:overworld run fill 381 58 -18 381 61 -18 stone
execute in minecraft:overworld run fill 381 62 -18 381 63 -18 dirt
execute in minecraft:overworld run setblock 381 64 -18 coarse_dirt
execute in minecraft:overworld run fill 381 65 -18 381 144 -18 air
execute in minecraft:overworld run fill 381 58 -17 381 61 -17 stone
execute in minecraft:overworld run fill 381 62 -17 381 63 -17 dirt
execute in minecraft:overworld run setblock 381 64 -17 coarse_dirt
execute in minecraft:overworld run fill 381 65 -17 381 144 -17 air
execute in minecraft:overworld run fill 381 58 -16 381 61 -16 stone
execute in minecraft:overworld run fill 381 62 -16 381 63 -16 dirt
execute in minecraft:overworld run setblock 381 64 -16 coarse_dirt
execute in minecraft:overworld run fill 381 65 -16 381 144 -16 air
execute in minecraft:overworld run fill 381 58 -15 381 61 -15 stone
execute in minecraft:overworld run fill 381 62 -15 381 63 -15 dirt
execute in minecraft:overworld run setblock 381 64 -15 grass_block
execute in minecraft:overworld run fill 381 65 -15 381 144 -15 air
execute in minecraft:overworld run fill 381 58 -14 381 61 -14 stone
execute in minecraft:overworld run fill 381 62 -14 381 63 -14 dirt
execute in minecraft:overworld run setblock 381 64 -14 coarse_dirt
execute in minecraft:overworld run fill 381 65 -14 381 144 -14 air
execute in minecraft:overworld run fill 381 58 -13 381 61 -13 stone
execute in minecraft:overworld run fill 381 62 -13 381 63 -13 dirt
execute in minecraft:overworld run setblock 381 64 -13 coarse_dirt
execute in minecraft:overworld run fill 381 65 -13 381 144 -13 air
execute in minecraft:overworld run fill 381 58 -12 381 61 -12 stone
execute in minecraft:overworld run fill 381 62 -12 381 63 -12 dirt
execute in minecraft:overworld run setblock 381 64 -12 coarse_dirt
execute in minecraft:overworld run fill 381 65 -12 381 144 -12 air
execute in minecraft:overworld run fill 381 58 -11 381 62 -11 stone
execute in minecraft:overworld run fill 381 63 -11 381 64 -11 dirt
execute in minecraft:overworld run setblock 381 65 -11 grass_block
execute in minecraft:overworld run fill 381 66 -11 381 144 -11 air
execute in minecraft:overworld run fill 381 58 -10 381 62 -10 stone
execute in minecraft:overworld run fill 381 63 -10 381 64 -10 dirt
execute in minecraft:overworld run setblock 381 65 -10 grass_block
execute in minecraft:overworld run fill 381 66 -10 381 144 -10 air
execute in minecraft:overworld run fill 381 58 -9 381 62 -9 stone
execute in minecraft:overworld run fill 381 63 -9 381 64 -9 dirt
execute in minecraft:overworld run setblock 381 65 -9 grass_block
execute in minecraft:overworld run fill 381 66 -9 381 144 -9 air
execute in minecraft:overworld run fill 381 58 -8 381 62 -8 stone
execute in minecraft:overworld run fill 381 63 -8 381 64 -8 dirt
execute in minecraft:overworld run setblock 381 65 -8 coarse_dirt
execute in minecraft:overworld run fill 381 66 -8 381 144 -8 air
execute in minecraft:overworld run setblock 381 66 -8 grass
execute in minecraft:overworld run fill 381 58 -7 381 63 -7 stone
execute in minecraft:overworld run fill 381 64 -7 381 65 -7 dirt
execute in minecraft:overworld run setblock 381 66 -7 grass_block
execute in minecraft:overworld run fill 381 67 -7 381 144 -7 air
execute in minecraft:overworld run fill 381 58 -6 381 63 -6 stone
execute in minecraft:overworld run fill 381 64 -6 381 65 -6 dirt
execute in minecraft:overworld run setblock 381 66 -6 coarse_dirt
execute in minecraft:overworld run fill 381 67 -6 381 144 -6 air
execute in minecraft:overworld run fill 381 58 -5 381 63 -5 stone
execute in minecraft:overworld run fill 381 64 -5 381 65 -5 dirt
execute in minecraft:overworld run setblock 381 66 -5 coarse_dirt
execute in minecraft:overworld run fill 381 67 -5 381 144 -5 air
execute in minecraft:overworld run fill 381 58 -4 381 63 -4 stone
execute in minecraft:overworld run fill 381 64 -4 381 65 -4 dirt
execute in minecraft:overworld run setblock 381 66 -4 coarse_dirt
execute in minecraft:overworld run fill 381 67 -4 381 144 -4 air
execute in minecraft:overworld run fill 381 58 -3 381 64 -3 stone
execute in minecraft:overworld run fill 381 65 -3 381 66 -3 dirt
execute in minecraft:overworld run setblock 381 67 -3 grass_block
execute in minecraft:overworld run fill 381 68 -3 381 144 -3 air
execute in minecraft:overworld run fill 381 58 -2 381 64 -2 stone
execute in minecraft:overworld run fill 381 65 -2 381 66 -2 dirt
execute in minecraft:overworld run setblock 381 67 -2 coarse_dirt
execute in minecraft:overworld run fill 381 68 -2 381 144 -2 air
execute in minecraft:overworld run setblock 381 68 -2 grass
execute in minecraft:overworld run fill 381 58 -1 381 64 -1 stone
execute in minecraft:overworld run fill 381 65 -1 381 66 -1 dirt
execute in minecraft:overworld run setblock 381 67 -1 coarse_dirt
execute in minecraft:overworld run fill 381 68 -1 381 144 -1 air
execute in minecraft:overworld run fill 381 58 0 381 64 0 stone
execute in minecraft:overworld run fill 381 65 0 381 66 0 dirt
execute in minecraft:overworld run setblock 381 67 0 coarse_dirt
execute in minecraft:overworld run fill 381 68 0 381 144 0 air
execute in minecraft:overworld run fill 381 58 1 381 64 1 stone
execute in minecraft:overworld run fill 381 65 1 381 66 1 dirt
execute in minecraft:overworld run setblock 381 67 1 coarse_dirt
execute in minecraft:overworld run fill 381 68 1 381 144 1 air
execute in minecraft:overworld run fill 381 58 2 381 64 2 stone
execute in minecraft:overworld run fill 381 65 2 381 66 2 dirt
execute in minecraft:overworld run setblock 381 67 2 grass_block
execute in minecraft:overworld run fill 381 68 2 381 144 2 air
execute in minecraft:overworld run fill 381 58 3 381 64 3 stone
execute in minecraft:overworld run fill 381 65 3 381 66 3 dirt
execute in minecraft:overworld run setblock 381 67 3 coarse_dirt
execute in minecraft:overworld run fill 381 68 3 381 144 3 air
execute in minecraft:overworld run fill 381 58 4 381 64 4 stone
execute in minecraft:overworld run fill 381 65 4 381 66 4 dirt
execute in minecraft:overworld run setblock 381 67 4 coarse_dirt
execute in minecraft:overworld run fill 381 68 4 381 144 4 air
execute in minecraft:overworld run fill 381 58 5 381 64 5 stone
execute in minecraft:overworld run fill 381 65 5 381 66 5 dirt
execute in minecraft:overworld run setblock 381 67 5 grass_block
execute in minecraft:overworld run fill 381 68 5 381 144 5 air
execute in minecraft:overworld run setblock 381 68 5 grass
execute in minecraft:overworld run fill 381 58 6 381 64 6 stone
execute in minecraft:overworld run fill 381 65 6 381 66 6 dirt
execute in minecraft:overworld run setblock 381 67 6 grass_block
execute in minecraft:overworld run fill 381 68 6 381 144 6 air
execute in minecraft:overworld run fill 381 58 7 381 64 7 stone
execute in minecraft:overworld run fill 381 65 7 381 66 7 dirt
execute in minecraft:overworld run setblock 381 67 7 coarse_dirt
execute in minecraft:overworld run fill 381 68 7 381 144 7 air
execute in minecraft:overworld run fill 381 58 8 381 64 8 stone
execute in minecraft:overworld run fill 381 65 8 381 66 8 dirt
execute in minecraft:overworld run setblock 381 67 8 grass_block
execute in minecraft:overworld run fill 381 68 8 381 144 8 air
execute in minecraft:overworld run fill 381 58 9 381 64 9 stone
execute in minecraft:overworld run fill 381 65 9 381 66 9 dirt
execute in minecraft:overworld run setblock 381 67 9 coarse_dirt
execute in minecraft:overworld run fill 381 68 9 381 144 9 air
execute in minecraft:overworld run fill 381 58 10 381 65 10 stone
execute in minecraft:overworld run fill 381 66 10 381 67 10 dirt
execute in minecraft:overworld run setblock 381 68 10 coarse_dirt
execute in minecraft:overworld run fill 381 69 10 381 144 10 air
execute in minecraft:overworld run fill 381 58 11 381 65 11 stone
schedule function blade_gallery:random/battlefield/part_70 1t replace
