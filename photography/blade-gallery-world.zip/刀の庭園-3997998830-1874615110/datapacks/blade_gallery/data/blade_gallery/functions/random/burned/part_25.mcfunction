execute in minecraft:overworld run fill 224 68 -13 224 144 -13 air
execute in minecraft:overworld run fill 224 58 -12 224 64 -12 stone
execute in minecraft:overworld run fill 224 65 -12 224 66 -12 dirt
execute in minecraft:overworld run setblock 224 67 -12 coarse_dirt
execute in minecraft:overworld run fill 224 68 -12 224 144 -12 air
execute in minecraft:overworld run fill 224 58 -11 224 64 -11 stone
execute in minecraft:overworld run fill 224 65 -11 224 66 -11 dirt
execute in minecraft:overworld run setblock 224 67 -11 coarse_dirt
execute in minecraft:overworld run fill 224 68 -11 224 144 -11 air
execute in minecraft:overworld run setblock 224 68 -11 grass
execute in minecraft:overworld run fill 224 58 -10 224 64 -10 stone
execute in minecraft:overworld run fill 224 65 -10 224 66 -10 dirt
execute in minecraft:overworld run setblock 224 67 -10 coarse_dirt
execute in minecraft:overworld run fill 224 68 -10 224 144 -10 air
execute in minecraft:overworld run fill 224 58 -9 224 64 -9 stone
execute in minecraft:overworld run fill 224 65 -9 224 66 -9 dirt
execute in minecraft:overworld run setblock 224 67 -9 coarse_dirt
execute in minecraft:overworld run fill 224 68 -9 224 144 -9 air
execute in minecraft:overworld run fill 224 58 -8 224 65 -8 stone
execute in minecraft:overworld run fill 224 66 -8 224 67 -8 dirt
execute in minecraft:overworld run setblock 224 68 -8 grass_block
execute in minecraft:overworld run fill 224 69 -8 224 144 -8 air
execute in minecraft:overworld run fill 224 58 -7 224 65 -7 stone
execute in minecraft:overworld run fill 224 66 -7 224 67 -7 dirt
execute in minecraft:overworld run setblock 224 68 -7 coarse_dirt
execute in minecraft:overworld run fill 224 69 -7 224 144 -7 air
execute in minecraft:overworld run fill 224 58 -6 224 66 -6 stone
execute in minecraft:overworld run fill 224 67 -6 224 68 -6 dirt
execute in minecraft:overworld run setblock 224 69 -6 coarse_dirt
execute in minecraft:overworld run fill 224 70 -6 224 144 -6 air
execute in minecraft:overworld run fill 224 58 -5 224 66 -5 stone
execute in minecraft:overworld run fill 224 67 -5 224 68 -5 dirt
execute in minecraft:overworld run setblock 224 69 -5 coarse_dirt
execute in minecraft:overworld run fill 224 70 -5 224 144 -5 air
execute in minecraft:overworld run setblock 224 70 -5 grass
execute in minecraft:overworld run fill 224 58 -4 224 67 -4 stone
execute in minecraft:overworld run fill 224 68 -4 224 69 -4 dirt
execute in minecraft:overworld run setblock 224 70 -4 grass_block
execute in minecraft:overworld run fill 224 71 -4 224 144 -4 air
execute in minecraft:overworld run fill 224 58 -3 224 67 -3 stone
execute in minecraft:overworld run fill 224 68 -3 224 69 -3 dirt
execute in minecraft:overworld run setblock 224 70 -3 coarse_dirt
execute in minecraft:overworld run fill 224 71 -3 224 144 -3 air
execute in minecraft:overworld run fill 224 58 -2 224 67 -2 stone
execute in minecraft:overworld run fill 224 68 -2 224 69 -2 dirt
execute in minecraft:overworld run setblock 224 70 -2 coarse_dirt
execute in minecraft:overworld run fill 224 71 -2 224 144 -2 air
execute in minecraft:overworld run fill 224 58 -1 224 68 -1 stone
execute in minecraft:overworld run fill 224 69 -1 224 70 -1 dirt
execute in minecraft:overworld run setblock 224 71 -1 grass_block
execute in minecraft:overworld run fill 224 72 -1 224 144 -1 air
execute in minecraft:overworld run fill 224 58 0 224 68 0 stone
execute in minecraft:overworld run fill 224 69 0 224 70 0 dirt
execute in minecraft:overworld run setblock 224 71 0 coarse_dirt
execute in minecraft:overworld run fill 224 72 0 224 144 0 air
execute in minecraft:overworld run fill 224 58 1 224 68 1 stone
execute in minecraft:overworld run fill 224 69 1 224 70 1 dirt
execute in minecraft:overworld run setblock 224 71 1 coarse_dirt
execute in minecraft:overworld run fill 224 72 1 224 144 1 air
execute in minecraft:overworld run fill 224 58 2 224 68 2 stone
execute in minecraft:overworld run fill 224 69 2 224 70 2 dirt
execute in minecraft:overworld run setblock 224 71 2 coarse_dirt
execute in minecraft:overworld run fill 224 72 2 224 144 2 air
execute in minecraft:overworld run fill 224 58 3 224 67 3 stone
execute in minecraft:overworld run fill 224 68 3 224 69 3 dirt
execute in minecraft:overworld run setblock 224 70 3 coarse_dirt
execute in minecraft:overworld run fill 224 71 3 224 144 3 air
execute in minecraft:overworld run fill 224 58 4 224 67 4 stone
execute in minecraft:overworld run fill 224 68 4 224 69 4 dirt
execute in minecraft:overworld run setblock 224 70 4 coarse_dirt
execute in minecraft:overworld run fill 224 71 4 224 144 4 air
execute in minecraft:overworld run fill 224 58 5 224 67 5 stone
execute in minecraft:overworld run fill 224 68 5 224 69 5 dirt
execute in minecraft:overworld run setblock 224 70 5 coarse_dirt
execute in minecraft:overworld run fill 224 71 5 224 144 5 air
execute in minecraft:overworld run fill 224 58 6 224 66 6 stone
execute in minecraft:overworld run fill 224 67 6 224 68 6 dirt
execute in minecraft:overworld run setblock 224 69 6 coarse_dirt
execute in minecraft:overworld run fill 224 70 6 224 144 6 air
execute in minecraft:overworld run fill 224 58 7 224 66 7 stone
execute in minecraft:overworld run fill 224 67 7 224 68 7 dirt
execute in minecraft:overworld run setblock 224 69 7 grass_block
execute in minecraft:overworld run fill 224 70 7 224 144 7 air
execute in minecraft:overworld run setblock 224 70 7 grass
execute in minecraft:overworld run fill 224 58 8 224 66 8 stone
execute in minecraft:overworld run fill 224 67 8 224 68 8 dirt
execute in minecraft:overworld run setblock 224 69 8 coarse_dirt
execute in minecraft:overworld run fill 224 70 8 224 144 8 air
execute in minecraft:overworld run fill 224 58 9 224 66 9 stone
execute in minecraft:overworld run fill 224 67 9 224 68 9 dirt
execute in minecraft:overworld run setblock 224 69 9 coarse_dirt
execute in minecraft:overworld run fill 224 70 9 224 144 9 air
execute in minecraft:overworld run fill 224 58 10 224 67 10 stone
execute in minecraft:overworld run fill 224 68 10 224 69 10 dirt
execute in minecraft:overworld run setblock 224 70 10 coarse_dirt
execute in minecraft:overworld run fill 224 71 10 224 144 10 air
execute in minecraft:overworld run fill 224 58 11 224 67 11 stone
execute in minecraft:overworld run fill 224 68 11 224 69 11 dirt
execute in minecraft:overworld run setblock 224 70 11 grass_block
execute in minecraft:overworld run fill 224 71 11 224 144 11 air
execute in minecraft:overworld run fill 224 58 12 224 67 12 stone
execute in minecraft:overworld run fill 224 68 12 224 69 12 dirt
execute in minecraft:overworld run setblock 224 70 12 grass_block
execute in minecraft:overworld run fill 224 71 12 224 144 12 air
execute in minecraft:overworld run fill 224 58 13 224 68 13 stone
execute in minecraft:overworld run fill 224 69 13 224 70 13 dirt
execute in minecraft:overworld run setblock 224 71 13 grass_block
execute in minecraft:overworld run fill 224 72 13 224 144 13 air
execute in minecraft:overworld run fill 224 58 14 224 68 14 stone
execute in minecraft:overworld run fill 224 69 14 224 70 14 dirt
execute in minecraft:overworld run setblock 224 71 14 coarse_dirt
execute in minecraft:overworld run fill 224 72 14 224 144 14 air
execute in minecraft:overworld run fill 224 58 15 224 69 15 stone
execute in minecraft:overworld run fill 224 70 15 224 71 15 dirt
execute in minecraft:overworld run setblock 224 72 15 coarse_dirt
execute in minecraft:overworld run fill 224 73 15 224 144 15 air
execute in minecraft:overworld run fill 224 58 16 224 69 16 stone
execute in minecraft:overworld run fill 224 70 16 224 71 16 dirt
execute in minecraft:overworld run setblock 224 72 16 coarse_dirt
execute in minecraft:overworld run fill 224 73 16 224 144 16 air
execute in minecraft:overworld run fill 224 58 17 224 69 17 stone
execute in minecraft:overworld run fill 224 70 17 224 71 17 dirt
execute in minecraft:overworld run setblock 224 72 17 grass_block
execute in minecraft:overworld run fill 224 73 17 224 144 17 air
execute in minecraft:overworld run fill 224 58 18 224 70 18 stone
execute in minecraft:overworld run fill 224 71 18 224 72 18 dirt
execute in minecraft:overworld run setblock 224 73 18 coarse_dirt
execute in minecraft:overworld run fill 224 74 18 224 144 18 air
execute in minecraft:overworld run fill 224 58 19 224 70 19 stone
execute in minecraft:overworld run fill 224 71 19 224 72 19 dirt
execute in minecraft:overworld run setblock 224 73 19 grass_block
execute in minecraft:overworld run fill 224 74 19 224 144 19 air
execute in minecraft:overworld run fill 224 58 20 224 70 20 stone
execute in minecraft:overworld run fill 224 71 20 224 72 20 dirt
execute in minecraft:overworld run setblock 224 73 20 coarse_dirt
execute in minecraft:overworld run fill 224 74 20 224 144 20 air
execute in minecraft:overworld run fill 224 58 21 224 70 21 stone
execute in minecraft:overworld run fill 224 71 21 224 72 21 dirt
execute in minecraft:overworld run setblock 224 73 21 coarse_dirt
execute in minecraft:overworld run fill 224 74 21 224 144 21 air
execute in minecraft:overworld run fill 224 58 22 224 70 22 stone
execute in minecraft:overworld run fill 224 71 22 224 72 22 dirt
execute in minecraft:overworld run setblock 224 73 22 grass_block
execute in minecraft:overworld run fill 224 74 22 224 144 22 air
execute in minecraft:overworld run fill 224 58 23 224 70 23 stone
execute in minecraft:overworld run fill 224 71 23 224 72 23 dirt
execute in minecraft:overworld run setblock 224 73 23 coarse_dirt
execute in minecraft:overworld run fill 224 74 23 224 144 23 air
execute in minecraft:overworld run fill 224 58 24 224 70 24 stone
execute in minecraft:overworld run fill 224 71 24 224 72 24 dirt
execute in minecraft:overworld run setblock 224 73 24 coarse_dirt
execute in minecraft:overworld run fill 224 74 24 224 144 24 air
execute in minecraft:overworld run fill 224 58 25 224 70 25 stone
execute in minecraft:overworld run fill 224 71 25 224 72 25 dirt
execute in minecraft:overworld run setblock 224 73 25 coarse_dirt
execute in minecraft:overworld run fill 224 74 25 224 144 25 air
execute in minecraft:overworld run fill 224 58 26 224 70 26 stone
execute in minecraft:overworld run fill 224 71 26 224 72 26 dirt
execute in minecraft:overworld run setblock 224 73 26 coarse_dirt
execute in minecraft:overworld run fill 224 74 26 224 144 26 air
execute in minecraft:overworld run fill 224 58 27 224 70 27 stone
execute in minecraft:overworld run fill 224 71 27 224 72 27 dirt
execute in minecraft:overworld run setblock 224 73 27 coarse_dirt
execute in minecraft:overworld run fill 224 74 27 224 144 27 air
execute in minecraft:overworld run fill 224 58 28 224 70 28 stone
execute in minecraft:overworld run fill 224 71 28 224 72 28 dirt
execute in minecraft:overworld run setblock 224 73 28 coarse_dirt
execute in minecraft:overworld run fill 224 74 28 224 144 28 air
execute in minecraft:overworld run fill 224 58 29 224 70 29 stone
execute in minecraft:overworld run fill 224 71 29 224 72 29 dirt
execute in minecraft:overworld run setblock 224 73 29 grass_block
execute in minecraft:overworld run fill 224 74 29 224 144 29 air
execute in minecraft:overworld run fill 224 58 30 224 70 30 stone
execute in minecraft:overworld run fill 224 71 30 224 72 30 dirt
execute in minecraft:overworld run setblock 224 73 30 grass_block
execute in minecraft:overworld run fill 224 74 30 224 144 30 air
execute in minecraft:overworld run fill 224 58 31 224 70 31 stone
execute in minecraft:overworld run fill 224 71 31 224 72 31 dirt
execute in minecraft:overworld run setblock 224 73 31 grass_block
execute in minecraft:overworld run fill 224 74 31 224 144 31 air
execute in minecraft:overworld run fill 224 58 32 224 70 32 stone
execute in minecraft:overworld run fill 224 71 32 224 72 32 dirt
execute in minecraft:overworld run setblock 224 73 32 grass_block
execute in minecraft:overworld run fill 224 74 32 224 144 32 air
execute in minecraft:overworld run fill 224 58 33 224 70 33 stone
execute in minecraft:overworld run fill 224 71 33 224 72 33 dirt
execute in minecraft:overworld run setblock 224 73 33 coarse_dirt
execute in minecraft:overworld run fill 224 74 33 224 144 33 air
execute in minecraft:overworld run fill 224 58 34 224 69 34 stone
execute in minecraft:overworld run fill 224 70 34 224 71 34 dirt
execute in minecraft:overworld run setblock 224 72 34 coarse_dirt
execute in minecraft:overworld run fill 224 73 34 224 144 34 air
execute in minecraft:overworld run fill 224 58 35 224 69 35 stone
execute in minecraft:overworld run fill 224 70 35 224 71 35 dirt
execute in minecraft:overworld run setblock 224 72 35 coarse_dirt
execute in minecraft:overworld run fill 224 73 35 224 144 35 air
execute in minecraft:overworld run fill 224 58 36 224 69 36 stone
execute in minecraft:overworld run fill 224 70 36 224 71 36 dirt
execute in minecraft:overworld run setblock 224 72 36 coarse_dirt
execute in minecraft:overworld run fill 224 73 36 224 144 36 air
execute in minecraft:overworld run fill 224 58 37 224 68 37 stone
execute in minecraft:overworld run fill 224 69 37 224 70 37 dirt
execute in minecraft:overworld run setblock 224 71 37 grass_block
execute in minecraft:overworld run fill 224 72 37 224 144 37 air
execute in minecraft:overworld run fill 224 58 38 224 68 38 stone
execute in minecraft:overworld run fill 224 69 38 224 70 38 dirt
execute in minecraft:overworld run setblock 224 71 38 coarse_dirt
execute in minecraft:overworld run fill 224 72 38 224 144 38 air
execute in minecraft:overworld run fill 224 58 39 224 67 39 stone
execute in minecraft:overworld run fill 224 68 39 224 69 39 dirt
execute in minecraft:overworld run setblock 224 70 39 grass_block
execute in minecraft:overworld run fill 224 71 39 224 144 39 air
execute in minecraft:overworld run fill 224 58 40 224 66 40 stone
execute in minecraft:overworld run fill 224 67 40 224 68 40 dirt
execute in minecraft:overworld run setblock 224 69 40 coarse_dirt
execute in minecraft:overworld run fill 224 70 40 224 144 40 air
execute in minecraft:overworld run setblock 224 70 40 grass
execute in minecraft:overworld run fill 224 58 41 224 65 41 stone
execute in minecraft:overworld run fill 224 66 41 224 67 41 dirt
execute in minecraft:overworld run setblock 224 68 41 grass_block
execute in minecraft:overworld run fill 224 69 41 224 144 41 air
execute in minecraft:overworld run fill 224 58 42 224 64 42 stone
execute in minecraft:overworld run fill 224 65 42 224 66 42 dirt
execute in minecraft:overworld run setblock 224 67 42 coarse_dirt
execute in minecraft:overworld run fill 224 68 42 224 144 42 air
execute in minecraft:overworld run fill 224 58 43 224 63 43 stone
execute in minecraft:overworld run fill 224 64 43 224 65 43 dirt
execute in minecraft:overworld run setblock 224 66 43 coarse_dirt
execute in minecraft:overworld run fill 224 67 43 224 144 43 air
execute in minecraft:overworld run fill 224 58 44 224 62 44 stone
execute in minecraft:overworld run fill 224 63 44 224 64 44 dirt
execute in minecraft:overworld run setblock 224 65 44 coarse_dirt
execute in minecraft:overworld run fill 224 66 44 224 144 44 air
execute in minecraft:overworld run fill 224 58 45 224 62 45 stone
execute in minecraft:overworld run fill 224 63 45 224 64 45 dirt
execute in minecraft:overworld run setblock 224 65 45 coarse_dirt
execute in minecraft:overworld run fill 224 66 45 224 144 45 air
execute in minecraft:overworld run fill 224 58 46 224 61 46 stone
execute in minecraft:overworld run fill 224 62 46 224 63 46 dirt
execute in minecraft:overworld run setblock 224 64 46 coarse_dirt
execute in minecraft:overworld run fill 224 65 46 224 144 46 air
execute in minecraft:overworld run fill 224 58 47 224 61 47 stone
execute in minecraft:overworld run fill 224 62 47 224 63 47 dirt
execute in minecraft:overworld run setblock 224 64 47 grass_block
execute in minecraft:overworld run fill 224 65 47 224 144 47 air
execute in minecraft:overworld run fill 225 58 -48 225 61 -48 stone
execute in minecraft:overworld run fill 225 62 -48 225 63 -48 dirt
execute in minecraft:overworld run setblock 225 64 -48 coarse_dirt
execute in minecraft:overworld run fill 225 65 -48 225 144 -48 air
execute in minecraft:overworld run fill 225 58 -47 225 63 -47 stone
execute in minecraft:overworld run fill 225 64 -47 225 65 -47 dirt
execute in minecraft:overworld run setblock 225 66 -47 coarse_dirt
execute in minecraft:overworld run fill 225 67 -47 225 144 -47 air
execute in minecraft:overworld run fill 225 58 -46 225 64 -46 stone
execute in minecraft:overworld run fill 225 65 -46 225 66 -46 dirt
execute in minecraft:overworld run setblock 225 67 -46 grass_block
schedule function blade_gallery:random/burned/part_26 1t replace
