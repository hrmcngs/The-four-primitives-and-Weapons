execute in minecraft:overworld run fill 259 58 -1 259 56 -1 stone
execute in minecraft:overworld run fill 259 57 -1 259 58 -1 dirt
execute in minecraft:overworld run setblock 259 59 -1 gravel
execute in minecraft:overworld run fill 259 60 -1 259 144 -1 air
execute in minecraft:overworld run fill 259 60 -1 259 64 -1 water
execute in minecraft:overworld run fill 259 58 0 259 57 0 stone
execute in minecraft:overworld run fill 259 58 0 259 59 0 dirt
execute in minecraft:overworld run setblock 259 60 0 gravel
execute in minecraft:overworld run fill 259 61 0 259 144 0 air
execute in minecraft:overworld run fill 259 61 0 259 64 0 water
execute in minecraft:overworld run fill 259 58 1 259 57 1 stone
execute in minecraft:overworld run fill 259 58 1 259 59 1 dirt
execute in minecraft:overworld run setblock 259 60 1 gravel
execute in minecraft:overworld run fill 259 61 1 259 144 1 air
execute in minecraft:overworld run fill 259 61 1 259 64 1 water
execute in minecraft:overworld run fill 259 58 2 259 57 2 stone
execute in minecraft:overworld run fill 259 58 2 259 59 2 dirt
execute in minecraft:overworld run setblock 259 60 2 gravel
execute in minecraft:overworld run fill 259 61 2 259 144 2 air
execute in minecraft:overworld run fill 259 61 2 259 64 2 water
execute in minecraft:overworld run fill 259 58 3 259 57 3 stone
execute in minecraft:overworld run fill 259 58 3 259 59 3 dirt
execute in minecraft:overworld run setblock 259 60 3 gravel
execute in minecraft:overworld run fill 259 61 3 259 144 3 air
execute in minecraft:overworld run fill 259 61 3 259 64 3 water
execute in minecraft:overworld run fill 259 58 4 259 58 4 stone
execute in minecraft:overworld run fill 259 59 4 259 60 4 dirt
execute in minecraft:overworld run setblock 259 61 4 gravel
execute in minecraft:overworld run fill 259 62 4 259 144 4 air
execute in minecraft:overworld run fill 259 62 4 259 64 4 water
execute in minecraft:overworld run fill 259 58 5 259 58 5 stone
execute in minecraft:overworld run fill 259 59 5 259 60 5 dirt
execute in minecraft:overworld run setblock 259 61 5 gravel
execute in minecraft:overworld run fill 259 62 5 259 144 5 air
execute in minecraft:overworld run fill 259 62 5 259 64 5 water
execute in minecraft:overworld run fill 259 58 6 259 58 6 stone
execute in minecraft:overworld run fill 259 59 6 259 60 6 dirt
execute in minecraft:overworld run setblock 259 61 6 gravel
execute in minecraft:overworld run fill 259 62 6 259 144 6 air
execute in minecraft:overworld run fill 259 62 6 259 64 6 water
execute in minecraft:overworld run fill 259 58 7 259 58 7 stone
execute in minecraft:overworld run fill 259 59 7 259 60 7 dirt
execute in minecraft:overworld run setblock 259 61 7 gravel
execute in minecraft:overworld run fill 259 62 7 259 144 7 air
execute in minecraft:overworld run fill 259 62 7 259 64 7 water
execute in minecraft:overworld run fill 259 58 8 259 59 8 stone
execute in minecraft:overworld run fill 259 60 8 259 61 8 dirt
execute in minecraft:overworld run setblock 259 62 8 gravel
execute in minecraft:overworld run fill 259 63 8 259 144 8 air
execute in minecraft:overworld run fill 259 63 8 259 64 8 water
execute in minecraft:overworld run fill 259 58 9 259 59 9 stone
execute in minecraft:overworld run fill 259 60 9 259 61 9 dirt
execute in minecraft:overworld run setblock 259 62 9 gravel
execute in minecraft:overworld run fill 259 63 9 259 144 9 air
execute in minecraft:overworld run fill 259 63 9 259 64 9 water
execute in minecraft:overworld run fill 259 58 10 259 59 10 stone
execute in minecraft:overworld run fill 259 60 10 259 61 10 dirt
execute in minecraft:overworld run setblock 259 62 10 gravel
execute in minecraft:overworld run fill 259 63 10 259 144 10 air
execute in minecraft:overworld run fill 259 63 10 259 64 10 water
execute in minecraft:overworld run fill 259 58 11 259 59 11 stone
execute in minecraft:overworld run fill 259 60 11 259 61 11 dirt
execute in minecraft:overworld run setblock 259 62 11 gravel
execute in minecraft:overworld run fill 259 63 11 259 144 11 air
execute in minecraft:overworld run fill 259 63 11 259 64 11 water
execute in minecraft:overworld run fill 259 58 12 259 60 12 stone
execute in minecraft:overworld run fill 259 61 12 259 62 12 dirt
execute in minecraft:overworld run setblock 259 63 12 gravel
execute in minecraft:overworld run fill 259 64 12 259 144 12 air
execute in minecraft:overworld run fill 259 64 12 259 64 12 water
execute in minecraft:overworld run fill 259 58 13 259 60 13 stone
execute in minecraft:overworld run fill 259 61 13 259 62 13 dirt
execute in minecraft:overworld run setblock 259 63 13 gravel
execute in minecraft:overworld run fill 259 64 13 259 144 13 air
execute in minecraft:overworld run fill 259 64 13 259 64 13 water
execute in minecraft:overworld run fill 259 58 14 259 61 14 stone
execute in minecraft:overworld run fill 259 62 14 259 63 14 dirt
execute in minecraft:overworld run setblock 259 64 14 grass_block
execute in minecraft:overworld run fill 259 65 14 259 144 14 air
execute in minecraft:overworld run fill 259 58 15 259 61 15 stone
execute in minecraft:overworld run fill 259 62 15 259 63 15 dirt
execute in minecraft:overworld run setblock 259 64 15 coarse_dirt
execute in minecraft:overworld run fill 259 65 15 259 144 15 air
execute in minecraft:overworld run fill 259 58 16 259 61 16 stone
execute in minecraft:overworld run fill 259 62 16 259 63 16 dirt
execute in minecraft:overworld run setblock 259 64 16 coarse_dirt
execute in minecraft:overworld run fill 259 65 16 259 144 16 air
execute in minecraft:overworld run fill 259 58 17 259 62 17 stone
execute in minecraft:overworld run fill 259 63 17 259 64 17 dirt
execute in minecraft:overworld run setblock 259 65 17 coarse_dirt
execute in minecraft:overworld run fill 259 66 17 259 144 17 air
execute in minecraft:overworld run fill 259 58 18 259 62 18 stone
execute in minecraft:overworld run fill 259 63 18 259 64 18 dirt
execute in minecraft:overworld run setblock 259 65 18 coarse_dirt
execute in minecraft:overworld run fill 259 66 18 259 144 18 air
execute in minecraft:overworld run fill 259 58 19 259 62 19 stone
execute in minecraft:overworld run fill 259 63 19 259 64 19 dirt
execute in minecraft:overworld run setblock 259 65 19 coarse_dirt
execute in minecraft:overworld run fill 259 66 19 259 144 19 air
execute in minecraft:overworld run fill 259 58 20 259 62 20 stone
execute in minecraft:overworld run fill 259 63 20 259 64 20 dirt
execute in minecraft:overworld run setblock 259 65 20 coarse_dirt
execute in minecraft:overworld run fill 259 66 20 259 144 20 air
execute in minecraft:overworld run fill 259 58 21 259 61 21 stone
execute in minecraft:overworld run fill 259 62 21 259 63 21 dirt
execute in minecraft:overworld run setblock 259 64 21 grass_block
execute in minecraft:overworld run fill 259 65 21 259 144 21 air
execute in minecraft:overworld run fill 259 58 22 259 61 22 stone
execute in minecraft:overworld run fill 259 62 22 259 63 22 dirt
execute in minecraft:overworld run setblock 259 64 22 coarse_dirt
execute in minecraft:overworld run fill 259 65 22 259 144 22 air
execute in minecraft:overworld run fill 259 58 23 259 61 23 stone
execute in minecraft:overworld run fill 259 62 23 259 63 23 dirt
execute in minecraft:overworld run setblock 259 64 23 coarse_dirt
execute in minecraft:overworld run fill 259 65 23 259 144 23 air
execute in minecraft:overworld run fill 259 58 24 259 61 24 stone
execute in minecraft:overworld run fill 259 62 24 259 63 24 dirt
execute in minecraft:overworld run setblock 259 64 24 coarse_dirt
execute in minecraft:overworld run fill 259 65 24 259 144 24 air
execute in minecraft:overworld run fill 259 58 25 259 60 25 stone
execute in minecraft:overworld run fill 259 61 25 259 62 25 dirt
execute in minecraft:overworld run setblock 259 63 25 gravel
execute in minecraft:overworld run fill 259 64 25 259 144 25 air
execute in minecraft:overworld run fill 259 64 25 259 64 25 water
execute in minecraft:overworld run fill 259 58 26 259 60 26 stone
execute in minecraft:overworld run fill 259 61 26 259 62 26 dirt
execute in minecraft:overworld run setblock 259 63 26 gravel
execute in minecraft:overworld run fill 259 64 26 259 144 26 air
execute in minecraft:overworld run fill 259 64 26 259 64 26 water
execute in minecraft:overworld run fill 259 58 27 259 60 27 stone
execute in minecraft:overworld run fill 259 61 27 259 62 27 dirt
execute in minecraft:overworld run setblock 259 63 27 gravel
execute in minecraft:overworld run fill 259 64 27 259 144 27 air
execute in minecraft:overworld run fill 259 64 27 259 64 27 water
execute in minecraft:overworld run fill 259 58 28 259 60 28 stone
execute in minecraft:overworld run fill 259 61 28 259 62 28 dirt
execute in minecraft:overworld run setblock 259 63 28 gravel
execute in minecraft:overworld run fill 259 64 28 259 144 28 air
execute in minecraft:overworld run fill 259 64 28 259 64 28 water
execute in minecraft:overworld run fill 259 58 29 259 59 29 stone
execute in minecraft:overworld run fill 259 60 29 259 61 29 dirt
execute in minecraft:overworld run setblock 259 62 29 gravel
execute in minecraft:overworld run fill 259 63 29 259 144 29 air
execute in minecraft:overworld run fill 259 63 29 259 64 29 water
execute in minecraft:overworld run fill 259 58 30 259 59 30 stone
execute in minecraft:overworld run fill 259 60 30 259 61 30 dirt
execute in minecraft:overworld run setblock 259 62 30 gravel
execute in minecraft:overworld run fill 259 63 30 259 144 30 air
execute in minecraft:overworld run fill 259 63 30 259 64 30 water
execute in minecraft:overworld run fill 259 58 31 259 58 31 stone
execute in minecraft:overworld run fill 259 59 31 259 60 31 dirt
execute in minecraft:overworld run setblock 259 61 31 gravel
execute in minecraft:overworld run fill 259 62 31 259 144 31 air
execute in minecraft:overworld run fill 259 62 31 259 64 31 water
execute in minecraft:overworld run fill 259 58 32 259 58 32 stone
execute in minecraft:overworld run fill 259 59 32 259 60 32 dirt
execute in minecraft:overworld run setblock 259 61 32 gravel
execute in minecraft:overworld run fill 259 62 32 259 144 32 air
execute in minecraft:overworld run fill 259 62 32 259 64 32 water
execute in minecraft:overworld run fill 259 58 33 259 57 33 stone
execute in minecraft:overworld run fill 259 58 33 259 59 33 dirt
execute in minecraft:overworld run setblock 259 60 33 gravel
execute in minecraft:overworld run fill 259 61 33 259 144 33 air
execute in minecraft:overworld run fill 259 61 33 259 64 33 water
execute in minecraft:overworld run fill 259 58 34 259 57 34 stone
execute in minecraft:overworld run fill 259 58 34 259 59 34 dirt
execute in minecraft:overworld run setblock 259 60 34 gravel
execute in minecraft:overworld run fill 259 61 34 259 144 34 air
execute in minecraft:overworld run fill 259 61 34 259 64 34 water
execute in minecraft:overworld run fill 259 58 35 259 57 35 stone
execute in minecraft:overworld run fill 259 58 35 259 59 35 dirt
execute in minecraft:overworld run setblock 259 60 35 gravel
execute in minecraft:overworld run fill 259 61 35 259 144 35 air
execute in minecraft:overworld run fill 259 61 35 259 64 35 water
execute in minecraft:overworld run fill 259 58 36 259 56 36 stone
execute in minecraft:overworld run fill 259 57 36 259 58 36 dirt
execute in minecraft:overworld run setblock 259 59 36 gravel
execute in minecraft:overworld run fill 259 60 36 259 144 36 air
execute in minecraft:overworld run fill 259 60 36 259 64 36 water
execute in minecraft:overworld run fill 259 58 37 259 56 37 stone
execute in minecraft:overworld run fill 259 57 37 259 58 37 dirt
execute in minecraft:overworld run setblock 259 59 37 gravel
execute in minecraft:overworld run fill 259 60 37 259 144 37 air
execute in minecraft:overworld run fill 259 60 37 259 64 37 water
execute in minecraft:overworld run fill 259 58 38 259 55 38 stone
execute in minecraft:overworld run fill 259 56 38 259 57 38 dirt
execute in minecraft:overworld run setblock 259 58 38 gravel
execute in minecraft:overworld run fill 259 59 38 259 144 38 air
execute in minecraft:overworld run fill 259 59 38 259 64 38 water
execute in minecraft:overworld run fill 259 58 39 259 56 39 stone
execute in minecraft:overworld run fill 259 57 39 259 58 39 dirt
execute in minecraft:overworld run setblock 259 59 39 gravel
execute in minecraft:overworld run fill 259 60 39 259 144 39 air
execute in minecraft:overworld run fill 259 60 39 259 64 39 water
execute in minecraft:overworld run fill 259 58 40 259 56 40 stone
execute in minecraft:overworld run fill 259 57 40 259 58 40 dirt
execute in minecraft:overworld run setblock 259 59 40 gravel
execute in minecraft:overworld run fill 259 60 40 259 144 40 air
execute in minecraft:overworld run fill 259 60 40 259 64 40 water
execute in minecraft:overworld run fill 259 58 41 259 57 41 stone
execute in minecraft:overworld run fill 259 58 41 259 59 41 dirt
execute in minecraft:overworld run setblock 259 60 41 gravel
execute in minecraft:overworld run fill 259 61 41 259 144 41 air
execute in minecraft:overworld run fill 259 61 41 259 64 41 water
execute in minecraft:overworld run fill 259 58 42 259 58 42 stone
execute in minecraft:overworld run fill 259 59 42 259 60 42 dirt
execute in minecraft:overworld run setblock 259 61 42 gravel
execute in minecraft:overworld run fill 259 62 42 259 144 42 air
execute in minecraft:overworld run fill 259 62 42 259 64 42 water
execute in minecraft:overworld run fill 259 58 43 259 58 43 stone
execute in minecraft:overworld run fill 259 59 43 259 60 43 dirt
execute in minecraft:overworld run setblock 259 61 43 gravel
execute in minecraft:overworld run fill 259 62 43 259 144 43 air
execute in minecraft:overworld run fill 259 62 43 259 64 43 water
execute in minecraft:overworld run fill 259 58 44 259 59 44 stone
execute in minecraft:overworld run fill 259 60 44 259 61 44 dirt
execute in minecraft:overworld run setblock 259 62 44 gravel
execute in minecraft:overworld run fill 259 63 44 259 144 44 air
execute in minecraft:overworld run fill 259 63 44 259 64 44 water
execute in minecraft:overworld run fill 259 58 45 259 59 45 stone
execute in minecraft:overworld run fill 259 60 45 259 61 45 dirt
execute in minecraft:overworld run setblock 259 62 45 gravel
execute in minecraft:overworld run fill 259 63 45 259 144 45 air
execute in minecraft:overworld run fill 259 63 45 259 64 45 water
execute in minecraft:overworld run fill 259 58 46 259 60 46 stone
execute in minecraft:overworld run fill 259 61 46 259 62 46 dirt
execute in minecraft:overworld run setblock 259 63 46 gravel
execute in minecraft:overworld run fill 259 64 46 259 144 46 air
execute in minecraft:overworld run fill 259 64 46 259 64 46 water
execute in minecraft:overworld run fill 259 58 47 259 60 47 stone
execute in minecraft:overworld run fill 259 61 47 259 62 47 dirt
execute in minecraft:overworld run setblock 259 63 47 gravel
execute in minecraft:overworld run fill 259 64 47 259 144 47 air
execute in minecraft:overworld run fill 259 64 47 259 64 47 water
execute in minecraft:overworld run fill 260 58 -48 260 61 -48 stone
execute in minecraft:overworld run fill 260 62 -48 260 63 -48 dirt
execute in minecraft:overworld run setblock 260 64 -48 grass_block
execute in minecraft:overworld run fill 260 65 -48 260 144 -48 air
execute in minecraft:overworld run fill 260 58 -47 260 63 -47 stone
execute in minecraft:overworld run fill 260 64 -47 260 65 -47 dirt
execute in minecraft:overworld run setblock 260 66 -47 coarse_dirt
execute in minecraft:overworld run fill 260 67 -47 260 144 -47 air
execute in minecraft:overworld run fill 260 58 -46 260 64 -46 stone
execute in minecraft:overworld run fill 260 65 -46 260 66 -46 dirt
execute in minecraft:overworld run setblock 260 67 -46 coarse_dirt
execute in minecraft:overworld run fill 260 68 -46 260 144 -46 air
execute in minecraft:overworld run fill 260 58 -45 260 66 -45 stone
execute in minecraft:overworld run fill 260 67 -45 260 68 -45 dirt
execute in minecraft:overworld run setblock 260 69 -45 grass_block
execute in minecraft:overworld run fill 260 70 -45 260 144 -45 air
execute in minecraft:overworld run fill 260 58 -44 260 68 -44 stone
execute in minecraft:overworld run fill 260 69 -44 260 70 -44 dirt
execute in minecraft:overworld run setblock 260 71 -44 grass_block
execute in minecraft:overworld run fill 260 72 -44 260 144 -44 air
execute in minecraft:overworld run fill 260 58 -43 260 69 -43 stone
execute in minecraft:overworld run fill 260 70 -43 260 71 -43 dirt
schedule function blade_gallery:random/burned/part_81 1t replace
