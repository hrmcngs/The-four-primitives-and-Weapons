execute in minecraft:overworld run fill 252 68 -26 252 69 -26 dirt
execute in minecraft:overworld run setblock 252 70 -26 coarse_dirt
execute in minecraft:overworld run fill 252 71 -26 252 144 -26 air
execute in minecraft:overworld run fill 252 58 -25 252 67 -25 stone
execute in minecraft:overworld run fill 252 68 -25 252 69 -25 dirt
execute in minecraft:overworld run setblock 252 70 -25 coarse_dirt
execute in minecraft:overworld run fill 252 71 -25 252 144 -25 air
execute in minecraft:overworld run fill 252 58 -24 252 66 -24 stone
execute in minecraft:overworld run fill 252 67 -24 252 68 -24 dirt
execute in minecraft:overworld run setblock 252 69 -24 coarse_dirt
execute in minecraft:overworld run fill 252 70 -24 252 144 -24 air
execute in minecraft:overworld run fill 252 58 -23 252 66 -23 stone
execute in minecraft:overworld run fill 252 67 -23 252 68 -23 dirt
execute in minecraft:overworld run setblock 252 69 -23 coarse_dirt
execute in minecraft:overworld run fill 252 70 -23 252 144 -23 air
execute in minecraft:overworld run fill 252 58 -22 252 65 -22 stone
execute in minecraft:overworld run fill 252 66 -22 252 67 -22 dirt
execute in minecraft:overworld run setblock 252 68 -22 coarse_dirt
execute in minecraft:overworld run fill 252 69 -22 252 144 -22 air
execute in minecraft:overworld run setblock 252 69 -22 grass
execute in minecraft:overworld run fill 252 58 -21 252 65 -21 stone
execute in minecraft:overworld run fill 252 66 -21 252 67 -21 dirt
execute in minecraft:overworld run setblock 252 68 -21 coarse_dirt
execute in minecraft:overworld run fill 252 69 -21 252 144 -21 air
execute in minecraft:overworld run fill 252 58 -20 252 65 -20 stone
execute in minecraft:overworld run fill 252 66 -20 252 67 -20 dirt
execute in minecraft:overworld run setblock 252 68 -20 grass_block
execute in minecraft:overworld run fill 252 69 -20 252 144 -20 air
execute in minecraft:overworld run fill 252 58 -19 252 64 -19 stone
execute in minecraft:overworld run fill 252 65 -19 252 66 -19 dirt
execute in minecraft:overworld run setblock 252 67 -19 coarse_dirt
execute in minecraft:overworld run fill 252 68 -19 252 144 -19 air
execute in minecraft:overworld run fill 252 58 -18 252 64 -18 stone
execute in minecraft:overworld run fill 252 65 -18 252 66 -18 dirt
execute in minecraft:overworld run setblock 252 67 -18 coarse_dirt
execute in minecraft:overworld run fill 252 68 -18 252 144 -18 air
execute in minecraft:overworld run setblock 252 68 -18 grass
execute in minecraft:overworld run fill 252 58 -17 252 63 -17 stone
execute in minecraft:overworld run fill 252 64 -17 252 65 -17 dirt
execute in minecraft:overworld run setblock 252 66 -17 coarse_dirt
execute in minecraft:overworld run fill 252 67 -17 252 144 -17 air
execute in minecraft:overworld run fill 252 58 -16 252 63 -16 stone
execute in minecraft:overworld run fill 252 64 -16 252 65 -16 dirt
execute in minecraft:overworld run setblock 252 66 -16 coarse_dirt
execute in minecraft:overworld run fill 252 67 -16 252 144 -16 air
execute in minecraft:overworld run fill 252 58 -15 252 63 -15 stone
execute in minecraft:overworld run fill 252 64 -15 252 65 -15 dirt
execute in minecraft:overworld run setblock 252 66 -15 grass_block
execute in minecraft:overworld run fill 252 67 -15 252 144 -15 air
execute in minecraft:overworld run fill 252 58 -14 252 63 -14 stone
execute in minecraft:overworld run fill 252 64 -14 252 65 -14 dirt
execute in minecraft:overworld run setblock 252 66 -14 coarse_dirt
execute in minecraft:overworld run fill 252 67 -14 252 144 -14 air
execute in minecraft:overworld run fill 252 58 -13 252 62 -13 stone
execute in minecraft:overworld run fill 252 63 -13 252 64 -13 dirt
execute in minecraft:overworld run setblock 252 65 -13 grass_block
execute in minecraft:overworld run fill 252 66 -13 252 144 -13 air
execute in minecraft:overworld run fill 252 58 -12 252 62 -12 stone
execute in minecraft:overworld run fill 252 63 -12 252 64 -12 dirt
execute in minecraft:overworld run setblock 252 65 -12 coarse_dirt
execute in minecraft:overworld run fill 252 66 -12 252 144 -12 air
execute in minecraft:overworld run fill 252 58 -11 252 62 -11 stone
execute in minecraft:overworld run fill 252 63 -11 252 64 -11 dirt
execute in minecraft:overworld run setblock 252 65 -11 coarse_dirt
execute in minecraft:overworld run fill 252 66 -11 252 144 -11 air
execute in minecraft:overworld run fill 252 58 -10 252 62 -10 stone
execute in minecraft:overworld run fill 252 63 -10 252 64 -10 dirt
execute in minecraft:overworld run setblock 252 65 -10 coarse_dirt
execute in minecraft:overworld run fill 252 66 -10 252 144 -10 air
execute in minecraft:overworld run setblock 252 66 -10 grass
execute in minecraft:overworld run fill 252 58 -9 252 61 -9 stone
execute in minecraft:overworld run fill 252 62 -9 252 63 -9 dirt
execute in minecraft:overworld run setblock 252 64 -9 coarse_dirt
execute in minecraft:overworld run fill 252 65 -9 252 144 -9 air
execute in minecraft:overworld run fill 252 58 -8 252 61 -8 stone
execute in minecraft:overworld run fill 252 62 -8 252 63 -8 dirt
execute in minecraft:overworld run setblock 252 64 -8 coarse_dirt
execute in minecraft:overworld run fill 252 65 -8 252 144 -8 air
execute in minecraft:overworld run fill 252 58 -7 252 61 -7 stone
execute in minecraft:overworld run fill 252 62 -7 252 63 -7 dirt
execute in minecraft:overworld run setblock 252 64 -7 coarse_dirt
execute in minecraft:overworld run fill 252 65 -7 252 144 -7 air
execute in minecraft:overworld run fill 252 58 -6 252 61 -6 stone
execute in minecraft:overworld run fill 252 62 -6 252 63 -6 dirt
execute in minecraft:overworld run setblock 252 64 -6 coarse_dirt
execute in minecraft:overworld run fill 252 65 -6 252 144 -6 air
execute in minecraft:overworld run fill 252 58 -5 252 60 -5 stone
execute in minecraft:overworld run fill 252 61 -5 252 62 -5 dirt
execute in minecraft:overworld run setblock 252 63 -5 gravel
execute in minecraft:overworld run fill 252 64 -5 252 144 -5 air
execute in minecraft:overworld run fill 252 64 -5 252 64 -5 water
execute in minecraft:overworld run fill 252 58 -4 252 60 -4 stone
execute in minecraft:overworld run fill 252 61 -4 252 62 -4 dirt
execute in minecraft:overworld run setblock 252 63 -4 gravel
execute in minecraft:overworld run fill 252 64 -4 252 144 -4 air
execute in minecraft:overworld run fill 252 64 -4 252 64 -4 water
execute in minecraft:overworld run fill 252 58 -3 252 60 -3 stone
execute in minecraft:overworld run fill 252 61 -3 252 62 -3 dirt
execute in minecraft:overworld run setblock 252 63 -3 gravel
execute in minecraft:overworld run fill 252 64 -3 252 144 -3 air
execute in minecraft:overworld run fill 252 64 -3 252 64 -3 water
execute in minecraft:overworld run fill 252 58 -2 252 59 -2 stone
execute in minecraft:overworld run fill 252 60 -2 252 61 -2 dirt
execute in minecraft:overworld run setblock 252 62 -2 gravel
execute in minecraft:overworld run fill 252 63 -2 252 144 -2 air
execute in minecraft:overworld run fill 252 63 -2 252 64 -2 water
execute in minecraft:overworld run fill 252 58 -1 252 59 -1 stone
execute in minecraft:overworld run fill 252 60 -1 252 61 -1 dirt
execute in minecraft:overworld run setblock 252 62 -1 gravel
execute in minecraft:overworld run fill 252 63 -1 252 144 -1 air
execute in minecraft:overworld run fill 252 63 -1 252 64 -1 water
execute in minecraft:overworld run fill 252 58 0 252 59 0 stone
execute in minecraft:overworld run fill 252 60 0 252 61 0 dirt
execute in minecraft:overworld run setblock 252 62 0 gravel
execute in minecraft:overworld run fill 252 63 0 252 144 0 air
execute in minecraft:overworld run fill 252 63 0 252 64 0 water
execute in minecraft:overworld run fill 252 58 1 252 59 1 stone
execute in minecraft:overworld run fill 252 60 1 252 61 1 dirt
execute in minecraft:overworld run setblock 252 62 1 gravel
execute in minecraft:overworld run fill 252 63 1 252 144 1 air
execute in minecraft:overworld run fill 252 63 1 252 64 1 water
execute in minecraft:overworld run fill 252 58 2 252 60 2 stone
execute in minecraft:overworld run fill 252 61 2 252 62 2 dirt
execute in minecraft:overworld run setblock 252 63 2 gravel
execute in minecraft:overworld run fill 252 64 2 252 144 2 air
execute in minecraft:overworld run fill 252 64 2 252 64 2 water
execute in minecraft:overworld run fill 252 58 3 252 60 3 stone
execute in minecraft:overworld run fill 252 61 3 252 62 3 dirt
execute in minecraft:overworld run setblock 252 63 3 gravel
execute in minecraft:overworld run fill 252 64 3 252 144 3 air
execute in minecraft:overworld run fill 252 64 3 252 64 3 water
execute in minecraft:overworld run fill 252 58 4 252 60 4 stone
execute in minecraft:overworld run fill 252 61 4 252 62 4 dirt
execute in minecraft:overworld run setblock 252 63 4 gravel
execute in minecraft:overworld run fill 252 64 4 252 144 4 air
execute in minecraft:overworld run fill 252 64 4 252 64 4 water
execute in minecraft:overworld run fill 252 58 5 252 61 5 stone
execute in minecraft:overworld run fill 252 62 5 252 63 5 dirt
execute in minecraft:overworld run setblock 252 64 5 coarse_dirt
execute in minecraft:overworld run fill 252 65 5 252 144 5 air
execute in minecraft:overworld run fill 252 58 6 252 61 6 stone
execute in minecraft:overworld run fill 252 62 6 252 63 6 dirt
execute in minecraft:overworld run setblock 252 64 6 grass_block
execute in minecraft:overworld run fill 252 65 6 252 144 6 air
execute in minecraft:overworld run fill 252 58 7 252 62 7 stone
execute in minecraft:overworld run fill 252 63 7 252 64 7 dirt
execute in minecraft:overworld run setblock 252 65 7 coarse_dirt
execute in minecraft:overworld run fill 252 66 7 252 144 7 air
execute in minecraft:overworld run fill 252 58 8 252 62 8 stone
execute in minecraft:overworld run fill 252 63 8 252 64 8 dirt
execute in minecraft:overworld run setblock 252 65 8 coarse_dirt
execute in minecraft:overworld run fill 252 66 8 252 144 8 air
execute in minecraft:overworld run fill 252 58 9 252 62 9 stone
execute in minecraft:overworld run fill 252 63 9 252 64 9 dirt
execute in minecraft:overworld run setblock 252 65 9 coarse_dirt
execute in minecraft:overworld run fill 252 66 9 252 144 9 air
execute in minecraft:overworld run fill 252 58 10 252 62 10 stone
execute in minecraft:overworld run fill 252 63 10 252 64 10 dirt
execute in minecraft:overworld run setblock 252 65 10 coarse_dirt
execute in minecraft:overworld run fill 252 66 10 252 144 10 air
execute in minecraft:overworld run fill 252 58 11 252 63 11 stone
execute in minecraft:overworld run fill 252 64 11 252 65 11 dirt
execute in minecraft:overworld run setblock 252 66 11 grass_block
execute in minecraft:overworld run fill 252 67 11 252 144 11 air
execute in minecraft:overworld run fill 252 58 12 252 63 12 stone
execute in minecraft:overworld run fill 252 64 12 252 65 12 dirt
execute in minecraft:overworld run setblock 252 66 12 grass_block
execute in minecraft:overworld run fill 252 67 12 252 144 12 air
execute in minecraft:overworld run setblock 252 67 12 grass
execute in minecraft:overworld run fill 252 58 13 252 63 13 stone
execute in minecraft:overworld run fill 252 64 13 252 65 13 dirt
execute in minecraft:overworld run setblock 252 66 13 coarse_dirt
execute in minecraft:overworld run fill 252 67 13 252 144 13 air
execute in minecraft:overworld run fill 252 58 14 252 63 14 stone
execute in minecraft:overworld run fill 252 64 14 252 65 14 dirt
execute in minecraft:overworld run setblock 252 66 14 coarse_dirt
execute in minecraft:overworld run fill 252 67 14 252 144 14 air
execute in minecraft:overworld run fill 252 58 15 252 64 15 stone
execute in minecraft:overworld run fill 252 65 15 252 66 15 dirt
execute in minecraft:overworld run setblock 252 67 15 coarse_dirt
execute in minecraft:overworld run fill 252 68 15 252 144 15 air
execute in minecraft:overworld run fill 252 58 16 252 64 16 stone
execute in minecraft:overworld run fill 252 65 16 252 66 16 dirt
execute in minecraft:overworld run setblock 252 67 16 coarse_dirt
execute in minecraft:overworld run fill 252 68 16 252 144 16 air
execute in minecraft:overworld run setblock 252 68 16 grass
execute in minecraft:overworld run fill 252 58 17 252 64 17 stone
execute in minecraft:overworld run fill 252 65 17 252 66 17 dirt
execute in minecraft:overworld run setblock 252 67 17 coarse_dirt
execute in minecraft:overworld run fill 252 68 17 252 144 17 air
execute in minecraft:overworld run fill 252 58 18 252 64 18 stone
execute in minecraft:overworld run fill 252 65 18 252 66 18 dirt
execute in minecraft:overworld run setblock 252 67 18 coarse_dirt
execute in minecraft:overworld run fill 252 68 18 252 144 18 air
execute in minecraft:overworld run fill 252 58 19 252 65 19 stone
execute in minecraft:overworld run fill 252 66 19 252 67 19 dirt
execute in minecraft:overworld run setblock 252 68 19 coarse_dirt
execute in minecraft:overworld run fill 252 69 19 252 144 19 air
execute in minecraft:overworld run fill 252 58 20 252 65 20 stone
execute in minecraft:overworld run fill 252 66 20 252 67 20 dirt
execute in minecraft:overworld run setblock 252 68 20 grass_block
execute in minecraft:overworld run fill 252 69 20 252 144 20 air
execute in minecraft:overworld run fill 252 58 21 252 65 21 stone
execute in minecraft:overworld run fill 252 66 21 252 67 21 dirt
execute in minecraft:overworld run setblock 252 68 21 coarse_dirt
execute in minecraft:overworld run fill 252 69 21 252 144 21 air
execute in minecraft:overworld run setblock 252 69 21 grass
execute in minecraft:overworld run fill 252 58 22 252 65 22 stone
execute in minecraft:overworld run fill 252 66 22 252 67 22 dirt
execute in minecraft:overworld run setblock 252 68 22 grass_block
execute in minecraft:overworld run fill 252 69 22 252 144 22 air
execute in minecraft:overworld run fill 252 58 23 252 65 23 stone
execute in minecraft:overworld run fill 252 66 23 252 67 23 dirt
execute in minecraft:overworld run setblock 252 68 23 coarse_dirt
execute in minecraft:overworld run fill 252 69 23 252 144 23 air
execute in minecraft:overworld run fill 252 58 24 252 65 24 stone
execute in minecraft:overworld run fill 252 66 24 252 67 24 dirt
execute in minecraft:overworld run setblock 252 68 24 grass_block
execute in minecraft:overworld run fill 252 69 24 252 144 24 air
execute in minecraft:overworld run fill 252 58 25 252 65 25 stone
execute in minecraft:overworld run fill 252 66 25 252 67 25 dirt
execute in minecraft:overworld run setblock 252 68 25 grass_block
execute in minecraft:overworld run fill 252 69 25 252 144 25 air
execute in minecraft:overworld run fill 252 58 26 252 65 26 stone
execute in minecraft:overworld run fill 252 66 26 252 67 26 dirt
execute in minecraft:overworld run setblock 252 68 26 grass_block
execute in minecraft:overworld run fill 252 69 26 252 144 26 air
execute in minecraft:overworld run fill 252 58 27 252 65 27 stone
execute in minecraft:overworld run fill 252 66 27 252 67 27 dirt
execute in minecraft:overworld run setblock 252 68 27 coarse_dirt
execute in minecraft:overworld run fill 252 69 27 252 144 27 air
execute in minecraft:overworld run setblock 252 69 27 grass
execute in minecraft:overworld run fill 252 58 28 252 65 28 stone
execute in minecraft:overworld run fill 252 66 28 252 67 28 dirt
execute in minecraft:overworld run setblock 252 68 28 coarse_dirt
execute in minecraft:overworld run fill 252 69 28 252 144 28 air
execute in minecraft:overworld run fill 252 58 29 252 65 29 stone
execute in minecraft:overworld run fill 252 66 29 252 67 29 dirt
execute in minecraft:overworld run setblock 252 68 29 coarse_dirt
execute in minecraft:overworld run fill 252 69 29 252 144 29 air
execute in minecraft:overworld run setblock 252 69 29 grass
execute in minecraft:overworld run fill 252 58 30 252 65 30 stone
execute in minecraft:overworld run fill 252 66 30 252 67 30 dirt
execute in minecraft:overworld run setblock 252 68 30 grass_block
execute in minecraft:overworld run fill 252 69 30 252 144 30 air
execute in minecraft:overworld run fill 252 58 31 252 65 31 stone
execute in minecraft:overworld run fill 252 66 31 252 67 31 dirt
execute in minecraft:overworld run setblock 252 68 31 grass_block
execute in minecraft:overworld run fill 252 69 31 252 144 31 air
execute in minecraft:overworld run fill 252 58 32 252 65 32 stone
execute in minecraft:overworld run fill 252 66 32 252 67 32 dirt
execute in minecraft:overworld run setblock 252 68 32 coarse_dirt
execute in minecraft:overworld run fill 252 69 32 252 144 32 air
execute in minecraft:overworld run setblock 252 69 32 grass
execute in minecraft:overworld run fill 252 58 33 252 65 33 stone
execute in minecraft:overworld run fill 252 66 33 252 67 33 dirt
schedule function blade_gallery:random/burned/part_69 1t replace
