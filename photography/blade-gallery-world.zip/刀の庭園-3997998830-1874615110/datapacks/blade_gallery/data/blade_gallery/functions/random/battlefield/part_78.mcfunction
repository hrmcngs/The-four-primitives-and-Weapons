execute in minecraft:overworld run fill 386 58 12 386 62 12 stone
execute in minecraft:overworld run fill 386 63 12 386 64 12 dirt
execute in minecraft:overworld run setblock 386 65 12 grass_block
execute in minecraft:overworld run fill 386 66 12 386 144 12 air
execute in minecraft:overworld run fill 386 58 13 386 62 13 stone
execute in minecraft:overworld run fill 386 63 13 386 64 13 dirt
execute in minecraft:overworld run setblock 386 65 13 grass_block
execute in minecraft:overworld run fill 386 66 13 386 144 13 air
execute in minecraft:overworld run fill 386 58 14 386 62 14 stone
execute in minecraft:overworld run fill 386 63 14 386 64 14 dirt
execute in minecraft:overworld run setblock 386 65 14 coarse_dirt
execute in minecraft:overworld run fill 386 66 14 386 144 14 air
execute in minecraft:overworld run fill 386 58 15 386 62 15 stone
execute in minecraft:overworld run fill 386 63 15 386 64 15 dirt
execute in minecraft:overworld run setblock 386 65 15 coarse_dirt
execute in minecraft:overworld run fill 386 66 15 386 144 15 air
execute in minecraft:overworld run fill 386 58 16 386 62 16 stone
execute in minecraft:overworld run fill 386 63 16 386 64 16 dirt
execute in minecraft:overworld run setblock 386 65 16 coarse_dirt
execute in minecraft:overworld run fill 386 66 16 386 144 16 air
execute in minecraft:overworld run fill 386 58 17 386 62 17 stone
execute in minecraft:overworld run fill 386 63 17 386 64 17 dirt
execute in minecraft:overworld run setblock 386 65 17 coarse_dirt
execute in minecraft:overworld run fill 386 66 17 386 144 17 air
execute in minecraft:overworld run fill 386 58 18 386 62 18 stone
execute in minecraft:overworld run fill 386 63 18 386 64 18 dirt
execute in minecraft:overworld run setblock 386 65 18 coarse_dirt
execute in minecraft:overworld run fill 386 66 18 386 144 18 air
execute in minecraft:overworld run fill 386 58 19 386 62 19 stone
execute in minecraft:overworld run fill 386 63 19 386 64 19 dirt
execute in minecraft:overworld run setblock 386 65 19 coarse_dirt
execute in minecraft:overworld run fill 386 66 19 386 144 19 air
execute in minecraft:overworld run fill 386 58 20 386 62 20 stone
execute in minecraft:overworld run fill 386 63 20 386 64 20 dirt
execute in minecraft:overworld run setblock 386 65 20 grass_block
execute in minecraft:overworld run fill 386 66 20 386 144 20 air
execute in minecraft:overworld run fill 386 58 21 386 62 21 stone
execute in minecraft:overworld run fill 386 63 21 386 64 21 dirt
execute in minecraft:overworld run setblock 386 65 21 coarse_dirt
execute in minecraft:overworld run fill 386 66 21 386 144 21 air
execute in minecraft:overworld run fill 386 58 22 386 63 22 stone
execute in minecraft:overworld run fill 386 64 22 386 65 22 dirt
execute in minecraft:overworld run setblock 386 66 22 coarse_dirt
execute in minecraft:overworld run fill 386 67 22 386 144 22 air
execute in minecraft:overworld run fill 386 58 23 386 62 23 stone
execute in minecraft:overworld run fill 386 63 23 386 64 23 dirt
execute in minecraft:overworld run setblock 386 65 23 grass_block
execute in minecraft:overworld run fill 386 66 23 386 144 23 air
execute in minecraft:overworld run setblock 386 66 23 grass
execute in minecraft:overworld run fill 386 58 24 386 62 24 stone
execute in minecraft:overworld run fill 386 63 24 386 64 24 dirt
execute in minecraft:overworld run setblock 386 65 24 grass_block
execute in minecraft:overworld run fill 386 66 24 386 144 24 air
execute in minecraft:overworld run fill 386 58 25 386 62 25 stone
execute in minecraft:overworld run fill 386 63 25 386 64 25 dirt
execute in minecraft:overworld run setblock 386 65 25 coarse_dirt
execute in minecraft:overworld run fill 386 66 25 386 144 25 air
execute in minecraft:overworld run fill 386 58 26 386 62 26 stone
execute in minecraft:overworld run fill 386 63 26 386 64 26 dirt
execute in minecraft:overworld run setblock 386 65 26 coarse_dirt
execute in minecraft:overworld run fill 386 66 26 386 144 26 air
execute in minecraft:overworld run fill 386 58 27 386 62 27 stone
execute in minecraft:overworld run fill 386 63 27 386 64 27 dirt
execute in minecraft:overworld run setblock 386 65 27 coarse_dirt
execute in minecraft:overworld run fill 386 66 27 386 144 27 air
execute in minecraft:overworld run fill 386 58 28 386 62 28 stone
execute in minecraft:overworld run fill 386 63 28 386 64 28 dirt
execute in minecraft:overworld run setblock 386 65 28 coarse_dirt
execute in minecraft:overworld run fill 386 66 28 386 144 28 air
execute in minecraft:overworld run fill 386 58 29 386 61 29 stone
execute in minecraft:overworld run fill 386 62 29 386 63 29 dirt
execute in minecraft:overworld run setblock 386 64 29 coarse_dirt
execute in minecraft:overworld run fill 386 65 29 386 144 29 air
execute in minecraft:overworld run fill 386 58 30 386 61 30 stone
execute in minecraft:overworld run fill 386 62 30 386 63 30 dirt
execute in minecraft:overworld run setblock 386 64 30 grass_block
execute in minecraft:overworld run fill 386 65 30 386 144 30 air
execute in minecraft:overworld run fill 386 58 31 386 61 31 stone
execute in minecraft:overworld run fill 386 62 31 386 63 31 dirt
execute in minecraft:overworld run setblock 386 64 31 coarse_dirt
execute in minecraft:overworld run fill 386 65 31 386 144 31 air
execute in minecraft:overworld run fill 386 58 32 386 61 32 stone
execute in minecraft:overworld run fill 386 62 32 386 63 32 dirt
execute in minecraft:overworld run setblock 386 64 32 coarse_dirt
execute in minecraft:overworld run fill 386 65 32 386 144 32 air
execute in minecraft:overworld run fill 386 58 33 386 61 33 stone
execute in minecraft:overworld run fill 386 62 33 386 63 33 dirt
execute in minecraft:overworld run setblock 386 64 33 coarse_dirt
execute in minecraft:overworld run fill 386 65 33 386 144 33 air
execute in minecraft:overworld run fill 386 58 34 386 61 34 stone
execute in minecraft:overworld run fill 386 62 34 386 63 34 dirt
execute in minecraft:overworld run setblock 386 64 34 coarse_dirt
execute in minecraft:overworld run fill 386 65 34 386 144 34 air
execute in minecraft:overworld run fill 386 58 35 386 61 35 stone
execute in minecraft:overworld run fill 386 62 35 386 63 35 dirt
execute in minecraft:overworld run setblock 386 64 35 coarse_dirt
execute in minecraft:overworld run fill 386 65 35 386 144 35 air
execute in minecraft:overworld run fill 386 58 36 386 60 36 stone
execute in minecraft:overworld run fill 386 61 36 386 62 36 dirt
execute in minecraft:overworld run setblock 386 63 36 gravel
execute in minecraft:overworld run fill 386 64 36 386 144 36 air
execute in minecraft:overworld run fill 386 64 36 386 64 36 water
execute in minecraft:overworld run fill 386 58 37 386 60 37 stone
execute in minecraft:overworld run fill 386 61 37 386 62 37 dirt
execute in minecraft:overworld run setblock 386 63 37 gravel
execute in minecraft:overworld run fill 386 64 37 386 144 37 air
execute in minecraft:overworld run fill 386 64 37 386 64 37 water
execute in minecraft:overworld run fill 386 58 38 386 60 38 stone
execute in minecraft:overworld run fill 386 61 38 386 62 38 dirt
execute in minecraft:overworld run setblock 386 63 38 gravel
execute in minecraft:overworld run fill 386 64 38 386 144 38 air
execute in minecraft:overworld run fill 386 64 38 386 64 38 water
execute in minecraft:overworld run fill 386 58 39 386 60 39 stone
execute in minecraft:overworld run fill 386 61 39 386 62 39 dirt
execute in minecraft:overworld run setblock 386 63 39 gravel
execute in minecraft:overworld run fill 386 64 39 386 144 39 air
execute in minecraft:overworld run fill 386 64 39 386 64 39 water
execute in minecraft:overworld run fill 386 58 40 386 60 40 stone
execute in minecraft:overworld run fill 386 61 40 386 62 40 dirt
execute in minecraft:overworld run setblock 386 63 40 gravel
execute in minecraft:overworld run fill 386 64 40 386 144 40 air
execute in minecraft:overworld run fill 386 64 40 386 64 40 water
execute in minecraft:overworld run fill 386 58 41 386 60 41 stone
execute in minecraft:overworld run fill 386 61 41 386 62 41 dirt
execute in minecraft:overworld run setblock 386 63 41 gravel
execute in minecraft:overworld run fill 386 64 41 386 144 41 air
execute in minecraft:overworld run fill 386 64 41 386 64 41 water
execute in minecraft:overworld run fill 386 58 42 386 60 42 stone
execute in minecraft:overworld run fill 386 61 42 386 62 42 dirt
execute in minecraft:overworld run setblock 386 63 42 gravel
execute in minecraft:overworld run fill 386 64 42 386 144 42 air
execute in minecraft:overworld run fill 386 64 42 386 64 42 water
execute in minecraft:overworld run fill 386 58 43 386 60 43 stone
execute in minecraft:overworld run fill 386 61 43 386 62 43 dirt
execute in minecraft:overworld run setblock 386 63 43 gravel
execute in minecraft:overworld run fill 386 64 43 386 144 43 air
execute in minecraft:overworld run fill 386 64 43 386 64 43 water
execute in minecraft:overworld run fill 386 58 44 386 60 44 stone
execute in minecraft:overworld run fill 386 61 44 386 62 44 dirt
execute in minecraft:overworld run setblock 386 63 44 gravel
execute in minecraft:overworld run fill 386 64 44 386 144 44 air
execute in minecraft:overworld run fill 386 64 44 386 64 44 water
execute in minecraft:overworld run fill 386 58 45 386 61 45 stone
execute in minecraft:overworld run fill 386 62 45 386 63 45 dirt
execute in minecraft:overworld run setblock 386 64 45 grass_block
execute in minecraft:overworld run fill 386 65 45 386 144 45 air
execute in minecraft:overworld run fill 386 58 46 386 61 46 stone
execute in minecraft:overworld run fill 386 62 46 386 63 46 dirt
execute in minecraft:overworld run setblock 386 64 46 coarse_dirt
execute in minecraft:overworld run fill 386 65 46 386 144 46 air
execute in minecraft:overworld run fill 386 58 47 386 61 47 stone
execute in minecraft:overworld run fill 386 62 47 386 63 47 dirt
execute in minecraft:overworld run setblock 386 64 47 coarse_dirt
execute in minecraft:overworld run fill 386 65 47 386 144 47 air
execute in minecraft:overworld run fill 387 58 -48 387 61 -48 stone
execute in minecraft:overworld run fill 387 62 -48 387 63 -48 dirt
execute in minecraft:overworld run setblock 387 64 -48 coarse_dirt
execute in minecraft:overworld run fill 387 65 -48 387 144 -48 air
execute in minecraft:overworld run fill 387 58 -47 387 62 -47 stone
execute in minecraft:overworld run fill 387 63 -47 387 64 -47 dirt
execute in minecraft:overworld run setblock 387 65 -47 grass_block
execute in minecraft:overworld run fill 387 66 -47 387 144 -47 air
execute in minecraft:overworld run fill 387 58 -46 387 64 -46 stone
execute in minecraft:overworld run fill 387 65 -46 387 66 -46 dirt
execute in minecraft:overworld run setblock 387 67 -46 coarse_dirt
execute in minecraft:overworld run fill 387 68 -46 387 144 -46 air
execute in minecraft:overworld run fill 387 58 -45 387 65 -45 stone
execute in minecraft:overworld run fill 387 66 -45 387 67 -45 dirt
execute in minecraft:overworld run setblock 387 68 -45 grass_block
execute in minecraft:overworld run fill 387 69 -45 387 144 -45 air
execute in minecraft:overworld run fill 387 58 -44 387 67 -44 stone
execute in minecraft:overworld run fill 387 68 -44 387 69 -44 dirt
execute in minecraft:overworld run setblock 387 70 -44 grass_block
execute in minecraft:overworld run fill 387 71 -44 387 144 -44 air
execute in minecraft:overworld run fill 387 58 -43 387 68 -43 stone
execute in minecraft:overworld run fill 387 69 -43 387 70 -43 dirt
execute in minecraft:overworld run setblock 387 71 -43 grass_block
execute in minecraft:overworld run fill 387 72 -43 387 144 -43 air
execute in minecraft:overworld run fill 387 58 -42 387 69 -42 stone
execute in minecraft:overworld run fill 387 70 -42 387 71 -42 dirt
execute in minecraft:overworld run setblock 387 72 -42 coarse_dirt
execute in minecraft:overworld run fill 387 73 -42 387 144 -42 air
execute in minecraft:overworld run fill 387 58 -41 387 70 -41 stone
execute in minecraft:overworld run fill 387 71 -41 387 72 -41 dirt
execute in minecraft:overworld run setblock 387 73 -41 coarse_dirt
execute in minecraft:overworld run fill 387 74 -41 387 144 -41 air
execute in minecraft:overworld run fill 387 58 -40 387 71 -40 stone
execute in minecraft:overworld run fill 387 72 -40 387 73 -40 dirt
execute in minecraft:overworld run setblock 387 74 -40 grass_block
execute in minecraft:overworld run fill 387 75 -40 387 144 -40 air
execute in minecraft:overworld run fill 387 58 -39 387 72 -39 stone
execute in minecraft:overworld run fill 387 73 -39 387 74 -39 dirt
execute in minecraft:overworld run setblock 387 75 -39 coarse_dirt
execute in minecraft:overworld run fill 387 76 -39 387 144 -39 air
execute in minecraft:overworld run fill 387 58 -38 387 73 -38 stone
execute in minecraft:overworld run fill 387 74 -38 387 75 -38 dirt
execute in minecraft:overworld run setblock 387 76 -38 coarse_dirt
execute in minecraft:overworld run fill 387 77 -38 387 144 -38 air
execute in minecraft:overworld run fill 387 58 -37 387 72 -37 stone
execute in minecraft:overworld run fill 387 73 -37 387 74 -37 dirt
execute in minecraft:overworld run setblock 387 75 -37 coarse_dirt
execute in minecraft:overworld run fill 387 76 -37 387 144 -37 air
execute in minecraft:overworld run fill 387 58 -36 387 72 -36 stone
execute in minecraft:overworld run fill 387 73 -36 387 74 -36 dirt
execute in minecraft:overworld run setblock 387 75 -36 coarse_dirt
execute in minecraft:overworld run fill 387 76 -36 387 144 -36 air
execute in minecraft:overworld run fill 387 58 -35 387 71 -35 stone
execute in minecraft:overworld run fill 387 72 -35 387 73 -35 dirt
execute in minecraft:overworld run setblock 387 74 -35 coarse_dirt
execute in minecraft:overworld run fill 387 75 -35 387 144 -35 air
execute in minecraft:overworld run fill 387 58 -34 387 71 -34 stone
execute in minecraft:overworld run fill 387 72 -34 387 73 -34 dirt
execute in minecraft:overworld run setblock 387 74 -34 coarse_dirt
execute in minecraft:overworld run fill 387 75 -34 387 144 -34 air
execute in minecraft:overworld run fill 387 58 -33 387 71 -33 stone
execute in minecraft:overworld run fill 387 72 -33 387 73 -33 dirt
execute in minecraft:overworld run setblock 387 74 -33 coarse_dirt
execute in minecraft:overworld run fill 387 75 -33 387 144 -33 air
execute in minecraft:overworld run fill 387 58 -32 387 70 -32 stone
execute in minecraft:overworld run fill 387 71 -32 387 72 -32 dirt
execute in minecraft:overworld run setblock 387 73 -32 coarse_dirt
execute in minecraft:overworld run fill 387 74 -32 387 144 -32 air
execute in minecraft:overworld run setblock 387 74 -32 mossy_cobblestone
execute in minecraft:overworld run fill 387 58 -31 387 70 -31 stone
execute in minecraft:overworld run fill 387 71 -31 387 72 -31 dirt
execute in minecraft:overworld run setblock 387 73 -31 coarse_dirt
execute in minecraft:overworld run fill 387 74 -31 387 144 -31 air
execute in minecraft:overworld run fill 387 58 -30 387 69 -30 stone
execute in minecraft:overworld run fill 387 70 -30 387 71 -30 dirt
execute in minecraft:overworld run setblock 387 72 -30 grass_block
execute in minecraft:overworld run fill 387 73 -30 387 144 -30 air
execute in minecraft:overworld run fill 387 58 -29 387 69 -29 stone
execute in minecraft:overworld run fill 387 70 -29 387 71 -29 dirt
execute in minecraft:overworld run setblock 387 72 -29 coarse_dirt
execute in minecraft:overworld run fill 387 73 -29 387 144 -29 air
execute in minecraft:overworld run fill 387 58 -28 387 68 -28 stone
execute in minecraft:overworld run fill 387 69 -28 387 70 -28 dirt
execute in minecraft:overworld run setblock 387 71 -28 grass_block
execute in minecraft:overworld run fill 387 72 -28 387 144 -28 air
execute in minecraft:overworld run fill 387 58 -27 387 67 -27 stone
execute in minecraft:overworld run fill 387 68 -27 387 69 -27 dirt
execute in minecraft:overworld run setblock 387 70 -27 coarse_dirt
execute in minecraft:overworld run fill 387 71 -27 387 144 -27 air
execute in minecraft:overworld run fill 387 58 -26 387 66 -26 stone
execute in minecraft:overworld run fill 387 67 -26 387 68 -26 dirt
execute in minecraft:overworld run setblock 387 69 -26 coarse_dirt
execute in minecraft:overworld run fill 387 70 -26 387 144 -26 air
execute in minecraft:overworld run fill 387 58 -25 387 65 -25 stone
execute in minecraft:overworld run fill 387 66 -25 387 67 -25 dirt
execute in minecraft:overworld run setblock 387 68 -25 grass_block
execute in minecraft:overworld run fill 387 69 -25 387 144 -25 air
execute in minecraft:overworld run fill 387 58 -24 387 64 -24 stone
execute in minecraft:overworld run fill 387 65 -24 387 66 -24 dirt
execute in minecraft:overworld run setblock 387 67 -24 coarse_dirt
execute in minecraft:overworld run fill 387 68 -24 387 144 -24 air
execute in minecraft:overworld run setblock 387 68 -24 grass
schedule function blade_gallery:random/battlefield/part_79 1t replace
