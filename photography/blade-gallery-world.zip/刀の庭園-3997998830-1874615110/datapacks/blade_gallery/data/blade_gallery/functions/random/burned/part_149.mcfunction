execute in minecraft:overworld run fill 302 63 25 302 64 25 dirt
execute in minecraft:overworld run setblock 302 65 25 coarse_dirt
execute in minecraft:overworld run fill 302 66 25 302 144 25 air
execute in minecraft:overworld run fill 302 58 26 302 62 26 stone
execute in minecraft:overworld run fill 302 63 26 302 64 26 dirt
execute in minecraft:overworld run setblock 302 65 26 coarse_dirt
execute in minecraft:overworld run fill 302 66 26 302 144 26 air
execute in minecraft:overworld run fill 302 58 27 302 62 27 stone
execute in minecraft:overworld run fill 302 63 27 302 64 27 dirt
execute in minecraft:overworld run setblock 302 65 27 grass_block
execute in minecraft:overworld run fill 302 66 27 302 144 27 air
execute in minecraft:overworld run fill 302 58 28 302 62 28 stone
execute in minecraft:overworld run fill 302 63 28 302 64 28 dirt
execute in minecraft:overworld run setblock 302 65 28 grass_block
execute in minecraft:overworld run fill 302 66 28 302 144 28 air
execute in minecraft:overworld run fill 302 58 29 302 62 29 stone
execute in minecraft:overworld run fill 302 63 29 302 64 29 dirt
execute in minecraft:overworld run setblock 302 65 29 coarse_dirt
execute in minecraft:overworld run fill 302 66 29 302 144 29 air
execute in minecraft:overworld run fill 302 58 30 302 62 30 stone
execute in minecraft:overworld run fill 302 63 30 302 64 30 dirt
execute in minecraft:overworld run setblock 302 65 30 coarse_dirt
execute in minecraft:overworld run fill 302 66 30 302 144 30 air
execute in minecraft:overworld run fill 302 58 31 302 62 31 stone
execute in minecraft:overworld run fill 302 63 31 302 64 31 dirt
execute in minecraft:overworld run setblock 302 65 31 coarse_dirt
execute in minecraft:overworld run fill 302 66 31 302 144 31 air
execute in minecraft:overworld run fill 302 58 32 302 62 32 stone
execute in minecraft:overworld run fill 302 63 32 302 64 32 dirt
execute in minecraft:overworld run setblock 302 65 32 coarse_dirt
execute in minecraft:overworld run fill 302 66 32 302 144 32 air
execute in minecraft:overworld run fill 302 58 33 302 62 33 stone
execute in minecraft:overworld run fill 302 63 33 302 64 33 dirt
execute in minecraft:overworld run setblock 302 65 33 coarse_dirt
execute in minecraft:overworld run fill 302 66 33 302 144 33 air
execute in minecraft:overworld run fill 302 58 34 302 62 34 stone
execute in minecraft:overworld run fill 302 63 34 302 64 34 dirt
execute in minecraft:overworld run setblock 302 65 34 coarse_dirt
execute in minecraft:overworld run fill 302 66 34 302 144 34 air
execute in minecraft:overworld run fill 302 58 35 302 62 35 stone
execute in minecraft:overworld run fill 302 63 35 302 64 35 dirt
execute in minecraft:overworld run setblock 302 65 35 coarse_dirt
execute in minecraft:overworld run fill 302 66 35 302 144 35 air
execute in minecraft:overworld run fill 302 58 36 302 62 36 stone
execute in minecraft:overworld run fill 302 63 36 302 64 36 dirt
execute in minecraft:overworld run setblock 302 65 36 grass_block
execute in minecraft:overworld run fill 302 66 36 302 144 36 air
execute in minecraft:overworld run fill 302 58 37 302 62 37 stone
execute in minecraft:overworld run fill 302 63 37 302 64 37 dirt
execute in minecraft:overworld run setblock 302 65 37 coarse_dirt
execute in minecraft:overworld run fill 302 66 37 302 144 37 air
execute in minecraft:overworld run fill 302 58 38 302 62 38 stone
execute in minecraft:overworld run fill 302 63 38 302 64 38 dirt
execute in minecraft:overworld run setblock 302 65 38 coarse_dirt
execute in minecraft:overworld run fill 302 66 38 302 144 38 air
execute in minecraft:overworld run fill 302 58 39 302 62 39 stone
execute in minecraft:overworld run fill 302 63 39 302 64 39 dirt
execute in minecraft:overworld run setblock 302 65 39 coarse_dirt
execute in minecraft:overworld run fill 302 66 39 302 144 39 air
execute in minecraft:overworld run fill 302 58 40 302 62 40 stone
execute in minecraft:overworld run fill 302 63 40 302 64 40 dirt
execute in minecraft:overworld run setblock 302 65 40 grass_block
execute in minecraft:overworld run fill 302 66 40 302 144 40 air
execute in minecraft:overworld run fill 302 58 41 302 62 41 stone
execute in minecraft:overworld run fill 302 63 41 302 64 41 dirt
execute in minecraft:overworld run setblock 302 65 41 coarse_dirt
execute in minecraft:overworld run fill 302 66 41 302 144 41 air
execute in minecraft:overworld run fill 302 58 42 302 62 42 stone
execute in minecraft:overworld run fill 302 63 42 302 64 42 dirt
execute in minecraft:overworld run setblock 302 65 42 grass_block
execute in minecraft:overworld run fill 302 66 42 302 144 42 air
execute in minecraft:overworld run fill 302 58 43 302 62 43 stone
execute in minecraft:overworld run fill 302 63 43 302 64 43 dirt
execute in minecraft:overworld run setblock 302 65 43 grass_block
execute in minecraft:overworld run fill 302 66 43 302 144 43 air
execute in minecraft:overworld run fill 302 58 44 302 62 44 stone
execute in minecraft:overworld run fill 302 63 44 302 64 44 dirt
execute in minecraft:overworld run setblock 302 65 44 grass_block
execute in minecraft:overworld run fill 302 66 44 302 144 44 air
execute in minecraft:overworld run fill 302 58 45 302 61 45 stone
execute in minecraft:overworld run fill 302 62 45 302 63 45 dirt
execute in minecraft:overworld run setblock 302 64 45 coarse_dirt
execute in minecraft:overworld run fill 302 65 45 302 144 45 air
execute in minecraft:overworld run fill 302 58 46 302 61 46 stone
execute in minecraft:overworld run fill 302 62 46 302 63 46 dirt
execute in minecraft:overworld run setblock 302 64 46 coarse_dirt
execute in minecraft:overworld run fill 302 65 46 302 144 46 air
execute in minecraft:overworld run fill 302 58 47 302 61 47 stone
execute in minecraft:overworld run fill 302 62 47 302 63 47 dirt
execute in minecraft:overworld run setblock 302 64 47 grass_block
execute in minecraft:overworld run fill 302 65 47 302 144 47 air
execute in minecraft:overworld run fill 303 58 -48 303 61 -48 stone
execute in minecraft:overworld run fill 303 62 -48 303 63 -48 dirt
execute in minecraft:overworld run setblock 303 64 -48 coarse_dirt
execute in minecraft:overworld run fill 303 65 -48 303 144 -48 air
execute in minecraft:overworld run fill 303 58 -47 303 63 -47 stone
execute in minecraft:overworld run fill 303 64 -47 303 65 -47 dirt
execute in minecraft:overworld run setblock 303 66 -47 coarse_dirt
execute in minecraft:overworld run fill 303 67 -47 303 144 -47 air
execute in minecraft:overworld run fill 303 58 -46 303 63 -46 stone
execute in minecraft:overworld run fill 303 64 -46 303 65 -46 dirt
execute in minecraft:overworld run setblock 303 66 -46 grass_block
execute in minecraft:overworld run fill 303 67 -46 303 144 -46 air
execute in minecraft:overworld run fill 303 58 -45 303 63 -45 stone
execute in minecraft:overworld run fill 303 64 -45 303 65 -45 dirt
execute in minecraft:overworld run setblock 303 66 -45 coarse_dirt
execute in minecraft:overworld run fill 303 67 -45 303 144 -45 air
execute in minecraft:overworld run fill 303 58 -44 303 63 -44 stone
execute in minecraft:overworld run fill 303 64 -44 303 65 -44 dirt
execute in minecraft:overworld run setblock 303 66 -44 coarse_dirt
execute in minecraft:overworld run fill 303 67 -44 303 144 -44 air
execute in minecraft:overworld run fill 303 58 -43 303 63 -43 stone
execute in minecraft:overworld run fill 303 64 -43 303 65 -43 dirt
execute in minecraft:overworld run setblock 303 66 -43 coarse_dirt
execute in minecraft:overworld run fill 303 67 -43 303 144 -43 air
execute in minecraft:overworld run fill 303 58 -42 303 63 -42 stone
execute in minecraft:overworld run fill 303 64 -42 303 65 -42 dirt
execute in minecraft:overworld run setblock 303 66 -42 coarse_dirt
execute in minecraft:overworld run fill 303 67 -42 303 144 -42 air
execute in minecraft:overworld run fill 303 58 -41 303 63 -41 stone
execute in minecraft:overworld run fill 303 64 -41 303 65 -41 dirt
execute in minecraft:overworld run setblock 303 66 -41 coarse_dirt
execute in minecraft:overworld run fill 303 67 -41 303 144 -41 air
execute in minecraft:overworld run fill 303 58 -40 303 63 -40 stone
execute in minecraft:overworld run fill 303 64 -40 303 65 -40 dirt
execute in minecraft:overworld run setblock 303 66 -40 coarse_dirt
execute in minecraft:overworld run fill 303 67 -40 303 144 -40 air
execute in minecraft:overworld run fill 303 58 -39 303 63 -39 stone
execute in minecraft:overworld run fill 303 64 -39 303 65 -39 dirt
execute in minecraft:overworld run setblock 303 66 -39 coarse_dirt
execute in minecraft:overworld run fill 303 67 -39 303 144 -39 air
execute in minecraft:overworld run fill 303 58 -38 303 63 -38 stone
execute in minecraft:overworld run fill 303 64 -38 303 65 -38 dirt
execute in minecraft:overworld run setblock 303 66 -38 grass_block
execute in minecraft:overworld run fill 303 67 -38 303 144 -38 air
execute in minecraft:overworld run fill 303 58 -37 303 63 -37 stone
execute in minecraft:overworld run fill 303 64 -37 303 65 -37 dirt
execute in minecraft:overworld run setblock 303 66 -37 coarse_dirt
execute in minecraft:overworld run fill 303 67 -37 303 144 -37 air
execute in minecraft:overworld run fill 303 58 -36 303 63 -36 stone
execute in minecraft:overworld run fill 303 64 -36 303 65 -36 dirt
execute in minecraft:overworld run setblock 303 66 -36 coarse_dirt
execute in minecraft:overworld run fill 303 67 -36 303 144 -36 air
execute in minecraft:overworld run fill 303 58 -35 303 63 -35 stone
execute in minecraft:overworld run fill 303 64 -35 303 65 -35 dirt
execute in minecraft:overworld run setblock 303 66 -35 coarse_dirt
execute in minecraft:overworld run fill 303 67 -35 303 144 -35 air
execute in minecraft:overworld run fill 303 58 -34 303 63 -34 stone
execute in minecraft:overworld run fill 303 64 -34 303 65 -34 dirt
execute in minecraft:overworld run setblock 303 66 -34 coarse_dirt
execute in minecraft:overworld run fill 303 67 -34 303 144 -34 air
execute in minecraft:overworld run fill 303 58 -33 303 63 -33 stone
execute in minecraft:overworld run fill 303 64 -33 303 65 -33 dirt
execute in minecraft:overworld run setblock 303 66 -33 coarse_dirt
execute in minecraft:overworld run fill 303 67 -33 303 144 -33 air
execute in minecraft:overworld run fill 303 58 -32 303 63 -32 stone
execute in minecraft:overworld run fill 303 64 -32 303 65 -32 dirt
execute in minecraft:overworld run setblock 303 66 -32 coarse_dirt
execute in minecraft:overworld run fill 303 67 -32 303 144 -32 air
execute in minecraft:overworld run fill 303 58 -31 303 62 -31 stone
execute in minecraft:overworld run fill 303 63 -31 303 64 -31 dirt
execute in minecraft:overworld run setblock 303 65 -31 coarse_dirt
execute in minecraft:overworld run fill 303 66 -31 303 144 -31 air
execute in minecraft:overworld run fill 303 58 -30 303 62 -30 stone
execute in minecraft:overworld run fill 303 63 -30 303 64 -30 dirt
execute in minecraft:overworld run setblock 303 65 -30 grass_block
execute in minecraft:overworld run fill 303 66 -30 303 144 -30 air
execute in minecraft:overworld run fill 303 58 -29 303 62 -29 stone
execute in minecraft:overworld run fill 303 63 -29 303 64 -29 dirt
execute in minecraft:overworld run setblock 303 65 -29 coarse_dirt
execute in minecraft:overworld run fill 303 66 -29 303 144 -29 air
execute in minecraft:overworld run fill 303 58 -28 303 62 -28 stone
execute in minecraft:overworld run fill 303 63 -28 303 64 -28 dirt
execute in minecraft:overworld run setblock 303 65 -28 coarse_dirt
execute in minecraft:overworld run fill 303 66 -28 303 144 -28 air
execute in minecraft:overworld run fill 303 58 -27 303 62 -27 stone
execute in minecraft:overworld run fill 303 63 -27 303 64 -27 dirt
execute in minecraft:overworld run setblock 303 65 -27 coarse_dirt
execute in minecraft:overworld run fill 303 66 -27 303 144 -27 air
execute in minecraft:overworld run fill 303 58 -26 303 62 -26 stone
execute in minecraft:overworld run fill 303 63 -26 303 64 -26 dirt
execute in minecraft:overworld run setblock 303 65 -26 coarse_dirt
execute in minecraft:overworld run fill 303 66 -26 303 144 -26 air
execute in minecraft:overworld run fill 303 58 -25 303 62 -25 stone
execute in minecraft:overworld run fill 303 63 -25 303 64 -25 dirt
execute in minecraft:overworld run setblock 303 65 -25 coarse_dirt
execute in minecraft:overworld run fill 303 66 -25 303 144 -25 air
execute in minecraft:overworld run fill 303 58 -24 303 62 -24 stone
execute in minecraft:overworld run fill 303 63 -24 303 64 -24 dirt
execute in minecraft:overworld run setblock 303 65 -24 coarse_dirt
execute in minecraft:overworld run fill 303 66 -24 303 144 -24 air
execute in minecraft:overworld run fill 303 58 -23 303 62 -23 stone
execute in minecraft:overworld run fill 303 63 -23 303 64 -23 dirt
execute in minecraft:overworld run setblock 303 65 -23 coarse_dirt
execute in minecraft:overworld run fill 303 66 -23 303 144 -23 air
execute in minecraft:overworld run fill 303 58 -22 303 62 -22 stone
execute in minecraft:overworld run fill 303 63 -22 303 64 -22 dirt
execute in minecraft:overworld run setblock 303 65 -22 coarse_dirt
execute in minecraft:overworld run fill 303 66 -22 303 144 -22 air
execute in minecraft:overworld run fill 303 58 -21 303 62 -21 stone
execute in minecraft:overworld run fill 303 63 -21 303 64 -21 dirt
execute in minecraft:overworld run setblock 303 65 -21 grass_block
execute in minecraft:overworld run fill 303 66 -21 303 144 -21 air
execute in minecraft:overworld run fill 303 58 -20 303 62 -20 stone
execute in minecraft:overworld run fill 303 63 -20 303 64 -20 dirt
execute in minecraft:overworld run setblock 303 65 -20 coarse_dirt
execute in minecraft:overworld run fill 303 66 -20 303 144 -20 air
execute in minecraft:overworld run fill 303 58 -19 303 62 -19 stone
execute in minecraft:overworld run fill 303 63 -19 303 64 -19 dirt
execute in minecraft:overworld run setblock 303 65 -19 coarse_dirt
execute in minecraft:overworld run fill 303 66 -19 303 144 -19 air
execute in minecraft:overworld run fill 303 58 -18 303 62 -18 stone
execute in minecraft:overworld run fill 303 63 -18 303 64 -18 dirt
execute in minecraft:overworld run setblock 303 65 -18 coarse_dirt
execute in minecraft:overworld run fill 303 66 -18 303 144 -18 air
execute in minecraft:overworld run fill 303 58 -17 303 62 -17 stone
execute in minecraft:overworld run fill 303 63 -17 303 64 -17 dirt
execute in minecraft:overworld run setblock 303 65 -17 grass_block
execute in minecraft:overworld run fill 303 66 -17 303 144 -17 air
execute in minecraft:overworld run fill 303 58 -16 303 62 -16 stone
execute in minecraft:overworld run fill 303 63 -16 303 64 -16 dirt
execute in minecraft:overworld run setblock 303 65 -16 grass_block
execute in minecraft:overworld run fill 303 66 -16 303 144 -16 air
execute in minecraft:overworld run fill 303 58 -15 303 62 -15 stone
execute in minecraft:overworld run fill 303 63 -15 303 64 -15 dirt
execute in minecraft:overworld run setblock 303 65 -15 coarse_dirt
execute in minecraft:overworld run fill 303 66 -15 303 144 -15 air
execute in minecraft:overworld run fill 303 58 -14 303 62 -14 stone
execute in minecraft:overworld run fill 303 63 -14 303 64 -14 dirt
execute in minecraft:overworld run setblock 303 65 -14 grass_block
execute in minecraft:overworld run fill 303 66 -14 303 144 -14 air
execute in minecraft:overworld run fill 303 58 -13 303 62 -13 stone
execute in minecraft:overworld run fill 303 63 -13 303 64 -13 dirt
execute in minecraft:overworld run setblock 303 65 -13 coarse_dirt
execute in minecraft:overworld run fill 303 66 -13 303 144 -13 air
execute in minecraft:overworld run fill 303 58 -12 303 62 -12 stone
execute in minecraft:overworld run fill 303 63 -12 303 64 -12 dirt
execute in minecraft:overworld run setblock 303 65 -12 coarse_dirt
execute in minecraft:overworld run fill 303 66 -12 303 144 -12 air
execute in minecraft:overworld run fill 303 58 -11 303 62 -11 stone
execute in minecraft:overworld run fill 303 63 -11 303 64 -11 dirt
execute in minecraft:overworld run setblock 303 65 -11 coarse_dirt
execute in minecraft:overworld run fill 303 66 -11 303 144 -11 air
execute in minecraft:overworld run fill 303 58 -10 303 62 -10 stone
execute in minecraft:overworld run fill 303 63 -10 303 64 -10 dirt
execute in minecraft:overworld run setblock 303 65 -10 coarse_dirt
execute in minecraft:overworld run fill 303 66 -10 303 144 -10 air
execute in minecraft:overworld run fill 303 58 -9 303 62 -9 stone
execute in minecraft:overworld run fill 303 63 -9 303 64 -9 dirt
execute in minecraft:overworld run setblock 303 65 -9 coarse_dirt
execute in minecraft:overworld run fill 303 66 -9 303 144 -9 air
execute in minecraft:overworld run fill 303 58 -8 303 62 -8 stone
execute in minecraft:overworld run fill 303 63 -8 303 64 -8 dirt
execute in minecraft:overworld run setblock 303 65 -8 grass_block
execute in minecraft:overworld run fill 303 66 -8 303 144 -8 air
execute in minecraft:overworld run fill 303 58 -7 303 62 -7 stone
schedule function blade_gallery:random/burned/part_150 1t replace
