execute in minecraft:overworld run fill 254 58 20 254 64 20 stone
execute in minecraft:overworld run fill 254 65 20 254 66 20 dirt
execute in minecraft:overworld run setblock 254 67 20 grass_block
execute in minecraft:overworld run fill 254 68 20 254 144 20 air
execute in minecraft:overworld run fill 254 58 21 254 64 21 stone
execute in minecraft:overworld run fill 254 65 21 254 66 21 dirt
execute in minecraft:overworld run setblock 254 67 21 coarse_dirt
execute in minecraft:overworld run fill 254 68 21 254 144 21 air
execute in minecraft:overworld run fill 254 58 22 254 64 22 stone
execute in minecraft:overworld run fill 254 65 22 254 66 22 dirt
execute in minecraft:overworld run setblock 254 67 22 grass_block
execute in minecraft:overworld run fill 254 68 22 254 144 22 air
execute in minecraft:overworld run fill 254 58 23 254 64 23 stone
execute in minecraft:overworld run fill 254 65 23 254 66 23 dirt
execute in minecraft:overworld run setblock 254 67 23 coarse_dirt
execute in minecraft:overworld run fill 254 68 23 254 144 23 air
execute in minecraft:overworld run setblock 254 68 23 grass
execute in minecraft:overworld run fill 254 58 24 254 64 24 stone
execute in minecraft:overworld run fill 254 65 24 254 66 24 dirt
execute in minecraft:overworld run setblock 254 67 24 grass_block
execute in minecraft:overworld run fill 254 68 24 254 144 24 air
execute in minecraft:overworld run fill 254 58 25 254 64 25 stone
execute in minecraft:overworld run fill 254 65 25 254 66 25 dirt
execute in minecraft:overworld run setblock 254 67 25 coarse_dirt
execute in minecraft:overworld run fill 254 68 25 254 144 25 air
execute in minecraft:overworld run fill 254 58 26 254 64 26 stone
execute in minecraft:overworld run fill 254 65 26 254 66 26 dirt
execute in minecraft:overworld run setblock 254 67 26 coarse_dirt
execute in minecraft:overworld run fill 254 68 26 254 144 26 air
execute in minecraft:overworld run fill 254 58 27 254 64 27 stone
execute in minecraft:overworld run fill 254 65 27 254 66 27 dirt
execute in minecraft:overworld run setblock 254 67 27 coarse_dirt
execute in minecraft:overworld run fill 254 68 27 254 144 27 air
execute in minecraft:overworld run setblock 254 68 27 grass
execute in minecraft:overworld run fill 254 58 28 254 64 28 stone
execute in minecraft:overworld run fill 254 65 28 254 66 28 dirt
execute in minecraft:overworld run setblock 254 67 28 grass_block
execute in minecraft:overworld run fill 254 68 28 254 144 28 air
execute in minecraft:overworld run setblock 254 68 28 grass
execute in minecraft:overworld run fill 254 58 29 254 64 29 stone
execute in minecraft:overworld run fill 254 65 29 254 66 29 dirt
execute in minecraft:overworld run setblock 254 67 29 coarse_dirt
execute in minecraft:overworld run fill 254 68 29 254 144 29 air
execute in minecraft:overworld run fill 254 58 30 254 64 30 stone
execute in minecraft:overworld run fill 254 65 30 254 66 30 dirt
execute in minecraft:overworld run setblock 254 67 30 grass_block
execute in minecraft:overworld run fill 254 68 30 254 144 30 air
execute in minecraft:overworld run fill 254 58 31 254 64 31 stone
execute in minecraft:overworld run fill 254 65 31 254 66 31 dirt
execute in minecraft:overworld run setblock 254 67 31 coarse_dirt
execute in minecraft:overworld run fill 254 68 31 254 144 31 air
execute in minecraft:overworld run fill 254 58 32 254 64 32 stone
execute in minecraft:overworld run fill 254 65 32 254 66 32 dirt
execute in minecraft:overworld run setblock 254 67 32 coarse_dirt
execute in minecraft:overworld run fill 254 68 32 254 144 32 air
execute in minecraft:overworld run fill 254 58 33 254 63 33 stone
execute in minecraft:overworld run fill 254 64 33 254 65 33 dirt
execute in minecraft:overworld run setblock 254 66 33 coarse_dirt
execute in minecraft:overworld run fill 254 67 33 254 144 33 air
execute in minecraft:overworld run setblock 254 67 33 grass
execute in minecraft:overworld run fill 254 58 34 254 63 34 stone
execute in minecraft:overworld run fill 254 64 34 254 65 34 dirt
execute in minecraft:overworld run setblock 254 66 34 grass_block
execute in minecraft:overworld run fill 254 67 34 254 144 34 air
execute in minecraft:overworld run setblock 254 67 34 grass
execute in minecraft:overworld run fill 254 58 35 254 63 35 stone
execute in minecraft:overworld run fill 254 64 35 254 65 35 dirt
execute in minecraft:overworld run setblock 254 66 35 coarse_dirt
execute in minecraft:overworld run fill 254 67 35 254 144 35 air
execute in minecraft:overworld run setblock 254 67 35 grass
execute in minecraft:overworld run fill 254 58 36 254 62 36 stone
execute in minecraft:overworld run fill 254 63 36 254 64 36 dirt
execute in minecraft:overworld run setblock 254 65 36 coarse_dirt
execute in minecraft:overworld run fill 254 66 36 254 144 36 air
execute in minecraft:overworld run fill 254 58 37 254 62 37 stone
execute in minecraft:overworld run fill 254 63 37 254 64 37 dirt
execute in minecraft:overworld run setblock 254 65 37 coarse_dirt
execute in minecraft:overworld run fill 254 66 37 254 144 37 air
execute in minecraft:overworld run fill 254 58 38 254 61 38 stone
execute in minecraft:overworld run fill 254 62 38 254 63 38 dirt
execute in minecraft:overworld run setblock 254 64 38 coarse_dirt
execute in minecraft:overworld run fill 254 65 38 254 144 38 air
execute in minecraft:overworld run fill 254 58 39 254 60 39 stone
execute in minecraft:overworld run fill 254 61 39 254 62 39 dirt
execute in minecraft:overworld run setblock 254 63 39 gravel
execute in minecraft:overworld run fill 254 64 39 254 144 39 air
execute in minecraft:overworld run fill 254 64 39 254 64 39 water
execute in minecraft:overworld run fill 254 58 40 254 60 40 stone
execute in minecraft:overworld run fill 254 61 40 254 62 40 dirt
execute in minecraft:overworld run setblock 254 63 40 gravel
execute in minecraft:overworld run fill 254 64 40 254 144 40 air
execute in minecraft:overworld run fill 254 64 40 254 64 40 water
execute in minecraft:overworld run fill 254 58 41 254 60 41 stone
execute in minecraft:overworld run fill 254 61 41 254 62 41 dirt
execute in minecraft:overworld run setblock 254 63 41 gravel
execute in minecraft:overworld run fill 254 64 41 254 144 41 air
execute in minecraft:overworld run fill 254 64 41 254 64 41 water
execute in minecraft:overworld run fill 254 58 42 254 59 42 stone
execute in minecraft:overworld run fill 254 60 42 254 61 42 dirt
execute in minecraft:overworld run setblock 254 62 42 gravel
execute in minecraft:overworld run fill 254 63 42 254 144 42 air
execute in minecraft:overworld run fill 254 63 42 254 64 42 water
execute in minecraft:overworld run fill 254 58 43 254 59 43 stone
execute in minecraft:overworld run fill 254 60 43 254 61 43 dirt
execute in minecraft:overworld run setblock 254 62 43 gravel
execute in minecraft:overworld run fill 254 63 43 254 144 43 air
execute in minecraft:overworld run fill 254 63 43 254 64 43 water
execute in minecraft:overworld run fill 254 58 44 254 59 44 stone
execute in minecraft:overworld run fill 254 60 44 254 61 44 dirt
execute in minecraft:overworld run setblock 254 62 44 gravel
execute in minecraft:overworld run fill 254 63 44 254 144 44 air
execute in minecraft:overworld run fill 254 63 44 254 64 44 water
execute in minecraft:overworld run fill 254 58 45 254 60 45 stone
execute in minecraft:overworld run fill 254 61 45 254 62 45 dirt
execute in minecraft:overworld run setblock 254 63 45 gravel
execute in minecraft:overworld run fill 254 64 45 254 144 45 air
execute in minecraft:overworld run fill 254 64 45 254 64 45 water
execute in minecraft:overworld run fill 254 58 46 254 60 46 stone
execute in minecraft:overworld run fill 254 61 46 254 62 46 dirt
execute in minecraft:overworld run setblock 254 63 46 gravel
execute in minecraft:overworld run fill 254 64 46 254 144 46 air
execute in minecraft:overworld run fill 254 64 46 254 64 46 water
execute in minecraft:overworld run fill 254 58 47 254 60 47 stone
execute in minecraft:overworld run fill 254 61 47 254 62 47 dirt
execute in minecraft:overworld run setblock 254 63 47 gravel
execute in minecraft:overworld run fill 254 64 47 254 144 47 air
execute in minecraft:overworld run fill 254 64 47 254 64 47 water
execute in minecraft:overworld run fill 255 58 -48 255 61 -48 stone
execute in minecraft:overworld run fill 255 62 -48 255 63 -48 dirt
execute in minecraft:overworld run setblock 255 64 -48 coarse_dirt
execute in minecraft:overworld run fill 255 65 -48 255 144 -48 air
execute in minecraft:overworld run fill 255 58 -47 255 62 -47 stone
execute in minecraft:overworld run fill 255 63 -47 255 64 -47 dirt
execute in minecraft:overworld run setblock 255 65 -47 coarse_dirt
execute in minecraft:overworld run fill 255 66 -47 255 144 -47 air
execute in minecraft:overworld run fill 255 58 -46 255 64 -46 stone
execute in minecraft:overworld run fill 255 65 -46 255 66 -46 dirt
execute in minecraft:overworld run setblock 255 67 -46 coarse_dirt
execute in minecraft:overworld run fill 255 68 -46 255 144 -46 air
execute in minecraft:overworld run fill 255 58 -45 255 65 -45 stone
execute in minecraft:overworld run fill 255 66 -45 255 67 -45 dirt
execute in minecraft:overworld run setblock 255 68 -45 coarse_dirt
execute in minecraft:overworld run fill 255 69 -45 255 144 -45 air
execute in minecraft:overworld run fill 255 58 -44 255 66 -44 stone
execute in minecraft:overworld run fill 255 67 -44 255 68 -44 dirt
execute in minecraft:overworld run setblock 255 69 -44 coarse_dirt
execute in minecraft:overworld run fill 255 70 -44 255 144 -44 air
execute in minecraft:overworld run fill 255 58 -43 255 68 -43 stone
execute in minecraft:overworld run fill 255 69 -43 255 70 -43 dirt
execute in minecraft:overworld run setblock 255 71 -43 coarse_dirt
execute in minecraft:overworld run fill 255 72 -43 255 144 -43 air
execute in minecraft:overworld run fill 255 58 -42 255 69 -42 stone
execute in minecraft:overworld run fill 255 70 -42 255 71 -42 dirt
execute in minecraft:overworld run setblock 255 72 -42 coarse_dirt
execute in minecraft:overworld run fill 255 73 -42 255 144 -42 air
execute in minecraft:overworld run fill 255 58 -41 255 70 -41 stone
execute in minecraft:overworld run fill 255 71 -41 255 72 -41 dirt
execute in minecraft:overworld run setblock 255 73 -41 grass_block
execute in minecraft:overworld run fill 255 74 -41 255 144 -41 air
execute in minecraft:overworld run fill 255 58 -40 255 71 -40 stone
execute in minecraft:overworld run fill 255 72 -40 255 73 -40 dirt
execute in minecraft:overworld run setblock 255 74 -40 coarse_dirt
execute in minecraft:overworld run fill 255 75 -40 255 144 -40 air
execute in minecraft:overworld run setblock 255 75 -40 grass
execute in minecraft:overworld run fill 255 58 -39 255 72 -39 stone
execute in minecraft:overworld run fill 255 73 -39 255 74 -39 dirt
execute in minecraft:overworld run setblock 255 75 -39 coarse_dirt
execute in minecraft:overworld run fill 255 76 -39 255 144 -39 air
execute in minecraft:overworld run fill 255 58 -38 255 73 -38 stone
execute in minecraft:overworld run fill 255 74 -38 255 75 -38 dirt
execute in minecraft:overworld run setblock 255 76 -38 coarse_dirt
execute in minecraft:overworld run fill 255 77 -38 255 144 -38 air
execute in minecraft:overworld run fill 255 58 -37 255 73 -37 stone
execute in minecraft:overworld run fill 255 74 -37 255 75 -37 dirt
execute in minecraft:overworld run setblock 255 76 -37 coarse_dirt
execute in minecraft:overworld run fill 255 77 -37 255 144 -37 air
execute in minecraft:overworld run fill 255 58 -36 255 72 -36 stone
execute in minecraft:overworld run fill 255 73 -36 255 74 -36 dirt
execute in minecraft:overworld run setblock 255 75 -36 coarse_dirt
execute in minecraft:overworld run fill 255 76 -36 255 144 -36 air
execute in minecraft:overworld run setblock 255 76 -36 grass
execute in minecraft:overworld run fill 255 58 -35 255 72 -35 stone
execute in minecraft:overworld run fill 255 73 -35 255 74 -35 dirt
execute in minecraft:overworld run setblock 255 75 -35 coarse_dirt
execute in minecraft:overworld run fill 255 76 -35 255 144 -35 air
execute in minecraft:overworld run fill 255 58 -34 255 71 -34 stone
execute in minecraft:overworld run fill 255 72 -34 255 73 -34 dirt
execute in minecraft:overworld run setblock 255 74 -34 coarse_dirt
execute in minecraft:overworld run fill 255 75 -34 255 144 -34 air
execute in minecraft:overworld run fill 255 58 -33 255 71 -33 stone
execute in minecraft:overworld run fill 255 72 -33 255 73 -33 dirt
execute in minecraft:overworld run setblock 255 74 -33 coarse_dirt
execute in minecraft:overworld run fill 255 75 -33 255 144 -33 air
execute in minecraft:overworld run fill 255 58 -32 255 70 -32 stone
execute in minecraft:overworld run fill 255 71 -32 255 72 -32 dirt
execute in minecraft:overworld run setblock 255 73 -32 grass_block
execute in minecraft:overworld run fill 255 74 -32 255 144 -32 air
execute in minecraft:overworld run fill 255 58 -31 255 70 -31 stone
execute in minecraft:overworld run fill 255 71 -31 255 72 -31 dirt
execute in minecraft:overworld run setblock 255 73 -31 grass_block
execute in minecraft:overworld run fill 255 74 -31 255 144 -31 air
execute in minecraft:overworld run fill 255 58 -30 255 70 -30 stone
execute in minecraft:overworld run fill 255 71 -30 255 72 -30 dirt
execute in minecraft:overworld run setblock 255 73 -30 grass_block
execute in minecraft:overworld run fill 255 74 -30 255 144 -30 air
execute in minecraft:overworld run fill 255 58 -29 255 69 -29 stone
execute in minecraft:overworld run fill 255 70 -29 255 71 -29 dirt
execute in minecraft:overworld run setblock 255 72 -29 coarse_dirt
execute in minecraft:overworld run fill 255 73 -29 255 144 -29 air
execute in minecraft:overworld run fill 255 58 -28 255 68 -28 stone
execute in minecraft:overworld run fill 255 69 -28 255 70 -28 dirt
execute in minecraft:overworld run setblock 255 71 -28 grass_block
execute in minecraft:overworld run fill 255 72 -28 255 144 -28 air
execute in minecraft:overworld run fill 255 58 -27 255 68 -27 stone
execute in minecraft:overworld run fill 255 69 -27 255 70 -27 dirt
execute in minecraft:overworld run setblock 255 71 -27 coarse_dirt
execute in minecraft:overworld run fill 255 72 -27 255 144 -27 air
execute in minecraft:overworld run fill 255 58 -26 255 67 -26 stone
execute in minecraft:overworld run fill 255 68 -26 255 69 -26 dirt
execute in minecraft:overworld run setblock 255 70 -26 grass_block
execute in minecraft:overworld run fill 255 71 -26 255 144 -26 air
execute in minecraft:overworld run setblock 255 71 -26 grass
execute in minecraft:overworld run fill 255 58 -25 255 66 -25 stone
execute in minecraft:overworld run fill 255 67 -25 255 68 -25 dirt
execute in minecraft:overworld run setblock 255 69 -25 coarse_dirt
execute in minecraft:overworld run fill 255 70 -25 255 144 -25 air
execute in minecraft:overworld run fill 255 58 -24 255 66 -24 stone
execute in minecraft:overworld run fill 255 67 -24 255 68 -24 dirt
execute in minecraft:overworld run setblock 255 69 -24 coarse_dirt
execute in minecraft:overworld run fill 255 70 -24 255 144 -24 air
execute in minecraft:overworld run fill 255 58 -23 255 65 -23 stone
execute in minecraft:overworld run fill 255 66 -23 255 67 -23 dirt
execute in minecraft:overworld run setblock 255 68 -23 coarse_dirt
execute in minecraft:overworld run fill 255 69 -23 255 144 -23 air
execute in minecraft:overworld run fill 255 58 -22 255 64 -22 stone
execute in minecraft:overworld run fill 255 65 -22 255 66 -22 dirt
execute in minecraft:overworld run setblock 255 67 -22 coarse_dirt
execute in minecraft:overworld run fill 255 68 -22 255 144 -22 air
execute in minecraft:overworld run fill 255 58 -21 255 63 -21 stone
execute in minecraft:overworld run fill 255 64 -21 255 65 -21 dirt
execute in minecraft:overworld run setblock 255 66 -21 coarse_dirt
execute in minecraft:overworld run fill 255 67 -21 255 144 -21 air
execute in minecraft:overworld run fill 255 58 -20 255 63 -20 stone
execute in minecraft:overworld run fill 255 64 -20 255 65 -20 dirt
execute in minecraft:overworld run setblock 255 66 -20 coarse_dirt
execute in minecraft:overworld run fill 255 67 -20 255 144 -20 air
execute in minecraft:overworld run fill 255 58 -19 255 62 -19 stone
execute in minecraft:overworld run fill 255 63 -19 255 64 -19 dirt
execute in minecraft:overworld run setblock 255 65 -19 coarse_dirt
execute in minecraft:overworld run fill 255 66 -19 255 144 -19 air
execute in minecraft:overworld run fill 255 58 -18 255 62 -18 stone
execute in minecraft:overworld run fill 255 63 -18 255 64 -18 dirt
execute in minecraft:overworld run setblock 255 65 -18 grass_block
execute in minecraft:overworld run fill 255 66 -18 255 144 -18 air
execute in minecraft:overworld run fill 255 58 -17 255 61 -17 stone
execute in minecraft:overworld run fill 255 62 -17 255 63 -17 dirt
schedule function blade_gallery:random/burned/part_73 1t replace
