execute in minecraft:overworld run fill 424 66 10 424 67 10 dirt
execute in minecraft:overworld run setblock 424 68 10 grass_block
execute in minecraft:overworld run fill 424 69 10 424 144 10 air
execute in minecraft:overworld run fill 424 58 11 424 65 11 stone
execute in minecraft:overworld run fill 424 66 11 424 67 11 dirt
execute in minecraft:overworld run setblock 424 68 11 coarse_dirt
execute in minecraft:overworld run fill 424 69 11 424 144 11 air
execute in minecraft:overworld run fill 424 58 12 424 66 12 stone
execute in minecraft:overworld run fill 424 67 12 424 68 12 dirt
execute in minecraft:overworld run setblock 424 69 12 coarse_dirt
execute in minecraft:overworld run fill 424 70 12 424 144 12 air
execute in minecraft:overworld run fill 424 58 13 424 66 13 stone
execute in minecraft:overworld run fill 424 67 13 424 68 13 dirt
execute in minecraft:overworld run setblock 424 69 13 grass_block
execute in minecraft:overworld run fill 424 70 13 424 144 13 air
execute in minecraft:overworld run fill 424 58 14 424 67 14 stone
execute in minecraft:overworld run fill 424 68 14 424 69 14 dirt
execute in minecraft:overworld run setblock 424 70 14 coarse_dirt
execute in minecraft:overworld run fill 424 71 14 424 144 14 air
execute in minecraft:overworld run fill 424 58 15 424 67 15 stone
execute in minecraft:overworld run fill 424 68 15 424 69 15 dirt
execute in minecraft:overworld run setblock 424 70 15 coarse_dirt
execute in minecraft:overworld run fill 424 71 15 424 144 15 air
execute in minecraft:overworld run fill 424 58 16 424 67 16 stone
execute in minecraft:overworld run fill 424 68 16 424 69 16 dirt
execute in minecraft:overworld run setblock 424 70 16 coarse_dirt
execute in minecraft:overworld run fill 424 71 16 424 144 16 air
execute in minecraft:overworld run fill 424 58 17 424 68 17 stone
execute in minecraft:overworld run fill 424 69 17 424 70 17 dirt
execute in minecraft:overworld run setblock 424 71 17 coarse_dirt
execute in minecraft:overworld run fill 424 72 17 424 144 17 air
execute in minecraft:overworld run fill 424 58 18 424 68 18 stone
execute in minecraft:overworld run fill 424 69 18 424 70 18 dirt
execute in minecraft:overworld run setblock 424 71 18 coarse_dirt
execute in minecraft:overworld run fill 424 72 18 424 144 18 air
execute in minecraft:overworld run fill 424 58 19 424 68 19 stone
execute in minecraft:overworld run fill 424 69 19 424 70 19 dirt
execute in minecraft:overworld run setblock 424 71 19 coarse_dirt
execute in minecraft:overworld run fill 424 72 19 424 144 19 air
execute in minecraft:overworld run fill 424 58 20 424 68 20 stone
execute in minecraft:overworld run fill 424 69 20 424 70 20 dirt
execute in minecraft:overworld run setblock 424 71 20 coarse_dirt
execute in minecraft:overworld run fill 424 72 20 424 144 20 air
execute in minecraft:overworld run fill 424 58 21 424 69 21 stone
execute in minecraft:overworld run fill 424 70 21 424 71 21 dirt
execute in minecraft:overworld run setblock 424 72 21 coarse_dirt
execute in minecraft:overworld run fill 424 73 21 424 144 21 air
execute in minecraft:overworld run fill 424 58 22 424 69 22 stone
execute in minecraft:overworld run fill 424 70 22 424 71 22 dirt
execute in minecraft:overworld run setblock 424 72 22 coarse_dirt
execute in minecraft:overworld run fill 424 73 22 424 144 22 air
execute in minecraft:overworld run fill 424 58 23 424 69 23 stone
execute in minecraft:overworld run fill 424 70 23 424 71 23 dirt
execute in minecraft:overworld run setblock 424 72 23 coarse_dirt
execute in minecraft:overworld run fill 424 73 23 424 144 23 air
execute in minecraft:overworld run fill 424 58 24 424 69 24 stone
execute in minecraft:overworld run fill 424 70 24 424 71 24 dirt
execute in minecraft:overworld run setblock 424 72 24 grass_block
execute in minecraft:overworld run fill 424 73 24 424 144 24 air
execute in minecraft:overworld run fill 424 58 25 424 69 25 stone
execute in minecraft:overworld run fill 424 70 25 424 71 25 dirt
execute in minecraft:overworld run setblock 424 72 25 coarse_dirt
execute in minecraft:overworld run fill 424 73 25 424 144 25 air
execute in minecraft:overworld run fill 424 58 26 424 69 26 stone
execute in minecraft:overworld run fill 424 70 26 424 71 26 dirt
execute in minecraft:overworld run setblock 424 72 26 coarse_dirt
execute in minecraft:overworld run fill 424 73 26 424 144 26 air
execute in minecraft:overworld run fill 424 58 27 424 69 27 stone
execute in minecraft:overworld run fill 424 70 27 424 71 27 dirt
execute in minecraft:overworld run setblock 424 72 27 coarse_dirt
execute in minecraft:overworld run fill 424 73 27 424 144 27 air
execute in minecraft:overworld run fill 424 58 28 424 69 28 stone
execute in minecraft:overworld run fill 424 70 28 424 71 28 dirt
execute in minecraft:overworld run setblock 424 72 28 coarse_dirt
execute in minecraft:overworld run fill 424 73 28 424 144 28 air
execute in minecraft:overworld run fill 424 58 29 424 69 29 stone
execute in minecraft:overworld run fill 424 70 29 424 71 29 dirt
execute in minecraft:overworld run setblock 424 72 29 grass_block
execute in minecraft:overworld run fill 424 73 29 424 144 29 air
execute in minecraft:overworld run fill 424 58 30 424 69 30 stone
execute in minecraft:overworld run fill 424 70 30 424 71 30 dirt
execute in minecraft:overworld run setblock 424 72 30 coarse_dirt
execute in minecraft:overworld run fill 424 73 30 424 144 30 air
execute in minecraft:overworld run fill 424 58 31 424 69 31 stone
execute in minecraft:overworld run fill 424 70 31 424 71 31 dirt
execute in minecraft:overworld run setblock 424 72 31 coarse_dirt
execute in minecraft:overworld run fill 424 73 31 424 144 31 air
execute in minecraft:overworld run setblock 424 73 31 grass
execute in minecraft:overworld run fill 424 58 32 424 69 32 stone
execute in minecraft:overworld run fill 424 70 32 424 71 32 dirt
execute in minecraft:overworld run setblock 424 72 32 coarse_dirt
execute in minecraft:overworld run fill 424 73 32 424 144 32 air
execute in minecraft:overworld run setblock 424 73 32 grass
execute in minecraft:overworld run fill 424 58 33 424 69 33 stone
execute in minecraft:overworld run fill 424 70 33 424 71 33 dirt
execute in minecraft:overworld run setblock 424 72 33 coarse_dirt
execute in minecraft:overworld run fill 424 73 33 424 144 33 air
execute in minecraft:overworld run fill 424 58 34 424 69 34 stone
execute in minecraft:overworld run fill 424 70 34 424 71 34 dirt
execute in minecraft:overworld run setblock 424 72 34 grass_block
execute in minecraft:overworld run fill 424 73 34 424 144 34 air
execute in minecraft:overworld run fill 424 58 35 424 68 35 stone
execute in minecraft:overworld run fill 424 69 35 424 70 35 dirt
execute in minecraft:overworld run setblock 424 71 35 coarse_dirt
execute in minecraft:overworld run fill 424 72 35 424 144 35 air
execute in minecraft:overworld run fill 424 58 36 424 68 36 stone
execute in minecraft:overworld run fill 424 69 36 424 70 36 dirt
execute in minecraft:overworld run setblock 424 71 36 coarse_dirt
execute in minecraft:overworld run fill 424 72 36 424 144 36 air
execute in minecraft:overworld run fill 424 58 37 424 68 37 stone
execute in minecraft:overworld run fill 424 69 37 424 70 37 dirt
execute in minecraft:overworld run setblock 424 71 37 coarse_dirt
execute in minecraft:overworld run fill 424 72 37 424 144 37 air
execute in minecraft:overworld run setblock 424 72 37 grass
execute in minecraft:overworld run fill 424 58 38 424 67 38 stone
execute in minecraft:overworld run fill 424 68 38 424 69 38 dirt
execute in minecraft:overworld run setblock 424 70 38 grass_block
execute in minecraft:overworld run fill 424 71 38 424 144 38 air
execute in minecraft:overworld run setblock 424 71 38 grass
execute in minecraft:overworld run fill 424 58 39 424 67 39 stone
execute in minecraft:overworld run fill 424 68 39 424 69 39 dirt
execute in minecraft:overworld run setblock 424 70 39 grass_block
execute in minecraft:overworld run fill 424 71 39 424 144 39 air
execute in minecraft:overworld run setblock 424 71 39 grass
execute in minecraft:overworld run fill 424 58 40 424 66 40 stone
execute in minecraft:overworld run fill 424 67 40 424 68 40 dirt
execute in minecraft:overworld run setblock 424 69 40 grass_block
execute in minecraft:overworld run fill 424 70 40 424 144 40 air
execute in minecraft:overworld run fill 424 58 41 424 65 41 stone
execute in minecraft:overworld run fill 424 66 41 424 67 41 dirt
execute in minecraft:overworld run setblock 424 68 41 coarse_dirt
execute in minecraft:overworld run fill 424 69 41 424 144 41 air
execute in minecraft:overworld run fill 424 58 42 424 64 42 stone
execute in minecraft:overworld run fill 424 65 42 424 66 42 dirt
execute in minecraft:overworld run setblock 424 67 42 grass_block
execute in minecraft:overworld run fill 424 68 42 424 144 42 air
execute in minecraft:overworld run fill 424 58 43 424 63 43 stone
execute in minecraft:overworld run fill 424 64 43 424 65 43 dirt
execute in minecraft:overworld run setblock 424 66 43 coarse_dirt
execute in minecraft:overworld run fill 424 67 43 424 144 43 air
execute in minecraft:overworld run fill 424 58 44 424 62 44 stone
execute in minecraft:overworld run fill 424 63 44 424 64 44 dirt
execute in minecraft:overworld run setblock 424 65 44 coarse_dirt
execute in minecraft:overworld run fill 424 66 44 424 144 44 air
execute in minecraft:overworld run fill 424 58 45 424 62 45 stone
execute in minecraft:overworld run fill 424 63 45 424 64 45 dirt
execute in minecraft:overworld run setblock 424 65 45 coarse_dirt
execute in minecraft:overworld run fill 424 66 45 424 144 45 air
execute in minecraft:overworld run fill 424 58 46 424 61 46 stone
execute in minecraft:overworld run fill 424 62 46 424 63 46 dirt
execute in minecraft:overworld run setblock 424 64 46 coarse_dirt
execute in minecraft:overworld run fill 424 65 46 424 144 46 air
execute in minecraft:overworld run fill 424 58 47 424 61 47 stone
execute in minecraft:overworld run fill 424 62 47 424 63 47 dirt
execute in minecraft:overworld run setblock 424 64 47 coarse_dirt
execute in minecraft:overworld run fill 424 65 47 424 144 47 air
execute in minecraft:overworld run fill 425 58 -48 425 61 -48 stone
execute in minecraft:overworld run fill 425 62 -48 425 63 -48 dirt
execute in minecraft:overworld run setblock 425 64 -48 coarse_dirt
execute in minecraft:overworld run fill 425 65 -48 425 144 -48 air
execute in minecraft:overworld run fill 425 58 -47 425 63 -47 stone
execute in minecraft:overworld run fill 425 64 -47 425 65 -47 dirt
execute in minecraft:overworld run setblock 425 66 -47 coarse_dirt
execute in minecraft:overworld run fill 425 67 -47 425 144 -47 air
execute in minecraft:overworld run fill 425 58 -46 425 64 -46 stone
execute in minecraft:overworld run fill 425 65 -46 425 66 -46 dirt
execute in minecraft:overworld run setblock 425 67 -46 coarse_dirt
execute in minecraft:overworld run fill 425 68 -46 425 144 -46 air
execute in minecraft:overworld run fill 425 58 -45 425 66 -45 stone
execute in minecraft:overworld run fill 425 67 -45 425 68 -45 dirt
execute in minecraft:overworld run setblock 425 69 -45 coarse_dirt
execute in minecraft:overworld run fill 425 70 -45 425 144 -45 air
execute in minecraft:overworld run fill 425 58 -44 425 67 -44 stone
execute in minecraft:overworld run fill 425 68 -44 425 69 -44 dirt
execute in minecraft:overworld run setblock 425 70 -44 coarse_dirt
execute in minecraft:overworld run fill 425 71 -44 425 144 -44 air
execute in minecraft:overworld run fill 425 58 -43 425 69 -43 stone
execute in minecraft:overworld run fill 425 70 -43 425 71 -43 dirt
execute in minecraft:overworld run setblock 425 72 -43 coarse_dirt
execute in minecraft:overworld run fill 425 73 -43 425 144 -43 air
execute in minecraft:overworld run fill 425 58 -42 425 70 -42 stone
execute in minecraft:overworld run fill 425 71 -42 425 72 -42 dirt
execute in minecraft:overworld run setblock 425 73 -42 coarse_dirt
execute in minecraft:overworld run fill 425 74 -42 425 144 -42 air
execute in minecraft:overworld run fill 425 58 -41 425 72 -41 stone
execute in minecraft:overworld run fill 425 73 -41 425 74 -41 dirt
execute in minecraft:overworld run setblock 425 75 -41 coarse_dirt
execute in minecraft:overworld run fill 425 76 -41 425 144 -41 air
execute in minecraft:overworld run fill 425 58 -40 425 72 -40 stone
execute in minecraft:overworld run fill 425 73 -40 425 74 -40 dirt
execute in minecraft:overworld run setblock 425 75 -40 grass_block
execute in minecraft:overworld run fill 425 76 -40 425 144 -40 air
execute in minecraft:overworld run fill 425 58 -39 425 71 -39 stone
execute in minecraft:overworld run fill 425 72 -39 425 73 -39 dirt
execute in minecraft:overworld run setblock 425 74 -39 coarse_dirt
execute in minecraft:overworld run fill 425 75 -39 425 144 -39 air
execute in minecraft:overworld run fill 425 58 -38 425 71 -38 stone
execute in minecraft:overworld run fill 425 72 -38 425 73 -38 dirt
execute in minecraft:overworld run setblock 425 74 -38 coarse_dirt
execute in minecraft:overworld run fill 425 75 -38 425 144 -38 air
execute in minecraft:overworld run setblock 425 75 -38 grass
execute in minecraft:overworld run fill 425 58 -37 425 71 -37 stone
execute in minecraft:overworld run fill 425 72 -37 425 73 -37 dirt
execute in minecraft:overworld run setblock 425 74 -37 coarse_dirt
execute in minecraft:overworld run fill 425 75 -37 425 144 -37 air
execute in minecraft:overworld run fill 425 58 -36 425 71 -36 stone
execute in minecraft:overworld run fill 425 72 -36 425 73 -36 dirt
execute in minecraft:overworld run setblock 425 74 -36 grass_block
execute in minecraft:overworld run fill 425 75 -36 425 144 -36 air
execute in minecraft:overworld run fill 425 58 -35 425 71 -35 stone
execute in minecraft:overworld run fill 425 72 -35 425 73 -35 dirt
execute in minecraft:overworld run setblock 425 74 -35 grass_block
execute in minecraft:overworld run fill 425 75 -35 425 144 -35 air
execute in minecraft:overworld run fill 425 58 -34 425 70 -34 stone
execute in minecraft:overworld run fill 425 71 -34 425 72 -34 dirt
execute in minecraft:overworld run setblock 425 73 -34 coarse_dirt
execute in minecraft:overworld run fill 425 74 -34 425 144 -34 air
execute in minecraft:overworld run fill 425 58 -33 425 70 -33 stone
execute in minecraft:overworld run fill 425 71 -33 425 72 -33 dirt
execute in minecraft:overworld run setblock 425 73 -33 coarse_dirt
execute in minecraft:overworld run fill 425 74 -33 425 144 -33 air
execute in minecraft:overworld run fill 425 58 -32 425 70 -32 stone
execute in minecraft:overworld run fill 425 71 -32 425 72 -32 dirt
execute in minecraft:overworld run setblock 425 73 -32 coarse_dirt
execute in minecraft:overworld run fill 425 74 -32 425 144 -32 air
execute in minecraft:overworld run fill 425 58 -31 425 69 -31 stone
execute in minecraft:overworld run fill 425 70 -31 425 71 -31 dirt
execute in minecraft:overworld run setblock 425 72 -31 grass_block
execute in minecraft:overworld run fill 425 73 -31 425 144 -31 air
execute in minecraft:overworld run fill 425 58 -30 425 69 -30 stone
execute in minecraft:overworld run fill 425 70 -30 425 71 -30 dirt
execute in minecraft:overworld run setblock 425 72 -30 grass_block
execute in minecraft:overworld run fill 425 73 -30 425 144 -30 air
execute in minecraft:overworld run fill 425 58 -29 425 69 -29 stone
execute in minecraft:overworld run fill 425 70 -29 425 71 -29 dirt
execute in minecraft:overworld run setblock 425 72 -29 grass_block
execute in minecraft:overworld run fill 425 73 -29 425 144 -29 air
execute in minecraft:overworld run fill 425 58 -28 425 68 -28 stone
execute in minecraft:overworld run fill 425 69 -28 425 70 -28 dirt
execute in minecraft:overworld run setblock 425 71 -28 coarse_dirt
execute in minecraft:overworld run fill 425 72 -28 425 144 -28 air
execute in minecraft:overworld run fill 425 58 -27 425 68 -27 stone
execute in minecraft:overworld run fill 425 69 -27 425 70 -27 dirt
execute in minecraft:overworld run setblock 425 71 -27 coarse_dirt
execute in minecraft:overworld run fill 425 72 -27 425 144 -27 air
execute in minecraft:overworld run fill 425 58 -26 425 68 -26 stone
execute in minecraft:overworld run fill 425 69 -26 425 70 -26 dirt
execute in minecraft:overworld run setblock 425 71 -26 grass_block
execute in minecraft:overworld run fill 425 72 -26 425 144 -26 air
execute in minecraft:overworld run fill 425 58 -25 425 68 -25 stone
execute in minecraft:overworld run fill 425 69 -25 425 70 -25 dirt
execute in minecraft:overworld run setblock 425 71 -25 grass_block
execute in minecraft:overworld run fill 425 72 -25 425 144 -25 air
execute in minecraft:overworld run fill 425 58 -24 425 67 -24 stone
execute in minecraft:overworld run fill 425 68 -24 425 69 -24 dirt
execute in minecraft:overworld run setblock 425 70 -24 grass_block
schedule function blade_gallery:random/battlefield/part_140 1t replace
