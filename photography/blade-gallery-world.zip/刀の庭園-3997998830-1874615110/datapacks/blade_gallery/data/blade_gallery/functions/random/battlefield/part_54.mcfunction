execute in minecraft:overworld run fill 371 73 -25 371 144 -25 air
execute in minecraft:overworld run setblock 371 73 -25 mossy_cobblestone
execute in minecraft:overworld run fill 371 58 -24 371 69 -24 stone
execute in minecraft:overworld run fill 371 70 -24 371 71 -24 dirt
execute in minecraft:overworld run setblock 371 72 -24 coarse_dirt
execute in minecraft:overworld run fill 371 73 -24 371 144 -24 air
execute in minecraft:overworld run fill 371 58 -23 371 69 -23 stone
execute in minecraft:overworld run fill 371 70 -23 371 71 -23 dirt
execute in minecraft:overworld run setblock 371 72 -23 grass_block
execute in minecraft:overworld run fill 371 73 -23 371 144 -23 air
execute in minecraft:overworld run fill 371 58 -22 371 69 -22 stone
execute in minecraft:overworld run fill 371 70 -22 371 71 -22 dirt
execute in minecraft:overworld run setblock 371 72 -22 coarse_dirt
execute in minecraft:overworld run fill 371 73 -22 371 144 -22 air
execute in minecraft:overworld run fill 371 58 -21 371 68 -21 stone
execute in minecraft:overworld run fill 371 69 -21 371 70 -21 dirt
execute in minecraft:overworld run setblock 371 71 -21 coarse_dirt
execute in minecraft:overworld run fill 371 72 -21 371 144 -21 air
execute in minecraft:overworld run fill 371 58 -20 371 68 -20 stone
execute in minecraft:overworld run fill 371 69 -20 371 70 -20 dirt
execute in minecraft:overworld run setblock 371 71 -20 coarse_dirt
execute in minecraft:overworld run fill 371 72 -20 371 144 -20 air
execute in minecraft:overworld run fill 371 58 -19 371 67 -19 stone
execute in minecraft:overworld run fill 371 68 -19 371 69 -19 dirt
execute in minecraft:overworld run setblock 371 70 -19 coarse_dirt
execute in minecraft:overworld run fill 371 71 -19 371 144 -19 air
execute in minecraft:overworld run fill 371 58 -18 371 67 -18 stone
execute in minecraft:overworld run fill 371 68 -18 371 69 -18 dirt
execute in minecraft:overworld run setblock 371 70 -18 grass_block
execute in minecraft:overworld run fill 371 71 -18 371 144 -18 air
execute in minecraft:overworld run fill 371 58 -17 371 67 -17 stone
execute in minecraft:overworld run fill 371 68 -17 371 69 -17 dirt
execute in minecraft:overworld run setblock 371 70 -17 coarse_dirt
execute in minecraft:overworld run fill 371 71 -17 371 144 -17 air
execute in minecraft:overworld run fill 371 58 -16 371 67 -16 stone
execute in minecraft:overworld run fill 371 68 -16 371 69 -16 dirt
execute in minecraft:overworld run setblock 371 70 -16 coarse_dirt
execute in minecraft:overworld run fill 371 71 -16 371 144 -16 air
execute in minecraft:overworld run fill 371 58 -15 371 66 -15 stone
execute in minecraft:overworld run fill 371 67 -15 371 68 -15 dirt
execute in minecraft:overworld run setblock 371 69 -15 coarse_dirt
execute in minecraft:overworld run fill 371 70 -15 371 144 -15 air
execute in minecraft:overworld run setblock 371 70 -15 grass
execute in minecraft:overworld run fill 371 58 -14 371 66 -14 stone
execute in minecraft:overworld run fill 371 67 -14 371 68 -14 dirt
execute in minecraft:overworld run setblock 371 69 -14 grass_block
execute in minecraft:overworld run fill 371 70 -14 371 144 -14 air
execute in minecraft:overworld run fill 371 58 -13 371 66 -13 stone
execute in minecraft:overworld run fill 371 67 -13 371 68 -13 dirt
execute in minecraft:overworld run setblock 371 69 -13 coarse_dirt
execute in minecraft:overworld run fill 371 70 -13 371 144 -13 air
execute in minecraft:overworld run fill 371 58 -12 371 65 -12 stone
execute in minecraft:overworld run fill 371 66 -12 371 67 -12 dirt
execute in minecraft:overworld run setblock 371 68 -12 coarse_dirt
execute in minecraft:overworld run fill 371 69 -12 371 144 -12 air
execute in minecraft:overworld run fill 371 58 -11 371 66 -11 stone
execute in minecraft:overworld run fill 371 67 -11 371 68 -11 dirt
execute in minecraft:overworld run setblock 371 69 -11 coarse_dirt
execute in minecraft:overworld run fill 371 70 -11 371 144 -11 air
execute in minecraft:overworld run fill 371 58 -10 371 66 -10 stone
execute in minecraft:overworld run fill 371 67 -10 371 68 -10 dirt
execute in minecraft:overworld run setblock 371 69 -10 coarse_dirt
execute in minecraft:overworld run fill 371 70 -10 371 144 -10 air
execute in minecraft:overworld run fill 371 58 -9 371 66 -9 stone
execute in minecraft:overworld run fill 371 67 -9 371 68 -9 dirt
execute in minecraft:overworld run setblock 371 69 -9 coarse_dirt
execute in minecraft:overworld run fill 371 70 -9 371 144 -9 air
execute in minecraft:overworld run fill 371 58 -8 371 66 -8 stone
execute in minecraft:overworld run fill 371 67 -8 371 68 -8 dirt
execute in minecraft:overworld run setblock 371 69 -8 coarse_dirt
execute in minecraft:overworld run fill 371 70 -8 371 144 -8 air
execute in minecraft:overworld run fill 371 58 -7 371 65 -7 stone
execute in minecraft:overworld run fill 371 66 -7 371 67 -7 dirt
execute in minecraft:overworld run setblock 371 68 -7 coarse_dirt
execute in minecraft:overworld run fill 371 69 -7 371 144 -7 air
execute in minecraft:overworld run fill 371 58 -6 371 65 -6 stone
execute in minecraft:overworld run fill 371 66 -6 371 67 -6 dirt
execute in minecraft:overworld run setblock 371 68 -6 coarse_dirt
execute in minecraft:overworld run fill 371 69 -6 371 144 -6 air
execute in minecraft:overworld run setblock 371 69 -6 mossy_cobblestone
execute in minecraft:overworld run fill 371 58 -5 371 65 -5 stone
execute in minecraft:overworld run fill 371 66 -5 371 67 -5 dirt
execute in minecraft:overworld run setblock 371 68 -5 grass_block
execute in minecraft:overworld run fill 371 69 -5 371 144 -5 air
execute in minecraft:overworld run fill 371 58 -4 371 65 -4 stone
execute in minecraft:overworld run fill 371 66 -4 371 67 -4 dirt
execute in minecraft:overworld run setblock 371 68 -4 grass_block
execute in minecraft:overworld run fill 371 69 -4 371 144 -4 air
execute in minecraft:overworld run fill 371 58 -3 371 65 -3 stone
execute in minecraft:overworld run fill 371 66 -3 371 67 -3 dirt
execute in minecraft:overworld run setblock 371 68 -3 coarse_dirt
execute in minecraft:overworld run fill 371 69 -3 371 144 -3 air
execute in minecraft:overworld run fill 371 58 -2 371 65 -2 stone
execute in minecraft:overworld run fill 371 66 -2 371 67 -2 dirt
execute in minecraft:overworld run setblock 371 68 -2 coarse_dirt
execute in minecraft:overworld run fill 371 69 -2 371 144 -2 air
execute in minecraft:overworld run fill 371 58 -1 371 65 -1 stone
execute in minecraft:overworld run fill 371 66 -1 371 67 -1 dirt
execute in minecraft:overworld run setblock 371 68 -1 coarse_dirt
execute in minecraft:overworld run fill 371 69 -1 371 144 -1 air
execute in minecraft:overworld run fill 371 58 0 371 65 0 stone
execute in minecraft:overworld run fill 371 66 0 371 67 0 dirt
execute in minecraft:overworld run setblock 371 68 0 coarse_dirt
execute in minecraft:overworld run fill 371 69 0 371 144 0 air
execute in minecraft:overworld run fill 371 58 1 371 65 1 stone
execute in minecraft:overworld run fill 371 66 1 371 67 1 dirt
execute in minecraft:overworld run setblock 371 68 1 grass_block
execute in minecraft:overworld run fill 371 69 1 371 144 1 air
execute in minecraft:overworld run setblock 371 69 1 grass
execute in minecraft:overworld run fill 371 58 2 371 65 2 stone
execute in minecraft:overworld run fill 371 66 2 371 67 2 dirt
execute in minecraft:overworld run setblock 371 68 2 coarse_dirt
execute in minecraft:overworld run fill 371 69 2 371 144 2 air
execute in minecraft:overworld run setblock 371 69 2 grass
execute in minecraft:overworld run fill 371 58 3 371 65 3 stone
execute in minecraft:overworld run fill 371 66 3 371 67 3 dirt
execute in minecraft:overworld run setblock 371 68 3 grass_block
execute in minecraft:overworld run fill 371 69 3 371 144 3 air
execute in minecraft:overworld run fill 371 58 4 371 65 4 stone
execute in minecraft:overworld run fill 371 66 4 371 67 4 dirt
execute in minecraft:overworld run setblock 371 68 4 grass_block
execute in minecraft:overworld run fill 371 69 4 371 144 4 air
execute in minecraft:overworld run fill 371 58 5 371 65 5 stone
execute in minecraft:overworld run fill 371 66 5 371 67 5 dirt
execute in minecraft:overworld run setblock 371 68 5 grass_block
execute in minecraft:overworld run fill 371 69 5 371 144 5 air
execute in minecraft:overworld run fill 371 58 6 371 65 6 stone
execute in minecraft:overworld run fill 371 66 6 371 67 6 dirt
execute in minecraft:overworld run setblock 371 68 6 coarse_dirt
execute in minecraft:overworld run fill 371 69 6 371 144 6 air
execute in minecraft:overworld run fill 371 58 7 371 65 7 stone
execute in minecraft:overworld run fill 371 66 7 371 67 7 dirt
execute in minecraft:overworld run setblock 371 68 7 coarse_dirt
execute in minecraft:overworld run fill 371 69 7 371 144 7 air
execute in minecraft:overworld run fill 371 58 8 371 65 8 stone
execute in minecraft:overworld run fill 371 66 8 371 67 8 dirt
execute in minecraft:overworld run setblock 371 68 8 coarse_dirt
execute in minecraft:overworld run fill 371 69 8 371 144 8 air
execute in minecraft:overworld run fill 371 58 9 371 65 9 stone
execute in minecraft:overworld run fill 371 66 9 371 67 9 dirt
execute in minecraft:overworld run setblock 371 68 9 coarse_dirt
execute in minecraft:overworld run fill 371 69 9 371 144 9 air
execute in minecraft:overworld run fill 371 58 10 371 65 10 stone
execute in minecraft:overworld run fill 371 66 10 371 67 10 dirt
execute in minecraft:overworld run setblock 371 68 10 grass_block
execute in minecraft:overworld run fill 371 69 10 371 144 10 air
execute in minecraft:overworld run fill 371 58 11 371 66 11 stone
execute in minecraft:overworld run fill 371 67 11 371 68 11 dirt
execute in minecraft:overworld run setblock 371 69 11 coarse_dirt
execute in minecraft:overworld run fill 371 70 11 371 144 11 air
execute in minecraft:overworld run fill 371 58 12 371 66 12 stone
execute in minecraft:overworld run fill 371 67 12 371 68 12 dirt
execute in minecraft:overworld run setblock 371 69 12 coarse_dirt
execute in minecraft:overworld run fill 371 70 12 371 144 12 air
execute in minecraft:overworld run fill 371 58 13 371 66 13 stone
execute in minecraft:overworld run fill 371 67 13 371 68 13 dirt
execute in minecraft:overworld run setblock 371 69 13 coarse_dirt
execute in minecraft:overworld run fill 371 70 13 371 144 13 air
execute in minecraft:overworld run fill 371 58 14 371 66 14 stone
execute in minecraft:overworld run fill 371 67 14 371 68 14 dirt
execute in minecraft:overworld run setblock 371 69 14 grass_block
execute in minecraft:overworld run fill 371 70 14 371 144 14 air
execute in minecraft:overworld run fill 371 58 15 371 67 15 stone
execute in minecraft:overworld run fill 371 68 15 371 69 15 dirt
execute in minecraft:overworld run setblock 371 70 15 coarse_dirt
execute in minecraft:overworld run fill 371 71 15 371 144 15 air
execute in minecraft:overworld run fill 371 58 16 371 67 16 stone
execute in minecraft:overworld run fill 371 68 16 371 69 16 dirt
execute in minecraft:overworld run setblock 371 70 16 coarse_dirt
execute in minecraft:overworld run fill 371 71 16 371 144 16 air
execute in minecraft:overworld run fill 371 58 17 371 67 17 stone
execute in minecraft:overworld run fill 371 68 17 371 69 17 dirt
execute in minecraft:overworld run setblock 371 70 17 coarse_dirt
execute in minecraft:overworld run fill 371 71 17 371 144 17 air
execute in minecraft:overworld run fill 371 58 18 371 67 18 stone
execute in minecraft:overworld run fill 371 68 18 371 69 18 dirt
execute in minecraft:overworld run setblock 371 70 18 coarse_dirt
execute in minecraft:overworld run fill 371 71 18 371 144 18 air
execute in minecraft:overworld run fill 371 58 19 371 68 19 stone
execute in minecraft:overworld run fill 371 69 19 371 70 19 dirt
execute in minecraft:overworld run setblock 371 71 19 coarse_dirt
execute in minecraft:overworld run fill 371 72 19 371 144 19 air
execute in minecraft:overworld run fill 371 58 20 371 68 20 stone
execute in minecraft:overworld run fill 371 69 20 371 70 20 dirt
execute in minecraft:overworld run setblock 371 71 20 coarse_dirt
execute in minecraft:overworld run fill 371 72 20 371 144 20 air
execute in minecraft:overworld run setblock 371 72 20 grass
execute in minecraft:overworld run fill 371 58 21 371 68 21 stone
execute in minecraft:overworld run fill 371 69 21 371 70 21 dirt
execute in minecraft:overworld run setblock 371 71 21 coarse_dirt
execute in minecraft:overworld run fill 371 72 21 371 144 21 air
execute in minecraft:overworld run setblock 371 72 21 grass
execute in minecraft:overworld run fill 371 58 22 371 68 22 stone
execute in minecraft:overworld run fill 371 69 22 371 70 22 dirt
execute in minecraft:overworld run setblock 371 71 22 coarse_dirt
execute in minecraft:overworld run fill 371 72 22 371 144 22 air
execute in minecraft:overworld run fill 371 58 23 371 68 23 stone
execute in minecraft:overworld run fill 371 69 23 371 70 23 dirt
execute in minecraft:overworld run setblock 371 71 23 grass_block
execute in minecraft:overworld run fill 371 72 23 371 144 23 air
execute in minecraft:overworld run fill 371 58 24 371 68 24 stone
execute in minecraft:overworld run fill 371 69 24 371 70 24 dirt
execute in minecraft:overworld run setblock 371 71 24 coarse_dirt
execute in minecraft:overworld run fill 371 72 24 371 144 24 air
execute in minecraft:overworld run fill 371 58 25 371 68 25 stone
execute in minecraft:overworld run fill 371 69 25 371 70 25 dirt
execute in minecraft:overworld run setblock 371 71 25 grass_block
execute in minecraft:overworld run fill 371 72 25 371 144 25 air
execute in minecraft:overworld run setblock 371 72 25 grass
execute in minecraft:overworld run fill 371 58 26 371 68 26 stone
execute in minecraft:overworld run fill 371 69 26 371 70 26 dirt
execute in minecraft:overworld run setblock 371 71 26 coarse_dirt
execute in minecraft:overworld run fill 371 72 26 371 144 26 air
execute in minecraft:overworld run fill 371 58 27 371 68 27 stone
execute in minecraft:overworld run fill 371 69 27 371 70 27 dirt
execute in minecraft:overworld run setblock 371 71 27 coarse_dirt
execute in minecraft:overworld run fill 371 72 27 371 144 27 air
execute in minecraft:overworld run setblock 371 72 27 grass
execute in minecraft:overworld run fill 371 58 28 371 68 28 stone
execute in minecraft:overworld run fill 371 69 28 371 70 28 dirt
execute in minecraft:overworld run setblock 371 71 28 coarse_dirt
execute in minecraft:overworld run fill 371 72 28 371 144 28 air
execute in minecraft:overworld run fill 371 58 29 371 68 29 stone
execute in minecraft:overworld run fill 371 69 29 371 70 29 dirt
execute in minecraft:overworld run setblock 371 71 29 grass_block
execute in minecraft:overworld run fill 371 72 29 371 144 29 air
execute in minecraft:overworld run fill 371 58 30 371 68 30 stone
execute in minecraft:overworld run fill 371 69 30 371 70 30 dirt
execute in minecraft:overworld run setblock 371 71 30 coarse_dirt
execute in minecraft:overworld run fill 371 72 30 371 144 30 air
execute in minecraft:overworld run fill 371 58 31 371 69 31 stone
execute in minecraft:overworld run fill 371 70 31 371 71 31 dirt
execute in minecraft:overworld run setblock 371 72 31 grass_block
execute in minecraft:overworld run fill 371 73 31 371 144 31 air
execute in minecraft:overworld run setblock 371 73 31 grass
execute in minecraft:overworld run fill 371 58 32 371 69 32 stone
execute in minecraft:overworld run fill 371 70 32 371 71 32 dirt
execute in minecraft:overworld run setblock 371 72 32 grass_block
execute in minecraft:overworld run fill 371 73 32 371 144 32 air
execute in minecraft:overworld run setblock 371 73 32 grass
execute in minecraft:overworld run fill 371 58 33 371 69 33 stone
execute in minecraft:overworld run fill 371 70 33 371 71 33 dirt
execute in minecraft:overworld run setblock 371 72 33 grass_block
execute in minecraft:overworld run fill 371 73 33 371 144 33 air
execute in minecraft:overworld run fill 371 58 34 371 70 34 stone
execute in minecraft:overworld run fill 371 71 34 371 72 34 dirt
execute in minecraft:overworld run setblock 371 73 34 grass_block
execute in minecraft:overworld run fill 371 74 34 371 144 34 air
execute in minecraft:overworld run fill 371 58 35 371 70 35 stone
execute in minecraft:overworld run fill 371 71 35 371 72 35 dirt
execute in minecraft:overworld run setblock 371 73 35 coarse_dirt
execute in minecraft:overworld run fill 371 74 35 371 144 35 air
execute in minecraft:overworld run fill 371 58 36 371 70 36 stone
execute in minecraft:overworld run fill 371 71 36 371 72 36 dirt
execute in minecraft:overworld run setblock 371 73 36 grass_block
execute in minecraft:overworld run fill 371 74 36 371 144 36 air
schedule function blade_gallery:random/battlefield/part_55 1t replace
