execute in minecraft:overworld run fill 284 58 -3 284 69 -3 stone
execute in minecraft:overworld run fill 284 70 -3 284 71 -3 dirt
execute in minecraft:overworld run setblock 284 72 -3 coarse_dirt
execute in minecraft:overworld run fill 284 73 -3 284 144 -3 air
execute in minecraft:overworld run fill 284 58 -2 284 69 -2 stone
execute in minecraft:overworld run fill 284 70 -2 284 71 -2 dirt
execute in minecraft:overworld run setblock 284 72 -2 coarse_dirt
execute in minecraft:overworld run fill 284 73 -2 284 144 -2 air
execute in minecraft:overworld run fill 284 58 -1 284 69 -1 stone
execute in minecraft:overworld run fill 284 70 -1 284 71 -1 dirt
execute in minecraft:overworld run setblock 284 72 -1 coarse_dirt
execute in minecraft:overworld run fill 284 73 -1 284 144 -1 air
execute in minecraft:overworld run fill 284 58 0 284 69 0 stone
execute in minecraft:overworld run fill 284 70 0 284 71 0 dirt
execute in minecraft:overworld run setblock 284 72 0 coarse_dirt
execute in minecraft:overworld run fill 284 73 0 284 144 0 air
execute in minecraft:overworld run setblock 284 73 0 grass
execute in minecraft:overworld run fill 284 58 1 284 69 1 stone
execute in minecraft:overworld run fill 284 70 1 284 71 1 dirt
execute in minecraft:overworld run setblock 284 72 1 grass_block
execute in minecraft:overworld run fill 284 73 1 284 144 1 air
execute in minecraft:overworld run fill 284 58 2 284 69 2 stone
execute in minecraft:overworld run fill 284 70 2 284 71 2 dirt
execute in minecraft:overworld run setblock 284 72 2 coarse_dirt
execute in minecraft:overworld run fill 284 73 2 284 144 2 air
execute in minecraft:overworld run fill 284 58 3 284 68 3 stone
execute in minecraft:overworld run fill 284 69 3 284 70 3 dirt
execute in minecraft:overworld run setblock 284 71 3 grass_block
execute in minecraft:overworld run fill 284 72 3 284 144 3 air
execute in minecraft:overworld run fill 284 58 4 284 68 4 stone
execute in minecraft:overworld run fill 284 69 4 284 70 4 dirt
execute in minecraft:overworld run setblock 284 71 4 coarse_dirt
execute in minecraft:overworld run fill 284 72 4 284 144 4 air
execute in minecraft:overworld run fill 284 58 5 284 68 5 stone
execute in minecraft:overworld run fill 284 69 5 284 70 5 dirt
execute in minecraft:overworld run setblock 284 71 5 grass_block
execute in minecraft:overworld run fill 284 72 5 284 144 5 air
execute in minecraft:overworld run fill 284 58 6 284 67 6 stone
execute in minecraft:overworld run fill 284 68 6 284 69 6 dirt
execute in minecraft:overworld run setblock 284 70 6 grass_block
execute in minecraft:overworld run fill 284 71 6 284 144 6 air
execute in minecraft:overworld run fill 284 58 7 284 67 7 stone
execute in minecraft:overworld run fill 284 68 7 284 69 7 dirt
execute in minecraft:overworld run setblock 284 70 7 grass_block
execute in minecraft:overworld run fill 284 71 7 284 144 7 air
execute in minecraft:overworld run fill 284 58 8 284 66 8 stone
execute in minecraft:overworld run fill 284 67 8 284 68 8 dirt
execute in minecraft:overworld run setblock 284 69 8 coarse_dirt
execute in minecraft:overworld run fill 284 70 8 284 144 8 air
execute in minecraft:overworld run setblock 284 70 8 grass
execute in minecraft:overworld run fill 284 58 9 284 66 9 stone
execute in minecraft:overworld run fill 284 67 9 284 68 9 dirt
execute in minecraft:overworld run setblock 284 69 9 coarse_dirt
execute in minecraft:overworld run fill 284 70 9 284 144 9 air
execute in minecraft:overworld run fill 284 58 10 284 66 10 stone
execute in minecraft:overworld run fill 284 67 10 284 68 10 dirt
execute in minecraft:overworld run setblock 284 69 10 grass_block
execute in minecraft:overworld run fill 284 70 10 284 144 10 air
execute in minecraft:overworld run fill 284 58 11 284 66 11 stone
execute in minecraft:overworld run fill 284 67 11 284 68 11 dirt
execute in minecraft:overworld run setblock 284 69 11 grass_block
execute in minecraft:overworld run fill 284 70 11 284 144 11 air
execute in minecraft:overworld run fill 284 58 12 284 65 12 stone
execute in minecraft:overworld run fill 284 66 12 284 67 12 dirt
execute in minecraft:overworld run setblock 284 68 12 grass_block
execute in minecraft:overworld run fill 284 69 12 284 144 12 air
execute in minecraft:overworld run fill 284 58 13 284 65 13 stone
execute in minecraft:overworld run fill 284 66 13 284 67 13 dirt
execute in minecraft:overworld run setblock 284 68 13 grass_block
execute in minecraft:overworld run fill 284 69 13 284 144 13 air
execute in minecraft:overworld run fill 284 58 14 284 65 14 stone
execute in minecraft:overworld run fill 284 66 14 284 67 14 dirt
execute in minecraft:overworld run setblock 284 68 14 coarse_dirt
execute in minecraft:overworld run fill 284 69 14 284 144 14 air
execute in minecraft:overworld run fill 284 58 15 284 65 15 stone
execute in minecraft:overworld run fill 284 66 15 284 67 15 dirt
execute in minecraft:overworld run setblock 284 68 15 coarse_dirt
execute in minecraft:overworld run fill 284 69 15 284 144 15 air
execute in minecraft:overworld run fill 284 58 16 284 65 16 stone
execute in minecraft:overworld run fill 284 66 16 284 67 16 dirt
execute in minecraft:overworld run setblock 284 68 16 grass_block
execute in minecraft:overworld run fill 284 69 16 284 144 16 air
execute in minecraft:overworld run setblock 284 69 16 mossy_cobblestone
execute in minecraft:overworld run fill 284 58 17 284 65 17 stone
execute in minecraft:overworld run fill 284 66 17 284 67 17 dirt
execute in minecraft:overworld run setblock 284 68 17 coarse_dirt
execute in minecraft:overworld run fill 284 69 17 284 144 17 air
execute in minecraft:overworld run setblock 284 69 17 grass
execute in minecraft:overworld run fill 284 58 18 284 65 18 stone
execute in minecraft:overworld run fill 284 66 18 284 67 18 dirt
execute in minecraft:overworld run setblock 284 68 18 grass_block
execute in minecraft:overworld run fill 284 69 18 284 144 18 air
execute in minecraft:overworld run fill 284 58 19 284 64 19 stone
execute in minecraft:overworld run fill 284 65 19 284 66 19 dirt
execute in minecraft:overworld run setblock 284 67 19 coarse_dirt
execute in minecraft:overworld run fill 284 68 19 284 144 19 air
execute in minecraft:overworld run setblock 284 68 19 grass
execute in minecraft:overworld run fill 284 58 20 284 64 20 stone
execute in minecraft:overworld run fill 284 65 20 284 66 20 dirt
execute in minecraft:overworld run setblock 284 67 20 coarse_dirt
execute in minecraft:overworld run fill 284 68 20 284 144 20 air
execute in minecraft:overworld run fill 284 58 21 284 64 21 stone
execute in minecraft:overworld run fill 284 65 21 284 66 21 dirt
execute in minecraft:overworld run setblock 284 67 21 coarse_dirt
execute in minecraft:overworld run fill 284 68 21 284 144 21 air
execute in minecraft:overworld run fill 284 58 22 284 64 22 stone
execute in minecraft:overworld run fill 284 65 22 284 66 22 dirt
execute in minecraft:overworld run setblock 284 67 22 coarse_dirt
execute in minecraft:overworld run fill 284 68 22 284 144 22 air
execute in minecraft:overworld run fill 284 58 23 284 64 23 stone
execute in minecraft:overworld run fill 284 65 23 284 66 23 dirt
execute in minecraft:overworld run setblock 284 67 23 coarse_dirt
execute in minecraft:overworld run fill 284 68 23 284 144 23 air
execute in minecraft:overworld run fill 284 58 24 284 64 24 stone
execute in minecraft:overworld run fill 284 65 24 284 66 24 dirt
execute in minecraft:overworld run setblock 284 67 24 grass_block
execute in minecraft:overworld run fill 284 68 24 284 144 24 air
execute in minecraft:overworld run fill 284 58 25 284 64 25 stone
execute in minecraft:overworld run fill 284 65 25 284 66 25 dirt
execute in minecraft:overworld run setblock 284 67 25 coarse_dirt
execute in minecraft:overworld run fill 284 68 25 284 144 25 air
execute in minecraft:overworld run fill 284 58 26 284 64 26 stone
execute in minecraft:overworld run fill 284 65 26 284 66 26 dirt
execute in minecraft:overworld run setblock 284 67 26 coarse_dirt
execute in minecraft:overworld run fill 284 68 26 284 144 26 air
execute in minecraft:overworld run fill 284 58 27 284 64 27 stone
execute in minecraft:overworld run fill 284 65 27 284 66 27 dirt
execute in minecraft:overworld run setblock 284 67 27 grass_block
execute in minecraft:overworld run fill 284 68 27 284 144 27 air
execute in minecraft:overworld run setblock 284 68 27 grass
execute in minecraft:overworld run fill 284 58 28 284 64 28 stone
execute in minecraft:overworld run fill 284 65 28 284 66 28 dirt
execute in minecraft:overworld run setblock 284 67 28 coarse_dirt
execute in minecraft:overworld run fill 284 68 28 284 144 28 air
execute in minecraft:overworld run fill 284 58 29 284 64 29 stone
execute in minecraft:overworld run fill 284 65 29 284 66 29 dirt
execute in minecraft:overworld run setblock 284 67 29 coarse_dirt
execute in minecraft:overworld run fill 284 68 29 284 144 29 air
execute in minecraft:overworld run fill 284 58 30 284 63 30 stone
execute in minecraft:overworld run fill 284 64 30 284 65 30 dirt
execute in minecraft:overworld run setblock 284 66 30 coarse_dirt
execute in minecraft:overworld run fill 284 67 30 284 144 30 air
execute in minecraft:overworld run fill 284 58 31 284 63 31 stone
execute in minecraft:overworld run fill 284 64 31 284 65 31 dirt
execute in minecraft:overworld run setblock 284 66 31 coarse_dirt
execute in minecraft:overworld run fill 284 67 31 284 144 31 air
execute in minecraft:overworld run fill 284 58 32 284 63 32 stone
execute in minecraft:overworld run fill 284 64 32 284 65 32 dirt
execute in minecraft:overworld run setblock 284 66 32 coarse_dirt
execute in minecraft:overworld run fill 284 67 32 284 144 32 air
execute in minecraft:overworld run fill 284 58 33 284 62 33 stone
execute in minecraft:overworld run fill 284 63 33 284 64 33 dirt
execute in minecraft:overworld run setblock 284 65 33 grass_block
execute in minecraft:overworld run fill 284 66 33 284 144 33 air
execute in minecraft:overworld run fill 284 58 34 284 62 34 stone
execute in minecraft:overworld run fill 284 63 34 284 64 34 dirt
execute in minecraft:overworld run setblock 284 65 34 grass_block
execute in minecraft:overworld run fill 284 66 34 284 144 34 air
execute in minecraft:overworld run fill 284 58 35 284 62 35 stone
execute in minecraft:overworld run fill 284 63 35 284 64 35 dirt
execute in minecraft:overworld run setblock 284 65 35 coarse_dirt
execute in minecraft:overworld run fill 284 66 35 284 144 35 air
execute in minecraft:overworld run fill 284 58 36 284 61 36 stone
execute in minecraft:overworld run fill 284 62 36 284 63 36 dirt
execute in minecraft:overworld run setblock 284 64 36 grass_block
execute in minecraft:overworld run fill 284 65 36 284 144 36 air
execute in minecraft:overworld run fill 284 58 37 284 61 37 stone
execute in minecraft:overworld run fill 284 62 37 284 63 37 dirt
execute in minecraft:overworld run setblock 284 64 37 coarse_dirt
execute in minecraft:overworld run fill 284 65 37 284 144 37 air
execute in minecraft:overworld run fill 284 58 38 284 62 38 stone
execute in minecraft:overworld run fill 284 63 38 284 64 38 dirt
execute in minecraft:overworld run setblock 284 65 38 grass_block
execute in minecraft:overworld run fill 284 66 38 284 144 38 air
execute in minecraft:overworld run fill 284 58 39 284 62 39 stone
execute in minecraft:overworld run fill 284 63 39 284 64 39 dirt
execute in minecraft:overworld run setblock 284 65 39 coarse_dirt
execute in minecraft:overworld run fill 284 66 39 284 144 39 air
execute in minecraft:overworld run setblock 284 66 39 grass
execute in minecraft:overworld run fill 284 58 40 284 62 40 stone
execute in minecraft:overworld run fill 284 63 40 284 64 40 dirt
execute in minecraft:overworld run setblock 284 65 40 coarse_dirt
execute in minecraft:overworld run fill 284 66 40 284 144 40 air
execute in minecraft:overworld run fill 284 58 41 284 62 41 stone
execute in minecraft:overworld run fill 284 63 41 284 64 41 dirt
execute in minecraft:overworld run setblock 284 65 41 coarse_dirt
execute in minecraft:overworld run fill 284 66 41 284 144 41 air
execute in minecraft:overworld run fill 284 58 42 284 62 42 stone
execute in minecraft:overworld run fill 284 63 42 284 64 42 dirt
execute in minecraft:overworld run setblock 284 65 42 coarse_dirt
execute in minecraft:overworld run fill 284 66 42 284 144 42 air
execute in minecraft:overworld run fill 284 58 43 284 62 43 stone
execute in minecraft:overworld run fill 284 63 43 284 64 43 dirt
execute in minecraft:overworld run setblock 284 65 43 coarse_dirt
execute in minecraft:overworld run fill 284 66 43 284 144 43 air
execute in minecraft:overworld run fill 284 58 44 284 62 44 stone
execute in minecraft:overworld run fill 284 63 44 284 64 44 dirt
execute in minecraft:overworld run setblock 284 65 44 grass_block
execute in minecraft:overworld run fill 284 66 44 284 144 44 air
execute in minecraft:overworld run fill 284 58 45 284 61 45 stone
execute in minecraft:overworld run fill 284 62 45 284 63 45 dirt
execute in minecraft:overworld run setblock 284 64 45 coarse_dirt
execute in minecraft:overworld run fill 284 65 45 284 144 45 air
execute in minecraft:overworld run fill 284 58 46 284 61 46 stone
execute in minecraft:overworld run fill 284 62 46 284 63 46 dirt
execute in minecraft:overworld run setblock 284 64 46 coarse_dirt
execute in minecraft:overworld run fill 284 65 46 284 144 46 air
execute in minecraft:overworld run fill 284 58 47 284 61 47 stone
execute in minecraft:overworld run fill 284 62 47 284 63 47 dirt
execute in minecraft:overworld run setblock 284 64 47 coarse_dirt
execute in minecraft:overworld run fill 284 65 47 284 144 47 air
execute in minecraft:overworld run fill 285 58 -48 285 61 -48 stone
execute in minecraft:overworld run fill 285 62 -48 285 63 -48 dirt
execute in minecraft:overworld run setblock 285 64 -48 grass_block
execute in minecraft:overworld run fill 285 65 -48 285 144 -48 air
execute in minecraft:overworld run fill 285 58 -47 285 63 -47 stone
execute in minecraft:overworld run fill 285 64 -47 285 65 -47 dirt
execute in minecraft:overworld run setblock 285 66 -47 grass_block
execute in minecraft:overworld run fill 285 67 -47 285 144 -47 air
execute in minecraft:overworld run fill 285 58 -46 285 65 -46 stone
execute in minecraft:overworld run fill 285 66 -46 285 67 -46 dirt
execute in minecraft:overworld run setblock 285 68 -46 grass_block
execute in minecraft:overworld run fill 285 69 -46 285 144 -46 air
execute in minecraft:overworld run fill 285 58 -45 285 67 -45 stone
execute in minecraft:overworld run fill 285 68 -45 285 69 -45 dirt
execute in minecraft:overworld run setblock 285 70 -45 coarse_dirt
execute in minecraft:overworld run fill 285 71 -45 285 144 -45 air
execute in minecraft:overworld run fill 285 58 -44 285 69 -44 stone
execute in minecraft:overworld run fill 285 70 -44 285 71 -44 dirt
execute in minecraft:overworld run setblock 285 72 -44 coarse_dirt
execute in minecraft:overworld run fill 285 73 -44 285 144 -44 air
execute in minecraft:overworld run fill 285 58 -43 285 71 -43 stone
execute in minecraft:overworld run fill 285 72 -43 285 73 -43 dirt
execute in minecraft:overworld run setblock 285 74 -43 coarse_dirt
execute in minecraft:overworld run fill 285 75 -43 285 144 -43 air
execute in minecraft:overworld run fill 285 58 -42 285 73 -42 stone
execute in minecraft:overworld run fill 285 74 -42 285 75 -42 dirt
execute in minecraft:overworld run setblock 285 76 -42 coarse_dirt
execute in minecraft:overworld run fill 285 77 -42 285 144 -42 air
execute in minecraft:overworld run fill 285 58 -41 285 74 -41 stone
execute in minecraft:overworld run fill 285 75 -41 285 76 -41 dirt
execute in minecraft:overworld run setblock 285 77 -41 coarse_dirt
execute in minecraft:overworld run fill 285 78 -41 285 144 -41 air
execute in minecraft:overworld run fill 285 58 -40 285 76 -40 stone
execute in minecraft:overworld run fill 285 77 -40 285 78 -40 dirt
execute in minecraft:overworld run setblock 285 79 -40 coarse_dirt
execute in minecraft:overworld run fill 285 80 -40 285 144 -40 air
execute in minecraft:overworld run fill 285 58 -39 285 78 -39 stone
execute in minecraft:overworld run fill 285 79 -39 285 80 -39 dirt
execute in minecraft:overworld run setblock 285 81 -39 grass_block
execute in minecraft:overworld run fill 285 82 -39 285 144 -39 air
execute in minecraft:overworld run fill 285 58 -38 285 79 -38 stone
execute in minecraft:overworld run fill 285 80 -38 285 81 -38 dirt
execute in minecraft:overworld run setblock 285 82 -38 grass_block
execute in minecraft:overworld run fill 285 83 -38 285 144 -38 air
execute in minecraft:overworld run fill 285 58 -37 285 79 -37 stone
schedule function blade_gallery:random/burned/part_122 1t replace
