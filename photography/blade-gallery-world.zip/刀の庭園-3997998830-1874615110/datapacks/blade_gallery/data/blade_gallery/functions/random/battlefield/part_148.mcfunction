execute in minecraft:overworld run fill 430 66 6 430 144 6 air
execute in minecraft:overworld run fill 430 58 7 430 62 7 stone
execute in minecraft:overworld run fill 430 63 7 430 64 7 dirt
execute in minecraft:overworld run setblock 430 65 7 coarse_dirt
execute in minecraft:overworld run fill 430 66 7 430 144 7 air
execute in minecraft:overworld run fill 430 58 8 430 62 8 stone
execute in minecraft:overworld run fill 430 63 8 430 64 8 dirt
execute in minecraft:overworld run setblock 430 65 8 coarse_dirt
execute in minecraft:overworld run fill 430 66 8 430 144 8 air
execute in minecraft:overworld run fill 430 58 9 430 62 9 stone
execute in minecraft:overworld run fill 430 63 9 430 64 9 dirt
execute in minecraft:overworld run setblock 430 65 9 coarse_dirt
execute in minecraft:overworld run fill 430 66 9 430 144 9 air
execute in minecraft:overworld run fill 430 58 10 430 62 10 stone
execute in minecraft:overworld run fill 430 63 10 430 64 10 dirt
execute in minecraft:overworld run setblock 430 65 10 coarse_dirt
execute in minecraft:overworld run fill 430 66 10 430 144 10 air
execute in minecraft:overworld run fill 430 58 11 430 62 11 stone
execute in minecraft:overworld run fill 430 63 11 430 64 11 dirt
execute in minecraft:overworld run setblock 430 65 11 coarse_dirt
execute in minecraft:overworld run fill 430 66 11 430 144 11 air
execute in minecraft:overworld run fill 430 58 12 430 62 12 stone
execute in minecraft:overworld run fill 430 63 12 430 64 12 dirt
execute in minecraft:overworld run setblock 430 65 12 grass_block
execute in minecraft:overworld run fill 430 66 12 430 144 12 air
execute in minecraft:overworld run fill 430 58 13 430 62 13 stone
execute in minecraft:overworld run fill 430 63 13 430 64 13 dirt
execute in minecraft:overworld run setblock 430 65 13 grass_block
execute in minecraft:overworld run fill 430 66 13 430 144 13 air
execute in minecraft:overworld run fill 430 58 14 430 62 14 stone
execute in minecraft:overworld run fill 430 63 14 430 64 14 dirt
execute in minecraft:overworld run setblock 430 65 14 coarse_dirt
execute in minecraft:overworld run fill 430 66 14 430 144 14 air
execute in minecraft:overworld run fill 430 58 15 430 62 15 stone
execute in minecraft:overworld run fill 430 63 15 430 64 15 dirt
execute in minecraft:overworld run setblock 430 65 15 coarse_dirt
execute in minecraft:overworld run fill 430 66 15 430 144 15 air
execute in minecraft:overworld run fill 430 58 16 430 62 16 stone
execute in minecraft:overworld run fill 430 63 16 430 64 16 dirt
execute in minecraft:overworld run setblock 430 65 16 grass_block
execute in minecraft:overworld run fill 430 66 16 430 144 16 air
execute in minecraft:overworld run fill 430 58 17 430 63 17 stone
execute in minecraft:overworld run fill 430 64 17 430 65 17 dirt
execute in minecraft:overworld run setblock 430 66 17 coarse_dirt
execute in minecraft:overworld run fill 430 67 17 430 144 17 air
execute in minecraft:overworld run fill 430 58 18 430 63 18 stone
execute in minecraft:overworld run fill 430 64 18 430 65 18 dirt
execute in minecraft:overworld run setblock 430 66 18 coarse_dirt
execute in minecraft:overworld run fill 430 67 18 430 144 18 air
execute in minecraft:overworld run fill 430 58 19 430 63 19 stone
execute in minecraft:overworld run fill 430 64 19 430 65 19 dirt
execute in minecraft:overworld run setblock 430 66 19 grass_block
execute in minecraft:overworld run fill 430 67 19 430 144 19 air
execute in minecraft:overworld run fill 430 58 20 430 63 20 stone
execute in minecraft:overworld run fill 430 64 20 430 65 20 dirt
execute in minecraft:overworld run setblock 430 66 20 coarse_dirt
execute in minecraft:overworld run fill 430 67 20 430 144 20 air
execute in minecraft:overworld run fill 430 58 21 430 63 21 stone
execute in minecraft:overworld run fill 430 64 21 430 65 21 dirt
execute in minecraft:overworld run setblock 430 66 21 grass_block
execute in minecraft:overworld run fill 430 67 21 430 144 21 air
execute in minecraft:overworld run fill 430 58 22 430 63 22 stone
execute in minecraft:overworld run fill 430 64 22 430 65 22 dirt
execute in minecraft:overworld run setblock 430 66 22 coarse_dirt
execute in minecraft:overworld run fill 430 67 22 430 144 22 air
execute in minecraft:overworld run fill 430 58 23 430 63 23 stone
execute in minecraft:overworld run fill 430 64 23 430 65 23 dirt
execute in minecraft:overworld run setblock 430 66 23 coarse_dirt
execute in minecraft:overworld run fill 430 67 23 430 144 23 air
execute in minecraft:overworld run fill 430 58 24 430 63 24 stone
execute in minecraft:overworld run fill 430 64 24 430 65 24 dirt
execute in minecraft:overworld run setblock 430 66 24 grass_block
execute in minecraft:overworld run fill 430 67 24 430 144 24 air
execute in minecraft:overworld run fill 430 58 25 430 63 25 stone
execute in minecraft:overworld run fill 430 64 25 430 65 25 dirt
execute in minecraft:overworld run setblock 430 66 25 grass_block
execute in minecraft:overworld run fill 430 67 25 430 144 25 air
execute in minecraft:overworld run fill 430 58 26 430 63 26 stone
execute in minecraft:overworld run fill 430 64 26 430 65 26 dirt
execute in minecraft:overworld run setblock 430 66 26 coarse_dirt
execute in minecraft:overworld run fill 430 67 26 430 144 26 air
execute in minecraft:overworld run fill 430 58 27 430 63 27 stone
execute in minecraft:overworld run fill 430 64 27 430 65 27 dirt
execute in minecraft:overworld run setblock 430 66 27 coarse_dirt
execute in minecraft:overworld run fill 430 67 27 430 144 27 air
execute in minecraft:overworld run fill 430 58 28 430 63 28 stone
execute in minecraft:overworld run fill 430 64 28 430 65 28 dirt
execute in minecraft:overworld run setblock 430 66 28 coarse_dirt
execute in minecraft:overworld run fill 430 67 28 430 144 28 air
execute in minecraft:overworld run fill 430 58 29 430 63 29 stone
execute in minecraft:overworld run fill 430 64 29 430 65 29 dirt
execute in minecraft:overworld run setblock 430 66 29 coarse_dirt
execute in minecraft:overworld run fill 430 67 29 430 144 29 air
execute in minecraft:overworld run fill 430 58 30 430 63 30 stone
execute in minecraft:overworld run fill 430 64 30 430 65 30 dirt
execute in minecraft:overworld run setblock 430 66 30 coarse_dirt
execute in minecraft:overworld run fill 430 67 30 430 144 30 air
execute in minecraft:overworld run fill 430 58 31 430 63 31 stone
execute in minecraft:overworld run fill 430 64 31 430 65 31 dirt
execute in minecraft:overworld run setblock 430 66 31 coarse_dirt
execute in minecraft:overworld run fill 430 67 31 430 144 31 air
execute in minecraft:overworld run fill 430 58 32 430 63 32 stone
execute in minecraft:overworld run fill 430 64 32 430 65 32 dirt
execute in minecraft:overworld run setblock 430 66 32 coarse_dirt
execute in minecraft:overworld run fill 430 67 32 430 144 32 air
execute in minecraft:overworld run fill 430 58 33 430 63 33 stone
execute in minecraft:overworld run fill 430 64 33 430 65 33 dirt
execute in minecraft:overworld run setblock 430 66 33 grass_block
execute in minecraft:overworld run fill 430 67 33 430 144 33 air
execute in minecraft:overworld run fill 430 58 34 430 63 34 stone
execute in minecraft:overworld run fill 430 64 34 430 65 34 dirt
execute in minecraft:overworld run setblock 430 66 34 coarse_dirt
execute in minecraft:overworld run fill 430 67 34 430 144 34 air
execute in minecraft:overworld run fill 430 58 35 430 63 35 stone
execute in minecraft:overworld run fill 430 64 35 430 65 35 dirt
execute in minecraft:overworld run setblock 430 66 35 coarse_dirt
execute in minecraft:overworld run fill 430 67 35 430 144 35 air
execute in minecraft:overworld run fill 430 58 36 430 63 36 stone
execute in minecraft:overworld run fill 430 64 36 430 65 36 dirt
execute in minecraft:overworld run setblock 430 66 36 coarse_dirt
execute in minecraft:overworld run fill 430 67 36 430 144 36 air
execute in minecraft:overworld run fill 430 58 37 430 63 37 stone
execute in minecraft:overworld run fill 430 64 37 430 65 37 dirt
execute in minecraft:overworld run setblock 430 66 37 coarse_dirt
execute in minecraft:overworld run fill 430 67 37 430 144 37 air
execute in minecraft:overworld run fill 430 58 38 430 62 38 stone
execute in minecraft:overworld run fill 430 63 38 430 64 38 dirt
execute in minecraft:overworld run setblock 430 65 38 coarse_dirt
execute in minecraft:overworld run fill 430 66 38 430 144 38 air
execute in minecraft:overworld run fill 430 58 39 430 62 39 stone
execute in minecraft:overworld run fill 430 63 39 430 64 39 dirt
execute in minecraft:overworld run setblock 430 65 39 coarse_dirt
execute in minecraft:overworld run fill 430 66 39 430 144 39 air
execute in minecraft:overworld run fill 430 58 40 430 62 40 stone
execute in minecraft:overworld run fill 430 63 40 430 64 40 dirt
execute in minecraft:overworld run setblock 430 65 40 grass_block
execute in minecraft:overworld run fill 430 66 40 430 144 40 air
execute in minecraft:overworld run fill 430 58 41 430 62 41 stone
execute in minecraft:overworld run fill 430 63 41 430 64 41 dirt
execute in minecraft:overworld run setblock 430 65 41 grass_block
execute in minecraft:overworld run fill 430 66 41 430 144 41 air
execute in minecraft:overworld run fill 430 58 42 430 62 42 stone
execute in minecraft:overworld run fill 430 63 42 430 64 42 dirt
execute in minecraft:overworld run setblock 430 65 42 grass_block
execute in minecraft:overworld run fill 430 66 42 430 144 42 air
execute in minecraft:overworld run fill 430 58 43 430 62 43 stone
execute in minecraft:overworld run fill 430 63 43 430 64 43 dirt
execute in minecraft:overworld run setblock 430 65 43 coarse_dirt
execute in minecraft:overworld run fill 430 66 43 430 144 43 air
execute in minecraft:overworld run fill 430 58 44 430 62 44 stone
execute in minecraft:overworld run fill 430 63 44 430 64 44 dirt
execute in minecraft:overworld run setblock 430 65 44 coarse_dirt
execute in minecraft:overworld run fill 430 66 44 430 144 44 air
execute in minecraft:overworld run fill 430 58 45 430 62 45 stone
execute in minecraft:overworld run fill 430 63 45 430 64 45 dirt
execute in minecraft:overworld run setblock 430 65 45 coarse_dirt
execute in minecraft:overworld run fill 430 66 45 430 144 45 air
execute in minecraft:overworld run fill 430 58 46 430 62 46 stone
execute in minecraft:overworld run fill 430 63 46 430 64 46 dirt
execute in minecraft:overworld run setblock 430 65 46 coarse_dirt
execute in minecraft:overworld run fill 430 66 46 430 144 46 air
execute in minecraft:overworld run fill 430 58 47 430 61 47 stone
execute in minecraft:overworld run fill 430 62 47 430 63 47 dirt
execute in minecraft:overworld run setblock 430 64 47 coarse_dirt
execute in minecraft:overworld run fill 430 65 47 430 144 47 air
execute in minecraft:overworld run fill 431 58 -48 431 61 -48 stone
execute in minecraft:overworld run fill 431 62 -48 431 63 -48 dirt
execute in minecraft:overworld run setblock 431 64 -48 coarse_dirt
execute in minecraft:overworld run fill 431 65 -48 431 144 -48 air
execute in minecraft:overworld run fill 431 58 -47 431 63 -47 stone
execute in minecraft:overworld run fill 431 64 -47 431 65 -47 dirt
execute in minecraft:overworld run setblock 431 66 -47 grass_block
execute in minecraft:overworld run fill 431 67 -47 431 144 -47 air
execute in minecraft:overworld run fill 431 58 -46 431 63 -46 stone
execute in minecraft:overworld run fill 431 64 -46 431 65 -46 dirt
execute in minecraft:overworld run setblock 431 66 -46 coarse_dirt
execute in minecraft:overworld run fill 431 67 -46 431 144 -46 air
execute in minecraft:overworld run fill 431 58 -45 431 63 -45 stone
execute in minecraft:overworld run fill 431 64 -45 431 65 -45 dirt
execute in minecraft:overworld run setblock 431 66 -45 coarse_dirt
execute in minecraft:overworld run fill 431 67 -45 431 144 -45 air
execute in minecraft:overworld run fill 431 58 -44 431 63 -44 stone
execute in minecraft:overworld run fill 431 64 -44 431 65 -44 dirt
execute in minecraft:overworld run setblock 431 66 -44 coarse_dirt
execute in minecraft:overworld run fill 431 67 -44 431 144 -44 air
execute in minecraft:overworld run fill 431 58 -43 431 63 -43 stone
execute in minecraft:overworld run fill 431 64 -43 431 65 -43 dirt
execute in minecraft:overworld run setblock 431 66 -43 coarse_dirt
execute in minecraft:overworld run fill 431 67 -43 431 144 -43 air
execute in minecraft:overworld run fill 431 58 -42 431 63 -42 stone
execute in minecraft:overworld run fill 431 64 -42 431 65 -42 dirt
execute in minecraft:overworld run setblock 431 66 -42 coarse_dirt
execute in minecraft:overworld run fill 431 67 -42 431 144 -42 air
execute in minecraft:overworld run fill 431 58 -41 431 63 -41 stone
execute in minecraft:overworld run fill 431 64 -41 431 65 -41 dirt
execute in minecraft:overworld run setblock 431 66 -41 grass_block
execute in minecraft:overworld run fill 431 67 -41 431 144 -41 air
execute in minecraft:overworld run fill 431 58 -40 431 63 -40 stone
execute in minecraft:overworld run fill 431 64 -40 431 65 -40 dirt
execute in minecraft:overworld run setblock 431 66 -40 coarse_dirt
execute in minecraft:overworld run fill 431 67 -40 431 144 -40 air
execute in minecraft:overworld run fill 431 58 -39 431 63 -39 stone
execute in minecraft:overworld run fill 431 64 -39 431 65 -39 dirt
execute in minecraft:overworld run setblock 431 66 -39 coarse_dirt
execute in minecraft:overworld run fill 431 67 -39 431 144 -39 air
execute in minecraft:overworld run fill 431 58 -38 431 63 -38 stone
execute in minecraft:overworld run fill 431 64 -38 431 65 -38 dirt
execute in minecraft:overworld run setblock 431 66 -38 grass_block
execute in minecraft:overworld run fill 431 67 -38 431 144 -38 air
execute in minecraft:overworld run fill 431 58 -37 431 62 -37 stone
execute in minecraft:overworld run fill 431 63 -37 431 64 -37 dirt
execute in minecraft:overworld run setblock 431 65 -37 grass_block
execute in minecraft:overworld run fill 431 66 -37 431 144 -37 air
execute in minecraft:overworld run fill 431 58 -36 431 62 -36 stone
execute in minecraft:overworld run fill 431 63 -36 431 64 -36 dirt
execute in minecraft:overworld run setblock 431 65 -36 coarse_dirt
execute in minecraft:overworld run fill 431 66 -36 431 144 -36 air
execute in minecraft:overworld run fill 431 58 -35 431 62 -35 stone
execute in minecraft:overworld run fill 431 63 -35 431 64 -35 dirt
execute in minecraft:overworld run setblock 431 65 -35 grass_block
execute in minecraft:overworld run fill 431 66 -35 431 144 -35 air
execute in minecraft:overworld run fill 431 58 -34 431 62 -34 stone
execute in minecraft:overworld run fill 431 63 -34 431 64 -34 dirt
execute in minecraft:overworld run setblock 431 65 -34 coarse_dirt
execute in minecraft:overworld run fill 431 66 -34 431 144 -34 air
execute in minecraft:overworld run fill 431 58 -33 431 62 -33 stone
execute in minecraft:overworld run fill 431 63 -33 431 64 -33 dirt
execute in minecraft:overworld run setblock 431 65 -33 coarse_dirt
execute in minecraft:overworld run fill 431 66 -33 431 144 -33 air
execute in minecraft:overworld run fill 431 58 -32 431 62 -32 stone
execute in minecraft:overworld run fill 431 63 -32 431 64 -32 dirt
execute in minecraft:overworld run setblock 431 65 -32 coarse_dirt
execute in minecraft:overworld run fill 431 66 -32 431 144 -32 air
execute in minecraft:overworld run fill 431 58 -31 431 62 -31 stone
execute in minecraft:overworld run fill 431 63 -31 431 64 -31 dirt
execute in minecraft:overworld run setblock 431 65 -31 grass_block
execute in minecraft:overworld run fill 431 66 -31 431 144 -31 air
execute in minecraft:overworld run fill 431 58 -30 431 62 -30 stone
execute in minecraft:overworld run fill 431 63 -30 431 64 -30 dirt
execute in minecraft:overworld run setblock 431 65 -30 grass_block
execute in minecraft:overworld run fill 431 66 -30 431 144 -30 air
execute in minecraft:overworld run fill 431 58 -29 431 62 -29 stone
execute in minecraft:overworld run fill 431 63 -29 431 64 -29 dirt
execute in minecraft:overworld run setblock 431 65 -29 coarse_dirt
execute in minecraft:overworld run fill 431 66 -29 431 144 -29 air
execute in minecraft:overworld run fill 431 58 -28 431 62 -28 stone
execute in minecraft:overworld run fill 431 63 -28 431 64 -28 dirt
execute in minecraft:overworld run setblock 431 65 -28 coarse_dirt
execute in minecraft:overworld run fill 431 66 -28 431 144 -28 air
execute in minecraft:overworld run fill 431 58 -27 431 62 -27 stone
execute in minecraft:overworld run fill 431 63 -27 431 64 -27 dirt
execute in minecraft:overworld run setblock 431 65 -27 grass_block
execute in minecraft:overworld run fill 431 66 -27 431 144 -27 air
execute in minecraft:overworld run fill 431 58 -26 431 62 -26 stone
execute in minecraft:overworld run fill 431 63 -26 431 64 -26 dirt
execute in minecraft:overworld run setblock 431 65 -26 coarse_dirt
schedule function blade_gallery:random/battlefield/part_149 1t replace
