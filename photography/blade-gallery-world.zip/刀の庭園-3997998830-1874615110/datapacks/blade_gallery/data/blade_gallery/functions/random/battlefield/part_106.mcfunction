execute in minecraft:overworld run fill 403 73 -26 403 74 -26 dirt
execute in minecraft:overworld run setblock 403 75 -26 coarse_dirt
execute in minecraft:overworld run fill 403 76 -26 403 144 -26 air
execute in minecraft:overworld run fill 403 58 -25 403 71 -25 stone
execute in minecraft:overworld run fill 403 72 -25 403 73 -25 dirt
execute in minecraft:overworld run setblock 403 74 -25 coarse_dirt
execute in minecraft:overworld run fill 403 75 -25 403 144 -25 air
execute in minecraft:overworld run fill 403 58 -24 403 71 -24 stone
execute in minecraft:overworld run fill 403 72 -24 403 73 -24 dirt
execute in minecraft:overworld run setblock 403 74 -24 grass_block
execute in minecraft:overworld run fill 403 75 -24 403 144 -24 air
execute in minecraft:overworld run fill 403 58 -23 403 71 -23 stone
execute in minecraft:overworld run fill 403 72 -23 403 73 -23 dirt
execute in minecraft:overworld run setblock 403 74 -23 grass_block
execute in minecraft:overworld run fill 403 75 -23 403 144 -23 air
execute in minecraft:overworld run fill 403 58 -22 403 70 -22 stone
execute in minecraft:overworld run fill 403 71 -22 403 72 -22 dirt
execute in minecraft:overworld run setblock 403 73 -22 grass_block
execute in minecraft:overworld run fill 403 74 -22 403 144 -22 air
execute in minecraft:overworld run fill 403 58 -21 403 70 -21 stone
execute in minecraft:overworld run fill 403 71 -21 403 72 -21 dirt
execute in minecraft:overworld run setblock 403 73 -21 grass_block
execute in minecraft:overworld run fill 403 74 -21 403 144 -21 air
execute in minecraft:overworld run fill 403 58 -20 403 70 -20 stone
execute in minecraft:overworld run fill 403 71 -20 403 72 -20 dirt
execute in minecraft:overworld run setblock 403 73 -20 grass_block
execute in minecraft:overworld run fill 403 74 -20 403 144 -20 air
execute in minecraft:overworld run fill 403 58 -19 403 69 -19 stone
execute in minecraft:overworld run fill 403 70 -19 403 71 -19 dirt
execute in minecraft:overworld run setblock 403 72 -19 coarse_dirt
execute in minecraft:overworld run fill 403 73 -19 403 144 -19 air
execute in minecraft:overworld run fill 403 58 -18 403 69 -18 stone
execute in minecraft:overworld run fill 403 70 -18 403 71 -18 dirt
execute in minecraft:overworld run setblock 403 72 -18 coarse_dirt
execute in minecraft:overworld run fill 403 73 -18 403 144 -18 air
execute in minecraft:overworld run fill 403 58 -17 403 68 -17 stone
execute in minecraft:overworld run fill 403 69 -17 403 70 -17 dirt
execute in minecraft:overworld run setblock 403 71 -17 coarse_dirt
execute in minecraft:overworld run fill 403 72 -17 403 144 -17 air
execute in minecraft:overworld run fill 403 58 -16 403 67 -16 stone
execute in minecraft:overworld run fill 403 68 -16 403 69 -16 dirt
execute in minecraft:overworld run setblock 403 70 -16 coarse_dirt
execute in minecraft:overworld run fill 403 71 -16 403 144 -16 air
execute in minecraft:overworld run fill 403 58 -15 403 66 -15 stone
execute in minecraft:overworld run fill 403 67 -15 403 68 -15 dirt
execute in minecraft:overworld run setblock 403 69 -15 grass_block
execute in minecraft:overworld run fill 403 70 -15 403 144 -15 air
execute in minecraft:overworld run fill 403 58 -14 403 65 -14 stone
execute in minecraft:overworld run fill 403 66 -14 403 67 -14 dirt
execute in minecraft:overworld run setblock 403 68 -14 grass_block
execute in minecraft:overworld run fill 403 69 -14 403 144 -14 air
execute in minecraft:overworld run setblock 403 69 -14 grass
execute in minecraft:overworld run fill 403 58 -13 403 65 -13 stone
execute in minecraft:overworld run fill 403 66 -13 403 67 -13 dirt
execute in minecraft:overworld run setblock 403 68 -13 coarse_dirt
execute in minecraft:overworld run fill 403 69 -13 403 144 -13 air
execute in minecraft:overworld run fill 403 58 -12 403 64 -12 stone
execute in minecraft:overworld run fill 403 65 -12 403 66 -12 dirt
execute in minecraft:overworld run setblock 403 67 -12 coarse_dirt
execute in minecraft:overworld run fill 403 68 -12 403 144 -12 air
execute in minecraft:overworld run fill 403 58 -11 403 63 -11 stone
execute in minecraft:overworld run fill 403 64 -11 403 65 -11 dirt
execute in minecraft:overworld run setblock 403 66 -11 coarse_dirt
execute in minecraft:overworld run fill 403 67 -11 403 144 -11 air
execute in minecraft:overworld run fill 403 58 -10 403 63 -10 stone
execute in minecraft:overworld run fill 403 64 -10 403 65 -10 dirt
execute in minecraft:overworld run setblock 403 66 -10 coarse_dirt
execute in minecraft:overworld run fill 403 67 -10 403 144 -10 air
execute in minecraft:overworld run fill 403 58 -9 403 62 -9 stone
execute in minecraft:overworld run fill 403 63 -9 403 64 -9 dirt
execute in minecraft:overworld run setblock 403 65 -9 coarse_dirt
execute in minecraft:overworld run fill 403 66 -9 403 144 -9 air
execute in minecraft:overworld run fill 403 58 -8 403 62 -8 stone
execute in minecraft:overworld run fill 403 63 -8 403 64 -8 dirt
execute in minecraft:overworld run setblock 403 65 -8 grass_block
execute in minecraft:overworld run fill 403 66 -8 403 144 -8 air
execute in minecraft:overworld run fill 403 58 -7 403 62 -7 stone
execute in minecraft:overworld run fill 403 63 -7 403 64 -7 dirt
execute in minecraft:overworld run setblock 403 65 -7 coarse_dirt
execute in minecraft:overworld run fill 403 66 -7 403 144 -7 air
execute in minecraft:overworld run fill 403 58 -6 403 61 -6 stone
execute in minecraft:overworld run fill 403 62 -6 403 63 -6 dirt
execute in minecraft:overworld run setblock 403 64 -6 coarse_dirt
execute in minecraft:overworld run fill 403 65 -6 403 144 -6 air
execute in minecraft:overworld run fill 403 58 -5 403 61 -5 stone
execute in minecraft:overworld run fill 403 62 -5 403 63 -5 dirt
execute in minecraft:overworld run setblock 403 64 -5 coarse_dirt
execute in minecraft:overworld run fill 403 65 -5 403 144 -5 air
execute in minecraft:overworld run fill 403 58 -4 403 61 -4 stone
execute in minecraft:overworld run fill 403 62 -4 403 63 -4 dirt
execute in minecraft:overworld run setblock 403 64 -4 coarse_dirt
execute in minecraft:overworld run fill 403 65 -4 403 144 -4 air
execute in minecraft:overworld run fill 403 58 -3 403 60 -3 stone
execute in minecraft:overworld run fill 403 61 -3 403 62 -3 dirt
execute in minecraft:overworld run setblock 403 63 -3 gravel
execute in minecraft:overworld run fill 403 64 -3 403 144 -3 air
execute in minecraft:overworld run fill 403 64 -3 403 64 -3 water
execute in minecraft:overworld run fill 403 58 -2 403 60 -2 stone
execute in minecraft:overworld run fill 403 61 -2 403 62 -2 dirt
execute in minecraft:overworld run setblock 403 63 -2 gravel
execute in minecraft:overworld run fill 403 64 -2 403 144 -2 air
execute in minecraft:overworld run fill 403 64 -2 403 64 -2 water
execute in minecraft:overworld run fill 403 58 -1 403 60 -1 stone
execute in minecraft:overworld run fill 403 61 -1 403 62 -1 dirt
execute in minecraft:overworld run setblock 403 63 -1 gravel
execute in minecraft:overworld run fill 403 64 -1 403 144 -1 air
execute in minecraft:overworld run fill 403 64 -1 403 64 -1 water
execute in minecraft:overworld run fill 403 58 0 403 60 0 stone
execute in minecraft:overworld run fill 403 61 0 403 62 0 dirt
execute in minecraft:overworld run setblock 403 63 0 gravel
execute in minecraft:overworld run fill 403 64 0 403 144 0 air
execute in minecraft:overworld run fill 403 64 0 403 64 0 water
execute in minecraft:overworld run fill 403 58 1 403 60 1 stone
execute in minecraft:overworld run fill 403 61 1 403 62 1 dirt
execute in minecraft:overworld run setblock 403 63 1 gravel
execute in minecraft:overworld run fill 403 64 1 403 144 1 air
execute in minecraft:overworld run fill 403 64 1 403 64 1 water
execute in minecraft:overworld run fill 403 58 2 403 59 2 stone
execute in minecraft:overworld run fill 403 60 2 403 61 2 dirt
execute in minecraft:overworld run setblock 403 62 2 gravel
execute in minecraft:overworld run fill 403 63 2 403 144 2 air
execute in minecraft:overworld run fill 403 63 2 403 64 2 water
execute in minecraft:overworld run fill 403 58 3 403 59 3 stone
execute in minecraft:overworld run fill 403 60 3 403 61 3 dirt
execute in minecraft:overworld run setblock 403 62 3 gravel
execute in minecraft:overworld run fill 403 63 3 403 144 3 air
execute in minecraft:overworld run fill 403 63 3 403 64 3 water
execute in minecraft:overworld run fill 403 58 4 403 59 4 stone
execute in minecraft:overworld run fill 403 60 4 403 61 4 dirt
execute in minecraft:overworld run setblock 403 62 4 gravel
execute in minecraft:overworld run fill 403 63 4 403 144 4 air
execute in minecraft:overworld run fill 403 63 4 403 64 4 water
execute in minecraft:overworld run fill 403 58 5 403 59 5 stone
execute in minecraft:overworld run fill 403 60 5 403 61 5 dirt
execute in minecraft:overworld run setblock 403 62 5 gravel
execute in minecraft:overworld run fill 403 63 5 403 144 5 air
execute in minecraft:overworld run fill 403 63 5 403 64 5 water
execute in minecraft:overworld run fill 403 58 6 403 59 6 stone
execute in minecraft:overworld run fill 403 60 6 403 61 6 dirt
execute in minecraft:overworld run setblock 403 62 6 gravel
execute in minecraft:overworld run fill 403 63 6 403 144 6 air
execute in minecraft:overworld run fill 403 63 6 403 64 6 water
execute in minecraft:overworld run fill 403 58 7 403 59 7 stone
execute in minecraft:overworld run fill 403 60 7 403 61 7 dirt
execute in minecraft:overworld run setblock 403 62 7 gravel
execute in minecraft:overworld run fill 403 63 7 403 144 7 air
execute in minecraft:overworld run fill 403 63 7 403 64 7 water
execute in minecraft:overworld run fill 403 58 8 403 59 8 stone
execute in minecraft:overworld run fill 403 60 8 403 61 8 dirt
execute in minecraft:overworld run setblock 403 62 8 gravel
execute in minecraft:overworld run fill 403 63 8 403 144 8 air
execute in minecraft:overworld run fill 403 63 8 403 64 8 water
execute in minecraft:overworld run fill 403 58 9 403 60 9 stone
execute in minecraft:overworld run fill 403 61 9 403 62 9 dirt
execute in minecraft:overworld run setblock 403 63 9 gravel
execute in minecraft:overworld run fill 403 64 9 403 144 9 air
execute in minecraft:overworld run fill 403 64 9 403 64 9 water
execute in minecraft:overworld run fill 403 58 10 403 60 10 stone
execute in minecraft:overworld run fill 403 61 10 403 62 10 dirt
execute in minecraft:overworld run setblock 403 63 10 gravel
execute in minecraft:overworld run fill 403 64 10 403 144 10 air
execute in minecraft:overworld run fill 403 64 10 403 64 10 water
execute in minecraft:overworld run fill 403 58 11 403 60 11 stone
execute in minecraft:overworld run fill 403 61 11 403 62 11 dirt
execute in minecraft:overworld run setblock 403 63 11 gravel
execute in minecraft:overworld run fill 403 64 11 403 144 11 air
execute in minecraft:overworld run fill 403 64 11 403 64 11 water
execute in minecraft:overworld run fill 403 58 12 403 60 12 stone
execute in minecraft:overworld run fill 403 61 12 403 62 12 dirt
execute in minecraft:overworld run setblock 403 63 12 gravel
execute in minecraft:overworld run fill 403 64 12 403 144 12 air
execute in minecraft:overworld run fill 403 64 12 403 64 12 water
execute in minecraft:overworld run fill 403 58 13 403 60 13 stone
execute in minecraft:overworld run fill 403 61 13 403 62 13 dirt
execute in minecraft:overworld run setblock 403 63 13 gravel
execute in minecraft:overworld run fill 403 64 13 403 144 13 air
execute in minecraft:overworld run fill 403 64 13 403 64 13 water
execute in minecraft:overworld run fill 403 58 14 403 61 14 stone
execute in minecraft:overworld run fill 403 62 14 403 63 14 dirt
execute in minecraft:overworld run setblock 403 64 14 coarse_dirt
execute in minecraft:overworld run fill 403 65 14 403 144 14 air
execute in minecraft:overworld run fill 403 58 15 403 61 15 stone
execute in minecraft:overworld run fill 403 62 15 403 63 15 dirt
execute in minecraft:overworld run setblock 403 64 15 grass_block
execute in minecraft:overworld run fill 403 65 15 403 144 15 air
execute in minecraft:overworld run fill 403 58 16 403 62 16 stone
execute in minecraft:overworld run fill 403 63 16 403 64 16 dirt
execute in minecraft:overworld run setblock 403 65 16 coarse_dirt
execute in minecraft:overworld run fill 403 66 16 403 144 16 air
execute in minecraft:overworld run fill 403 58 17 403 62 17 stone
execute in minecraft:overworld run fill 403 63 17 403 64 17 dirt
execute in minecraft:overworld run setblock 403 65 17 grass_block
execute in minecraft:overworld run fill 403 66 17 403 144 17 air
execute in minecraft:overworld run fill 403 58 18 403 62 18 stone
execute in minecraft:overworld run fill 403 63 18 403 64 18 dirt
execute in minecraft:overworld run setblock 403 65 18 coarse_dirt
execute in minecraft:overworld run fill 403 66 18 403 144 18 air
execute in minecraft:overworld run fill 403 58 19 403 63 19 stone
execute in minecraft:overworld run fill 403 64 19 403 65 19 dirt
execute in minecraft:overworld run setblock 403 66 19 coarse_dirt
execute in minecraft:overworld run fill 403 67 19 403 144 19 air
execute in minecraft:overworld run fill 403 58 20 403 63 20 stone
execute in minecraft:overworld run fill 403 64 20 403 65 20 dirt
execute in minecraft:overworld run setblock 403 66 20 grass_block
execute in minecraft:overworld run fill 403 67 20 403 144 20 air
execute in minecraft:overworld run fill 403 58 21 403 63 21 stone
execute in minecraft:overworld run fill 403 64 21 403 65 21 dirt
execute in minecraft:overworld run setblock 403 66 21 coarse_dirt
execute in minecraft:overworld run fill 403 67 21 403 144 21 air
execute in minecraft:overworld run fill 403 58 22 403 64 22 stone
execute in minecraft:overworld run fill 403 65 22 403 66 22 dirt
execute in minecraft:overworld run setblock 403 67 22 coarse_dirt
execute in minecraft:overworld run fill 403 68 22 403 144 22 air
execute in minecraft:overworld run fill 403 58 23 403 64 23 stone
execute in minecraft:overworld run fill 403 65 23 403 66 23 dirt
execute in minecraft:overworld run setblock 403 67 23 grass_block
execute in minecraft:overworld run fill 403 68 23 403 144 23 air
execute in minecraft:overworld run fill 403 58 24 403 64 24 stone
execute in minecraft:overworld run fill 403 65 24 403 66 24 dirt
execute in minecraft:overworld run setblock 403 67 24 grass_block
execute in minecraft:overworld run fill 403 68 24 403 144 24 air
execute in minecraft:overworld run fill 403 58 25 403 65 25 stone
execute in minecraft:overworld run fill 403 66 25 403 67 25 dirt
execute in minecraft:overworld run setblock 403 68 25 grass_block
execute in minecraft:overworld run fill 403 69 25 403 144 25 air
execute in minecraft:overworld run fill 403 58 26 403 65 26 stone
execute in minecraft:overworld run fill 403 66 26 403 67 26 dirt
execute in minecraft:overworld run setblock 403 68 26 grass_block
execute in minecraft:overworld run fill 403 69 26 403 144 26 air
execute in minecraft:overworld run fill 403 58 27 403 65 27 stone
execute in minecraft:overworld run fill 403 66 27 403 67 27 dirt
execute in minecraft:overworld run setblock 403 68 27 coarse_dirt
execute in minecraft:overworld run fill 403 69 27 403 144 27 air
execute in minecraft:overworld run fill 403 58 28 403 66 28 stone
execute in minecraft:overworld run fill 403 67 28 403 68 28 dirt
execute in minecraft:overworld run setblock 403 69 28 grass_block
execute in minecraft:overworld run fill 403 70 28 403 144 28 air
execute in minecraft:overworld run fill 403 58 29 403 66 29 stone
execute in minecraft:overworld run fill 403 67 29 403 68 29 dirt
execute in minecraft:overworld run setblock 403 69 29 coarse_dirt
execute in minecraft:overworld run fill 403 70 29 403 144 29 air
execute in minecraft:overworld run fill 403 58 30 403 66 30 stone
execute in minecraft:overworld run fill 403 67 30 403 68 30 dirt
execute in minecraft:overworld run setblock 403 69 30 coarse_dirt
execute in minecraft:overworld run fill 403 70 30 403 144 30 air
execute in minecraft:overworld run fill 403 58 31 403 66 31 stone
execute in minecraft:overworld run fill 403 67 31 403 68 31 dirt
execute in minecraft:overworld run setblock 403 69 31 coarse_dirt
execute in minecraft:overworld run fill 403 70 31 403 144 31 air
execute in minecraft:overworld run fill 403 58 32 403 66 32 stone
execute in minecraft:overworld run fill 403 67 32 403 68 32 dirt
execute in minecraft:overworld run setblock 403 69 32 grass_block
execute in minecraft:overworld run fill 403 70 32 403 144 32 air
execute in minecraft:overworld run fill 403 58 33 403 66 33 stone
execute in minecraft:overworld run fill 403 67 33 403 68 33 dirt
execute in minecraft:overworld run setblock 403 69 33 coarse_dirt
schedule function blade_gallery:random/battlefield/part_107 1t replace
