execute in minecraft:overworld run setblock 220 86 -29 gray_concrete
execute in minecraft:overworld run setblock 220 86 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 86 -27 gray_concrete
execute in minecraft:overworld run setblock 222 86 -35 gray_concrete
execute in minecraft:overworld run setblock 222 86 -27 gray_concrete
execute in minecraft:overworld run setblock 223 86 -35 gray_concrete
execute in minecraft:overworld run setblock 223 86 -27 gray_concrete
execute in minecraft:overworld run setblock 225 86 -35 gray_concrete
execute in minecraft:overworld run setblock 225 86 -27 gray_concrete
execute in minecraft:overworld run setblock 226 86 -35 gray_concrete
execute in minecraft:overworld run setblock 226 86 -27 gray_concrete
execute in minecraft:overworld run setblock 227 86 -35 gray_concrete
execute in minecraft:overworld run setblock 227 86 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 86 -35 gray_concrete
execute in minecraft:overworld run setblock 228 86 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 86 -30 gray_concrete
execute in minecraft:overworld run setblock 228 86 -29 gray_concrete
execute in minecraft:overworld run setblock 228 86 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 86 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 87 -34 gray_concrete
execute in minecraft:overworld run setblock 220 87 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 87 -31 gray_concrete
execute in minecraft:overworld run setblock 220 87 -29 gray_concrete
execute in minecraft:overworld run setblock 220 87 -28 gray_concrete
execute in minecraft:overworld run setblock 220 87 -27 gray_concrete
execute in minecraft:overworld run setblock 221 87 -35 gray_concrete
execute in minecraft:overworld run setblock 221 87 -27 gray_concrete
execute in minecraft:overworld run setblock 222 87 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 87 -35 gray_concrete
execute in minecraft:overworld run setblock 224 87 -35 gray_concrete
execute in minecraft:overworld run setblock 224 87 -27 gray_concrete
execute in minecraft:overworld run setblock 225 87 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 226 87 -35 gray_concrete
execute in minecraft:overworld run setblock 226 87 -27 gray_concrete
execute in minecraft:overworld run setblock 227 87 -35 gray_concrete
execute in minecraft:overworld run setblock 227 87 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 87 -34 gray_concrete
execute in minecraft:overworld run setblock 228 87 -33 gray_concrete
execute in minecraft:overworld run setblock 228 87 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 87 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 87 -27 gray_concrete
execute in minecraft:overworld run setblock 220 88 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 88 -33 gray_concrete
execute in minecraft:overworld run setblock 220 88 -32 gray_concrete
execute in minecraft:overworld run setblock 220 88 -31 gray_concrete
execute in minecraft:overworld run setblock 220 88 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 88 -28 gray_concrete
execute in minecraft:overworld run setblock 220 88 -27 gray_concrete
execute in minecraft:overworld run setblock 221 88 -35 gray_concrete
execute in minecraft:overworld run setblock 221 88 -27 gray_concrete
execute in minecraft:overworld run setblock 222 88 -35 gray_concrete
execute in minecraft:overworld run setblock 222 88 -27 gray_concrete
execute in minecraft:overworld run setblock 223 88 -27 gray_concrete
execute in minecraft:overworld run setblock 225 88 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 226 88 -27 gray_concrete
execute in minecraft:overworld run setblock 228 88 -34 gray_concrete
execute in minecraft:overworld run setblock 228 88 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 88 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 88 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 88 -28 gray_concrete
execute in minecraft:overworld run setblock 220 89 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 89 -34 gray_concrete
execute in minecraft:overworld run setblock 220 89 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 89 -29 gray_concrete
execute in minecraft:overworld run setblock 220 89 -28 gray_concrete
execute in minecraft:overworld run setblock 221 89 -35 gray_concrete
execute in minecraft:overworld run setblock 221 89 -33 gray_concrete
execute in minecraft:overworld run setblock 221 89 -31 gray_concrete
execute in minecraft:overworld run setblock 221 89 -29 gray_concrete
execute in minecraft:overworld run setblock 221 89 -28 gray_concrete
execute in minecraft:overworld run setblock 221 89 -27 gray_concrete
execute in minecraft:overworld run setblock 222 89 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 222 89 -33 gray_concrete
execute in minecraft:overworld run setblock 222 89 -32 gray_concrete
execute in minecraft:overworld run setblock 222 89 -30 gray_concrete
execute in minecraft:overworld run setblock 222 89 -29 gray_concrete
execute in minecraft:overworld run setblock 222 89 -27 gray_concrete
execute in minecraft:overworld run setblock 223 89 -35 gray_concrete
execute in minecraft:overworld run setblock 223 89 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 89 -30 gray_concrete
execute in minecraft:overworld run setblock 223 89 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 89 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 89 -35 gray_concrete
execute in minecraft:overworld run setblock 224 89 -34 gray_concrete
execute in minecraft:overworld run setblock 224 89 -33 gray_concrete
execute in minecraft:overworld run setblock 224 89 -32 gray_concrete
execute in minecraft:overworld run setblock 224 89 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 89 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 89 -28 gray_concrete
execute in minecraft:overworld run setblock 224 89 -27 gray_concrete
execute in minecraft:overworld run setblock 225 89 -34 gray_concrete
execute in minecraft:overworld run setblock 225 89 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 225 89 -32 gray_concrete
execute in minecraft:overworld run setblock 225 89 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 225 89 -29 gray_concrete
execute in minecraft:overworld run setblock 225 89 -28 gray_concrete
execute in minecraft:overworld run setblock 225 89 -27 gray_concrete
execute in minecraft:overworld run setblock 226 89 -34 gray_concrete
execute in minecraft:overworld run setblock 226 89 -32 gray_concrete
execute in minecraft:overworld run setblock 226 89 -31 gray_concrete
execute in minecraft:overworld run setblock 226 89 -30 gray_concrete
execute in minecraft:overworld run setblock 226 89 -29 gray_concrete
execute in minecraft:overworld run setblock 226 89 -28 gray_concrete
execute in minecraft:overworld run setblock 226 89 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 89 -34 gray_concrete
execute in minecraft:overworld run setblock 227 89 -29 gray_concrete
execute in minecraft:overworld run setblock 227 89 -28 gray_concrete
execute in minecraft:overworld run setblock 228 89 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 89 -33 gray_concrete
execute in minecraft:overworld run setblock 228 89 -32 gray_concrete
execute in minecraft:overworld run setblock 228 89 -31 gray_concrete
execute in minecraft:overworld run setblock 228 89 -30 gray_concrete
execute in minecraft:overworld run setblock 228 89 -29 gray_concrete
execute in minecraft:overworld run setblock 228 89 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 90 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 90 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 90 -32 gray_concrete
execute in minecraft:overworld run setblock 220 90 -31 gray_concrete
execute in minecraft:overworld run setblock 220 90 -28 gray_concrete
execute in minecraft:overworld run setblock 220 90 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 90 -35 gray_concrete
execute in minecraft:overworld run setblock 221 90 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 222 90 -35 gray_concrete
execute in minecraft:overworld run setblock 222 90 -27 gray_concrete
execute in minecraft:overworld run setblock 224 90 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 90 -27 gray_concrete
execute in minecraft:overworld run setblock 225 90 -35 gray_concrete
execute in minecraft:overworld run setblock 226 90 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 90 -35 gray_concrete
execute in minecraft:overworld run setblock 227 90 -27 gray_concrete
execute in minecraft:overworld run setblock 228 90 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 90 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 91 -34 gray_concrete
execute in minecraft:overworld run setblock 220 91 -33 gray_concrete
execute in minecraft:overworld run setblock 220 91 -31 gray_concrete
execute in minecraft:overworld run setblock 220 91 -30 gray_concrete
execute in minecraft:overworld run setblock 220 91 -29 gray_concrete
execute in minecraft:overworld run setblock 220 91 -27 gray_concrete
execute in minecraft:overworld run setblock 221 91 -27 gray_concrete
execute in minecraft:overworld run setblock 222 91 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 91 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 91 -27 gray_concrete
execute in minecraft:overworld run setblock 224 91 -27 gray_concrete
execute in minecraft:overworld run setblock 225 91 -35 gray_concrete
execute in minecraft:overworld run setblock 225 91 -27 gray_concrete
execute in minecraft:overworld run setblock 226 91 -27 gray_concrete
execute in minecraft:overworld run setblock 227 91 -35 gray_concrete
execute in minecraft:overworld run setblock 227 91 -27 gray_concrete
execute in minecraft:overworld run setblock 228 91 -35 gray_concrete
execute in minecraft:overworld run setblock 228 91 -32 gray_concrete
execute in minecraft:overworld run setblock 228 91 -29 gray_concrete
execute in minecraft:overworld run setblock 228 91 -28 gray_concrete
execute in minecraft:overworld run setblock 220 92 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 92 -32 gray_concrete
execute in minecraft:overworld run setblock 220 92 -31 gray_concrete
execute in minecraft:overworld run setblock 220 92 -29 gray_concrete
execute in minecraft:overworld run setblock 220 92 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 92 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 92 -27 gray_concrete
execute in minecraft:overworld run setblock 222 92 -27 gray_concrete
execute in minecraft:overworld run setblock 223 92 -35 gray_concrete
execute in minecraft:overworld run setblock 224 92 -35 gray_concrete
execute in minecraft:overworld run setblock 225 92 -35 gray_concrete
execute in minecraft:overworld run setblock 226 92 -27 gray_concrete
execute in minecraft:overworld run setblock 227 92 -35 gray_concrete
execute in minecraft:overworld run setblock 227 92 -27 gray_concrete
execute in minecraft:overworld run setblock 228 92 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 92 -34 gray_concrete
execute in minecraft:overworld run setblock 228 92 -33 gray_concrete
execute in minecraft:overworld run setblock 220 93 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 93 -34 gray_concrete
execute in minecraft:overworld run setblock 220 93 -31 gray_concrete
execute in minecraft:overworld run setblock 220 93 -28 gray_concrete
execute in minecraft:overworld run setblock 220 93 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 93 -35 gray_concrete
execute in minecraft:overworld run setblock 222 93 -27 gray_concrete
execute in minecraft:overworld run setblock 224 93 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 93 -27 gray_concrete
execute in minecraft:overworld run setblock 227 93 -35 gray_concrete
execute in minecraft:overworld run setblock 228 93 -35 gray_concrete
execute in minecraft:overworld run setblock 228 93 -33 gray_concrete
execute in minecraft:overworld run setblock 228 93 -32 gray_concrete
execute in minecraft:overworld run setblock 228 93 -28 gray_concrete
execute in minecraft:overworld run setblock 220 94 -33 gray_concrete
execute in minecraft:overworld run setblock 220 94 -30 gray_concrete
execute in minecraft:overworld run setblock 220 94 -28 gray_concrete
execute in minecraft:overworld run setblock 221 94 -35 gray_concrete
execute in minecraft:overworld run setblock 221 94 -34 gray_concrete
execute in minecraft:overworld run setblock 221 94 -33 gray_concrete
execute in minecraft:overworld run setblock 221 94 -32 gray_concrete
execute in minecraft:overworld run setblock 221 94 -30 gray_concrete
execute in minecraft:overworld run setblock 221 94 -29 gray_concrete
execute in minecraft:overworld run setblock 221 94 -28 gray_concrete
execute in minecraft:overworld run setblock 221 94 -27 gray_concrete
execute in minecraft:overworld run setblock 222 94 -34 gray_concrete
execute in minecraft:overworld run setblock 222 94 -33 gray_concrete
execute in minecraft:overworld run setblock 222 94 -32 gray_concrete
execute in minecraft:overworld run setblock 222 94 -30 gray_concrete
execute in minecraft:overworld run setblock 222 94 -28 gray_concrete
execute in minecraft:overworld run setblock 223 94 -33 gray_concrete
execute in minecraft:overworld run setblock 223 94 -32 gray_concrete
execute in minecraft:overworld run setblock 223 94 -29 gray_concrete
execute in minecraft:overworld run setblock 223 94 -28 gray_concrete
execute in minecraft:overworld run setblock 223 94 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 94 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 94 -33 gray_concrete
execute in minecraft:overworld run setblock 224 94 -32 gray_concrete
execute in minecraft:overworld run setblock 224 94 -31 gray_concrete
execute in minecraft:overworld run setblock 224 94 -29 gray_concrete
execute in minecraft:overworld run setblock 224 94 -28 gray_concrete
execute in minecraft:overworld run setblock 225 94 -35 gray_concrete
execute in minecraft:overworld run setblock 225 94 -33 gray_concrete
execute in minecraft:overworld run setblock 225 94 -32 gray_concrete
execute in minecraft:overworld run setblock 225 94 -28 gray_concrete
execute in minecraft:overworld run setblock 226 94 -35 gray_concrete
execute in minecraft:overworld run setblock 226 94 -33 gray_concrete
execute in minecraft:overworld run setblock 226 94 -32 gray_concrete
execute in minecraft:overworld run setblock 226 94 -31 gray_concrete
execute in minecraft:overworld run setblock 226 94 -29 gray_concrete
execute in minecraft:overworld run setblock 226 94 -28 gray_concrete
execute in minecraft:overworld run setblock 227 94 -35 gray_concrete
execute in minecraft:overworld run setblock 227 94 -34 gray_concrete
execute in minecraft:overworld run setblock 227 94 -33 gray_concrete
execute in minecraft:overworld run setblock 227 94 -32 gray_concrete
execute in minecraft:overworld run setblock 227 94 -30 gray_concrete
execute in minecraft:overworld run setblock 227 94 -29 gray_concrete
execute in minecraft:overworld run setblock 227 94 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 94 -34 gray_concrete
execute in minecraft:overworld run setblock 228 94 -33 gray_concrete
execute in minecraft:overworld run setblock 228 94 -30 gray_concrete
execute in minecraft:overworld run setblock 228 94 -28 gray_concrete
execute in minecraft:overworld run fill 236 77 -36 236 78 -36 stone_bricks
execute in minecraft:overworld run fill 236 76 -35 236 78 -35 stone_bricks
execute in minecraft:overworld run fill 236 76 -34 236 78 -34 stone_bricks
execute in minecraft:overworld run fill 236 76 -33 236 78 -33 stone_bricks
execute in minecraft:overworld run fill 236 75 -32 236 78 -32 stone_bricks
execute in minecraft:overworld run fill 236 75 -31 236 78 -31 stone_bricks
execute in minecraft:overworld run fill 236 74 -30 236 78 -30 stone_bricks
execute in minecraft:overworld run fill 236 74 -29 236 78 -29 stone_bricks
execute in minecraft:overworld run fill 236 74 -28 236 78 -28 stone_bricks
execute in minecraft:overworld run fill 237 76 -36 237 78 -36 stone_bricks
execute in minecraft:overworld run fill 237 76 -35 237 78 -35 stone_bricks
execute in minecraft:overworld run fill 237 76 -34 237 78 -34 stone_bricks
execute in minecraft:overworld run fill 237 76 -33 237 78 -33 stone_bricks
execute in minecraft:overworld run fill 237 75 -32 237 78 -32 stone_bricks
execute in minecraft:overworld run fill 237 75 -31 237 78 -31 stone_bricks
execute in minecraft:overworld run fill 237 75 -30 237 78 -30 stone_bricks
execute in minecraft:overworld run fill 237 74 -29 237 78 -29 stone_bricks
execute in minecraft:overworld run fill 237 74 -28 237 78 -28 stone_bricks
execute in minecraft:overworld run fill 238 76 -36 238 78 -36 stone_bricks
execute in minecraft:overworld run fill 238 76 -35 238 78 -35 stone_bricks
execute in minecraft:overworld run fill 238 76 -34 238 78 -34 stone_bricks
execute in minecraft:overworld run fill 238 75 -33 238 78 -33 stone_bricks
execute in minecraft:overworld run fill 238 75 -32 238 78 -32 stone_bricks
execute in minecraft:overworld run fill 238 75 -31 238 78 -31 stone_bricks
execute in minecraft:overworld run fill 238 75 -30 238 78 -30 stone_bricks
schedule function blade_gallery:random/burned/part_154 1t replace
