execute in minecraft:overworld run fill 263 56 1 263 57 1 dirt
execute in minecraft:overworld run setblock 263 58 1 gravel
execute in minecraft:overworld run fill 263 59 1 263 144 1 air
execute in minecraft:overworld run fill 263 59 1 263 64 1 water
execute in minecraft:overworld run fill 263 58 2 263 55 2 stone
execute in minecraft:overworld run fill 263 56 2 263 57 2 dirt
execute in minecraft:overworld run setblock 263 58 2 gravel
execute in minecraft:overworld run fill 263 59 2 263 144 2 air
execute in minecraft:overworld run fill 263 59 2 263 64 2 water
execute in minecraft:overworld run fill 263 58 3 263 55 3 stone
execute in minecraft:overworld run fill 263 56 3 263 57 3 dirt
execute in minecraft:overworld run setblock 263 58 3 gravel
execute in minecraft:overworld run fill 263 59 3 263 144 3 air
execute in minecraft:overworld run fill 263 59 3 263 64 3 water
execute in minecraft:overworld run fill 263 58 4 263 55 4 stone
execute in minecraft:overworld run fill 263 56 4 263 57 4 dirt
execute in minecraft:overworld run setblock 263 58 4 gravel
execute in minecraft:overworld run fill 263 59 4 263 144 4 air
execute in minecraft:overworld run fill 263 59 4 263 64 4 water
execute in minecraft:overworld run fill 263 58 5 263 56 5 stone
execute in minecraft:overworld run fill 263 57 5 263 58 5 dirt
execute in minecraft:overworld run setblock 263 59 5 gravel
execute in minecraft:overworld run fill 263 60 5 263 144 5 air
execute in minecraft:overworld run fill 263 60 5 263 64 5 water
execute in minecraft:overworld run fill 263 58 6 263 56 6 stone
execute in minecraft:overworld run fill 263 57 6 263 58 6 dirt
execute in minecraft:overworld run setblock 263 59 6 gravel
execute in minecraft:overworld run fill 263 60 6 263 144 6 air
execute in minecraft:overworld run fill 263 60 6 263 64 6 water
execute in minecraft:overworld run fill 263 58 7 263 56 7 stone
execute in minecraft:overworld run fill 263 57 7 263 58 7 dirt
execute in minecraft:overworld run setblock 263 59 7 gravel
execute in minecraft:overworld run fill 263 60 7 263 144 7 air
execute in minecraft:overworld run fill 263 60 7 263 64 7 water
execute in minecraft:overworld run fill 263 58 8 263 56 8 stone
execute in minecraft:overworld run fill 263 57 8 263 58 8 dirt
execute in minecraft:overworld run setblock 263 59 8 gravel
execute in minecraft:overworld run fill 263 60 8 263 144 8 air
execute in minecraft:overworld run fill 263 60 8 263 64 8 water
execute in minecraft:overworld run fill 263 58 9 263 56 9 stone
execute in minecraft:overworld run fill 263 57 9 263 58 9 dirt
execute in minecraft:overworld run setblock 263 59 9 gravel
execute in minecraft:overworld run fill 263 60 9 263 144 9 air
execute in minecraft:overworld run fill 263 60 9 263 64 9 water
execute in minecraft:overworld run fill 263 58 10 263 56 10 stone
execute in minecraft:overworld run fill 263 57 10 263 58 10 dirt
execute in minecraft:overworld run setblock 263 59 10 gravel
execute in minecraft:overworld run fill 263 60 10 263 144 10 air
execute in minecraft:overworld run fill 263 60 10 263 64 10 water
execute in minecraft:overworld run fill 263 58 11 263 57 11 stone
execute in minecraft:overworld run fill 263 58 11 263 59 11 dirt
execute in minecraft:overworld run setblock 263 60 11 gravel
execute in minecraft:overworld run fill 263 61 11 263 144 11 air
execute in minecraft:overworld run fill 263 61 11 263 64 11 water
execute in minecraft:overworld run fill 263 58 12 263 57 12 stone
execute in minecraft:overworld run fill 263 58 12 263 59 12 dirt
execute in minecraft:overworld run setblock 263 60 12 gravel
execute in minecraft:overworld run fill 263 61 12 263 144 12 air
execute in minecraft:overworld run fill 263 61 12 263 64 12 water
execute in minecraft:overworld run fill 263 58 13 263 57 13 stone
execute in minecraft:overworld run fill 263 58 13 263 59 13 dirt
execute in minecraft:overworld run setblock 263 60 13 gravel
execute in minecraft:overworld run fill 263 61 13 263 144 13 air
execute in minecraft:overworld run fill 263 61 13 263 64 13 water
execute in minecraft:overworld run fill 263 58 14 263 58 14 stone
execute in minecraft:overworld run fill 263 59 14 263 60 14 dirt
execute in minecraft:overworld run setblock 263 61 14 gravel
execute in minecraft:overworld run fill 263 62 14 263 144 14 air
execute in minecraft:overworld run fill 263 62 14 263 64 14 water
execute in minecraft:overworld run fill 263 58 15 263 58 15 stone
execute in minecraft:overworld run fill 263 59 15 263 60 15 dirt
execute in minecraft:overworld run setblock 263 61 15 gravel
execute in minecraft:overworld run fill 263 62 15 263 144 15 air
execute in minecraft:overworld run fill 263 62 15 263 64 15 water
execute in minecraft:overworld run fill 263 58 16 263 58 16 stone
execute in minecraft:overworld run fill 263 59 16 263 60 16 dirt
execute in minecraft:overworld run setblock 263 61 16 gravel
execute in minecraft:overworld run fill 263 62 16 263 144 16 air
execute in minecraft:overworld run fill 263 62 16 263 64 16 water
execute in minecraft:overworld run fill 263 58 17 263 58 17 stone
execute in minecraft:overworld run fill 263 59 17 263 60 17 dirt
execute in minecraft:overworld run setblock 263 61 17 gravel
execute in minecraft:overworld run fill 263 62 17 263 144 17 air
execute in minecraft:overworld run fill 263 62 17 263 64 17 water
execute in minecraft:overworld run fill 263 58 18 263 58 18 stone
execute in minecraft:overworld run fill 263 59 18 263 60 18 dirt
execute in minecraft:overworld run setblock 263 61 18 gravel
execute in minecraft:overworld run fill 263 62 18 263 144 18 air
execute in minecraft:overworld run fill 263 62 18 263 64 18 water
execute in minecraft:overworld run fill 263 58 19 263 58 19 stone
execute in minecraft:overworld run fill 263 59 19 263 60 19 dirt
execute in minecraft:overworld run setblock 263 61 19 gravel
execute in minecraft:overworld run fill 263 62 19 263 144 19 air
execute in minecraft:overworld run fill 263 62 19 263 64 19 water
execute in minecraft:overworld run fill 263 58 20 263 58 20 stone
execute in minecraft:overworld run fill 263 59 20 263 60 20 dirt
execute in minecraft:overworld run setblock 263 61 20 gravel
execute in minecraft:overworld run fill 263 62 20 263 144 20 air
execute in minecraft:overworld run fill 263 62 20 263 64 20 water
execute in minecraft:overworld run fill 263 58 21 263 58 21 stone
execute in minecraft:overworld run fill 263 59 21 263 60 21 dirt
execute in minecraft:overworld run setblock 263 61 21 gravel
execute in minecraft:overworld run fill 263 62 21 263 144 21 air
execute in minecraft:overworld run fill 263 62 21 263 64 21 water
execute in minecraft:overworld run fill 263 58 22 263 57 22 stone
execute in minecraft:overworld run fill 263 58 22 263 59 22 dirt
execute in minecraft:overworld run setblock 263 60 22 gravel
execute in minecraft:overworld run fill 263 61 22 263 144 22 air
execute in minecraft:overworld run fill 263 61 22 263 64 22 water
execute in minecraft:overworld run fill 263 58 23 263 57 23 stone
execute in minecraft:overworld run fill 263 58 23 263 59 23 dirt
execute in minecraft:overworld run setblock 263 60 23 gravel
execute in minecraft:overworld run fill 263 61 23 263 144 23 air
execute in minecraft:overworld run fill 263 61 23 263 64 23 water
execute in minecraft:overworld run fill 263 58 24 263 57 24 stone
execute in minecraft:overworld run fill 263 58 24 263 59 24 dirt
execute in minecraft:overworld run setblock 263 60 24 gravel
execute in minecraft:overworld run fill 263 61 24 263 144 24 air
execute in minecraft:overworld run fill 263 61 24 263 64 24 water
execute in minecraft:overworld run fill 263 58 25 263 57 25 stone
execute in minecraft:overworld run fill 263 58 25 263 59 25 dirt
execute in minecraft:overworld run setblock 263 60 25 gravel
execute in minecraft:overworld run fill 263 61 25 263 144 25 air
execute in minecraft:overworld run fill 263 61 25 263 64 25 water
execute in minecraft:overworld run fill 263 58 26 263 56 26 stone
execute in minecraft:overworld run fill 263 57 26 263 58 26 dirt
execute in minecraft:overworld run setblock 263 59 26 gravel
execute in minecraft:overworld run fill 263 60 26 263 144 26 air
execute in minecraft:overworld run fill 263 60 26 263 64 26 water
execute in minecraft:overworld run fill 263 58 27 263 56 27 stone
execute in minecraft:overworld run fill 263 57 27 263 58 27 dirt
execute in minecraft:overworld run setblock 263 59 27 gravel
execute in minecraft:overworld run fill 263 60 27 263 144 27 air
execute in minecraft:overworld run fill 263 60 27 263 64 27 water
execute in minecraft:overworld run fill 263 58 28 263 56 28 stone
execute in minecraft:overworld run fill 263 57 28 263 58 28 dirt
execute in minecraft:overworld run setblock 263 59 28 gravel
execute in minecraft:overworld run fill 263 60 28 263 144 28 air
execute in minecraft:overworld run fill 263 60 28 263 64 28 water
execute in minecraft:overworld run fill 263 58 29 263 56 29 stone
execute in minecraft:overworld run fill 263 57 29 263 58 29 dirt
execute in minecraft:overworld run setblock 263 59 29 gravel
execute in minecraft:overworld run fill 263 60 29 263 144 29 air
execute in minecraft:overworld run fill 263 60 29 263 64 29 water
execute in minecraft:overworld run fill 263 58 30 263 55 30 stone
execute in minecraft:overworld run fill 263 56 30 263 57 30 dirt
execute in minecraft:overworld run setblock 263 58 30 gravel
execute in minecraft:overworld run fill 263 59 30 263 144 30 air
execute in minecraft:overworld run fill 263 59 30 263 64 30 water
execute in minecraft:overworld run fill 263 58 31 263 55 31 stone
execute in minecraft:overworld run fill 263 56 31 263 57 31 dirt
execute in minecraft:overworld run setblock 263 58 31 gravel
execute in minecraft:overworld run fill 263 59 31 263 144 31 air
execute in minecraft:overworld run fill 263 59 31 263 64 31 water
execute in minecraft:overworld run fill 263 58 32 263 55 32 stone
execute in minecraft:overworld run fill 263 56 32 263 57 32 dirt
execute in minecraft:overworld run setblock 263 58 32 gravel
execute in minecraft:overworld run fill 263 59 32 263 144 32 air
execute in minecraft:overworld run fill 263 59 32 263 64 32 water
execute in minecraft:overworld run fill 263 58 33 263 55 33 stone
execute in minecraft:overworld run fill 263 56 33 263 57 33 dirt
execute in minecraft:overworld run setblock 263 58 33 gravel
execute in minecraft:overworld run fill 263 59 33 263 144 33 air
execute in minecraft:overworld run fill 263 59 33 263 64 33 water
execute in minecraft:overworld run fill 263 58 34 263 55 34 stone
execute in minecraft:overworld run fill 263 56 34 263 57 34 dirt
execute in minecraft:overworld run setblock 263 58 34 gravel
execute in minecraft:overworld run fill 263 59 34 263 144 34 air
execute in minecraft:overworld run fill 263 59 34 263 64 34 water
execute in minecraft:overworld run fill 263 58 35 263 55 35 stone
execute in minecraft:overworld run fill 263 56 35 263 57 35 dirt
execute in minecraft:overworld run setblock 263 58 35 gravel
execute in minecraft:overworld run fill 263 59 35 263 144 35 air
execute in minecraft:overworld run fill 263 59 35 263 64 35 water
execute in minecraft:overworld run fill 263 58 36 263 55 36 stone
execute in minecraft:overworld run fill 263 56 36 263 57 36 dirt
execute in minecraft:overworld run setblock 263 58 36 gravel
execute in minecraft:overworld run fill 263 59 36 263 144 36 air
execute in minecraft:overworld run fill 263 59 36 263 64 36 water
execute in minecraft:overworld run fill 263 58 37 263 55 37 stone
execute in minecraft:overworld run fill 263 56 37 263 57 37 dirt
execute in minecraft:overworld run setblock 263 58 37 gravel
execute in minecraft:overworld run fill 263 59 37 263 144 37 air
execute in minecraft:overworld run fill 263 59 37 263 64 37 water
execute in minecraft:overworld run fill 263 58 38 263 55 38 stone
execute in minecraft:overworld run fill 263 56 38 263 57 38 dirt
execute in minecraft:overworld run setblock 263 58 38 gravel
execute in minecraft:overworld run fill 263 59 38 263 144 38 air
execute in minecraft:overworld run fill 263 59 38 263 64 38 water
execute in minecraft:overworld run fill 263 58 39 263 56 39 stone
execute in minecraft:overworld run fill 263 57 39 263 58 39 dirt
execute in minecraft:overworld run setblock 263 59 39 gravel
execute in minecraft:overworld run fill 263 60 39 263 144 39 air
execute in minecraft:overworld run fill 263 60 39 263 64 39 water
execute in minecraft:overworld run fill 263 58 40 263 57 40 stone
execute in minecraft:overworld run fill 263 58 40 263 59 40 dirt
execute in minecraft:overworld run setblock 263 60 40 gravel
execute in minecraft:overworld run fill 263 61 40 263 144 40 air
execute in minecraft:overworld run fill 263 61 40 263 64 40 water
execute in minecraft:overworld run fill 263 58 41 263 58 41 stone
execute in minecraft:overworld run fill 263 59 41 263 60 41 dirt
execute in minecraft:overworld run setblock 263 61 41 gravel
execute in minecraft:overworld run fill 263 62 41 263 144 41 air
execute in minecraft:overworld run fill 263 62 41 263 64 41 water
execute in minecraft:overworld run fill 263 58 42 263 59 42 stone
execute in minecraft:overworld run fill 263 60 42 263 61 42 dirt
execute in minecraft:overworld run setblock 263 62 42 gravel
execute in minecraft:overworld run fill 263 63 42 263 144 42 air
execute in minecraft:overworld run fill 263 63 42 263 64 42 water
execute in minecraft:overworld run fill 263 58 43 263 59 43 stone
execute in minecraft:overworld run fill 263 60 43 263 61 43 dirt
execute in minecraft:overworld run setblock 263 62 43 gravel
execute in minecraft:overworld run fill 263 63 43 263 144 43 air
execute in minecraft:overworld run fill 263 63 43 263 64 43 water
execute in minecraft:overworld run fill 263 58 44 263 60 44 stone
execute in minecraft:overworld run fill 263 61 44 263 62 44 dirt
execute in minecraft:overworld run setblock 263 63 44 gravel
execute in minecraft:overworld run fill 263 64 44 263 144 44 air
execute in minecraft:overworld run fill 263 64 44 263 64 44 water
execute in minecraft:overworld run fill 263 58 45 263 60 45 stone
execute in minecraft:overworld run fill 263 61 45 263 62 45 dirt
execute in minecraft:overworld run setblock 263 63 45 gravel
execute in minecraft:overworld run fill 263 64 45 263 144 45 air
execute in minecraft:overworld run fill 263 64 45 263 64 45 water
execute in minecraft:overworld run fill 263 58 46 263 61 46 stone
execute in minecraft:overworld run fill 263 62 46 263 63 46 dirt
execute in minecraft:overworld run setblock 263 64 46 grass_block
execute in minecraft:overworld run fill 263 65 46 263 144 46 air
execute in minecraft:overworld run fill 263 58 47 263 61 47 stone
execute in minecraft:overworld run fill 263 62 47 263 63 47 dirt
execute in minecraft:overworld run setblock 263 64 47 grass_block
execute in minecraft:overworld run fill 263 65 47 263 144 47 air
execute in minecraft:overworld run fill 264 58 -48 264 61 -48 stone
execute in minecraft:overworld run fill 264 62 -48 264 63 -48 dirt
execute in minecraft:overworld run setblock 264 64 -48 grass_block
execute in minecraft:overworld run fill 264 65 -48 264 144 -48 air
execute in minecraft:overworld run fill 264 58 -47 264 63 -47 stone
execute in minecraft:overworld run fill 264 64 -47 264 65 -47 dirt
execute in minecraft:overworld run setblock 264 66 -47 grass_block
execute in minecraft:overworld run fill 264 67 -47 264 144 -47 air
execute in minecraft:overworld run fill 264 58 -46 264 65 -46 stone
execute in minecraft:overworld run fill 264 66 -46 264 67 -46 dirt
execute in minecraft:overworld run setblock 264 68 -46 grass_block
execute in minecraft:overworld run fill 264 69 -46 264 144 -46 air
execute in minecraft:overworld run fill 264 58 -45 264 66 -45 stone
execute in minecraft:overworld run fill 264 67 -45 264 68 -45 dirt
execute in minecraft:overworld run setblock 264 69 -45 coarse_dirt
execute in minecraft:overworld run fill 264 70 -45 264 144 -45 air
execute in minecraft:overworld run fill 264 58 -44 264 68 -44 stone
execute in minecraft:overworld run fill 264 69 -44 264 70 -44 dirt
execute in minecraft:overworld run setblock 264 71 -44 grass_block
execute in minecraft:overworld run fill 264 72 -44 264 144 -44 air
execute in minecraft:overworld run fill 264 58 -43 264 70 -43 stone
execute in minecraft:overworld run fill 264 71 -43 264 72 -43 dirt
execute in minecraft:overworld run setblock 264 73 -43 coarse_dirt
execute in minecraft:overworld run fill 264 74 -43 264 144 -43 air
schedule function blade_gallery:random/burned/part_88 1t replace
