execute in minecraft:overworld run fill 298 65 25 298 66 25 dirt
execute in minecraft:overworld run setblock 298 67 25 coarse_dirt
execute in minecraft:overworld run fill 298 68 25 298 144 25 air
execute in minecraft:overworld run fill 298 58 26 298 64 26 stone
execute in minecraft:overworld run fill 298 65 26 298 66 26 dirt
execute in minecraft:overworld run setblock 298 67 26 coarse_dirt
execute in minecraft:overworld run fill 298 68 26 298 144 26 air
execute in minecraft:overworld run fill 298 58 27 298 64 27 stone
execute in minecraft:overworld run fill 298 65 27 298 66 27 dirt
execute in minecraft:overworld run setblock 298 67 27 coarse_dirt
execute in minecraft:overworld run fill 298 68 27 298 144 27 air
execute in minecraft:overworld run fill 298 58 28 298 64 28 stone
execute in minecraft:overworld run fill 298 65 28 298 66 28 dirt
execute in minecraft:overworld run setblock 298 67 28 grass_block
execute in minecraft:overworld run fill 298 68 28 298 144 28 air
execute in minecraft:overworld run fill 298 58 29 298 64 29 stone
execute in minecraft:overworld run fill 298 65 29 298 66 29 dirt
execute in minecraft:overworld run setblock 298 67 29 grass_block
execute in minecraft:overworld run fill 298 68 29 298 144 29 air
execute in minecraft:overworld run fill 298 58 30 298 64 30 stone
execute in minecraft:overworld run fill 298 65 30 298 66 30 dirt
execute in minecraft:overworld run setblock 298 67 30 coarse_dirt
execute in minecraft:overworld run fill 298 68 30 298 144 30 air
execute in minecraft:overworld run fill 298 58 31 298 64 31 stone
execute in minecraft:overworld run fill 298 65 31 298 66 31 dirt
execute in minecraft:overworld run setblock 298 67 31 grass_block
execute in minecraft:overworld run fill 298 68 31 298 144 31 air
execute in minecraft:overworld run fill 298 58 32 298 64 32 stone
execute in minecraft:overworld run fill 298 65 32 298 66 32 dirt
execute in minecraft:overworld run setblock 298 67 32 coarse_dirt
execute in minecraft:overworld run fill 298 68 32 298 144 32 air
execute in minecraft:overworld run fill 298 58 33 298 64 33 stone
execute in minecraft:overworld run fill 298 65 33 298 66 33 dirt
execute in minecraft:overworld run setblock 298 67 33 grass_block
execute in minecraft:overworld run fill 298 68 33 298 144 33 air
execute in minecraft:overworld run fill 298 58 34 298 64 34 stone
execute in minecraft:overworld run fill 298 65 34 298 66 34 dirt
execute in minecraft:overworld run setblock 298 67 34 coarse_dirt
execute in minecraft:overworld run fill 298 68 34 298 144 34 air
execute in minecraft:overworld run fill 298 58 35 298 64 35 stone
execute in minecraft:overworld run fill 298 65 35 298 66 35 dirt
execute in minecraft:overworld run setblock 298 67 35 coarse_dirt
execute in minecraft:overworld run fill 298 68 35 298 144 35 air
execute in minecraft:overworld run fill 298 58 36 298 63 36 stone
execute in minecraft:overworld run fill 298 64 36 298 65 36 dirt
execute in minecraft:overworld run setblock 298 66 36 coarse_dirt
execute in minecraft:overworld run fill 298 67 36 298 144 36 air
execute in minecraft:overworld run fill 298 58 37 298 63 37 stone
execute in minecraft:overworld run fill 298 64 37 298 65 37 dirt
execute in minecraft:overworld run setblock 298 66 37 coarse_dirt
execute in minecraft:overworld run fill 298 67 37 298 144 37 air
execute in minecraft:overworld run fill 298 58 38 298 63 38 stone
execute in minecraft:overworld run fill 298 64 38 298 65 38 dirt
execute in minecraft:overworld run setblock 298 66 38 coarse_dirt
execute in minecraft:overworld run fill 298 67 38 298 144 38 air
execute in minecraft:overworld run fill 298 58 39 298 63 39 stone
execute in minecraft:overworld run fill 298 64 39 298 65 39 dirt
execute in minecraft:overworld run setblock 298 66 39 coarse_dirt
execute in minecraft:overworld run fill 298 67 39 298 144 39 air
execute in minecraft:overworld run fill 298 58 40 298 63 40 stone
execute in minecraft:overworld run fill 298 64 40 298 65 40 dirt
execute in minecraft:overworld run setblock 298 66 40 coarse_dirt
execute in minecraft:overworld run fill 298 67 40 298 144 40 air
execute in minecraft:overworld run fill 298 58 41 298 63 41 stone
execute in minecraft:overworld run fill 298 64 41 298 65 41 dirt
execute in minecraft:overworld run setblock 298 66 41 coarse_dirt
execute in minecraft:overworld run fill 298 67 41 298 144 41 air
execute in minecraft:overworld run fill 298 58 42 298 63 42 stone
execute in minecraft:overworld run fill 298 64 42 298 65 42 dirt
execute in minecraft:overworld run setblock 298 66 42 grass_block
execute in minecraft:overworld run fill 298 67 42 298 144 42 air
execute in minecraft:overworld run fill 298 58 43 298 63 43 stone
execute in minecraft:overworld run fill 298 64 43 298 65 43 dirt
execute in minecraft:overworld run setblock 298 66 43 grass_block
execute in minecraft:overworld run fill 298 67 43 298 144 43 air
execute in minecraft:overworld run fill 298 58 44 298 62 44 stone
execute in minecraft:overworld run fill 298 63 44 298 64 44 dirt
execute in minecraft:overworld run setblock 298 65 44 coarse_dirt
execute in minecraft:overworld run fill 298 66 44 298 144 44 air
execute in minecraft:overworld run fill 298 58 45 298 62 45 stone
execute in minecraft:overworld run fill 298 63 45 298 64 45 dirt
execute in minecraft:overworld run setblock 298 65 45 grass_block
execute in minecraft:overworld run fill 298 66 45 298 144 45 air
execute in minecraft:overworld run fill 298 58 46 298 62 46 stone
execute in minecraft:overworld run fill 298 63 46 298 64 46 dirt
execute in minecraft:overworld run setblock 298 65 46 coarse_dirt
execute in minecraft:overworld run fill 298 66 46 298 144 46 air
execute in minecraft:overworld run fill 298 58 47 298 61 47 stone
execute in minecraft:overworld run fill 298 62 47 298 63 47 dirt
execute in minecraft:overworld run setblock 298 64 47 grass_block
execute in minecraft:overworld run fill 298 65 47 298 144 47 air
execute in minecraft:overworld run fill 299 58 -48 299 61 -48 stone
execute in minecraft:overworld run fill 299 62 -48 299 63 -48 dirt
execute in minecraft:overworld run setblock 299 64 -48 grass_block
execute in minecraft:overworld run fill 299 65 -48 299 144 -48 air
execute in minecraft:overworld run fill 299 58 -47 299 63 -47 stone
execute in minecraft:overworld run fill 299 64 -47 299 65 -47 dirt
execute in minecraft:overworld run setblock 299 66 -47 coarse_dirt
execute in minecraft:overworld run fill 299 67 -47 299 144 -47 air
execute in minecraft:overworld run fill 299 58 -46 299 65 -46 stone
execute in minecraft:overworld run fill 299 66 -46 299 67 -46 dirt
execute in minecraft:overworld run setblock 299 68 -46 grass_block
execute in minecraft:overworld run fill 299 69 -46 299 144 -46 air
execute in minecraft:overworld run fill 299 58 -45 299 67 -45 stone
execute in minecraft:overworld run fill 299 68 -45 299 69 -45 dirt
execute in minecraft:overworld run setblock 299 70 -45 coarse_dirt
execute in minecraft:overworld run fill 299 71 -45 299 144 -45 air
execute in minecraft:overworld run fill 299 58 -44 299 69 -44 stone
execute in minecraft:overworld run fill 299 70 -44 299 71 -44 dirt
execute in minecraft:overworld run setblock 299 72 -44 coarse_dirt
execute in minecraft:overworld run fill 299 73 -44 299 144 -44 air
execute in minecraft:overworld run fill 299 58 -43 299 70 -43 stone
execute in minecraft:overworld run fill 299 71 -43 299 72 -43 dirt
execute in minecraft:overworld run setblock 299 73 -43 coarse_dirt
execute in minecraft:overworld run fill 299 74 -43 299 144 -43 air
execute in minecraft:overworld run fill 299 58 -42 299 70 -42 stone
execute in minecraft:overworld run fill 299 71 -42 299 72 -42 dirt
execute in minecraft:overworld run setblock 299 73 -42 coarse_dirt
execute in minecraft:overworld run fill 299 74 -42 299 144 -42 air
execute in minecraft:overworld run fill 299 58 -41 299 70 -41 stone
execute in minecraft:overworld run fill 299 71 -41 299 72 -41 dirt
execute in minecraft:overworld run setblock 299 73 -41 grass_block
execute in minecraft:overworld run fill 299 74 -41 299 144 -41 air
execute in minecraft:overworld run fill 299 58 -40 299 70 -40 stone
execute in minecraft:overworld run fill 299 71 -40 299 72 -40 dirt
execute in minecraft:overworld run setblock 299 73 -40 grass_block
execute in minecraft:overworld run fill 299 74 -40 299 144 -40 air
execute in minecraft:overworld run fill 299 58 -39 299 70 -39 stone
execute in minecraft:overworld run fill 299 71 -39 299 72 -39 dirt
execute in minecraft:overworld run setblock 299 73 -39 grass_block
execute in minecraft:overworld run fill 299 74 -39 299 144 -39 air
execute in minecraft:overworld run fill 299 58 -38 299 70 -38 stone
execute in minecraft:overworld run fill 299 71 -38 299 72 -38 dirt
execute in minecraft:overworld run setblock 299 73 -38 grass_block
execute in minecraft:overworld run fill 299 74 -38 299 144 -38 air
execute in minecraft:overworld run fill 299 58 -37 299 70 -37 stone
execute in minecraft:overworld run fill 299 71 -37 299 72 -37 dirt
execute in minecraft:overworld run setblock 299 73 -37 coarse_dirt
execute in minecraft:overworld run fill 299 74 -37 299 144 -37 air
execute in minecraft:overworld run fill 299 58 -36 299 70 -36 stone
execute in minecraft:overworld run fill 299 71 -36 299 72 -36 dirt
execute in minecraft:overworld run setblock 299 73 -36 coarse_dirt
execute in minecraft:overworld run fill 299 74 -36 299 144 -36 air
execute in minecraft:overworld run fill 299 58 -35 299 70 -35 stone
execute in minecraft:overworld run fill 299 71 -35 299 72 -35 dirt
execute in minecraft:overworld run setblock 299 73 -35 coarse_dirt
execute in minecraft:overworld run fill 299 74 -35 299 144 -35 air
execute in minecraft:overworld run fill 299 58 -34 299 69 -34 stone
execute in minecraft:overworld run fill 299 70 -34 299 71 -34 dirt
execute in minecraft:overworld run setblock 299 72 -34 coarse_dirt
execute in minecraft:overworld run fill 299 73 -34 299 144 -34 air
execute in minecraft:overworld run fill 299 58 -33 299 69 -33 stone
execute in minecraft:overworld run fill 299 70 -33 299 71 -33 dirt
execute in minecraft:overworld run setblock 299 72 -33 grass_block
execute in minecraft:overworld run fill 299 73 -33 299 144 -33 air
execute in minecraft:overworld run fill 299 58 -32 299 69 -32 stone
execute in minecraft:overworld run fill 299 70 -32 299 71 -32 dirt
execute in minecraft:overworld run setblock 299 72 -32 coarse_dirt
execute in minecraft:overworld run fill 299 73 -32 299 144 -32 air
execute in minecraft:overworld run fill 299 58 -31 299 69 -31 stone
execute in minecraft:overworld run fill 299 70 -31 299 71 -31 dirt
execute in minecraft:overworld run setblock 299 72 -31 coarse_dirt
execute in minecraft:overworld run fill 299 73 -31 299 144 -31 air
execute in minecraft:overworld run fill 299 58 -30 299 69 -30 stone
execute in minecraft:overworld run fill 299 70 -30 299 71 -30 dirt
execute in minecraft:overworld run setblock 299 72 -30 grass_block
execute in minecraft:overworld run fill 299 73 -30 299 144 -30 air
execute in minecraft:overworld run fill 299 58 -29 299 68 -29 stone
execute in minecraft:overworld run fill 299 69 -29 299 70 -29 dirt
execute in minecraft:overworld run setblock 299 71 -29 coarse_dirt
execute in minecraft:overworld run fill 299 72 -29 299 144 -29 air
execute in minecraft:overworld run fill 299 58 -28 299 68 -28 stone
execute in minecraft:overworld run fill 299 69 -28 299 70 -28 dirt
execute in minecraft:overworld run setblock 299 71 -28 coarse_dirt
execute in minecraft:overworld run fill 299 72 -28 299 144 -28 air
execute in minecraft:overworld run fill 299 58 -27 299 68 -27 stone
execute in minecraft:overworld run fill 299 69 -27 299 70 -27 dirt
execute in minecraft:overworld run setblock 299 71 -27 grass_block
execute in minecraft:overworld run fill 299 72 -27 299 144 -27 air
execute in minecraft:overworld run fill 299 58 -26 299 68 -26 stone
execute in minecraft:overworld run fill 299 69 -26 299 70 -26 dirt
execute in minecraft:overworld run setblock 299 71 -26 coarse_dirt
execute in minecraft:overworld run fill 299 72 -26 299 144 -26 air
execute in minecraft:overworld run fill 299 58 -25 299 68 -25 stone
execute in minecraft:overworld run fill 299 69 -25 299 70 -25 dirt
execute in minecraft:overworld run setblock 299 71 -25 grass_block
execute in minecraft:overworld run fill 299 72 -25 299 144 -25 air
execute in minecraft:overworld run fill 299 58 -24 299 67 -24 stone
execute in minecraft:overworld run fill 299 68 -24 299 69 -24 dirt
execute in minecraft:overworld run setblock 299 70 -24 coarse_dirt
execute in minecraft:overworld run fill 299 71 -24 299 144 -24 air
execute in minecraft:overworld run fill 299 58 -23 299 67 -23 stone
execute in minecraft:overworld run fill 299 68 -23 299 69 -23 dirt
execute in minecraft:overworld run setblock 299 70 -23 grass_block
execute in minecraft:overworld run fill 299 71 -23 299 144 -23 air
execute in minecraft:overworld run fill 299 58 -22 299 67 -22 stone
execute in minecraft:overworld run fill 299 68 -22 299 69 -22 dirt
execute in minecraft:overworld run setblock 299 70 -22 grass_block
execute in minecraft:overworld run fill 299 71 -22 299 144 -22 air
execute in minecraft:overworld run fill 299 58 -21 299 66 -21 stone
execute in minecraft:overworld run fill 299 67 -21 299 68 -21 dirt
execute in minecraft:overworld run setblock 299 69 -21 grass_block
execute in minecraft:overworld run fill 299 70 -21 299 144 -21 air
execute in minecraft:overworld run fill 299 58 -20 299 66 -20 stone
execute in minecraft:overworld run fill 299 67 -20 299 68 -20 dirt
execute in minecraft:overworld run setblock 299 69 -20 coarse_dirt
execute in minecraft:overworld run fill 299 70 -20 299 144 -20 air
execute in minecraft:overworld run fill 299 58 -19 299 66 -19 stone
execute in minecraft:overworld run fill 299 67 -19 299 68 -19 dirt
execute in minecraft:overworld run setblock 299 69 -19 coarse_dirt
execute in minecraft:overworld run fill 299 70 -19 299 144 -19 air
execute in minecraft:overworld run fill 299 58 -18 299 66 -18 stone
execute in minecraft:overworld run fill 299 67 -18 299 68 -18 dirt
execute in minecraft:overworld run setblock 299 69 -18 grass_block
execute in minecraft:overworld run fill 299 70 -18 299 144 -18 air
execute in minecraft:overworld run fill 299 58 -17 299 66 -17 stone
execute in minecraft:overworld run fill 299 67 -17 299 68 -17 dirt
execute in minecraft:overworld run setblock 299 69 -17 coarse_dirt
execute in minecraft:overworld run fill 299 70 -17 299 144 -17 air
execute in minecraft:overworld run fill 299 58 -16 299 65 -16 stone
execute in minecraft:overworld run fill 299 66 -16 299 67 -16 dirt
execute in minecraft:overworld run setblock 299 68 -16 coarse_dirt
execute in minecraft:overworld run fill 299 69 -16 299 144 -16 air
execute in minecraft:overworld run fill 299 58 -15 299 65 -15 stone
execute in minecraft:overworld run fill 299 66 -15 299 67 -15 dirt
execute in minecraft:overworld run setblock 299 68 -15 coarse_dirt
execute in minecraft:overworld run fill 299 69 -15 299 144 -15 air
execute in minecraft:overworld run fill 299 58 -14 299 65 -14 stone
execute in minecraft:overworld run fill 299 66 -14 299 67 -14 dirt
execute in minecraft:overworld run setblock 299 68 -14 coarse_dirt
execute in minecraft:overworld run fill 299 69 -14 299 144 -14 air
execute in minecraft:overworld run fill 299 58 -13 299 65 -13 stone
execute in minecraft:overworld run fill 299 66 -13 299 67 -13 dirt
execute in minecraft:overworld run setblock 299 68 -13 grass_block
execute in minecraft:overworld run fill 299 69 -13 299 144 -13 air
execute in minecraft:overworld run fill 299 58 -12 299 64 -12 stone
execute in minecraft:overworld run fill 299 65 -12 299 66 -12 dirt
execute in minecraft:overworld run setblock 299 67 -12 coarse_dirt
execute in minecraft:overworld run fill 299 68 -12 299 144 -12 air
execute in minecraft:overworld run fill 299 58 -11 299 64 -11 stone
execute in minecraft:overworld run fill 299 65 -11 299 66 -11 dirt
execute in minecraft:overworld run setblock 299 67 -11 coarse_dirt
execute in minecraft:overworld run fill 299 68 -11 299 144 -11 air
execute in minecraft:overworld run fill 299 58 -10 299 64 -10 stone
execute in minecraft:overworld run fill 299 65 -10 299 66 -10 dirt
execute in minecraft:overworld run setblock 299 67 -10 coarse_dirt
execute in minecraft:overworld run fill 299 68 -10 299 144 -10 air
execute in minecraft:overworld run fill 299 58 -9 299 64 -9 stone
execute in minecraft:overworld run fill 299 65 -9 299 66 -9 dirt
execute in minecraft:overworld run setblock 299 67 -9 grass_block
execute in minecraft:overworld run fill 299 68 -9 299 144 -9 air
execute in minecraft:overworld run fill 299 58 -8 299 64 -8 stone
execute in minecraft:overworld run fill 299 65 -8 299 66 -8 dirt
execute in minecraft:overworld run setblock 299 67 -8 coarse_dirt
execute in minecraft:overworld run fill 299 68 -8 299 144 -8 air
execute in minecraft:overworld run fill 299 58 -7 299 64 -7 stone
schedule function blade_gallery:random/burned/part_144 1t replace
