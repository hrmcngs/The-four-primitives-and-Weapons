execute in minecraft:overworld run fill 271 67 -47 271 144 -47 air
execute in minecraft:overworld run fill 271 58 -46 271 65 -46 stone
execute in minecraft:overworld run fill 271 66 -46 271 67 -46 dirt
execute in minecraft:overworld run setblock 271 68 -46 coarse_dirt
execute in minecraft:overworld run fill 271 69 -46 271 144 -46 air
execute in minecraft:overworld run fill 271 58 -45 271 67 -45 stone
execute in minecraft:overworld run fill 271 68 -45 271 69 -45 dirt
execute in minecraft:overworld run setblock 271 70 -45 coarse_dirt
execute in minecraft:overworld run fill 271 71 -45 271 144 -45 air
execute in minecraft:overworld run fill 271 58 -44 271 69 -44 stone
execute in minecraft:overworld run fill 271 70 -44 271 71 -44 dirt
execute in minecraft:overworld run setblock 271 72 -44 coarse_dirt
execute in minecraft:overworld run fill 271 73 -44 271 144 -44 air
execute in minecraft:overworld run fill 271 58 -43 271 71 -43 stone
execute in minecraft:overworld run fill 271 72 -43 271 73 -43 dirt
execute in minecraft:overworld run setblock 271 74 -43 coarse_dirt
execute in minecraft:overworld run fill 271 75 -43 271 144 -43 air
execute in minecraft:overworld run fill 271 58 -42 271 72 -42 stone
execute in minecraft:overworld run fill 271 73 -42 271 74 -42 dirt
execute in minecraft:overworld run setblock 271 75 -42 coarse_dirt
execute in minecraft:overworld run fill 271 76 -42 271 144 -42 air
execute in minecraft:overworld run fill 271 58 -41 271 74 -41 stone
execute in minecraft:overworld run fill 271 75 -41 271 76 -41 dirt
execute in minecraft:overworld run setblock 271 77 -41 coarse_dirt
execute in minecraft:overworld run fill 271 78 -41 271 144 -41 air
execute in minecraft:overworld run fill 271 58 -40 271 76 -40 stone
execute in minecraft:overworld run fill 271 77 -40 271 78 -40 dirt
execute in minecraft:overworld run setblock 271 79 -40 coarse_dirt
execute in minecraft:overworld run fill 271 80 -40 271 144 -40 air
execute in minecraft:overworld run fill 271 58 -39 271 77 -39 stone
execute in minecraft:overworld run fill 271 78 -39 271 79 -39 dirt
execute in minecraft:overworld run setblock 271 80 -39 grass_block
execute in minecraft:overworld run fill 271 81 -39 271 144 -39 air
execute in minecraft:overworld run fill 271 58 -38 271 78 -38 stone
execute in minecraft:overworld run fill 271 79 -38 271 80 -38 dirt
execute in minecraft:overworld run setblock 271 81 -38 grass_block
execute in minecraft:overworld run fill 271 82 -38 271 144 -38 air
execute in minecraft:overworld run setblock 271 82 -38 grass
execute in minecraft:overworld run fill 271 58 -37 271 78 -37 stone
execute in minecraft:overworld run fill 271 79 -37 271 80 -37 dirt
execute in minecraft:overworld run setblock 271 81 -37 coarse_dirt
execute in minecraft:overworld run fill 271 82 -37 271 144 -37 air
execute in minecraft:overworld run fill 271 58 -36 271 77 -36 stone
execute in minecraft:overworld run fill 271 78 -36 271 79 -36 dirt
execute in minecraft:overworld run setblock 271 80 -36 coarse_dirt
execute in minecraft:overworld run fill 271 81 -36 271 144 -36 air
execute in minecraft:overworld run setblock 271 81 -36 grass
execute in minecraft:overworld run fill 271 58 -35 271 77 -35 stone
execute in minecraft:overworld run fill 271 78 -35 271 79 -35 dirt
execute in minecraft:overworld run setblock 271 80 -35 coarse_dirt
execute in minecraft:overworld run fill 271 81 -35 271 144 -35 air
execute in minecraft:overworld run fill 271 58 -34 271 77 -34 stone
execute in minecraft:overworld run fill 271 78 -34 271 79 -34 dirt
execute in minecraft:overworld run setblock 271 80 -34 grass_block
execute in minecraft:overworld run fill 271 81 -34 271 144 -34 air
execute in minecraft:overworld run fill 271 58 -33 271 76 -33 stone
execute in minecraft:overworld run fill 271 77 -33 271 78 -33 dirt
execute in minecraft:overworld run setblock 271 79 -33 coarse_dirt
execute in minecraft:overworld run fill 271 80 -33 271 144 -33 air
execute in minecraft:overworld run fill 271 58 -32 271 76 -32 stone
execute in minecraft:overworld run fill 271 77 -32 271 78 -32 dirt
execute in minecraft:overworld run setblock 271 79 -32 coarse_dirt
execute in minecraft:overworld run fill 271 80 -32 271 144 -32 air
execute in minecraft:overworld run fill 271 58 -31 271 76 -31 stone
execute in minecraft:overworld run fill 271 77 -31 271 78 -31 dirt
execute in minecraft:overworld run setblock 271 79 -31 coarse_dirt
execute in minecraft:overworld run fill 271 80 -31 271 144 -31 air
execute in minecraft:overworld run fill 271 58 -30 271 75 -30 stone
execute in minecraft:overworld run fill 271 76 -30 271 77 -30 dirt
execute in minecraft:overworld run setblock 271 78 -30 coarse_dirt
execute in minecraft:overworld run fill 271 79 -30 271 144 -30 air
execute in minecraft:overworld run fill 271 58 -29 271 75 -29 stone
execute in minecraft:overworld run fill 271 76 -29 271 77 -29 dirt
execute in minecraft:overworld run setblock 271 78 -29 grass_block
execute in minecraft:overworld run fill 271 79 -29 271 144 -29 air
execute in minecraft:overworld run fill 271 58 -28 271 74 -28 stone
execute in minecraft:overworld run fill 271 75 -28 271 76 -28 dirt
execute in minecraft:overworld run setblock 271 77 -28 coarse_dirt
execute in minecraft:overworld run fill 271 78 -28 271 144 -28 air
execute in minecraft:overworld run fill 271 58 -27 271 74 -27 stone
execute in minecraft:overworld run fill 271 75 -27 271 76 -27 dirt
execute in minecraft:overworld run setblock 271 77 -27 coarse_dirt
execute in minecraft:overworld run fill 271 78 -27 271 144 -27 air
execute in minecraft:overworld run fill 271 58 -26 271 74 -26 stone
execute in minecraft:overworld run fill 271 75 -26 271 76 -26 dirt
execute in minecraft:overworld run setblock 271 77 -26 grass_block
execute in minecraft:overworld run fill 271 78 -26 271 144 -26 air
execute in minecraft:overworld run setblock 271 78 -26 mossy_cobblestone
execute in minecraft:overworld run fill 271 58 -25 271 73 -25 stone
execute in minecraft:overworld run fill 271 74 -25 271 75 -25 dirt
execute in minecraft:overworld run setblock 271 76 -25 coarse_dirt
execute in minecraft:overworld run fill 271 77 -25 271 144 -25 air
execute in minecraft:overworld run fill 271 58 -24 271 73 -24 stone
execute in minecraft:overworld run fill 271 74 -24 271 75 -24 dirt
execute in minecraft:overworld run setblock 271 76 -24 coarse_dirt
execute in minecraft:overworld run fill 271 77 -24 271 144 -24 air
execute in minecraft:overworld run fill 271 58 -23 271 72 -23 stone
execute in minecraft:overworld run fill 271 73 -23 271 74 -23 dirt
execute in minecraft:overworld run setblock 271 75 -23 coarse_dirt
execute in minecraft:overworld run fill 271 76 -23 271 144 -23 air
execute in minecraft:overworld run fill 271 58 -22 271 72 -22 stone
execute in minecraft:overworld run fill 271 73 -22 271 74 -22 dirt
execute in minecraft:overworld run setblock 271 75 -22 coarse_dirt
execute in minecraft:overworld run fill 271 76 -22 271 144 -22 air
execute in minecraft:overworld run fill 271 58 -21 271 72 -21 stone
execute in minecraft:overworld run fill 271 73 -21 271 74 -21 dirt
execute in minecraft:overworld run setblock 271 75 -21 coarse_dirt
execute in minecraft:overworld run fill 271 76 -21 271 144 -21 air
execute in minecraft:overworld run fill 271 58 -20 271 71 -20 stone
execute in minecraft:overworld run fill 271 72 -20 271 73 -20 dirt
execute in minecraft:overworld run setblock 271 74 -20 coarse_dirt
execute in minecraft:overworld run fill 271 75 -20 271 144 -20 air
execute in minecraft:overworld run fill 271 58 -19 271 70 -19 stone
execute in minecraft:overworld run fill 271 71 -19 271 72 -19 dirt
execute in minecraft:overworld run setblock 271 73 -19 coarse_dirt
execute in minecraft:overworld run fill 271 74 -19 271 144 -19 air
execute in minecraft:overworld run fill 271 58 -18 271 70 -18 stone
execute in minecraft:overworld run fill 271 71 -18 271 72 -18 dirt
execute in minecraft:overworld run setblock 271 73 -18 grass_block
execute in minecraft:overworld run fill 271 74 -18 271 144 -18 air
execute in minecraft:overworld run fill 271 58 -17 271 69 -17 stone
execute in minecraft:overworld run fill 271 70 -17 271 71 -17 dirt
execute in minecraft:overworld run setblock 271 72 -17 coarse_dirt
execute in minecraft:overworld run fill 271 73 -17 271 144 -17 air
execute in minecraft:overworld run setblock 271 73 -17 grass
execute in minecraft:overworld run fill 271 58 -16 271 68 -16 stone
execute in minecraft:overworld run fill 271 69 -16 271 70 -16 dirt
execute in minecraft:overworld run setblock 271 71 -16 grass_block
execute in minecraft:overworld run fill 271 72 -16 271 144 -16 air
execute in minecraft:overworld run fill 271 58 -15 271 68 -15 stone
execute in minecraft:overworld run fill 271 69 -15 271 70 -15 dirt
execute in minecraft:overworld run setblock 271 71 -15 coarse_dirt
execute in minecraft:overworld run fill 271 72 -15 271 144 -15 air
execute in minecraft:overworld run fill 271 58 -14 271 67 -14 stone
execute in minecraft:overworld run fill 271 68 -14 271 69 -14 dirt
execute in minecraft:overworld run setblock 271 70 -14 grass_block
execute in minecraft:overworld run fill 271 71 -14 271 144 -14 air
execute in minecraft:overworld run fill 271 58 -13 271 66 -13 stone
execute in minecraft:overworld run fill 271 67 -13 271 68 -13 dirt
execute in minecraft:overworld run setblock 271 69 -13 coarse_dirt
execute in minecraft:overworld run fill 271 70 -13 271 144 -13 air
execute in minecraft:overworld run fill 271 58 -12 271 65 -12 stone
execute in minecraft:overworld run fill 271 66 -12 271 67 -12 dirt
execute in minecraft:overworld run setblock 271 68 -12 coarse_dirt
execute in minecraft:overworld run fill 271 69 -12 271 144 -12 air
execute in minecraft:overworld run setblock 271 69 -12 mossy_cobblestone
execute in minecraft:overworld run fill 271 58 -11 271 64 -11 stone
execute in minecraft:overworld run fill 271 65 -11 271 66 -11 dirt
execute in minecraft:overworld run setblock 271 67 -11 coarse_dirt
execute in minecraft:overworld run fill 271 68 -11 271 144 -11 air
execute in minecraft:overworld run fill 271 58 -10 271 64 -10 stone
execute in minecraft:overworld run fill 271 65 -10 271 66 -10 dirt
execute in minecraft:overworld run setblock 271 67 -10 grass_block
execute in minecraft:overworld run fill 271 68 -10 271 144 -10 air
execute in minecraft:overworld run fill 271 58 -9 271 63 -9 stone
execute in minecraft:overworld run fill 271 64 -9 271 65 -9 dirt
execute in minecraft:overworld run setblock 271 66 -9 coarse_dirt
execute in minecraft:overworld run fill 271 67 -9 271 144 -9 air
execute in minecraft:overworld run setblock 271 67 -9 grass
execute in minecraft:overworld run fill 271 58 -8 271 63 -8 stone
execute in minecraft:overworld run fill 271 64 -8 271 65 -8 dirt
execute in minecraft:overworld run setblock 271 66 -8 grass_block
execute in minecraft:overworld run fill 271 67 -8 271 144 -8 air
execute in minecraft:overworld run fill 271 58 -7 271 62 -7 stone
execute in minecraft:overworld run fill 271 63 -7 271 64 -7 dirt
execute in minecraft:overworld run setblock 271 65 -7 grass_block
execute in minecraft:overworld run fill 271 66 -7 271 144 -7 air
execute in minecraft:overworld run fill 271 58 -6 271 62 -6 stone
execute in minecraft:overworld run fill 271 63 -6 271 64 -6 dirt
execute in minecraft:overworld run setblock 271 65 -6 coarse_dirt
execute in minecraft:overworld run fill 271 66 -6 271 144 -6 air
execute in minecraft:overworld run setblock 271 66 -6 grass
execute in minecraft:overworld run fill 271 58 -5 271 61 -5 stone
execute in minecraft:overworld run fill 271 62 -5 271 63 -5 dirt
execute in minecraft:overworld run setblock 271 64 -5 coarse_dirt
execute in minecraft:overworld run fill 271 65 -5 271 144 -5 air
execute in minecraft:overworld run fill 271 58 -4 271 61 -4 stone
execute in minecraft:overworld run fill 271 62 -4 271 63 -4 dirt
execute in minecraft:overworld run setblock 271 64 -4 grass_block
execute in minecraft:overworld run fill 271 65 -4 271 144 -4 air
execute in minecraft:overworld run fill 271 58 -3 271 61 -3 stone
execute in minecraft:overworld run fill 271 62 -3 271 63 -3 dirt
execute in minecraft:overworld run setblock 271 64 -3 coarse_dirt
execute in minecraft:overworld run fill 271 65 -3 271 144 -3 air
execute in minecraft:overworld run fill 271 58 -2 271 60 -2 stone
execute in minecraft:overworld run fill 271 61 -2 271 62 -2 dirt
execute in minecraft:overworld run setblock 271 63 -2 gravel
execute in minecraft:overworld run fill 271 64 -2 271 144 -2 air
execute in minecraft:overworld run fill 271 64 -2 271 64 -2 water
execute in minecraft:overworld run fill 271 58 -1 271 60 -1 stone
execute in minecraft:overworld run fill 271 61 -1 271 62 -1 dirt
execute in minecraft:overworld run setblock 271 63 -1 gravel
execute in minecraft:overworld run fill 271 64 -1 271 144 -1 air
execute in minecraft:overworld run fill 271 64 -1 271 64 -1 water
execute in minecraft:overworld run fill 271 58 0 271 59 0 stone
execute in minecraft:overworld run fill 271 60 0 271 61 0 dirt
execute in minecraft:overworld run setblock 271 62 0 gravel
execute in minecraft:overworld run fill 271 63 0 271 144 0 air
execute in minecraft:overworld run fill 271 63 0 271 64 0 water
execute in minecraft:overworld run fill 271 58 1 271 59 1 stone
execute in minecraft:overworld run fill 271 60 1 271 61 1 dirt
execute in minecraft:overworld run setblock 271 62 1 gravel
execute in minecraft:overworld run fill 271 63 1 271 144 1 air
execute in minecraft:overworld run fill 271 63 1 271 64 1 water
execute in minecraft:overworld run fill 271 58 2 271 59 2 stone
execute in minecraft:overworld run fill 271 60 2 271 61 2 dirt
execute in minecraft:overworld run setblock 271 62 2 gravel
execute in minecraft:overworld run fill 271 63 2 271 144 2 air
execute in minecraft:overworld run fill 271 63 2 271 64 2 water
execute in minecraft:overworld run fill 271 58 3 271 59 3 stone
execute in minecraft:overworld run fill 271 60 3 271 61 3 dirt
execute in minecraft:overworld run setblock 271 62 3 gravel
execute in minecraft:overworld run fill 271 63 3 271 144 3 air
execute in minecraft:overworld run fill 271 63 3 271 64 3 water
execute in minecraft:overworld run fill 271 58 4 271 59 4 stone
execute in minecraft:overworld run fill 271 60 4 271 61 4 dirt
execute in minecraft:overworld run setblock 271 62 4 gravel
execute in minecraft:overworld run fill 271 63 4 271 144 4 air
execute in minecraft:overworld run fill 271 63 4 271 64 4 water
execute in minecraft:overworld run fill 271 58 5 271 59 5 stone
execute in minecraft:overworld run fill 271 60 5 271 61 5 dirt
execute in minecraft:overworld run setblock 271 62 5 gravel
execute in minecraft:overworld run fill 271 63 5 271 144 5 air
execute in minecraft:overworld run fill 271 63 5 271 64 5 water
execute in minecraft:overworld run fill 271 58 6 271 59 6 stone
execute in minecraft:overworld run fill 271 60 6 271 61 6 dirt
execute in minecraft:overworld run setblock 271 62 6 gravel
execute in minecraft:overworld run fill 271 63 6 271 144 6 air
execute in minecraft:overworld run fill 271 63 6 271 64 6 water
execute in minecraft:overworld run fill 271 58 7 271 59 7 stone
execute in minecraft:overworld run fill 271 60 7 271 61 7 dirt
execute in minecraft:overworld run setblock 271 62 7 gravel
execute in minecraft:overworld run fill 271 63 7 271 144 7 air
execute in minecraft:overworld run fill 271 63 7 271 64 7 water
execute in minecraft:overworld run fill 271 58 8 271 59 8 stone
execute in minecraft:overworld run fill 271 60 8 271 61 8 dirt
execute in minecraft:overworld run setblock 271 62 8 gravel
execute in minecraft:overworld run fill 271 63 8 271 144 8 air
execute in minecraft:overworld run fill 271 63 8 271 64 8 water
execute in minecraft:overworld run fill 271 58 9 271 59 9 stone
execute in minecraft:overworld run fill 271 60 9 271 61 9 dirt
execute in minecraft:overworld run setblock 271 62 9 gravel
execute in minecraft:overworld run fill 271 63 9 271 144 9 air
execute in minecraft:overworld run fill 271 63 9 271 64 9 water
execute in minecraft:overworld run fill 271 58 10 271 59 10 stone
execute in minecraft:overworld run fill 271 60 10 271 61 10 dirt
execute in minecraft:overworld run setblock 271 62 10 gravel
execute in minecraft:overworld run fill 271 63 10 271 144 10 air
execute in minecraft:overworld run fill 271 63 10 271 64 10 water
execute in minecraft:overworld run fill 271 58 11 271 58 11 stone
execute in minecraft:overworld run fill 271 59 11 271 60 11 dirt
execute in minecraft:overworld run setblock 271 61 11 gravel
execute in minecraft:overworld run fill 271 62 11 271 144 11 air
execute in minecraft:overworld run fill 271 62 11 271 64 11 water
execute in minecraft:overworld run fill 271 58 12 271 58 12 stone
execute in minecraft:overworld run fill 271 59 12 271 60 12 dirt
schedule function blade_gallery:random/burned/part_101 1t replace
