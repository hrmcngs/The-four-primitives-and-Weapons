execute in minecraft:overworld run setblock 343 71 -18 grass_block
execute in minecraft:overworld run fill 343 72 -18 343 144 -18 air
execute in minecraft:overworld run fill 343 58 -17 343 68 -17 stone
execute in minecraft:overworld run fill 343 69 -17 343 70 -17 dirt
execute in minecraft:overworld run setblock 343 71 -17 grass_block
execute in minecraft:overworld run fill 343 72 -17 343 144 -17 air
execute in minecraft:overworld run fill 343 58 -16 343 67 -16 stone
execute in minecraft:overworld run fill 343 68 -16 343 69 -16 dirt
execute in minecraft:overworld run setblock 343 70 -16 coarse_dirt
execute in minecraft:overworld run fill 343 71 -16 343 144 -16 air
execute in minecraft:overworld run fill 343 58 -15 343 67 -15 stone
execute in minecraft:overworld run fill 343 68 -15 343 69 -15 dirt
execute in minecraft:overworld run setblock 343 70 -15 coarse_dirt
execute in minecraft:overworld run fill 343 71 -15 343 144 -15 air
execute in minecraft:overworld run setblock 343 71 -15 grass
execute in minecraft:overworld run fill 343 58 -14 343 66 -14 stone
execute in minecraft:overworld run fill 343 67 -14 343 68 -14 dirt
execute in minecraft:overworld run setblock 343 69 -14 coarse_dirt
execute in minecraft:overworld run fill 343 70 -14 343 144 -14 air
execute in minecraft:overworld run fill 343 58 -13 343 66 -13 stone
execute in minecraft:overworld run fill 343 67 -13 343 68 -13 dirt
execute in minecraft:overworld run setblock 343 69 -13 coarse_dirt
execute in minecraft:overworld run fill 343 70 -13 343 144 -13 air
execute in minecraft:overworld run fill 343 58 -12 343 65 -12 stone
execute in minecraft:overworld run fill 343 66 -12 343 67 -12 dirt
execute in minecraft:overworld run setblock 343 68 -12 grass_block
execute in minecraft:overworld run fill 343 69 -12 343 144 -12 air
execute in minecraft:overworld run fill 343 58 -11 343 65 -11 stone
execute in minecraft:overworld run fill 343 66 -11 343 67 -11 dirt
execute in minecraft:overworld run setblock 343 68 -11 coarse_dirt
execute in minecraft:overworld run fill 343 69 -11 343 144 -11 air
execute in minecraft:overworld run fill 343 58 -10 343 65 -10 stone
execute in minecraft:overworld run fill 343 66 -10 343 67 -10 dirt
execute in minecraft:overworld run setblock 343 68 -10 coarse_dirt
execute in minecraft:overworld run fill 343 69 -10 343 144 -10 air
execute in minecraft:overworld run fill 343 58 -9 343 65 -9 stone
execute in minecraft:overworld run fill 343 66 -9 343 67 -9 dirt
execute in minecraft:overworld run setblock 343 68 -9 grass_block
execute in minecraft:overworld run fill 343 69 -9 343 144 -9 air
execute in minecraft:overworld run fill 343 58 -8 343 65 -8 stone
execute in minecraft:overworld run fill 343 66 -8 343 67 -8 dirt
execute in minecraft:overworld run setblock 343 68 -8 coarse_dirt
execute in minecraft:overworld run fill 343 69 -8 343 144 -8 air
execute in minecraft:overworld run setblock 343 69 -8 grass
execute in minecraft:overworld run fill 343 58 -7 343 65 -7 stone
execute in minecraft:overworld run fill 343 66 -7 343 67 -7 dirt
execute in minecraft:overworld run setblock 343 68 -7 grass_block
execute in minecraft:overworld run fill 343 69 -7 343 144 -7 air
execute in minecraft:overworld run fill 343 58 -6 343 65 -6 stone
execute in minecraft:overworld run fill 343 66 -6 343 67 -6 dirt
execute in minecraft:overworld run setblock 343 68 -6 coarse_dirt
execute in minecraft:overworld run fill 343 69 -6 343 144 -6 air
execute in minecraft:overworld run fill 343 58 -5 343 65 -5 stone
execute in minecraft:overworld run fill 343 66 -5 343 67 -5 dirt
execute in minecraft:overworld run setblock 343 68 -5 grass_block
execute in minecraft:overworld run fill 343 69 -5 343 144 -5 air
execute in minecraft:overworld run fill 343 58 -4 343 65 -4 stone
execute in minecraft:overworld run fill 343 66 -4 343 67 -4 dirt
execute in minecraft:overworld run setblock 343 68 -4 coarse_dirt
execute in minecraft:overworld run fill 343 69 -4 343 144 -4 air
execute in minecraft:overworld run fill 343 58 -3 343 65 -3 stone
execute in minecraft:overworld run fill 343 66 -3 343 67 -3 dirt
execute in minecraft:overworld run setblock 343 68 -3 coarse_dirt
execute in minecraft:overworld run fill 343 69 -3 343 144 -3 air
execute in minecraft:overworld run fill 343 58 -2 343 65 -2 stone
execute in minecraft:overworld run fill 343 66 -2 343 67 -2 dirt
execute in minecraft:overworld run setblock 343 68 -2 coarse_dirt
execute in minecraft:overworld run fill 343 69 -2 343 144 -2 air
execute in minecraft:overworld run fill 343 58 -1 343 65 -1 stone
execute in minecraft:overworld run fill 343 66 -1 343 67 -1 dirt
execute in minecraft:overworld run setblock 343 68 -1 coarse_dirt
execute in minecraft:overworld run fill 343 69 -1 343 144 -1 air
execute in minecraft:overworld run fill 343 58 0 343 65 0 stone
execute in minecraft:overworld run fill 343 66 0 343 67 0 dirt
execute in minecraft:overworld run setblock 343 68 0 grass_block
execute in minecraft:overworld run fill 343 69 0 343 144 0 air
execute in minecraft:overworld run setblock 343 69 0 grass
execute in minecraft:overworld run fill 343 58 1 343 65 1 stone
execute in minecraft:overworld run fill 343 66 1 343 67 1 dirt
execute in minecraft:overworld run setblock 343 68 1 grass_block
execute in minecraft:overworld run fill 343 69 1 343 144 1 air
execute in minecraft:overworld run fill 343 58 2 343 65 2 stone
execute in minecraft:overworld run fill 343 66 2 343 67 2 dirt
execute in minecraft:overworld run setblock 343 68 2 coarse_dirt
execute in minecraft:overworld run fill 343 69 2 343 144 2 air
execute in minecraft:overworld run fill 343 58 3 343 65 3 stone
execute in minecraft:overworld run fill 343 66 3 343 67 3 dirt
execute in minecraft:overworld run setblock 343 68 3 grass_block
execute in minecraft:overworld run fill 343 69 3 343 144 3 air
execute in minecraft:overworld run fill 343 58 4 343 65 4 stone
execute in minecraft:overworld run fill 343 66 4 343 67 4 dirt
execute in minecraft:overworld run setblock 343 68 4 coarse_dirt
execute in minecraft:overworld run fill 343 69 4 343 144 4 air
execute in minecraft:overworld run fill 343 58 5 343 65 5 stone
execute in minecraft:overworld run fill 343 66 5 343 67 5 dirt
execute in minecraft:overworld run setblock 343 68 5 coarse_dirt
execute in minecraft:overworld run fill 343 69 5 343 144 5 air
execute in minecraft:overworld run fill 343 58 6 343 65 6 stone
execute in minecraft:overworld run fill 343 66 6 343 67 6 dirt
execute in minecraft:overworld run setblock 343 68 6 coarse_dirt
execute in minecraft:overworld run fill 343 69 6 343 144 6 air
execute in minecraft:overworld run fill 343 58 7 343 65 7 stone
execute in minecraft:overworld run fill 343 66 7 343 67 7 dirt
execute in minecraft:overworld run setblock 343 68 7 coarse_dirt
execute in minecraft:overworld run fill 343 69 7 343 144 7 air
execute in minecraft:overworld run fill 343 58 8 343 65 8 stone
execute in minecraft:overworld run fill 343 66 8 343 67 8 dirt
execute in minecraft:overworld run setblock 343 68 8 coarse_dirt
execute in minecraft:overworld run fill 343 69 8 343 144 8 air
execute in minecraft:overworld run setblock 343 69 8 grass
execute in minecraft:overworld run fill 343 58 9 343 65 9 stone
execute in minecraft:overworld run fill 343 66 9 343 67 9 dirt
execute in minecraft:overworld run setblock 343 68 9 grass_block
execute in minecraft:overworld run fill 343 69 9 343 144 9 air
execute in minecraft:overworld run fill 343 58 10 343 65 10 stone
execute in minecraft:overworld run fill 343 66 10 343 67 10 dirt
execute in minecraft:overworld run setblock 343 68 10 coarse_dirt
execute in minecraft:overworld run fill 343 69 10 343 144 10 air
execute in minecraft:overworld run fill 343 58 11 343 65 11 stone
execute in minecraft:overworld run fill 343 66 11 343 67 11 dirt
execute in minecraft:overworld run setblock 343 68 11 coarse_dirt
execute in minecraft:overworld run fill 343 69 11 343 144 11 air
execute in minecraft:overworld run fill 343 58 12 343 64 12 stone
execute in minecraft:overworld run fill 343 65 12 343 66 12 dirt
execute in minecraft:overworld run setblock 343 67 12 coarse_dirt
execute in minecraft:overworld run fill 343 68 12 343 144 12 air
execute in minecraft:overworld run fill 343 58 13 343 64 13 stone
execute in minecraft:overworld run fill 343 65 13 343 66 13 dirt
execute in minecraft:overworld run setblock 343 67 13 coarse_dirt
execute in minecraft:overworld run fill 343 68 13 343 144 13 air
execute in minecraft:overworld run fill 343 58 14 343 64 14 stone
execute in minecraft:overworld run fill 343 65 14 343 66 14 dirt
execute in minecraft:overworld run setblock 343 67 14 coarse_dirt
execute in minecraft:overworld run fill 343 68 14 343 144 14 air
execute in minecraft:overworld run fill 343 58 15 343 64 15 stone
execute in minecraft:overworld run fill 343 65 15 343 66 15 dirt
execute in minecraft:overworld run setblock 343 67 15 coarse_dirt
execute in minecraft:overworld run fill 343 68 15 343 144 15 air
execute in minecraft:overworld run fill 343 58 16 343 63 16 stone
execute in minecraft:overworld run fill 343 64 16 343 65 16 dirt
execute in minecraft:overworld run setblock 343 66 16 coarse_dirt
execute in minecraft:overworld run fill 343 67 16 343 144 16 air
execute in minecraft:overworld run fill 343 58 17 343 63 17 stone
execute in minecraft:overworld run fill 343 64 17 343 65 17 dirt
execute in minecraft:overworld run setblock 343 66 17 grass_block
execute in minecraft:overworld run fill 343 67 17 343 144 17 air
execute in minecraft:overworld run fill 343 58 18 343 63 18 stone
execute in minecraft:overworld run fill 343 64 18 343 65 18 dirt
execute in minecraft:overworld run setblock 343 66 18 grass_block
execute in minecraft:overworld run fill 343 67 18 343 144 18 air
execute in minecraft:overworld run fill 343 58 19 343 63 19 stone
execute in minecraft:overworld run fill 343 64 19 343 65 19 dirt
execute in minecraft:overworld run setblock 343 66 19 coarse_dirt
execute in minecraft:overworld run fill 343 67 19 343 144 19 air
execute in minecraft:overworld run fill 343 58 20 343 63 20 stone
execute in minecraft:overworld run fill 343 64 20 343 65 20 dirt
execute in minecraft:overworld run setblock 343 66 20 grass_block
execute in minecraft:overworld run fill 343 67 20 343 144 20 air
execute in minecraft:overworld run fill 343 58 21 343 63 21 stone
execute in minecraft:overworld run fill 343 64 21 343 65 21 dirt
execute in minecraft:overworld run setblock 343 66 21 coarse_dirt
execute in minecraft:overworld run fill 343 67 21 343 144 21 air
execute in minecraft:overworld run fill 343 58 22 343 63 22 stone
execute in minecraft:overworld run fill 343 64 22 343 65 22 dirt
execute in minecraft:overworld run setblock 343 66 22 coarse_dirt
execute in minecraft:overworld run fill 343 67 22 343 144 22 air
execute in minecraft:overworld run fill 343 58 23 343 63 23 stone
execute in minecraft:overworld run fill 343 64 23 343 65 23 dirt
execute in minecraft:overworld run setblock 343 66 23 coarse_dirt
execute in minecraft:overworld run fill 343 67 23 343 144 23 air
execute in minecraft:overworld run fill 343 58 24 343 63 24 stone
execute in minecraft:overworld run fill 343 64 24 343 65 24 dirt
execute in minecraft:overworld run setblock 343 66 24 grass_block
execute in minecraft:overworld run fill 343 67 24 343 144 24 air
execute in minecraft:overworld run fill 343 58 25 343 63 25 stone
execute in minecraft:overworld run fill 343 64 25 343 65 25 dirt
execute in minecraft:overworld run setblock 343 66 25 coarse_dirt
execute in minecraft:overworld run fill 343 67 25 343 144 25 air
execute in minecraft:overworld run setblock 343 67 25 grass
execute in minecraft:overworld run fill 343 58 26 343 63 26 stone
execute in minecraft:overworld run fill 343 64 26 343 65 26 dirt
execute in minecraft:overworld run setblock 343 66 26 coarse_dirt
execute in minecraft:overworld run fill 343 67 26 343 144 26 air
execute in minecraft:overworld run fill 343 58 27 343 63 27 stone
execute in minecraft:overworld run fill 343 64 27 343 65 27 dirt
execute in minecraft:overworld run setblock 343 66 27 grass_block
execute in minecraft:overworld run fill 343 67 27 343 144 27 air
execute in minecraft:overworld run fill 343 58 28 343 63 28 stone
execute in minecraft:overworld run fill 343 64 28 343 65 28 dirt
execute in minecraft:overworld run setblock 343 66 28 coarse_dirt
execute in minecraft:overworld run fill 343 67 28 343 144 28 air
execute in minecraft:overworld run fill 343 58 29 343 63 29 stone
execute in minecraft:overworld run fill 343 64 29 343 65 29 dirt
execute in minecraft:overworld run setblock 343 66 29 grass_block
execute in minecraft:overworld run fill 343 67 29 343 144 29 air
execute in minecraft:overworld run fill 343 58 30 343 63 30 stone
execute in minecraft:overworld run fill 343 64 30 343 65 30 dirt
execute in minecraft:overworld run setblock 343 66 30 grass_block
execute in minecraft:overworld run fill 343 67 30 343 144 30 air
execute in minecraft:overworld run fill 343 58 31 343 63 31 stone
execute in minecraft:overworld run fill 343 64 31 343 65 31 dirt
execute in minecraft:overworld run setblock 343 66 31 grass_block
execute in minecraft:overworld run fill 343 67 31 343 144 31 air
execute in minecraft:overworld run fill 343 58 32 343 63 32 stone
execute in minecraft:overworld run fill 343 64 32 343 65 32 dirt
execute in minecraft:overworld run setblock 343 66 32 coarse_dirt
execute in minecraft:overworld run fill 343 67 32 343 144 32 air
execute in minecraft:overworld run fill 343 58 33 343 63 33 stone
execute in minecraft:overworld run fill 343 64 33 343 65 33 dirt
execute in minecraft:overworld run setblock 343 66 33 coarse_dirt
execute in minecraft:overworld run fill 343 67 33 343 144 33 air
execute in minecraft:overworld run fill 343 58 34 343 63 34 stone
execute in minecraft:overworld run fill 343 64 34 343 65 34 dirt
execute in minecraft:overworld run setblock 343 66 34 coarse_dirt
execute in minecraft:overworld run fill 343 67 34 343 144 34 air
execute in minecraft:overworld run fill 343 58 35 343 63 35 stone
execute in minecraft:overworld run fill 343 64 35 343 65 35 dirt
execute in minecraft:overworld run setblock 343 66 35 coarse_dirt
execute in minecraft:overworld run fill 343 67 35 343 144 35 air
execute in minecraft:overworld run fill 343 58 36 343 63 36 stone
execute in minecraft:overworld run fill 343 64 36 343 65 36 dirt
execute in minecraft:overworld run setblock 343 66 36 grass_block
execute in minecraft:overworld run fill 343 67 36 343 144 36 air
execute in minecraft:overworld run fill 343 58 37 343 63 37 stone
execute in minecraft:overworld run fill 343 64 37 343 65 37 dirt
execute in minecraft:overworld run setblock 343 66 37 coarse_dirt
execute in minecraft:overworld run fill 343 67 37 343 144 37 air
execute in minecraft:overworld run fill 343 58 38 343 63 38 stone
execute in minecraft:overworld run fill 343 64 38 343 65 38 dirt
execute in minecraft:overworld run setblock 343 66 38 coarse_dirt
execute in minecraft:overworld run fill 343 67 38 343 144 38 air
execute in minecraft:overworld run fill 343 58 39 343 63 39 stone
execute in minecraft:overworld run fill 343 64 39 343 65 39 dirt
execute in minecraft:overworld run setblock 343 66 39 grass_block
execute in minecraft:overworld run fill 343 67 39 343 144 39 air
execute in minecraft:overworld run fill 343 58 40 343 63 40 stone
execute in minecraft:overworld run fill 343 64 40 343 65 40 dirt
execute in minecraft:overworld run setblock 343 66 40 coarse_dirt
execute in minecraft:overworld run fill 343 67 40 343 144 40 air
execute in minecraft:overworld run fill 343 58 41 343 63 41 stone
execute in minecraft:overworld run fill 343 64 41 343 65 41 dirt
execute in minecraft:overworld run setblock 343 66 41 coarse_dirt
execute in minecraft:overworld run fill 343 67 41 343 144 41 air
execute in minecraft:overworld run fill 343 58 42 343 63 42 stone
execute in minecraft:overworld run fill 343 64 42 343 65 42 dirt
execute in minecraft:overworld run setblock 343 66 42 coarse_dirt
execute in minecraft:overworld run fill 343 67 42 343 144 42 air
execute in minecraft:overworld run fill 343 58 43 343 63 43 stone
execute in minecraft:overworld run fill 343 64 43 343 65 43 dirt
execute in minecraft:overworld run setblock 343 66 43 coarse_dirt
execute in minecraft:overworld run fill 343 67 43 343 144 43 air
execute in minecraft:overworld run fill 343 58 44 343 62 44 stone
execute in minecraft:overworld run fill 343 63 44 343 64 44 dirt
execute in minecraft:overworld run setblock 343 65 44 grass_block
execute in minecraft:overworld run fill 343 66 44 343 144 44 air
execute in minecraft:overworld run fill 343 58 45 343 62 45 stone
schedule function blade_gallery:random/battlefield/part_12 1t replace
