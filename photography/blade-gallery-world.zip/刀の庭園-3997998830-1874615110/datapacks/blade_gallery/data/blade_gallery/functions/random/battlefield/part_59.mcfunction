execute in minecraft:overworld run fill 374 69 -2 374 144 -2 air
execute in minecraft:overworld run fill 374 58 -1 374 65 -1 stone
execute in minecraft:overworld run fill 374 66 -1 374 67 -1 dirt
execute in minecraft:overworld run setblock 374 68 -1 coarse_dirt
execute in minecraft:overworld run fill 374 69 -1 374 144 -1 air
execute in minecraft:overworld run fill 374 58 0 374 65 0 stone
execute in minecraft:overworld run fill 374 66 0 374 67 0 dirt
execute in minecraft:overworld run setblock 374 68 0 coarse_dirt
execute in minecraft:overworld run fill 374 69 0 374 144 0 air
execute in minecraft:overworld run fill 374 58 1 374 65 1 stone
execute in minecraft:overworld run fill 374 66 1 374 67 1 dirt
execute in minecraft:overworld run setblock 374 68 1 grass_block
execute in minecraft:overworld run fill 374 69 1 374 144 1 air
execute in minecraft:overworld run fill 374 58 2 374 65 2 stone
execute in minecraft:overworld run fill 374 66 2 374 67 2 dirt
execute in minecraft:overworld run setblock 374 68 2 coarse_dirt
execute in minecraft:overworld run fill 374 69 2 374 144 2 air
execute in minecraft:overworld run fill 374 58 3 374 65 3 stone
execute in minecraft:overworld run fill 374 66 3 374 67 3 dirt
execute in minecraft:overworld run setblock 374 68 3 grass_block
execute in minecraft:overworld run fill 374 69 3 374 144 3 air
execute in minecraft:overworld run fill 374 58 4 374 65 4 stone
execute in minecraft:overworld run fill 374 66 4 374 67 4 dirt
execute in minecraft:overworld run setblock 374 68 4 coarse_dirt
execute in minecraft:overworld run fill 374 69 4 374 144 4 air
execute in minecraft:overworld run fill 374 58 5 374 65 5 stone
execute in minecraft:overworld run fill 374 66 5 374 67 5 dirt
execute in minecraft:overworld run setblock 374 68 5 grass_block
execute in minecraft:overworld run fill 374 69 5 374 144 5 air
execute in minecraft:overworld run fill 374 58 6 374 65 6 stone
execute in minecraft:overworld run fill 374 66 6 374 67 6 dirt
execute in minecraft:overworld run setblock 374 68 6 grass_block
execute in minecraft:overworld run fill 374 69 6 374 144 6 air
execute in minecraft:overworld run setblock 374 69 6 grass
execute in minecraft:overworld run fill 374 58 7 374 65 7 stone
execute in minecraft:overworld run fill 374 66 7 374 67 7 dirt
execute in minecraft:overworld run setblock 374 68 7 grass_block
execute in minecraft:overworld run fill 374 69 7 374 144 7 air
execute in minecraft:overworld run fill 374 58 8 374 65 8 stone
execute in minecraft:overworld run fill 374 66 8 374 67 8 dirt
execute in minecraft:overworld run setblock 374 68 8 grass_block
execute in minecraft:overworld run fill 374 69 8 374 144 8 air
execute in minecraft:overworld run fill 374 58 9 374 65 9 stone
execute in minecraft:overworld run fill 374 66 9 374 67 9 dirt
execute in minecraft:overworld run setblock 374 68 9 coarse_dirt
execute in minecraft:overworld run fill 374 69 9 374 144 9 air
execute in minecraft:overworld run setblock 374 69 9 grass
execute in minecraft:overworld run fill 374 58 10 374 66 10 stone
execute in minecraft:overworld run fill 374 67 10 374 68 10 dirt
execute in minecraft:overworld run setblock 374 69 10 grass_block
execute in minecraft:overworld run fill 374 70 10 374 144 10 air
execute in minecraft:overworld run fill 374 58 11 374 66 11 stone
execute in minecraft:overworld run fill 374 67 11 374 68 11 dirt
execute in minecraft:overworld run setblock 374 69 11 coarse_dirt
execute in minecraft:overworld run fill 374 70 11 374 144 11 air
execute in minecraft:overworld run fill 374 58 12 374 66 12 stone
execute in minecraft:overworld run fill 374 67 12 374 68 12 dirt
execute in minecraft:overworld run setblock 374 69 12 grass_block
execute in minecraft:overworld run fill 374 70 12 374 144 12 air
execute in minecraft:overworld run fill 374 58 13 374 67 13 stone
execute in minecraft:overworld run fill 374 68 13 374 69 13 dirt
execute in minecraft:overworld run setblock 374 70 13 coarse_dirt
execute in minecraft:overworld run fill 374 71 13 374 144 13 air
execute in minecraft:overworld run fill 374 58 14 374 67 14 stone
execute in minecraft:overworld run fill 374 68 14 374 69 14 dirt
execute in minecraft:overworld run setblock 374 70 14 grass_block
execute in minecraft:overworld run fill 374 71 14 374 144 14 air
execute in minecraft:overworld run fill 374 58 15 374 67 15 stone
execute in minecraft:overworld run fill 374 68 15 374 69 15 dirt
execute in minecraft:overworld run setblock 374 70 15 grass_block
execute in minecraft:overworld run fill 374 71 15 374 144 15 air
execute in minecraft:overworld run fill 374 58 16 374 67 16 stone
execute in minecraft:overworld run fill 374 68 16 374 69 16 dirt
execute in minecraft:overworld run setblock 374 70 16 coarse_dirt
execute in minecraft:overworld run fill 374 71 16 374 144 16 air
execute in minecraft:overworld run fill 374 58 17 374 68 17 stone
execute in minecraft:overworld run fill 374 69 17 374 70 17 dirt
execute in minecraft:overworld run setblock 374 71 17 grass_block
execute in minecraft:overworld run fill 374 72 17 374 144 17 air
execute in minecraft:overworld run fill 374 58 18 374 68 18 stone
execute in minecraft:overworld run fill 374 69 18 374 70 18 dirt
execute in minecraft:overworld run setblock 374 71 18 grass_block
execute in minecraft:overworld run fill 374 72 18 374 144 18 air
execute in minecraft:overworld run fill 374 58 19 374 68 19 stone
execute in minecraft:overworld run fill 374 69 19 374 70 19 dirt
execute in minecraft:overworld run setblock 374 71 19 coarse_dirt
execute in minecraft:overworld run fill 374 72 19 374 144 19 air
execute in minecraft:overworld run fill 374 58 20 374 68 20 stone
execute in minecraft:overworld run fill 374 69 20 374 70 20 dirt
execute in minecraft:overworld run setblock 374 71 20 coarse_dirt
execute in minecraft:overworld run fill 374 72 20 374 144 20 air
execute in minecraft:overworld run fill 374 58 21 374 68 21 stone
execute in minecraft:overworld run fill 374 69 21 374 70 21 dirt
execute in minecraft:overworld run setblock 374 71 21 coarse_dirt
execute in minecraft:overworld run fill 374 72 21 374 144 21 air
execute in minecraft:overworld run fill 374 58 22 374 68 22 stone
execute in minecraft:overworld run fill 374 69 22 374 70 22 dirt
execute in minecraft:overworld run setblock 374 71 22 coarse_dirt
execute in minecraft:overworld run fill 374 72 22 374 144 22 air
execute in minecraft:overworld run fill 374 58 23 374 68 23 stone
execute in minecraft:overworld run fill 374 69 23 374 70 23 dirt
execute in minecraft:overworld run setblock 374 71 23 grass_block
execute in minecraft:overworld run fill 374 72 23 374 144 23 air
execute in minecraft:overworld run fill 374 58 24 374 68 24 stone
execute in minecraft:overworld run fill 374 69 24 374 70 24 dirt
execute in minecraft:overworld run setblock 374 71 24 coarse_dirt
execute in minecraft:overworld run fill 374 72 24 374 144 24 air
execute in minecraft:overworld run fill 374 58 25 374 67 25 stone
execute in minecraft:overworld run fill 374 68 25 374 69 25 dirt
execute in minecraft:overworld run setblock 374 70 25 grass_block
execute in minecraft:overworld run fill 374 71 25 374 144 25 air
execute in minecraft:overworld run fill 374 58 26 374 67 26 stone
execute in minecraft:overworld run fill 374 68 26 374 69 26 dirt
execute in minecraft:overworld run setblock 374 70 26 coarse_dirt
execute in minecraft:overworld run fill 374 71 26 374 144 26 air
execute in minecraft:overworld run fill 374 58 27 374 67 27 stone
execute in minecraft:overworld run fill 374 68 27 374 69 27 dirt
execute in minecraft:overworld run setblock 374 70 27 grass_block
execute in minecraft:overworld run fill 374 71 27 374 144 27 air
execute in minecraft:overworld run fill 374 58 28 374 67 28 stone
execute in minecraft:overworld run fill 374 68 28 374 69 28 dirt
execute in minecraft:overworld run setblock 374 70 28 coarse_dirt
execute in minecraft:overworld run fill 374 71 28 374 144 28 air
execute in minecraft:overworld run fill 374 58 29 374 68 29 stone
execute in minecraft:overworld run fill 374 69 29 374 70 29 dirt
execute in minecraft:overworld run setblock 374 71 29 coarse_dirt
execute in minecraft:overworld run fill 374 72 29 374 144 29 air
execute in minecraft:overworld run setblock 374 72 29 grass
execute in minecraft:overworld run fill 374 58 30 374 68 30 stone
execute in minecraft:overworld run fill 374 69 30 374 70 30 dirt
execute in minecraft:overworld run setblock 374 71 30 coarse_dirt
execute in minecraft:overworld run fill 374 72 30 374 144 30 air
execute in minecraft:overworld run fill 374 58 31 374 68 31 stone
execute in minecraft:overworld run fill 374 69 31 374 70 31 dirt
execute in minecraft:overworld run setblock 374 71 31 coarse_dirt
execute in minecraft:overworld run fill 374 72 31 374 144 31 air
execute in minecraft:overworld run fill 374 58 32 374 68 32 stone
execute in minecraft:overworld run fill 374 69 32 374 70 32 dirt
execute in minecraft:overworld run setblock 374 71 32 coarse_dirt
execute in minecraft:overworld run fill 374 72 32 374 144 32 air
execute in minecraft:overworld run fill 374 58 33 374 68 33 stone
execute in minecraft:overworld run fill 374 69 33 374 70 33 dirt
execute in minecraft:overworld run setblock 374 71 33 coarse_dirt
execute in minecraft:overworld run fill 374 72 33 374 144 33 air
execute in minecraft:overworld run fill 374 58 34 374 69 34 stone
execute in minecraft:overworld run fill 374 70 34 374 71 34 dirt
execute in minecraft:overworld run setblock 374 72 34 grass_block
execute in minecraft:overworld run fill 374 73 34 374 144 34 air
execute in minecraft:overworld run fill 374 58 35 374 69 35 stone
execute in minecraft:overworld run fill 374 70 35 374 71 35 dirt
execute in minecraft:overworld run setblock 374 72 35 coarse_dirt
execute in minecraft:overworld run fill 374 73 35 374 144 35 air
execute in minecraft:overworld run fill 374 58 36 374 69 36 stone
execute in minecraft:overworld run fill 374 70 36 374 71 36 dirt
execute in minecraft:overworld run setblock 374 72 36 coarse_dirt
execute in minecraft:overworld run fill 374 73 36 374 144 36 air
execute in minecraft:overworld run fill 374 58 37 374 69 37 stone
execute in minecraft:overworld run fill 374 70 37 374 71 37 dirt
execute in minecraft:overworld run setblock 374 72 37 grass_block
execute in minecraft:overworld run fill 374 73 37 374 144 37 air
execute in minecraft:overworld run fill 374 58 38 374 69 38 stone
execute in minecraft:overworld run fill 374 70 38 374 71 38 dirt
execute in minecraft:overworld run setblock 374 72 38 grass_block
execute in minecraft:overworld run fill 374 73 38 374 144 38 air
execute in minecraft:overworld run fill 374 58 39 374 68 39 stone
execute in minecraft:overworld run fill 374 69 39 374 70 39 dirt
execute in minecraft:overworld run setblock 374 71 39 coarse_dirt
execute in minecraft:overworld run fill 374 72 39 374 144 39 air
execute in minecraft:overworld run fill 374 58 40 374 67 40 stone
execute in minecraft:overworld run fill 374 68 40 374 69 40 dirt
execute in minecraft:overworld run setblock 374 70 40 coarse_dirt
execute in minecraft:overworld run fill 374 71 40 374 144 40 air
execute in minecraft:overworld run fill 374 58 41 374 66 41 stone
execute in minecraft:overworld run fill 374 67 41 374 68 41 dirt
execute in minecraft:overworld run setblock 374 69 41 grass_block
execute in minecraft:overworld run fill 374 70 41 374 144 41 air
execute in minecraft:overworld run fill 374 58 42 374 65 42 stone
execute in minecraft:overworld run fill 374 66 42 374 67 42 dirt
execute in minecraft:overworld run setblock 374 68 42 coarse_dirt
execute in minecraft:overworld run fill 374 69 42 374 144 42 air
execute in minecraft:overworld run fill 374 58 43 374 65 43 stone
execute in minecraft:overworld run fill 374 66 43 374 67 43 dirt
execute in minecraft:overworld run setblock 374 68 43 grass_block
execute in minecraft:overworld run fill 374 69 43 374 144 43 air
execute in minecraft:overworld run fill 374 58 44 374 64 44 stone
execute in minecraft:overworld run fill 374 65 44 374 66 44 dirt
execute in minecraft:overworld run setblock 374 67 44 coarse_dirt
execute in minecraft:overworld run fill 374 68 44 374 144 44 air
execute in minecraft:overworld run fill 374 58 45 374 63 45 stone
execute in minecraft:overworld run fill 374 64 45 374 65 45 dirt
execute in minecraft:overworld run setblock 374 66 45 coarse_dirt
execute in minecraft:overworld run fill 374 67 45 374 144 45 air
execute in minecraft:overworld run fill 374 58 46 374 62 46 stone
execute in minecraft:overworld run fill 374 63 46 374 64 46 dirt
execute in minecraft:overworld run setblock 374 65 46 grass_block
execute in minecraft:overworld run fill 374 66 46 374 144 46 air
execute in minecraft:overworld run fill 374 58 47 374 62 47 stone
execute in minecraft:overworld run fill 374 63 47 374 64 47 dirt
execute in minecraft:overworld run setblock 374 65 47 coarse_dirt
execute in minecraft:overworld run fill 374 66 47 374 144 47 air
execute in minecraft:overworld run fill 375 58 -48 375 61 -48 stone
execute in minecraft:overworld run fill 375 62 -48 375 63 -48 dirt
execute in minecraft:overworld run setblock 375 64 -48 coarse_dirt
execute in minecraft:overworld run fill 375 65 -48 375 144 -48 air
execute in minecraft:overworld run fill 375 58 -47 375 62 -47 stone
execute in minecraft:overworld run fill 375 63 -47 375 64 -47 dirt
execute in minecraft:overworld run setblock 375 65 -47 coarse_dirt
execute in minecraft:overworld run fill 375 66 -47 375 144 -47 air
execute in minecraft:overworld run fill 375 58 -46 375 63 -46 stone
execute in minecraft:overworld run fill 375 64 -46 375 65 -46 dirt
execute in minecraft:overworld run setblock 375 66 -46 coarse_dirt
execute in minecraft:overworld run fill 375 67 -46 375 144 -46 air
execute in minecraft:overworld run fill 375 58 -45 375 63 -45 stone
execute in minecraft:overworld run fill 375 64 -45 375 65 -45 dirt
execute in minecraft:overworld run setblock 375 66 -45 coarse_dirt
execute in minecraft:overworld run fill 375 67 -45 375 144 -45 air
execute in minecraft:overworld run fill 375 58 -44 375 64 -44 stone
execute in minecraft:overworld run fill 375 65 -44 375 66 -44 dirt
execute in minecraft:overworld run setblock 375 67 -44 grass_block
execute in minecraft:overworld run fill 375 68 -44 375 144 -44 air
execute in minecraft:overworld run fill 375 58 -43 375 65 -43 stone
execute in minecraft:overworld run fill 375 66 -43 375 67 -43 dirt
execute in minecraft:overworld run setblock 375 68 -43 grass_block
execute in minecraft:overworld run fill 375 69 -43 375 144 -43 air
execute in minecraft:overworld run fill 375 58 -42 375 65 -42 stone
execute in minecraft:overworld run fill 375 66 -42 375 67 -42 dirt
execute in minecraft:overworld run setblock 375 68 -42 grass_block
execute in minecraft:overworld run fill 375 69 -42 375 144 -42 air
execute in minecraft:overworld run fill 375 58 -41 375 65 -41 stone
execute in minecraft:overworld run fill 375 66 -41 375 67 -41 dirt
execute in minecraft:overworld run setblock 375 68 -41 grass_block
execute in minecraft:overworld run fill 375 69 -41 375 144 -41 air
execute in minecraft:overworld run fill 375 58 -40 375 66 -40 stone
execute in minecraft:overworld run fill 375 67 -40 375 68 -40 dirt
execute in minecraft:overworld run setblock 375 69 -40 grass_block
execute in minecraft:overworld run fill 375 70 -40 375 144 -40 air
execute in minecraft:overworld run fill 375 58 -39 375 66 -39 stone
execute in minecraft:overworld run fill 375 67 -39 375 68 -39 dirt
execute in minecraft:overworld run setblock 375 69 -39 grass_block
execute in minecraft:overworld run fill 375 70 -39 375 144 -39 air
execute in minecraft:overworld run setblock 375 70 -39 grass
execute in minecraft:overworld run fill 375 58 -38 375 66 -38 stone
execute in minecraft:overworld run fill 375 67 -38 375 68 -38 dirt
execute in minecraft:overworld run setblock 375 69 -38 coarse_dirt
execute in minecraft:overworld run fill 375 70 -38 375 144 -38 air
execute in minecraft:overworld run fill 375 58 -37 375 66 -37 stone
execute in minecraft:overworld run fill 375 67 -37 375 68 -37 dirt
execute in minecraft:overworld run setblock 375 69 -37 coarse_dirt
execute in minecraft:overworld run fill 375 70 -37 375 144 -37 air
execute in minecraft:overworld run setblock 375 70 -37 grass
execute in minecraft:overworld run fill 375 58 -36 375 66 -36 stone
execute in minecraft:overworld run fill 375 67 -36 375 68 -36 dirt
execute in minecraft:overworld run setblock 375 69 -36 grass_block
execute in minecraft:overworld run fill 375 70 -36 375 144 -36 air
execute in minecraft:overworld run fill 375 58 -35 375 66 -35 stone
execute in minecraft:overworld run fill 375 67 -35 375 68 -35 dirt
schedule function blade_gallery:random/battlefield/part_60 1t replace
