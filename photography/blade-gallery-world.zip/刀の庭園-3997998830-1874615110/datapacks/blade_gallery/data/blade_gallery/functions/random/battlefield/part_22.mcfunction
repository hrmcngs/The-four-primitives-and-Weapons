execute in minecraft:overworld run fill 350 58 -4 350 67 -4 stone
execute in minecraft:overworld run fill 350 68 -4 350 69 -4 dirt
execute in minecraft:overworld run setblock 350 70 -4 grass_block
execute in minecraft:overworld run fill 350 71 -4 350 144 -4 air
execute in minecraft:overworld run fill 350 58 -3 350 66 -3 stone
execute in minecraft:overworld run fill 350 67 -3 350 68 -3 dirt
execute in minecraft:overworld run setblock 350 69 -3 coarse_dirt
execute in minecraft:overworld run fill 350 70 -3 350 144 -3 air
execute in minecraft:overworld run fill 350 58 -2 350 66 -2 stone
execute in minecraft:overworld run fill 350 67 -2 350 68 -2 dirt
execute in minecraft:overworld run setblock 350 69 -2 grass_block
execute in minecraft:overworld run fill 350 70 -2 350 144 -2 air
execute in minecraft:overworld run fill 350 58 -1 350 66 -1 stone
execute in minecraft:overworld run fill 350 67 -1 350 68 -1 dirt
execute in minecraft:overworld run setblock 350 69 -1 coarse_dirt
execute in minecraft:overworld run fill 350 70 -1 350 144 -1 air
execute in minecraft:overworld run fill 350 58 0 350 66 0 stone
execute in minecraft:overworld run fill 350 67 0 350 68 0 dirt
execute in minecraft:overworld run setblock 350 69 0 grass_block
execute in minecraft:overworld run fill 350 70 0 350 144 0 air
execute in minecraft:overworld run fill 350 58 1 350 66 1 stone
execute in minecraft:overworld run fill 350 67 1 350 68 1 dirt
execute in minecraft:overworld run setblock 350 69 1 coarse_dirt
execute in minecraft:overworld run fill 350 70 1 350 144 1 air
execute in minecraft:overworld run fill 350 58 2 350 67 2 stone
execute in minecraft:overworld run fill 350 68 2 350 69 2 dirt
execute in minecraft:overworld run setblock 350 70 2 coarse_dirt
execute in minecraft:overworld run fill 350 71 2 350 144 2 air
execute in minecraft:overworld run fill 350 58 3 350 67 3 stone
execute in minecraft:overworld run fill 350 68 3 350 69 3 dirt
execute in minecraft:overworld run setblock 350 70 3 coarse_dirt
execute in minecraft:overworld run fill 350 71 3 350 144 3 air
execute in minecraft:overworld run setblock 350 71 3 grass
execute in minecraft:overworld run fill 350 58 4 350 67 4 stone
execute in minecraft:overworld run fill 350 68 4 350 69 4 dirt
execute in minecraft:overworld run setblock 350 70 4 coarse_dirt
execute in minecraft:overworld run fill 350 71 4 350 144 4 air
execute in minecraft:overworld run fill 350 58 5 350 67 5 stone
execute in minecraft:overworld run fill 350 68 5 350 69 5 dirt
execute in minecraft:overworld run setblock 350 70 5 coarse_dirt
execute in minecraft:overworld run fill 350 71 5 350 144 5 air
execute in minecraft:overworld run fill 350 58 6 350 67 6 stone
execute in minecraft:overworld run fill 350 68 6 350 69 6 dirt
execute in minecraft:overworld run setblock 350 70 6 coarse_dirt
execute in minecraft:overworld run fill 350 71 6 350 144 6 air
execute in minecraft:overworld run fill 350 58 7 350 67 7 stone
execute in minecraft:overworld run fill 350 68 7 350 69 7 dirt
execute in minecraft:overworld run setblock 350 70 7 coarse_dirt
execute in minecraft:overworld run fill 350 71 7 350 144 7 air
execute in minecraft:overworld run fill 350 58 8 350 67 8 stone
execute in minecraft:overworld run fill 350 68 8 350 69 8 dirt
execute in minecraft:overworld run setblock 350 70 8 grass_block
execute in minecraft:overworld run fill 350 71 8 350 144 8 air
execute in minecraft:overworld run fill 350 58 9 350 67 9 stone
execute in minecraft:overworld run fill 350 68 9 350 69 9 dirt
execute in minecraft:overworld run setblock 350 70 9 coarse_dirt
execute in minecraft:overworld run fill 350 71 9 350 144 9 air
execute in minecraft:overworld run fill 350 58 10 350 67 10 stone
execute in minecraft:overworld run fill 350 68 10 350 69 10 dirt
execute in minecraft:overworld run setblock 350 70 10 coarse_dirt
execute in minecraft:overworld run fill 350 71 10 350 144 10 air
execute in minecraft:overworld run fill 350 58 11 350 67 11 stone
execute in minecraft:overworld run fill 350 68 11 350 69 11 dirt
execute in minecraft:overworld run setblock 350 70 11 coarse_dirt
execute in minecraft:overworld run fill 350 71 11 350 144 11 air
execute in minecraft:overworld run setblock 350 71 11 grass
execute in minecraft:overworld run fill 350 58 12 350 67 12 stone
execute in minecraft:overworld run fill 350 68 12 350 69 12 dirt
execute in minecraft:overworld run setblock 350 70 12 coarse_dirt
execute in minecraft:overworld run fill 350 71 12 350 144 12 air
execute in minecraft:overworld run fill 350 58 13 350 66 13 stone
execute in minecraft:overworld run fill 350 67 13 350 68 13 dirt
execute in minecraft:overworld run setblock 350 69 13 grass_block
execute in minecraft:overworld run fill 350 70 13 350 144 13 air
execute in minecraft:overworld run fill 350 58 14 350 66 14 stone
execute in minecraft:overworld run fill 350 67 14 350 68 14 dirt
execute in minecraft:overworld run setblock 350 69 14 grass_block
execute in minecraft:overworld run fill 350 70 14 350 144 14 air
execute in minecraft:overworld run fill 350 58 15 350 66 15 stone
execute in minecraft:overworld run fill 350 67 15 350 68 15 dirt
execute in minecraft:overworld run setblock 350 69 15 coarse_dirt
execute in minecraft:overworld run fill 350 70 15 350 144 15 air
execute in minecraft:overworld run fill 350 58 16 350 65 16 stone
execute in minecraft:overworld run fill 350 66 16 350 67 16 dirt
execute in minecraft:overworld run setblock 350 68 16 coarse_dirt
execute in minecraft:overworld run fill 350 69 16 350 144 16 air
execute in minecraft:overworld run fill 350 58 17 350 65 17 stone
execute in minecraft:overworld run fill 350 66 17 350 67 17 dirt
execute in minecraft:overworld run setblock 350 68 17 coarse_dirt
execute in minecraft:overworld run fill 350 69 17 350 144 17 air
execute in minecraft:overworld run fill 350 58 18 350 65 18 stone
execute in minecraft:overworld run fill 350 66 18 350 67 18 dirt
execute in minecraft:overworld run setblock 350 68 18 coarse_dirt
execute in minecraft:overworld run fill 350 69 18 350 144 18 air
execute in minecraft:overworld run setblock 350 69 18 grass
execute in minecraft:overworld run fill 350 58 19 350 65 19 stone
execute in minecraft:overworld run fill 350 66 19 350 67 19 dirt
execute in minecraft:overworld run setblock 350 68 19 coarse_dirt
execute in minecraft:overworld run fill 350 69 19 350 144 19 air
execute in minecraft:overworld run setblock 350 69 19 mossy_cobblestone
execute in minecraft:overworld run fill 350 58 20 350 65 20 stone
execute in minecraft:overworld run fill 350 66 20 350 67 20 dirt
execute in minecraft:overworld run setblock 350 68 20 grass_block
execute in minecraft:overworld run fill 350 69 20 350 144 20 air
execute in minecraft:overworld run fill 350 58 21 350 66 21 stone
execute in minecraft:overworld run fill 350 67 21 350 68 21 dirt
execute in minecraft:overworld run setblock 350 69 21 coarse_dirt
execute in minecraft:overworld run fill 350 70 21 350 144 21 air
execute in minecraft:overworld run fill 350 58 22 350 66 22 stone
execute in minecraft:overworld run fill 350 67 22 350 68 22 dirt
execute in minecraft:overworld run setblock 350 69 22 coarse_dirt
execute in minecraft:overworld run fill 350 70 22 350 144 22 air
execute in minecraft:overworld run fill 350 58 23 350 67 23 stone
execute in minecraft:overworld run fill 350 68 23 350 69 23 dirt
execute in minecraft:overworld run setblock 350 70 23 coarse_dirt
execute in minecraft:overworld run fill 350 71 23 350 144 23 air
execute in minecraft:overworld run fill 350 58 24 350 67 24 stone
execute in minecraft:overworld run fill 350 68 24 350 69 24 dirt
execute in minecraft:overworld run setblock 350 70 24 coarse_dirt
execute in minecraft:overworld run fill 350 71 24 350 144 24 air
execute in minecraft:overworld run fill 350 58 25 350 67 25 stone
execute in minecraft:overworld run fill 350 68 25 350 69 25 dirt
execute in minecraft:overworld run setblock 350 70 25 coarse_dirt
execute in minecraft:overworld run fill 350 71 25 350 144 25 air
execute in minecraft:overworld run setblock 350 71 25 grass
execute in minecraft:overworld run fill 350 58 26 350 68 26 stone
execute in minecraft:overworld run fill 350 69 26 350 70 26 dirt
execute in minecraft:overworld run setblock 350 71 26 grass_block
execute in minecraft:overworld run fill 350 72 26 350 144 26 air
execute in minecraft:overworld run fill 350 58 27 350 68 27 stone
execute in minecraft:overworld run fill 350 69 27 350 70 27 dirt
execute in minecraft:overworld run setblock 350 71 27 grass_block
execute in minecraft:overworld run fill 350 72 27 350 144 27 air
execute in minecraft:overworld run fill 350 58 28 350 68 28 stone
execute in minecraft:overworld run fill 350 69 28 350 70 28 dirt
execute in minecraft:overworld run setblock 350 71 28 coarse_dirt
execute in minecraft:overworld run fill 350 72 28 350 144 28 air
execute in minecraft:overworld run fill 350 58 29 350 68 29 stone
execute in minecraft:overworld run fill 350 69 29 350 70 29 dirt
execute in minecraft:overworld run setblock 350 71 29 coarse_dirt
execute in minecraft:overworld run fill 350 72 29 350 144 29 air
execute in minecraft:overworld run fill 350 58 30 350 67 30 stone
execute in minecraft:overworld run fill 350 68 30 350 69 30 dirt
execute in minecraft:overworld run setblock 350 70 30 grass_block
execute in minecraft:overworld run fill 350 71 30 350 144 30 air
execute in minecraft:overworld run fill 350 58 31 350 67 31 stone
execute in minecraft:overworld run fill 350 68 31 350 69 31 dirt
execute in minecraft:overworld run setblock 350 70 31 coarse_dirt
execute in minecraft:overworld run fill 350 71 31 350 144 31 air
execute in minecraft:overworld run fill 350 58 32 350 67 32 stone
execute in minecraft:overworld run fill 350 68 32 350 69 32 dirt
execute in minecraft:overworld run setblock 350 70 32 coarse_dirt
execute in minecraft:overworld run fill 350 71 32 350 144 32 air
execute in minecraft:overworld run fill 350 58 33 350 67 33 stone
execute in minecraft:overworld run fill 350 68 33 350 69 33 dirt
execute in minecraft:overworld run setblock 350 70 33 coarse_dirt
execute in minecraft:overworld run fill 350 71 33 350 144 33 air
execute in minecraft:overworld run fill 350 58 34 350 67 34 stone
execute in minecraft:overworld run fill 350 68 34 350 69 34 dirt
execute in minecraft:overworld run setblock 350 70 34 grass_block
execute in minecraft:overworld run fill 350 71 34 350 144 34 air
execute in minecraft:overworld run fill 350 58 35 350 67 35 stone
execute in minecraft:overworld run fill 350 68 35 350 69 35 dirt
execute in minecraft:overworld run setblock 350 70 35 coarse_dirt
execute in minecraft:overworld run fill 350 71 35 350 144 35 air
execute in minecraft:overworld run fill 350 58 36 350 67 36 stone
execute in minecraft:overworld run fill 350 68 36 350 69 36 dirt
execute in minecraft:overworld run setblock 350 70 36 coarse_dirt
execute in minecraft:overworld run fill 350 71 36 350 144 36 air
execute in minecraft:overworld run fill 350 58 37 350 67 37 stone
execute in minecraft:overworld run fill 350 68 37 350 69 37 dirt
execute in minecraft:overworld run setblock 350 70 37 coarse_dirt
execute in minecraft:overworld run fill 350 71 37 350 144 37 air
execute in minecraft:overworld run fill 350 58 38 350 67 38 stone
execute in minecraft:overworld run fill 350 68 38 350 69 38 dirt
execute in minecraft:overworld run setblock 350 70 38 coarse_dirt
execute in minecraft:overworld run fill 350 71 38 350 144 38 air
execute in minecraft:overworld run fill 350 58 39 350 66 39 stone
execute in minecraft:overworld run fill 350 67 39 350 68 39 dirt
execute in minecraft:overworld run setblock 350 69 39 coarse_dirt
execute in minecraft:overworld run fill 350 70 39 350 144 39 air
execute in minecraft:overworld run fill 350 58 40 350 66 40 stone
execute in minecraft:overworld run fill 350 67 40 350 68 40 dirt
execute in minecraft:overworld run setblock 350 69 40 coarse_dirt
execute in minecraft:overworld run fill 350 70 40 350 144 40 air
execute in minecraft:overworld run fill 350 58 41 350 65 41 stone
execute in minecraft:overworld run fill 350 66 41 350 67 41 dirt
execute in minecraft:overworld run setblock 350 68 41 coarse_dirt
execute in minecraft:overworld run fill 350 69 41 350 144 41 air
execute in minecraft:overworld run fill 350 58 42 350 64 42 stone
execute in minecraft:overworld run fill 350 65 42 350 66 42 dirt
execute in minecraft:overworld run setblock 350 67 42 coarse_dirt
execute in minecraft:overworld run fill 350 68 42 350 144 42 air
execute in minecraft:overworld run fill 350 58 43 350 64 43 stone
execute in minecraft:overworld run fill 350 65 43 350 66 43 dirt
execute in minecraft:overworld run setblock 350 67 43 coarse_dirt
execute in minecraft:overworld run fill 350 68 43 350 144 43 air
execute in minecraft:overworld run fill 350 58 44 350 63 44 stone
execute in minecraft:overworld run fill 350 64 44 350 65 44 dirt
execute in minecraft:overworld run setblock 350 66 44 coarse_dirt
execute in minecraft:overworld run fill 350 67 44 350 144 44 air
execute in minecraft:overworld run fill 350 58 45 350 63 45 stone
execute in minecraft:overworld run fill 350 64 45 350 65 45 dirt
execute in minecraft:overworld run setblock 350 66 45 grass_block
execute in minecraft:overworld run fill 350 67 45 350 144 45 air
execute in minecraft:overworld run fill 350 58 46 350 62 46 stone
execute in minecraft:overworld run fill 350 63 46 350 64 46 dirt
execute in minecraft:overworld run setblock 350 65 46 coarse_dirt
execute in minecraft:overworld run fill 350 66 46 350 144 46 air
execute in minecraft:overworld run fill 350 58 47 350 62 47 stone
execute in minecraft:overworld run fill 350 63 47 350 64 47 dirt
execute in minecraft:overworld run setblock 350 65 47 coarse_dirt
execute in minecraft:overworld run fill 350 66 47 350 144 47 air
execute in minecraft:overworld run fill 351 58 -48 351 61 -48 stone
execute in minecraft:overworld run fill 351 62 -48 351 63 -48 dirt
execute in minecraft:overworld run setblock 351 64 -48 coarse_dirt
execute in minecraft:overworld run fill 351 65 -48 351 144 -48 air
execute in minecraft:overworld run fill 351 58 -47 351 63 -47 stone
execute in minecraft:overworld run fill 351 64 -47 351 65 -47 dirt
execute in minecraft:overworld run setblock 351 66 -47 coarse_dirt
execute in minecraft:overworld run fill 351 67 -47 351 144 -47 air
execute in minecraft:overworld run fill 351 58 -46 351 65 -46 stone
execute in minecraft:overworld run fill 351 66 -46 351 67 -46 dirt
execute in minecraft:overworld run setblock 351 68 -46 coarse_dirt
execute in minecraft:overworld run fill 351 69 -46 351 144 -46 air
execute in minecraft:overworld run fill 351 58 -45 351 67 -45 stone
execute in minecraft:overworld run fill 351 68 -45 351 69 -45 dirt
execute in minecraft:overworld run setblock 351 70 -45 coarse_dirt
execute in minecraft:overworld run fill 351 71 -45 351 144 -45 air
execute in minecraft:overworld run fill 351 58 -44 351 68 -44 stone
execute in minecraft:overworld run fill 351 69 -44 351 70 -44 dirt
execute in minecraft:overworld run setblock 351 71 -44 coarse_dirt
execute in minecraft:overworld run fill 351 72 -44 351 144 -44 air
execute in minecraft:overworld run fill 351 58 -43 351 70 -43 stone
execute in minecraft:overworld run fill 351 71 -43 351 72 -43 dirt
execute in minecraft:overworld run setblock 351 73 -43 grass_block
execute in minecraft:overworld run fill 351 74 -43 351 144 -43 air
execute in minecraft:overworld run fill 351 58 -42 351 71 -42 stone
execute in minecraft:overworld run fill 351 72 -42 351 73 -42 dirt
execute in minecraft:overworld run setblock 351 74 -42 coarse_dirt
execute in minecraft:overworld run fill 351 75 -42 351 144 -42 air
execute in minecraft:overworld run fill 351 58 -41 351 73 -41 stone
execute in minecraft:overworld run fill 351 74 -41 351 75 -41 dirt
execute in minecraft:overworld run setblock 351 76 -41 grass_block
execute in minecraft:overworld run fill 351 77 -41 351 144 -41 air
execute in minecraft:overworld run fill 351 58 -40 351 74 -40 stone
execute in minecraft:overworld run fill 351 75 -40 351 76 -40 dirt
execute in minecraft:overworld run setblock 351 77 -40 coarse_dirt
execute in minecraft:overworld run fill 351 78 -40 351 144 -40 air
execute in minecraft:overworld run fill 351 58 -39 351 75 -39 stone
execute in minecraft:overworld run fill 351 76 -39 351 77 -39 dirt
execute in minecraft:overworld run setblock 351 78 -39 coarse_dirt
execute in minecraft:overworld run fill 351 79 -39 351 144 -39 air
execute in minecraft:overworld run fill 351 58 -38 351 76 -38 stone
execute in minecraft:overworld run fill 351 77 -38 351 78 -38 dirt
execute in minecraft:overworld run setblock 351 79 -38 coarse_dirt
schedule function blade_gallery:random/battlefield/part_23 1t replace
