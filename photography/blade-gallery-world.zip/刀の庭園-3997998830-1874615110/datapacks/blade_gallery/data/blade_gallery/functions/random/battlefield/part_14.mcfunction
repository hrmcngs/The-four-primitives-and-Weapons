execute in minecraft:overworld run fill 345 75 -24 345 144 -24 air
execute in minecraft:overworld run fill 345 58 -23 345 71 -23 stone
execute in minecraft:overworld run fill 345 72 -23 345 73 -23 dirt
execute in minecraft:overworld run setblock 345 74 -23 coarse_dirt
execute in minecraft:overworld run fill 345 75 -23 345 144 -23 air
execute in minecraft:overworld run fill 345 58 -22 345 71 -22 stone
execute in minecraft:overworld run fill 345 72 -22 345 73 -22 dirt
execute in minecraft:overworld run setblock 345 74 -22 coarse_dirt
execute in minecraft:overworld run fill 345 75 -22 345 144 -22 air
execute in minecraft:overworld run fill 345 58 -21 345 71 -21 stone
execute in minecraft:overworld run fill 345 72 -21 345 73 -21 dirt
execute in minecraft:overworld run setblock 345 74 -21 grass_block
execute in minecraft:overworld run fill 345 75 -21 345 144 -21 air
execute in minecraft:overworld run fill 345 58 -20 345 70 -20 stone
execute in minecraft:overworld run fill 345 71 -20 345 72 -20 dirt
execute in minecraft:overworld run setblock 345 73 -20 coarse_dirt
execute in minecraft:overworld run fill 345 74 -20 345 144 -20 air
execute in minecraft:overworld run fill 345 58 -19 345 70 -19 stone
execute in minecraft:overworld run fill 345 71 -19 345 72 -19 dirt
execute in minecraft:overworld run setblock 345 73 -19 grass_block
execute in minecraft:overworld run fill 345 74 -19 345 144 -19 air
execute in minecraft:overworld run fill 345 58 -18 345 70 -18 stone
execute in minecraft:overworld run fill 345 71 -18 345 72 -18 dirt
execute in minecraft:overworld run setblock 345 73 -18 coarse_dirt
execute in minecraft:overworld run fill 345 74 -18 345 144 -18 air
execute in minecraft:overworld run fill 345 58 -17 345 69 -17 stone
execute in minecraft:overworld run fill 345 70 -17 345 71 -17 dirt
execute in minecraft:overworld run setblock 345 72 -17 coarse_dirt
execute in minecraft:overworld run fill 345 73 -17 345 144 -17 air
execute in minecraft:overworld run setblock 345 73 -17 grass
execute in minecraft:overworld run fill 345 58 -16 345 69 -16 stone
execute in minecraft:overworld run fill 345 70 -16 345 71 -16 dirt
execute in minecraft:overworld run setblock 345 72 -16 grass_block
execute in minecraft:overworld run fill 345 73 -16 345 144 -16 air
execute in minecraft:overworld run fill 345 58 -15 345 68 -15 stone
execute in minecraft:overworld run fill 345 69 -15 345 70 -15 dirt
execute in minecraft:overworld run setblock 345 71 -15 coarse_dirt
execute in minecraft:overworld run fill 345 72 -15 345 144 -15 air
execute in minecraft:overworld run fill 345 58 -14 345 68 -14 stone
execute in minecraft:overworld run fill 345 69 -14 345 70 -14 dirt
execute in minecraft:overworld run setblock 345 71 -14 coarse_dirt
execute in minecraft:overworld run fill 345 72 -14 345 144 -14 air
execute in minecraft:overworld run fill 345 58 -13 345 67 -13 stone
execute in minecraft:overworld run fill 345 68 -13 345 69 -13 dirt
execute in minecraft:overworld run setblock 345 70 -13 coarse_dirt
execute in minecraft:overworld run fill 345 71 -13 345 144 -13 air
execute in minecraft:overworld run fill 345 58 -12 345 66 -12 stone
execute in minecraft:overworld run fill 345 67 -12 345 68 -12 dirt
execute in minecraft:overworld run setblock 345 69 -12 grass_block
execute in minecraft:overworld run fill 345 70 -12 345 144 -12 air
execute in minecraft:overworld run fill 345 58 -11 345 66 -11 stone
execute in minecraft:overworld run fill 345 67 -11 345 68 -11 dirt
execute in minecraft:overworld run setblock 345 69 -11 coarse_dirt
execute in minecraft:overworld run fill 345 70 -11 345 144 -11 air
execute in minecraft:overworld run setblock 345 70 -11 grass
execute in minecraft:overworld run fill 345 58 -10 345 66 -10 stone
execute in minecraft:overworld run fill 345 67 -10 345 68 -10 dirt
execute in minecraft:overworld run setblock 345 69 -10 grass_block
execute in minecraft:overworld run fill 345 70 -10 345 144 -10 air
execute in minecraft:overworld run fill 345 58 -9 345 66 -9 stone
execute in minecraft:overworld run fill 345 67 -9 345 68 -9 dirt
execute in minecraft:overworld run setblock 345 69 -9 coarse_dirt
execute in minecraft:overworld run fill 345 70 -9 345 144 -9 air
execute in minecraft:overworld run fill 345 58 -8 345 66 -8 stone
execute in minecraft:overworld run fill 345 67 -8 345 68 -8 dirt
execute in minecraft:overworld run setblock 345 69 -8 grass_block
execute in minecraft:overworld run fill 345 70 -8 345 144 -8 air
execute in minecraft:overworld run fill 345 58 -7 345 66 -7 stone
execute in minecraft:overworld run fill 345 67 -7 345 68 -7 dirt
execute in minecraft:overworld run setblock 345 69 -7 coarse_dirt
execute in minecraft:overworld run fill 345 70 -7 345 144 -7 air
execute in minecraft:overworld run fill 345 58 -6 345 66 -6 stone
execute in minecraft:overworld run fill 345 67 -6 345 68 -6 dirt
execute in minecraft:overworld run setblock 345 69 -6 grass_block
execute in minecraft:overworld run fill 345 70 -6 345 144 -6 air
execute in minecraft:overworld run fill 345 58 -5 345 66 -5 stone
execute in minecraft:overworld run fill 345 67 -5 345 68 -5 dirt
execute in minecraft:overworld run setblock 345 69 -5 grass_block
execute in minecraft:overworld run fill 345 70 -5 345 144 -5 air
execute in minecraft:overworld run fill 345 58 -4 345 66 -4 stone
execute in minecraft:overworld run fill 345 67 -4 345 68 -4 dirt
execute in minecraft:overworld run setblock 345 69 -4 coarse_dirt
execute in minecraft:overworld run fill 345 70 -4 345 144 -4 air
execute in minecraft:overworld run fill 345 58 -3 345 66 -3 stone
execute in minecraft:overworld run fill 345 67 -3 345 68 -3 dirt
execute in minecraft:overworld run setblock 345 69 -3 coarse_dirt
execute in minecraft:overworld run fill 345 70 -3 345 144 -3 air
execute in minecraft:overworld run fill 345 58 -2 345 66 -2 stone
execute in minecraft:overworld run fill 345 67 -2 345 68 -2 dirt
execute in minecraft:overworld run setblock 345 69 -2 grass_block
execute in minecraft:overworld run fill 345 70 -2 345 144 -2 air
execute in minecraft:overworld run setblock 345 70 -2 grass
execute in minecraft:overworld run fill 345 58 -1 345 66 -1 stone
execute in minecraft:overworld run fill 345 67 -1 345 68 -1 dirt
execute in minecraft:overworld run setblock 345 69 -1 grass_block
execute in minecraft:overworld run fill 345 70 -1 345 144 -1 air
execute in minecraft:overworld run fill 345 58 0 345 67 0 stone
execute in minecraft:overworld run fill 345 68 0 345 69 0 dirt
execute in minecraft:overworld run setblock 345 70 0 grass_block
execute in minecraft:overworld run fill 345 71 0 345 144 0 air
execute in minecraft:overworld run fill 345 58 1 345 67 1 stone
execute in minecraft:overworld run fill 345 68 1 345 69 1 dirt
execute in minecraft:overworld run setblock 345 70 1 coarse_dirt
execute in minecraft:overworld run fill 345 71 1 345 144 1 air
execute in minecraft:overworld run fill 345 58 2 345 66 2 stone
execute in minecraft:overworld run fill 345 67 2 345 68 2 dirt
execute in minecraft:overworld run setblock 345 69 2 grass_block
execute in minecraft:overworld run fill 345 70 2 345 144 2 air
execute in minecraft:overworld run fill 345 58 3 345 66 3 stone
execute in minecraft:overworld run fill 345 67 3 345 68 3 dirt
execute in minecraft:overworld run setblock 345 69 3 coarse_dirt
execute in minecraft:overworld run fill 345 70 3 345 144 3 air
execute in minecraft:overworld run fill 345 58 4 345 66 4 stone
execute in minecraft:overworld run fill 345 67 4 345 68 4 dirt
execute in minecraft:overworld run setblock 345 69 4 coarse_dirt
execute in minecraft:overworld run fill 345 70 4 345 144 4 air
execute in minecraft:overworld run fill 345 58 5 345 66 5 stone
execute in minecraft:overworld run fill 345 67 5 345 68 5 dirt
execute in minecraft:overworld run setblock 345 69 5 coarse_dirt
execute in minecraft:overworld run fill 345 70 5 345 144 5 air
execute in minecraft:overworld run fill 345 58 6 345 66 6 stone
execute in minecraft:overworld run fill 345 67 6 345 68 6 dirt
execute in minecraft:overworld run setblock 345 69 6 coarse_dirt
execute in minecraft:overworld run fill 345 70 6 345 144 6 air
execute in minecraft:overworld run fill 345 58 7 345 66 7 stone
execute in minecraft:overworld run fill 345 67 7 345 68 7 dirt
execute in minecraft:overworld run setblock 345 69 7 coarse_dirt
execute in minecraft:overworld run fill 345 70 7 345 144 7 air
execute in minecraft:overworld run fill 345 58 8 345 66 8 stone
execute in minecraft:overworld run fill 345 67 8 345 68 8 dirt
execute in minecraft:overworld run setblock 345 69 8 coarse_dirt
execute in minecraft:overworld run fill 345 70 8 345 144 8 air
execute in minecraft:overworld run fill 345 58 9 345 66 9 stone
execute in minecraft:overworld run fill 345 67 9 345 68 9 dirt
execute in minecraft:overworld run setblock 345 69 9 grass_block
execute in minecraft:overworld run fill 345 70 9 345 144 9 air
execute in minecraft:overworld run fill 345 58 10 345 66 10 stone
execute in minecraft:overworld run fill 345 67 10 345 68 10 dirt
execute in minecraft:overworld run setblock 345 69 10 grass_block
execute in minecraft:overworld run fill 345 70 10 345 144 10 air
execute in minecraft:overworld run fill 345 58 11 345 66 11 stone
execute in minecraft:overworld run fill 345 67 11 345 68 11 dirt
execute in minecraft:overworld run setblock 345 69 11 coarse_dirt
execute in minecraft:overworld run fill 345 70 11 345 144 11 air
execute in minecraft:overworld run setblock 345 70 11 mossy_cobblestone
execute in minecraft:overworld run fill 345 58 12 345 66 12 stone
execute in minecraft:overworld run fill 345 67 12 345 68 12 dirt
execute in minecraft:overworld run setblock 345 69 12 grass_block
execute in minecraft:overworld run fill 345 70 12 345 144 12 air
execute in minecraft:overworld run fill 345 58 13 345 65 13 stone
execute in minecraft:overworld run fill 345 66 13 345 67 13 dirt
execute in minecraft:overworld run setblock 345 68 13 grass_block
execute in minecraft:overworld run fill 345 69 13 345 144 13 air
execute in minecraft:overworld run fill 345 58 14 345 65 14 stone
execute in minecraft:overworld run fill 345 66 14 345 67 14 dirt
execute in minecraft:overworld run setblock 345 68 14 grass_block
execute in minecraft:overworld run fill 345 69 14 345 144 14 air
execute in minecraft:overworld run fill 345 58 15 345 64 15 stone
execute in minecraft:overworld run fill 345 65 15 345 66 15 dirt
execute in minecraft:overworld run setblock 345 67 15 coarse_dirt
execute in minecraft:overworld run fill 345 68 15 345 144 15 air
execute in minecraft:overworld run setblock 345 68 15 grass
execute in minecraft:overworld run fill 345 58 16 345 64 16 stone
execute in minecraft:overworld run fill 345 65 16 345 66 16 dirt
execute in minecraft:overworld run setblock 345 67 16 coarse_dirt
execute in minecraft:overworld run fill 345 68 16 345 144 16 air
execute in minecraft:overworld run setblock 345 68 16 grass
execute in minecraft:overworld run fill 345 58 17 345 64 17 stone
execute in minecraft:overworld run fill 345 65 17 345 66 17 dirt
execute in minecraft:overworld run setblock 345 67 17 coarse_dirt
execute in minecraft:overworld run fill 345 68 17 345 144 17 air
execute in minecraft:overworld run fill 345 58 18 345 64 18 stone
execute in minecraft:overworld run fill 345 65 18 345 66 18 dirt
execute in minecraft:overworld run setblock 345 67 18 coarse_dirt
execute in minecraft:overworld run fill 345 68 18 345 144 18 air
execute in minecraft:overworld run fill 345 58 19 345 64 19 stone
execute in minecraft:overworld run fill 345 65 19 345 66 19 dirt
execute in minecraft:overworld run setblock 345 67 19 coarse_dirt
execute in minecraft:overworld run fill 345 68 19 345 144 19 air
execute in minecraft:overworld run fill 345 58 20 345 64 20 stone
execute in minecraft:overworld run fill 345 65 20 345 66 20 dirt
execute in minecraft:overworld run setblock 345 67 20 coarse_dirt
execute in minecraft:overworld run fill 345 68 20 345 144 20 air
execute in minecraft:overworld run fill 345 58 21 345 64 21 stone
execute in minecraft:overworld run fill 345 65 21 345 66 21 dirt
execute in minecraft:overworld run setblock 345 67 21 grass_block
execute in minecraft:overworld run fill 345 68 21 345 144 21 air
execute in minecraft:overworld run fill 345 58 22 345 64 22 stone
execute in minecraft:overworld run fill 345 65 22 345 66 22 dirt
execute in minecraft:overworld run setblock 345 67 22 coarse_dirt
execute in minecraft:overworld run fill 345 68 22 345 144 22 air
execute in minecraft:overworld run fill 345 58 23 345 64 23 stone
execute in minecraft:overworld run fill 345 65 23 345 66 23 dirt
execute in minecraft:overworld run setblock 345 67 23 grass_block
execute in minecraft:overworld run fill 345 68 23 345 144 23 air
execute in minecraft:overworld run fill 345 58 24 345 65 24 stone
execute in minecraft:overworld run fill 345 66 24 345 67 24 dirt
execute in minecraft:overworld run setblock 345 68 24 coarse_dirt
execute in minecraft:overworld run fill 345 69 24 345 144 24 air
execute in minecraft:overworld run setblock 345 69 24 grass
execute in minecraft:overworld run fill 345 58 25 345 65 25 stone
execute in minecraft:overworld run fill 345 66 25 345 67 25 dirt
execute in minecraft:overworld run setblock 345 68 25 coarse_dirt
execute in minecraft:overworld run fill 345 69 25 345 144 25 air
execute in minecraft:overworld run fill 345 58 26 345 65 26 stone
execute in minecraft:overworld run fill 345 66 26 345 67 26 dirt
execute in minecraft:overworld run setblock 345 68 26 coarse_dirt
execute in minecraft:overworld run fill 345 69 26 345 144 26 air
execute in minecraft:overworld run fill 345 58 27 345 65 27 stone
execute in minecraft:overworld run fill 345 66 27 345 67 27 dirt
execute in minecraft:overworld run setblock 345 68 27 grass_block
execute in minecraft:overworld run fill 345 69 27 345 144 27 air
execute in minecraft:overworld run fill 345 58 28 345 65 28 stone
execute in minecraft:overworld run fill 345 66 28 345 67 28 dirt
execute in minecraft:overworld run setblock 345 68 28 grass_block
execute in minecraft:overworld run fill 345 69 28 345 144 28 air
execute in minecraft:overworld run fill 345 58 29 345 65 29 stone
execute in minecraft:overworld run fill 345 66 29 345 67 29 dirt
execute in minecraft:overworld run setblock 345 68 29 grass_block
execute in minecraft:overworld run fill 345 69 29 345 144 29 air
execute in minecraft:overworld run fill 345 58 30 345 65 30 stone
execute in minecraft:overworld run fill 345 66 30 345 67 30 dirt
execute in minecraft:overworld run setblock 345 68 30 coarse_dirt
execute in minecraft:overworld run fill 345 69 30 345 144 30 air
execute in minecraft:overworld run fill 345 58 31 345 65 31 stone
execute in minecraft:overworld run fill 345 66 31 345 67 31 dirt
execute in minecraft:overworld run setblock 345 68 31 coarse_dirt
execute in minecraft:overworld run fill 345 69 31 345 144 31 air
execute in minecraft:overworld run fill 345 58 32 345 64 32 stone
execute in minecraft:overworld run fill 345 65 32 345 66 32 dirt
execute in minecraft:overworld run setblock 345 67 32 grass_block
execute in minecraft:overworld run fill 345 68 32 345 144 32 air
execute in minecraft:overworld run fill 345 58 33 345 64 33 stone
execute in minecraft:overworld run fill 345 65 33 345 66 33 dirt
execute in minecraft:overworld run setblock 345 67 33 coarse_dirt
execute in minecraft:overworld run fill 345 68 33 345 144 33 air
execute in minecraft:overworld run fill 345 58 34 345 64 34 stone
execute in minecraft:overworld run fill 345 65 34 345 66 34 dirt
execute in minecraft:overworld run setblock 345 67 34 coarse_dirt
execute in minecraft:overworld run fill 345 68 34 345 144 34 air
execute in minecraft:overworld run fill 345 58 35 345 64 35 stone
execute in minecraft:overworld run fill 345 65 35 345 66 35 dirt
execute in minecraft:overworld run setblock 345 67 35 coarse_dirt
execute in minecraft:overworld run fill 345 68 35 345 144 35 air
execute in minecraft:overworld run fill 345 58 36 345 64 36 stone
execute in minecraft:overworld run fill 345 65 36 345 66 36 dirt
execute in minecraft:overworld run setblock 345 67 36 grass_block
execute in minecraft:overworld run fill 345 68 36 345 144 36 air
execute in minecraft:overworld run fill 345 58 37 345 64 37 stone
execute in minecraft:overworld run fill 345 65 37 345 66 37 dirt
execute in minecraft:overworld run setblock 345 67 37 coarse_dirt
execute in minecraft:overworld run fill 345 68 37 345 144 37 air
execute in minecraft:overworld run fill 345 58 38 345 64 38 stone
execute in minecraft:overworld run fill 345 65 38 345 66 38 dirt
execute in minecraft:overworld run setblock 345 67 38 coarse_dirt
execute in minecraft:overworld run fill 345 68 38 345 144 38 air
schedule function blade_gallery:random/battlefield/part_15 1t replace
