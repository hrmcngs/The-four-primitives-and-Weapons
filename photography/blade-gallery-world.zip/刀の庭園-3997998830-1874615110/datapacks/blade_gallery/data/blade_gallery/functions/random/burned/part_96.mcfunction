execute in minecraft:overworld run fill 268 58 17 268 56 17 stone
execute in minecraft:overworld run fill 268 57 17 268 58 17 dirt
execute in minecraft:overworld run setblock 268 59 17 gravel
execute in minecraft:overworld run fill 268 60 17 268 144 17 air
execute in minecraft:overworld run fill 268 60 17 268 64 17 water
execute in minecraft:overworld run fill 268 58 18 268 56 18 stone
execute in minecraft:overworld run fill 268 57 18 268 58 18 dirt
execute in minecraft:overworld run setblock 268 59 18 gravel
execute in minecraft:overworld run fill 268 60 18 268 144 18 air
execute in minecraft:overworld run fill 268 60 18 268 64 18 water
execute in minecraft:overworld run fill 268 58 19 268 56 19 stone
execute in minecraft:overworld run fill 268 57 19 268 58 19 dirt
execute in minecraft:overworld run setblock 268 59 19 gravel
execute in minecraft:overworld run fill 268 60 19 268 144 19 air
execute in minecraft:overworld run fill 268 60 19 268 64 19 water
execute in minecraft:overworld run fill 268 58 20 268 56 20 stone
execute in minecraft:overworld run fill 268 57 20 268 58 20 dirt
execute in minecraft:overworld run setblock 268 59 20 gravel
execute in minecraft:overworld run fill 268 60 20 268 144 20 air
execute in minecraft:overworld run fill 268 60 20 268 64 20 water
execute in minecraft:overworld run fill 268 58 21 268 56 21 stone
execute in minecraft:overworld run fill 268 57 21 268 58 21 dirt
execute in minecraft:overworld run setblock 268 59 21 gravel
execute in minecraft:overworld run fill 268 60 21 268 144 21 air
execute in minecraft:overworld run fill 268 60 21 268 64 21 water
execute in minecraft:overworld run fill 268 58 22 268 56 22 stone
execute in minecraft:overworld run fill 268 57 22 268 58 22 dirt
execute in minecraft:overworld run setblock 268 59 22 gravel
execute in minecraft:overworld run fill 268 60 22 268 144 22 air
execute in minecraft:overworld run fill 268 60 22 268 64 22 water
execute in minecraft:overworld run fill 268 58 23 268 56 23 stone
execute in minecraft:overworld run fill 268 57 23 268 58 23 dirt
execute in minecraft:overworld run setblock 268 59 23 gravel
execute in minecraft:overworld run fill 268 60 23 268 144 23 air
execute in minecraft:overworld run fill 268 60 23 268 64 23 water
execute in minecraft:overworld run fill 268 58 24 268 56 24 stone
execute in minecraft:overworld run fill 268 57 24 268 58 24 dirt
execute in minecraft:overworld run setblock 268 59 24 gravel
execute in minecraft:overworld run fill 268 60 24 268 144 24 air
execute in minecraft:overworld run fill 268 60 24 268 64 24 water
execute in minecraft:overworld run fill 268 58 25 268 56 25 stone
execute in minecraft:overworld run fill 268 57 25 268 58 25 dirt
execute in minecraft:overworld run setblock 268 59 25 gravel
execute in minecraft:overworld run fill 268 60 25 268 144 25 air
execute in minecraft:overworld run fill 268 60 25 268 64 25 water
execute in minecraft:overworld run fill 268 58 26 268 56 26 stone
execute in minecraft:overworld run fill 268 57 26 268 58 26 dirt
execute in minecraft:overworld run setblock 268 59 26 gravel
execute in minecraft:overworld run fill 268 60 26 268 144 26 air
execute in minecraft:overworld run fill 268 60 26 268 64 26 water
execute in minecraft:overworld run fill 268 58 27 268 56 27 stone
execute in minecraft:overworld run fill 268 57 27 268 58 27 dirt
execute in minecraft:overworld run setblock 268 59 27 gravel
execute in minecraft:overworld run fill 268 60 27 268 144 27 air
execute in minecraft:overworld run fill 268 60 27 268 64 27 water
execute in minecraft:overworld run fill 268 58 28 268 57 28 stone
execute in minecraft:overworld run fill 268 58 28 268 59 28 dirt
execute in minecraft:overworld run setblock 268 60 28 gravel
execute in minecraft:overworld run fill 268 61 28 268 144 28 air
execute in minecraft:overworld run fill 268 61 28 268 64 28 water
execute in minecraft:overworld run fill 268 58 29 268 57 29 stone
execute in minecraft:overworld run fill 268 58 29 268 59 29 dirt
execute in minecraft:overworld run setblock 268 60 29 gravel
execute in minecraft:overworld run fill 268 61 29 268 144 29 air
execute in minecraft:overworld run fill 268 61 29 268 64 29 water
execute in minecraft:overworld run fill 268 58 30 268 57 30 stone
execute in minecraft:overworld run fill 268 58 30 268 59 30 dirt
execute in minecraft:overworld run setblock 268 60 30 gravel
execute in minecraft:overworld run fill 268 61 30 268 144 30 air
execute in minecraft:overworld run fill 268 61 30 268 64 30 water
execute in minecraft:overworld run fill 268 58 31 268 57 31 stone
execute in minecraft:overworld run fill 268 58 31 268 59 31 dirt
execute in minecraft:overworld run setblock 268 60 31 gravel
execute in minecraft:overworld run fill 268 61 31 268 144 31 air
execute in minecraft:overworld run fill 268 61 31 268 64 31 water
execute in minecraft:overworld run fill 268 58 32 268 58 32 stone
execute in minecraft:overworld run fill 268 59 32 268 60 32 dirt
execute in minecraft:overworld run setblock 268 61 32 gravel
execute in minecraft:overworld run fill 268 62 32 268 144 32 air
execute in minecraft:overworld run fill 268 62 32 268 64 32 water
execute in minecraft:overworld run fill 268 58 33 268 58 33 stone
execute in minecraft:overworld run fill 268 59 33 268 60 33 dirt
execute in minecraft:overworld run setblock 268 61 33 gravel
execute in minecraft:overworld run fill 268 62 33 268 144 33 air
execute in minecraft:overworld run fill 268 62 33 268 64 33 water
execute in minecraft:overworld run fill 268 58 34 268 58 34 stone
execute in minecraft:overworld run fill 268 59 34 268 60 34 dirt
execute in minecraft:overworld run setblock 268 61 34 gravel
execute in minecraft:overworld run fill 268 62 34 268 144 34 air
execute in minecraft:overworld run fill 268 62 34 268 64 34 water
execute in minecraft:overworld run fill 268 58 35 268 58 35 stone
execute in minecraft:overworld run fill 268 59 35 268 60 35 dirt
execute in minecraft:overworld run setblock 268 61 35 gravel
execute in minecraft:overworld run fill 268 62 35 268 144 35 air
execute in minecraft:overworld run fill 268 62 35 268 64 35 water
execute in minecraft:overworld run fill 268 58 36 268 59 36 stone
execute in minecraft:overworld run fill 268 60 36 268 61 36 dirt
execute in minecraft:overworld run setblock 268 62 36 gravel
execute in minecraft:overworld run fill 268 63 36 268 144 36 air
execute in minecraft:overworld run fill 268 63 36 268 64 36 water
execute in minecraft:overworld run fill 268 58 37 268 59 37 stone
execute in minecraft:overworld run fill 268 60 37 268 61 37 dirt
execute in minecraft:overworld run setblock 268 62 37 gravel
execute in minecraft:overworld run fill 268 63 37 268 144 37 air
execute in minecraft:overworld run fill 268 63 37 268 64 37 water
execute in minecraft:overworld run fill 268 58 38 268 59 38 stone
execute in minecraft:overworld run fill 268 60 38 268 61 38 dirt
execute in minecraft:overworld run setblock 268 62 38 gravel
execute in minecraft:overworld run fill 268 63 38 268 144 38 air
execute in minecraft:overworld run fill 268 63 38 268 64 38 water
execute in minecraft:overworld run fill 268 58 39 268 60 39 stone
execute in minecraft:overworld run fill 268 61 39 268 62 39 dirt
execute in minecraft:overworld run setblock 268 63 39 gravel
execute in minecraft:overworld run fill 268 64 39 268 144 39 air
execute in minecraft:overworld run fill 268 64 39 268 64 39 water
execute in minecraft:overworld run fill 268 58 40 268 60 40 stone
execute in minecraft:overworld run fill 268 61 40 268 62 40 dirt
execute in minecraft:overworld run setblock 268 63 40 gravel
execute in minecraft:overworld run fill 268 64 40 268 144 40 air
execute in minecraft:overworld run fill 268 64 40 268 64 40 water
execute in minecraft:overworld run fill 268 58 41 268 60 41 stone
execute in minecraft:overworld run fill 268 61 41 268 62 41 dirt
execute in minecraft:overworld run setblock 268 63 41 gravel
execute in minecraft:overworld run fill 268 64 41 268 144 41 air
execute in minecraft:overworld run fill 268 64 41 268 64 41 water
execute in minecraft:overworld run fill 268 58 42 268 61 42 stone
execute in minecraft:overworld run fill 268 62 42 268 63 42 dirt
execute in minecraft:overworld run setblock 268 64 42 grass_block
execute in minecraft:overworld run fill 268 65 42 268 144 42 air
execute in minecraft:overworld run fill 268 58 43 268 61 43 stone
execute in minecraft:overworld run fill 268 62 43 268 63 43 dirt
execute in minecraft:overworld run setblock 268 64 43 grass_block
execute in minecraft:overworld run fill 268 65 43 268 144 43 air
execute in minecraft:overworld run fill 268 58 44 268 61 44 stone
execute in minecraft:overworld run fill 268 62 44 268 63 44 dirt
execute in minecraft:overworld run setblock 268 64 44 grass_block
execute in minecraft:overworld run fill 268 65 44 268 144 44 air
execute in minecraft:overworld run fill 268 58 45 268 61 45 stone
execute in minecraft:overworld run fill 268 62 45 268 63 45 dirt
execute in minecraft:overworld run setblock 268 64 45 grass_block
execute in minecraft:overworld run fill 268 65 45 268 144 45 air
execute in minecraft:overworld run fill 268 58 46 268 61 46 stone
execute in minecraft:overworld run fill 268 62 46 268 63 46 dirt
execute in minecraft:overworld run setblock 268 64 46 coarse_dirt
execute in minecraft:overworld run fill 268 65 46 268 144 46 air
execute in minecraft:overworld run fill 268 58 47 268 61 47 stone
execute in minecraft:overworld run fill 268 62 47 268 63 47 dirt
execute in minecraft:overworld run setblock 268 64 47 coarse_dirt
execute in minecraft:overworld run fill 268 65 47 268 144 47 air
execute in minecraft:overworld run fill 269 58 -48 269 61 -48 stone
execute in minecraft:overworld run fill 269 62 -48 269 63 -48 dirt
execute in minecraft:overworld run setblock 269 64 -48 grass_block
execute in minecraft:overworld run fill 269 65 -48 269 144 -48 air
execute in minecraft:overworld run fill 269 58 -47 269 63 -47 stone
execute in minecraft:overworld run fill 269 64 -47 269 65 -47 dirt
execute in minecraft:overworld run setblock 269 66 -47 grass_block
execute in minecraft:overworld run fill 269 67 -47 269 144 -47 air
execute in minecraft:overworld run fill 269 58 -46 269 65 -46 stone
execute in minecraft:overworld run fill 269 66 -46 269 67 -46 dirt
execute in minecraft:overworld run setblock 269 68 -46 grass_block
execute in minecraft:overworld run fill 269 69 -46 269 144 -46 air
execute in minecraft:overworld run fill 269 58 -45 269 67 -45 stone
execute in minecraft:overworld run fill 269 68 -45 269 69 -45 dirt
execute in minecraft:overworld run setblock 269 70 -45 grass_block
execute in minecraft:overworld run fill 269 71 -45 269 144 -45 air
execute in minecraft:overworld run fill 269 58 -44 269 69 -44 stone
execute in minecraft:overworld run fill 269 70 -44 269 71 -44 dirt
execute in minecraft:overworld run setblock 269 72 -44 coarse_dirt
execute in minecraft:overworld run fill 269 73 -44 269 144 -44 air
execute in minecraft:overworld run fill 269 58 -43 269 71 -43 stone
execute in minecraft:overworld run fill 269 72 -43 269 73 -43 dirt
execute in minecraft:overworld run setblock 269 74 -43 coarse_dirt
execute in minecraft:overworld run fill 269 75 -43 269 144 -43 air
execute in minecraft:overworld run fill 269 58 -42 269 72 -42 stone
execute in minecraft:overworld run fill 269 73 -42 269 74 -42 dirt
execute in minecraft:overworld run setblock 269 75 -42 grass_block
execute in minecraft:overworld run fill 269 76 -42 269 144 -42 air
execute in minecraft:overworld run fill 269 58 -41 269 74 -41 stone
execute in minecraft:overworld run fill 269 75 -41 269 76 -41 dirt
execute in minecraft:overworld run setblock 269 77 -41 coarse_dirt
execute in minecraft:overworld run fill 269 78 -41 269 144 -41 air
execute in minecraft:overworld run fill 269 58 -40 269 75 -40 stone
execute in minecraft:overworld run fill 269 76 -40 269 77 -40 dirt
execute in minecraft:overworld run setblock 269 78 -40 coarse_dirt
execute in minecraft:overworld run fill 269 79 -40 269 144 -40 air
execute in minecraft:overworld run fill 269 58 -39 269 77 -39 stone
execute in minecraft:overworld run fill 269 78 -39 269 79 -39 dirt
execute in minecraft:overworld run setblock 269 80 -39 coarse_dirt
execute in minecraft:overworld run fill 269 81 -39 269 144 -39 air
execute in minecraft:overworld run fill 269 58 -38 269 78 -38 stone
execute in minecraft:overworld run fill 269 79 -38 269 80 -38 dirt
execute in minecraft:overworld run setblock 269 81 -38 coarse_dirt
execute in minecraft:overworld run fill 269 82 -38 269 144 -38 air
execute in minecraft:overworld run fill 269 58 -37 269 78 -37 stone
execute in minecraft:overworld run fill 269 79 -37 269 80 -37 dirt
execute in minecraft:overworld run setblock 269 81 -37 coarse_dirt
execute in minecraft:overworld run fill 269 82 -37 269 144 -37 air
execute in minecraft:overworld run fill 269 58 -36 269 77 -36 stone
execute in minecraft:overworld run fill 269 78 -36 269 79 -36 dirt
execute in minecraft:overworld run setblock 269 80 -36 coarse_dirt
execute in minecraft:overworld run fill 269 81 -36 269 144 -36 air
execute in minecraft:overworld run fill 269 58 -35 269 77 -35 stone
execute in minecraft:overworld run fill 269 78 -35 269 79 -35 dirt
execute in minecraft:overworld run setblock 269 80 -35 grass_block
execute in minecraft:overworld run fill 269 81 -35 269 144 -35 air
execute in minecraft:overworld run fill 269 58 -34 269 77 -34 stone
execute in minecraft:overworld run fill 269 78 -34 269 79 -34 dirt
execute in minecraft:overworld run setblock 269 80 -34 coarse_dirt
execute in minecraft:overworld run fill 269 81 -34 269 144 -34 air
execute in minecraft:overworld run fill 269 58 -33 269 76 -33 stone
execute in minecraft:overworld run fill 269 77 -33 269 78 -33 dirt
execute in minecraft:overworld run setblock 269 79 -33 coarse_dirt
execute in minecraft:overworld run fill 269 80 -33 269 144 -33 air
execute in minecraft:overworld run fill 269 58 -32 269 76 -32 stone
execute in minecraft:overworld run fill 269 77 -32 269 78 -32 dirt
execute in minecraft:overworld run setblock 269 79 -32 grass_block
execute in minecraft:overworld run fill 269 80 -32 269 144 -32 air
execute in minecraft:overworld run setblock 269 80 -32 grass
execute in minecraft:overworld run fill 269 58 -31 269 76 -31 stone
execute in minecraft:overworld run fill 269 77 -31 269 78 -31 dirt
execute in minecraft:overworld run setblock 269 79 -31 coarse_dirt
execute in minecraft:overworld run fill 269 80 -31 269 144 -31 air
execute in minecraft:overworld run setblock 269 80 -31 grass
execute in minecraft:overworld run fill 269 58 -30 269 75 -30 stone
execute in minecraft:overworld run fill 269 76 -30 269 77 -30 dirt
execute in minecraft:overworld run setblock 269 78 -30 grass_block
execute in minecraft:overworld run fill 269 79 -30 269 144 -30 air
execute in minecraft:overworld run fill 269 58 -29 269 75 -29 stone
execute in minecraft:overworld run fill 269 76 -29 269 77 -29 dirt
execute in minecraft:overworld run setblock 269 78 -29 coarse_dirt
execute in minecraft:overworld run fill 269 79 -29 269 144 -29 air
execute in minecraft:overworld run fill 269 58 -28 269 74 -28 stone
execute in minecraft:overworld run fill 269 75 -28 269 76 -28 dirt
execute in minecraft:overworld run setblock 269 77 -28 coarse_dirt
execute in minecraft:overworld run fill 269 78 -28 269 144 -28 air
execute in minecraft:overworld run fill 269 58 -27 269 74 -27 stone
execute in minecraft:overworld run fill 269 75 -27 269 76 -27 dirt
execute in minecraft:overworld run setblock 269 77 -27 coarse_dirt
execute in minecraft:overworld run fill 269 78 -27 269 144 -27 air
execute in minecraft:overworld run fill 269 58 -26 269 74 -26 stone
execute in minecraft:overworld run fill 269 75 -26 269 76 -26 dirt
execute in minecraft:overworld run setblock 269 77 -26 grass_block
execute in minecraft:overworld run fill 269 78 -26 269 144 -26 air
execute in minecraft:overworld run fill 269 58 -25 269 73 -25 stone
execute in minecraft:overworld run fill 269 74 -25 269 75 -25 dirt
execute in minecraft:overworld run setblock 269 76 -25 coarse_dirt
execute in minecraft:overworld run fill 269 77 -25 269 144 -25 air
execute in minecraft:overworld run fill 269 58 -24 269 73 -24 stone
execute in minecraft:overworld run fill 269 74 -24 269 75 -24 dirt
execute in minecraft:overworld run setblock 269 76 -24 coarse_dirt
execute in minecraft:overworld run fill 269 77 -24 269 144 -24 air
execute in minecraft:overworld run fill 269 58 -23 269 72 -23 stone
execute in minecraft:overworld run fill 269 73 -23 269 74 -23 dirt
execute in minecraft:overworld run setblock 269 75 -23 coarse_dirt
execute in minecraft:overworld run fill 269 76 -23 269 144 -23 air
execute in minecraft:overworld run fill 269 58 -22 269 72 -22 stone
schedule function blade_gallery:random/burned/part_97 1t replace
