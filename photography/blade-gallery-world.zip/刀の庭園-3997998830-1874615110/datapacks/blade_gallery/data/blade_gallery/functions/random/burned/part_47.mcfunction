execute in minecraft:overworld run fill 238 58 15 238 66 15 stone
execute in minecraft:overworld run fill 238 67 15 238 68 15 dirt
execute in minecraft:overworld run setblock 238 69 15 coarse_dirt
execute in minecraft:overworld run fill 238 70 15 238 144 15 air
execute in minecraft:overworld run fill 238 58 16 238 67 16 stone
execute in minecraft:overworld run fill 238 68 16 238 69 16 dirt
execute in minecraft:overworld run setblock 238 70 16 coarse_dirt
execute in minecraft:overworld run fill 238 71 16 238 144 16 air
execute in minecraft:overworld run fill 238 58 17 238 67 17 stone
execute in minecraft:overworld run fill 238 68 17 238 69 17 dirt
execute in minecraft:overworld run setblock 238 70 17 grass_block
execute in minecraft:overworld run fill 238 71 17 238 144 17 air
execute in minecraft:overworld run fill 238 58 18 238 67 18 stone
execute in minecraft:overworld run fill 238 68 18 238 69 18 dirt
execute in minecraft:overworld run setblock 238 70 18 coarse_dirt
execute in minecraft:overworld run fill 238 71 18 238 144 18 air
execute in minecraft:overworld run fill 238 58 19 238 67 19 stone
execute in minecraft:overworld run fill 238 68 19 238 69 19 dirt
execute in minecraft:overworld run setblock 238 70 19 coarse_dirt
execute in minecraft:overworld run fill 238 71 19 238 144 19 air
execute in minecraft:overworld run fill 238 58 20 238 67 20 stone
execute in minecraft:overworld run fill 238 68 20 238 69 20 dirt
execute in minecraft:overworld run setblock 238 70 20 grass_block
execute in minecraft:overworld run fill 238 71 20 238 144 20 air
execute in minecraft:overworld run fill 238 58 21 238 67 21 stone
execute in minecraft:overworld run fill 238 68 21 238 69 21 dirt
execute in minecraft:overworld run setblock 238 70 21 coarse_dirt
execute in minecraft:overworld run fill 238 71 21 238 144 21 air
execute in minecraft:overworld run fill 238 58 22 238 68 22 stone
execute in minecraft:overworld run fill 238 69 22 238 70 22 dirt
execute in minecraft:overworld run setblock 238 71 22 grass_block
execute in minecraft:overworld run fill 238 72 22 238 144 22 air
execute in minecraft:overworld run fill 238 58 23 238 68 23 stone
execute in minecraft:overworld run fill 238 69 23 238 70 23 dirt
execute in minecraft:overworld run setblock 238 71 23 coarse_dirt
execute in minecraft:overworld run fill 238 72 23 238 144 23 air
execute in minecraft:overworld run fill 238 58 24 238 68 24 stone
execute in minecraft:overworld run fill 238 69 24 238 70 24 dirt
execute in minecraft:overworld run setblock 238 71 24 grass_block
execute in minecraft:overworld run fill 238 72 24 238 144 24 air
execute in minecraft:overworld run fill 238 58 25 238 68 25 stone
execute in minecraft:overworld run fill 238 69 25 238 70 25 dirt
execute in minecraft:overworld run setblock 238 71 25 coarse_dirt
execute in minecraft:overworld run fill 238 72 25 238 144 25 air
execute in minecraft:overworld run fill 238 58 26 238 68 26 stone
execute in minecraft:overworld run fill 238 69 26 238 70 26 dirt
execute in minecraft:overworld run setblock 238 71 26 grass_block
execute in minecraft:overworld run fill 238 72 26 238 144 26 air
execute in minecraft:overworld run fill 238 58 27 238 68 27 stone
execute in minecraft:overworld run fill 238 69 27 238 70 27 dirt
execute in minecraft:overworld run setblock 238 71 27 coarse_dirt
execute in minecraft:overworld run fill 238 72 27 238 144 27 air
execute in minecraft:overworld run fill 238 58 28 238 68 28 stone
execute in minecraft:overworld run fill 238 69 28 238 70 28 dirt
execute in minecraft:overworld run setblock 238 71 28 coarse_dirt
execute in minecraft:overworld run fill 238 72 28 238 144 28 air
execute in minecraft:overworld run fill 238 58 29 238 68 29 stone
execute in minecraft:overworld run fill 238 69 29 238 70 29 dirt
execute in minecraft:overworld run setblock 238 71 29 coarse_dirt
execute in minecraft:overworld run fill 238 72 29 238 144 29 air
execute in minecraft:overworld run fill 238 58 30 238 68 30 stone
execute in minecraft:overworld run fill 238 69 30 238 70 30 dirt
execute in minecraft:overworld run setblock 238 71 30 coarse_dirt
execute in minecraft:overworld run fill 238 72 30 238 144 30 air
execute in minecraft:overworld run fill 238 58 31 238 68 31 stone
execute in minecraft:overworld run fill 238 69 31 238 70 31 dirt
execute in minecraft:overworld run setblock 238 71 31 grass_block
execute in minecraft:overworld run fill 238 72 31 238 144 31 air
execute in minecraft:overworld run fill 238 58 32 238 68 32 stone
execute in minecraft:overworld run fill 238 69 32 238 70 32 dirt
execute in minecraft:overworld run setblock 238 71 32 grass_block
execute in minecraft:overworld run fill 238 72 32 238 144 32 air
execute in minecraft:overworld run setblock 238 72 32 grass
execute in minecraft:overworld run fill 238 58 33 238 67 33 stone
execute in minecraft:overworld run fill 238 68 33 238 69 33 dirt
execute in minecraft:overworld run setblock 238 70 33 grass_block
execute in minecraft:overworld run fill 238 71 33 238 144 33 air
execute in minecraft:overworld run fill 238 58 34 238 67 34 stone
execute in minecraft:overworld run fill 238 68 34 238 69 34 dirt
execute in minecraft:overworld run setblock 238 70 34 coarse_dirt
execute in minecraft:overworld run fill 238 71 34 238 144 34 air
execute in minecraft:overworld run fill 238 58 35 238 67 35 stone
execute in minecraft:overworld run fill 238 68 35 238 69 35 dirt
execute in minecraft:overworld run setblock 238 70 35 coarse_dirt
execute in minecraft:overworld run fill 238 71 35 238 144 35 air
execute in minecraft:overworld run fill 238 58 36 238 67 36 stone
execute in minecraft:overworld run fill 238 68 36 238 69 36 dirt
execute in minecraft:overworld run setblock 238 70 36 grass_block
execute in minecraft:overworld run fill 238 71 36 238 144 36 air
execute in minecraft:overworld run setblock 238 71 36 grass
execute in minecraft:overworld run fill 238 58 37 238 66 37 stone
execute in minecraft:overworld run fill 238 67 37 238 68 37 dirt
execute in minecraft:overworld run setblock 238 69 37 grass_block
execute in minecraft:overworld run fill 238 70 37 238 144 37 air
execute in minecraft:overworld run fill 238 58 38 238 66 38 stone
execute in minecraft:overworld run fill 238 67 38 238 68 38 dirt
execute in minecraft:overworld run setblock 238 69 38 grass_block
execute in minecraft:overworld run fill 238 70 38 238 144 38 air
execute in minecraft:overworld run fill 238 58 39 238 65 39 stone
execute in minecraft:overworld run fill 238 66 39 238 67 39 dirt
execute in minecraft:overworld run setblock 238 68 39 coarse_dirt
execute in minecraft:overworld run fill 238 69 39 238 144 39 air
execute in minecraft:overworld run fill 238 58 40 238 65 40 stone
execute in minecraft:overworld run fill 238 66 40 238 67 40 dirt
execute in minecraft:overworld run setblock 238 68 40 grass_block
execute in minecraft:overworld run fill 238 69 40 238 144 40 air
execute in minecraft:overworld run fill 238 58 41 238 64 41 stone
execute in minecraft:overworld run fill 238 65 41 238 66 41 dirt
execute in minecraft:overworld run setblock 238 67 41 coarse_dirt
execute in minecraft:overworld run fill 238 68 41 238 144 41 air
execute in minecraft:overworld run setblock 238 68 41 grass
execute in minecraft:overworld run fill 238 58 42 238 63 42 stone
execute in minecraft:overworld run fill 238 64 42 238 65 42 dirt
execute in minecraft:overworld run setblock 238 66 42 grass_block
execute in minecraft:overworld run fill 238 67 42 238 144 42 air
execute in minecraft:overworld run fill 238 58 43 238 63 43 stone
execute in minecraft:overworld run fill 238 64 43 238 65 43 dirt
execute in minecraft:overworld run setblock 238 66 43 coarse_dirt
execute in minecraft:overworld run fill 238 67 43 238 144 43 air
execute in minecraft:overworld run fill 238 58 44 238 62 44 stone
execute in minecraft:overworld run fill 238 63 44 238 64 44 dirt
execute in minecraft:overworld run setblock 238 65 44 grass_block
execute in minecraft:overworld run fill 238 66 44 238 144 44 air
execute in minecraft:overworld run fill 238 58 45 238 62 45 stone
execute in minecraft:overworld run fill 238 63 45 238 64 45 dirt
execute in minecraft:overworld run setblock 238 65 45 grass_block
execute in minecraft:overworld run fill 238 66 45 238 144 45 air
execute in minecraft:overworld run fill 238 58 46 238 62 46 stone
execute in minecraft:overworld run fill 238 63 46 238 64 46 dirt
execute in minecraft:overworld run setblock 238 65 46 grass_block
execute in minecraft:overworld run fill 238 66 46 238 144 46 air
execute in minecraft:overworld run fill 238 58 47 238 61 47 stone
execute in minecraft:overworld run fill 238 62 47 238 63 47 dirt
execute in minecraft:overworld run setblock 238 64 47 coarse_dirt
execute in minecraft:overworld run fill 238 65 47 238 144 47 air
execute in minecraft:overworld run fill 239 58 -48 239 61 -48 stone
execute in minecraft:overworld run fill 239 62 -48 239 63 -48 dirt
execute in minecraft:overworld run setblock 239 64 -48 coarse_dirt
execute in minecraft:overworld run fill 239 65 -48 239 144 -48 air
execute in minecraft:overworld run fill 239 58 -47 239 62 -47 stone
execute in minecraft:overworld run fill 239 63 -47 239 64 -47 dirt
execute in minecraft:overworld run setblock 239 65 -47 coarse_dirt
execute in minecraft:overworld run fill 239 66 -47 239 144 -47 air
execute in minecraft:overworld run fill 239 58 -46 239 63 -46 stone
execute in minecraft:overworld run fill 239 64 -46 239 65 -46 dirt
execute in minecraft:overworld run setblock 239 66 -46 coarse_dirt
execute in minecraft:overworld run fill 239 67 -46 239 144 -46 air
execute in minecraft:overworld run fill 239 58 -45 239 65 -45 stone
execute in minecraft:overworld run fill 239 66 -45 239 67 -45 dirt
execute in minecraft:overworld run setblock 239 68 -45 coarse_dirt
execute in minecraft:overworld run fill 239 69 -45 239 144 -45 air
execute in minecraft:overworld run fill 239 58 -44 239 66 -44 stone
execute in minecraft:overworld run fill 239 67 -44 239 68 -44 dirt
execute in minecraft:overworld run setblock 239 69 -44 grass_block
execute in minecraft:overworld run fill 239 70 -44 239 144 -44 air
execute in minecraft:overworld run fill 239 58 -43 239 67 -43 stone
execute in minecraft:overworld run fill 239 68 -43 239 69 -43 dirt
execute in minecraft:overworld run setblock 239 70 -43 coarse_dirt
execute in minecraft:overworld run fill 239 71 -43 239 144 -43 air
execute in minecraft:overworld run fill 239 58 -42 239 68 -42 stone
execute in minecraft:overworld run fill 239 69 -42 239 70 -42 dirt
execute in minecraft:overworld run setblock 239 71 -42 coarse_dirt
execute in minecraft:overworld run fill 239 72 -42 239 144 -42 air
execute in minecraft:overworld run fill 239 58 -41 239 69 -41 stone
execute in minecraft:overworld run fill 239 70 -41 239 71 -41 dirt
execute in minecraft:overworld run setblock 239 72 -41 coarse_dirt
execute in minecraft:overworld run fill 239 73 -41 239 144 -41 air
execute in minecraft:overworld run fill 239 58 -40 239 70 -40 stone
execute in minecraft:overworld run fill 239 71 -40 239 72 -40 dirt
execute in minecraft:overworld run setblock 239 73 -40 grass_block
execute in minecraft:overworld run fill 239 74 -40 239 144 -40 air
execute in minecraft:overworld run fill 239 58 -39 239 71 -39 stone
execute in minecraft:overworld run fill 239 72 -39 239 73 -39 dirt
execute in minecraft:overworld run setblock 239 74 -39 grass_block
execute in minecraft:overworld run fill 239 75 -39 239 144 -39 air
execute in minecraft:overworld run fill 239 58 -38 239 73 -38 stone
execute in minecraft:overworld run fill 239 74 -38 239 75 -38 dirt
execute in minecraft:overworld run setblock 239 76 -38 coarse_dirt
execute in minecraft:overworld run fill 239 77 -38 239 144 -38 air
execute in minecraft:overworld run fill 239 58 -37 239 73 -37 stone
execute in minecraft:overworld run fill 239 74 -37 239 75 -37 dirt
execute in minecraft:overworld run setblock 239 76 -37 grass_block
execute in minecraft:overworld run fill 239 77 -37 239 144 -37 air
execute in minecraft:overworld run fill 239 58 -36 239 72 -36 stone
execute in minecraft:overworld run fill 239 73 -36 239 74 -36 dirt
execute in minecraft:overworld run setblock 239 75 -36 coarse_dirt
execute in minecraft:overworld run fill 239 76 -36 239 144 -36 air
execute in minecraft:overworld run fill 239 58 -35 239 72 -35 stone
execute in minecraft:overworld run fill 239 73 -35 239 74 -35 dirt
execute in minecraft:overworld run setblock 239 75 -35 coarse_dirt
execute in minecraft:overworld run fill 239 76 -35 239 144 -35 air
execute in minecraft:overworld run fill 239 58 -34 239 72 -34 stone
execute in minecraft:overworld run fill 239 73 -34 239 74 -34 dirt
execute in minecraft:overworld run setblock 239 75 -34 coarse_dirt
execute in minecraft:overworld run fill 239 76 -34 239 144 -34 air
execute in minecraft:overworld run fill 239 58 -33 239 72 -33 stone
execute in minecraft:overworld run fill 239 73 -33 239 74 -33 dirt
execute in minecraft:overworld run setblock 239 75 -33 grass_block
execute in minecraft:overworld run fill 239 76 -33 239 144 -33 air
execute in minecraft:overworld run fill 239 58 -32 239 72 -32 stone
execute in minecraft:overworld run fill 239 73 -32 239 74 -32 dirt
execute in minecraft:overworld run setblock 239 75 -32 coarse_dirt
execute in minecraft:overworld run fill 239 76 -32 239 144 -32 air
execute in minecraft:overworld run fill 239 58 -31 239 72 -31 stone
execute in minecraft:overworld run fill 239 73 -31 239 74 -31 dirt
execute in minecraft:overworld run setblock 239 75 -31 coarse_dirt
execute in minecraft:overworld run fill 239 76 -31 239 144 -31 air
execute in minecraft:overworld run fill 239 58 -30 239 72 -30 stone
execute in minecraft:overworld run fill 239 73 -30 239 74 -30 dirt
execute in minecraft:overworld run setblock 239 75 -30 coarse_dirt
execute in minecraft:overworld run fill 239 76 -30 239 144 -30 air
execute in minecraft:overworld run fill 239 58 -29 239 71 -29 stone
execute in minecraft:overworld run fill 239 72 -29 239 73 -29 dirt
execute in minecraft:overworld run setblock 239 74 -29 coarse_dirt
execute in minecraft:overworld run fill 239 75 -29 239 144 -29 air
execute in minecraft:overworld run fill 239 58 -28 239 71 -28 stone
execute in minecraft:overworld run fill 239 72 -28 239 73 -28 dirt
execute in minecraft:overworld run setblock 239 74 -28 coarse_dirt
execute in minecraft:overworld run fill 239 75 -28 239 144 -28 air
execute in minecraft:overworld run fill 239 58 -27 239 71 -27 stone
execute in minecraft:overworld run fill 239 72 -27 239 73 -27 dirt
execute in minecraft:overworld run setblock 239 74 -27 coarse_dirt
execute in minecraft:overworld run fill 239 75 -27 239 144 -27 air
execute in minecraft:overworld run setblock 239 75 -27 grass
execute in minecraft:overworld run fill 239 58 -26 239 71 -26 stone
execute in minecraft:overworld run fill 239 72 -26 239 73 -26 dirt
execute in minecraft:overworld run setblock 239 74 -26 coarse_dirt
execute in minecraft:overworld run fill 239 75 -26 239 144 -26 air
execute in minecraft:overworld run fill 239 58 -25 239 70 -25 stone
execute in minecraft:overworld run fill 239 71 -25 239 72 -25 dirt
execute in minecraft:overworld run setblock 239 73 -25 coarse_dirt
execute in minecraft:overworld run fill 239 74 -25 239 144 -25 air
execute in minecraft:overworld run setblock 239 74 -25 grass
execute in minecraft:overworld run fill 239 58 -24 239 70 -24 stone
execute in minecraft:overworld run fill 239 71 -24 239 72 -24 dirt
execute in minecraft:overworld run setblock 239 73 -24 coarse_dirt
execute in minecraft:overworld run fill 239 74 -24 239 144 -24 air
execute in minecraft:overworld run fill 239 58 -23 239 69 -23 stone
execute in minecraft:overworld run fill 239 70 -23 239 71 -23 dirt
execute in minecraft:overworld run setblock 239 72 -23 coarse_dirt
execute in minecraft:overworld run fill 239 73 -23 239 144 -23 air
execute in minecraft:overworld run setblock 239 73 -23 grass
execute in minecraft:overworld run fill 239 58 -22 239 69 -22 stone
execute in minecraft:overworld run fill 239 70 -22 239 71 -22 dirt
execute in minecraft:overworld run setblock 239 72 -22 coarse_dirt
execute in minecraft:overworld run fill 239 73 -22 239 144 -22 air
execute in minecraft:overworld run fill 239 58 -21 239 68 -21 stone
execute in minecraft:overworld run fill 239 69 -21 239 70 -21 dirt
execute in minecraft:overworld run setblock 239 71 -21 coarse_dirt
execute in minecraft:overworld run fill 239 72 -21 239 144 -21 air
execute in minecraft:overworld run fill 239 58 -20 239 68 -20 stone
execute in minecraft:overworld run fill 239 69 -20 239 70 -20 dirt
execute in minecraft:overworld run setblock 239 71 -20 grass_block
execute in minecraft:overworld run fill 239 72 -20 239 144 -20 air
execute in minecraft:overworld run fill 239 58 -19 239 67 -19 stone
execute in minecraft:overworld run fill 239 68 -19 239 69 -19 dirt
schedule function blade_gallery:random/burned/part_48 1t replace
