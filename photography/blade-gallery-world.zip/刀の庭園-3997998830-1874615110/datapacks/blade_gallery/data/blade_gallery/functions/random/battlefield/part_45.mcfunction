execute in minecraft:overworld run setblock 365 69 -9 coarse_dirt
execute in minecraft:overworld run fill 365 70 -9 365 144 -9 air
execute in minecraft:overworld run setblock 365 70 -9 grass
execute in minecraft:overworld run fill 365 58 -8 365 65 -8 stone
execute in minecraft:overworld run fill 365 66 -8 365 67 -8 dirt
execute in minecraft:overworld run setblock 365 68 -8 coarse_dirt
execute in minecraft:overworld run fill 365 69 -8 365 144 -8 air
execute in minecraft:overworld run fill 365 58 -7 365 65 -7 stone
execute in minecraft:overworld run fill 365 66 -7 365 67 -7 dirt
execute in minecraft:overworld run setblock 365 68 -7 coarse_dirt
execute in minecraft:overworld run fill 365 69 -7 365 144 -7 air
execute in minecraft:overworld run fill 365 58 -6 365 65 -6 stone
execute in minecraft:overworld run fill 365 66 -6 365 67 -6 dirt
execute in minecraft:overworld run setblock 365 68 -6 grass_block
execute in minecraft:overworld run fill 365 69 -6 365 144 -6 air
execute in minecraft:overworld run fill 365 58 -5 365 65 -5 stone
execute in minecraft:overworld run fill 365 66 -5 365 67 -5 dirt
execute in minecraft:overworld run setblock 365 68 -5 coarse_dirt
execute in minecraft:overworld run fill 365 69 -5 365 144 -5 air
execute in minecraft:overworld run fill 365 58 -4 365 65 -4 stone
execute in minecraft:overworld run fill 365 66 -4 365 67 -4 dirt
execute in minecraft:overworld run setblock 365 68 -4 coarse_dirt
execute in minecraft:overworld run fill 365 69 -4 365 144 -4 air
execute in minecraft:overworld run setblock 365 69 -4 grass
execute in minecraft:overworld run fill 365 58 -3 365 65 -3 stone
execute in minecraft:overworld run fill 365 66 -3 365 67 -3 dirt
execute in minecraft:overworld run setblock 365 68 -3 coarse_dirt
execute in minecraft:overworld run fill 365 69 -3 365 144 -3 air
execute in minecraft:overworld run fill 365 58 -2 365 65 -2 stone
execute in minecraft:overworld run fill 365 66 -2 365 67 -2 dirt
execute in minecraft:overworld run setblock 365 68 -2 grass_block
execute in minecraft:overworld run fill 365 69 -2 365 144 -2 air
execute in minecraft:overworld run fill 365 58 -1 365 65 -1 stone
execute in minecraft:overworld run fill 365 66 -1 365 67 -1 dirt
execute in minecraft:overworld run setblock 365 68 -1 coarse_dirt
execute in minecraft:overworld run fill 365 69 -1 365 144 -1 air
execute in minecraft:overworld run fill 365 58 0 365 65 0 stone
execute in minecraft:overworld run fill 365 66 0 365 67 0 dirt
execute in minecraft:overworld run setblock 365 68 0 coarse_dirt
execute in minecraft:overworld run fill 365 69 0 365 144 0 air
execute in minecraft:overworld run fill 365 58 1 365 65 1 stone
execute in minecraft:overworld run fill 365 66 1 365 67 1 dirt
execute in minecraft:overworld run setblock 365 68 1 coarse_dirt
execute in minecraft:overworld run fill 365 69 1 365 144 1 air
execute in minecraft:overworld run fill 365 58 2 365 65 2 stone
execute in minecraft:overworld run fill 365 66 2 365 67 2 dirt
execute in minecraft:overworld run setblock 365 68 2 coarse_dirt
execute in minecraft:overworld run fill 365 69 2 365 144 2 air
execute in minecraft:overworld run fill 365 58 3 365 65 3 stone
execute in minecraft:overworld run fill 365 66 3 365 67 3 dirt
execute in minecraft:overworld run setblock 365 68 3 coarse_dirt
execute in minecraft:overworld run fill 365 69 3 365 144 3 air
execute in minecraft:overworld run fill 365 58 4 365 66 4 stone
execute in minecraft:overworld run fill 365 67 4 365 68 4 dirt
execute in minecraft:overworld run setblock 365 69 4 grass_block
execute in minecraft:overworld run fill 365 70 4 365 144 4 air
execute in minecraft:overworld run fill 365 58 5 365 66 5 stone
execute in minecraft:overworld run fill 365 67 5 365 68 5 dirt
execute in minecraft:overworld run setblock 365 69 5 grass_block
execute in minecraft:overworld run fill 365 70 5 365 144 5 air
execute in minecraft:overworld run fill 365 58 6 365 66 6 stone
execute in minecraft:overworld run fill 365 67 6 365 68 6 dirt
execute in minecraft:overworld run setblock 365 69 6 grass_block
execute in minecraft:overworld run fill 365 70 6 365 144 6 air
execute in minecraft:overworld run fill 365 58 7 365 66 7 stone
execute in minecraft:overworld run fill 365 67 7 365 68 7 dirt
execute in minecraft:overworld run setblock 365 69 7 coarse_dirt
execute in minecraft:overworld run fill 365 70 7 365 144 7 air
execute in minecraft:overworld run fill 365 58 8 365 66 8 stone
execute in minecraft:overworld run fill 365 67 8 365 68 8 dirt
execute in minecraft:overworld run setblock 365 69 8 coarse_dirt
execute in minecraft:overworld run fill 365 70 8 365 144 8 air
execute in minecraft:overworld run fill 365 58 9 365 67 9 stone
execute in minecraft:overworld run fill 365 68 9 365 69 9 dirt
execute in minecraft:overworld run setblock 365 70 9 coarse_dirt
execute in minecraft:overworld run fill 365 71 9 365 144 9 air
execute in minecraft:overworld run fill 365 58 10 365 67 10 stone
execute in minecraft:overworld run fill 365 68 10 365 69 10 dirt
execute in minecraft:overworld run setblock 365 70 10 coarse_dirt
execute in minecraft:overworld run fill 365 71 10 365 144 10 air
execute in minecraft:overworld run fill 365 58 11 365 67 11 stone
execute in minecraft:overworld run fill 365 68 11 365 69 11 dirt
execute in minecraft:overworld run setblock 365 70 11 grass_block
execute in minecraft:overworld run fill 365 71 11 365 144 11 air
execute in minecraft:overworld run fill 365 58 12 365 67 12 stone
execute in minecraft:overworld run fill 365 68 12 365 69 12 dirt
execute in minecraft:overworld run setblock 365 70 12 coarse_dirt
execute in minecraft:overworld run fill 365 71 12 365 144 12 air
execute in minecraft:overworld run fill 365 58 13 365 67 13 stone
execute in minecraft:overworld run fill 365 68 13 365 69 13 dirt
execute in minecraft:overworld run setblock 365 70 13 coarse_dirt
execute in minecraft:overworld run fill 365 71 13 365 144 13 air
execute in minecraft:overworld run fill 365 58 14 365 68 14 stone
execute in minecraft:overworld run fill 365 69 14 365 70 14 dirt
execute in minecraft:overworld run setblock 365 71 14 coarse_dirt
execute in minecraft:overworld run fill 365 72 14 365 144 14 air
execute in minecraft:overworld run fill 365 58 15 365 68 15 stone
execute in minecraft:overworld run fill 365 69 15 365 70 15 dirt
execute in minecraft:overworld run setblock 365 71 15 coarse_dirt
execute in minecraft:overworld run fill 365 72 15 365 144 15 air
execute in minecraft:overworld run setblock 365 72 15 grass
execute in minecraft:overworld run fill 365 58 16 365 68 16 stone
execute in minecraft:overworld run fill 365 69 16 365 70 16 dirt
execute in minecraft:overworld run setblock 365 71 16 coarse_dirt
execute in minecraft:overworld run fill 365 72 16 365 144 16 air
execute in minecraft:overworld run fill 365 58 17 365 68 17 stone
execute in minecraft:overworld run fill 365 69 17 365 70 17 dirt
execute in minecraft:overworld run setblock 365 71 17 coarse_dirt
execute in minecraft:overworld run fill 365 72 17 365 144 17 air
execute in minecraft:overworld run setblock 365 72 17 grass
execute in minecraft:overworld run fill 365 58 18 365 68 18 stone
execute in minecraft:overworld run fill 365 69 18 365 70 18 dirt
execute in minecraft:overworld run setblock 365 71 18 coarse_dirt
execute in minecraft:overworld run fill 365 72 18 365 144 18 air
execute in minecraft:overworld run setblock 365 72 18 grass
execute in minecraft:overworld run fill 365 58 19 365 69 19 stone
execute in minecraft:overworld run fill 365 70 19 365 71 19 dirt
execute in minecraft:overworld run setblock 365 72 19 coarse_dirt
execute in minecraft:overworld run fill 365 73 19 365 144 19 air
execute in minecraft:overworld run fill 365 58 20 365 69 20 stone
execute in minecraft:overworld run fill 365 70 20 365 71 20 dirt
execute in minecraft:overworld run setblock 365 72 20 coarse_dirt
execute in minecraft:overworld run fill 365 73 20 365 144 20 air
execute in minecraft:overworld run fill 365 58 21 365 69 21 stone
execute in minecraft:overworld run fill 365 70 21 365 71 21 dirt
execute in minecraft:overworld run setblock 365 72 21 coarse_dirt
execute in minecraft:overworld run fill 365 73 21 365 144 21 air
execute in minecraft:overworld run fill 365 58 22 365 69 22 stone
execute in minecraft:overworld run fill 365 70 22 365 71 22 dirt
execute in minecraft:overworld run setblock 365 72 22 coarse_dirt
execute in minecraft:overworld run fill 365 73 22 365 144 22 air
execute in minecraft:overworld run fill 365 58 23 365 69 23 stone
execute in minecraft:overworld run fill 365 70 23 365 71 23 dirt
execute in minecraft:overworld run setblock 365 72 23 coarse_dirt
execute in minecraft:overworld run fill 365 73 23 365 144 23 air
execute in minecraft:overworld run setblock 365 73 23 grass
execute in minecraft:overworld run fill 365 58 24 365 69 24 stone
execute in minecraft:overworld run fill 365 70 24 365 71 24 dirt
execute in minecraft:overworld run setblock 365 72 24 coarse_dirt
execute in minecraft:overworld run fill 365 73 24 365 144 24 air
execute in minecraft:overworld run setblock 365 73 24 mossy_cobblestone
execute in minecraft:overworld run fill 365 58 25 365 68 25 stone
execute in minecraft:overworld run fill 365 69 25 365 70 25 dirt
execute in minecraft:overworld run setblock 365 71 25 coarse_dirt
execute in minecraft:overworld run fill 365 72 25 365 144 25 air
execute in minecraft:overworld run fill 365 58 26 365 68 26 stone
execute in minecraft:overworld run fill 365 69 26 365 70 26 dirt
execute in minecraft:overworld run setblock 365 71 26 coarse_dirt
execute in minecraft:overworld run fill 365 72 26 365 144 26 air
execute in minecraft:overworld run fill 365 58 27 365 68 27 stone
execute in minecraft:overworld run fill 365 69 27 365 70 27 dirt
execute in minecraft:overworld run setblock 365 71 27 coarse_dirt
execute in minecraft:overworld run fill 365 72 27 365 144 27 air
execute in minecraft:overworld run fill 365 58 28 365 69 28 stone
execute in minecraft:overworld run fill 365 70 28 365 71 28 dirt
execute in minecraft:overworld run setblock 365 72 28 coarse_dirt
execute in minecraft:overworld run fill 365 73 28 365 144 28 air
execute in minecraft:overworld run fill 365 58 29 365 69 29 stone
execute in minecraft:overworld run fill 365 70 29 365 71 29 dirt
execute in minecraft:overworld run setblock 365 72 29 coarse_dirt
execute in minecraft:overworld run fill 365 73 29 365 144 29 air
execute in minecraft:overworld run fill 365 58 30 365 69 30 stone
execute in minecraft:overworld run fill 365 70 30 365 71 30 dirt
execute in minecraft:overworld run setblock 365 72 30 coarse_dirt
execute in minecraft:overworld run fill 365 73 30 365 144 30 air
execute in minecraft:overworld run fill 365 58 31 365 69 31 stone
execute in minecraft:overworld run fill 365 70 31 365 71 31 dirt
execute in minecraft:overworld run setblock 365 72 31 coarse_dirt
execute in minecraft:overworld run fill 365 73 31 365 144 31 air
execute in minecraft:overworld run fill 365 58 32 365 69 32 stone
execute in minecraft:overworld run fill 365 70 32 365 71 32 dirt
execute in minecraft:overworld run setblock 365 72 32 coarse_dirt
execute in minecraft:overworld run fill 365 73 32 365 144 32 air
execute in minecraft:overworld run fill 365 58 33 365 70 33 stone
execute in minecraft:overworld run fill 365 71 33 365 72 33 dirt
execute in minecraft:overworld run setblock 365 73 33 coarse_dirt
execute in minecraft:overworld run fill 365 74 33 365 144 33 air
execute in minecraft:overworld run fill 365 58 34 365 70 34 stone
execute in minecraft:overworld run fill 365 71 34 365 72 34 dirt
execute in minecraft:overworld run setblock 365 73 34 coarse_dirt
execute in minecraft:overworld run fill 365 74 34 365 144 34 air
execute in minecraft:overworld run fill 365 58 35 365 70 35 stone
execute in minecraft:overworld run fill 365 71 35 365 72 35 dirt
execute in minecraft:overworld run setblock 365 73 35 coarse_dirt
execute in minecraft:overworld run fill 365 74 35 365 144 35 air
execute in minecraft:overworld run fill 365 58 36 365 70 36 stone
execute in minecraft:overworld run fill 365 71 36 365 72 36 dirt
execute in minecraft:overworld run setblock 365 73 36 coarse_dirt
execute in minecraft:overworld run fill 365 74 36 365 144 36 air
execute in minecraft:overworld run fill 365 58 37 365 70 37 stone
execute in minecraft:overworld run fill 365 71 37 365 72 37 dirt
execute in minecraft:overworld run setblock 365 73 37 coarse_dirt
execute in minecraft:overworld run fill 365 74 37 365 144 37 air
execute in minecraft:overworld run fill 365 58 38 365 70 38 stone
execute in minecraft:overworld run fill 365 71 38 365 72 38 dirt
execute in minecraft:overworld run setblock 365 73 38 coarse_dirt
execute in minecraft:overworld run fill 365 74 38 365 144 38 air
execute in minecraft:overworld run setblock 365 74 38 grass
execute in minecraft:overworld run fill 365 58 39 365 69 39 stone
execute in minecraft:overworld run fill 365 70 39 365 71 39 dirt
execute in minecraft:overworld run setblock 365 72 39 grass_block
execute in minecraft:overworld run fill 365 73 39 365 144 39 air
execute in minecraft:overworld run fill 365 58 40 365 68 40 stone
execute in minecraft:overworld run fill 365 69 40 365 70 40 dirt
execute in minecraft:overworld run setblock 365 71 40 coarse_dirt
execute in minecraft:overworld run fill 365 72 40 365 144 40 air
execute in minecraft:overworld run fill 365 58 41 365 67 41 stone
execute in minecraft:overworld run fill 365 68 41 365 69 41 dirt
execute in minecraft:overworld run setblock 365 70 41 grass_block
execute in minecraft:overworld run fill 365 71 41 365 144 41 air
execute in minecraft:overworld run setblock 365 71 41 grass
execute in minecraft:overworld run fill 365 58 42 365 66 42 stone
execute in minecraft:overworld run fill 365 67 42 365 68 42 dirt
execute in minecraft:overworld run setblock 365 69 42 grass_block
execute in minecraft:overworld run fill 365 70 42 365 144 42 air
execute in minecraft:overworld run fill 365 58 43 365 65 43 stone
execute in minecraft:overworld run fill 365 66 43 365 67 43 dirt
execute in minecraft:overworld run setblock 365 68 43 grass_block
execute in minecraft:overworld run fill 365 69 43 365 144 43 air
execute in minecraft:overworld run fill 365 58 44 365 65 44 stone
execute in minecraft:overworld run fill 365 66 44 365 67 44 dirt
execute in minecraft:overworld run setblock 365 68 44 coarse_dirt
execute in minecraft:overworld run fill 365 69 44 365 144 44 air
execute in minecraft:overworld run fill 365 58 45 365 64 45 stone
execute in minecraft:overworld run fill 365 65 45 365 66 45 dirt
execute in minecraft:overworld run setblock 365 67 45 grass_block
execute in minecraft:overworld run fill 365 68 45 365 144 45 air
execute in minecraft:overworld run fill 365 58 46 365 63 46 stone
execute in minecraft:overworld run fill 365 64 46 365 65 46 dirt
execute in minecraft:overworld run setblock 365 66 46 coarse_dirt
execute in minecraft:overworld run fill 365 67 46 365 144 46 air
execute in minecraft:overworld run fill 365 58 47 365 62 47 stone
execute in minecraft:overworld run fill 365 63 47 365 64 47 dirt
execute in minecraft:overworld run setblock 365 65 47 grass_block
execute in minecraft:overworld run fill 365 66 47 365 144 47 air
execute in minecraft:overworld run fill 366 58 -48 366 61 -48 stone
execute in minecraft:overworld run fill 366 62 -48 366 63 -48 dirt
execute in minecraft:overworld run setblock 366 64 -48 grass_block
execute in minecraft:overworld run fill 366 65 -48 366 144 -48 air
execute in minecraft:overworld run fill 366 58 -47 366 62 -47 stone
execute in minecraft:overworld run fill 366 63 -47 366 64 -47 dirt
execute in minecraft:overworld run setblock 366 65 -47 grass_block
execute in minecraft:overworld run fill 366 66 -47 366 144 -47 air
execute in minecraft:overworld run fill 366 58 -46 366 64 -46 stone
execute in minecraft:overworld run fill 366 65 -46 366 66 -46 dirt
execute in minecraft:overworld run setblock 366 67 -46 grass_block
execute in minecraft:overworld run fill 366 68 -46 366 144 -46 air
execute in minecraft:overworld run fill 366 58 -45 366 65 -45 stone
execute in minecraft:overworld run fill 366 66 -45 366 67 -45 dirt
execute in minecraft:overworld run setblock 366 68 -45 coarse_dirt
execute in minecraft:overworld run fill 366 69 -45 366 144 -45 air
execute in minecraft:overworld run fill 366 58 -44 366 67 -44 stone
execute in minecraft:overworld run fill 366 68 -44 366 69 -44 dirt
execute in minecraft:overworld run setblock 366 70 -44 grass_block
execute in minecraft:overworld run fill 366 71 -44 366 144 -44 air
execute in minecraft:overworld run fill 366 58 -43 366 68 -43 stone
schedule function blade_gallery:random/battlefield/part_46 1t replace
