execute in minecraft:overworld run fill 412 58 40 412 66 40 stone
execute in minecraft:overworld run fill 412 67 40 412 68 40 dirt
execute in minecraft:overworld run setblock 412 69 40 coarse_dirt
execute in minecraft:overworld run fill 412 70 40 412 144 40 air
execute in minecraft:overworld run fill 412 58 41 412 65 41 stone
execute in minecraft:overworld run fill 412 66 41 412 67 41 dirt
execute in minecraft:overworld run setblock 412 68 41 coarse_dirt
execute in minecraft:overworld run fill 412 69 41 412 144 41 air
execute in minecraft:overworld run fill 412 58 42 412 64 42 stone
execute in minecraft:overworld run fill 412 65 42 412 66 42 dirt
execute in minecraft:overworld run setblock 412 67 42 coarse_dirt
execute in minecraft:overworld run fill 412 68 42 412 144 42 air
execute in minecraft:overworld run fill 412 58 43 412 64 43 stone
execute in minecraft:overworld run fill 412 65 43 412 66 43 dirt
execute in minecraft:overworld run setblock 412 67 43 coarse_dirt
execute in minecraft:overworld run fill 412 68 43 412 144 43 air
execute in minecraft:overworld run fill 412 58 44 412 63 44 stone
execute in minecraft:overworld run fill 412 64 44 412 65 44 dirt
execute in minecraft:overworld run setblock 412 66 44 coarse_dirt
execute in minecraft:overworld run fill 412 67 44 412 144 44 air
execute in minecraft:overworld run fill 412 58 45 412 62 45 stone
execute in minecraft:overworld run fill 412 63 45 412 64 45 dirt
execute in minecraft:overworld run setblock 412 65 45 coarse_dirt
execute in minecraft:overworld run fill 412 66 45 412 144 45 air
execute in minecraft:overworld run fill 412 58 46 412 62 46 stone
execute in minecraft:overworld run fill 412 63 46 412 64 46 dirt
execute in minecraft:overworld run setblock 412 65 46 coarse_dirt
execute in minecraft:overworld run fill 412 66 46 412 144 46 air
execute in minecraft:overworld run fill 412 58 47 412 61 47 stone
execute in minecraft:overworld run fill 412 62 47 412 63 47 dirt
execute in minecraft:overworld run setblock 412 64 47 grass_block
execute in minecraft:overworld run fill 412 65 47 412 144 47 air
execute in minecraft:overworld run fill 413 58 -48 413 61 -48 stone
execute in minecraft:overworld run fill 413 62 -48 413 63 -48 dirt
execute in minecraft:overworld run setblock 413 64 -48 coarse_dirt
execute in minecraft:overworld run fill 413 65 -48 413 144 -48 air
execute in minecraft:overworld run fill 413 58 -47 413 63 -47 stone
execute in minecraft:overworld run fill 413 64 -47 413 65 -47 dirt
execute in minecraft:overworld run setblock 413 66 -47 coarse_dirt
execute in minecraft:overworld run fill 413 67 -47 413 144 -47 air
execute in minecraft:overworld run fill 413 58 -46 413 64 -46 stone
execute in minecraft:overworld run fill 413 65 -46 413 66 -46 dirt
execute in minecraft:overworld run setblock 413 67 -46 grass_block
execute in minecraft:overworld run fill 413 68 -46 413 144 -46 air
execute in minecraft:overworld run fill 413 58 -45 413 66 -45 stone
execute in minecraft:overworld run fill 413 67 -45 413 68 -45 dirt
execute in minecraft:overworld run setblock 413 69 -45 coarse_dirt
execute in minecraft:overworld run fill 413 70 -45 413 144 -45 air
execute in minecraft:overworld run fill 413 58 -44 413 67 -44 stone
execute in minecraft:overworld run fill 413 68 -44 413 69 -44 dirt
execute in minecraft:overworld run setblock 413 70 -44 coarse_dirt
execute in minecraft:overworld run fill 413 71 -44 413 144 -44 air
execute in minecraft:overworld run fill 413 58 -43 413 69 -43 stone
execute in minecraft:overworld run fill 413 70 -43 413 71 -43 dirt
execute in minecraft:overworld run setblock 413 72 -43 coarse_dirt
execute in minecraft:overworld run fill 413 73 -43 413 144 -43 air
execute in minecraft:overworld run fill 413 58 -42 413 70 -42 stone
execute in minecraft:overworld run fill 413 71 -42 413 72 -42 dirt
execute in minecraft:overworld run setblock 413 73 -42 grass_block
execute in minecraft:overworld run fill 413 74 -42 413 144 -42 air
execute in minecraft:overworld run fill 413 58 -41 413 71 -41 stone
execute in minecraft:overworld run fill 413 72 -41 413 73 -41 dirt
execute in minecraft:overworld run setblock 413 74 -41 grass_block
execute in minecraft:overworld run fill 413 75 -41 413 144 -41 air
execute in minecraft:overworld run fill 413 58 -40 413 73 -40 stone
execute in minecraft:overworld run fill 413 74 -40 413 75 -40 dirt
execute in minecraft:overworld run setblock 413 76 -40 coarse_dirt
execute in minecraft:overworld run fill 413 77 -40 413 144 -40 air
execute in minecraft:overworld run fill 413 58 -39 413 74 -39 stone
execute in minecraft:overworld run fill 413 75 -39 413 76 -39 dirt
execute in minecraft:overworld run setblock 413 77 -39 coarse_dirt
execute in minecraft:overworld run fill 413 78 -39 413 144 -39 air
execute in minecraft:overworld run fill 413 58 -38 413 75 -38 stone
execute in minecraft:overworld run fill 413 76 -38 413 77 -38 dirt
execute in minecraft:overworld run setblock 413 78 -38 grass_block
execute in minecraft:overworld run fill 413 79 -38 413 144 -38 air
execute in minecraft:overworld run fill 413 58 -37 413 75 -37 stone
execute in minecraft:overworld run fill 413 76 -37 413 77 -37 dirt
execute in minecraft:overworld run setblock 413 78 -37 coarse_dirt
execute in minecraft:overworld run fill 413 79 -37 413 144 -37 air
execute in minecraft:overworld run fill 413 58 -36 413 74 -36 stone
execute in minecraft:overworld run fill 413 75 -36 413 76 -36 dirt
execute in minecraft:overworld run setblock 413 77 -36 coarse_dirt
execute in minecraft:overworld run fill 413 78 -36 413 144 -36 air
execute in minecraft:overworld run fill 413 58 -35 413 74 -35 stone
execute in minecraft:overworld run fill 413 75 -35 413 76 -35 dirt
execute in minecraft:overworld run setblock 413 77 -35 coarse_dirt
execute in minecraft:overworld run fill 413 78 -35 413 144 -35 air
execute in minecraft:overworld run fill 413 58 -34 413 73 -34 stone
execute in minecraft:overworld run fill 413 74 -34 413 75 -34 dirt
execute in minecraft:overworld run setblock 413 76 -34 coarse_dirt
execute in minecraft:overworld run fill 413 77 -34 413 144 -34 air
execute in minecraft:overworld run fill 413 58 -33 413 73 -33 stone
execute in minecraft:overworld run fill 413 74 -33 413 75 -33 dirt
execute in minecraft:overworld run setblock 413 76 -33 coarse_dirt
execute in minecraft:overworld run fill 413 77 -33 413 144 -33 air
execute in minecraft:overworld run fill 413 58 -32 413 73 -32 stone
execute in minecraft:overworld run fill 413 74 -32 413 75 -32 dirt
execute in minecraft:overworld run setblock 413 76 -32 coarse_dirt
execute in minecraft:overworld run fill 413 77 -32 413 144 -32 air
execute in minecraft:overworld run fill 413 58 -31 413 72 -31 stone
execute in minecraft:overworld run fill 413 73 -31 413 74 -31 dirt
execute in minecraft:overworld run setblock 413 75 -31 grass_block
execute in minecraft:overworld run fill 413 76 -31 413 144 -31 air
execute in minecraft:overworld run fill 413 58 -30 413 72 -30 stone
execute in minecraft:overworld run fill 413 73 -30 413 74 -30 dirt
execute in minecraft:overworld run setblock 413 75 -30 grass_block
execute in minecraft:overworld run fill 413 76 -30 413 144 -30 air
execute in minecraft:overworld run fill 413 58 -29 413 71 -29 stone
execute in minecraft:overworld run fill 413 72 -29 413 73 -29 dirt
execute in minecraft:overworld run setblock 413 74 -29 coarse_dirt
execute in minecraft:overworld run fill 413 75 -29 413 144 -29 air
execute in minecraft:overworld run fill 413 58 -28 413 71 -28 stone
execute in minecraft:overworld run fill 413 72 -28 413 73 -28 dirt
execute in minecraft:overworld run setblock 413 74 -28 coarse_dirt
execute in minecraft:overworld run fill 413 75 -28 413 144 -28 air
execute in minecraft:overworld run fill 413 58 -27 413 71 -27 stone
execute in minecraft:overworld run fill 413 72 -27 413 73 -27 dirt
execute in minecraft:overworld run setblock 413 74 -27 grass_block
execute in minecraft:overworld run fill 413 75 -27 413 144 -27 air
execute in minecraft:overworld run fill 413 58 -26 413 70 -26 stone
execute in minecraft:overworld run fill 413 71 -26 413 72 -26 dirt
execute in minecraft:overworld run setblock 413 73 -26 coarse_dirt
execute in minecraft:overworld run fill 413 74 -26 413 144 -26 air
execute in minecraft:overworld run fill 413 58 -25 413 70 -25 stone
execute in minecraft:overworld run fill 413 71 -25 413 72 -25 dirt
execute in minecraft:overworld run setblock 413 73 -25 coarse_dirt
execute in minecraft:overworld run fill 413 74 -25 413 144 -25 air
execute in minecraft:overworld run fill 413 58 -24 413 70 -24 stone
execute in minecraft:overworld run fill 413 71 -24 413 72 -24 dirt
execute in minecraft:overworld run setblock 413 73 -24 coarse_dirt
execute in minecraft:overworld run fill 413 74 -24 413 144 -24 air
execute in minecraft:overworld run fill 413 58 -23 413 69 -23 stone
execute in minecraft:overworld run fill 413 70 -23 413 71 -23 dirt
execute in minecraft:overworld run setblock 413 72 -23 grass_block
execute in minecraft:overworld run fill 413 73 -23 413 144 -23 air
execute in minecraft:overworld run fill 413 58 -22 413 69 -22 stone
execute in minecraft:overworld run fill 413 70 -22 413 71 -22 dirt
execute in minecraft:overworld run setblock 413 72 -22 coarse_dirt
execute in minecraft:overworld run fill 413 73 -22 413 144 -22 air
execute in minecraft:overworld run fill 413 58 -21 413 69 -21 stone
execute in minecraft:overworld run fill 413 70 -21 413 71 -21 dirt
execute in minecraft:overworld run setblock 413 72 -21 grass_block
execute in minecraft:overworld run fill 413 73 -21 413 144 -21 air
execute in minecraft:overworld run fill 413 58 -20 413 69 -20 stone
execute in minecraft:overworld run fill 413 70 -20 413 71 -20 dirt
execute in minecraft:overworld run setblock 413 72 -20 grass_block
execute in minecraft:overworld run fill 413 73 -20 413 144 -20 air
execute in minecraft:overworld run setblock 413 73 -20 grass
execute in minecraft:overworld run fill 413 58 -19 413 68 -19 stone
execute in minecraft:overworld run fill 413 69 -19 413 70 -19 dirt
execute in minecraft:overworld run setblock 413 71 -19 grass_block
execute in minecraft:overworld run fill 413 72 -19 413 144 -19 air
execute in minecraft:overworld run fill 413 58 -18 413 68 -18 stone
execute in minecraft:overworld run fill 413 69 -18 413 70 -18 dirt
execute in minecraft:overworld run setblock 413 71 -18 coarse_dirt
execute in minecraft:overworld run fill 413 72 -18 413 144 -18 air
execute in minecraft:overworld run setblock 413 72 -18 mossy_cobblestone
execute in minecraft:overworld run fill 413 58 -17 413 67 -17 stone
execute in minecraft:overworld run fill 413 68 -17 413 69 -17 dirt
execute in minecraft:overworld run setblock 413 70 -17 coarse_dirt
execute in minecraft:overworld run fill 413 71 -17 413 144 -17 air
execute in minecraft:overworld run fill 413 58 -16 413 67 -16 stone
execute in minecraft:overworld run fill 413 68 -16 413 69 -16 dirt
execute in minecraft:overworld run setblock 413 70 -16 coarse_dirt
execute in minecraft:overworld run fill 413 71 -16 413 144 -16 air
execute in minecraft:overworld run fill 413 58 -15 413 66 -15 stone
execute in minecraft:overworld run fill 413 67 -15 413 68 -15 dirt
execute in minecraft:overworld run setblock 413 69 -15 grass_block
execute in minecraft:overworld run fill 413 70 -15 413 144 -15 air
execute in minecraft:overworld run fill 413 58 -14 413 66 -14 stone
execute in minecraft:overworld run fill 413 67 -14 413 68 -14 dirt
execute in minecraft:overworld run setblock 413 69 -14 grass_block
execute in minecraft:overworld run fill 413 70 -14 413 144 -14 air
execute in minecraft:overworld run fill 413 58 -13 413 65 -13 stone
execute in minecraft:overworld run fill 413 66 -13 413 67 -13 dirt
execute in minecraft:overworld run setblock 413 68 -13 grass_block
execute in minecraft:overworld run fill 413 69 -13 413 144 -13 air
execute in minecraft:overworld run fill 413 58 -12 413 65 -12 stone
execute in minecraft:overworld run fill 413 66 -12 413 67 -12 dirt
execute in minecraft:overworld run setblock 413 68 -12 coarse_dirt
execute in minecraft:overworld run fill 413 69 -12 413 144 -12 air
execute in minecraft:overworld run fill 413 58 -11 413 65 -11 stone
execute in minecraft:overworld run fill 413 66 -11 413 67 -11 dirt
execute in minecraft:overworld run setblock 413 68 -11 coarse_dirt
execute in minecraft:overworld run fill 413 69 -11 413 144 -11 air
execute in minecraft:overworld run fill 413 58 -10 413 65 -10 stone
execute in minecraft:overworld run fill 413 66 -10 413 67 -10 dirt
execute in minecraft:overworld run setblock 413 68 -10 coarse_dirt
execute in minecraft:overworld run fill 413 69 -10 413 144 -10 air
execute in minecraft:overworld run fill 413 58 -9 413 65 -9 stone
execute in minecraft:overworld run fill 413 66 -9 413 67 -9 dirt
execute in minecraft:overworld run setblock 413 68 -9 grass_block
execute in minecraft:overworld run fill 413 69 -9 413 144 -9 air
execute in minecraft:overworld run fill 413 58 -8 413 64 -8 stone
execute in minecraft:overworld run fill 413 65 -8 413 66 -8 dirt
execute in minecraft:overworld run setblock 413 67 -8 coarse_dirt
execute in minecraft:overworld run fill 413 68 -8 413 144 -8 air
execute in minecraft:overworld run setblock 413 68 -8 grass
execute in minecraft:overworld run fill 413 58 -7 413 64 -7 stone
execute in minecraft:overworld run fill 413 65 -7 413 66 -7 dirt
execute in minecraft:overworld run setblock 413 67 -7 grass_block
execute in minecraft:overworld run fill 413 68 -7 413 144 -7 air
execute in minecraft:overworld run setblock 413 68 -7 grass
execute in minecraft:overworld run fill 413 58 -6 413 64 -6 stone
execute in minecraft:overworld run fill 413 65 -6 413 66 -6 dirt
execute in minecraft:overworld run setblock 413 67 -6 grass_block
execute in minecraft:overworld run fill 413 68 -6 413 144 -6 air
execute in minecraft:overworld run fill 413 58 -5 413 64 -5 stone
execute in minecraft:overworld run fill 413 65 -5 413 66 -5 dirt
execute in minecraft:overworld run setblock 413 67 -5 grass_block
execute in minecraft:overworld run fill 413 68 -5 413 144 -5 air
execute in minecraft:overworld run fill 413 58 -4 413 63 -4 stone
execute in minecraft:overworld run fill 413 64 -4 413 65 -4 dirt
execute in minecraft:overworld run setblock 413 66 -4 coarse_dirt
execute in minecraft:overworld run fill 413 67 -4 413 144 -4 air
execute in minecraft:overworld run fill 413 58 -3 413 63 -3 stone
execute in minecraft:overworld run fill 413 64 -3 413 65 -3 dirt
execute in minecraft:overworld run setblock 413 66 -3 coarse_dirt
execute in minecraft:overworld run fill 413 67 -3 413 144 -3 air
execute in minecraft:overworld run fill 413 58 -2 413 63 -2 stone
execute in minecraft:overworld run fill 413 64 -2 413 65 -2 dirt
execute in minecraft:overworld run setblock 413 66 -2 grass_block
execute in minecraft:overworld run fill 413 67 -2 413 144 -2 air
execute in minecraft:overworld run fill 413 58 -1 413 63 -1 stone
execute in minecraft:overworld run fill 413 64 -1 413 65 -1 dirt
execute in minecraft:overworld run setblock 413 66 -1 coarse_dirt
execute in minecraft:overworld run fill 413 67 -1 413 144 -1 air
execute in minecraft:overworld run fill 413 58 0 413 63 0 stone
execute in minecraft:overworld run fill 413 64 0 413 65 0 dirt
execute in minecraft:overworld run setblock 413 66 0 grass_block
execute in minecraft:overworld run fill 413 67 0 413 144 0 air
execute in minecraft:overworld run fill 413 58 1 413 63 1 stone
execute in minecraft:overworld run fill 413 64 1 413 65 1 dirt
execute in minecraft:overworld run setblock 413 66 1 grass_block
execute in minecraft:overworld run fill 413 67 1 413 144 1 air
execute in minecraft:overworld run fill 413 58 2 413 63 2 stone
execute in minecraft:overworld run fill 413 64 2 413 65 2 dirt
execute in minecraft:overworld run setblock 413 66 2 coarse_dirt
execute in minecraft:overworld run fill 413 67 2 413 144 2 air
execute in minecraft:overworld run fill 413 58 3 413 63 3 stone
execute in minecraft:overworld run fill 413 64 3 413 65 3 dirt
execute in minecraft:overworld run setblock 413 66 3 coarse_dirt
execute in minecraft:overworld run fill 413 67 3 413 144 3 air
execute in minecraft:overworld run fill 413 58 4 413 63 4 stone
execute in minecraft:overworld run fill 413 64 4 413 65 4 dirt
execute in minecraft:overworld run setblock 413 66 4 coarse_dirt
execute in minecraft:overworld run fill 413 67 4 413 144 4 air
execute in minecraft:overworld run fill 413 58 5 413 64 5 stone
execute in minecraft:overworld run fill 413 65 5 413 66 5 dirt
execute in minecraft:overworld run setblock 413 67 5 coarse_dirt
execute in minecraft:overworld run fill 413 68 5 413 144 5 air
execute in minecraft:overworld run fill 413 58 6 413 64 6 stone
execute in minecraft:overworld run fill 413 65 6 413 66 6 dirt
execute in minecraft:overworld run setblock 413 67 6 coarse_dirt
execute in minecraft:overworld run fill 413 68 6 413 144 6 air
schedule function blade_gallery:random/battlefield/part_122 1t replace
