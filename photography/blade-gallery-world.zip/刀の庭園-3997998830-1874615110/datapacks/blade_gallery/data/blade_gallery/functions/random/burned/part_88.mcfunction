execute in minecraft:overworld run fill 264 58 -42 264 72 -42 stone
execute in minecraft:overworld run fill 264 73 -42 264 74 -42 dirt
execute in minecraft:overworld run setblock 264 75 -42 coarse_dirt
execute in minecraft:overworld run fill 264 76 -42 264 144 -42 air
execute in minecraft:overworld run fill 264 58 -41 264 73 -41 stone
execute in minecraft:overworld run fill 264 74 -41 264 75 -41 dirt
execute in minecraft:overworld run setblock 264 76 -41 grass_block
execute in minecraft:overworld run fill 264 77 -41 264 144 -41 air
execute in minecraft:overworld run fill 264 58 -40 264 75 -40 stone
execute in minecraft:overworld run fill 264 76 -40 264 77 -40 dirt
execute in minecraft:overworld run setblock 264 78 -40 coarse_dirt
execute in minecraft:overworld run fill 264 79 -40 264 144 -40 air
execute in minecraft:overworld run fill 264 58 -39 264 77 -39 stone
execute in minecraft:overworld run fill 264 78 -39 264 79 -39 dirt
execute in minecraft:overworld run setblock 264 80 -39 grass_block
execute in minecraft:overworld run fill 264 81 -39 264 144 -39 air
execute in minecraft:overworld run fill 264 58 -38 264 78 -38 stone
execute in minecraft:overworld run fill 264 79 -38 264 80 -38 dirt
execute in minecraft:overworld run setblock 264 81 -38 coarse_dirt
execute in minecraft:overworld run fill 264 82 -38 264 144 -38 air
execute in minecraft:overworld run fill 264 58 -37 264 78 -37 stone
execute in minecraft:overworld run fill 264 79 -37 264 80 -37 dirt
execute in minecraft:overworld run setblock 264 81 -37 coarse_dirt
execute in minecraft:overworld run fill 264 82 -37 264 144 -37 air
execute in minecraft:overworld run fill 264 58 -36 264 78 -36 stone
execute in minecraft:overworld run fill 264 79 -36 264 80 -36 dirt
execute in minecraft:overworld run setblock 264 81 -36 grass_block
execute in minecraft:overworld run fill 264 82 -36 264 144 -36 air
execute in minecraft:overworld run setblock 264 82 -36 grass
execute in minecraft:overworld run fill 264 58 -35 264 77 -35 stone
execute in minecraft:overworld run fill 264 78 -35 264 79 -35 dirt
execute in minecraft:overworld run setblock 264 80 -35 coarse_dirt
execute in minecraft:overworld run fill 264 81 -35 264 144 -35 air
execute in minecraft:overworld run fill 264 58 -34 264 77 -34 stone
execute in minecraft:overworld run fill 264 78 -34 264 79 -34 dirt
execute in minecraft:overworld run setblock 264 80 -34 coarse_dirt
execute in minecraft:overworld run fill 264 81 -34 264 144 -34 air
execute in minecraft:overworld run fill 264 58 -33 264 77 -33 stone
execute in minecraft:overworld run fill 264 78 -33 264 79 -33 dirt
execute in minecraft:overworld run setblock 264 80 -33 coarse_dirt
execute in minecraft:overworld run fill 264 81 -33 264 144 -33 air
execute in minecraft:overworld run fill 264 58 -32 264 77 -32 stone
execute in minecraft:overworld run fill 264 78 -32 264 79 -32 dirt
execute in minecraft:overworld run setblock 264 80 -32 coarse_dirt
execute in minecraft:overworld run fill 264 81 -32 264 144 -32 air
execute in minecraft:overworld run fill 264 58 -31 264 77 -31 stone
execute in minecraft:overworld run fill 264 78 -31 264 79 -31 dirt
execute in minecraft:overworld run setblock 264 80 -31 coarse_dirt
execute in minecraft:overworld run fill 264 81 -31 264 144 -31 air
execute in minecraft:overworld run fill 264 58 -30 264 76 -30 stone
execute in minecraft:overworld run fill 264 77 -30 264 78 -30 dirt
execute in minecraft:overworld run setblock 264 79 -30 coarse_dirt
execute in minecraft:overworld run fill 264 80 -30 264 144 -30 air
execute in minecraft:overworld run fill 264 58 -29 264 76 -29 stone
execute in minecraft:overworld run fill 264 77 -29 264 78 -29 dirt
execute in minecraft:overworld run setblock 264 79 -29 coarse_dirt
execute in minecraft:overworld run fill 264 80 -29 264 144 -29 air
execute in minecraft:overworld run fill 264 58 -28 264 75 -28 stone
execute in minecraft:overworld run fill 264 76 -28 264 77 -28 dirt
execute in minecraft:overworld run setblock 264 78 -28 grass_block
execute in minecraft:overworld run fill 264 79 -28 264 144 -28 air
execute in minecraft:overworld run fill 264 58 -27 264 75 -27 stone
execute in minecraft:overworld run fill 264 76 -27 264 77 -27 dirt
execute in minecraft:overworld run setblock 264 78 -27 coarse_dirt
execute in minecraft:overworld run fill 264 79 -27 264 144 -27 air
execute in minecraft:overworld run fill 264 58 -26 264 74 -26 stone
execute in minecraft:overworld run fill 264 75 -26 264 76 -26 dirt
execute in minecraft:overworld run setblock 264 77 -26 coarse_dirt
execute in minecraft:overworld run fill 264 78 -26 264 144 -26 air
execute in minecraft:overworld run fill 264 58 -25 264 73 -25 stone
execute in minecraft:overworld run fill 264 74 -25 264 75 -25 dirt
execute in minecraft:overworld run setblock 264 76 -25 coarse_dirt
execute in minecraft:overworld run fill 264 77 -25 264 144 -25 air
execute in minecraft:overworld run fill 264 58 -24 264 72 -24 stone
execute in minecraft:overworld run fill 264 73 -24 264 74 -24 dirt
execute in minecraft:overworld run setblock 264 75 -24 coarse_dirt
execute in minecraft:overworld run fill 264 76 -24 264 144 -24 air
execute in minecraft:overworld run setblock 264 76 -24 grass
execute in minecraft:overworld run fill 264 58 -23 264 71 -23 stone
execute in minecraft:overworld run fill 264 72 -23 264 73 -23 dirt
execute in minecraft:overworld run setblock 264 74 -23 coarse_dirt
execute in minecraft:overworld run fill 264 75 -23 264 144 -23 air
execute in minecraft:overworld run fill 264 58 -22 264 70 -22 stone
execute in minecraft:overworld run fill 264 71 -22 264 72 -22 dirt
execute in minecraft:overworld run setblock 264 73 -22 coarse_dirt
execute in minecraft:overworld run fill 264 74 -22 264 144 -22 air
execute in minecraft:overworld run fill 264 58 -21 264 69 -21 stone
execute in minecraft:overworld run fill 264 70 -21 264 71 -21 dirt
execute in minecraft:overworld run setblock 264 72 -21 coarse_dirt
execute in minecraft:overworld run fill 264 73 -21 264 144 -21 air
execute in minecraft:overworld run fill 264 58 -20 264 68 -20 stone
execute in minecraft:overworld run fill 264 69 -20 264 70 -20 dirt
execute in minecraft:overworld run setblock 264 71 -20 coarse_dirt
execute in minecraft:overworld run fill 264 72 -20 264 144 -20 air
execute in minecraft:overworld run fill 264 58 -19 264 67 -19 stone
execute in minecraft:overworld run fill 264 68 -19 264 69 -19 dirt
execute in minecraft:overworld run setblock 264 70 -19 grass_block
execute in minecraft:overworld run fill 264 71 -19 264 144 -19 air
execute in minecraft:overworld run fill 264 58 -18 264 65 -18 stone
execute in minecraft:overworld run fill 264 66 -18 264 67 -18 dirt
execute in minecraft:overworld run setblock 264 68 -18 coarse_dirt
execute in minecraft:overworld run fill 264 69 -18 264 144 -18 air
execute in minecraft:overworld run fill 264 58 -17 264 64 -17 stone
execute in minecraft:overworld run fill 264 65 -17 264 66 -17 dirt
execute in minecraft:overworld run setblock 264 67 -17 coarse_dirt
execute in minecraft:overworld run fill 264 68 -17 264 144 -17 air
execute in minecraft:overworld run fill 264 58 -16 264 63 -16 stone
execute in minecraft:overworld run fill 264 64 -16 264 65 -16 dirt
execute in minecraft:overworld run setblock 264 66 -16 coarse_dirt
execute in minecraft:overworld run fill 264 67 -16 264 144 -16 air
execute in minecraft:overworld run fill 264 58 -15 264 62 -15 stone
execute in minecraft:overworld run fill 264 63 -15 264 64 -15 dirt
execute in minecraft:overworld run setblock 264 65 -15 coarse_dirt
execute in minecraft:overworld run fill 264 66 -15 264 144 -15 air
execute in minecraft:overworld run fill 264 58 -14 264 60 -14 stone
execute in minecraft:overworld run fill 264 61 -14 264 62 -14 dirt
execute in minecraft:overworld run setblock 264 63 -14 gravel
execute in minecraft:overworld run fill 264 64 -14 264 144 -14 air
execute in minecraft:overworld run fill 264 64 -14 264 64 -14 water
execute in minecraft:overworld run fill 264 58 -13 264 59 -13 stone
execute in minecraft:overworld run fill 264 60 -13 264 61 -13 dirt
execute in minecraft:overworld run setblock 264 62 -13 gravel
execute in minecraft:overworld run fill 264 63 -13 264 144 -13 air
execute in minecraft:overworld run fill 264 63 -13 264 64 -13 water
execute in minecraft:overworld run fill 264 58 -12 264 58 -12 stone
execute in minecraft:overworld run fill 264 59 -12 264 60 -12 dirt
execute in minecraft:overworld run setblock 264 61 -12 gravel
execute in minecraft:overworld run fill 264 62 -12 264 144 -12 air
execute in minecraft:overworld run fill 264 62 -12 264 64 -12 water
execute in minecraft:overworld run fill 264 58 -11 264 57 -11 stone
execute in minecraft:overworld run fill 264 58 -11 264 59 -11 dirt
execute in minecraft:overworld run setblock 264 60 -11 gravel
execute in minecraft:overworld run fill 264 61 -11 264 144 -11 air
execute in minecraft:overworld run fill 264 61 -11 264 64 -11 water
execute in minecraft:overworld run fill 264 58 -10 264 57 -10 stone
execute in minecraft:overworld run fill 264 58 -10 264 59 -10 dirt
execute in minecraft:overworld run setblock 264 60 -10 gravel
execute in minecraft:overworld run fill 264 61 -10 264 144 -10 air
execute in minecraft:overworld run fill 264 61 -10 264 64 -10 water
execute in minecraft:overworld run fill 264 58 -9 264 56 -9 stone
execute in minecraft:overworld run fill 264 57 -9 264 58 -9 dirt
execute in minecraft:overworld run setblock 264 59 -9 gravel
execute in minecraft:overworld run fill 264 60 -9 264 144 -9 air
execute in minecraft:overworld run fill 264 60 -9 264 64 -9 water
execute in minecraft:overworld run fill 264 58 -8 264 56 -8 stone
execute in minecraft:overworld run fill 264 57 -8 264 58 -8 dirt
execute in minecraft:overworld run setblock 264 59 -8 gravel
execute in minecraft:overworld run fill 264 60 -8 264 144 -8 air
execute in minecraft:overworld run fill 264 60 -8 264 64 -8 water
execute in minecraft:overworld run fill 264 58 -7 264 55 -7 stone
execute in minecraft:overworld run fill 264 56 -7 264 57 -7 dirt
execute in minecraft:overworld run setblock 264 58 -7 gravel
execute in minecraft:overworld run fill 264 59 -7 264 144 -7 air
execute in minecraft:overworld run fill 264 59 -7 264 64 -7 water
execute in minecraft:overworld run fill 264 58 -6 264 55 -6 stone
execute in minecraft:overworld run fill 264 56 -6 264 57 -6 dirt
execute in minecraft:overworld run setblock 264 58 -6 gravel
execute in minecraft:overworld run fill 264 59 -6 264 144 -6 air
execute in minecraft:overworld run fill 264 59 -6 264 64 -6 water
execute in minecraft:overworld run fill 264 58 -5 264 55 -5 stone
execute in minecraft:overworld run fill 264 56 -5 264 57 -5 dirt
execute in minecraft:overworld run setblock 264 58 -5 gravel
execute in minecraft:overworld run fill 264 59 -5 264 144 -5 air
execute in minecraft:overworld run fill 264 59 -5 264 64 -5 water
execute in minecraft:overworld run fill 264 58 -4 264 55 -4 stone
execute in minecraft:overworld run fill 264 56 -4 264 57 -4 dirt
execute in minecraft:overworld run setblock 264 58 -4 gravel
execute in minecraft:overworld run fill 264 59 -4 264 144 -4 air
execute in minecraft:overworld run fill 264 59 -4 264 64 -4 water
execute in minecraft:overworld run fill 264 58 -3 264 54 -3 stone
execute in minecraft:overworld run fill 264 55 -3 264 56 -3 dirt
execute in minecraft:overworld run setblock 264 57 -3 gravel
execute in minecraft:overworld run fill 264 58 -3 264 144 -3 air
execute in minecraft:overworld run fill 264 58 -3 264 64 -3 water
execute in minecraft:overworld run fill 264 58 -2 264 54 -2 stone
execute in minecraft:overworld run fill 264 55 -2 264 56 -2 dirt
execute in minecraft:overworld run setblock 264 57 -2 gravel
execute in minecraft:overworld run fill 264 58 -2 264 144 -2 air
execute in minecraft:overworld run fill 264 58 -2 264 64 -2 water
execute in minecraft:overworld run fill 264 58 -1 264 54 -1 stone
execute in minecraft:overworld run fill 264 55 -1 264 56 -1 dirt
execute in minecraft:overworld run setblock 264 57 -1 gravel
execute in minecraft:overworld run fill 264 58 -1 264 144 -1 air
execute in minecraft:overworld run fill 264 58 -1 264 64 -1 water
execute in minecraft:overworld run fill 264 58 0 264 54 0 stone
execute in minecraft:overworld run fill 264 55 0 264 56 0 dirt
execute in minecraft:overworld run setblock 264 57 0 gravel
execute in minecraft:overworld run fill 264 58 0 264 144 0 air
execute in minecraft:overworld run fill 264 58 0 264 64 0 water
execute in minecraft:overworld run fill 264 58 1 264 55 1 stone
execute in minecraft:overworld run fill 264 56 1 264 57 1 dirt
execute in minecraft:overworld run setblock 264 58 1 gravel
execute in minecraft:overworld run fill 264 59 1 264 144 1 air
execute in minecraft:overworld run fill 264 59 1 264 64 1 water
execute in minecraft:overworld run fill 264 58 2 264 55 2 stone
execute in minecraft:overworld run fill 264 56 2 264 57 2 dirt
execute in minecraft:overworld run setblock 264 58 2 gravel
execute in minecraft:overworld run fill 264 59 2 264 144 2 air
execute in minecraft:overworld run fill 264 59 2 264 64 2 water
execute in minecraft:overworld run fill 264 58 3 264 55 3 stone
execute in minecraft:overworld run fill 264 56 3 264 57 3 dirt
execute in minecraft:overworld run setblock 264 58 3 gravel
execute in minecraft:overworld run fill 264 59 3 264 144 3 air
execute in minecraft:overworld run fill 264 59 3 264 64 3 water
execute in minecraft:overworld run fill 264 58 4 264 55 4 stone
execute in minecraft:overworld run fill 264 56 4 264 57 4 dirt
execute in minecraft:overworld run setblock 264 58 4 gravel
execute in minecraft:overworld run fill 264 59 4 264 144 4 air
execute in minecraft:overworld run fill 264 59 4 264 64 4 water
execute in minecraft:overworld run fill 264 58 5 264 55 5 stone
execute in minecraft:overworld run fill 264 56 5 264 57 5 dirt
execute in minecraft:overworld run setblock 264 58 5 gravel
execute in minecraft:overworld run fill 264 59 5 264 144 5 air
execute in minecraft:overworld run fill 264 59 5 264 64 5 water
execute in minecraft:overworld run fill 264 58 6 264 56 6 stone
execute in minecraft:overworld run fill 264 57 6 264 58 6 dirt
execute in minecraft:overworld run setblock 264 59 6 gravel
execute in minecraft:overworld run fill 264 60 6 264 144 6 air
execute in minecraft:overworld run fill 264 60 6 264 64 6 water
execute in minecraft:overworld run fill 264 58 7 264 56 7 stone
execute in minecraft:overworld run fill 264 57 7 264 58 7 dirt
execute in minecraft:overworld run setblock 264 59 7 gravel
execute in minecraft:overworld run fill 264 60 7 264 144 7 air
execute in minecraft:overworld run fill 264 60 7 264 64 7 water
execute in minecraft:overworld run fill 264 58 8 264 56 8 stone
execute in minecraft:overworld run fill 264 57 8 264 58 8 dirt
execute in minecraft:overworld run setblock 264 59 8 gravel
execute in minecraft:overworld run fill 264 60 8 264 144 8 air
execute in minecraft:overworld run fill 264 60 8 264 64 8 water
execute in minecraft:overworld run fill 264 58 9 264 56 9 stone
execute in minecraft:overworld run fill 264 57 9 264 58 9 dirt
execute in minecraft:overworld run setblock 264 59 9 gravel
execute in minecraft:overworld run fill 264 60 9 264 144 9 air
execute in minecraft:overworld run fill 264 60 9 264 64 9 water
execute in minecraft:overworld run fill 264 58 10 264 56 10 stone
execute in minecraft:overworld run fill 264 57 10 264 58 10 dirt
execute in minecraft:overworld run setblock 264 59 10 gravel
execute in minecraft:overworld run fill 264 60 10 264 144 10 air
execute in minecraft:overworld run fill 264 60 10 264 64 10 water
execute in minecraft:overworld run fill 264 58 11 264 56 11 stone
execute in minecraft:overworld run fill 264 57 11 264 58 11 dirt
execute in minecraft:overworld run setblock 264 59 11 gravel
execute in minecraft:overworld run fill 264 60 11 264 144 11 air
execute in minecraft:overworld run fill 264 60 11 264 64 11 water
execute in minecraft:overworld run fill 264 58 12 264 56 12 stone
execute in minecraft:overworld run fill 264 57 12 264 58 12 dirt
execute in minecraft:overworld run setblock 264 59 12 gravel
execute in minecraft:overworld run fill 264 60 12 264 144 12 air
execute in minecraft:overworld run fill 264 60 12 264 64 12 water
execute in minecraft:overworld run fill 264 58 13 264 57 13 stone
execute in minecraft:overworld run fill 264 58 13 264 59 13 dirt
execute in minecraft:overworld run setblock 264 60 13 gravel
execute in minecraft:overworld run fill 264 61 13 264 144 13 air
execute in minecraft:overworld run fill 264 61 13 264 64 13 water
execute in minecraft:overworld run fill 264 58 14 264 57 14 stone
execute in minecraft:overworld run fill 264 58 14 264 59 14 dirt
schedule function blade_gallery:random/burned/part_89 1t replace
