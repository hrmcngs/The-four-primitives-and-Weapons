execute in minecraft:overworld run fill 236 69 -43 236 70 -43 dirt
execute in minecraft:overworld run setblock 236 71 -43 grass_block
execute in minecraft:overworld run fill 236 72 -43 236 144 -43 air
execute in minecraft:overworld run fill 236 58 -42 236 69 -42 stone
execute in minecraft:overworld run fill 236 70 -42 236 71 -42 dirt
execute in minecraft:overworld run setblock 236 72 -42 coarse_dirt
execute in minecraft:overworld run fill 236 73 -42 236 144 -42 air
execute in minecraft:overworld run fill 236 58 -41 236 70 -41 stone
execute in minecraft:overworld run fill 236 71 -41 236 72 -41 dirt
execute in minecraft:overworld run setblock 236 73 -41 grass_block
execute in minecraft:overworld run fill 236 74 -41 236 144 -41 air
execute in minecraft:overworld run fill 236 58 -40 236 72 -40 stone
execute in minecraft:overworld run fill 236 73 -40 236 74 -40 dirt
execute in minecraft:overworld run setblock 236 75 -40 coarse_dirt
execute in minecraft:overworld run fill 236 76 -40 236 144 -40 air
execute in minecraft:overworld run fill 236 58 -39 236 73 -39 stone
execute in minecraft:overworld run fill 236 74 -39 236 75 -39 dirt
execute in minecraft:overworld run setblock 236 76 -39 coarse_dirt
execute in minecraft:overworld run fill 236 77 -39 236 144 -39 air
execute in minecraft:overworld run fill 236 58 -38 236 74 -38 stone
execute in minecraft:overworld run fill 236 75 -38 236 76 -38 dirt
execute in minecraft:overworld run setblock 236 77 -38 grass_block
execute in minecraft:overworld run fill 236 78 -38 236 144 -38 air
execute in minecraft:overworld run fill 236 58 -37 236 74 -37 stone
execute in minecraft:overworld run fill 236 75 -37 236 76 -37 dirt
execute in minecraft:overworld run setblock 236 77 -37 coarse_dirt
execute in minecraft:overworld run fill 236 78 -37 236 144 -37 air
execute in minecraft:overworld run fill 236 58 -36 236 74 -36 stone
execute in minecraft:overworld run fill 236 75 -36 236 76 -36 dirt
execute in minecraft:overworld run setblock 236 77 -36 coarse_dirt
execute in minecraft:overworld run fill 236 78 -36 236 144 -36 air
execute in minecraft:overworld run fill 236 58 -35 236 73 -35 stone
execute in minecraft:overworld run fill 236 74 -35 236 75 -35 dirt
execute in minecraft:overworld run setblock 236 76 -35 coarse_dirt
execute in minecraft:overworld run fill 236 77 -35 236 144 -35 air
execute in minecraft:overworld run fill 236 58 -34 236 73 -34 stone
execute in minecraft:overworld run fill 236 74 -34 236 75 -34 dirt
execute in minecraft:overworld run setblock 236 76 -34 grass_block
execute in minecraft:overworld run fill 236 77 -34 236 144 -34 air
execute in minecraft:overworld run fill 236 58 -33 236 73 -33 stone
execute in minecraft:overworld run fill 236 74 -33 236 75 -33 dirt
execute in minecraft:overworld run setblock 236 76 -33 coarse_dirt
execute in minecraft:overworld run fill 236 77 -33 236 144 -33 air
execute in minecraft:overworld run fill 236 58 -32 236 72 -32 stone
execute in minecraft:overworld run fill 236 73 -32 236 74 -32 dirt
execute in minecraft:overworld run setblock 236 75 -32 coarse_dirt
execute in minecraft:overworld run fill 236 76 -32 236 144 -32 air
execute in minecraft:overworld run fill 236 58 -31 236 72 -31 stone
execute in minecraft:overworld run fill 236 73 -31 236 74 -31 dirt
execute in minecraft:overworld run setblock 236 75 -31 grass_block
execute in minecraft:overworld run fill 236 76 -31 236 144 -31 air
execute in minecraft:overworld run fill 236 58 -30 236 71 -30 stone
execute in minecraft:overworld run fill 236 72 -30 236 73 -30 dirt
execute in minecraft:overworld run setblock 236 74 -30 grass_block
execute in minecraft:overworld run fill 236 75 -30 236 144 -30 air
execute in minecraft:overworld run fill 236 58 -29 236 71 -29 stone
execute in minecraft:overworld run fill 236 72 -29 236 73 -29 dirt
execute in minecraft:overworld run setblock 236 74 -29 grass_block
execute in minecraft:overworld run fill 236 75 -29 236 144 -29 air
execute in minecraft:overworld run fill 236 58 -28 236 71 -28 stone
execute in minecraft:overworld run fill 236 72 -28 236 73 -28 dirt
execute in minecraft:overworld run setblock 236 74 -28 coarse_dirt
execute in minecraft:overworld run fill 236 75 -28 236 144 -28 air
execute in minecraft:overworld run setblock 236 75 -28 grass
execute in minecraft:overworld run fill 236 58 -27 236 70 -27 stone
execute in minecraft:overworld run fill 236 71 -27 236 72 -27 dirt
execute in minecraft:overworld run setblock 236 73 -27 coarse_dirt
execute in minecraft:overworld run fill 236 74 -27 236 144 -27 air
execute in minecraft:overworld run fill 236 58 -26 236 70 -26 stone
execute in minecraft:overworld run fill 236 71 -26 236 72 -26 dirt
execute in minecraft:overworld run setblock 236 73 -26 coarse_dirt
execute in minecraft:overworld run fill 236 74 -26 236 144 -26 air
execute in minecraft:overworld run fill 236 58 -25 236 70 -25 stone
execute in minecraft:overworld run fill 236 71 -25 236 72 -25 dirt
execute in minecraft:overworld run setblock 236 73 -25 coarse_dirt
execute in minecraft:overworld run fill 236 74 -25 236 144 -25 air
execute in minecraft:overworld run setblock 236 74 -25 mossy_cobblestone
execute in minecraft:overworld run fill 236 58 -24 236 69 -24 stone
execute in minecraft:overworld run fill 236 70 -24 236 71 -24 dirt
execute in minecraft:overworld run setblock 236 72 -24 grass_block
execute in minecraft:overworld run fill 236 73 -24 236 144 -24 air
execute in minecraft:overworld run fill 236 58 -23 236 69 -23 stone
execute in minecraft:overworld run fill 236 70 -23 236 71 -23 dirt
execute in minecraft:overworld run setblock 236 72 -23 coarse_dirt
execute in minecraft:overworld run fill 236 73 -23 236 144 -23 air
execute in minecraft:overworld run fill 236 58 -22 236 68 -22 stone
execute in minecraft:overworld run fill 236 69 -22 236 70 -22 dirt
execute in minecraft:overworld run setblock 236 71 -22 coarse_dirt
execute in minecraft:overworld run fill 236 72 -22 236 144 -22 air
execute in minecraft:overworld run fill 236 58 -21 236 68 -21 stone
execute in minecraft:overworld run fill 236 69 -21 236 70 -21 dirt
execute in minecraft:overworld run setblock 236 71 -21 coarse_dirt
execute in minecraft:overworld run fill 236 72 -21 236 144 -21 air
execute in minecraft:overworld run fill 236 58 -20 236 67 -20 stone
execute in minecraft:overworld run fill 236 68 -20 236 69 -20 dirt
execute in minecraft:overworld run setblock 236 70 -20 coarse_dirt
execute in minecraft:overworld run fill 236 71 -20 236 144 -20 air
execute in minecraft:overworld run fill 236 58 -19 236 67 -19 stone
execute in minecraft:overworld run fill 236 68 -19 236 69 -19 dirt
execute in minecraft:overworld run setblock 236 70 -19 grass_block
execute in minecraft:overworld run fill 236 71 -19 236 144 -19 air
execute in minecraft:overworld run fill 236 58 -18 236 67 -18 stone
execute in minecraft:overworld run fill 236 68 -18 236 69 -18 dirt
execute in minecraft:overworld run setblock 236 70 -18 coarse_dirt
execute in minecraft:overworld run fill 236 71 -18 236 144 -18 air
execute in minecraft:overworld run fill 236 58 -17 236 66 -17 stone
execute in minecraft:overworld run fill 236 67 -17 236 68 -17 dirt
execute in minecraft:overworld run setblock 236 69 -17 grass_block
execute in minecraft:overworld run fill 236 70 -17 236 144 -17 air
execute in minecraft:overworld run fill 236 58 -16 236 66 -16 stone
execute in minecraft:overworld run fill 236 67 -16 236 68 -16 dirt
execute in minecraft:overworld run setblock 236 69 -16 grass_block
execute in minecraft:overworld run fill 236 70 -16 236 144 -16 air
execute in minecraft:overworld run fill 236 58 -15 236 66 -15 stone
execute in minecraft:overworld run fill 236 67 -15 236 68 -15 dirt
execute in minecraft:overworld run setblock 236 69 -15 grass_block
execute in minecraft:overworld run fill 236 70 -15 236 144 -15 air
execute in minecraft:overworld run fill 236 58 -14 236 65 -14 stone
execute in minecraft:overworld run fill 236 66 -14 236 67 -14 dirt
execute in minecraft:overworld run setblock 236 68 -14 coarse_dirt
execute in minecraft:overworld run fill 236 69 -14 236 144 -14 air
execute in minecraft:overworld run fill 236 58 -13 236 65 -13 stone
execute in minecraft:overworld run fill 236 66 -13 236 67 -13 dirt
execute in minecraft:overworld run setblock 236 68 -13 coarse_dirt
execute in minecraft:overworld run fill 236 69 -13 236 144 -13 air
execute in minecraft:overworld run fill 236 58 -12 236 65 -12 stone
execute in minecraft:overworld run fill 236 66 -12 236 67 -12 dirt
execute in minecraft:overworld run setblock 236 68 -12 coarse_dirt
execute in minecraft:overworld run fill 236 69 -12 236 144 -12 air
execute in minecraft:overworld run fill 236 58 -11 236 65 -11 stone
execute in minecraft:overworld run fill 236 66 -11 236 67 -11 dirt
execute in minecraft:overworld run setblock 236 68 -11 coarse_dirt
execute in minecraft:overworld run fill 236 69 -11 236 144 -11 air
execute in minecraft:overworld run fill 236 58 -10 236 65 -10 stone
execute in minecraft:overworld run fill 236 66 -10 236 67 -10 dirt
execute in minecraft:overworld run setblock 236 68 -10 coarse_dirt
execute in minecraft:overworld run fill 236 69 -10 236 144 -10 air
execute in minecraft:overworld run fill 236 58 -9 236 65 -9 stone
execute in minecraft:overworld run fill 236 66 -9 236 67 -9 dirt
execute in minecraft:overworld run setblock 236 68 -9 grass_block
execute in minecraft:overworld run fill 236 69 -9 236 144 -9 air
execute in minecraft:overworld run fill 236 58 -8 236 65 -8 stone
execute in minecraft:overworld run fill 236 66 -8 236 67 -8 dirt
execute in minecraft:overworld run setblock 236 68 -8 grass_block
execute in minecraft:overworld run fill 236 69 -8 236 144 -8 air
execute in minecraft:overworld run fill 236 58 -7 236 64 -7 stone
execute in minecraft:overworld run fill 236 65 -7 236 66 -7 dirt
execute in minecraft:overworld run setblock 236 67 -7 coarse_dirt
execute in minecraft:overworld run fill 236 68 -7 236 144 -7 air
execute in minecraft:overworld run fill 236 58 -6 236 64 -6 stone
execute in minecraft:overworld run fill 236 65 -6 236 66 -6 dirt
execute in minecraft:overworld run setblock 236 67 -6 coarse_dirt
execute in minecraft:overworld run fill 236 68 -6 236 144 -6 air
execute in minecraft:overworld run setblock 236 68 -6 grass
execute in minecraft:overworld run fill 236 58 -5 236 64 -5 stone
execute in minecraft:overworld run fill 236 65 -5 236 66 -5 dirt
execute in minecraft:overworld run setblock 236 67 -5 coarse_dirt
execute in minecraft:overworld run fill 236 68 -5 236 144 -5 air
execute in minecraft:overworld run fill 236 58 -4 236 64 -4 stone
execute in minecraft:overworld run fill 236 65 -4 236 66 -4 dirt
execute in minecraft:overworld run setblock 236 67 -4 grass_block
execute in minecraft:overworld run fill 236 68 -4 236 144 -4 air
execute in minecraft:overworld run fill 236 58 -3 236 64 -3 stone
execute in minecraft:overworld run fill 236 65 -3 236 66 -3 dirt
execute in minecraft:overworld run setblock 236 67 -3 coarse_dirt
execute in minecraft:overworld run fill 236 68 -3 236 144 -3 air
execute in minecraft:overworld run fill 236 58 -2 236 64 -2 stone
execute in minecraft:overworld run fill 236 65 -2 236 66 -2 dirt
execute in minecraft:overworld run setblock 236 67 -2 grass_block
execute in minecraft:overworld run fill 236 68 -2 236 144 -2 air
execute in minecraft:overworld run fill 236 58 -1 236 64 -1 stone
execute in minecraft:overworld run fill 236 65 -1 236 66 -1 dirt
execute in minecraft:overworld run setblock 236 67 -1 coarse_dirt
execute in minecraft:overworld run fill 236 68 -1 236 144 -1 air
execute in minecraft:overworld run setblock 236 68 -1 grass
execute in minecraft:overworld run fill 236 58 0 236 64 0 stone
execute in minecraft:overworld run fill 236 65 0 236 66 0 dirt
execute in minecraft:overworld run setblock 236 67 0 grass_block
execute in minecraft:overworld run fill 236 68 0 236 144 0 air
execute in minecraft:overworld run fill 236 58 1 236 64 1 stone
execute in minecraft:overworld run fill 236 65 1 236 66 1 dirt
execute in minecraft:overworld run setblock 236 67 1 coarse_dirt
execute in minecraft:overworld run fill 236 68 1 236 144 1 air
execute in minecraft:overworld run fill 236 58 2 236 64 2 stone
execute in minecraft:overworld run fill 236 65 2 236 66 2 dirt
execute in minecraft:overworld run setblock 236 67 2 coarse_dirt
execute in minecraft:overworld run fill 236 68 2 236 144 2 air
execute in minecraft:overworld run fill 236 58 3 236 64 3 stone
execute in minecraft:overworld run fill 236 65 3 236 66 3 dirt
execute in minecraft:overworld run setblock 236 67 3 coarse_dirt
execute in minecraft:overworld run fill 236 68 3 236 144 3 air
execute in minecraft:overworld run fill 236 58 4 236 64 4 stone
execute in minecraft:overworld run fill 236 65 4 236 66 4 dirt
execute in minecraft:overworld run setblock 236 67 4 grass_block
execute in minecraft:overworld run fill 236 68 4 236 144 4 air
execute in minecraft:overworld run fill 236 58 5 236 64 5 stone
execute in minecraft:overworld run fill 236 65 5 236 66 5 dirt
execute in minecraft:overworld run setblock 236 67 5 coarse_dirt
execute in minecraft:overworld run fill 236 68 5 236 144 5 air
execute in minecraft:overworld run fill 236 58 6 236 65 6 stone
execute in minecraft:overworld run fill 236 66 6 236 67 6 dirt
execute in minecraft:overworld run setblock 236 68 6 grass_block
execute in minecraft:overworld run fill 236 69 6 236 144 6 air
execute in minecraft:overworld run fill 236 58 7 236 65 7 stone
execute in minecraft:overworld run fill 236 66 7 236 67 7 dirt
execute in minecraft:overworld run setblock 236 68 7 coarse_dirt
execute in minecraft:overworld run fill 236 69 7 236 144 7 air
execute in minecraft:overworld run fill 236 58 8 236 65 8 stone
execute in minecraft:overworld run fill 236 66 8 236 67 8 dirt
execute in minecraft:overworld run setblock 236 68 8 coarse_dirt
execute in minecraft:overworld run fill 236 69 8 236 144 8 air
execute in minecraft:overworld run fill 236 58 9 236 65 9 stone
execute in minecraft:overworld run fill 236 66 9 236 67 9 dirt
execute in minecraft:overworld run setblock 236 68 9 coarse_dirt
execute in minecraft:overworld run fill 236 69 9 236 144 9 air
execute in minecraft:overworld run fill 236 58 10 236 66 10 stone
execute in minecraft:overworld run fill 236 67 10 236 68 10 dirt
execute in minecraft:overworld run setblock 236 69 10 coarse_dirt
execute in minecraft:overworld run fill 236 70 10 236 144 10 air
execute in minecraft:overworld run fill 236 58 11 236 66 11 stone
execute in minecraft:overworld run fill 236 67 11 236 68 11 dirt
execute in minecraft:overworld run setblock 236 69 11 coarse_dirt
execute in minecraft:overworld run fill 236 70 11 236 144 11 air
execute in minecraft:overworld run fill 236 58 12 236 66 12 stone
execute in minecraft:overworld run fill 236 67 12 236 68 12 dirt
execute in minecraft:overworld run setblock 236 69 12 coarse_dirt
execute in minecraft:overworld run fill 236 70 12 236 144 12 air
execute in minecraft:overworld run fill 236 58 13 236 66 13 stone
execute in minecraft:overworld run fill 236 67 13 236 68 13 dirt
execute in minecraft:overworld run setblock 236 69 13 coarse_dirt
execute in minecraft:overworld run fill 236 70 13 236 144 13 air
execute in minecraft:overworld run fill 236 58 14 236 67 14 stone
execute in minecraft:overworld run fill 236 68 14 236 69 14 dirt
execute in minecraft:overworld run setblock 236 70 14 grass_block
execute in minecraft:overworld run fill 236 71 14 236 144 14 air
execute in minecraft:overworld run fill 236 58 15 236 67 15 stone
execute in minecraft:overworld run fill 236 68 15 236 69 15 dirt
execute in minecraft:overworld run setblock 236 70 15 grass_block
execute in minecraft:overworld run fill 236 71 15 236 144 15 air
execute in minecraft:overworld run fill 236 58 16 236 67 16 stone
execute in minecraft:overworld run fill 236 68 16 236 69 16 dirt
execute in minecraft:overworld run setblock 236 70 16 coarse_dirt
execute in minecraft:overworld run fill 236 71 16 236 144 16 air
execute in minecraft:overworld run fill 236 58 17 236 67 17 stone
execute in minecraft:overworld run fill 236 68 17 236 69 17 dirt
execute in minecraft:overworld run setblock 236 70 17 coarse_dirt
execute in minecraft:overworld run fill 236 71 17 236 144 17 air
execute in minecraft:overworld run fill 236 58 18 236 68 18 stone
execute in minecraft:overworld run fill 236 69 18 236 70 18 dirt
execute in minecraft:overworld run setblock 236 71 18 grass_block
execute in minecraft:overworld run fill 236 72 18 236 144 18 air
execute in minecraft:overworld run fill 236 58 19 236 68 19 stone
execute in minecraft:overworld run fill 236 69 19 236 70 19 dirt
execute in minecraft:overworld run setblock 236 71 19 coarse_dirt
execute in minecraft:overworld run fill 236 72 19 236 144 19 air
execute in minecraft:overworld run fill 236 58 20 236 68 20 stone
schedule function blade_gallery:random/burned/part_44 1t replace
