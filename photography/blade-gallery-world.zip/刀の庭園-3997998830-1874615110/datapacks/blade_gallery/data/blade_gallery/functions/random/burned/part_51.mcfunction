execute in minecraft:overworld run setblock 241 73 -23 coarse_dirt
execute in minecraft:overworld run fill 241 74 -23 241 144 -23 air
execute in minecraft:overworld run fill 241 58 -22 241 69 -22 stone
execute in minecraft:overworld run fill 241 70 -22 241 71 -22 dirt
execute in minecraft:overworld run setblock 241 72 -22 grass_block
execute in minecraft:overworld run fill 241 73 -22 241 144 -22 air
execute in minecraft:overworld run fill 241 58 -21 241 69 -21 stone
execute in minecraft:overworld run fill 241 70 -21 241 71 -21 dirt
execute in minecraft:overworld run setblock 241 72 -21 coarse_dirt
execute in minecraft:overworld run fill 241 73 -21 241 144 -21 air
execute in minecraft:overworld run fill 241 58 -20 241 68 -20 stone
execute in minecraft:overworld run fill 241 69 -20 241 70 -20 dirt
execute in minecraft:overworld run setblock 241 71 -20 coarse_dirt
execute in minecraft:overworld run fill 241 72 -20 241 144 -20 air
execute in minecraft:overworld run fill 241 58 -19 241 68 -19 stone
execute in minecraft:overworld run fill 241 69 -19 241 70 -19 dirt
execute in minecraft:overworld run setblock 241 71 -19 grass_block
execute in minecraft:overworld run fill 241 72 -19 241 144 -19 air
execute in minecraft:overworld run fill 241 58 -18 241 67 -18 stone
execute in minecraft:overworld run fill 241 68 -18 241 69 -18 dirt
execute in minecraft:overworld run setblock 241 70 -18 coarse_dirt
execute in minecraft:overworld run fill 241 71 -18 241 144 -18 air
execute in minecraft:overworld run fill 241 58 -17 241 66 -17 stone
execute in minecraft:overworld run fill 241 67 -17 241 68 -17 dirt
execute in minecraft:overworld run setblock 241 69 -17 grass_block
execute in minecraft:overworld run fill 241 70 -17 241 144 -17 air
execute in minecraft:overworld run fill 241 58 -16 241 66 -16 stone
execute in minecraft:overworld run fill 241 67 -16 241 68 -16 dirt
execute in minecraft:overworld run setblock 241 69 -16 coarse_dirt
execute in minecraft:overworld run fill 241 70 -16 241 144 -16 air
execute in minecraft:overworld run setblock 241 70 -16 grass
execute in minecraft:overworld run fill 241 58 -15 241 66 -15 stone
execute in minecraft:overworld run fill 241 67 -15 241 68 -15 dirt
execute in minecraft:overworld run setblock 241 69 -15 grass_block
execute in minecraft:overworld run fill 241 70 -15 241 144 -15 air
execute in minecraft:overworld run fill 241 58 -14 241 65 -14 stone
execute in minecraft:overworld run fill 241 66 -14 241 67 -14 dirt
execute in minecraft:overworld run setblock 241 68 -14 coarse_dirt
execute in minecraft:overworld run fill 241 69 -14 241 144 -14 air
execute in minecraft:overworld run fill 241 58 -13 241 65 -13 stone
execute in minecraft:overworld run fill 241 66 -13 241 67 -13 dirt
execute in minecraft:overworld run setblock 241 68 -13 coarse_dirt
execute in minecraft:overworld run fill 241 69 -13 241 144 -13 air
execute in minecraft:overworld run fill 241 58 -12 241 64 -12 stone
execute in minecraft:overworld run fill 241 65 -12 241 66 -12 dirt
execute in minecraft:overworld run setblock 241 67 -12 coarse_dirt
execute in minecraft:overworld run fill 241 68 -12 241 144 -12 air
execute in minecraft:overworld run fill 241 58 -11 241 64 -11 stone
execute in minecraft:overworld run fill 241 65 -11 241 66 -11 dirt
execute in minecraft:overworld run setblock 241 67 -11 grass_block
execute in minecraft:overworld run fill 241 68 -11 241 144 -11 air
execute in minecraft:overworld run fill 241 58 -10 241 64 -10 stone
execute in minecraft:overworld run fill 241 65 -10 241 66 -10 dirt
execute in minecraft:overworld run setblock 241 67 -10 coarse_dirt
execute in minecraft:overworld run fill 241 68 -10 241 144 -10 air
execute in minecraft:overworld run setblock 241 68 -10 mossy_cobblestone
execute in minecraft:overworld run fill 241 58 -9 241 64 -9 stone
execute in minecraft:overworld run fill 241 65 -9 241 66 -9 dirt
execute in minecraft:overworld run setblock 241 67 -9 grass_block
execute in minecraft:overworld run fill 241 68 -9 241 144 -9 air
execute in minecraft:overworld run fill 241 58 -8 241 64 -8 stone
execute in minecraft:overworld run fill 241 65 -8 241 66 -8 dirt
execute in minecraft:overworld run setblock 241 67 -8 coarse_dirt
execute in minecraft:overworld run fill 241 68 -8 241 144 -8 air
execute in minecraft:overworld run fill 241 58 -7 241 64 -7 stone
execute in minecraft:overworld run fill 241 65 -7 241 66 -7 dirt
execute in minecraft:overworld run setblock 241 67 -7 coarse_dirt
execute in minecraft:overworld run fill 241 68 -7 241 144 -7 air
execute in minecraft:overworld run setblock 241 68 -7 grass
execute in minecraft:overworld run fill 241 58 -6 241 63 -6 stone
execute in minecraft:overworld run fill 241 64 -6 241 65 -6 dirt
execute in minecraft:overworld run setblock 241 66 -6 grass_block
execute in minecraft:overworld run fill 241 67 -6 241 144 -6 air
execute in minecraft:overworld run fill 241 58 -5 241 63 -5 stone
execute in minecraft:overworld run fill 241 64 -5 241 65 -5 dirt
execute in minecraft:overworld run setblock 241 66 -5 grass_block
execute in minecraft:overworld run fill 241 67 -5 241 144 -5 air
execute in minecraft:overworld run fill 241 58 -4 241 63 -4 stone
execute in minecraft:overworld run fill 241 64 -4 241 65 -4 dirt
execute in minecraft:overworld run setblock 241 66 -4 grass_block
execute in minecraft:overworld run fill 241 67 -4 241 144 -4 air
execute in minecraft:overworld run fill 241 58 -3 241 63 -3 stone
execute in minecraft:overworld run fill 241 64 -3 241 65 -3 dirt
execute in minecraft:overworld run setblock 241 66 -3 grass_block
execute in minecraft:overworld run fill 241 67 -3 241 144 -3 air
execute in minecraft:overworld run fill 241 58 -2 241 62 -2 stone
execute in minecraft:overworld run fill 241 63 -2 241 64 -2 dirt
execute in minecraft:overworld run setblock 241 65 -2 coarse_dirt
execute in minecraft:overworld run fill 241 66 -2 241 144 -2 air
execute in minecraft:overworld run fill 241 58 -1 241 62 -1 stone
execute in minecraft:overworld run fill 241 63 -1 241 64 -1 dirt
execute in minecraft:overworld run setblock 241 65 -1 coarse_dirt
execute in minecraft:overworld run fill 241 66 -1 241 144 -1 air
execute in minecraft:overworld run fill 241 58 0 241 62 0 stone
execute in minecraft:overworld run fill 241 63 0 241 64 0 dirt
execute in minecraft:overworld run setblock 241 65 0 coarse_dirt
execute in minecraft:overworld run fill 241 66 0 241 144 0 air
execute in minecraft:overworld run fill 241 58 1 241 62 1 stone
execute in minecraft:overworld run fill 241 63 1 241 64 1 dirt
execute in minecraft:overworld run setblock 241 65 1 coarse_dirt
execute in minecraft:overworld run fill 241 66 1 241 144 1 air
execute in minecraft:overworld run fill 241 58 2 241 62 2 stone
execute in minecraft:overworld run fill 241 63 2 241 64 2 dirt
execute in minecraft:overworld run setblock 241 65 2 coarse_dirt
execute in minecraft:overworld run fill 241 66 2 241 144 2 air
execute in minecraft:overworld run fill 241 58 3 241 63 3 stone
execute in minecraft:overworld run fill 241 64 3 241 65 3 dirt
execute in minecraft:overworld run setblock 241 66 3 grass_block
execute in minecraft:overworld run fill 241 67 3 241 144 3 air
execute in minecraft:overworld run fill 241 58 4 241 63 4 stone
execute in minecraft:overworld run fill 241 64 4 241 65 4 dirt
execute in minecraft:overworld run setblock 241 66 4 coarse_dirt
execute in minecraft:overworld run fill 241 67 4 241 144 4 air
execute in minecraft:overworld run fill 241 58 5 241 64 5 stone
execute in minecraft:overworld run fill 241 65 5 241 66 5 dirt
execute in minecraft:overworld run setblock 241 67 5 grass_block
execute in minecraft:overworld run fill 241 68 5 241 144 5 air
execute in minecraft:overworld run setblock 241 68 5 grass
execute in minecraft:overworld run fill 241 58 6 241 64 6 stone
execute in minecraft:overworld run fill 241 65 6 241 66 6 dirt
execute in minecraft:overworld run setblock 241 67 6 coarse_dirt
execute in minecraft:overworld run fill 241 68 6 241 144 6 air
execute in minecraft:overworld run fill 241 58 7 241 64 7 stone
execute in minecraft:overworld run fill 241 65 7 241 66 7 dirt
execute in minecraft:overworld run setblock 241 67 7 coarse_dirt
execute in minecraft:overworld run fill 241 68 7 241 144 7 air
execute in minecraft:overworld run fill 241 58 8 241 65 8 stone
execute in minecraft:overworld run fill 241 66 8 241 67 8 dirt
execute in minecraft:overworld run setblock 241 68 8 coarse_dirt
execute in minecraft:overworld run fill 241 69 8 241 144 8 air
execute in minecraft:overworld run fill 241 58 9 241 65 9 stone
execute in minecraft:overworld run fill 241 66 9 241 67 9 dirt
execute in minecraft:overworld run setblock 241 68 9 coarse_dirt
execute in minecraft:overworld run fill 241 69 9 241 144 9 air
execute in minecraft:overworld run fill 241 58 10 241 65 10 stone
execute in minecraft:overworld run fill 241 66 10 241 67 10 dirt
execute in minecraft:overworld run setblock 241 68 10 coarse_dirt
execute in minecraft:overworld run fill 241 69 10 241 144 10 air
execute in minecraft:overworld run fill 241 58 11 241 65 11 stone
execute in minecraft:overworld run fill 241 66 11 241 67 11 dirt
execute in minecraft:overworld run setblock 241 68 11 coarse_dirt
execute in minecraft:overworld run fill 241 69 11 241 144 11 air
execute in minecraft:overworld run fill 241 58 12 241 65 12 stone
execute in minecraft:overworld run fill 241 66 12 241 67 12 dirt
execute in minecraft:overworld run setblock 241 68 12 coarse_dirt
execute in minecraft:overworld run fill 241 69 12 241 144 12 air
execute in minecraft:overworld run fill 241 58 13 241 66 13 stone
execute in minecraft:overworld run fill 241 67 13 241 68 13 dirt
execute in minecraft:overworld run setblock 241 69 13 coarse_dirt
execute in minecraft:overworld run fill 241 70 13 241 144 13 air
execute in minecraft:overworld run fill 241 58 14 241 66 14 stone
execute in minecraft:overworld run fill 241 67 14 241 68 14 dirt
execute in minecraft:overworld run setblock 241 69 14 grass_block
execute in minecraft:overworld run fill 241 70 14 241 144 14 air
execute in minecraft:overworld run setblock 241 70 14 mossy_cobblestone
execute in minecraft:overworld run fill 241 58 15 241 66 15 stone
execute in minecraft:overworld run fill 241 67 15 241 68 15 dirt
execute in minecraft:overworld run setblock 241 69 15 coarse_dirt
execute in minecraft:overworld run fill 241 70 15 241 144 15 air
execute in minecraft:overworld run fill 241 58 16 241 66 16 stone
execute in minecraft:overworld run fill 241 67 16 241 68 16 dirt
execute in minecraft:overworld run setblock 241 69 16 grass_block
execute in minecraft:overworld run fill 241 70 16 241 144 16 air
execute in minecraft:overworld run fill 241 58 17 241 66 17 stone
execute in minecraft:overworld run fill 241 67 17 241 68 17 dirt
execute in minecraft:overworld run setblock 241 69 17 coarse_dirt
execute in minecraft:overworld run fill 241 70 17 241 144 17 air
execute in minecraft:overworld run setblock 241 70 17 grass
execute in minecraft:overworld run fill 241 58 18 241 66 18 stone
execute in minecraft:overworld run fill 241 67 18 241 68 18 dirt
execute in minecraft:overworld run setblock 241 69 18 grass_block
execute in minecraft:overworld run fill 241 70 18 241 144 18 air
execute in minecraft:overworld run fill 241 58 19 241 66 19 stone
execute in minecraft:overworld run fill 241 67 19 241 68 19 dirt
execute in minecraft:overworld run setblock 241 69 19 coarse_dirt
execute in minecraft:overworld run fill 241 70 19 241 144 19 air
execute in minecraft:overworld run fill 241 58 20 241 67 20 stone
execute in minecraft:overworld run fill 241 68 20 241 69 20 dirt
execute in minecraft:overworld run setblock 241 70 20 grass_block
execute in minecraft:overworld run fill 241 71 20 241 144 20 air
execute in minecraft:overworld run fill 241 58 21 241 67 21 stone
execute in minecraft:overworld run fill 241 68 21 241 69 21 dirt
execute in minecraft:overworld run setblock 241 70 21 grass_block
execute in minecraft:overworld run fill 241 71 21 241 144 21 air
execute in minecraft:overworld run setblock 241 71 21 grass
execute in minecraft:overworld run fill 241 58 22 241 67 22 stone
execute in minecraft:overworld run fill 241 68 22 241 69 22 dirt
execute in minecraft:overworld run setblock 241 70 22 coarse_dirt
execute in minecraft:overworld run fill 241 71 22 241 144 22 air
execute in minecraft:overworld run fill 241 58 23 241 67 23 stone
execute in minecraft:overworld run fill 241 68 23 241 69 23 dirt
execute in minecraft:overworld run setblock 241 70 23 grass_block
execute in minecraft:overworld run fill 241 71 23 241 144 23 air
execute in minecraft:overworld run fill 241 58 24 241 67 24 stone
execute in minecraft:overworld run fill 241 68 24 241 69 24 dirt
execute in minecraft:overworld run setblock 241 70 24 grass_block
execute in minecraft:overworld run fill 241 71 24 241 144 24 air
execute in minecraft:overworld run fill 241 58 25 241 67 25 stone
execute in minecraft:overworld run fill 241 68 25 241 69 25 dirt
execute in minecraft:overworld run setblock 241 70 25 grass_block
execute in minecraft:overworld run fill 241 71 25 241 144 25 air
execute in minecraft:overworld run fill 241 58 26 241 67 26 stone
execute in minecraft:overworld run fill 241 68 26 241 69 26 dirt
execute in minecraft:overworld run setblock 241 70 26 coarse_dirt
execute in minecraft:overworld run fill 241 71 26 241 144 26 air
execute in minecraft:overworld run setblock 241 71 26 grass
execute in minecraft:overworld run fill 241 58 27 241 67 27 stone
execute in minecraft:overworld run fill 241 68 27 241 69 27 dirt
execute in minecraft:overworld run setblock 241 70 27 coarse_dirt
execute in minecraft:overworld run fill 241 71 27 241 144 27 air
execute in minecraft:overworld run fill 241 58 28 241 67 28 stone
execute in minecraft:overworld run fill 241 68 28 241 69 28 dirt
execute in minecraft:overworld run setblock 241 70 28 coarse_dirt
execute in minecraft:overworld run fill 241 71 28 241 144 28 air
execute in minecraft:overworld run fill 241 58 29 241 67 29 stone
execute in minecraft:overworld run fill 241 68 29 241 69 29 dirt
execute in minecraft:overworld run setblock 241 70 29 coarse_dirt
execute in minecraft:overworld run fill 241 71 29 241 144 29 air
execute in minecraft:overworld run fill 241 58 30 241 66 30 stone
execute in minecraft:overworld run fill 241 67 30 241 68 30 dirt
execute in minecraft:overworld run setblock 241 69 30 coarse_dirt
execute in minecraft:overworld run fill 241 70 30 241 144 30 air
execute in minecraft:overworld run fill 241 58 31 241 66 31 stone
execute in minecraft:overworld run fill 241 67 31 241 68 31 dirt
execute in minecraft:overworld run setblock 241 69 31 coarse_dirt
execute in minecraft:overworld run fill 241 70 31 241 144 31 air
execute in minecraft:overworld run fill 241 58 32 241 66 32 stone
execute in minecraft:overworld run fill 241 67 32 241 68 32 dirt
execute in minecraft:overworld run setblock 241 69 32 coarse_dirt
execute in minecraft:overworld run fill 241 70 32 241 144 32 air
execute in minecraft:overworld run fill 241 58 33 241 66 33 stone
execute in minecraft:overworld run fill 241 67 33 241 68 33 dirt
execute in minecraft:overworld run setblock 241 69 33 coarse_dirt
execute in minecraft:overworld run fill 241 70 33 241 144 33 air
execute in minecraft:overworld run fill 241 58 34 241 66 34 stone
execute in minecraft:overworld run fill 241 67 34 241 68 34 dirt
execute in minecraft:overworld run setblock 241 69 34 coarse_dirt
execute in minecraft:overworld run fill 241 70 34 241 144 34 air
execute in minecraft:overworld run fill 241 58 35 241 65 35 stone
execute in minecraft:overworld run fill 241 66 35 241 67 35 dirt
execute in minecraft:overworld run setblock 241 68 35 coarse_dirt
execute in minecraft:overworld run fill 241 69 35 241 144 35 air
execute in minecraft:overworld run fill 241 58 36 241 65 36 stone
execute in minecraft:overworld run fill 241 66 36 241 67 36 dirt
execute in minecraft:overworld run setblock 241 68 36 coarse_dirt
execute in minecraft:overworld run fill 241 69 36 241 144 36 air
execute in minecraft:overworld run fill 241 58 37 241 65 37 stone
execute in minecraft:overworld run fill 241 66 37 241 67 37 dirt
execute in minecraft:overworld run setblock 241 68 37 grass_block
execute in minecraft:overworld run fill 241 69 37 241 144 37 air
execute in minecraft:overworld run setblock 241 69 37 grass
execute in minecraft:overworld run fill 241 58 38 241 65 38 stone
execute in minecraft:overworld run fill 241 66 38 241 67 38 dirt
execute in minecraft:overworld run setblock 241 68 38 grass_block
execute in minecraft:overworld run fill 241 69 38 241 144 38 air
execute in minecraft:overworld run fill 241 58 39 241 64 39 stone
schedule function blade_gallery:random/burned/part_52 1t replace
