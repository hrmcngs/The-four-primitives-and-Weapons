execute in minecraft:overworld run setblock 295 71 -3 grass_block
execute in minecraft:overworld run fill 295 72 -3 295 144 -3 air
execute in minecraft:overworld run fill 295 58 -2 295 68 -2 stone
execute in minecraft:overworld run fill 295 69 -2 295 70 -2 dirt
execute in minecraft:overworld run setblock 295 71 -2 coarse_dirt
execute in minecraft:overworld run fill 295 72 -2 295 144 -2 air
execute in minecraft:overworld run fill 295 58 -1 295 69 -1 stone
execute in minecraft:overworld run fill 295 70 -1 295 71 -1 dirt
execute in minecraft:overworld run setblock 295 72 -1 grass_block
execute in minecraft:overworld run fill 295 73 -1 295 144 -1 air
execute in minecraft:overworld run fill 295 58 0 295 69 0 stone
execute in minecraft:overworld run fill 295 70 0 295 71 0 dirt
execute in minecraft:overworld run setblock 295 72 0 coarse_dirt
execute in minecraft:overworld run fill 295 73 0 295 144 0 air
execute in minecraft:overworld run fill 295 58 1 295 69 1 stone
execute in minecraft:overworld run fill 295 70 1 295 71 1 dirt
execute in minecraft:overworld run setblock 295 72 1 coarse_dirt
execute in minecraft:overworld run fill 295 73 1 295 144 1 air
execute in minecraft:overworld run fill 295 58 2 295 68 2 stone
execute in minecraft:overworld run fill 295 69 2 295 70 2 dirt
execute in minecraft:overworld run setblock 295 71 2 grass_block
execute in minecraft:overworld run fill 295 72 2 295 144 2 air
execute in minecraft:overworld run fill 295 58 3 295 68 3 stone
execute in minecraft:overworld run fill 295 69 3 295 70 3 dirt
execute in minecraft:overworld run setblock 295 71 3 grass_block
execute in minecraft:overworld run fill 295 72 3 295 144 3 air
execute in minecraft:overworld run fill 295 58 4 295 68 4 stone
execute in minecraft:overworld run fill 295 69 4 295 70 4 dirt
execute in minecraft:overworld run setblock 295 71 4 coarse_dirt
execute in minecraft:overworld run fill 295 72 4 295 144 4 air
execute in minecraft:overworld run fill 295 58 5 295 67 5 stone
execute in minecraft:overworld run fill 295 68 5 295 69 5 dirt
execute in minecraft:overworld run setblock 295 70 5 grass_block
execute in minecraft:overworld run fill 295 71 5 295 144 5 air
execute in minecraft:overworld run fill 295 58 6 295 67 6 stone
execute in minecraft:overworld run fill 295 68 6 295 69 6 dirt
execute in minecraft:overworld run setblock 295 70 6 grass_block
execute in minecraft:overworld run fill 295 71 6 295 144 6 air
execute in minecraft:overworld run fill 295 58 7 295 67 7 stone
execute in minecraft:overworld run fill 295 68 7 295 69 7 dirt
execute in minecraft:overworld run setblock 295 70 7 coarse_dirt
execute in minecraft:overworld run fill 295 71 7 295 144 7 air
execute in minecraft:overworld run fill 295 58 8 295 67 8 stone
execute in minecraft:overworld run fill 295 68 8 295 69 8 dirt
execute in minecraft:overworld run setblock 295 70 8 coarse_dirt
execute in minecraft:overworld run fill 295 71 8 295 144 8 air
execute in minecraft:overworld run setblock 295 71 8 grass
execute in minecraft:overworld run fill 295 58 9 295 66 9 stone
execute in minecraft:overworld run fill 295 67 9 295 68 9 dirt
execute in minecraft:overworld run setblock 295 69 9 coarse_dirt
execute in minecraft:overworld run fill 295 70 9 295 144 9 air
execute in minecraft:overworld run fill 295 58 10 295 66 10 stone
execute in minecraft:overworld run fill 295 67 10 295 68 10 dirt
execute in minecraft:overworld run setblock 295 69 10 coarse_dirt
execute in minecraft:overworld run fill 295 70 10 295 144 10 air
execute in minecraft:overworld run fill 295 58 11 295 66 11 stone
execute in minecraft:overworld run fill 295 67 11 295 68 11 dirt
execute in minecraft:overworld run setblock 295 69 11 coarse_dirt
execute in minecraft:overworld run fill 295 70 11 295 144 11 air
execute in minecraft:overworld run fill 295 58 12 295 66 12 stone
execute in minecraft:overworld run fill 295 67 12 295 68 12 dirt
execute in minecraft:overworld run setblock 295 69 12 grass_block
execute in minecraft:overworld run fill 295 70 12 295 144 12 air
execute in minecraft:overworld run fill 295 58 13 295 66 13 stone
execute in minecraft:overworld run fill 295 67 13 295 68 13 dirt
execute in minecraft:overworld run setblock 295 69 13 coarse_dirt
execute in minecraft:overworld run fill 295 70 13 295 144 13 air
execute in minecraft:overworld run fill 295 58 14 295 65 14 stone
execute in minecraft:overworld run fill 295 66 14 295 67 14 dirt
execute in minecraft:overworld run setblock 295 68 14 coarse_dirt
execute in minecraft:overworld run fill 295 69 14 295 144 14 air
execute in minecraft:overworld run setblock 295 69 14 mossy_cobblestone
execute in minecraft:overworld run fill 295 58 15 295 65 15 stone
execute in minecraft:overworld run fill 295 66 15 295 67 15 dirt
execute in minecraft:overworld run setblock 295 68 15 grass_block
execute in minecraft:overworld run fill 295 69 15 295 144 15 air
execute in minecraft:overworld run fill 295 58 16 295 65 16 stone
execute in minecraft:overworld run fill 295 66 16 295 67 16 dirt
execute in minecraft:overworld run setblock 295 68 16 grass_block
execute in minecraft:overworld run fill 295 69 16 295 144 16 air
execute in minecraft:overworld run fill 295 58 17 295 65 17 stone
execute in minecraft:overworld run fill 295 66 17 295 67 17 dirt
execute in minecraft:overworld run setblock 295 68 17 coarse_dirt
execute in minecraft:overworld run fill 295 69 17 295 144 17 air
execute in minecraft:overworld run fill 295 58 18 295 65 18 stone
execute in minecraft:overworld run fill 295 66 18 295 67 18 dirt
execute in minecraft:overworld run setblock 295 68 18 coarse_dirt
execute in minecraft:overworld run fill 295 69 18 295 144 18 air
execute in minecraft:overworld run fill 295 58 19 295 65 19 stone
execute in minecraft:overworld run fill 295 66 19 295 67 19 dirt
execute in minecraft:overworld run setblock 295 68 19 coarse_dirt
execute in minecraft:overworld run fill 295 69 19 295 144 19 air
execute in minecraft:overworld run fill 295 58 20 295 65 20 stone
execute in minecraft:overworld run fill 295 66 20 295 67 20 dirt
execute in minecraft:overworld run setblock 295 68 20 coarse_dirt
execute in minecraft:overworld run fill 295 69 20 295 144 20 air
execute in minecraft:overworld run fill 295 58 21 295 65 21 stone
execute in minecraft:overworld run fill 295 66 21 295 67 21 dirt
execute in minecraft:overworld run setblock 295 68 21 grass_block
execute in minecraft:overworld run fill 295 69 21 295 144 21 air
execute in minecraft:overworld run fill 295 58 22 295 65 22 stone
execute in minecraft:overworld run fill 295 66 22 295 67 22 dirt
execute in minecraft:overworld run setblock 295 68 22 grass_block
execute in minecraft:overworld run fill 295 69 22 295 144 22 air
execute in minecraft:overworld run fill 295 58 23 295 65 23 stone
execute in minecraft:overworld run fill 295 66 23 295 67 23 dirt
execute in minecraft:overworld run setblock 295 68 23 coarse_dirt
execute in minecraft:overworld run fill 295 69 23 295 144 23 air
execute in minecraft:overworld run fill 295 58 24 295 65 24 stone
execute in minecraft:overworld run fill 295 66 24 295 67 24 dirt
execute in minecraft:overworld run setblock 295 68 24 grass_block
execute in minecraft:overworld run fill 295 69 24 295 144 24 air
execute in minecraft:overworld run fill 295 58 25 295 65 25 stone
execute in minecraft:overworld run fill 295 66 25 295 67 25 dirt
execute in minecraft:overworld run setblock 295 68 25 coarse_dirt
execute in minecraft:overworld run fill 295 69 25 295 144 25 air
execute in minecraft:overworld run fill 295 58 26 295 65 26 stone
execute in minecraft:overworld run fill 295 66 26 295 67 26 dirt
execute in minecraft:overworld run setblock 295 68 26 grass_block
execute in minecraft:overworld run fill 295 69 26 295 144 26 air
execute in minecraft:overworld run fill 295 58 27 295 65 27 stone
execute in minecraft:overworld run fill 295 66 27 295 67 27 dirt
execute in minecraft:overworld run setblock 295 68 27 grass_block
execute in minecraft:overworld run fill 295 69 27 295 144 27 air
execute in minecraft:overworld run fill 295 58 28 295 65 28 stone
execute in minecraft:overworld run fill 295 66 28 295 67 28 dirt
execute in minecraft:overworld run setblock 295 68 28 coarse_dirt
execute in minecraft:overworld run fill 295 69 28 295 144 28 air
execute in minecraft:overworld run fill 295 58 29 295 65 29 stone
execute in minecraft:overworld run fill 295 66 29 295 67 29 dirt
execute in minecraft:overworld run setblock 295 68 29 coarse_dirt
execute in minecraft:overworld run fill 295 69 29 295 144 29 air
execute in minecraft:overworld run fill 295 58 30 295 65 30 stone
execute in minecraft:overworld run fill 295 66 30 295 67 30 dirt
execute in minecraft:overworld run setblock 295 68 30 coarse_dirt
execute in minecraft:overworld run fill 295 69 30 295 144 30 air
execute in minecraft:overworld run fill 295 58 31 295 65 31 stone
execute in minecraft:overworld run fill 295 66 31 295 67 31 dirt
execute in minecraft:overworld run setblock 295 68 31 coarse_dirt
execute in minecraft:overworld run fill 295 69 31 295 144 31 air
execute in minecraft:overworld run fill 295 58 32 295 65 32 stone
execute in minecraft:overworld run fill 295 66 32 295 67 32 dirt
execute in minecraft:overworld run setblock 295 68 32 coarse_dirt
execute in minecraft:overworld run fill 295 69 32 295 144 32 air
execute in minecraft:overworld run fill 295 58 33 295 65 33 stone
execute in minecraft:overworld run fill 295 66 33 295 67 33 dirt
execute in minecraft:overworld run setblock 295 68 33 coarse_dirt
execute in minecraft:overworld run fill 295 69 33 295 144 33 air
execute in minecraft:overworld run fill 295 58 34 295 64 34 stone
execute in minecraft:overworld run fill 295 65 34 295 66 34 dirt
execute in minecraft:overworld run setblock 295 67 34 coarse_dirt
execute in minecraft:overworld run fill 295 68 34 295 144 34 air
execute in minecraft:overworld run fill 295 58 35 295 64 35 stone
execute in minecraft:overworld run fill 295 65 35 295 66 35 dirt
execute in minecraft:overworld run setblock 295 67 35 coarse_dirt
execute in minecraft:overworld run fill 295 68 35 295 144 35 air
execute in minecraft:overworld run fill 295 58 36 295 64 36 stone
execute in minecraft:overworld run fill 295 65 36 295 66 36 dirt
execute in minecraft:overworld run setblock 295 67 36 grass_block
execute in minecraft:overworld run fill 295 68 36 295 144 36 air
execute in minecraft:overworld run fill 295 58 37 295 64 37 stone
execute in minecraft:overworld run fill 295 65 37 295 66 37 dirt
execute in minecraft:overworld run setblock 295 67 37 coarse_dirt
execute in minecraft:overworld run fill 295 68 37 295 144 37 air
execute in minecraft:overworld run fill 295 58 38 295 64 38 stone
execute in minecraft:overworld run fill 295 65 38 295 66 38 dirt
execute in minecraft:overworld run setblock 295 67 38 grass_block
execute in minecraft:overworld run fill 295 68 38 295 144 38 air
execute in minecraft:overworld run fill 295 58 39 295 64 39 stone
execute in minecraft:overworld run fill 295 65 39 295 66 39 dirt
execute in minecraft:overworld run setblock 295 67 39 coarse_dirt
execute in minecraft:overworld run fill 295 68 39 295 144 39 air
execute in minecraft:overworld run fill 295 58 40 295 63 40 stone
execute in minecraft:overworld run fill 295 64 40 295 65 40 dirt
execute in minecraft:overworld run setblock 295 66 40 coarse_dirt
execute in minecraft:overworld run fill 295 67 40 295 144 40 air
execute in minecraft:overworld run fill 295 58 41 295 63 41 stone
execute in minecraft:overworld run fill 295 64 41 295 65 41 dirt
execute in minecraft:overworld run setblock 295 66 41 coarse_dirt
execute in minecraft:overworld run fill 295 67 41 295 144 41 air
execute in minecraft:overworld run fill 295 58 42 295 63 42 stone
execute in minecraft:overworld run fill 295 64 42 295 65 42 dirt
execute in minecraft:overworld run setblock 295 66 42 grass_block
execute in minecraft:overworld run fill 295 67 42 295 144 42 air
execute in minecraft:overworld run fill 295 58 43 295 62 43 stone
execute in minecraft:overworld run fill 295 63 43 295 64 43 dirt
execute in minecraft:overworld run setblock 295 65 43 grass_block
execute in minecraft:overworld run fill 295 66 43 295 144 43 air
execute in minecraft:overworld run fill 295 58 44 295 62 44 stone
execute in minecraft:overworld run fill 295 63 44 295 64 44 dirt
execute in minecraft:overworld run setblock 295 65 44 coarse_dirt
execute in minecraft:overworld run fill 295 66 44 295 144 44 air
execute in minecraft:overworld run fill 295 58 45 295 62 45 stone
execute in minecraft:overworld run fill 295 63 45 295 64 45 dirt
execute in minecraft:overworld run setblock 295 65 45 coarse_dirt
execute in minecraft:overworld run fill 295 66 45 295 144 45 air
execute in minecraft:overworld run fill 295 58 46 295 61 46 stone
execute in minecraft:overworld run fill 295 62 46 295 63 46 dirt
execute in minecraft:overworld run setblock 295 64 46 grass_block
execute in minecraft:overworld run fill 295 65 46 295 144 46 air
execute in minecraft:overworld run fill 295 58 47 295 61 47 stone
execute in minecraft:overworld run fill 295 62 47 295 63 47 dirt
execute in minecraft:overworld run setblock 295 64 47 coarse_dirt
execute in minecraft:overworld run fill 295 65 47 295 144 47 air
execute in minecraft:overworld run fill 296 58 -48 296 61 -48 stone
execute in minecraft:overworld run fill 296 62 -48 296 63 -48 dirt
execute in minecraft:overworld run setblock 296 64 -48 coarse_dirt
execute in minecraft:overworld run fill 296 65 -48 296 144 -48 air
execute in minecraft:overworld run fill 296 58 -47 296 63 -47 stone
execute in minecraft:overworld run fill 296 64 -47 296 65 -47 dirt
execute in minecraft:overworld run setblock 296 66 -47 coarse_dirt
execute in minecraft:overworld run fill 296 67 -47 296 144 -47 air
execute in minecraft:overworld run fill 296 58 -46 296 65 -46 stone
execute in minecraft:overworld run fill 296 66 -46 296 67 -46 dirt
execute in minecraft:overworld run setblock 296 68 -46 coarse_dirt
execute in minecraft:overworld run fill 296 69 -46 296 144 -46 air
execute in minecraft:overworld run fill 296 58 -45 296 67 -45 stone
execute in minecraft:overworld run fill 296 68 -45 296 69 -45 dirt
execute in minecraft:overworld run setblock 296 70 -45 grass_block
execute in minecraft:overworld run fill 296 71 -45 296 144 -45 air
execute in minecraft:overworld run fill 296 58 -44 296 69 -44 stone
execute in minecraft:overworld run fill 296 70 -44 296 71 -44 dirt
execute in minecraft:overworld run setblock 296 72 -44 coarse_dirt
execute in minecraft:overworld run fill 296 73 -44 296 144 -44 air
execute in minecraft:overworld run fill 296 58 -43 296 71 -43 stone
execute in minecraft:overworld run fill 296 72 -43 296 73 -43 dirt
execute in minecraft:overworld run setblock 296 74 -43 grass_block
execute in minecraft:overworld run fill 296 75 -43 296 144 -43 air
execute in minecraft:overworld run fill 296 58 -42 296 72 -42 stone
execute in minecraft:overworld run fill 296 73 -42 296 74 -42 dirt
execute in minecraft:overworld run setblock 296 75 -42 coarse_dirt
execute in minecraft:overworld run fill 296 76 -42 296 144 -42 air
execute in minecraft:overworld run fill 296 58 -41 296 74 -41 stone
execute in minecraft:overworld run fill 296 75 -41 296 76 -41 dirt
execute in minecraft:overworld run setblock 296 77 -41 grass_block
execute in minecraft:overworld run fill 296 78 -41 296 144 -41 air
execute in minecraft:overworld run fill 296 58 -40 296 76 -40 stone
execute in minecraft:overworld run fill 296 77 -40 296 78 -40 dirt
execute in minecraft:overworld run setblock 296 79 -40 coarse_dirt
execute in minecraft:overworld run fill 296 80 -40 296 144 -40 air
execute in minecraft:overworld run fill 296 58 -39 296 76 -39 stone
execute in minecraft:overworld run fill 296 77 -39 296 78 -39 dirt
execute in minecraft:overworld run setblock 296 79 -39 grass_block
execute in minecraft:overworld run fill 296 80 -39 296 144 -39 air
execute in minecraft:overworld run fill 296 58 -38 296 76 -38 stone
execute in minecraft:overworld run fill 296 77 -38 296 78 -38 dirt
execute in minecraft:overworld run setblock 296 79 -38 grass_block
execute in minecraft:overworld run fill 296 80 -38 296 144 -38 air
execute in minecraft:overworld run fill 296 58 -37 296 75 -37 stone
execute in minecraft:overworld run fill 296 76 -37 296 77 -37 dirt
execute in minecraft:overworld run setblock 296 78 -37 coarse_dirt
execute in minecraft:overworld run fill 296 79 -37 296 144 -37 air
execute in minecraft:overworld run fill 296 58 -36 296 75 -36 stone
execute in minecraft:overworld run fill 296 76 -36 296 77 -36 dirt
execute in minecraft:overworld run setblock 296 78 -36 coarse_dirt
execute in minecraft:overworld run fill 296 79 -36 296 144 -36 air
schedule function blade_gallery:random/burned/part_139 1t replace
