data modify storage blade_gallery:state random_busy set value 1b
execute in minecraft:overworld run forceload add 208 -48 303 47
schedule function blade_gallery:random/burned/wait 1s replace
