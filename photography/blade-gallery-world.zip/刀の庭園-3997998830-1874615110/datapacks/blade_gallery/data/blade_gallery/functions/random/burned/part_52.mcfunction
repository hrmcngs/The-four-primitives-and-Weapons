execute in minecraft:overworld run fill 241 65 39 241 66 39 dirt
execute in minecraft:overworld run setblock 241 67 39 coarse_dirt
execute in minecraft:overworld run fill 241 68 39 241 144 39 air
execute in minecraft:overworld run fill 241 58 40 241 64 40 stone
execute in minecraft:overworld run fill 241 65 40 241 66 40 dirt
execute in minecraft:overworld run setblock 241 67 40 grass_block
execute in minecraft:overworld run fill 241 68 40 241 144 40 air
execute in minecraft:overworld run fill 241 58 41 241 64 41 stone
execute in minecraft:overworld run fill 241 65 41 241 66 41 dirt
execute in minecraft:overworld run setblock 241 67 41 grass_block
execute in minecraft:overworld run fill 241 68 41 241 144 41 air
execute in minecraft:overworld run setblock 241 68 41 grass
execute in minecraft:overworld run fill 241 58 42 241 63 42 stone
execute in minecraft:overworld run fill 241 64 42 241 65 42 dirt
execute in minecraft:overworld run setblock 241 66 42 coarse_dirt
execute in minecraft:overworld run fill 241 67 42 241 144 42 air
execute in minecraft:overworld run fill 241 58 43 241 63 43 stone
execute in minecraft:overworld run fill 241 64 43 241 65 43 dirt
execute in minecraft:overworld run setblock 241 66 43 grass_block
execute in minecraft:overworld run fill 241 67 43 241 144 43 air
execute in minecraft:overworld run fill 241 58 44 241 62 44 stone
execute in minecraft:overworld run fill 241 63 44 241 64 44 dirt
execute in minecraft:overworld run setblock 241 65 44 coarse_dirt
execute in minecraft:overworld run fill 241 66 44 241 144 44 air
execute in minecraft:overworld run fill 241 58 45 241 62 45 stone
execute in minecraft:overworld run fill 241 63 45 241 64 45 dirt
execute in minecraft:overworld run setblock 241 65 45 coarse_dirt
execute in minecraft:overworld run fill 241 66 45 241 144 45 air
execute in minecraft:overworld run fill 241 58 46 241 62 46 stone
execute in minecraft:overworld run fill 241 63 46 241 64 46 dirt
execute in minecraft:overworld run setblock 241 65 46 grass_block
execute in minecraft:overworld run fill 241 66 46 241 144 46 air
execute in minecraft:overworld run fill 241 58 47 241 61 47 stone
execute in minecraft:overworld run fill 241 62 47 241 63 47 dirt
execute in minecraft:overworld run setblock 241 64 47 coarse_dirt
execute in minecraft:overworld run fill 241 65 47 241 144 47 air
execute in minecraft:overworld run fill 242 58 -48 242 61 -48 stone
execute in minecraft:overworld run fill 242 62 -48 242 63 -48 dirt
execute in minecraft:overworld run setblock 242 64 -48 coarse_dirt
execute in minecraft:overworld run fill 242 65 -48 242 144 -48 air
execute in minecraft:overworld run fill 242 58 -47 242 62 -47 stone
execute in minecraft:overworld run fill 242 63 -47 242 64 -47 dirt
execute in minecraft:overworld run setblock 242 65 -47 coarse_dirt
execute in minecraft:overworld run fill 242 66 -47 242 144 -47 air
execute in minecraft:overworld run fill 242 58 -46 242 63 -46 stone
execute in minecraft:overworld run fill 242 64 -46 242 65 -46 dirt
execute in minecraft:overworld run setblock 242 66 -46 coarse_dirt
execute in minecraft:overworld run fill 242 67 -46 242 144 -46 air
execute in minecraft:overworld run fill 242 58 -45 242 64 -45 stone
execute in minecraft:overworld run fill 242 65 -45 242 66 -45 dirt
execute in minecraft:overworld run setblock 242 67 -45 grass_block
execute in minecraft:overworld run fill 242 68 -45 242 144 -45 air
execute in minecraft:overworld run fill 242 58 -44 242 65 -44 stone
execute in minecraft:overworld run fill 242 66 -44 242 67 -44 dirt
execute in minecraft:overworld run setblock 242 68 -44 coarse_dirt
execute in minecraft:overworld run fill 242 69 -44 242 144 -44 air
execute in minecraft:overworld run fill 242 58 -43 242 66 -43 stone
execute in minecraft:overworld run fill 242 67 -43 242 68 -43 dirt
execute in minecraft:overworld run setblock 242 69 -43 coarse_dirt
execute in minecraft:overworld run fill 242 70 -43 242 144 -43 air
execute in minecraft:overworld run fill 242 58 -42 242 67 -42 stone
execute in minecraft:overworld run fill 242 68 -42 242 69 -42 dirt
execute in minecraft:overworld run setblock 242 70 -42 grass_block
execute in minecraft:overworld run fill 242 71 -42 242 144 -42 air
execute in minecraft:overworld run fill 242 58 -41 242 68 -41 stone
execute in minecraft:overworld run fill 242 69 -41 242 70 -41 dirt
execute in minecraft:overworld run setblock 242 71 -41 coarse_dirt
execute in minecraft:overworld run fill 242 72 -41 242 144 -41 air
execute in minecraft:overworld run fill 242 58 -40 242 68 -40 stone
execute in minecraft:overworld run fill 242 69 -40 242 70 -40 dirt
execute in minecraft:overworld run setblock 242 71 -40 coarse_dirt
execute in minecraft:overworld run fill 242 72 -40 242 144 -40 air
execute in minecraft:overworld run fill 242 58 -39 242 69 -39 stone
execute in minecraft:overworld run fill 242 70 -39 242 71 -39 dirt
execute in minecraft:overworld run setblock 242 72 -39 coarse_dirt
execute in minecraft:overworld run fill 242 73 -39 242 144 -39 air
execute in minecraft:overworld run fill 242 58 -38 242 70 -38 stone
execute in minecraft:overworld run fill 242 71 -38 242 72 -38 dirt
execute in minecraft:overworld run setblock 242 73 -38 grass_block
execute in minecraft:overworld run fill 242 74 -38 242 144 -38 air
execute in minecraft:overworld run fill 242 58 -37 242 70 -37 stone
execute in minecraft:overworld run fill 242 71 -37 242 72 -37 dirt
execute in minecraft:overworld run setblock 242 73 -37 coarse_dirt
execute in minecraft:overworld run fill 242 74 -37 242 144 -37 air
execute in minecraft:overworld run fill 242 58 -36 242 70 -36 stone
execute in minecraft:overworld run fill 242 71 -36 242 72 -36 dirt
execute in minecraft:overworld run setblock 242 73 -36 coarse_dirt
execute in minecraft:overworld run fill 242 74 -36 242 144 -36 air
execute in minecraft:overworld run fill 242 58 -35 242 71 -35 stone
execute in minecraft:overworld run fill 242 72 -35 242 73 -35 dirt
execute in minecraft:overworld run setblock 242 74 -35 coarse_dirt
execute in minecraft:overworld run fill 242 75 -35 242 144 -35 air
execute in minecraft:overworld run fill 242 58 -34 242 71 -34 stone
execute in minecraft:overworld run fill 242 72 -34 242 73 -34 dirt
execute in minecraft:overworld run setblock 242 74 -34 coarse_dirt
execute in minecraft:overworld run fill 242 75 -34 242 144 -34 air
execute in minecraft:overworld run fill 242 58 -33 242 71 -33 stone
execute in minecraft:overworld run fill 242 72 -33 242 73 -33 dirt
execute in minecraft:overworld run setblock 242 74 -33 grass_block
execute in minecraft:overworld run fill 242 75 -33 242 144 -33 air
execute in minecraft:overworld run setblock 242 75 -33 grass
execute in minecraft:overworld run fill 242 58 -32 242 71 -32 stone
execute in minecraft:overworld run fill 242 72 -32 242 73 -32 dirt
execute in minecraft:overworld run setblock 242 74 -32 coarse_dirt
execute in minecraft:overworld run fill 242 75 -32 242 144 -32 air
execute in minecraft:overworld run fill 242 58 -31 242 71 -31 stone
execute in minecraft:overworld run fill 242 72 -31 242 73 -31 dirt
execute in minecraft:overworld run setblock 242 74 -31 coarse_dirt
execute in minecraft:overworld run fill 242 75 -31 242 144 -31 air
execute in minecraft:overworld run fill 242 58 -30 242 71 -30 stone
execute in minecraft:overworld run fill 242 72 -30 242 73 -30 dirt
execute in minecraft:overworld run setblock 242 74 -30 coarse_dirt
execute in minecraft:overworld run fill 242 75 -30 242 144 -30 air
execute in minecraft:overworld run fill 242 58 -29 242 71 -29 stone
execute in minecraft:overworld run fill 242 72 -29 242 73 -29 dirt
execute in minecraft:overworld run setblock 242 74 -29 coarse_dirt
execute in minecraft:overworld run fill 242 75 -29 242 144 -29 air
execute in minecraft:overworld run fill 242 58 -28 242 71 -28 stone
execute in minecraft:overworld run fill 242 72 -28 242 73 -28 dirt
execute in minecraft:overworld run setblock 242 74 -28 grass_block
execute in minecraft:overworld run fill 242 75 -28 242 144 -28 air
execute in minecraft:overworld run fill 242 58 -27 242 71 -27 stone
execute in minecraft:overworld run fill 242 72 -27 242 73 -27 dirt
execute in minecraft:overworld run setblock 242 74 -27 grass_block
execute in minecraft:overworld run fill 242 75 -27 242 144 -27 air
execute in minecraft:overworld run fill 242 58 -26 242 71 -26 stone
execute in minecraft:overworld run fill 242 72 -26 242 73 -26 dirt
execute in minecraft:overworld run setblock 242 74 -26 coarse_dirt
execute in minecraft:overworld run fill 242 75 -26 242 144 -26 air
execute in minecraft:overworld run fill 242 58 -25 242 70 -25 stone
execute in minecraft:overworld run fill 242 71 -25 242 72 -25 dirt
execute in minecraft:overworld run setblock 242 73 -25 coarse_dirt
execute in minecraft:overworld run fill 242 74 -25 242 144 -25 air
execute in minecraft:overworld run fill 242 58 -24 242 70 -24 stone
execute in minecraft:overworld run fill 242 71 -24 242 72 -24 dirt
execute in minecraft:overworld run setblock 242 73 -24 coarse_dirt
execute in minecraft:overworld run fill 242 74 -24 242 144 -24 air
execute in minecraft:overworld run fill 242 58 -23 242 70 -23 stone
execute in minecraft:overworld run fill 242 71 -23 242 72 -23 dirt
execute in minecraft:overworld run setblock 242 73 -23 coarse_dirt
execute in minecraft:overworld run fill 242 74 -23 242 144 -23 air
execute in minecraft:overworld run fill 242 58 -22 242 69 -22 stone
execute in minecraft:overworld run fill 242 70 -22 242 71 -22 dirt
execute in minecraft:overworld run setblock 242 72 -22 grass_block
execute in minecraft:overworld run fill 242 73 -22 242 144 -22 air
execute in minecraft:overworld run fill 242 58 -21 242 69 -21 stone
execute in minecraft:overworld run fill 242 70 -21 242 71 -21 dirt
execute in minecraft:overworld run setblock 242 72 -21 grass_block
execute in minecraft:overworld run fill 242 73 -21 242 144 -21 air
execute in minecraft:overworld run fill 242 58 -20 242 68 -20 stone
execute in minecraft:overworld run fill 242 69 -20 242 70 -20 dirt
execute in minecraft:overworld run setblock 242 71 -20 coarse_dirt
execute in minecraft:overworld run fill 242 72 -20 242 144 -20 air
execute in minecraft:overworld run fill 242 58 -19 242 68 -19 stone
execute in minecraft:overworld run fill 242 69 -19 242 70 -19 dirt
execute in minecraft:overworld run setblock 242 71 -19 grass_block
execute in minecraft:overworld run fill 242 72 -19 242 144 -19 air
execute in minecraft:overworld run fill 242 58 -18 242 67 -18 stone
execute in minecraft:overworld run fill 242 68 -18 242 69 -18 dirt
execute in minecraft:overworld run setblock 242 70 -18 coarse_dirt
execute in minecraft:overworld run fill 242 71 -18 242 144 -18 air
execute in minecraft:overworld run fill 242 58 -17 242 67 -17 stone
execute in minecraft:overworld run fill 242 68 -17 242 69 -17 dirt
execute in minecraft:overworld run setblock 242 70 -17 coarse_dirt
execute in minecraft:overworld run fill 242 71 -17 242 144 -17 air
execute in minecraft:overworld run fill 242 58 -16 242 66 -16 stone
execute in minecraft:overworld run fill 242 67 -16 242 68 -16 dirt
execute in minecraft:overworld run setblock 242 69 -16 grass_block
execute in minecraft:overworld run fill 242 70 -16 242 144 -16 air
execute in minecraft:overworld run fill 242 58 -15 242 66 -15 stone
execute in minecraft:overworld run fill 242 67 -15 242 68 -15 dirt
execute in minecraft:overworld run setblock 242 69 -15 coarse_dirt
execute in minecraft:overworld run fill 242 70 -15 242 144 -15 air
execute in minecraft:overworld run fill 242 58 -14 242 65 -14 stone
execute in minecraft:overworld run fill 242 66 -14 242 67 -14 dirt
execute in minecraft:overworld run setblock 242 68 -14 coarse_dirt
execute in minecraft:overworld run fill 242 69 -14 242 144 -14 air
execute in minecraft:overworld run fill 242 58 -13 242 65 -13 stone
execute in minecraft:overworld run fill 242 66 -13 242 67 -13 dirt
execute in minecraft:overworld run setblock 242 68 -13 grass_block
execute in minecraft:overworld run fill 242 69 -13 242 144 -13 air
execute in minecraft:overworld run fill 242 58 -12 242 64 -12 stone
execute in minecraft:overworld run fill 242 65 -12 242 66 -12 dirt
execute in minecraft:overworld run setblock 242 67 -12 coarse_dirt
execute in minecraft:overworld run fill 242 68 -12 242 144 -12 air
execute in minecraft:overworld run fill 242 58 -11 242 64 -11 stone
execute in minecraft:overworld run fill 242 65 -11 242 66 -11 dirt
execute in minecraft:overworld run setblock 242 67 -11 coarse_dirt
execute in minecraft:overworld run fill 242 68 -11 242 144 -11 air
execute in minecraft:overworld run fill 242 58 -10 242 64 -10 stone
execute in minecraft:overworld run fill 242 65 -10 242 66 -10 dirt
execute in minecraft:overworld run setblock 242 67 -10 grass_block
execute in minecraft:overworld run fill 242 68 -10 242 144 -10 air
execute in minecraft:overworld run fill 242 58 -9 242 64 -9 stone
execute in minecraft:overworld run fill 242 65 -9 242 66 -9 dirt
execute in minecraft:overworld run setblock 242 67 -9 grass_block
execute in minecraft:overworld run fill 242 68 -9 242 144 -9 air
execute in minecraft:overworld run setblock 242 68 -9 grass
execute in minecraft:overworld run fill 242 58 -8 242 64 -8 stone
execute in minecraft:overworld run fill 242 65 -8 242 66 -8 dirt
execute in minecraft:overworld run setblock 242 67 -8 coarse_dirt
execute in minecraft:overworld run fill 242 68 -8 242 144 -8 air
execute in minecraft:overworld run fill 242 58 -7 242 63 -7 stone
execute in minecraft:overworld run fill 242 64 -7 242 65 -7 dirt
execute in minecraft:overworld run setblock 242 66 -7 grass_block
execute in minecraft:overworld run fill 242 67 -7 242 144 -7 air
execute in minecraft:overworld run fill 242 58 -6 242 63 -6 stone
execute in minecraft:overworld run fill 242 64 -6 242 65 -6 dirt
execute in minecraft:overworld run setblock 242 66 -6 grass_block
execute in minecraft:overworld run fill 242 67 -6 242 144 -6 air
execute in minecraft:overworld run setblock 242 67 -6 grass
execute in minecraft:overworld run fill 242 58 -5 242 63 -5 stone
execute in minecraft:overworld run fill 242 64 -5 242 65 -5 dirt
execute in minecraft:overworld run setblock 242 66 -5 coarse_dirt
execute in minecraft:overworld run fill 242 67 -5 242 144 -5 air
execute in minecraft:overworld run setblock 242 67 -5 mossy_cobblestone
execute in minecraft:overworld run fill 242 58 -4 242 63 -4 stone
execute in minecraft:overworld run fill 242 64 -4 242 65 -4 dirt
execute in minecraft:overworld run setblock 242 66 -4 grass_block
execute in minecraft:overworld run fill 242 67 -4 242 144 -4 air
execute in minecraft:overworld run fill 242 58 -3 242 62 -3 stone
execute in minecraft:overworld run fill 242 63 -3 242 64 -3 dirt
execute in minecraft:overworld run setblock 242 65 -3 coarse_dirt
execute in minecraft:overworld run fill 242 66 -3 242 144 -3 air
execute in minecraft:overworld run fill 242 58 -2 242 62 -2 stone
execute in minecraft:overworld run fill 242 63 -2 242 64 -2 dirt
execute in minecraft:overworld run setblock 242 65 -2 coarse_dirt
execute in minecraft:overworld run fill 242 66 -2 242 144 -2 air
execute in minecraft:overworld run fill 242 58 -1 242 62 -1 stone
execute in minecraft:overworld run fill 242 63 -1 242 64 -1 dirt
execute in minecraft:overworld run setblock 242 65 -1 coarse_dirt
execute in minecraft:overworld run fill 242 66 -1 242 144 -1 air
execute in minecraft:overworld run fill 242 58 0 242 62 0 stone
execute in minecraft:overworld run fill 242 63 0 242 64 0 dirt
execute in minecraft:overworld run setblock 242 65 0 coarse_dirt
execute in minecraft:overworld run fill 242 66 0 242 144 0 air
execute in minecraft:overworld run fill 242 58 1 242 62 1 stone
execute in minecraft:overworld run fill 242 63 1 242 64 1 dirt
execute in minecraft:overworld run setblock 242 65 1 coarse_dirt
execute in minecraft:overworld run fill 242 66 1 242 144 1 air
execute in minecraft:overworld run fill 242 58 2 242 62 2 stone
execute in minecraft:overworld run fill 242 63 2 242 64 2 dirt
execute in minecraft:overworld run setblock 242 65 2 grass_block
execute in minecraft:overworld run fill 242 66 2 242 144 2 air
execute in minecraft:overworld run fill 242 58 3 242 63 3 stone
execute in minecraft:overworld run fill 242 64 3 242 65 3 dirt
execute in minecraft:overworld run setblock 242 66 3 coarse_dirt
execute in minecraft:overworld run fill 242 67 3 242 144 3 air
execute in minecraft:overworld run fill 242 58 4 242 63 4 stone
execute in minecraft:overworld run fill 242 64 4 242 65 4 dirt
execute in minecraft:overworld run setblock 242 66 4 grass_block
execute in minecraft:overworld run fill 242 67 4 242 144 4 air
execute in minecraft:overworld run fill 242 58 5 242 63 5 stone
execute in minecraft:overworld run fill 242 64 5 242 65 5 dirt
execute in minecraft:overworld run setblock 242 66 5 coarse_dirt
execute in minecraft:overworld run fill 242 67 5 242 144 5 air
schedule function blade_gallery:random/burned/part_53 1t replace
