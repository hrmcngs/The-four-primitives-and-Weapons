execute in minecraft:overworld run tp @s 502 74 22 facing 512 76 -12
