execute in minecraft:overworld run fill 216 70 9 216 144 9 air
execute in minecraft:overworld run fill 216 58 10 216 66 10 stone
execute in minecraft:overworld run fill 216 67 10 216 68 10 dirt
execute in minecraft:overworld run setblock 216 69 10 grass_block
execute in minecraft:overworld run fill 216 70 10 216 144 10 air
execute in minecraft:overworld run fill 216 58 11 216 66 11 stone
execute in minecraft:overworld run fill 216 67 11 216 68 11 dirt
execute in minecraft:overworld run setblock 216 69 11 coarse_dirt
execute in minecraft:overworld run fill 216 70 11 216 144 11 air
execute in minecraft:overworld run fill 216 58 12 216 66 12 stone
execute in minecraft:overworld run fill 216 67 12 216 68 12 dirt
execute in minecraft:overworld run setblock 216 69 12 grass_block
execute in minecraft:overworld run fill 216 70 12 216 144 12 air
execute in minecraft:overworld run fill 216 58 13 216 67 13 stone
execute in minecraft:overworld run fill 216 68 13 216 69 13 dirt
execute in minecraft:overworld run setblock 216 70 13 coarse_dirt
execute in minecraft:overworld run fill 216 71 13 216 144 13 air
execute in minecraft:overworld run fill 216 58 14 216 67 14 stone
execute in minecraft:overworld run fill 216 68 14 216 69 14 dirt
execute in minecraft:overworld run setblock 216 70 14 grass_block
execute in minecraft:overworld run fill 216 71 14 216 144 14 air
execute in minecraft:overworld run fill 216 58 15 216 67 15 stone
execute in minecraft:overworld run fill 216 68 15 216 69 15 dirt
execute in minecraft:overworld run setblock 216 70 15 coarse_dirt
execute in minecraft:overworld run fill 216 71 15 216 144 15 air
execute in minecraft:overworld run fill 216 58 16 216 68 16 stone
execute in minecraft:overworld run fill 216 69 16 216 70 16 dirt
execute in minecraft:overworld run setblock 216 71 16 grass_block
execute in minecraft:overworld run fill 216 72 16 216 144 16 air
execute in minecraft:overworld run fill 216 58 17 216 68 17 stone
execute in minecraft:overworld run fill 216 69 17 216 70 17 dirt
execute in minecraft:overworld run setblock 216 71 17 coarse_dirt
execute in minecraft:overworld run fill 216 72 17 216 144 17 air
execute in minecraft:overworld run fill 216 58 18 216 68 18 stone
execute in minecraft:overworld run fill 216 69 18 216 70 18 dirt
execute in minecraft:overworld run setblock 216 71 18 coarse_dirt
execute in minecraft:overworld run fill 216 72 18 216 144 18 air
execute in minecraft:overworld run fill 216 58 19 216 68 19 stone
execute in minecraft:overworld run fill 216 69 19 216 70 19 dirt
execute in minecraft:overworld run setblock 216 71 19 grass_block
execute in minecraft:overworld run fill 216 72 19 216 144 19 air
execute in minecraft:overworld run fill 216 58 20 216 68 20 stone
execute in minecraft:overworld run fill 216 69 20 216 70 20 dirt
execute in minecraft:overworld run setblock 216 71 20 coarse_dirt
execute in minecraft:overworld run fill 216 72 20 216 144 20 air
execute in minecraft:overworld run fill 216 58 21 216 68 21 stone
execute in minecraft:overworld run fill 216 69 21 216 70 21 dirt
execute in minecraft:overworld run setblock 216 71 21 coarse_dirt
execute in minecraft:overworld run fill 216 72 21 216 144 21 air
execute in minecraft:overworld run fill 216 58 22 216 68 22 stone
execute in minecraft:overworld run fill 216 69 22 216 70 22 dirt
execute in minecraft:overworld run setblock 216 71 22 grass_block
execute in minecraft:overworld run fill 216 72 22 216 144 22 air
execute in minecraft:overworld run fill 216 58 23 216 68 23 stone
execute in minecraft:overworld run fill 216 69 23 216 70 23 dirt
execute in minecraft:overworld run setblock 216 71 23 coarse_dirt
execute in minecraft:overworld run fill 216 72 23 216 144 23 air
execute in minecraft:overworld run fill 216 58 24 216 69 24 stone
execute in minecraft:overworld run fill 216 70 24 216 71 24 dirt
execute in minecraft:overworld run setblock 216 72 24 coarse_dirt
execute in minecraft:overworld run fill 216 73 24 216 144 24 air
execute in minecraft:overworld run setblock 216 73 24 grass
execute in minecraft:overworld run fill 216 58 25 216 69 25 stone
execute in minecraft:overworld run fill 216 70 25 216 71 25 dirt
execute in minecraft:overworld run setblock 216 72 25 coarse_dirt
execute in minecraft:overworld run fill 216 73 25 216 144 25 air
execute in minecraft:overworld run fill 216 58 26 216 69 26 stone
execute in minecraft:overworld run fill 216 70 26 216 71 26 dirt
execute in minecraft:overworld run setblock 216 72 26 grass_block
execute in minecraft:overworld run fill 216 73 26 216 144 26 air
execute in minecraft:overworld run fill 216 58 27 216 69 27 stone
execute in minecraft:overworld run fill 216 70 27 216 71 27 dirt
execute in minecraft:overworld run setblock 216 72 27 grass_block
execute in minecraft:overworld run fill 216 73 27 216 144 27 air
execute in minecraft:overworld run fill 216 58 28 216 69 28 stone
execute in minecraft:overworld run fill 216 70 28 216 71 28 dirt
execute in minecraft:overworld run setblock 216 72 28 grass_block
execute in minecraft:overworld run fill 216 73 28 216 144 28 air
execute in minecraft:overworld run fill 216 58 29 216 69 29 stone
execute in minecraft:overworld run fill 216 70 29 216 71 29 dirt
execute in minecraft:overworld run setblock 216 72 29 grass_block
execute in minecraft:overworld run fill 216 73 29 216 144 29 air
execute in minecraft:overworld run fill 216 58 30 216 69 30 stone
execute in minecraft:overworld run fill 216 70 30 216 71 30 dirt
execute in minecraft:overworld run setblock 216 72 30 coarse_dirt
execute in minecraft:overworld run fill 216 73 30 216 144 30 air
execute in minecraft:overworld run fill 216 58 31 216 68 31 stone
execute in minecraft:overworld run fill 216 69 31 216 70 31 dirt
execute in minecraft:overworld run setblock 216 71 31 grass_block
execute in minecraft:overworld run fill 216 72 31 216 144 31 air
execute in minecraft:overworld run fill 216 58 32 216 68 32 stone
execute in minecraft:overworld run fill 216 69 32 216 70 32 dirt
execute in minecraft:overworld run setblock 216 71 32 grass_block
execute in minecraft:overworld run fill 216 72 32 216 144 32 air
execute in minecraft:overworld run fill 216 58 33 216 68 33 stone
execute in minecraft:overworld run fill 216 69 33 216 70 33 dirt
execute in minecraft:overworld run setblock 216 71 33 grass_block
execute in minecraft:overworld run fill 216 72 33 216 144 33 air
execute in minecraft:overworld run fill 216 58 34 216 68 34 stone
execute in minecraft:overworld run fill 216 69 34 216 70 34 dirt
execute in minecraft:overworld run setblock 216 71 34 grass_block
execute in minecraft:overworld run fill 216 72 34 216 144 34 air
execute in minecraft:overworld run setblock 216 72 34 grass
execute in minecraft:overworld run fill 216 58 35 216 67 35 stone
execute in minecraft:overworld run fill 216 68 35 216 69 35 dirt
execute in minecraft:overworld run setblock 216 70 35 coarse_dirt
execute in minecraft:overworld run fill 216 71 35 216 144 35 air
execute in minecraft:overworld run fill 216 58 36 216 67 36 stone
execute in minecraft:overworld run fill 216 68 36 216 69 36 dirt
execute in minecraft:overworld run setblock 216 70 36 coarse_dirt
execute in minecraft:overworld run fill 216 71 36 216 144 36 air
execute in minecraft:overworld run fill 216 58 37 216 67 37 stone
execute in minecraft:overworld run fill 216 68 37 216 69 37 dirt
execute in minecraft:overworld run setblock 216 70 37 grass_block
execute in minecraft:overworld run fill 216 71 37 216 144 37 air
execute in minecraft:overworld run fill 216 58 38 216 67 38 stone
execute in minecraft:overworld run fill 216 68 38 216 69 38 dirt
execute in minecraft:overworld run setblock 216 70 38 coarse_dirt
execute in minecraft:overworld run fill 216 71 38 216 144 38 air
execute in minecraft:overworld run setblock 216 71 38 grass
execute in minecraft:overworld run fill 216 58 39 216 66 39 stone
execute in minecraft:overworld run fill 216 67 39 216 68 39 dirt
execute in minecraft:overworld run setblock 216 69 39 coarse_dirt
execute in minecraft:overworld run fill 216 70 39 216 144 39 air
execute in minecraft:overworld run setblock 216 70 39 grass
execute in minecraft:overworld run fill 216 58 40 216 66 40 stone
execute in minecraft:overworld run fill 216 67 40 216 68 40 dirt
execute in minecraft:overworld run setblock 216 69 40 grass_block
execute in minecraft:overworld run fill 216 70 40 216 144 40 air
execute in minecraft:overworld run fill 216 58 41 216 65 41 stone
execute in minecraft:overworld run fill 216 66 41 216 67 41 dirt
execute in minecraft:overworld run setblock 216 68 41 grass_block
execute in minecraft:overworld run fill 216 69 41 216 144 41 air
execute in minecraft:overworld run fill 216 58 42 216 64 42 stone
execute in minecraft:overworld run fill 216 65 42 216 66 42 dirt
execute in minecraft:overworld run setblock 216 67 42 coarse_dirt
execute in minecraft:overworld run fill 216 68 42 216 144 42 air
execute in minecraft:overworld run fill 216 58 43 216 64 43 stone
execute in minecraft:overworld run fill 216 65 43 216 66 43 dirt
execute in minecraft:overworld run setblock 216 67 43 coarse_dirt
execute in minecraft:overworld run fill 216 68 43 216 144 43 air
execute in minecraft:overworld run fill 216 58 44 216 63 44 stone
execute in minecraft:overworld run fill 216 64 44 216 65 44 dirt
execute in minecraft:overworld run setblock 216 66 44 grass_block
execute in minecraft:overworld run fill 216 67 44 216 144 44 air
execute in minecraft:overworld run fill 216 58 45 216 62 45 stone
execute in minecraft:overworld run fill 216 63 45 216 64 45 dirt
execute in minecraft:overworld run setblock 216 65 45 coarse_dirt
execute in minecraft:overworld run fill 216 66 45 216 144 45 air
execute in minecraft:overworld run fill 216 58 46 216 62 46 stone
execute in minecraft:overworld run fill 216 63 46 216 64 46 dirt
execute in minecraft:overworld run setblock 216 65 46 coarse_dirt
execute in minecraft:overworld run fill 216 66 46 216 144 46 air
execute in minecraft:overworld run fill 216 58 47 216 61 47 stone
execute in minecraft:overworld run fill 216 62 47 216 63 47 dirt
execute in minecraft:overworld run setblock 216 64 47 coarse_dirt
execute in minecraft:overworld run fill 216 65 47 216 144 47 air
execute in minecraft:overworld run fill 217 58 -48 217 61 -48 stone
execute in minecraft:overworld run fill 217 62 -48 217 63 -48 dirt
execute in minecraft:overworld run setblock 217 64 -48 coarse_dirt
execute in minecraft:overworld run fill 217 65 -48 217 144 -48 air
execute in minecraft:overworld run fill 217 58 -47 217 63 -47 stone
execute in minecraft:overworld run fill 217 64 -47 217 65 -47 dirt
execute in minecraft:overworld run setblock 217 66 -47 grass_block
execute in minecraft:overworld run fill 217 67 -47 217 144 -47 air
execute in minecraft:overworld run fill 217 58 -46 217 64 -46 stone
execute in minecraft:overworld run fill 217 65 -46 217 66 -46 dirt
execute in minecraft:overworld run setblock 217 67 -46 coarse_dirt
execute in minecraft:overworld run fill 217 68 -46 217 144 -46 air
execute in minecraft:overworld run fill 217 58 -45 217 66 -45 stone
execute in minecraft:overworld run fill 217 67 -45 217 68 -45 dirt
execute in minecraft:overworld run setblock 217 69 -45 coarse_dirt
execute in minecraft:overworld run fill 217 70 -45 217 144 -45 air
execute in minecraft:overworld run fill 217 58 -44 217 67 -44 stone
execute in minecraft:overworld run fill 217 68 -44 217 69 -44 dirt
execute in minecraft:overworld run setblock 217 70 -44 grass_block
execute in minecraft:overworld run fill 217 71 -44 217 144 -44 air
execute in minecraft:overworld run fill 217 58 -43 217 68 -43 stone
execute in minecraft:overworld run fill 217 69 -43 217 70 -43 dirt
execute in minecraft:overworld run setblock 217 71 -43 coarse_dirt
execute in minecraft:overworld run fill 217 72 -43 217 144 -43 air
execute in minecraft:overworld run fill 217 58 -42 217 69 -42 stone
execute in minecraft:overworld run fill 217 70 -42 217 71 -42 dirt
execute in minecraft:overworld run setblock 217 72 -42 grass_block
execute in minecraft:overworld run fill 217 73 -42 217 144 -42 air
execute in minecraft:overworld run fill 217 58 -41 217 70 -41 stone
execute in minecraft:overworld run fill 217 71 -41 217 72 -41 dirt
execute in minecraft:overworld run setblock 217 73 -41 coarse_dirt
execute in minecraft:overworld run fill 217 74 -41 217 144 -41 air
execute in minecraft:overworld run fill 217 58 -40 217 71 -40 stone
execute in minecraft:overworld run fill 217 72 -40 217 73 -40 dirt
execute in minecraft:overworld run setblock 217 74 -40 grass_block
execute in minecraft:overworld run fill 217 75 -40 217 144 -40 air
execute in minecraft:overworld run fill 217 58 -39 217 71 -39 stone
execute in minecraft:overworld run fill 217 72 -39 217 73 -39 dirt
execute in minecraft:overworld run setblock 217 74 -39 grass_block
execute in minecraft:overworld run fill 217 75 -39 217 144 -39 air
execute in minecraft:overworld run setblock 217 75 -39 grass
execute in minecraft:overworld run fill 217 58 -38 217 71 -38 stone
execute in minecraft:overworld run fill 217 72 -38 217 73 -38 dirt
execute in minecraft:overworld run setblock 217 74 -38 grass_block
execute in minecraft:overworld run fill 217 75 -38 217 144 -38 air
execute in minecraft:overworld run fill 217 58 -37 217 70 -37 stone
execute in minecraft:overworld run fill 217 71 -37 217 72 -37 dirt
execute in minecraft:overworld run setblock 217 73 -37 coarse_dirt
execute in minecraft:overworld run fill 217 74 -37 217 144 -37 air
execute in minecraft:overworld run fill 217 58 -36 217 69 -36 stone
execute in minecraft:overworld run fill 217 70 -36 217 71 -36 dirt
execute in minecraft:overworld run setblock 217 72 -36 grass_block
execute in minecraft:overworld run fill 217 73 -36 217 144 -36 air
execute in minecraft:overworld run fill 217 58 -35 217 69 -35 stone
execute in minecraft:overworld run fill 217 70 -35 217 71 -35 dirt
execute in minecraft:overworld run setblock 217 72 -35 coarse_dirt
execute in minecraft:overworld run fill 217 73 -35 217 144 -35 air
execute in minecraft:overworld run fill 217 58 -34 217 68 -34 stone
execute in minecraft:overworld run fill 217 69 -34 217 70 -34 dirt
execute in minecraft:overworld run setblock 217 71 -34 coarse_dirt
execute in minecraft:overworld run fill 217 72 -34 217 144 -34 air
execute in minecraft:overworld run fill 217 58 -33 217 67 -33 stone
execute in minecraft:overworld run fill 217 68 -33 217 69 -33 dirt
execute in minecraft:overworld run setblock 217 70 -33 grass_block
execute in minecraft:overworld run fill 217 71 -33 217 144 -33 air
execute in minecraft:overworld run fill 217 58 -32 217 67 -32 stone
execute in minecraft:overworld run fill 217 68 -32 217 69 -32 dirt
execute in minecraft:overworld run setblock 217 70 -32 grass_block
execute in minecraft:overworld run fill 217 71 -32 217 144 -32 air
execute in minecraft:overworld run fill 217 58 -31 217 66 -31 stone
execute in minecraft:overworld run fill 217 67 -31 217 68 -31 dirt
execute in minecraft:overworld run setblock 217 69 -31 coarse_dirt
execute in minecraft:overworld run fill 217 70 -31 217 144 -31 air
execute in minecraft:overworld run fill 217 58 -30 217 66 -30 stone
execute in minecraft:overworld run fill 217 67 -30 217 68 -30 dirt
execute in minecraft:overworld run setblock 217 69 -30 coarse_dirt
execute in minecraft:overworld run fill 217 70 -30 217 144 -30 air
execute in minecraft:overworld run fill 217 58 -29 217 66 -29 stone
execute in minecraft:overworld run fill 217 67 -29 217 68 -29 dirt
execute in minecraft:overworld run setblock 217 69 -29 coarse_dirt
execute in minecraft:overworld run fill 217 70 -29 217 144 -29 air
execute in minecraft:overworld run fill 217 58 -28 217 65 -28 stone
execute in minecraft:overworld run fill 217 66 -28 217 67 -28 dirt
execute in minecraft:overworld run setblock 217 68 -28 coarse_dirt
execute in minecraft:overworld run fill 217 69 -28 217 144 -28 air
execute in minecraft:overworld run fill 217 58 -27 217 65 -27 stone
execute in minecraft:overworld run fill 217 66 -27 217 67 -27 dirt
execute in minecraft:overworld run setblock 217 68 -27 grass_block
execute in minecraft:overworld run fill 217 69 -27 217 144 -27 air
execute in minecraft:overworld run fill 217 58 -26 217 65 -26 stone
execute in minecraft:overworld run fill 217 66 -26 217 67 -26 dirt
execute in minecraft:overworld run setblock 217 68 -26 coarse_dirt
execute in minecraft:overworld run fill 217 69 -26 217 144 -26 air
execute in minecraft:overworld run fill 217 58 -25 217 65 -25 stone
execute in minecraft:overworld run fill 217 66 -25 217 67 -25 dirt
execute in minecraft:overworld run setblock 217 68 -25 grass_block
execute in minecraft:overworld run fill 217 69 -25 217 144 -25 air
execute in minecraft:overworld run fill 217 58 -24 217 65 -24 stone
execute in minecraft:overworld run fill 217 66 -24 217 67 -24 dirt
schedule function blade_gallery:random/burned/part_14 1t replace
