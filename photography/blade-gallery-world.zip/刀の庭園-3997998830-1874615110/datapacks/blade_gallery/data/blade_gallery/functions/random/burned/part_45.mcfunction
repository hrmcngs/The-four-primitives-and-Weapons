execute in minecraft:overworld run fill 237 58 -13 237 65 -13 stone
execute in minecraft:overworld run fill 237 66 -13 237 67 -13 dirt
execute in minecraft:overworld run setblock 237 68 -13 coarse_dirt
execute in minecraft:overworld run fill 237 69 -13 237 144 -13 air
execute in minecraft:overworld run fill 237 58 -12 237 65 -12 stone
execute in minecraft:overworld run fill 237 66 -12 237 67 -12 dirt
execute in minecraft:overworld run setblock 237 68 -12 coarse_dirt
execute in minecraft:overworld run fill 237 69 -12 237 144 -12 air
execute in minecraft:overworld run fill 237 58 -11 237 65 -11 stone
execute in minecraft:overworld run fill 237 66 -11 237 67 -11 dirt
execute in minecraft:overworld run setblock 237 68 -11 coarse_dirt
execute in minecraft:overworld run fill 237 69 -11 237 144 -11 air
execute in minecraft:overworld run setblock 237 69 -11 grass
execute in minecraft:overworld run fill 237 58 -10 237 65 -10 stone
execute in minecraft:overworld run fill 237 66 -10 237 67 -10 dirt
execute in minecraft:overworld run setblock 237 68 -10 coarse_dirt
execute in minecraft:overworld run fill 237 69 -10 237 144 -10 air
execute in minecraft:overworld run fill 237 58 -9 237 64 -9 stone
execute in minecraft:overworld run fill 237 65 -9 237 66 -9 dirt
execute in minecraft:overworld run setblock 237 67 -9 coarse_dirt
execute in minecraft:overworld run fill 237 68 -9 237 144 -9 air
execute in minecraft:overworld run fill 237 58 -8 237 64 -8 stone
execute in minecraft:overworld run fill 237 65 -8 237 66 -8 dirt
execute in minecraft:overworld run setblock 237 67 -8 coarse_dirt
execute in minecraft:overworld run fill 237 68 -8 237 144 -8 air
execute in minecraft:overworld run fill 237 58 -7 237 64 -7 stone
execute in minecraft:overworld run fill 237 65 -7 237 66 -7 dirt
execute in minecraft:overworld run setblock 237 67 -7 grass_block
execute in minecraft:overworld run fill 237 68 -7 237 144 -7 air
execute in minecraft:overworld run fill 237 58 -6 237 64 -6 stone
execute in minecraft:overworld run fill 237 65 -6 237 66 -6 dirt
execute in minecraft:overworld run setblock 237 67 -6 coarse_dirt
execute in minecraft:overworld run fill 237 68 -6 237 144 -6 air
execute in minecraft:overworld run fill 237 58 -5 237 64 -5 stone
execute in minecraft:overworld run fill 237 65 -5 237 66 -5 dirt
execute in minecraft:overworld run setblock 237 67 -5 coarse_dirt
execute in minecraft:overworld run fill 237 68 -5 237 144 -5 air
execute in minecraft:overworld run fill 237 58 -4 237 64 -4 stone
execute in minecraft:overworld run fill 237 65 -4 237 66 -4 dirt
execute in minecraft:overworld run setblock 237 67 -4 coarse_dirt
execute in minecraft:overworld run fill 237 68 -4 237 144 -4 air
execute in minecraft:overworld run fill 237 58 -3 237 64 -3 stone
execute in minecraft:overworld run fill 237 65 -3 237 66 -3 dirt
execute in minecraft:overworld run setblock 237 67 -3 coarse_dirt
execute in minecraft:overworld run fill 237 68 -3 237 144 -3 air
execute in minecraft:overworld run setblock 237 68 -3 mossy_cobblestone
execute in minecraft:overworld run fill 237 58 -2 237 63 -2 stone
execute in minecraft:overworld run fill 237 64 -2 237 65 -2 dirt
execute in minecraft:overworld run setblock 237 66 -2 grass_block
execute in minecraft:overworld run fill 237 67 -2 237 144 -2 air
execute in minecraft:overworld run fill 237 58 -1 237 63 -1 stone
execute in minecraft:overworld run fill 237 64 -1 237 65 -1 dirt
execute in minecraft:overworld run setblock 237 66 -1 coarse_dirt
execute in minecraft:overworld run fill 237 67 -1 237 144 -1 air
execute in minecraft:overworld run fill 237 58 0 237 63 0 stone
execute in minecraft:overworld run fill 237 64 0 237 65 0 dirt
execute in minecraft:overworld run setblock 237 66 0 coarse_dirt
execute in minecraft:overworld run fill 237 67 0 237 144 0 air
execute in minecraft:overworld run setblock 237 67 0 grass
execute in minecraft:overworld run fill 237 58 1 237 63 1 stone
execute in minecraft:overworld run fill 237 64 1 237 65 1 dirt
execute in minecraft:overworld run setblock 237 66 1 coarse_dirt
execute in minecraft:overworld run fill 237 67 1 237 144 1 air
execute in minecraft:overworld run setblock 237 67 1 grass
execute in minecraft:overworld run fill 237 58 2 237 64 2 stone
execute in minecraft:overworld run fill 237 65 2 237 66 2 dirt
execute in minecraft:overworld run setblock 237 67 2 coarse_dirt
execute in minecraft:overworld run fill 237 68 2 237 144 2 air
execute in minecraft:overworld run fill 237 58 3 237 64 3 stone
execute in minecraft:overworld run fill 237 65 3 237 66 3 dirt
execute in minecraft:overworld run setblock 237 67 3 coarse_dirt
execute in minecraft:overworld run fill 237 68 3 237 144 3 air
execute in minecraft:overworld run fill 237 58 4 237 64 4 stone
execute in minecraft:overworld run fill 237 65 4 237 66 4 dirt
execute in minecraft:overworld run setblock 237 67 4 coarse_dirt
execute in minecraft:overworld run fill 237 68 4 237 144 4 air
execute in minecraft:overworld run setblock 237 68 4 grass
execute in minecraft:overworld run fill 237 58 5 237 64 5 stone
execute in minecraft:overworld run fill 237 65 5 237 66 5 dirt
execute in minecraft:overworld run setblock 237 67 5 grass_block
execute in minecraft:overworld run fill 237 68 5 237 144 5 air
execute in minecraft:overworld run fill 237 58 6 237 65 6 stone
execute in minecraft:overworld run fill 237 66 6 237 67 6 dirt
execute in minecraft:overworld run setblock 237 68 6 grass_block
execute in minecraft:overworld run fill 237 69 6 237 144 6 air
execute in minecraft:overworld run fill 237 58 7 237 65 7 stone
execute in minecraft:overworld run fill 237 66 7 237 67 7 dirt
execute in minecraft:overworld run setblock 237 68 7 coarse_dirt
execute in minecraft:overworld run fill 237 69 7 237 144 7 air
execute in minecraft:overworld run fill 237 58 8 237 65 8 stone
execute in minecraft:overworld run fill 237 66 8 237 67 8 dirt
execute in minecraft:overworld run setblock 237 68 8 coarse_dirt
execute in minecraft:overworld run fill 237 69 8 237 144 8 air
execute in minecraft:overworld run setblock 237 69 8 grass
execute in minecraft:overworld run fill 237 58 9 237 65 9 stone
execute in minecraft:overworld run fill 237 66 9 237 67 9 dirt
execute in minecraft:overworld run setblock 237 68 9 coarse_dirt
execute in minecraft:overworld run fill 237 69 9 237 144 9 air
execute in minecraft:overworld run fill 237 58 10 237 66 10 stone
execute in minecraft:overworld run fill 237 67 10 237 68 10 dirt
execute in minecraft:overworld run setblock 237 69 10 coarse_dirt
execute in minecraft:overworld run fill 237 70 10 237 144 10 air
execute in minecraft:overworld run fill 237 58 11 237 66 11 stone
execute in minecraft:overworld run fill 237 67 11 237 68 11 dirt
execute in minecraft:overworld run setblock 237 69 11 grass_block
execute in minecraft:overworld run fill 237 70 11 237 144 11 air
execute in minecraft:overworld run fill 237 58 12 237 66 12 stone
execute in minecraft:overworld run fill 237 67 12 237 68 12 dirt
execute in minecraft:overworld run setblock 237 69 12 grass_block
execute in minecraft:overworld run fill 237 70 12 237 144 12 air
execute in minecraft:overworld run fill 237 58 13 237 66 13 stone
execute in minecraft:overworld run fill 237 67 13 237 68 13 dirt
execute in minecraft:overworld run setblock 237 69 13 coarse_dirt
execute in minecraft:overworld run fill 237 70 13 237 144 13 air
execute in minecraft:overworld run fill 237 58 14 237 66 14 stone
execute in minecraft:overworld run fill 237 67 14 237 68 14 dirt
execute in minecraft:overworld run setblock 237 69 14 coarse_dirt
execute in minecraft:overworld run fill 237 70 14 237 144 14 air
execute in minecraft:overworld run fill 237 58 15 237 67 15 stone
execute in minecraft:overworld run fill 237 68 15 237 69 15 dirt
execute in minecraft:overworld run setblock 237 70 15 grass_block
execute in minecraft:overworld run fill 237 71 15 237 144 15 air
execute in minecraft:overworld run setblock 237 71 15 grass
execute in minecraft:overworld run fill 237 58 16 237 67 16 stone
execute in minecraft:overworld run fill 237 68 16 237 69 16 dirt
execute in minecraft:overworld run setblock 237 70 16 coarse_dirt
execute in minecraft:overworld run fill 237 71 16 237 144 16 air
execute in minecraft:overworld run setblock 237 71 16 grass
execute in minecraft:overworld run fill 237 58 17 237 67 17 stone
execute in minecraft:overworld run fill 237 68 17 237 69 17 dirt
execute in minecraft:overworld run setblock 237 70 17 coarse_dirt
execute in minecraft:overworld run fill 237 71 17 237 144 17 air
execute in minecraft:overworld run fill 237 58 18 237 67 18 stone
execute in minecraft:overworld run fill 237 68 18 237 69 18 dirt
execute in minecraft:overworld run setblock 237 70 18 grass_block
execute in minecraft:overworld run fill 237 71 18 237 144 18 air
execute in minecraft:overworld run setblock 237 71 18 grass
execute in minecraft:overworld run fill 237 58 19 237 67 19 stone
execute in minecraft:overworld run fill 237 68 19 237 69 19 dirt
execute in minecraft:overworld run setblock 237 70 19 grass_block
execute in minecraft:overworld run fill 237 71 19 237 144 19 air
execute in minecraft:overworld run fill 237 58 20 237 68 20 stone
execute in minecraft:overworld run fill 237 69 20 237 70 20 dirt
execute in minecraft:overworld run setblock 237 71 20 coarse_dirt
execute in minecraft:overworld run fill 237 72 20 237 144 20 air
execute in minecraft:overworld run fill 237 58 21 237 68 21 stone
execute in minecraft:overworld run fill 237 69 21 237 70 21 dirt
execute in minecraft:overworld run setblock 237 71 21 coarse_dirt
execute in minecraft:overworld run fill 237 72 21 237 144 21 air
execute in minecraft:overworld run fill 237 58 22 237 68 22 stone
execute in minecraft:overworld run fill 237 69 22 237 70 22 dirt
execute in minecraft:overworld run setblock 237 71 22 grass_block
execute in minecraft:overworld run fill 237 72 22 237 144 22 air
execute in minecraft:overworld run fill 237 58 23 237 68 23 stone
execute in minecraft:overworld run fill 237 69 23 237 70 23 dirt
execute in minecraft:overworld run setblock 237 71 23 coarse_dirt
execute in minecraft:overworld run fill 237 72 23 237 144 23 air
execute in minecraft:overworld run fill 237 58 24 237 68 24 stone
execute in minecraft:overworld run fill 237 69 24 237 70 24 dirt
execute in minecraft:overworld run setblock 237 71 24 grass_block
execute in minecraft:overworld run fill 237 72 24 237 144 24 air
execute in minecraft:overworld run fill 237 58 25 237 68 25 stone
execute in minecraft:overworld run fill 237 69 25 237 70 25 dirt
execute in minecraft:overworld run setblock 237 71 25 coarse_dirt
execute in minecraft:overworld run fill 237 72 25 237 144 25 air
execute in minecraft:overworld run fill 237 58 26 237 68 26 stone
execute in minecraft:overworld run fill 237 69 26 237 70 26 dirt
execute in minecraft:overworld run setblock 237 71 26 grass_block
execute in minecraft:overworld run fill 237 72 26 237 144 26 air
execute in minecraft:overworld run fill 237 58 27 237 68 27 stone
execute in minecraft:overworld run fill 237 69 27 237 70 27 dirt
execute in minecraft:overworld run setblock 237 71 27 coarse_dirt
execute in minecraft:overworld run fill 237 72 27 237 144 27 air
execute in minecraft:overworld run fill 237 58 28 237 68 28 stone
execute in minecraft:overworld run fill 237 69 28 237 70 28 dirt
execute in minecraft:overworld run setblock 237 71 28 grass_block
execute in minecraft:overworld run fill 237 72 28 237 144 28 air
execute in minecraft:overworld run fill 237 58 29 237 68 29 stone
execute in minecraft:overworld run fill 237 69 29 237 70 29 dirt
execute in minecraft:overworld run setblock 237 71 29 coarse_dirt
execute in minecraft:overworld run fill 237 72 29 237 144 29 air
execute in minecraft:overworld run fill 237 58 30 237 68 30 stone
execute in minecraft:overworld run fill 237 69 30 237 70 30 dirt
execute in minecraft:overworld run setblock 237 71 30 grass_block
execute in minecraft:overworld run fill 237 72 30 237 144 30 air
execute in minecraft:overworld run fill 237 58 31 237 68 31 stone
execute in minecraft:overworld run fill 237 69 31 237 70 31 dirt
execute in minecraft:overworld run setblock 237 71 31 coarse_dirt
execute in minecraft:overworld run fill 237 72 31 237 144 31 air
execute in minecraft:overworld run fill 237 58 32 237 68 32 stone
execute in minecraft:overworld run fill 237 69 32 237 70 32 dirt
execute in minecraft:overworld run setblock 237 71 32 coarse_dirt
execute in minecraft:overworld run fill 237 72 32 237 144 32 air
execute in minecraft:overworld run setblock 237 72 32 grass
execute in minecraft:overworld run fill 237 58 33 237 68 33 stone
execute in minecraft:overworld run fill 237 69 33 237 70 33 dirt
execute in minecraft:overworld run setblock 237 71 33 coarse_dirt
execute in minecraft:overworld run fill 237 72 33 237 144 33 air
execute in minecraft:overworld run fill 237 58 34 237 68 34 stone
execute in minecraft:overworld run fill 237 69 34 237 70 34 dirt
execute in minecraft:overworld run setblock 237 71 34 coarse_dirt
execute in minecraft:overworld run fill 237 72 34 237 144 34 air
execute in minecraft:overworld run fill 237 58 35 237 68 35 stone
execute in minecraft:overworld run fill 237 69 35 237 70 35 dirt
execute in minecraft:overworld run setblock 237 71 35 coarse_dirt
execute in minecraft:overworld run fill 237 72 35 237 144 35 air
execute in minecraft:overworld run fill 237 58 36 237 67 36 stone
execute in minecraft:overworld run fill 237 68 36 237 69 36 dirt
execute in minecraft:overworld run setblock 237 70 36 coarse_dirt
execute in minecraft:overworld run fill 237 71 36 237 144 36 air
execute in minecraft:overworld run fill 237 58 37 237 67 37 stone
execute in minecraft:overworld run fill 237 68 37 237 69 37 dirt
execute in minecraft:overworld run setblock 237 70 37 coarse_dirt
execute in minecraft:overworld run fill 237 71 37 237 144 37 air
execute in minecraft:overworld run fill 237 58 38 237 67 38 stone
execute in minecraft:overworld run fill 237 68 38 237 69 38 dirt
execute in minecraft:overworld run setblock 237 70 38 coarse_dirt
execute in minecraft:overworld run fill 237 71 38 237 144 38 air
execute in minecraft:overworld run fill 237 58 39 237 66 39 stone
execute in minecraft:overworld run fill 237 67 39 237 68 39 dirt
execute in minecraft:overworld run setblock 237 69 39 grass_block
execute in minecraft:overworld run fill 237 70 39 237 144 39 air
execute in minecraft:overworld run fill 237 58 40 237 65 40 stone
execute in minecraft:overworld run fill 237 66 40 237 67 40 dirt
execute in minecraft:overworld run setblock 237 68 40 coarse_dirt
execute in minecraft:overworld run fill 237 69 40 237 144 40 air
execute in minecraft:overworld run setblock 237 69 40 grass
execute in minecraft:overworld run fill 237 58 41 237 64 41 stone
execute in minecraft:overworld run fill 237 65 41 237 66 41 dirt
execute in minecraft:overworld run setblock 237 67 41 coarse_dirt
execute in minecraft:overworld run fill 237 68 41 237 144 41 air
execute in minecraft:overworld run fill 237 58 42 237 64 42 stone
execute in minecraft:overworld run fill 237 65 42 237 66 42 dirt
execute in minecraft:overworld run setblock 237 67 42 coarse_dirt
execute in minecraft:overworld run fill 237 68 42 237 144 42 air
execute in minecraft:overworld run fill 237 58 43 237 63 43 stone
execute in minecraft:overworld run fill 237 64 43 237 65 43 dirt
execute in minecraft:overworld run setblock 237 66 43 grass_block
execute in minecraft:overworld run fill 237 67 43 237 144 43 air
execute in minecraft:overworld run fill 237 58 44 237 62 44 stone
execute in minecraft:overworld run fill 237 63 44 237 64 44 dirt
execute in minecraft:overworld run setblock 237 65 44 coarse_dirt
execute in minecraft:overworld run fill 237 66 44 237 144 44 air
execute in minecraft:overworld run fill 237 58 45 237 62 45 stone
execute in minecraft:overworld run fill 237 63 45 237 64 45 dirt
execute in minecraft:overworld run setblock 237 65 45 coarse_dirt
execute in minecraft:overworld run fill 237 66 45 237 144 45 air
execute in minecraft:overworld run fill 237 58 46 237 62 46 stone
execute in minecraft:overworld run fill 237 63 46 237 64 46 dirt
execute in minecraft:overworld run setblock 237 65 46 grass_block
execute in minecraft:overworld run fill 237 66 46 237 144 46 air
execute in minecraft:overworld run fill 237 58 47 237 61 47 stone
execute in minecraft:overworld run fill 237 62 47 237 63 47 dirt
execute in minecraft:overworld run setblock 237 64 47 coarse_dirt
execute in minecraft:overworld run fill 237 65 47 237 144 47 air
execute in minecraft:overworld run fill 238 58 -48 238 61 -48 stone
schedule function blade_gallery:random/burned/part_46 1t replace
