execute in minecraft:overworld run fill 423 69 -18 423 70 -18 dirt
execute in minecraft:overworld run setblock 423 71 -18 coarse_dirt
execute in minecraft:overworld run fill 423 72 -18 423 144 -18 air
execute in minecraft:overworld run fill 423 58 -17 423 67 -17 stone
execute in minecraft:overworld run fill 423 68 -17 423 69 -17 dirt
execute in minecraft:overworld run setblock 423 70 -17 grass_block
execute in minecraft:overworld run fill 423 71 -17 423 144 -17 air
execute in minecraft:overworld run fill 423 58 -16 423 67 -16 stone
execute in minecraft:overworld run fill 423 68 -16 423 69 -16 dirt
execute in minecraft:overworld run setblock 423 70 -16 coarse_dirt
execute in minecraft:overworld run fill 423 71 -16 423 144 -16 air
execute in minecraft:overworld run fill 423 58 -15 423 66 -15 stone
execute in minecraft:overworld run fill 423 67 -15 423 68 -15 dirt
execute in minecraft:overworld run setblock 423 69 -15 coarse_dirt
execute in minecraft:overworld run fill 423 70 -15 423 144 -15 air
execute in minecraft:overworld run fill 423 58 -14 423 66 -14 stone
execute in minecraft:overworld run fill 423 67 -14 423 68 -14 dirt
execute in minecraft:overworld run setblock 423 69 -14 coarse_dirt
execute in minecraft:overworld run fill 423 70 -14 423 144 -14 air
execute in minecraft:overworld run fill 423 58 -13 423 66 -13 stone
execute in minecraft:overworld run fill 423 67 -13 423 68 -13 dirt
execute in minecraft:overworld run setblock 423 69 -13 grass_block
execute in minecraft:overworld run fill 423 70 -13 423 144 -13 air
execute in minecraft:overworld run setblock 423 70 -13 mossy_cobblestone
execute in minecraft:overworld run fill 423 58 -12 423 65 -12 stone
execute in minecraft:overworld run fill 423 66 -12 423 67 -12 dirt
execute in minecraft:overworld run setblock 423 68 -12 coarse_dirt
execute in minecraft:overworld run fill 423 69 -12 423 144 -12 air
execute in minecraft:overworld run fill 423 58 -11 423 65 -11 stone
execute in minecraft:overworld run fill 423 66 -11 423 67 -11 dirt
execute in minecraft:overworld run setblock 423 68 -11 grass_block
execute in minecraft:overworld run fill 423 69 -11 423 144 -11 air
execute in minecraft:overworld run setblock 423 69 -11 mossy_cobblestone
execute in minecraft:overworld run fill 423 58 -10 423 65 -10 stone
execute in minecraft:overworld run fill 423 66 -10 423 67 -10 dirt
execute in minecraft:overworld run setblock 423 68 -10 coarse_dirt
execute in minecraft:overworld run fill 423 69 -10 423 144 -10 air
execute in minecraft:overworld run fill 423 58 -9 423 65 -9 stone
execute in minecraft:overworld run fill 423 66 -9 423 67 -9 dirt
execute in minecraft:overworld run setblock 423 68 -9 coarse_dirt
execute in minecraft:overworld run fill 423 69 -9 423 144 -9 air
execute in minecraft:overworld run fill 423 58 -8 423 65 -8 stone
execute in minecraft:overworld run fill 423 66 -8 423 67 -8 dirt
execute in minecraft:overworld run setblock 423 68 -8 coarse_dirt
execute in minecraft:overworld run fill 423 69 -8 423 144 -8 air
execute in minecraft:overworld run fill 423 58 -7 423 65 -7 stone
execute in minecraft:overworld run fill 423 66 -7 423 67 -7 dirt
execute in minecraft:overworld run setblock 423 68 -7 coarse_dirt
execute in minecraft:overworld run fill 423 69 -7 423 144 -7 air
execute in minecraft:overworld run setblock 423 69 -7 mossy_cobblestone
execute in minecraft:overworld run fill 423 58 -6 423 65 -6 stone
execute in minecraft:overworld run fill 423 66 -6 423 67 -6 dirt
execute in minecraft:overworld run setblock 423 68 -6 grass_block
execute in minecraft:overworld run fill 423 69 -6 423 144 -6 air
execute in minecraft:overworld run fill 423 58 -5 423 64 -5 stone
execute in minecraft:overworld run fill 423 65 -5 423 66 -5 dirt
execute in minecraft:overworld run setblock 423 67 -5 grass_block
execute in minecraft:overworld run fill 423 68 -5 423 144 -5 air
execute in minecraft:overworld run fill 423 58 -4 423 64 -4 stone
execute in minecraft:overworld run fill 423 65 -4 423 66 -4 dirt
execute in minecraft:overworld run setblock 423 67 -4 coarse_dirt
execute in minecraft:overworld run fill 423 68 -4 423 144 -4 air
execute in minecraft:overworld run setblock 423 68 -4 grass
execute in minecraft:overworld run fill 423 58 -3 423 64 -3 stone
execute in minecraft:overworld run fill 423 65 -3 423 66 -3 dirt
execute in minecraft:overworld run setblock 423 67 -3 coarse_dirt
execute in minecraft:overworld run fill 423 68 -3 423 144 -3 air
execute in minecraft:overworld run fill 423 58 -2 423 64 -2 stone
execute in minecraft:overworld run fill 423 65 -2 423 66 -2 dirt
execute in minecraft:overworld run setblock 423 67 -2 grass_block
execute in minecraft:overworld run fill 423 68 -2 423 144 -2 air
execute in minecraft:overworld run fill 423 58 -1 423 64 -1 stone
execute in minecraft:overworld run fill 423 65 -1 423 66 -1 dirt
execute in minecraft:overworld run setblock 423 67 -1 coarse_dirt
execute in minecraft:overworld run fill 423 68 -1 423 144 -1 air
execute in minecraft:overworld run fill 423 58 0 423 64 0 stone
execute in minecraft:overworld run fill 423 65 0 423 66 0 dirt
execute in minecraft:overworld run setblock 423 67 0 coarse_dirt
execute in minecraft:overworld run fill 423 68 0 423 144 0 air
execute in minecraft:overworld run fill 423 58 1 423 64 1 stone
execute in minecraft:overworld run fill 423 65 1 423 66 1 dirt
execute in minecraft:overworld run setblock 423 67 1 coarse_dirt
execute in minecraft:overworld run fill 423 68 1 423 144 1 air
execute in minecraft:overworld run fill 423 58 2 423 64 2 stone
execute in minecraft:overworld run fill 423 65 2 423 66 2 dirt
execute in minecraft:overworld run setblock 423 67 2 grass_block
execute in minecraft:overworld run fill 423 68 2 423 144 2 air
execute in minecraft:overworld run fill 423 58 3 423 64 3 stone
execute in minecraft:overworld run fill 423 65 3 423 66 3 dirt
execute in minecraft:overworld run setblock 423 67 3 grass_block
execute in minecraft:overworld run fill 423 68 3 423 144 3 air
execute in minecraft:overworld run fill 423 58 4 423 64 4 stone
execute in minecraft:overworld run fill 423 65 4 423 66 4 dirt
execute in minecraft:overworld run setblock 423 67 4 coarse_dirt
execute in minecraft:overworld run fill 423 68 4 423 144 4 air
execute in minecraft:overworld run fill 423 58 5 423 64 5 stone
execute in minecraft:overworld run fill 423 65 5 423 66 5 dirt
execute in minecraft:overworld run setblock 423 67 5 coarse_dirt
execute in minecraft:overworld run fill 423 68 5 423 144 5 air
execute in minecraft:overworld run fill 423 58 6 423 65 6 stone
execute in minecraft:overworld run fill 423 66 6 423 67 6 dirt
execute in minecraft:overworld run setblock 423 68 6 grass_block
execute in minecraft:overworld run fill 423 69 6 423 144 6 air
execute in minecraft:overworld run fill 423 58 7 423 65 7 stone
execute in minecraft:overworld run fill 423 66 7 423 67 7 dirt
execute in minecraft:overworld run setblock 423 68 7 coarse_dirt
execute in minecraft:overworld run fill 423 69 7 423 144 7 air
execute in minecraft:overworld run fill 423 58 8 423 65 8 stone
execute in minecraft:overworld run fill 423 66 8 423 67 8 dirt
execute in minecraft:overworld run setblock 423 68 8 coarse_dirt
execute in minecraft:overworld run fill 423 69 8 423 144 8 air
execute in minecraft:overworld run fill 423 58 9 423 65 9 stone
execute in minecraft:overworld run fill 423 66 9 423 67 9 dirt
execute in minecraft:overworld run setblock 423 68 9 grass_block
execute in minecraft:overworld run fill 423 69 9 423 144 9 air
execute in minecraft:overworld run fill 423 58 10 423 66 10 stone
execute in minecraft:overworld run fill 423 67 10 423 68 10 dirt
execute in minecraft:overworld run setblock 423 69 10 coarse_dirt
execute in minecraft:overworld run fill 423 70 10 423 144 10 air
execute in minecraft:overworld run fill 423 58 11 423 66 11 stone
execute in minecraft:overworld run fill 423 67 11 423 68 11 dirt
execute in minecraft:overworld run setblock 423 69 11 grass_block
execute in minecraft:overworld run fill 423 70 11 423 144 11 air
execute in minecraft:overworld run fill 423 58 12 423 66 12 stone
execute in minecraft:overworld run fill 423 67 12 423 68 12 dirt
execute in minecraft:overworld run setblock 423 69 12 grass_block
execute in minecraft:overworld run fill 423 70 12 423 144 12 air
execute in minecraft:overworld run fill 423 58 13 423 67 13 stone
execute in minecraft:overworld run fill 423 68 13 423 69 13 dirt
execute in minecraft:overworld run setblock 423 70 13 grass_block
execute in minecraft:overworld run fill 423 71 13 423 144 13 air
execute in minecraft:overworld run fill 423 58 14 423 67 14 stone
execute in minecraft:overworld run fill 423 68 14 423 69 14 dirt
execute in minecraft:overworld run setblock 423 70 14 coarse_dirt
execute in minecraft:overworld run fill 423 71 14 423 144 14 air
execute in minecraft:overworld run fill 423 58 15 423 68 15 stone
execute in minecraft:overworld run fill 423 69 15 423 70 15 dirt
execute in minecraft:overworld run setblock 423 71 15 grass_block
execute in minecraft:overworld run fill 423 72 15 423 144 15 air
execute in minecraft:overworld run fill 423 58 16 423 68 16 stone
execute in minecraft:overworld run fill 423 69 16 423 70 16 dirt
execute in minecraft:overworld run setblock 423 71 16 grass_block
execute in minecraft:overworld run fill 423 72 16 423 144 16 air
execute in minecraft:overworld run fill 423 58 17 423 68 17 stone
execute in minecraft:overworld run fill 423 69 17 423 70 17 dirt
execute in minecraft:overworld run setblock 423 71 17 grass_block
execute in minecraft:overworld run fill 423 72 17 423 144 17 air
execute in minecraft:overworld run fill 423 58 18 423 69 18 stone
execute in minecraft:overworld run fill 423 70 18 423 71 18 dirt
execute in minecraft:overworld run setblock 423 72 18 coarse_dirt
execute in minecraft:overworld run fill 423 73 18 423 144 18 air
execute in minecraft:overworld run fill 423 58 19 423 69 19 stone
execute in minecraft:overworld run fill 423 70 19 423 71 19 dirt
execute in minecraft:overworld run setblock 423 72 19 coarse_dirt
execute in minecraft:overworld run fill 423 73 19 423 144 19 air
execute in minecraft:overworld run fill 423 58 20 423 69 20 stone
execute in minecraft:overworld run fill 423 70 20 423 71 20 dirt
execute in minecraft:overworld run setblock 423 72 20 coarse_dirt
execute in minecraft:overworld run fill 423 73 20 423 144 20 air
execute in minecraft:overworld run fill 423 58 21 423 70 21 stone
execute in minecraft:overworld run fill 423 71 21 423 72 21 dirt
execute in minecraft:overworld run setblock 423 73 21 coarse_dirt
execute in minecraft:overworld run fill 423 74 21 423 144 21 air
execute in minecraft:overworld run fill 423 58 22 423 70 22 stone
execute in minecraft:overworld run fill 423 71 22 423 72 22 dirt
execute in minecraft:overworld run setblock 423 73 22 grass_block
execute in minecraft:overworld run fill 423 74 22 423 144 22 air
execute in minecraft:overworld run fill 423 58 23 423 70 23 stone
execute in minecraft:overworld run fill 423 71 23 423 72 23 dirt
execute in minecraft:overworld run setblock 423 73 23 coarse_dirt
execute in minecraft:overworld run fill 423 74 23 423 144 23 air
execute in minecraft:overworld run fill 423 58 24 423 70 24 stone
execute in minecraft:overworld run fill 423 71 24 423 72 24 dirt
execute in minecraft:overworld run setblock 423 73 24 grass_block
execute in minecraft:overworld run fill 423 74 24 423 144 24 air
execute in minecraft:overworld run fill 423 58 25 423 70 25 stone
execute in minecraft:overworld run fill 423 71 25 423 72 25 dirt
execute in minecraft:overworld run setblock 423 73 25 grass_block
execute in minecraft:overworld run fill 423 74 25 423 144 25 air
execute in minecraft:overworld run setblock 423 74 25 grass
execute in minecraft:overworld run fill 423 58 26 423 70 26 stone
execute in minecraft:overworld run fill 423 71 26 423 72 26 dirt
execute in minecraft:overworld run setblock 423 73 26 coarse_dirt
execute in minecraft:overworld run fill 423 74 26 423 144 26 air
execute in minecraft:overworld run fill 423 58 27 423 70 27 stone
execute in minecraft:overworld run fill 423 71 27 423 72 27 dirt
execute in minecraft:overworld run setblock 423 73 27 coarse_dirt
execute in minecraft:overworld run fill 423 74 27 423 144 27 air
execute in minecraft:overworld run fill 423 58 28 423 70 28 stone
execute in minecraft:overworld run fill 423 71 28 423 72 28 dirt
execute in minecraft:overworld run setblock 423 73 28 grass_block
execute in minecraft:overworld run fill 423 74 28 423 144 28 air
execute in minecraft:overworld run fill 423 58 29 423 70 29 stone
execute in minecraft:overworld run fill 423 71 29 423 72 29 dirt
execute in minecraft:overworld run setblock 423 73 29 coarse_dirt
execute in minecraft:overworld run fill 423 74 29 423 144 29 air
execute in minecraft:overworld run fill 423 58 30 423 70 30 stone
execute in minecraft:overworld run fill 423 71 30 423 72 30 dirt
execute in minecraft:overworld run setblock 423 73 30 coarse_dirt
execute in minecraft:overworld run fill 423 74 30 423 144 30 air
execute in minecraft:overworld run fill 423 58 31 423 70 31 stone
execute in minecraft:overworld run fill 423 71 31 423 72 31 dirt
execute in minecraft:overworld run setblock 423 73 31 coarse_dirt
execute in minecraft:overworld run fill 423 74 31 423 144 31 air
execute in minecraft:overworld run fill 423 58 32 423 70 32 stone
execute in minecraft:overworld run fill 423 71 32 423 72 32 dirt
execute in minecraft:overworld run setblock 423 73 32 grass_block
execute in minecraft:overworld run fill 423 74 32 423 144 32 air
execute in minecraft:overworld run fill 423 58 33 423 70 33 stone
execute in minecraft:overworld run fill 423 71 33 423 72 33 dirt
execute in minecraft:overworld run setblock 423 73 33 grass_block
execute in minecraft:overworld run fill 423 74 33 423 144 33 air
execute in minecraft:overworld run fill 423 58 34 423 70 34 stone
execute in minecraft:overworld run fill 423 71 34 423 72 34 dirt
execute in minecraft:overworld run setblock 423 73 34 coarse_dirt
execute in minecraft:overworld run fill 423 74 34 423 144 34 air
execute in minecraft:overworld run setblock 423 74 34 grass
execute in minecraft:overworld run fill 423 58 35 423 69 35 stone
execute in minecraft:overworld run fill 423 70 35 423 71 35 dirt
execute in minecraft:overworld run setblock 423 72 35 coarse_dirt
execute in minecraft:overworld run fill 423 73 35 423 144 35 air
execute in minecraft:overworld run fill 423 58 36 423 69 36 stone
execute in minecraft:overworld run fill 423 70 36 423 71 36 dirt
execute in minecraft:overworld run setblock 423 72 36 grass_block
execute in minecraft:overworld run fill 423 73 36 423 144 36 air
execute in minecraft:overworld run fill 423 58 37 423 69 37 stone
execute in minecraft:overworld run fill 423 70 37 423 71 37 dirt
execute in minecraft:overworld run setblock 423 72 37 coarse_dirt
execute in minecraft:overworld run fill 423 73 37 423 144 37 air
execute in minecraft:overworld run fill 423 58 38 423 68 38 stone
execute in minecraft:overworld run fill 423 69 38 423 70 38 dirt
execute in minecraft:overworld run setblock 423 71 38 coarse_dirt
execute in minecraft:overworld run fill 423 72 38 423 144 38 air
execute in minecraft:overworld run fill 423 58 39 423 67 39 stone
execute in minecraft:overworld run fill 423 68 39 423 69 39 dirt
execute in minecraft:overworld run setblock 423 70 39 coarse_dirt
execute in minecraft:overworld run fill 423 71 39 423 144 39 air
execute in minecraft:overworld run fill 423 58 40 423 66 40 stone
execute in minecraft:overworld run fill 423 67 40 423 68 40 dirt
execute in minecraft:overworld run setblock 423 69 40 coarse_dirt
execute in minecraft:overworld run fill 423 70 40 423 144 40 air
execute in minecraft:overworld run fill 423 58 41 423 65 41 stone
execute in minecraft:overworld run fill 423 66 41 423 67 41 dirt
execute in minecraft:overworld run setblock 423 68 41 coarse_dirt
execute in minecraft:overworld run fill 423 69 41 423 144 41 air
execute in minecraft:overworld run fill 423 58 42 423 64 42 stone
execute in minecraft:overworld run fill 423 65 42 423 66 42 dirt
execute in minecraft:overworld run setblock 423 67 42 grass_block
execute in minecraft:overworld run fill 423 68 42 423 144 42 air
execute in minecraft:overworld run fill 423 58 43 423 63 43 stone
execute in minecraft:overworld run fill 423 64 43 423 65 43 dirt
execute in minecraft:overworld run setblock 423 66 43 coarse_dirt
execute in minecraft:overworld run fill 423 67 43 423 144 43 air
execute in minecraft:overworld run fill 423 58 44 423 62 44 stone
execute in minecraft:overworld run fill 423 63 44 423 64 44 dirt
execute in minecraft:overworld run setblock 423 65 44 coarse_dirt
schedule function blade_gallery:random/battlefield/part_138 1t replace
