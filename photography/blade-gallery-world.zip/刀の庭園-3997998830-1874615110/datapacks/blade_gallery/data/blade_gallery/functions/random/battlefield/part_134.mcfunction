execute in minecraft:overworld run fill 421 70 -13 421 144 -13 air
execute in minecraft:overworld run fill 421 58 -12 421 66 -12 stone
execute in minecraft:overworld run fill 421 67 -12 421 68 -12 dirt
execute in minecraft:overworld run setblock 421 69 -12 grass_block
execute in minecraft:overworld run fill 421 70 -12 421 144 -12 air
execute in minecraft:overworld run fill 421 58 -11 421 65 -11 stone
execute in minecraft:overworld run fill 421 66 -11 421 67 -11 dirt
execute in minecraft:overworld run setblock 421 68 -11 coarse_dirt
execute in minecraft:overworld run fill 421 69 -11 421 144 -11 air
execute in minecraft:overworld run fill 421 58 -10 421 65 -10 stone
execute in minecraft:overworld run fill 421 66 -10 421 67 -10 dirt
execute in minecraft:overworld run setblock 421 68 -10 coarse_dirt
execute in minecraft:overworld run fill 421 69 -10 421 144 -10 air
execute in minecraft:overworld run fill 421 58 -9 421 65 -9 stone
execute in minecraft:overworld run fill 421 66 -9 421 67 -9 dirt
execute in minecraft:overworld run setblock 421 68 -9 coarse_dirt
execute in minecraft:overworld run fill 421 69 -9 421 144 -9 air
execute in minecraft:overworld run fill 421 58 -8 421 65 -8 stone
execute in minecraft:overworld run fill 421 66 -8 421 67 -8 dirt
execute in minecraft:overworld run setblock 421 68 -8 coarse_dirt
execute in minecraft:overworld run fill 421 69 -8 421 144 -8 air
execute in minecraft:overworld run fill 421 58 -7 421 65 -7 stone
execute in minecraft:overworld run fill 421 66 -7 421 67 -7 dirt
execute in minecraft:overworld run setblock 421 68 -7 coarse_dirt
execute in minecraft:overworld run fill 421 69 -7 421 144 -7 air
execute in minecraft:overworld run fill 421 58 -6 421 65 -6 stone
execute in minecraft:overworld run fill 421 66 -6 421 67 -6 dirt
execute in minecraft:overworld run setblock 421 68 -6 coarse_dirt
execute in minecraft:overworld run fill 421 69 -6 421 144 -6 air
execute in minecraft:overworld run fill 421 58 -5 421 65 -5 stone
execute in minecraft:overworld run fill 421 66 -5 421 67 -5 dirt
execute in minecraft:overworld run setblock 421 68 -5 coarse_dirt
execute in minecraft:overworld run fill 421 69 -5 421 144 -5 air
execute in minecraft:overworld run fill 421 58 -4 421 64 -4 stone
execute in minecraft:overworld run fill 421 65 -4 421 66 -4 dirt
execute in minecraft:overworld run setblock 421 67 -4 coarse_dirt
execute in minecraft:overworld run fill 421 68 -4 421 144 -4 air
execute in minecraft:overworld run fill 421 58 -3 421 64 -3 stone
execute in minecraft:overworld run fill 421 65 -3 421 66 -3 dirt
execute in minecraft:overworld run setblock 421 67 -3 coarse_dirt
execute in minecraft:overworld run fill 421 68 -3 421 144 -3 air
execute in minecraft:overworld run fill 421 58 -2 421 64 -2 stone
execute in minecraft:overworld run fill 421 65 -2 421 66 -2 dirt
execute in minecraft:overworld run setblock 421 67 -2 coarse_dirt
execute in minecraft:overworld run fill 421 68 -2 421 144 -2 air
execute in minecraft:overworld run fill 421 58 -1 421 64 -1 stone
execute in minecraft:overworld run fill 421 65 -1 421 66 -1 dirt
execute in minecraft:overworld run setblock 421 67 -1 coarse_dirt
execute in minecraft:overworld run fill 421 68 -1 421 144 -1 air
execute in minecraft:overworld run setblock 421 68 -1 grass
execute in minecraft:overworld run fill 421 58 0 421 64 0 stone
execute in minecraft:overworld run fill 421 65 0 421 66 0 dirt
execute in minecraft:overworld run setblock 421 67 0 coarse_dirt
execute in minecraft:overworld run fill 421 68 0 421 144 0 air
execute in minecraft:overworld run fill 421 58 1 421 64 1 stone
execute in minecraft:overworld run fill 421 65 1 421 66 1 dirt
execute in minecraft:overworld run setblock 421 67 1 grass_block
execute in minecraft:overworld run fill 421 68 1 421 144 1 air
execute in minecraft:overworld run fill 421 58 2 421 64 2 stone
execute in minecraft:overworld run fill 421 65 2 421 66 2 dirt
execute in minecraft:overworld run setblock 421 67 2 coarse_dirt
execute in minecraft:overworld run fill 421 68 2 421 144 2 air
execute in minecraft:overworld run fill 421 58 3 421 64 3 stone
execute in minecraft:overworld run fill 421 65 3 421 66 3 dirt
execute in minecraft:overworld run setblock 421 67 3 coarse_dirt
execute in minecraft:overworld run fill 421 68 3 421 144 3 air
execute in minecraft:overworld run fill 421 58 4 421 64 4 stone
execute in minecraft:overworld run fill 421 65 4 421 66 4 dirt
execute in minecraft:overworld run setblock 421 67 4 grass_block
execute in minecraft:overworld run fill 421 68 4 421 144 4 air
execute in minecraft:overworld run fill 421 58 5 421 64 5 stone
execute in minecraft:overworld run fill 421 65 5 421 66 5 dirt
execute in minecraft:overworld run setblock 421 67 5 grass_block
execute in minecraft:overworld run fill 421 68 5 421 144 5 air
execute in minecraft:overworld run fill 421 58 6 421 65 6 stone
execute in minecraft:overworld run fill 421 66 6 421 67 6 dirt
execute in minecraft:overworld run setblock 421 68 6 coarse_dirt
execute in minecraft:overworld run fill 421 69 6 421 144 6 air
execute in minecraft:overworld run fill 421 58 7 421 65 7 stone
execute in minecraft:overworld run fill 421 66 7 421 67 7 dirt
execute in minecraft:overworld run setblock 421 68 7 coarse_dirt
execute in minecraft:overworld run fill 421 69 7 421 144 7 air
execute in minecraft:overworld run fill 421 58 8 421 65 8 stone
execute in minecraft:overworld run fill 421 66 8 421 67 8 dirt
execute in minecraft:overworld run setblock 421 68 8 coarse_dirt
execute in minecraft:overworld run fill 421 69 8 421 144 8 air
execute in minecraft:overworld run fill 421 58 9 421 66 9 stone
execute in minecraft:overworld run fill 421 67 9 421 68 9 dirt
execute in minecraft:overworld run setblock 421 69 9 coarse_dirt
execute in minecraft:overworld run fill 421 70 9 421 144 9 air
execute in minecraft:overworld run setblock 421 70 9 grass
execute in minecraft:overworld run fill 421 58 10 421 66 10 stone
execute in minecraft:overworld run fill 421 67 10 421 68 10 dirt
execute in minecraft:overworld run setblock 421 69 10 coarse_dirt
execute in minecraft:overworld run fill 421 70 10 421 144 10 air
execute in minecraft:overworld run fill 421 58 11 421 66 11 stone
execute in minecraft:overworld run fill 421 67 11 421 68 11 dirt
execute in minecraft:overworld run setblock 421 69 11 grass_block
execute in minecraft:overworld run fill 421 70 11 421 144 11 air
execute in minecraft:overworld run fill 421 58 12 421 67 12 stone
execute in minecraft:overworld run fill 421 68 12 421 69 12 dirt
execute in minecraft:overworld run setblock 421 70 12 coarse_dirt
execute in minecraft:overworld run fill 421 71 12 421 144 12 air
execute in minecraft:overworld run fill 421 58 13 421 67 13 stone
execute in minecraft:overworld run fill 421 68 13 421 69 13 dirt
execute in minecraft:overworld run setblock 421 70 13 coarse_dirt
execute in minecraft:overworld run fill 421 71 13 421 144 13 air
execute in minecraft:overworld run fill 421 58 14 421 68 14 stone
execute in minecraft:overworld run fill 421 69 14 421 70 14 dirt
execute in minecraft:overworld run setblock 421 71 14 coarse_dirt
execute in minecraft:overworld run fill 421 72 14 421 144 14 air
execute in minecraft:overworld run fill 421 58 15 421 68 15 stone
execute in minecraft:overworld run fill 421 69 15 421 70 15 dirt
execute in minecraft:overworld run setblock 421 71 15 coarse_dirt
execute in minecraft:overworld run fill 421 72 15 421 144 15 air
execute in minecraft:overworld run setblock 421 72 15 grass
execute in minecraft:overworld run fill 421 58 16 421 69 16 stone
execute in minecraft:overworld run fill 421 70 16 421 71 16 dirt
execute in minecraft:overworld run setblock 421 72 16 grass_block
execute in minecraft:overworld run fill 421 73 16 421 144 16 air
execute in minecraft:overworld run fill 421 58 17 421 69 17 stone
execute in minecraft:overworld run fill 421 70 17 421 71 17 dirt
execute in minecraft:overworld run setblock 421 72 17 coarse_dirt
execute in minecraft:overworld run fill 421 73 17 421 144 17 air
execute in minecraft:overworld run fill 421 58 18 421 69 18 stone
execute in minecraft:overworld run fill 421 70 18 421 71 18 dirt
execute in minecraft:overworld run setblock 421 72 18 grass_block
execute in minecraft:overworld run fill 421 73 18 421 144 18 air
execute in minecraft:overworld run setblock 421 73 18 grass
execute in minecraft:overworld run fill 421 58 19 421 70 19 stone
execute in minecraft:overworld run fill 421 71 19 421 72 19 dirt
execute in minecraft:overworld run setblock 421 73 19 coarse_dirt
execute in minecraft:overworld run fill 421 74 19 421 144 19 air
execute in minecraft:overworld run fill 421 58 20 421 70 20 stone
execute in minecraft:overworld run fill 421 71 20 421 72 20 dirt
execute in minecraft:overworld run setblock 421 73 20 coarse_dirt
execute in minecraft:overworld run fill 421 74 20 421 144 20 air
execute in minecraft:overworld run fill 421 58 21 421 70 21 stone
execute in minecraft:overworld run fill 421 71 21 421 72 21 dirt
execute in minecraft:overworld run setblock 421 73 21 coarse_dirt
execute in minecraft:overworld run fill 421 74 21 421 144 21 air
execute in minecraft:overworld run setblock 421 74 21 grass
execute in minecraft:overworld run fill 421 58 22 421 71 22 stone
execute in minecraft:overworld run fill 421 72 22 421 73 22 dirt
execute in minecraft:overworld run setblock 421 74 22 coarse_dirt
execute in minecraft:overworld run fill 421 75 22 421 144 22 air
execute in minecraft:overworld run fill 421 58 23 421 71 23 stone
execute in minecraft:overworld run fill 421 72 23 421 73 23 dirt
execute in minecraft:overworld run setblock 421 74 23 coarse_dirt
execute in minecraft:overworld run fill 421 75 23 421 144 23 air
execute in minecraft:overworld run fill 421 58 24 421 71 24 stone
execute in minecraft:overworld run fill 421 72 24 421 73 24 dirt
execute in minecraft:overworld run setblock 421 74 24 coarse_dirt
execute in minecraft:overworld run fill 421 75 24 421 144 24 air
execute in minecraft:overworld run fill 421 58 25 421 71 25 stone
execute in minecraft:overworld run fill 421 72 25 421 73 25 dirt
execute in minecraft:overworld run setblock 421 74 25 grass_block
execute in minecraft:overworld run fill 421 75 25 421 144 25 air
execute in minecraft:overworld run fill 421 58 26 421 71 26 stone
execute in minecraft:overworld run fill 421 72 26 421 73 26 dirt
execute in minecraft:overworld run setblock 421 74 26 coarse_dirt
execute in minecraft:overworld run fill 421 75 26 421 144 26 air
execute in minecraft:overworld run fill 421 58 27 421 72 27 stone
execute in minecraft:overworld run fill 421 73 27 421 74 27 dirt
execute in minecraft:overworld run setblock 421 75 27 coarse_dirt
execute in minecraft:overworld run fill 421 76 27 421 144 27 air
execute in minecraft:overworld run fill 421 58 28 421 72 28 stone
execute in minecraft:overworld run fill 421 73 28 421 74 28 dirt
execute in minecraft:overworld run setblock 421 75 28 grass_block
execute in minecraft:overworld run fill 421 76 28 421 144 28 air
execute in minecraft:overworld run fill 421 58 29 421 72 29 stone
execute in minecraft:overworld run fill 421 73 29 421 74 29 dirt
execute in minecraft:overworld run setblock 421 75 29 coarse_dirt
execute in minecraft:overworld run fill 421 76 29 421 144 29 air
execute in minecraft:overworld run setblock 421 76 29 grass
execute in minecraft:overworld run fill 421 58 30 421 71 30 stone
execute in minecraft:overworld run fill 421 72 30 421 73 30 dirt
execute in minecraft:overworld run setblock 421 74 30 coarse_dirt
execute in minecraft:overworld run fill 421 75 30 421 144 30 air
execute in minecraft:overworld run fill 421 58 31 421 71 31 stone
execute in minecraft:overworld run fill 421 72 31 421 73 31 dirt
execute in minecraft:overworld run setblock 421 74 31 grass_block
execute in minecraft:overworld run fill 421 75 31 421 144 31 air
execute in minecraft:overworld run fill 421 58 32 421 71 32 stone
execute in minecraft:overworld run fill 421 72 32 421 73 32 dirt
execute in minecraft:overworld run setblock 421 74 32 coarse_dirt
execute in minecraft:overworld run fill 421 75 32 421 144 32 air
execute in minecraft:overworld run fill 421 58 33 421 71 33 stone
execute in minecraft:overworld run fill 421 72 33 421 73 33 dirt
execute in minecraft:overworld run setblock 421 74 33 coarse_dirt
execute in minecraft:overworld run fill 421 75 33 421 144 33 air
execute in minecraft:overworld run fill 421 58 34 421 71 34 stone
execute in minecraft:overworld run fill 421 72 34 421 73 34 dirt
execute in minecraft:overworld run setblock 421 74 34 coarse_dirt
execute in minecraft:overworld run fill 421 75 34 421 144 34 air
execute in minecraft:overworld run fill 421 58 35 421 70 35 stone
execute in minecraft:overworld run fill 421 71 35 421 72 35 dirt
execute in minecraft:overworld run setblock 421 73 35 grass_block
execute in minecraft:overworld run fill 421 74 35 421 144 35 air
execute in minecraft:overworld run fill 421 58 36 421 70 36 stone
execute in minecraft:overworld run fill 421 71 36 421 72 36 dirt
execute in minecraft:overworld run setblock 421 73 36 coarse_dirt
execute in minecraft:overworld run fill 421 74 36 421 144 36 air
execute in minecraft:overworld run fill 421 58 37 421 69 37 stone
execute in minecraft:overworld run fill 421 70 37 421 71 37 dirt
execute in minecraft:overworld run setblock 421 72 37 coarse_dirt
execute in minecraft:overworld run fill 421 73 37 421 144 37 air
execute in minecraft:overworld run fill 421 58 38 421 69 38 stone
execute in minecraft:overworld run fill 421 70 38 421 71 38 dirt
execute in minecraft:overworld run setblock 421 72 38 coarse_dirt
execute in minecraft:overworld run fill 421 73 38 421 144 38 air
execute in minecraft:overworld run fill 421 58 39 421 67 39 stone
execute in minecraft:overworld run fill 421 68 39 421 69 39 dirt
execute in minecraft:overworld run setblock 421 70 39 grass_block
execute in minecraft:overworld run fill 421 71 39 421 144 39 air
execute in minecraft:overworld run fill 421 58 40 421 66 40 stone
execute in minecraft:overworld run fill 421 67 40 421 68 40 dirt
execute in minecraft:overworld run setblock 421 69 40 grass_block
execute in minecraft:overworld run fill 421 70 40 421 144 40 air
execute in minecraft:overworld run setblock 421 70 40 mossy_cobblestone
execute in minecraft:overworld run fill 421 58 41 421 65 41 stone
execute in minecraft:overworld run fill 421 66 41 421 67 41 dirt
execute in minecraft:overworld run setblock 421 68 41 coarse_dirt
execute in minecraft:overworld run fill 421 69 41 421 144 41 air
execute in minecraft:overworld run fill 421 58 42 421 64 42 stone
execute in minecraft:overworld run fill 421 65 42 421 66 42 dirt
execute in minecraft:overworld run setblock 421 67 42 grass_block
execute in minecraft:overworld run fill 421 68 42 421 144 42 air
execute in minecraft:overworld run fill 421 58 43 421 63 43 stone
execute in minecraft:overworld run fill 421 64 43 421 65 43 dirt
execute in minecraft:overworld run setblock 421 66 43 coarse_dirt
execute in minecraft:overworld run fill 421 67 43 421 144 43 air
execute in minecraft:overworld run fill 421 58 44 421 62 44 stone
execute in minecraft:overworld run fill 421 63 44 421 64 44 dirt
execute in minecraft:overworld run setblock 421 65 44 coarse_dirt
execute in minecraft:overworld run fill 421 66 44 421 144 44 air
execute in minecraft:overworld run fill 421 58 45 421 62 45 stone
execute in minecraft:overworld run fill 421 63 45 421 64 45 dirt
execute in minecraft:overworld run setblock 421 65 45 coarse_dirt
execute in minecraft:overworld run fill 421 66 45 421 144 45 air
execute in minecraft:overworld run fill 421 58 46 421 61 46 stone
execute in minecraft:overworld run fill 421 62 46 421 63 46 dirt
execute in minecraft:overworld run setblock 421 64 46 coarse_dirt
execute in minecraft:overworld run fill 421 65 46 421 144 46 air
execute in minecraft:overworld run fill 421 58 47 421 61 47 stone
execute in minecraft:overworld run fill 421 62 47 421 63 47 dirt
execute in minecraft:overworld run setblock 421 64 47 coarse_dirt
execute in minecraft:overworld run fill 421 65 47 421 144 47 air
execute in minecraft:overworld run fill 422 58 -48 422 61 -48 stone
execute in minecraft:overworld run fill 422 62 -48 422 63 -48 dirt
execute in minecraft:overworld run setblock 422 64 -48 coarse_dirt
execute in minecraft:overworld run fill 422 65 -48 422 144 -48 air
execute in minecraft:overworld run fill 422 58 -47 422 63 -47 stone
execute in minecraft:overworld run fill 422 64 -47 422 65 -47 dirt
execute in minecraft:overworld run setblock 422 66 -47 grass_block
execute in minecraft:overworld run fill 422 67 -47 422 144 -47 air
schedule function blade_gallery:random/battlefield/part_135 1t replace
