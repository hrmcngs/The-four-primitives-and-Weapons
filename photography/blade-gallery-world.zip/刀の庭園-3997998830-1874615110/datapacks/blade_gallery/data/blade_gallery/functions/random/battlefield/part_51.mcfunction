execute in minecraft:overworld run setblock 369 71 -19 coarse_dirt
execute in minecraft:overworld run fill 369 72 -19 369 144 -19 air
execute in minecraft:overworld run fill 369 58 -18 369 67 -18 stone
execute in minecraft:overworld run fill 369 68 -18 369 69 -18 dirt
execute in minecraft:overworld run setblock 369 70 -18 grass_block
execute in minecraft:overworld run fill 369 71 -18 369 144 -18 air
execute in minecraft:overworld run fill 369 58 -17 369 67 -17 stone
execute in minecraft:overworld run fill 369 68 -17 369 69 -17 dirt
execute in minecraft:overworld run setblock 369 70 -17 coarse_dirt
execute in minecraft:overworld run fill 369 71 -17 369 144 -17 air
execute in minecraft:overworld run fill 369 58 -16 369 67 -16 stone
execute in minecraft:overworld run fill 369 68 -16 369 69 -16 dirt
execute in minecraft:overworld run setblock 369 70 -16 coarse_dirt
execute in minecraft:overworld run fill 369 71 -16 369 144 -16 air
execute in minecraft:overworld run fill 369 58 -15 369 66 -15 stone
execute in minecraft:overworld run fill 369 67 -15 369 68 -15 dirt
execute in minecraft:overworld run setblock 369 69 -15 grass_block
execute in minecraft:overworld run fill 369 70 -15 369 144 -15 air
execute in minecraft:overworld run fill 369 58 -14 369 66 -14 stone
execute in minecraft:overworld run fill 369 67 -14 369 68 -14 dirt
execute in minecraft:overworld run setblock 369 69 -14 grass_block
execute in minecraft:overworld run fill 369 70 -14 369 144 -14 air
execute in minecraft:overworld run fill 369 58 -13 369 66 -13 stone
execute in minecraft:overworld run fill 369 67 -13 369 68 -13 dirt
execute in minecraft:overworld run setblock 369 69 -13 grass_block
execute in minecraft:overworld run fill 369 70 -13 369 144 -13 air
execute in minecraft:overworld run fill 369 58 -12 369 66 -12 stone
execute in minecraft:overworld run fill 369 67 -12 369 68 -12 dirt
execute in minecraft:overworld run setblock 369 69 -12 grass_block
execute in minecraft:overworld run fill 369 70 -12 369 144 -12 air
execute in minecraft:overworld run fill 369 58 -11 369 66 -11 stone
execute in minecraft:overworld run fill 369 67 -11 369 68 -11 dirt
execute in minecraft:overworld run setblock 369 69 -11 coarse_dirt
execute in minecraft:overworld run fill 369 70 -11 369 144 -11 air
execute in minecraft:overworld run setblock 369 70 -11 grass
execute in minecraft:overworld run fill 369 58 -10 369 66 -10 stone
execute in minecraft:overworld run fill 369 67 -10 369 68 -10 dirt
execute in minecraft:overworld run setblock 369 69 -10 grass_block
execute in minecraft:overworld run fill 369 70 -10 369 144 -10 air
execute in minecraft:overworld run fill 369 58 -9 369 66 -9 stone
execute in minecraft:overworld run fill 369 67 -9 369 68 -9 dirt
execute in minecraft:overworld run setblock 369 69 -9 coarse_dirt
execute in minecraft:overworld run fill 369 70 -9 369 144 -9 air
execute in minecraft:overworld run fill 369 58 -8 369 66 -8 stone
execute in minecraft:overworld run fill 369 67 -8 369 68 -8 dirt
execute in minecraft:overworld run setblock 369 69 -8 grass_block
execute in minecraft:overworld run fill 369 70 -8 369 144 -8 air
execute in minecraft:overworld run fill 369 58 -7 369 66 -7 stone
execute in minecraft:overworld run fill 369 67 -7 369 68 -7 dirt
execute in minecraft:overworld run setblock 369 69 -7 coarse_dirt
execute in minecraft:overworld run fill 369 70 -7 369 144 -7 air
execute in minecraft:overworld run fill 369 58 -6 369 65 -6 stone
execute in minecraft:overworld run fill 369 66 -6 369 67 -6 dirt
execute in minecraft:overworld run setblock 369 68 -6 coarse_dirt
execute in minecraft:overworld run fill 369 69 -6 369 144 -6 air
execute in minecraft:overworld run fill 369 58 -5 369 65 -5 stone
execute in minecraft:overworld run fill 369 66 -5 369 67 -5 dirt
execute in minecraft:overworld run setblock 369 68 -5 grass_block
execute in minecraft:overworld run fill 369 69 -5 369 144 -5 air
execute in minecraft:overworld run fill 369 58 -4 369 65 -4 stone
execute in minecraft:overworld run fill 369 66 -4 369 67 -4 dirt
execute in minecraft:overworld run setblock 369 68 -4 coarse_dirt
execute in minecraft:overworld run fill 369 69 -4 369 144 -4 air
execute in minecraft:overworld run fill 369 58 -3 369 65 -3 stone
execute in minecraft:overworld run fill 369 66 -3 369 67 -3 dirt
execute in minecraft:overworld run setblock 369 68 -3 coarse_dirt
execute in minecraft:overworld run fill 369 69 -3 369 144 -3 air
execute in minecraft:overworld run fill 369 58 -2 369 65 -2 stone
execute in minecraft:overworld run fill 369 66 -2 369 67 -2 dirt
execute in minecraft:overworld run setblock 369 68 -2 grass_block
execute in minecraft:overworld run fill 369 69 -2 369 144 -2 air
execute in minecraft:overworld run fill 369 58 -1 369 65 -1 stone
execute in minecraft:overworld run fill 369 66 -1 369 67 -1 dirt
execute in minecraft:overworld run setblock 369 68 -1 grass_block
execute in minecraft:overworld run fill 369 69 -1 369 144 -1 air
execute in minecraft:overworld run fill 369 58 0 369 65 0 stone
execute in minecraft:overworld run fill 369 66 0 369 67 0 dirt
execute in minecraft:overworld run setblock 369 68 0 grass_block
execute in minecraft:overworld run fill 369 69 0 369 144 0 air
execute in minecraft:overworld run fill 369 58 1 369 65 1 stone
execute in minecraft:overworld run fill 369 66 1 369 67 1 dirt
execute in minecraft:overworld run setblock 369 68 1 grass_block
execute in minecraft:overworld run fill 369 69 1 369 144 1 air
execute in minecraft:overworld run setblock 369 69 1 grass
execute in minecraft:overworld run fill 369 58 2 369 65 2 stone
execute in minecraft:overworld run fill 369 66 2 369 67 2 dirt
execute in minecraft:overworld run setblock 369 68 2 coarse_dirt
execute in minecraft:overworld run fill 369 69 2 369 144 2 air
execute in minecraft:overworld run fill 369 58 3 369 65 3 stone
execute in minecraft:overworld run fill 369 66 3 369 67 3 dirt
execute in minecraft:overworld run setblock 369 68 3 coarse_dirt
execute in minecraft:overworld run fill 369 69 3 369 144 3 air
execute in minecraft:overworld run fill 369 58 4 369 65 4 stone
execute in minecraft:overworld run fill 369 66 4 369 67 4 dirt
execute in minecraft:overworld run setblock 369 68 4 coarse_dirt
execute in minecraft:overworld run fill 369 69 4 369 144 4 air
execute in minecraft:overworld run fill 369 58 5 369 65 5 stone
execute in minecraft:overworld run fill 369 66 5 369 67 5 dirt
execute in minecraft:overworld run setblock 369 68 5 coarse_dirt
execute in minecraft:overworld run fill 369 69 5 369 144 5 air
execute in minecraft:overworld run fill 369 58 6 369 65 6 stone
execute in minecraft:overworld run fill 369 66 6 369 67 6 dirt
execute in minecraft:overworld run setblock 369 68 6 grass_block
execute in minecraft:overworld run fill 369 69 6 369 144 6 air
execute in minecraft:overworld run fill 369 58 7 369 65 7 stone
execute in minecraft:overworld run fill 369 66 7 369 67 7 dirt
execute in minecraft:overworld run setblock 369 68 7 coarse_dirt
execute in minecraft:overworld run fill 369 69 7 369 144 7 air
execute in minecraft:overworld run fill 369 58 8 369 65 8 stone
execute in minecraft:overworld run fill 369 66 8 369 67 8 dirt
execute in minecraft:overworld run setblock 369 68 8 grass_block
execute in minecraft:overworld run fill 369 69 8 369 144 8 air
execute in minecraft:overworld run fill 369 58 9 369 65 9 stone
execute in minecraft:overworld run fill 369 66 9 369 67 9 dirt
execute in minecraft:overworld run setblock 369 68 9 grass_block
execute in minecraft:overworld run fill 369 69 9 369 144 9 air
execute in minecraft:overworld run setblock 369 69 9 grass
execute in minecraft:overworld run fill 369 58 10 369 65 10 stone
execute in minecraft:overworld run fill 369 66 10 369 67 10 dirt
execute in minecraft:overworld run setblock 369 68 10 coarse_dirt
execute in minecraft:overworld run fill 369 69 10 369 144 10 air
execute in minecraft:overworld run fill 369 58 11 369 66 11 stone
execute in minecraft:overworld run fill 369 67 11 369 68 11 dirt
execute in minecraft:overworld run setblock 369 69 11 coarse_dirt
execute in minecraft:overworld run fill 369 70 11 369 144 11 air
execute in minecraft:overworld run setblock 369 70 11 mossy_cobblestone
execute in minecraft:overworld run fill 369 58 12 369 66 12 stone
execute in minecraft:overworld run fill 369 67 12 369 68 12 dirt
execute in minecraft:overworld run setblock 369 69 12 coarse_dirt
execute in minecraft:overworld run fill 369 70 12 369 144 12 air
execute in minecraft:overworld run fill 369 58 13 369 66 13 stone
execute in minecraft:overworld run fill 369 67 13 369 68 13 dirt
execute in minecraft:overworld run setblock 369 69 13 coarse_dirt
execute in minecraft:overworld run fill 369 70 13 369 144 13 air
execute in minecraft:overworld run fill 369 58 14 369 66 14 stone
execute in minecraft:overworld run fill 369 67 14 369 68 14 dirt
execute in minecraft:overworld run setblock 369 69 14 grass_block
execute in minecraft:overworld run fill 369 70 14 369 144 14 air
execute in minecraft:overworld run fill 369 58 15 369 67 15 stone
execute in minecraft:overworld run fill 369 68 15 369 69 15 dirt
execute in minecraft:overworld run setblock 369 70 15 grass_block
execute in minecraft:overworld run fill 369 71 15 369 144 15 air
execute in minecraft:overworld run fill 369 58 16 369 67 16 stone
execute in minecraft:overworld run fill 369 68 16 369 69 16 dirt
execute in minecraft:overworld run setblock 369 70 16 coarse_dirt
execute in minecraft:overworld run fill 369 71 16 369 144 16 air
execute in minecraft:overworld run fill 369 58 17 369 67 17 stone
execute in minecraft:overworld run fill 369 68 17 369 69 17 dirt
execute in minecraft:overworld run setblock 369 70 17 coarse_dirt
execute in minecraft:overworld run fill 369 71 17 369 144 17 air
execute in minecraft:overworld run fill 369 58 18 369 67 18 stone
execute in minecraft:overworld run fill 369 68 18 369 69 18 dirt
execute in minecraft:overworld run setblock 369 70 18 grass_block
execute in minecraft:overworld run fill 369 71 18 369 144 18 air
execute in minecraft:overworld run fill 369 58 19 369 68 19 stone
execute in minecraft:overworld run fill 369 69 19 369 70 19 dirt
execute in minecraft:overworld run setblock 369 71 19 grass_block
execute in minecraft:overworld run fill 369 72 19 369 144 19 air
execute in minecraft:overworld run fill 369 58 20 369 68 20 stone
execute in minecraft:overworld run fill 369 69 20 369 70 20 dirt
execute in minecraft:overworld run setblock 369 71 20 grass_block
execute in minecraft:overworld run fill 369 72 20 369 144 20 air
execute in minecraft:overworld run setblock 369 72 20 grass
execute in minecraft:overworld run fill 369 58 21 369 68 21 stone
execute in minecraft:overworld run fill 369 69 21 369 70 21 dirt
execute in minecraft:overworld run setblock 369 71 21 coarse_dirt
execute in minecraft:overworld run fill 369 72 21 369 144 21 air
execute in minecraft:overworld run setblock 369 72 21 grass
execute in minecraft:overworld run fill 369 58 22 369 68 22 stone
execute in minecraft:overworld run fill 369 69 22 369 70 22 dirt
execute in minecraft:overworld run setblock 369 71 22 grass_block
execute in minecraft:overworld run fill 369 72 22 369 144 22 air
execute in minecraft:overworld run fill 369 58 23 369 68 23 stone
execute in minecraft:overworld run fill 369 69 23 369 70 23 dirt
execute in minecraft:overworld run setblock 369 71 23 grass_block
execute in minecraft:overworld run fill 369 72 23 369 144 23 air
execute in minecraft:overworld run fill 369 58 24 369 68 24 stone
execute in minecraft:overworld run fill 369 69 24 369 70 24 dirt
execute in minecraft:overworld run setblock 369 71 24 grass_block
execute in minecraft:overworld run fill 369 72 24 369 144 24 air
execute in minecraft:overworld run fill 369 58 25 369 68 25 stone
execute in minecraft:overworld run fill 369 69 25 369 70 25 dirt
execute in minecraft:overworld run setblock 369 71 25 coarse_dirt
execute in minecraft:overworld run fill 369 72 25 369 144 25 air
execute in minecraft:overworld run fill 369 58 26 369 68 26 stone
execute in minecraft:overworld run fill 369 69 26 369 70 26 dirt
execute in minecraft:overworld run setblock 369 71 26 coarse_dirt
execute in minecraft:overworld run fill 369 72 26 369 144 26 air
execute in minecraft:overworld run fill 369 58 27 369 68 27 stone
execute in minecraft:overworld run fill 369 69 27 369 70 27 dirt
execute in minecraft:overworld run setblock 369 71 27 grass_block
execute in minecraft:overworld run fill 369 72 27 369 144 27 air
execute in minecraft:overworld run fill 369 58 28 369 68 28 stone
execute in minecraft:overworld run fill 369 69 28 369 70 28 dirt
execute in minecraft:overworld run setblock 369 71 28 coarse_dirt
execute in minecraft:overworld run fill 369 72 28 369 144 28 air
execute in minecraft:overworld run fill 369 58 29 369 68 29 stone
execute in minecraft:overworld run fill 369 69 29 369 70 29 dirt
execute in minecraft:overworld run setblock 369 71 29 coarse_dirt
execute in minecraft:overworld run fill 369 72 29 369 144 29 air
execute in minecraft:overworld run fill 369 58 30 369 69 30 stone
execute in minecraft:overworld run fill 369 70 30 369 71 30 dirt
execute in minecraft:overworld run setblock 369 72 30 coarse_dirt
execute in minecraft:overworld run fill 369 73 30 369 144 30 air
execute in minecraft:overworld run setblock 369 73 30 grass
execute in minecraft:overworld run fill 369 58 31 369 69 31 stone
execute in minecraft:overworld run fill 369 70 31 369 71 31 dirt
execute in minecraft:overworld run setblock 369 72 31 coarse_dirt
execute in minecraft:overworld run fill 369 73 31 369 144 31 air
execute in minecraft:overworld run fill 369 58 32 369 69 32 stone
execute in minecraft:overworld run fill 369 70 32 369 71 32 dirt
execute in minecraft:overworld run setblock 369 72 32 grass_block
execute in minecraft:overworld run fill 369 73 32 369 144 32 air
execute in minecraft:overworld run fill 369 58 33 369 70 33 stone
execute in minecraft:overworld run fill 369 71 33 369 72 33 dirt
execute in minecraft:overworld run setblock 369 73 33 grass_block
execute in minecraft:overworld run fill 369 74 33 369 144 33 air
execute in minecraft:overworld run fill 369 58 34 369 70 34 stone
execute in minecraft:overworld run fill 369 71 34 369 72 34 dirt
execute in minecraft:overworld run setblock 369 73 34 coarse_dirt
execute in minecraft:overworld run fill 369 74 34 369 144 34 air
execute in minecraft:overworld run fill 369 58 35 369 70 35 stone
execute in minecraft:overworld run fill 369 71 35 369 72 35 dirt
execute in minecraft:overworld run setblock 369 73 35 coarse_dirt
execute in minecraft:overworld run fill 369 74 35 369 144 35 air
execute in minecraft:overworld run fill 369 58 36 369 70 36 stone
execute in minecraft:overworld run fill 369 71 36 369 72 36 dirt
execute in minecraft:overworld run setblock 369 73 36 coarse_dirt
execute in minecraft:overworld run fill 369 74 36 369 144 36 air
execute in minecraft:overworld run fill 369 58 37 369 71 37 stone
execute in minecraft:overworld run fill 369 72 37 369 73 37 dirt
execute in minecraft:overworld run setblock 369 74 37 grass_block
execute in minecraft:overworld run fill 369 75 37 369 144 37 air
execute in minecraft:overworld run fill 369 58 38 369 71 38 stone
execute in minecraft:overworld run fill 369 72 38 369 73 38 dirt
execute in minecraft:overworld run setblock 369 74 38 coarse_dirt
execute in minecraft:overworld run fill 369 75 38 369 144 38 air
execute in minecraft:overworld run fill 369 58 39 369 70 39 stone
execute in minecraft:overworld run fill 369 71 39 369 72 39 dirt
execute in minecraft:overworld run setblock 369 73 39 grass_block
execute in minecraft:overworld run fill 369 74 39 369 144 39 air
execute in minecraft:overworld run fill 369 58 40 369 69 40 stone
execute in minecraft:overworld run fill 369 70 40 369 71 40 dirt
execute in minecraft:overworld run setblock 369 72 40 coarse_dirt
execute in minecraft:overworld run fill 369 73 40 369 144 40 air
execute in minecraft:overworld run setblock 369 73 40 mossy_cobblestone
execute in minecraft:overworld run fill 369 58 41 369 68 41 stone
execute in minecraft:overworld run fill 369 69 41 369 70 41 dirt
execute in minecraft:overworld run setblock 369 71 41 grass_block
execute in minecraft:overworld run fill 369 72 41 369 144 41 air
execute in minecraft:overworld run fill 369 58 42 369 67 42 stone
execute in minecraft:overworld run fill 369 68 42 369 69 42 dirt
execute in minecraft:overworld run setblock 369 70 42 grass_block
execute in minecraft:overworld run fill 369 71 42 369 144 42 air
execute in minecraft:overworld run fill 369 58 43 369 66 43 stone
execute in minecraft:overworld run fill 369 67 43 369 68 43 dirt
schedule function blade_gallery:random/battlefield/part_52 1t replace
