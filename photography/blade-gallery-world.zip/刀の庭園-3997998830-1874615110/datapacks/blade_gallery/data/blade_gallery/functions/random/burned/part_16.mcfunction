execute in minecraft:overworld run setblock 218 70 3 grass_block
execute in minecraft:overworld run fill 218 71 3 218 144 3 air
execute in minecraft:overworld run fill 218 58 4 218 67 4 stone
execute in minecraft:overworld run fill 218 68 4 218 69 4 dirt
execute in minecraft:overworld run setblock 218 70 4 coarse_dirt
execute in minecraft:overworld run fill 218 71 4 218 144 4 air
execute in minecraft:overworld run fill 218 58 5 218 67 5 stone
execute in minecraft:overworld run fill 218 68 5 218 69 5 dirt
execute in minecraft:overworld run setblock 218 70 5 coarse_dirt
execute in minecraft:overworld run fill 218 71 5 218 144 5 air
execute in minecraft:overworld run fill 218 58 6 218 67 6 stone
execute in minecraft:overworld run fill 218 68 6 218 69 6 dirt
execute in minecraft:overworld run setblock 218 70 6 grass_block
execute in minecraft:overworld run fill 218 71 6 218 144 6 air
execute in minecraft:overworld run fill 218 58 7 218 67 7 stone
execute in minecraft:overworld run fill 218 68 7 218 69 7 dirt
execute in minecraft:overworld run setblock 218 70 7 grass_block
execute in minecraft:overworld run fill 218 71 7 218 144 7 air
execute in minecraft:overworld run fill 218 58 8 218 67 8 stone
execute in minecraft:overworld run fill 218 68 8 218 69 8 dirt
execute in minecraft:overworld run setblock 218 70 8 grass_block
execute in minecraft:overworld run fill 218 71 8 218 144 8 air
execute in minecraft:overworld run fill 218 58 9 218 67 9 stone
execute in minecraft:overworld run fill 218 68 9 218 69 9 dirt
execute in minecraft:overworld run setblock 218 70 9 coarse_dirt
execute in minecraft:overworld run fill 218 71 9 218 144 9 air
execute in minecraft:overworld run fill 218 58 10 218 67 10 stone
execute in minecraft:overworld run fill 218 68 10 218 69 10 dirt
execute in minecraft:overworld run setblock 218 70 10 coarse_dirt
execute in minecraft:overworld run fill 218 71 10 218 144 10 air
execute in minecraft:overworld run fill 218 58 11 218 67 11 stone
execute in minecraft:overworld run fill 218 68 11 218 69 11 dirt
execute in minecraft:overworld run setblock 218 70 11 coarse_dirt
execute in minecraft:overworld run fill 218 71 11 218 144 11 air
execute in minecraft:overworld run fill 218 58 12 218 68 12 stone
execute in minecraft:overworld run fill 218 69 12 218 70 12 dirt
execute in minecraft:overworld run setblock 218 71 12 grass_block
execute in minecraft:overworld run fill 218 72 12 218 144 12 air
execute in minecraft:overworld run fill 218 58 13 218 68 13 stone
execute in minecraft:overworld run fill 218 69 13 218 70 13 dirt
execute in minecraft:overworld run setblock 218 71 13 coarse_dirt
execute in minecraft:overworld run fill 218 72 13 218 144 13 air
execute in minecraft:overworld run fill 218 58 14 218 69 14 stone
execute in minecraft:overworld run fill 218 70 14 218 71 14 dirt
execute in minecraft:overworld run setblock 218 72 14 coarse_dirt
execute in minecraft:overworld run fill 218 73 14 218 144 14 air
execute in minecraft:overworld run fill 218 58 15 218 69 15 stone
execute in minecraft:overworld run fill 218 70 15 218 71 15 dirt
execute in minecraft:overworld run setblock 218 72 15 coarse_dirt
execute in minecraft:overworld run fill 218 73 15 218 144 15 air
execute in minecraft:overworld run fill 218 58 16 218 69 16 stone
execute in minecraft:overworld run fill 218 70 16 218 71 16 dirt
execute in minecraft:overworld run setblock 218 72 16 coarse_dirt
execute in minecraft:overworld run fill 218 73 16 218 144 16 air
execute in minecraft:overworld run setblock 218 73 16 grass
execute in minecraft:overworld run fill 218 58 17 218 70 17 stone
execute in minecraft:overworld run fill 218 71 17 218 72 17 dirt
execute in minecraft:overworld run setblock 218 73 17 coarse_dirt
execute in minecraft:overworld run fill 218 74 17 218 144 17 air
execute in minecraft:overworld run fill 218 58 18 218 70 18 stone
execute in minecraft:overworld run fill 218 71 18 218 72 18 dirt
execute in minecraft:overworld run setblock 218 73 18 coarse_dirt
execute in minecraft:overworld run fill 218 74 18 218 144 18 air
execute in minecraft:overworld run fill 218 58 19 218 70 19 stone
execute in minecraft:overworld run fill 218 71 19 218 72 19 dirt
execute in minecraft:overworld run setblock 218 73 19 coarse_dirt
execute in minecraft:overworld run fill 218 74 19 218 144 19 air
execute in minecraft:overworld run fill 218 58 20 218 70 20 stone
execute in minecraft:overworld run fill 218 71 20 218 72 20 dirt
execute in minecraft:overworld run setblock 218 73 20 grass_block
execute in minecraft:overworld run fill 218 74 20 218 144 20 air
execute in minecraft:overworld run fill 218 58 21 218 70 21 stone
execute in minecraft:overworld run fill 218 71 21 218 72 21 dirt
execute in minecraft:overworld run setblock 218 73 21 coarse_dirt
execute in minecraft:overworld run fill 218 74 21 218 144 21 air
execute in minecraft:overworld run fill 218 58 22 218 71 22 stone
execute in minecraft:overworld run fill 218 72 22 218 73 22 dirt
execute in minecraft:overworld run setblock 218 74 22 coarse_dirt
execute in minecraft:overworld run fill 218 75 22 218 144 22 air
execute in minecraft:overworld run fill 218 58 23 218 71 23 stone
execute in minecraft:overworld run fill 218 72 23 218 73 23 dirt
execute in minecraft:overworld run setblock 218 74 23 coarse_dirt
execute in minecraft:overworld run fill 218 75 23 218 144 23 air
execute in minecraft:overworld run fill 218 58 24 218 71 24 stone
execute in minecraft:overworld run fill 218 72 24 218 73 24 dirt
execute in minecraft:overworld run setblock 218 74 24 coarse_dirt
execute in minecraft:overworld run fill 218 75 24 218 144 24 air
execute in minecraft:overworld run fill 218 58 25 218 71 25 stone
execute in minecraft:overworld run fill 218 72 25 218 73 25 dirt
execute in minecraft:overworld run setblock 218 74 25 coarse_dirt
execute in minecraft:overworld run fill 218 75 25 218 144 25 air
execute in minecraft:overworld run fill 218 58 26 218 71 26 stone
execute in minecraft:overworld run fill 218 72 26 218 73 26 dirt
execute in minecraft:overworld run setblock 218 74 26 grass_block
execute in minecraft:overworld run fill 218 75 26 218 144 26 air
execute in minecraft:overworld run fill 218 58 27 218 71 27 stone
execute in minecraft:overworld run fill 218 72 27 218 73 27 dirt
execute in minecraft:overworld run setblock 218 74 27 grass_block
execute in minecraft:overworld run fill 218 75 27 218 144 27 air
execute in minecraft:overworld run fill 218 58 28 218 71 28 stone
execute in minecraft:overworld run fill 218 72 28 218 73 28 dirt
execute in minecraft:overworld run setblock 218 74 28 coarse_dirt
execute in minecraft:overworld run fill 218 75 28 218 144 28 air
execute in minecraft:overworld run fill 218 58 29 218 71 29 stone
execute in minecraft:overworld run fill 218 72 29 218 73 29 dirt
execute in minecraft:overworld run setblock 218 74 29 coarse_dirt
execute in minecraft:overworld run fill 218 75 29 218 144 29 air
execute in minecraft:overworld run fill 218 58 30 218 71 30 stone
execute in minecraft:overworld run fill 218 72 30 218 73 30 dirt
execute in minecraft:overworld run setblock 218 74 30 grass_block
execute in minecraft:overworld run fill 218 75 30 218 144 30 air
execute in minecraft:overworld run fill 218 58 31 218 71 31 stone
execute in minecraft:overworld run fill 218 72 31 218 73 31 dirt
execute in minecraft:overworld run setblock 218 74 31 grass_block
execute in minecraft:overworld run fill 218 75 31 218 144 31 air
execute in minecraft:overworld run setblock 218 75 31 grass
execute in minecraft:overworld run fill 218 58 32 218 70 32 stone
execute in minecraft:overworld run fill 218 71 32 218 72 32 dirt
execute in minecraft:overworld run setblock 218 73 32 coarse_dirt
execute in minecraft:overworld run fill 218 74 32 218 144 32 air
execute in minecraft:overworld run fill 218 58 33 218 70 33 stone
execute in minecraft:overworld run fill 218 71 33 218 72 33 dirt
execute in minecraft:overworld run setblock 218 73 33 coarse_dirt
execute in minecraft:overworld run fill 218 74 33 218 144 33 air
execute in minecraft:overworld run fill 218 58 34 218 70 34 stone
execute in minecraft:overworld run fill 218 71 34 218 72 34 dirt
execute in minecraft:overworld run setblock 218 73 34 coarse_dirt
execute in minecraft:overworld run fill 218 74 34 218 144 34 air
execute in minecraft:overworld run setblock 218 74 34 grass
execute in minecraft:overworld run fill 218 58 35 218 69 35 stone
execute in minecraft:overworld run fill 218 70 35 218 71 35 dirt
execute in minecraft:overworld run setblock 218 72 35 grass_block
execute in minecraft:overworld run fill 218 73 35 218 144 35 air
execute in minecraft:overworld run setblock 218 73 35 mossy_cobblestone
execute in minecraft:overworld run fill 218 58 36 218 69 36 stone
execute in minecraft:overworld run fill 218 70 36 218 71 36 dirt
execute in minecraft:overworld run setblock 218 72 36 coarse_dirt
execute in minecraft:overworld run fill 218 73 36 218 144 36 air
execute in minecraft:overworld run setblock 218 73 36 mossy_cobblestone
execute in minecraft:overworld run fill 218 58 37 218 69 37 stone
execute in minecraft:overworld run fill 218 70 37 218 71 37 dirt
execute in minecraft:overworld run setblock 218 72 37 coarse_dirt
execute in minecraft:overworld run fill 218 73 37 218 144 37 air
execute in minecraft:overworld run setblock 218 73 37 grass
execute in minecraft:overworld run fill 218 58 38 218 68 38 stone
execute in minecraft:overworld run fill 218 69 38 218 70 38 dirt
execute in minecraft:overworld run setblock 218 71 38 coarse_dirt
execute in minecraft:overworld run fill 218 72 38 218 144 38 air
execute in minecraft:overworld run fill 218 58 39 218 67 39 stone
execute in minecraft:overworld run fill 218 68 39 218 69 39 dirt
execute in minecraft:overworld run setblock 218 70 39 grass_block
execute in minecraft:overworld run fill 218 71 39 218 144 39 air
execute in minecraft:overworld run setblock 218 71 39 grass
execute in minecraft:overworld run fill 218 58 40 218 66 40 stone
execute in minecraft:overworld run fill 218 67 40 218 68 40 dirt
execute in minecraft:overworld run setblock 218 69 40 coarse_dirt
execute in minecraft:overworld run fill 218 70 40 218 144 40 air
execute in minecraft:overworld run fill 218 58 41 218 65 41 stone
execute in minecraft:overworld run fill 218 66 41 218 67 41 dirt
execute in minecraft:overworld run setblock 218 68 41 coarse_dirt
execute in minecraft:overworld run fill 218 69 41 218 144 41 air
execute in minecraft:overworld run fill 218 58 42 218 64 42 stone
execute in minecraft:overworld run fill 218 65 42 218 66 42 dirt
execute in minecraft:overworld run setblock 218 67 42 coarse_dirt
execute in minecraft:overworld run fill 218 68 42 218 144 42 air
execute in minecraft:overworld run fill 218 58 43 218 63 43 stone
execute in minecraft:overworld run fill 218 64 43 218 65 43 dirt
execute in minecraft:overworld run setblock 218 66 43 grass_block
execute in minecraft:overworld run fill 218 67 43 218 144 43 air
execute in minecraft:overworld run fill 218 58 44 218 63 44 stone
execute in minecraft:overworld run fill 218 64 44 218 65 44 dirt
execute in minecraft:overworld run setblock 218 66 44 coarse_dirt
execute in minecraft:overworld run fill 218 67 44 218 144 44 air
execute in minecraft:overworld run fill 218 58 45 218 62 45 stone
execute in minecraft:overworld run fill 218 63 45 218 64 45 dirt
execute in minecraft:overworld run setblock 218 65 45 grass_block
execute in minecraft:overworld run fill 218 66 45 218 144 45 air
execute in minecraft:overworld run fill 218 58 46 218 62 46 stone
execute in minecraft:overworld run fill 218 63 46 218 64 46 dirt
execute in minecraft:overworld run setblock 218 65 46 coarse_dirt
execute in minecraft:overworld run fill 218 66 46 218 144 46 air
execute in minecraft:overworld run fill 218 58 47 218 61 47 stone
execute in minecraft:overworld run fill 218 62 47 218 63 47 dirt
execute in minecraft:overworld run setblock 218 64 47 coarse_dirt
execute in minecraft:overworld run fill 218 65 47 218 144 47 air
execute in minecraft:overworld run fill 219 58 -48 219 61 -48 stone
execute in minecraft:overworld run fill 219 62 -48 219 63 -48 dirt
execute in minecraft:overworld run setblock 219 64 -48 coarse_dirt
execute in minecraft:overworld run fill 219 65 -48 219 144 -48 air
execute in minecraft:overworld run fill 219 58 -47 219 63 -47 stone
execute in minecraft:overworld run fill 219 64 -47 219 65 -47 dirt
execute in minecraft:overworld run setblock 219 66 -47 coarse_dirt
execute in minecraft:overworld run fill 219 67 -47 219 144 -47 air
execute in minecraft:overworld run fill 219 58 -46 219 64 -46 stone
execute in minecraft:overworld run fill 219 65 -46 219 66 -46 dirt
execute in minecraft:overworld run setblock 219 67 -46 coarse_dirt
execute in minecraft:overworld run fill 219 68 -46 219 144 -46 air
execute in minecraft:overworld run fill 219 58 -45 219 66 -45 stone
execute in minecraft:overworld run fill 219 67 -45 219 68 -45 dirt
execute in minecraft:overworld run setblock 219 69 -45 grass_block
execute in minecraft:overworld run fill 219 70 -45 219 144 -45 air
execute in minecraft:overworld run fill 219 58 -44 219 67 -44 stone
execute in minecraft:overworld run fill 219 68 -44 219 69 -44 dirt
execute in minecraft:overworld run setblock 219 70 -44 coarse_dirt
execute in minecraft:overworld run fill 219 71 -44 219 144 -44 air
execute in minecraft:overworld run fill 219 58 -43 219 68 -43 stone
execute in minecraft:overworld run fill 219 69 -43 219 70 -43 dirt
execute in minecraft:overworld run setblock 219 71 -43 coarse_dirt
execute in minecraft:overworld run fill 219 72 -43 219 144 -43 air
execute in minecraft:overworld run fill 219 58 -42 219 69 -42 stone
execute in minecraft:overworld run fill 219 70 -42 219 71 -42 dirt
execute in minecraft:overworld run setblock 219 72 -42 coarse_dirt
execute in minecraft:overworld run fill 219 73 -42 219 144 -42 air
execute in minecraft:overworld run fill 219 58 -41 219 70 -41 stone
execute in minecraft:overworld run fill 219 71 -41 219 72 -41 dirt
execute in minecraft:overworld run setblock 219 73 -41 coarse_dirt
execute in minecraft:overworld run fill 219 74 -41 219 144 -41 air
execute in minecraft:overworld run fill 219 58 -40 219 71 -40 stone
execute in minecraft:overworld run fill 219 72 -40 219 73 -40 dirt
execute in minecraft:overworld run setblock 219 74 -40 coarse_dirt
execute in minecraft:overworld run fill 219 75 -40 219 144 -40 air
execute in minecraft:overworld run fill 219 58 -39 219 71 -39 stone
execute in minecraft:overworld run fill 219 72 -39 219 73 -39 dirt
execute in minecraft:overworld run setblock 219 74 -39 coarse_dirt
execute in minecraft:overworld run fill 219 75 -39 219 144 -39 air
execute in minecraft:overworld run setblock 219 75 -39 grass
execute in minecraft:overworld run fill 219 58 -38 219 71 -38 stone
execute in minecraft:overworld run fill 219 72 -38 219 73 -38 dirt
execute in minecraft:overworld run setblock 219 74 -38 grass_block
execute in minecraft:overworld run fill 219 75 -38 219 144 -38 air
execute in minecraft:overworld run fill 219 58 -37 219 71 -37 stone
execute in minecraft:overworld run fill 219 72 -37 219 73 -37 dirt
execute in minecraft:overworld run setblock 219 74 -37 coarse_dirt
execute in minecraft:overworld run fill 219 75 -37 219 144 -37 air
execute in minecraft:overworld run fill 219 58 -36 219 70 -36 stone
execute in minecraft:overworld run fill 219 71 -36 219 72 -36 dirt
execute in minecraft:overworld run setblock 219 73 -36 grass_block
execute in minecraft:overworld run fill 219 74 -36 219 144 -36 air
execute in minecraft:overworld run setblock 219 74 -36 grass
execute in minecraft:overworld run fill 219 58 -35 219 69 -35 stone
execute in minecraft:overworld run fill 219 70 -35 219 71 -35 dirt
execute in minecraft:overworld run setblock 219 72 -35 grass_block
execute in minecraft:overworld run fill 219 73 -35 219 144 -35 air
execute in minecraft:overworld run fill 219 58 -34 219 69 -34 stone
execute in minecraft:overworld run fill 219 70 -34 219 71 -34 dirt
execute in minecraft:overworld run setblock 219 72 -34 coarse_dirt
execute in minecraft:overworld run fill 219 73 -34 219 144 -34 air
execute in minecraft:overworld run fill 219 58 -33 219 68 -33 stone
execute in minecraft:overworld run fill 219 69 -33 219 70 -33 dirt
execute in minecraft:overworld run setblock 219 71 -33 grass_block
execute in minecraft:overworld run fill 219 72 -33 219 144 -33 air
execute in minecraft:overworld run fill 219 58 -32 219 68 -32 stone
execute in minecraft:overworld run fill 219 69 -32 219 70 -32 dirt
execute in minecraft:overworld run setblock 219 71 -32 coarse_dirt
execute in minecraft:overworld run fill 219 72 -32 219 144 -32 air
execute in minecraft:overworld run fill 219 58 -31 219 67 -31 stone
schedule function blade_gallery:random/burned/part_17 1t replace
