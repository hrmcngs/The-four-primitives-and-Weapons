execute in minecraft:overworld run fill 384 58 -32 384 68 -32 stone
execute in minecraft:overworld run fill 384 69 -32 384 70 -32 dirt
execute in minecraft:overworld run setblock 384 71 -32 coarse_dirt
execute in minecraft:overworld run fill 384 72 -32 384 144 -32 air
execute in minecraft:overworld run fill 384 58 -31 384 67 -31 stone
execute in minecraft:overworld run fill 384 68 -31 384 69 -31 dirt
execute in minecraft:overworld run setblock 384 70 -31 grass_block
execute in minecraft:overworld run fill 384 71 -31 384 144 -31 air
execute in minecraft:overworld run fill 384 58 -30 384 67 -30 stone
execute in minecraft:overworld run fill 384 68 -30 384 69 -30 dirt
execute in minecraft:overworld run setblock 384 70 -30 grass_block
execute in minecraft:overworld run fill 384 71 -30 384 144 -30 air
execute in minecraft:overworld run fill 384 58 -29 384 66 -29 stone
execute in minecraft:overworld run fill 384 67 -29 384 68 -29 dirt
execute in minecraft:overworld run setblock 384 69 -29 coarse_dirt
execute in minecraft:overworld run fill 384 70 -29 384 144 -29 air
execute in minecraft:overworld run fill 384 58 -28 384 66 -28 stone
execute in minecraft:overworld run fill 384 67 -28 384 68 -28 dirt
execute in minecraft:overworld run setblock 384 69 -28 grass_block
execute in minecraft:overworld run fill 384 70 -28 384 144 -28 air
execute in minecraft:overworld run fill 384 58 -27 384 65 -27 stone
execute in minecraft:overworld run fill 384 66 -27 384 67 -27 dirt
execute in minecraft:overworld run setblock 384 68 -27 coarse_dirt
execute in minecraft:overworld run fill 384 69 -27 384 144 -27 air
execute in minecraft:overworld run fill 384 58 -26 384 64 -26 stone
execute in minecraft:overworld run fill 384 65 -26 384 66 -26 dirt
execute in minecraft:overworld run setblock 384 67 -26 coarse_dirt
execute in minecraft:overworld run fill 384 68 -26 384 144 -26 air
execute in minecraft:overworld run fill 384 58 -25 384 63 -25 stone
execute in minecraft:overworld run fill 384 64 -25 384 65 -25 dirt
execute in minecraft:overworld run setblock 384 66 -25 grass_block
execute in minecraft:overworld run fill 384 67 -25 384 144 -25 air
execute in minecraft:overworld run fill 384 58 -24 384 62 -24 stone
execute in minecraft:overworld run fill 384 63 -24 384 64 -24 dirt
execute in minecraft:overworld run setblock 384 65 -24 coarse_dirt
execute in minecraft:overworld run fill 384 66 -24 384 144 -24 air
execute in minecraft:overworld run fill 384 58 -23 384 62 -23 stone
execute in minecraft:overworld run fill 384 63 -23 384 64 -23 dirt
execute in minecraft:overworld run setblock 384 65 -23 coarse_dirt
execute in minecraft:overworld run fill 384 66 -23 384 144 -23 air
execute in minecraft:overworld run setblock 384 66 -23 grass
execute in minecraft:overworld run fill 384 58 -22 384 61 -22 stone
execute in minecraft:overworld run fill 384 62 -22 384 63 -22 dirt
execute in minecraft:overworld run setblock 384 64 -22 coarse_dirt
execute in minecraft:overworld run fill 384 65 -22 384 144 -22 air
execute in minecraft:overworld run fill 384 58 -21 384 60 -21 stone
execute in minecraft:overworld run fill 384 61 -21 384 62 -21 dirt
execute in minecraft:overworld run setblock 384 63 -21 gravel
execute in minecraft:overworld run fill 384 64 -21 384 144 -21 air
execute in minecraft:overworld run fill 384 64 -21 384 64 -21 water
execute in minecraft:overworld run fill 384 58 -20 384 60 -20 stone
execute in minecraft:overworld run fill 384 61 -20 384 62 -20 dirt
execute in minecraft:overworld run setblock 384 63 -20 gravel
execute in minecraft:overworld run fill 384 64 -20 384 144 -20 air
execute in minecraft:overworld run fill 384 64 -20 384 64 -20 water
execute in minecraft:overworld run fill 384 58 -19 384 59 -19 stone
execute in minecraft:overworld run fill 384 60 -19 384 61 -19 dirt
execute in minecraft:overworld run setblock 384 62 -19 gravel
execute in minecraft:overworld run fill 384 63 -19 384 144 -19 air
execute in minecraft:overworld run fill 384 63 -19 384 64 -19 water
execute in minecraft:overworld run fill 384 58 -18 384 59 -18 stone
execute in minecraft:overworld run fill 384 60 -18 384 61 -18 dirt
execute in minecraft:overworld run setblock 384 62 -18 gravel
execute in minecraft:overworld run fill 384 63 -18 384 144 -18 air
execute in minecraft:overworld run fill 384 63 -18 384 64 -18 water
execute in minecraft:overworld run fill 384 58 -17 384 59 -17 stone
execute in minecraft:overworld run fill 384 60 -17 384 61 -17 dirt
execute in minecraft:overworld run setblock 384 62 -17 gravel
execute in minecraft:overworld run fill 384 63 -17 384 144 -17 air
execute in minecraft:overworld run fill 384 63 -17 384 64 -17 water
execute in minecraft:overworld run fill 384 58 -16 384 58 -16 stone
execute in minecraft:overworld run fill 384 59 -16 384 60 -16 dirt
execute in minecraft:overworld run setblock 384 61 -16 gravel
execute in minecraft:overworld run fill 384 62 -16 384 144 -16 air
execute in minecraft:overworld run fill 384 62 -16 384 64 -16 water
execute in minecraft:overworld run fill 384 58 -15 384 58 -15 stone
execute in minecraft:overworld run fill 384 59 -15 384 60 -15 dirt
execute in minecraft:overworld run setblock 384 61 -15 gravel
execute in minecraft:overworld run fill 384 62 -15 384 144 -15 air
execute in minecraft:overworld run fill 384 62 -15 384 64 -15 water
execute in minecraft:overworld run fill 384 58 -14 384 58 -14 stone
execute in minecraft:overworld run fill 384 59 -14 384 60 -14 dirt
execute in minecraft:overworld run setblock 384 61 -14 gravel
execute in minecraft:overworld run fill 384 62 -14 384 144 -14 air
execute in minecraft:overworld run fill 384 62 -14 384 64 -14 water
execute in minecraft:overworld run fill 384 58 -13 384 58 -13 stone
execute in minecraft:overworld run fill 384 59 -13 384 60 -13 dirt
execute in minecraft:overworld run setblock 384 61 -13 gravel
execute in minecraft:overworld run fill 384 62 -13 384 144 -13 air
execute in minecraft:overworld run fill 384 62 -13 384 64 -13 water
execute in minecraft:overworld run fill 384 58 -12 384 58 -12 stone
execute in minecraft:overworld run fill 384 59 -12 384 60 -12 dirt
execute in minecraft:overworld run setblock 384 61 -12 gravel
execute in minecraft:overworld run fill 384 62 -12 384 144 -12 air
execute in minecraft:overworld run fill 384 62 -12 384 64 -12 water
execute in minecraft:overworld run fill 384 58 -11 384 59 -11 stone
execute in minecraft:overworld run fill 384 60 -11 384 61 -11 dirt
execute in minecraft:overworld run setblock 384 62 -11 gravel
execute in minecraft:overworld run fill 384 63 -11 384 144 -11 air
execute in minecraft:overworld run fill 384 63 -11 384 64 -11 water
execute in minecraft:overworld run fill 384 58 -10 384 59 -10 stone
execute in minecraft:overworld run fill 384 60 -10 384 61 -10 dirt
execute in minecraft:overworld run setblock 384 62 -10 gravel
execute in minecraft:overworld run fill 384 63 -10 384 144 -10 air
execute in minecraft:overworld run fill 384 63 -10 384 64 -10 water
execute in minecraft:overworld run fill 384 58 -9 384 59 -9 stone
execute in minecraft:overworld run fill 384 60 -9 384 61 -9 dirt
execute in minecraft:overworld run setblock 384 62 -9 gravel
execute in minecraft:overworld run fill 384 63 -9 384 144 -9 air
execute in minecraft:overworld run fill 384 63 -9 384 64 -9 water
execute in minecraft:overworld run fill 384 58 -8 384 59 -8 stone
execute in minecraft:overworld run fill 384 60 -8 384 61 -8 dirt
execute in minecraft:overworld run setblock 384 62 -8 gravel
execute in minecraft:overworld run fill 384 63 -8 384 144 -8 air
execute in minecraft:overworld run fill 384 63 -8 384 64 -8 water
execute in minecraft:overworld run fill 384 58 -7 384 60 -7 stone
execute in minecraft:overworld run fill 384 61 -7 384 62 -7 dirt
execute in minecraft:overworld run setblock 384 63 -7 gravel
execute in minecraft:overworld run fill 384 64 -7 384 144 -7 air
execute in minecraft:overworld run fill 384 64 -7 384 64 -7 water
execute in minecraft:overworld run fill 384 58 -6 384 60 -6 stone
execute in minecraft:overworld run fill 384 61 -6 384 62 -6 dirt
execute in minecraft:overworld run setblock 384 63 -6 gravel
execute in minecraft:overworld run fill 384 64 -6 384 144 -6 air
execute in minecraft:overworld run fill 384 64 -6 384 64 -6 water
execute in minecraft:overworld run fill 384 58 -5 384 60 -5 stone
execute in minecraft:overworld run fill 384 61 -5 384 62 -5 dirt
execute in minecraft:overworld run setblock 384 63 -5 gravel
execute in minecraft:overworld run fill 384 64 -5 384 144 -5 air
execute in minecraft:overworld run fill 384 64 -5 384 64 -5 water
execute in minecraft:overworld run fill 384 58 -4 384 61 -4 stone
execute in minecraft:overworld run fill 384 62 -4 384 63 -4 dirt
execute in minecraft:overworld run setblock 384 64 -4 grass_block
execute in minecraft:overworld run fill 384 65 -4 384 144 -4 air
execute in minecraft:overworld run fill 384 58 -3 384 61 -3 stone
execute in minecraft:overworld run fill 384 62 -3 384 63 -3 dirt
execute in minecraft:overworld run setblock 384 64 -3 coarse_dirt
execute in minecraft:overworld run fill 384 65 -3 384 144 -3 air
execute in minecraft:overworld run fill 384 58 -2 384 61 -2 stone
execute in minecraft:overworld run fill 384 62 -2 384 63 -2 dirt
execute in minecraft:overworld run setblock 384 64 -2 coarse_dirt
execute in minecraft:overworld run fill 384 65 -2 384 144 -2 air
execute in minecraft:overworld run fill 384 58 -1 384 62 -1 stone
execute in minecraft:overworld run fill 384 63 -1 384 64 -1 dirt
execute in minecraft:overworld run setblock 384 65 -1 coarse_dirt
execute in minecraft:overworld run fill 384 66 -1 384 144 -1 air
execute in minecraft:overworld run fill 384 58 0 384 62 0 stone
execute in minecraft:overworld run fill 384 63 0 384 64 0 dirt
execute in minecraft:overworld run setblock 384 65 0 coarse_dirt
execute in minecraft:overworld run fill 384 66 0 384 144 0 air
execute in minecraft:overworld run setblock 384 66 0 grass
execute in minecraft:overworld run fill 384 58 1 384 62 1 stone
execute in minecraft:overworld run fill 384 63 1 384 64 1 dirt
execute in minecraft:overworld run setblock 384 65 1 coarse_dirt
execute in minecraft:overworld run fill 384 66 1 384 144 1 air
execute in minecraft:overworld run fill 384 58 2 384 62 2 stone
execute in minecraft:overworld run fill 384 63 2 384 64 2 dirt
execute in minecraft:overworld run setblock 384 65 2 coarse_dirt
execute in minecraft:overworld run fill 384 66 2 384 144 2 air
execute in minecraft:overworld run fill 384 58 3 384 62 3 stone
execute in minecraft:overworld run fill 384 63 3 384 64 3 dirt
execute in minecraft:overworld run setblock 384 65 3 coarse_dirt
execute in minecraft:overworld run fill 384 66 3 384 144 3 air
execute in minecraft:overworld run fill 384 58 4 384 62 4 stone
execute in minecraft:overworld run fill 384 63 4 384 64 4 dirt
execute in minecraft:overworld run setblock 384 65 4 grass_block
execute in minecraft:overworld run fill 384 66 4 384 144 4 air
execute in minecraft:overworld run fill 384 58 5 384 62 5 stone
execute in minecraft:overworld run fill 384 63 5 384 64 5 dirt
execute in minecraft:overworld run setblock 384 65 5 coarse_dirt
execute in minecraft:overworld run fill 384 66 5 384 144 5 air
execute in minecraft:overworld run fill 384 58 6 384 62 6 stone
execute in minecraft:overworld run fill 384 63 6 384 64 6 dirt
execute in minecraft:overworld run setblock 384 65 6 coarse_dirt
execute in minecraft:overworld run fill 384 66 6 384 144 6 air
execute in minecraft:overworld run fill 384 58 7 384 62 7 stone
execute in minecraft:overworld run fill 384 63 7 384 64 7 dirt
execute in minecraft:overworld run setblock 384 65 7 coarse_dirt
execute in minecraft:overworld run fill 384 66 7 384 144 7 air
execute in minecraft:overworld run fill 384 58 8 384 62 8 stone
execute in minecraft:overworld run fill 384 63 8 384 64 8 dirt
execute in minecraft:overworld run setblock 384 65 8 grass_block
execute in minecraft:overworld run fill 384 66 8 384 144 8 air
execute in minecraft:overworld run fill 384 58 9 384 63 9 stone
execute in minecraft:overworld run fill 384 64 9 384 65 9 dirt
execute in minecraft:overworld run setblock 384 66 9 coarse_dirt
execute in minecraft:overworld run fill 384 67 9 384 144 9 air
execute in minecraft:overworld run fill 384 58 10 384 63 10 stone
execute in minecraft:overworld run fill 384 64 10 384 65 10 dirt
execute in minecraft:overworld run setblock 384 66 10 coarse_dirt
execute in minecraft:overworld run fill 384 67 10 384 144 10 air
execute in minecraft:overworld run fill 384 58 11 384 63 11 stone
execute in minecraft:overworld run fill 384 64 11 384 65 11 dirt
execute in minecraft:overworld run setblock 384 66 11 grass_block
execute in minecraft:overworld run fill 384 67 11 384 144 11 air
execute in minecraft:overworld run fill 384 58 12 384 63 12 stone
execute in minecraft:overworld run fill 384 64 12 384 65 12 dirt
execute in minecraft:overworld run setblock 384 66 12 grass_block
execute in minecraft:overworld run fill 384 67 12 384 144 12 air
execute in minecraft:overworld run fill 384 58 13 384 63 13 stone
execute in minecraft:overworld run fill 384 64 13 384 65 13 dirt
execute in minecraft:overworld run setblock 384 66 13 coarse_dirt
execute in minecraft:overworld run fill 384 67 13 384 144 13 air
execute in minecraft:overworld run fill 384 58 14 384 64 14 stone
execute in minecraft:overworld run fill 384 65 14 384 66 14 dirt
execute in minecraft:overworld run setblock 384 67 14 coarse_dirt
execute in minecraft:overworld run fill 384 68 14 384 144 14 air
execute in minecraft:overworld run fill 384 58 15 384 64 15 stone
execute in minecraft:overworld run fill 384 65 15 384 66 15 dirt
execute in minecraft:overworld run setblock 384 67 15 grass_block
execute in minecraft:overworld run fill 384 68 15 384 144 15 air
execute in minecraft:overworld run fill 384 58 16 384 64 16 stone
execute in minecraft:overworld run fill 384 65 16 384 66 16 dirt
execute in minecraft:overworld run setblock 384 67 16 grass_block
execute in minecraft:overworld run fill 384 68 16 384 144 16 air
execute in minecraft:overworld run fill 384 58 17 384 64 17 stone
execute in minecraft:overworld run fill 384 65 17 384 66 17 dirt
execute in minecraft:overworld run setblock 384 67 17 coarse_dirt
execute in minecraft:overworld run fill 384 68 17 384 144 17 air
execute in minecraft:overworld run fill 384 58 18 384 64 18 stone
execute in minecraft:overworld run fill 384 65 18 384 66 18 dirt
execute in minecraft:overworld run setblock 384 67 18 coarse_dirt
execute in minecraft:overworld run fill 384 68 18 384 144 18 air
execute in minecraft:overworld run fill 384 58 19 384 64 19 stone
execute in minecraft:overworld run fill 384 65 19 384 66 19 dirt
execute in minecraft:overworld run setblock 384 67 19 grass_block
execute in minecraft:overworld run fill 384 68 19 384 144 19 air
execute in minecraft:overworld run fill 384 58 20 384 64 20 stone
execute in minecraft:overworld run fill 384 65 20 384 66 20 dirt
execute in minecraft:overworld run setblock 384 67 20 coarse_dirt
execute in minecraft:overworld run fill 384 68 20 384 144 20 air
execute in minecraft:overworld run fill 384 58 21 384 64 21 stone
execute in minecraft:overworld run fill 384 65 21 384 66 21 dirt
execute in minecraft:overworld run setblock 384 67 21 coarse_dirt
execute in minecraft:overworld run fill 384 68 21 384 144 21 air
execute in minecraft:overworld run fill 384 58 22 384 64 22 stone
execute in minecraft:overworld run fill 384 65 22 384 66 22 dirt
execute in minecraft:overworld run setblock 384 67 22 coarse_dirt
execute in minecraft:overworld run fill 384 68 22 384 144 22 air
execute in minecraft:overworld run fill 384 58 23 384 64 23 stone
execute in minecraft:overworld run fill 384 65 23 384 66 23 dirt
execute in minecraft:overworld run setblock 384 67 23 coarse_dirt
execute in minecraft:overworld run fill 384 68 23 384 144 23 air
execute in minecraft:overworld run fill 384 58 24 384 64 24 stone
execute in minecraft:overworld run fill 384 65 24 384 66 24 dirt
execute in minecraft:overworld run setblock 384 67 24 grass_block
execute in minecraft:overworld run fill 384 68 24 384 144 24 air
execute in minecraft:overworld run fill 384 58 25 384 64 25 stone
execute in minecraft:overworld run fill 384 65 25 384 66 25 dirt
execute in minecraft:overworld run setblock 384 67 25 grass_block
execute in minecraft:overworld run fill 384 68 25 384 144 25 air
execute in minecraft:overworld run fill 384 58 26 384 64 26 stone
execute in minecraft:overworld run fill 384 65 26 384 66 26 dirt
execute in minecraft:overworld run setblock 384 67 26 grass_block
execute in minecraft:overworld run fill 384 68 26 384 144 26 air
execute in minecraft:overworld run fill 384 58 27 384 64 27 stone
schedule function blade_gallery:random/battlefield/part_75 1t replace
