execute in minecraft:overworld run fill 299 65 -7 299 66 -7 dirt
execute in minecraft:overworld run setblock 299 67 -7 coarse_dirt
execute in minecraft:overworld run fill 299 68 -7 299 144 -7 air
execute in minecraft:overworld run fill 299 58 -6 299 64 -6 stone
execute in minecraft:overworld run fill 299 65 -6 299 66 -6 dirt
execute in minecraft:overworld run setblock 299 67 -6 coarse_dirt
execute in minecraft:overworld run fill 299 68 -6 299 144 -6 air
execute in minecraft:overworld run fill 299 58 -5 299 65 -5 stone
execute in minecraft:overworld run fill 299 66 -5 299 67 -5 dirt
execute in minecraft:overworld run setblock 299 68 -5 grass_block
execute in minecraft:overworld run fill 299 69 -5 299 144 -5 air
execute in minecraft:overworld run fill 299 58 -4 299 65 -4 stone
execute in minecraft:overworld run fill 299 66 -4 299 67 -4 dirt
execute in minecraft:overworld run setblock 299 68 -4 grass_block
execute in minecraft:overworld run fill 299 69 -4 299 144 -4 air
execute in minecraft:overworld run fill 299 58 -3 299 65 -3 stone
execute in minecraft:overworld run fill 299 66 -3 299 67 -3 dirt
execute in minecraft:overworld run setblock 299 68 -3 coarse_dirt
execute in minecraft:overworld run fill 299 69 -3 299 144 -3 air
execute in minecraft:overworld run fill 299 58 -2 299 65 -2 stone
execute in minecraft:overworld run fill 299 66 -2 299 67 -2 dirt
execute in minecraft:overworld run setblock 299 68 -2 grass_block
execute in minecraft:overworld run fill 299 69 -2 299 144 -2 air
execute in minecraft:overworld run fill 299 58 -1 299 65 -1 stone
execute in minecraft:overworld run fill 299 66 -1 299 67 -1 dirt
execute in minecraft:overworld run setblock 299 68 -1 coarse_dirt
execute in minecraft:overworld run fill 299 69 -1 299 144 -1 air
execute in minecraft:overworld run fill 299 58 0 299 65 0 stone
execute in minecraft:overworld run fill 299 66 0 299 67 0 dirt
execute in minecraft:overworld run setblock 299 68 0 grass_block
execute in minecraft:overworld run fill 299 69 0 299 144 0 air
execute in minecraft:overworld run fill 299 58 1 299 65 1 stone
execute in minecraft:overworld run fill 299 66 1 299 67 1 dirt
execute in minecraft:overworld run setblock 299 68 1 coarse_dirt
execute in minecraft:overworld run fill 299 69 1 299 144 1 air
execute in minecraft:overworld run fill 299 58 2 299 65 2 stone
execute in minecraft:overworld run fill 299 66 2 299 67 2 dirt
execute in minecraft:overworld run setblock 299 68 2 grass_block
execute in minecraft:overworld run fill 299 69 2 299 144 2 air
execute in minecraft:overworld run fill 299 58 3 299 65 3 stone
execute in minecraft:overworld run fill 299 66 3 299 67 3 dirt
execute in minecraft:overworld run setblock 299 68 3 coarse_dirt
execute in minecraft:overworld run fill 299 69 3 299 144 3 air
execute in minecraft:overworld run fill 299 58 4 299 65 4 stone
execute in minecraft:overworld run fill 299 66 4 299 67 4 dirt
execute in minecraft:overworld run setblock 299 68 4 grass_block
execute in minecraft:overworld run fill 299 69 4 299 144 4 air
execute in minecraft:overworld run fill 299 58 5 299 65 5 stone
execute in minecraft:overworld run fill 299 66 5 299 67 5 dirt
execute in minecraft:overworld run setblock 299 68 5 coarse_dirt
execute in minecraft:overworld run fill 299 69 5 299 144 5 air
execute in minecraft:overworld run fill 299 58 6 299 64 6 stone
execute in minecraft:overworld run fill 299 65 6 299 66 6 dirt
execute in minecraft:overworld run setblock 299 67 6 coarse_dirt
execute in minecraft:overworld run fill 299 68 6 299 144 6 air
execute in minecraft:overworld run fill 299 58 7 299 64 7 stone
execute in minecraft:overworld run fill 299 65 7 299 66 7 dirt
execute in minecraft:overworld run setblock 299 67 7 coarse_dirt
execute in minecraft:overworld run fill 299 68 7 299 144 7 air
execute in minecraft:overworld run fill 299 58 8 299 64 8 stone
execute in minecraft:overworld run fill 299 65 8 299 66 8 dirt
execute in minecraft:overworld run setblock 299 67 8 grass_block
execute in minecraft:overworld run fill 299 68 8 299 144 8 air
execute in minecraft:overworld run fill 299 58 9 299 64 9 stone
execute in minecraft:overworld run fill 299 65 9 299 66 9 dirt
execute in minecraft:overworld run setblock 299 67 9 coarse_dirt
execute in minecraft:overworld run fill 299 68 9 299 144 9 air
execute in minecraft:overworld run fill 299 58 10 299 64 10 stone
execute in minecraft:overworld run fill 299 65 10 299 66 10 dirt
execute in minecraft:overworld run setblock 299 67 10 coarse_dirt
execute in minecraft:overworld run fill 299 68 10 299 144 10 air
execute in minecraft:overworld run fill 299 58 11 299 64 11 stone
execute in minecraft:overworld run fill 299 65 11 299 66 11 dirt
execute in minecraft:overworld run setblock 299 67 11 grass_block
execute in minecraft:overworld run fill 299 68 11 299 144 11 air
execute in minecraft:overworld run fill 299 58 12 299 64 12 stone
execute in minecraft:overworld run fill 299 65 12 299 66 12 dirt
execute in minecraft:overworld run setblock 299 67 12 grass_block
execute in minecraft:overworld run fill 299 68 12 299 144 12 air
execute in minecraft:overworld run fill 299 58 13 299 64 13 stone
execute in minecraft:overworld run fill 299 65 13 299 66 13 dirt
execute in minecraft:overworld run setblock 299 67 13 grass_block
execute in minecraft:overworld run fill 299 68 13 299 144 13 air
execute in minecraft:overworld run fill 299 58 14 299 64 14 stone
execute in minecraft:overworld run fill 299 65 14 299 66 14 dirt
execute in minecraft:overworld run setblock 299 67 14 coarse_dirt
execute in minecraft:overworld run fill 299 68 14 299 144 14 air
execute in minecraft:overworld run fill 299 58 15 299 64 15 stone
execute in minecraft:overworld run fill 299 65 15 299 66 15 dirt
execute in minecraft:overworld run setblock 299 67 15 coarse_dirt
execute in minecraft:overworld run fill 299 68 15 299 144 15 air
execute in minecraft:overworld run fill 299 58 16 299 64 16 stone
execute in minecraft:overworld run fill 299 65 16 299 66 16 dirt
execute in minecraft:overworld run setblock 299 67 16 grass_block
execute in minecraft:overworld run fill 299 68 16 299 144 16 air
execute in minecraft:overworld run fill 299 58 17 299 63 17 stone
execute in minecraft:overworld run fill 299 64 17 299 65 17 dirt
execute in minecraft:overworld run setblock 299 66 17 coarse_dirt
execute in minecraft:overworld run fill 299 67 17 299 144 17 air
execute in minecraft:overworld run fill 299 58 18 299 63 18 stone
execute in minecraft:overworld run fill 299 64 18 299 65 18 dirt
execute in minecraft:overworld run setblock 299 66 18 grass_block
execute in minecraft:overworld run fill 299 67 18 299 144 18 air
execute in minecraft:overworld run fill 299 58 19 299 63 19 stone
execute in minecraft:overworld run fill 299 64 19 299 65 19 dirt
execute in minecraft:overworld run setblock 299 66 19 grass_block
execute in minecraft:overworld run fill 299 67 19 299 144 19 air
execute in minecraft:overworld run fill 299 58 20 299 63 20 stone
execute in minecraft:overworld run fill 299 64 20 299 65 20 dirt
execute in minecraft:overworld run setblock 299 66 20 coarse_dirt
execute in minecraft:overworld run fill 299 67 20 299 144 20 air
execute in minecraft:overworld run fill 299 58 21 299 63 21 stone
execute in minecraft:overworld run fill 299 64 21 299 65 21 dirt
execute in minecraft:overworld run setblock 299 66 21 grass_block
execute in minecraft:overworld run fill 299 67 21 299 144 21 air
execute in minecraft:overworld run fill 299 58 22 299 63 22 stone
execute in minecraft:overworld run fill 299 64 22 299 65 22 dirt
execute in minecraft:overworld run setblock 299 66 22 coarse_dirt
execute in minecraft:overworld run fill 299 67 22 299 144 22 air
execute in minecraft:overworld run fill 299 58 23 299 64 23 stone
execute in minecraft:overworld run fill 299 65 23 299 66 23 dirt
execute in minecraft:overworld run setblock 299 67 23 coarse_dirt
execute in minecraft:overworld run fill 299 68 23 299 144 23 air
execute in minecraft:overworld run fill 299 58 24 299 64 24 stone
execute in minecraft:overworld run fill 299 65 24 299 66 24 dirt
execute in minecraft:overworld run setblock 299 67 24 coarse_dirt
execute in minecraft:overworld run fill 299 68 24 299 144 24 air
execute in minecraft:overworld run fill 299 58 25 299 64 25 stone
execute in minecraft:overworld run fill 299 65 25 299 66 25 dirt
execute in minecraft:overworld run setblock 299 67 25 coarse_dirt
execute in minecraft:overworld run fill 299 68 25 299 144 25 air
execute in minecraft:overworld run fill 299 58 26 299 64 26 stone
execute in minecraft:overworld run fill 299 65 26 299 66 26 dirt
execute in minecraft:overworld run setblock 299 67 26 grass_block
execute in minecraft:overworld run fill 299 68 26 299 144 26 air
execute in minecraft:overworld run fill 299 58 27 299 64 27 stone
execute in minecraft:overworld run fill 299 65 27 299 66 27 dirt
execute in minecraft:overworld run setblock 299 67 27 coarse_dirt
execute in minecraft:overworld run fill 299 68 27 299 144 27 air
execute in minecraft:overworld run fill 299 58 28 299 64 28 stone
execute in minecraft:overworld run fill 299 65 28 299 66 28 dirt
execute in minecraft:overworld run setblock 299 67 28 grass_block
execute in minecraft:overworld run fill 299 68 28 299 144 28 air
execute in minecraft:overworld run fill 299 58 29 299 64 29 stone
execute in minecraft:overworld run fill 299 65 29 299 66 29 dirt
execute in minecraft:overworld run setblock 299 67 29 coarse_dirt
execute in minecraft:overworld run fill 299 68 29 299 144 29 air
execute in minecraft:overworld run fill 299 58 30 299 64 30 stone
execute in minecraft:overworld run fill 299 65 30 299 66 30 dirt
execute in minecraft:overworld run setblock 299 67 30 coarse_dirt
execute in minecraft:overworld run fill 299 68 30 299 144 30 air
execute in minecraft:overworld run fill 299 58 31 299 64 31 stone
execute in minecraft:overworld run fill 299 65 31 299 66 31 dirt
execute in minecraft:overworld run setblock 299 67 31 coarse_dirt
execute in minecraft:overworld run fill 299 68 31 299 144 31 air
execute in minecraft:overworld run fill 299 58 32 299 63 32 stone
execute in minecraft:overworld run fill 299 64 32 299 65 32 dirt
execute in minecraft:overworld run setblock 299 66 32 coarse_dirt
execute in minecraft:overworld run fill 299 67 32 299 144 32 air
execute in minecraft:overworld run fill 299 58 33 299 63 33 stone
execute in minecraft:overworld run fill 299 64 33 299 65 33 dirt
execute in minecraft:overworld run setblock 299 66 33 grass_block
execute in minecraft:overworld run fill 299 67 33 299 144 33 air
execute in minecraft:overworld run fill 299 58 34 299 63 34 stone
execute in minecraft:overworld run fill 299 64 34 299 65 34 dirt
execute in minecraft:overworld run setblock 299 66 34 grass_block
execute in minecraft:overworld run fill 299 67 34 299 144 34 air
execute in minecraft:overworld run fill 299 58 35 299 63 35 stone
execute in minecraft:overworld run fill 299 64 35 299 65 35 dirt
execute in minecraft:overworld run setblock 299 66 35 grass_block
execute in minecraft:overworld run fill 299 67 35 299 144 35 air
execute in minecraft:overworld run fill 299 58 36 299 63 36 stone
execute in minecraft:overworld run fill 299 64 36 299 65 36 dirt
execute in minecraft:overworld run setblock 299 66 36 grass_block
execute in minecraft:overworld run fill 299 67 36 299 144 36 air
execute in minecraft:overworld run fill 299 58 37 299 63 37 stone
execute in minecraft:overworld run fill 299 64 37 299 65 37 dirt
execute in minecraft:overworld run setblock 299 66 37 coarse_dirt
execute in minecraft:overworld run fill 299 67 37 299 144 37 air
execute in minecraft:overworld run fill 299 58 38 299 63 38 stone
execute in minecraft:overworld run fill 299 64 38 299 65 38 dirt
execute in minecraft:overworld run setblock 299 66 38 coarse_dirt
execute in minecraft:overworld run fill 299 67 38 299 144 38 air
execute in minecraft:overworld run fill 299 58 39 299 63 39 stone
execute in minecraft:overworld run fill 299 64 39 299 65 39 dirt
execute in minecraft:overworld run setblock 299 66 39 grass_block
execute in minecraft:overworld run fill 299 67 39 299 144 39 air
execute in minecraft:overworld run fill 299 58 40 299 63 40 stone
execute in minecraft:overworld run fill 299 64 40 299 65 40 dirt
execute in minecraft:overworld run setblock 299 66 40 grass_block
execute in minecraft:overworld run fill 299 67 40 299 144 40 air
execute in minecraft:overworld run fill 299 58 41 299 63 41 stone
execute in minecraft:overworld run fill 299 64 41 299 65 41 dirt
execute in minecraft:overworld run setblock 299 66 41 grass_block
execute in minecraft:overworld run fill 299 67 41 299 144 41 air
execute in minecraft:overworld run fill 299 58 42 299 63 42 stone
execute in minecraft:overworld run fill 299 64 42 299 65 42 dirt
execute in minecraft:overworld run setblock 299 66 42 coarse_dirt
execute in minecraft:overworld run fill 299 67 42 299 144 42 air
execute in minecraft:overworld run fill 299 58 43 299 63 43 stone
execute in minecraft:overworld run fill 299 64 43 299 65 43 dirt
execute in minecraft:overworld run setblock 299 66 43 coarse_dirt
execute in minecraft:overworld run fill 299 67 43 299 144 43 air
execute in minecraft:overworld run fill 299 58 44 299 62 44 stone
execute in minecraft:overworld run fill 299 63 44 299 64 44 dirt
execute in minecraft:overworld run setblock 299 65 44 grass_block
execute in minecraft:overworld run fill 299 66 44 299 144 44 air
execute in minecraft:overworld run fill 299 58 45 299 62 45 stone
execute in minecraft:overworld run fill 299 63 45 299 64 45 dirt
execute in minecraft:overworld run setblock 299 65 45 coarse_dirt
execute in minecraft:overworld run fill 299 66 45 299 144 45 air
execute in minecraft:overworld run fill 299 58 46 299 62 46 stone
execute in minecraft:overworld run fill 299 63 46 299 64 46 dirt
execute in minecraft:overworld run setblock 299 65 46 coarse_dirt
execute in minecraft:overworld run fill 299 66 46 299 144 46 air
execute in minecraft:overworld run fill 299 58 47 299 61 47 stone
execute in minecraft:overworld run fill 299 62 47 299 63 47 dirt
execute in minecraft:overworld run setblock 299 64 47 coarse_dirt
execute in minecraft:overworld run fill 299 65 47 299 144 47 air
execute in minecraft:overworld run fill 300 58 -48 300 61 -48 stone
execute in minecraft:overworld run fill 300 62 -48 300 63 -48 dirt
execute in minecraft:overworld run setblock 300 64 -48 coarse_dirt
execute in minecraft:overworld run fill 300 65 -48 300 144 -48 air
execute in minecraft:overworld run fill 300 58 -47 300 63 -47 stone
execute in minecraft:overworld run fill 300 64 -47 300 65 -47 dirt
execute in minecraft:overworld run setblock 300 66 -47 coarse_dirt
execute in minecraft:overworld run fill 300 67 -47 300 144 -47 air
execute in minecraft:overworld run fill 300 58 -46 300 65 -46 stone
execute in minecraft:overworld run fill 300 66 -46 300 67 -46 dirt
execute in minecraft:overworld run setblock 300 68 -46 coarse_dirt
execute in minecraft:overworld run fill 300 69 -46 300 144 -46 air
execute in minecraft:overworld run fill 300 58 -45 300 67 -45 stone
execute in minecraft:overworld run fill 300 68 -45 300 69 -45 dirt
execute in minecraft:overworld run setblock 300 70 -45 coarse_dirt
execute in minecraft:overworld run fill 300 71 -45 300 144 -45 air
execute in minecraft:overworld run fill 300 58 -44 300 69 -44 stone
execute in minecraft:overworld run fill 300 70 -44 300 71 -44 dirt
execute in minecraft:overworld run setblock 300 72 -44 grass_block
execute in minecraft:overworld run fill 300 73 -44 300 144 -44 air
execute in minecraft:overworld run fill 300 58 -43 300 68 -43 stone
execute in minecraft:overworld run fill 300 69 -43 300 70 -43 dirt
execute in minecraft:overworld run setblock 300 71 -43 coarse_dirt
execute in minecraft:overworld run fill 300 72 -43 300 144 -43 air
execute in minecraft:overworld run fill 300 58 -42 300 68 -42 stone
execute in minecraft:overworld run fill 300 69 -42 300 70 -42 dirt
execute in minecraft:overworld run setblock 300 71 -42 coarse_dirt
execute in minecraft:overworld run fill 300 72 -42 300 144 -42 air
execute in minecraft:overworld run fill 300 58 -41 300 68 -41 stone
execute in minecraft:overworld run fill 300 69 -41 300 70 -41 dirt
execute in minecraft:overworld run setblock 300 71 -41 coarse_dirt
execute in minecraft:overworld run fill 300 72 -41 300 144 -41 air
execute in minecraft:overworld run fill 300 58 -40 300 68 -40 stone
execute in minecraft:overworld run fill 300 69 -40 300 70 -40 dirt
execute in minecraft:overworld run setblock 300 71 -40 grass_block
execute in minecraft:overworld run fill 300 72 -40 300 144 -40 air
execute in minecraft:overworld run fill 300 58 -39 300 68 -39 stone
schedule function blade_gallery:random/burned/part_145 1t replace
