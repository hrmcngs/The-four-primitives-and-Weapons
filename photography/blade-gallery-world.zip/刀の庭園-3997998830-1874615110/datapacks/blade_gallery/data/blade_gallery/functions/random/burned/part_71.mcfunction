execute in minecraft:overworld run fill 254 58 -38 254 72 -38 stone
execute in minecraft:overworld run fill 254 73 -38 254 74 -38 dirt
execute in minecraft:overworld run setblock 254 75 -38 grass_block
execute in minecraft:overworld run fill 254 76 -38 254 144 -38 air
execute in minecraft:overworld run fill 254 58 -37 254 72 -37 stone
execute in minecraft:overworld run fill 254 73 -37 254 74 -37 dirt
execute in minecraft:overworld run setblock 254 75 -37 grass_block
execute in minecraft:overworld run fill 254 76 -37 254 144 -37 air
execute in minecraft:overworld run fill 254 58 -36 254 71 -36 stone
execute in minecraft:overworld run fill 254 72 -36 254 73 -36 dirt
execute in minecraft:overworld run setblock 254 74 -36 coarse_dirt
execute in minecraft:overworld run fill 254 75 -36 254 144 -36 air
execute in minecraft:overworld run fill 254 58 -35 254 71 -35 stone
execute in minecraft:overworld run fill 254 72 -35 254 73 -35 dirt
execute in minecraft:overworld run setblock 254 74 -35 coarse_dirt
execute in minecraft:overworld run fill 254 75 -35 254 144 -35 air
execute in minecraft:overworld run setblock 254 75 -35 mossy_cobblestone
execute in minecraft:overworld run fill 254 58 -34 254 70 -34 stone
execute in minecraft:overworld run fill 254 71 -34 254 72 -34 dirt
execute in minecraft:overworld run setblock 254 73 -34 grass_block
execute in minecraft:overworld run fill 254 74 -34 254 144 -34 air
execute in minecraft:overworld run fill 254 58 -33 254 70 -33 stone
execute in minecraft:overworld run fill 254 71 -33 254 72 -33 dirt
execute in minecraft:overworld run setblock 254 73 -33 grass_block
execute in minecraft:overworld run fill 254 74 -33 254 144 -33 air
execute in minecraft:overworld run fill 254 58 -32 254 70 -32 stone
execute in minecraft:overworld run fill 254 71 -32 254 72 -32 dirt
execute in minecraft:overworld run setblock 254 73 -32 grass_block
execute in minecraft:overworld run fill 254 74 -32 254 144 -32 air
execute in minecraft:overworld run fill 254 58 -31 254 69 -31 stone
execute in minecraft:overworld run fill 254 70 -31 254 71 -31 dirt
execute in minecraft:overworld run setblock 254 72 -31 grass_block
execute in minecraft:overworld run fill 254 73 -31 254 144 -31 air
execute in minecraft:overworld run fill 254 58 -30 254 69 -30 stone
execute in minecraft:overworld run fill 254 70 -30 254 71 -30 dirt
execute in minecraft:overworld run setblock 254 72 -30 grass_block
execute in minecraft:overworld run fill 254 73 -30 254 144 -30 air
execute in minecraft:overworld run fill 254 58 -29 254 68 -29 stone
execute in minecraft:overworld run fill 254 69 -29 254 70 -29 dirt
execute in minecraft:overworld run setblock 254 71 -29 coarse_dirt
execute in minecraft:overworld run fill 254 72 -29 254 144 -29 air
execute in minecraft:overworld run fill 254 58 -28 254 68 -28 stone
execute in minecraft:overworld run fill 254 69 -28 254 70 -28 dirt
execute in minecraft:overworld run setblock 254 71 -28 coarse_dirt
execute in minecraft:overworld run fill 254 72 -28 254 144 -28 air
execute in minecraft:overworld run fill 254 58 -27 254 67 -27 stone
execute in minecraft:overworld run fill 254 68 -27 254 69 -27 dirt
execute in minecraft:overworld run setblock 254 70 -27 grass_block
execute in minecraft:overworld run fill 254 71 -27 254 144 -27 air
execute in minecraft:overworld run fill 254 58 -26 254 67 -26 stone
execute in minecraft:overworld run fill 254 68 -26 254 69 -26 dirt
execute in minecraft:overworld run setblock 254 70 -26 grass_block
execute in minecraft:overworld run fill 254 71 -26 254 144 -26 air
execute in minecraft:overworld run fill 254 58 -25 254 66 -25 stone
execute in minecraft:overworld run fill 254 67 -25 254 68 -25 dirt
execute in minecraft:overworld run setblock 254 69 -25 coarse_dirt
execute in minecraft:overworld run fill 254 70 -25 254 144 -25 air
execute in minecraft:overworld run setblock 254 70 -25 grass
execute in minecraft:overworld run fill 254 58 -24 254 66 -24 stone
execute in minecraft:overworld run fill 254 67 -24 254 68 -24 dirt
execute in minecraft:overworld run setblock 254 69 -24 coarse_dirt
execute in minecraft:overworld run fill 254 70 -24 254 144 -24 air
execute in minecraft:overworld run fill 254 58 -23 254 65 -23 stone
execute in minecraft:overworld run fill 254 66 -23 254 67 -23 dirt
execute in minecraft:overworld run setblock 254 68 -23 coarse_dirt
execute in minecraft:overworld run fill 254 69 -23 254 144 -23 air
execute in minecraft:overworld run fill 254 58 -22 254 64 -22 stone
execute in minecraft:overworld run fill 254 65 -22 254 66 -22 dirt
execute in minecraft:overworld run setblock 254 67 -22 coarse_dirt
execute in minecraft:overworld run fill 254 68 -22 254 144 -22 air
execute in minecraft:overworld run fill 254 58 -21 254 64 -21 stone
execute in minecraft:overworld run fill 254 65 -21 254 66 -21 dirt
execute in minecraft:overworld run setblock 254 67 -21 grass_block
execute in minecraft:overworld run fill 254 68 -21 254 144 -21 air
execute in minecraft:overworld run fill 254 58 -20 254 63 -20 stone
execute in minecraft:overworld run fill 254 64 -20 254 65 -20 dirt
execute in minecraft:overworld run setblock 254 66 -20 coarse_dirt
execute in minecraft:overworld run fill 254 67 -20 254 144 -20 air
execute in minecraft:overworld run fill 254 58 -19 254 63 -19 stone
execute in minecraft:overworld run fill 254 64 -19 254 65 -19 dirt
execute in minecraft:overworld run setblock 254 66 -19 coarse_dirt
execute in minecraft:overworld run fill 254 67 -19 254 144 -19 air
execute in minecraft:overworld run fill 254 58 -18 254 62 -18 stone
execute in minecraft:overworld run fill 254 63 -18 254 64 -18 dirt
execute in minecraft:overworld run setblock 254 65 -18 grass_block
execute in minecraft:overworld run fill 254 66 -18 254 144 -18 air
execute in minecraft:overworld run fill 254 58 -17 254 62 -17 stone
execute in minecraft:overworld run fill 254 63 -17 254 64 -17 dirt
execute in minecraft:overworld run setblock 254 65 -17 grass_block
execute in minecraft:overworld run fill 254 66 -17 254 144 -17 air
execute in minecraft:overworld run fill 254 58 -16 254 62 -16 stone
execute in minecraft:overworld run fill 254 63 -16 254 64 -16 dirt
execute in minecraft:overworld run setblock 254 65 -16 coarse_dirt
execute in minecraft:overworld run fill 254 66 -16 254 144 -16 air
execute in minecraft:overworld run setblock 254 66 -16 grass
execute in minecraft:overworld run fill 254 58 -15 254 61 -15 stone
execute in minecraft:overworld run fill 254 62 -15 254 63 -15 dirt
execute in minecraft:overworld run setblock 254 64 -15 grass_block
execute in minecraft:overworld run fill 254 65 -15 254 144 -15 air
execute in minecraft:overworld run fill 254 58 -14 254 61 -14 stone
execute in minecraft:overworld run fill 254 62 -14 254 63 -14 dirt
execute in minecraft:overworld run setblock 254 64 -14 grass_block
execute in minecraft:overworld run fill 254 65 -14 254 144 -14 air
execute in minecraft:overworld run fill 254 58 -13 254 61 -13 stone
execute in minecraft:overworld run fill 254 62 -13 254 63 -13 dirt
execute in minecraft:overworld run setblock 254 64 -13 coarse_dirt
execute in minecraft:overworld run fill 254 65 -13 254 144 -13 air
execute in minecraft:overworld run fill 254 58 -12 254 60 -12 stone
execute in minecraft:overworld run fill 254 61 -12 254 62 -12 dirt
execute in minecraft:overworld run setblock 254 63 -12 gravel
execute in minecraft:overworld run fill 254 64 -12 254 144 -12 air
execute in minecraft:overworld run fill 254 64 -12 254 64 -12 water
execute in minecraft:overworld run fill 254 58 -11 254 60 -11 stone
execute in minecraft:overworld run fill 254 61 -11 254 62 -11 dirt
execute in minecraft:overworld run setblock 254 63 -11 gravel
execute in minecraft:overworld run fill 254 64 -11 254 144 -11 air
execute in minecraft:overworld run fill 254 64 -11 254 64 -11 water
execute in minecraft:overworld run fill 254 58 -10 254 60 -10 stone
execute in minecraft:overworld run fill 254 61 -10 254 62 -10 dirt
execute in minecraft:overworld run setblock 254 63 -10 gravel
execute in minecraft:overworld run fill 254 64 -10 254 144 -10 air
execute in minecraft:overworld run fill 254 64 -10 254 64 -10 water
execute in minecraft:overworld run fill 254 58 -9 254 60 -9 stone
execute in minecraft:overworld run fill 254 61 -9 254 62 -9 dirt
execute in minecraft:overworld run setblock 254 63 -9 gravel
execute in minecraft:overworld run fill 254 64 -9 254 144 -9 air
execute in minecraft:overworld run fill 254 64 -9 254 64 -9 water
execute in minecraft:overworld run fill 254 58 -8 254 60 -8 stone
execute in minecraft:overworld run fill 254 61 -8 254 62 -8 dirt
execute in minecraft:overworld run setblock 254 63 -8 gravel
execute in minecraft:overworld run fill 254 64 -8 254 144 -8 air
execute in minecraft:overworld run fill 254 64 -8 254 64 -8 water
execute in minecraft:overworld run fill 254 58 -7 254 60 -7 stone
execute in minecraft:overworld run fill 254 61 -7 254 62 -7 dirt
execute in minecraft:overworld run setblock 254 63 -7 gravel
execute in minecraft:overworld run fill 254 64 -7 254 144 -7 air
execute in minecraft:overworld run fill 254 64 -7 254 64 -7 water
execute in minecraft:overworld run fill 254 58 -6 254 60 -6 stone
execute in minecraft:overworld run fill 254 61 -6 254 62 -6 dirt
execute in minecraft:overworld run setblock 254 63 -6 gravel
execute in minecraft:overworld run fill 254 64 -6 254 144 -6 air
execute in minecraft:overworld run fill 254 64 -6 254 64 -6 water
execute in minecraft:overworld run fill 254 58 -5 254 59 -5 stone
execute in minecraft:overworld run fill 254 60 -5 254 61 -5 dirt
execute in minecraft:overworld run setblock 254 62 -5 gravel
execute in minecraft:overworld run fill 254 63 -5 254 144 -5 air
execute in minecraft:overworld run fill 254 63 -5 254 64 -5 water
execute in minecraft:overworld run fill 254 58 -4 254 59 -4 stone
execute in minecraft:overworld run fill 254 60 -4 254 61 -4 dirt
execute in minecraft:overworld run setblock 254 62 -4 gravel
execute in minecraft:overworld run fill 254 63 -4 254 144 -4 air
execute in minecraft:overworld run fill 254 63 -4 254 64 -4 water
execute in minecraft:overworld run fill 254 58 -3 254 59 -3 stone
execute in minecraft:overworld run fill 254 60 -3 254 61 -3 dirt
execute in minecraft:overworld run setblock 254 62 -3 gravel
execute in minecraft:overworld run fill 254 63 -3 254 144 -3 air
execute in minecraft:overworld run fill 254 63 -3 254 64 -3 water
execute in minecraft:overworld run fill 254 58 -2 254 59 -2 stone
execute in minecraft:overworld run fill 254 60 -2 254 61 -2 dirt
execute in minecraft:overworld run setblock 254 62 -2 gravel
execute in minecraft:overworld run fill 254 63 -2 254 144 -2 air
execute in minecraft:overworld run fill 254 63 -2 254 64 -2 water
execute in minecraft:overworld run fill 254 58 -1 254 59 -1 stone
execute in minecraft:overworld run fill 254 60 -1 254 61 -1 dirt
execute in minecraft:overworld run setblock 254 62 -1 gravel
execute in minecraft:overworld run fill 254 63 -1 254 144 -1 air
execute in minecraft:overworld run fill 254 63 -1 254 64 -1 water
execute in minecraft:overworld run fill 254 58 0 254 59 0 stone
execute in minecraft:overworld run fill 254 60 0 254 61 0 dirt
execute in minecraft:overworld run setblock 254 62 0 gravel
execute in minecraft:overworld run fill 254 63 0 254 144 0 air
execute in minecraft:overworld run fill 254 63 0 254 64 0 water
execute in minecraft:overworld run fill 254 58 1 254 59 1 stone
execute in minecraft:overworld run fill 254 60 1 254 61 1 dirt
execute in minecraft:overworld run setblock 254 62 1 gravel
execute in minecraft:overworld run fill 254 63 1 254 144 1 air
execute in minecraft:overworld run fill 254 63 1 254 64 1 water
execute in minecraft:overworld run fill 254 58 2 254 59 2 stone
execute in minecraft:overworld run fill 254 60 2 254 61 2 dirt
execute in minecraft:overworld run setblock 254 62 2 gravel
execute in minecraft:overworld run fill 254 63 2 254 144 2 air
execute in minecraft:overworld run fill 254 63 2 254 64 2 water
execute in minecraft:overworld run fill 254 58 3 254 60 3 stone
execute in minecraft:overworld run fill 254 61 3 254 62 3 dirt
execute in minecraft:overworld run setblock 254 63 3 gravel
execute in minecraft:overworld run fill 254 64 3 254 144 3 air
execute in minecraft:overworld run fill 254 64 3 254 64 3 water
execute in minecraft:overworld run fill 254 58 4 254 60 4 stone
execute in minecraft:overworld run fill 254 61 4 254 62 4 dirt
execute in minecraft:overworld run setblock 254 63 4 gravel
execute in minecraft:overworld run fill 254 64 4 254 144 4 air
execute in minecraft:overworld run fill 254 64 4 254 64 4 water
execute in minecraft:overworld run fill 254 58 5 254 60 5 stone
execute in minecraft:overworld run fill 254 61 5 254 62 5 dirt
execute in minecraft:overworld run setblock 254 63 5 gravel
execute in minecraft:overworld run fill 254 64 5 254 144 5 air
execute in minecraft:overworld run fill 254 64 5 254 64 5 water
execute in minecraft:overworld run fill 254 58 6 254 61 6 stone
execute in minecraft:overworld run fill 254 62 6 254 63 6 dirt
execute in minecraft:overworld run setblock 254 64 6 coarse_dirt
execute in minecraft:overworld run fill 254 65 6 254 144 6 air
execute in minecraft:overworld run fill 254 58 7 254 61 7 stone
execute in minecraft:overworld run fill 254 62 7 254 63 7 dirt
execute in minecraft:overworld run setblock 254 64 7 coarse_dirt
execute in minecraft:overworld run fill 254 65 7 254 144 7 air
execute in minecraft:overworld run fill 254 58 8 254 61 8 stone
execute in minecraft:overworld run fill 254 62 8 254 63 8 dirt
execute in minecraft:overworld run setblock 254 64 8 coarse_dirt
execute in minecraft:overworld run fill 254 65 8 254 144 8 air
execute in minecraft:overworld run fill 254 58 9 254 62 9 stone
execute in minecraft:overworld run fill 254 63 9 254 64 9 dirt
execute in minecraft:overworld run setblock 254 65 9 coarse_dirt
execute in minecraft:overworld run fill 254 66 9 254 144 9 air
execute in minecraft:overworld run setblock 254 66 9 grass
execute in minecraft:overworld run fill 254 58 10 254 62 10 stone
execute in minecraft:overworld run fill 254 63 10 254 64 10 dirt
execute in minecraft:overworld run setblock 254 65 10 grass_block
execute in minecraft:overworld run fill 254 66 10 254 144 10 air
execute in minecraft:overworld run setblock 254 66 10 grass
execute in minecraft:overworld run fill 254 58 11 254 62 11 stone
execute in minecraft:overworld run fill 254 63 11 254 64 11 dirt
execute in minecraft:overworld run setblock 254 65 11 grass_block
execute in minecraft:overworld run fill 254 66 11 254 144 11 air
execute in minecraft:overworld run fill 254 58 12 254 62 12 stone
execute in minecraft:overworld run fill 254 63 12 254 64 12 dirt
execute in minecraft:overworld run setblock 254 65 12 coarse_dirt
execute in minecraft:overworld run fill 254 66 12 254 144 12 air
execute in minecraft:overworld run setblock 254 66 12 grass
execute in minecraft:overworld run fill 254 58 13 254 63 13 stone
execute in minecraft:overworld run fill 254 64 13 254 65 13 dirt
execute in minecraft:overworld run setblock 254 66 13 coarse_dirt
execute in minecraft:overworld run fill 254 67 13 254 144 13 air
execute in minecraft:overworld run fill 254 58 14 254 63 14 stone
execute in minecraft:overworld run fill 254 64 14 254 65 14 dirt
execute in minecraft:overworld run setblock 254 66 14 grass_block
execute in minecraft:overworld run fill 254 67 14 254 144 14 air
execute in minecraft:overworld run fill 254 58 15 254 63 15 stone
execute in minecraft:overworld run fill 254 64 15 254 65 15 dirt
execute in minecraft:overworld run setblock 254 66 15 grass_block
execute in minecraft:overworld run fill 254 67 15 254 144 15 air
execute in minecraft:overworld run fill 254 58 16 254 64 16 stone
execute in minecraft:overworld run fill 254 65 16 254 66 16 dirt
execute in minecraft:overworld run setblock 254 67 16 coarse_dirt
execute in minecraft:overworld run fill 254 68 16 254 144 16 air
execute in minecraft:overworld run fill 254 58 17 254 64 17 stone
execute in minecraft:overworld run fill 254 65 17 254 66 17 dirt
execute in minecraft:overworld run setblock 254 67 17 grass_block
execute in minecraft:overworld run fill 254 68 17 254 144 17 air
execute in minecraft:overworld run fill 254 58 18 254 64 18 stone
execute in minecraft:overworld run fill 254 65 18 254 66 18 dirt
execute in minecraft:overworld run setblock 254 67 18 grass_block
execute in minecraft:overworld run fill 254 68 18 254 144 18 air
execute in minecraft:overworld run fill 254 58 19 254 64 19 stone
execute in minecraft:overworld run fill 254 65 19 254 66 19 dirt
execute in minecraft:overworld run setblock 254 67 19 coarse_dirt
execute in minecraft:overworld run fill 254 68 19 254 144 19 air
schedule function blade_gallery:random/burned/part_72 1t replace
