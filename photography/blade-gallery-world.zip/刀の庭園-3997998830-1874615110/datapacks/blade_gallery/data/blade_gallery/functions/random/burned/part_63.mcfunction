execute in minecraft:overworld run fill 249 65 -44 249 66 -44 dirt
execute in minecraft:overworld run setblock 249 67 -44 grass_block
execute in minecraft:overworld run fill 249 68 -44 249 144 -44 air
execute in minecraft:overworld run fill 249 58 -43 249 65 -43 stone
execute in minecraft:overworld run fill 249 66 -43 249 67 -43 dirt
execute in minecraft:overworld run setblock 249 68 -43 coarse_dirt
execute in minecraft:overworld run fill 249 69 -43 249 144 -43 air
execute in minecraft:overworld run fill 249 58 -42 249 66 -42 stone
execute in minecraft:overworld run fill 249 67 -42 249 68 -42 dirt
execute in minecraft:overworld run setblock 249 69 -42 coarse_dirt
execute in minecraft:overworld run fill 249 70 -42 249 144 -42 air
execute in minecraft:overworld run fill 249 58 -41 249 66 -41 stone
execute in minecraft:overworld run fill 249 67 -41 249 68 -41 dirt
execute in minecraft:overworld run setblock 249 69 -41 grass_block
execute in minecraft:overworld run fill 249 70 -41 249 144 -41 air
execute in minecraft:overworld run fill 249 58 -40 249 67 -40 stone
execute in minecraft:overworld run fill 249 68 -40 249 69 -40 dirt
execute in minecraft:overworld run setblock 249 70 -40 coarse_dirt
execute in minecraft:overworld run fill 249 71 -40 249 144 -40 air
execute in minecraft:overworld run fill 249 58 -39 249 68 -39 stone
execute in minecraft:overworld run fill 249 69 -39 249 70 -39 dirt
execute in minecraft:overworld run setblock 249 71 -39 coarse_dirt
execute in minecraft:overworld run fill 249 72 -39 249 144 -39 air
execute in minecraft:overworld run fill 249 58 -38 249 68 -38 stone
execute in minecraft:overworld run fill 249 69 -38 249 70 -38 dirt
execute in minecraft:overworld run setblock 249 71 -38 coarse_dirt
execute in minecraft:overworld run fill 249 72 -38 249 144 -38 air
execute in minecraft:overworld run setblock 249 72 -38 grass
execute in minecraft:overworld run fill 249 58 -37 249 68 -37 stone
execute in minecraft:overworld run fill 249 69 -37 249 70 -37 dirt
execute in minecraft:overworld run setblock 249 71 -37 coarse_dirt
execute in minecraft:overworld run fill 249 72 -37 249 144 -37 air
execute in minecraft:overworld run fill 249 58 -36 249 68 -36 stone
execute in minecraft:overworld run fill 249 69 -36 249 70 -36 dirt
execute in minecraft:overworld run setblock 249 71 -36 coarse_dirt
execute in minecraft:overworld run fill 249 72 -36 249 144 -36 air
execute in minecraft:overworld run fill 249 58 -35 249 68 -35 stone
execute in minecraft:overworld run fill 249 69 -35 249 70 -35 dirt
execute in minecraft:overworld run setblock 249 71 -35 coarse_dirt
execute in minecraft:overworld run fill 249 72 -35 249 144 -35 air
execute in minecraft:overworld run fill 249 58 -34 249 68 -34 stone
execute in minecraft:overworld run fill 249 69 -34 249 70 -34 dirt
execute in minecraft:overworld run setblock 249 71 -34 coarse_dirt
execute in minecraft:overworld run fill 249 72 -34 249 144 -34 air
execute in minecraft:overworld run fill 249 58 -33 249 68 -33 stone
execute in minecraft:overworld run fill 249 69 -33 249 70 -33 dirt
execute in minecraft:overworld run setblock 249 71 -33 coarse_dirt
execute in minecraft:overworld run fill 249 72 -33 249 144 -33 air
execute in minecraft:overworld run setblock 249 72 -33 grass
execute in minecraft:overworld run fill 249 58 -32 249 68 -32 stone
execute in minecraft:overworld run fill 249 69 -32 249 70 -32 dirt
execute in minecraft:overworld run setblock 249 71 -32 grass_block
execute in minecraft:overworld run fill 249 72 -32 249 144 -32 air
execute in minecraft:overworld run setblock 249 72 -32 grass
execute in minecraft:overworld run fill 249 58 -31 249 68 -31 stone
execute in minecraft:overworld run fill 249 69 -31 249 70 -31 dirt
execute in minecraft:overworld run setblock 249 71 -31 coarse_dirt
execute in minecraft:overworld run fill 249 72 -31 249 144 -31 air
execute in minecraft:overworld run fill 249 58 -30 249 68 -30 stone
execute in minecraft:overworld run fill 249 69 -30 249 70 -30 dirt
execute in minecraft:overworld run setblock 249 71 -30 coarse_dirt
execute in minecraft:overworld run fill 249 72 -30 249 144 -30 air
execute in minecraft:overworld run fill 249 58 -29 249 68 -29 stone
execute in minecraft:overworld run fill 249 69 -29 249 70 -29 dirt
execute in minecraft:overworld run setblock 249 71 -29 grass_block
execute in minecraft:overworld run fill 249 72 -29 249 144 -29 air
execute in minecraft:overworld run fill 249 58 -28 249 69 -28 stone
execute in minecraft:overworld run fill 249 70 -28 249 71 -28 dirt
execute in minecraft:overworld run setblock 249 72 -28 coarse_dirt
execute in minecraft:overworld run fill 249 73 -28 249 144 -28 air
execute in minecraft:overworld run fill 249 58 -27 249 69 -27 stone
execute in minecraft:overworld run fill 249 70 -27 249 71 -27 dirt
execute in minecraft:overworld run setblock 249 72 -27 grass_block
execute in minecraft:overworld run fill 249 73 -27 249 144 -27 air
execute in minecraft:overworld run fill 249 58 -26 249 69 -26 stone
execute in minecraft:overworld run fill 249 70 -26 249 71 -26 dirt
execute in minecraft:overworld run setblock 249 72 -26 coarse_dirt
execute in minecraft:overworld run fill 249 73 -26 249 144 -26 air
execute in minecraft:overworld run fill 249 58 -25 249 68 -25 stone
execute in minecraft:overworld run fill 249 69 -25 249 70 -25 dirt
execute in minecraft:overworld run setblock 249 71 -25 coarse_dirt
execute in minecraft:overworld run fill 249 72 -25 249 144 -25 air
execute in minecraft:overworld run fill 249 58 -24 249 68 -24 stone
execute in minecraft:overworld run fill 249 69 -24 249 70 -24 dirt
execute in minecraft:overworld run setblock 249 71 -24 grass_block
execute in minecraft:overworld run fill 249 72 -24 249 144 -24 air
execute in minecraft:overworld run fill 249 58 -23 249 68 -23 stone
execute in minecraft:overworld run fill 249 69 -23 249 70 -23 dirt
execute in minecraft:overworld run setblock 249 71 -23 coarse_dirt
execute in minecraft:overworld run fill 249 72 -23 249 144 -23 air
execute in minecraft:overworld run fill 249 58 -22 249 68 -22 stone
execute in minecraft:overworld run fill 249 69 -22 249 70 -22 dirt
execute in minecraft:overworld run setblock 249 71 -22 coarse_dirt
execute in minecraft:overworld run fill 249 72 -22 249 144 -22 air
execute in minecraft:overworld run fill 249 58 -21 249 67 -21 stone
execute in minecraft:overworld run fill 249 68 -21 249 69 -21 dirt
execute in minecraft:overworld run setblock 249 70 -21 grass_block
execute in minecraft:overworld run fill 249 71 -21 249 144 -21 air
execute in minecraft:overworld run setblock 249 71 -21 grass
execute in minecraft:overworld run fill 249 58 -20 249 67 -20 stone
execute in minecraft:overworld run fill 249 68 -20 249 69 -20 dirt
execute in minecraft:overworld run setblock 249 70 -20 coarse_dirt
execute in minecraft:overworld run fill 249 71 -20 249 144 -20 air
execute in minecraft:overworld run fill 249 58 -19 249 67 -19 stone
execute in minecraft:overworld run fill 249 68 -19 249 69 -19 dirt
execute in minecraft:overworld run setblock 249 70 -19 grass_block
execute in minecraft:overworld run fill 249 71 -19 249 144 -19 air
execute in minecraft:overworld run setblock 249 71 -19 grass
execute in minecraft:overworld run fill 249 58 -18 249 66 -18 stone
execute in minecraft:overworld run fill 249 67 -18 249 68 -18 dirt
execute in minecraft:overworld run setblock 249 69 -18 grass_block
execute in minecraft:overworld run fill 249 70 -18 249 144 -18 air
execute in minecraft:overworld run fill 249 58 -17 249 66 -17 stone
execute in minecraft:overworld run fill 249 67 -17 249 68 -17 dirt
execute in minecraft:overworld run setblock 249 69 -17 grass_block
execute in minecraft:overworld run fill 249 70 -17 249 144 -17 air
execute in minecraft:overworld run fill 249 58 -16 249 65 -16 stone
execute in minecraft:overworld run fill 249 66 -16 249 67 -16 dirt
execute in minecraft:overworld run setblock 249 68 -16 coarse_dirt
execute in minecraft:overworld run fill 249 69 -16 249 144 -16 air
execute in minecraft:overworld run setblock 249 69 -16 grass
execute in minecraft:overworld run fill 249 58 -15 249 65 -15 stone
execute in minecraft:overworld run fill 249 66 -15 249 67 -15 dirt
execute in minecraft:overworld run setblock 249 68 -15 grass_block
execute in minecraft:overworld run fill 249 69 -15 249 144 -15 air
execute in minecraft:overworld run fill 249 58 -14 249 64 -14 stone
execute in minecraft:overworld run fill 249 65 -14 249 66 -14 dirt
execute in minecraft:overworld run setblock 249 67 -14 coarse_dirt
execute in minecraft:overworld run fill 249 68 -14 249 144 -14 air
execute in minecraft:overworld run fill 249 58 -13 249 64 -13 stone
execute in minecraft:overworld run fill 249 65 -13 249 66 -13 dirt
execute in minecraft:overworld run setblock 249 67 -13 coarse_dirt
execute in minecraft:overworld run fill 249 68 -13 249 144 -13 air
execute in minecraft:overworld run fill 249 58 -12 249 63 -12 stone
execute in minecraft:overworld run fill 249 64 -12 249 65 -12 dirt
execute in minecraft:overworld run setblock 249 66 -12 coarse_dirt
execute in minecraft:overworld run fill 249 67 -12 249 144 -12 air
execute in minecraft:overworld run fill 249 58 -11 249 63 -11 stone
execute in minecraft:overworld run fill 249 64 -11 249 65 -11 dirt
execute in minecraft:overworld run setblock 249 66 -11 coarse_dirt
execute in minecraft:overworld run fill 249 67 -11 249 144 -11 air
execute in minecraft:overworld run fill 249 58 -10 249 63 -10 stone
execute in minecraft:overworld run fill 249 64 -10 249 65 -10 dirt
execute in minecraft:overworld run setblock 249 66 -10 coarse_dirt
execute in minecraft:overworld run fill 249 67 -10 249 144 -10 air
execute in minecraft:overworld run fill 249 58 -9 249 63 -9 stone
execute in minecraft:overworld run fill 249 64 -9 249 65 -9 dirt
execute in minecraft:overworld run setblock 249 66 -9 coarse_dirt
execute in minecraft:overworld run fill 249 67 -9 249 144 -9 air
execute in minecraft:overworld run fill 249 58 -8 249 62 -8 stone
execute in minecraft:overworld run fill 249 63 -8 249 64 -8 dirt
execute in minecraft:overworld run setblock 249 65 -8 grass_block
execute in minecraft:overworld run fill 249 66 -8 249 144 -8 air
execute in minecraft:overworld run fill 249 58 -7 249 62 -7 stone
execute in minecraft:overworld run fill 249 63 -7 249 64 -7 dirt
execute in minecraft:overworld run setblock 249 65 -7 coarse_dirt
execute in minecraft:overworld run fill 249 66 -7 249 144 -7 air
execute in minecraft:overworld run fill 249 58 -6 249 62 -6 stone
execute in minecraft:overworld run fill 249 63 -6 249 64 -6 dirt
execute in minecraft:overworld run setblock 249 65 -6 coarse_dirt
execute in minecraft:overworld run fill 249 66 -6 249 144 -6 air
execute in minecraft:overworld run fill 249 58 -5 249 61 -5 stone
execute in minecraft:overworld run fill 249 62 -5 249 63 -5 dirt
execute in minecraft:overworld run setblock 249 64 -5 grass_block
execute in minecraft:overworld run fill 249 65 -5 249 144 -5 air
execute in minecraft:overworld run fill 249 58 -4 249 61 -4 stone
execute in minecraft:overworld run fill 249 62 -4 249 63 -4 dirt
execute in minecraft:overworld run setblock 249 64 -4 grass_block
execute in minecraft:overworld run fill 249 65 -4 249 144 -4 air
execute in minecraft:overworld run fill 249 58 -3 249 60 -3 stone
execute in minecraft:overworld run fill 249 61 -3 249 62 -3 dirt
execute in minecraft:overworld run setblock 249 63 -3 gravel
execute in minecraft:overworld run fill 249 64 -3 249 144 -3 air
execute in minecraft:overworld run fill 249 64 -3 249 64 -3 water
execute in minecraft:overworld run fill 249 58 -2 249 60 -2 stone
execute in minecraft:overworld run fill 249 61 -2 249 62 -2 dirt
execute in minecraft:overworld run setblock 249 63 -2 gravel
execute in minecraft:overworld run fill 249 64 -2 249 144 -2 air
execute in minecraft:overworld run fill 249 64 -2 249 64 -2 water
execute in minecraft:overworld run fill 249 58 -1 249 60 -1 stone
execute in minecraft:overworld run fill 249 61 -1 249 62 -1 dirt
execute in minecraft:overworld run setblock 249 63 -1 gravel
execute in minecraft:overworld run fill 249 64 -1 249 144 -1 air
execute in minecraft:overworld run fill 249 64 -1 249 64 -1 water
execute in minecraft:overworld run fill 249 58 0 249 60 0 stone
execute in minecraft:overworld run fill 249 61 0 249 62 0 dirt
execute in minecraft:overworld run setblock 249 63 0 gravel
execute in minecraft:overworld run fill 249 64 0 249 144 0 air
execute in minecraft:overworld run fill 249 64 0 249 64 0 water
execute in minecraft:overworld run fill 249 58 1 249 60 1 stone
execute in minecraft:overworld run fill 249 61 1 249 62 1 dirt
execute in minecraft:overworld run setblock 249 63 1 gravel
execute in minecraft:overworld run fill 249 64 1 249 144 1 air
execute in minecraft:overworld run fill 249 64 1 249 64 1 water
execute in minecraft:overworld run fill 249 58 2 249 60 2 stone
execute in minecraft:overworld run fill 249 61 2 249 62 2 dirt
execute in minecraft:overworld run setblock 249 63 2 gravel
execute in minecraft:overworld run fill 249 64 2 249 144 2 air
execute in minecraft:overworld run fill 249 64 2 249 64 2 water
execute in minecraft:overworld run fill 249 58 3 249 61 3 stone
execute in minecraft:overworld run fill 249 62 3 249 63 3 dirt
execute in minecraft:overworld run setblock 249 64 3 grass_block
execute in minecraft:overworld run fill 249 65 3 249 144 3 air
execute in minecraft:overworld run fill 249 58 4 249 61 4 stone
execute in minecraft:overworld run fill 249 62 4 249 63 4 dirt
execute in minecraft:overworld run setblock 249 64 4 coarse_dirt
execute in minecraft:overworld run fill 249 65 4 249 144 4 air
execute in minecraft:overworld run fill 249 58 5 249 61 5 stone
execute in minecraft:overworld run fill 249 62 5 249 63 5 dirt
execute in minecraft:overworld run setblock 249 64 5 coarse_dirt
execute in minecraft:overworld run fill 249 65 5 249 144 5 air
execute in minecraft:overworld run fill 249 58 6 249 62 6 stone
execute in minecraft:overworld run fill 249 63 6 249 64 6 dirt
execute in minecraft:overworld run setblock 249 65 6 coarse_dirt
execute in minecraft:overworld run fill 249 66 6 249 144 6 air
execute in minecraft:overworld run fill 249 58 7 249 62 7 stone
execute in minecraft:overworld run fill 249 63 7 249 64 7 dirt
execute in minecraft:overworld run setblock 249 65 7 coarse_dirt
execute in minecraft:overworld run fill 249 66 7 249 144 7 air
execute in minecraft:overworld run fill 249 58 8 249 63 8 stone
execute in minecraft:overworld run fill 249 64 8 249 65 8 dirt
execute in minecraft:overworld run setblock 249 66 8 coarse_dirt
execute in minecraft:overworld run fill 249 67 8 249 144 8 air
execute in minecraft:overworld run setblock 249 67 8 grass
execute in minecraft:overworld run fill 249 58 9 249 63 9 stone
execute in minecraft:overworld run fill 249 64 9 249 65 9 dirt
execute in minecraft:overworld run setblock 249 66 9 coarse_dirt
execute in minecraft:overworld run fill 249 67 9 249 144 9 air
execute in minecraft:overworld run setblock 249 67 9 grass
execute in minecraft:overworld run fill 249 58 10 249 63 10 stone
execute in minecraft:overworld run fill 249 64 10 249 65 10 dirt
execute in minecraft:overworld run setblock 249 66 10 coarse_dirt
execute in minecraft:overworld run fill 249 67 10 249 144 10 air
execute in minecraft:overworld run fill 249 58 11 249 63 11 stone
execute in minecraft:overworld run fill 249 64 11 249 65 11 dirt
execute in minecraft:overworld run setblock 249 66 11 coarse_dirt
execute in minecraft:overworld run fill 249 67 11 249 144 11 air
execute in minecraft:overworld run fill 249 58 12 249 63 12 stone
execute in minecraft:overworld run fill 249 64 12 249 65 12 dirt
execute in minecraft:overworld run setblock 249 66 12 grass_block
execute in minecraft:overworld run fill 249 67 12 249 144 12 air
execute in minecraft:overworld run fill 249 58 13 249 64 13 stone
execute in minecraft:overworld run fill 249 65 13 249 66 13 dirt
execute in minecraft:overworld run setblock 249 67 13 coarse_dirt
execute in minecraft:overworld run fill 249 68 13 249 144 13 air
execute in minecraft:overworld run fill 249 58 14 249 64 14 stone
execute in minecraft:overworld run fill 249 65 14 249 66 14 dirt
execute in minecraft:overworld run setblock 249 67 14 coarse_dirt
execute in minecraft:overworld run fill 249 68 14 249 144 14 air
execute in minecraft:overworld run fill 249 58 15 249 64 15 stone
execute in minecraft:overworld run fill 249 65 15 249 66 15 dirt
execute in minecraft:overworld run setblock 249 67 15 coarse_dirt
execute in minecraft:overworld run fill 249 68 15 249 144 15 air
execute in minecraft:overworld run fill 249 58 16 249 64 16 stone
execute in minecraft:overworld run fill 249 65 16 249 66 16 dirt
execute in minecraft:overworld run setblock 249 67 16 grass_block
schedule function blade_gallery:random/burned/part_64 1t replace
