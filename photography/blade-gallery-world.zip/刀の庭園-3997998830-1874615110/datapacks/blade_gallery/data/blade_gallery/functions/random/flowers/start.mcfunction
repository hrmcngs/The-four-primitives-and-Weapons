data modify storage blade_gallery:state random_busy set value 1b
execute in minecraft:overworld run forceload add 464 -48 559 47
schedule function blade_gallery:random/flowers/wait 1s replace
