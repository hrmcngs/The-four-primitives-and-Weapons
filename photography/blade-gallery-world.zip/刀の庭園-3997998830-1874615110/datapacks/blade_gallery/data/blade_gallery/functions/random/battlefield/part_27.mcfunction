execute in minecraft:overworld run fill 353 58 22 353 67 22 stone
execute in minecraft:overworld run fill 353 68 22 353 69 22 dirt
execute in minecraft:overworld run setblock 353 70 22 coarse_dirt
execute in minecraft:overworld run fill 353 71 22 353 144 22 air
execute in minecraft:overworld run fill 353 58 23 353 67 23 stone
execute in minecraft:overworld run fill 353 68 23 353 69 23 dirt
execute in minecraft:overworld run setblock 353 70 23 coarse_dirt
execute in minecraft:overworld run fill 353 71 23 353 144 23 air
execute in minecraft:overworld run fill 353 58 24 353 68 24 stone
execute in minecraft:overworld run fill 353 69 24 353 70 24 dirt
execute in minecraft:overworld run setblock 353 71 24 coarse_dirt
execute in minecraft:overworld run fill 353 72 24 353 144 24 air
execute in minecraft:overworld run fill 353 58 25 353 68 25 stone
execute in minecraft:overworld run fill 353 69 25 353 70 25 dirt
execute in minecraft:overworld run setblock 353 71 25 grass_block
execute in minecraft:overworld run fill 353 72 25 353 144 25 air
execute in minecraft:overworld run fill 353 58 26 353 68 26 stone
execute in minecraft:overworld run fill 353 69 26 353 70 26 dirt
execute in minecraft:overworld run setblock 353 71 26 coarse_dirt
execute in minecraft:overworld run fill 353 72 26 353 144 26 air
execute in minecraft:overworld run fill 353 58 27 353 68 27 stone
execute in minecraft:overworld run fill 353 69 27 353 70 27 dirt
execute in minecraft:overworld run setblock 353 71 27 coarse_dirt
execute in minecraft:overworld run fill 353 72 27 353 144 27 air
execute in minecraft:overworld run fill 353 58 28 353 68 28 stone
execute in minecraft:overworld run fill 353 69 28 353 70 28 dirt
execute in minecraft:overworld run setblock 353 71 28 coarse_dirt
execute in minecraft:overworld run fill 353 72 28 353 144 28 air
execute in minecraft:overworld run fill 353 58 29 353 68 29 stone
execute in minecraft:overworld run fill 353 69 29 353 70 29 dirt
execute in minecraft:overworld run setblock 353 71 29 coarse_dirt
execute in minecraft:overworld run fill 353 72 29 353 144 29 air
execute in minecraft:overworld run fill 353 58 30 353 68 30 stone
execute in minecraft:overworld run fill 353 69 30 353 70 30 dirt
execute in minecraft:overworld run setblock 353 71 30 coarse_dirt
execute in minecraft:overworld run fill 353 72 30 353 144 30 air
execute in minecraft:overworld run fill 353 58 31 353 68 31 stone
execute in minecraft:overworld run fill 353 69 31 353 70 31 dirt
execute in minecraft:overworld run setblock 353 71 31 grass_block
execute in minecraft:overworld run fill 353 72 31 353 144 31 air
execute in minecraft:overworld run fill 353 58 32 353 68 32 stone
execute in minecraft:overworld run fill 353 69 32 353 70 32 dirt
execute in minecraft:overworld run setblock 353 71 32 coarse_dirt
execute in minecraft:overworld run fill 353 72 32 353 144 32 air
execute in minecraft:overworld run fill 353 58 33 353 68 33 stone
execute in minecraft:overworld run fill 353 69 33 353 70 33 dirt
execute in minecraft:overworld run setblock 353 71 33 coarse_dirt
execute in minecraft:overworld run fill 353 72 33 353 144 33 air
execute in minecraft:overworld run fill 353 58 34 353 68 34 stone
execute in minecraft:overworld run fill 353 69 34 353 70 34 dirt
execute in minecraft:overworld run setblock 353 71 34 coarse_dirt
execute in minecraft:overworld run fill 353 72 34 353 144 34 air
execute in minecraft:overworld run setblock 353 72 34 grass
execute in minecraft:overworld run fill 353 58 35 353 68 35 stone
execute in minecraft:overworld run fill 353 69 35 353 70 35 dirt
execute in minecraft:overworld run setblock 353 71 35 coarse_dirt
execute in minecraft:overworld run fill 353 72 35 353 144 35 air
execute in minecraft:overworld run fill 353 58 36 353 68 36 stone
execute in minecraft:overworld run fill 353 69 36 353 70 36 dirt
execute in minecraft:overworld run setblock 353 71 36 coarse_dirt
execute in minecraft:overworld run fill 353 72 36 353 144 36 air
execute in minecraft:overworld run fill 353 58 37 353 68 37 stone
execute in minecraft:overworld run fill 353 69 37 353 70 37 dirt
execute in minecraft:overworld run setblock 353 71 37 coarse_dirt
execute in minecraft:overworld run fill 353 72 37 353 144 37 air
execute in minecraft:overworld run fill 353 58 38 353 68 38 stone
execute in minecraft:overworld run fill 353 69 38 353 70 38 dirt
execute in minecraft:overworld run setblock 353 71 38 grass_block
execute in minecraft:overworld run fill 353 72 38 353 144 38 air
execute in minecraft:overworld run fill 353 58 39 353 67 39 stone
execute in minecraft:overworld run fill 353 68 39 353 69 39 dirt
execute in minecraft:overworld run setblock 353 70 39 coarse_dirt
execute in minecraft:overworld run fill 353 71 39 353 144 39 air
execute in minecraft:overworld run fill 353 58 40 353 66 40 stone
execute in minecraft:overworld run fill 353 67 40 353 68 40 dirt
execute in minecraft:overworld run setblock 353 69 40 grass_block
execute in minecraft:overworld run fill 353 70 40 353 144 40 air
execute in minecraft:overworld run fill 353 58 41 353 66 41 stone
execute in minecraft:overworld run fill 353 67 41 353 68 41 dirt
execute in minecraft:overworld run setblock 353 69 41 coarse_dirt
execute in minecraft:overworld run fill 353 70 41 353 144 41 air
execute in minecraft:overworld run setblock 353 70 41 grass
execute in minecraft:overworld run fill 353 58 42 353 65 42 stone
execute in minecraft:overworld run fill 353 66 42 353 67 42 dirt
execute in minecraft:overworld run setblock 353 68 42 grass_block
execute in minecraft:overworld run fill 353 69 42 353 144 42 air
execute in minecraft:overworld run fill 353 58 43 353 64 43 stone
execute in minecraft:overworld run fill 353 65 43 353 66 43 dirt
execute in minecraft:overworld run setblock 353 67 43 coarse_dirt
execute in minecraft:overworld run fill 353 68 43 353 144 43 air
execute in minecraft:overworld run fill 353 58 44 353 64 44 stone
execute in minecraft:overworld run fill 353 65 44 353 66 44 dirt
execute in minecraft:overworld run setblock 353 67 44 coarse_dirt
execute in minecraft:overworld run fill 353 68 44 353 144 44 air
execute in minecraft:overworld run fill 353 58 45 353 63 45 stone
execute in minecraft:overworld run fill 353 64 45 353 65 45 dirt
execute in minecraft:overworld run setblock 353 66 45 coarse_dirt
execute in minecraft:overworld run fill 353 67 45 353 144 45 air
execute in minecraft:overworld run fill 353 58 46 353 62 46 stone
execute in minecraft:overworld run fill 353 63 46 353 64 46 dirt
execute in minecraft:overworld run setblock 353 65 46 coarse_dirt
execute in minecraft:overworld run fill 353 66 46 353 144 46 air
execute in minecraft:overworld run fill 353 58 47 353 62 47 stone
execute in minecraft:overworld run fill 353 63 47 353 64 47 dirt
execute in minecraft:overworld run setblock 353 65 47 coarse_dirt
execute in minecraft:overworld run fill 353 66 47 353 144 47 air
execute in minecraft:overworld run fill 354 58 -48 354 61 -48 stone
execute in minecraft:overworld run fill 354 62 -48 354 63 -48 dirt
execute in minecraft:overworld run setblock 354 64 -48 coarse_dirt
execute in minecraft:overworld run fill 354 65 -48 354 144 -48 air
execute in minecraft:overworld run fill 354 58 -47 354 63 -47 stone
execute in minecraft:overworld run fill 354 64 -47 354 65 -47 dirt
execute in minecraft:overworld run setblock 354 66 -47 coarse_dirt
execute in minecraft:overworld run fill 354 67 -47 354 144 -47 air
execute in minecraft:overworld run fill 354 58 -46 354 65 -46 stone
execute in minecraft:overworld run fill 354 66 -46 354 67 -46 dirt
execute in minecraft:overworld run setblock 354 68 -46 coarse_dirt
execute in minecraft:overworld run fill 354 69 -46 354 144 -46 air
execute in minecraft:overworld run fill 354 58 -45 354 67 -45 stone
execute in minecraft:overworld run fill 354 68 -45 354 69 -45 dirt
execute in minecraft:overworld run setblock 354 70 -45 coarse_dirt
execute in minecraft:overworld run fill 354 71 -45 354 144 -45 air
execute in minecraft:overworld run fill 354 58 -44 354 68 -44 stone
execute in minecraft:overworld run fill 354 69 -44 354 70 -44 dirt
execute in minecraft:overworld run setblock 354 71 -44 coarse_dirt
execute in minecraft:overworld run fill 354 72 -44 354 144 -44 air
execute in minecraft:overworld run fill 354 58 -43 354 70 -43 stone
execute in minecraft:overworld run fill 354 71 -43 354 72 -43 dirt
execute in minecraft:overworld run setblock 354 73 -43 grass_block
execute in minecraft:overworld run fill 354 74 -43 354 144 -43 air
execute in minecraft:overworld run fill 354 58 -42 354 71 -42 stone
execute in minecraft:overworld run fill 354 72 -42 354 73 -42 dirt
execute in minecraft:overworld run setblock 354 74 -42 coarse_dirt
execute in minecraft:overworld run fill 354 75 -42 354 144 -42 air
execute in minecraft:overworld run fill 354 58 -41 354 72 -41 stone
execute in minecraft:overworld run fill 354 73 -41 354 74 -41 dirt
execute in minecraft:overworld run setblock 354 75 -41 coarse_dirt
execute in minecraft:overworld run fill 354 76 -41 354 144 -41 air
execute in minecraft:overworld run setblock 354 76 -41 grass
execute in minecraft:overworld run fill 354 58 -40 354 74 -40 stone
execute in minecraft:overworld run fill 354 75 -40 354 76 -40 dirt
execute in minecraft:overworld run setblock 354 77 -40 coarse_dirt
execute in minecraft:overworld run fill 354 78 -40 354 144 -40 air
execute in minecraft:overworld run fill 354 58 -39 354 75 -39 stone
execute in minecraft:overworld run fill 354 76 -39 354 77 -39 dirt
execute in minecraft:overworld run setblock 354 78 -39 coarse_dirt
execute in minecraft:overworld run fill 354 79 -39 354 144 -39 air
execute in minecraft:overworld run fill 354 58 -38 354 75 -38 stone
execute in minecraft:overworld run fill 354 76 -38 354 77 -38 dirt
execute in minecraft:overworld run setblock 354 78 -38 coarse_dirt
execute in minecraft:overworld run fill 354 79 -38 354 144 -38 air
execute in minecraft:overworld run fill 354 58 -37 354 75 -37 stone
execute in minecraft:overworld run fill 354 76 -37 354 77 -37 dirt
execute in minecraft:overworld run setblock 354 78 -37 coarse_dirt
execute in minecraft:overworld run fill 354 79 -37 354 144 -37 air
execute in minecraft:overworld run fill 354 58 -36 354 75 -36 stone
execute in minecraft:overworld run fill 354 76 -36 354 77 -36 dirt
execute in minecraft:overworld run setblock 354 78 -36 coarse_dirt
execute in minecraft:overworld run fill 354 79 -36 354 144 -36 air
execute in minecraft:overworld run fill 354 58 -35 354 74 -35 stone
execute in minecraft:overworld run fill 354 75 -35 354 76 -35 dirt
execute in minecraft:overworld run setblock 354 77 -35 coarse_dirt
execute in minecraft:overworld run fill 354 78 -35 354 144 -35 air
execute in minecraft:overworld run fill 354 58 -34 354 74 -34 stone
execute in minecraft:overworld run fill 354 75 -34 354 76 -34 dirt
execute in minecraft:overworld run setblock 354 77 -34 coarse_dirt
execute in minecraft:overworld run fill 354 78 -34 354 144 -34 air
execute in minecraft:overworld run fill 354 58 -33 354 74 -33 stone
execute in minecraft:overworld run fill 354 75 -33 354 76 -33 dirt
execute in minecraft:overworld run setblock 354 77 -33 coarse_dirt
execute in minecraft:overworld run fill 354 78 -33 354 144 -33 air
execute in minecraft:overworld run fill 354 58 -32 354 74 -32 stone
execute in minecraft:overworld run fill 354 75 -32 354 76 -32 dirt
execute in minecraft:overworld run setblock 354 77 -32 coarse_dirt
execute in minecraft:overworld run fill 354 78 -32 354 144 -32 air
execute in minecraft:overworld run fill 354 58 -31 354 74 -31 stone
execute in minecraft:overworld run fill 354 75 -31 354 76 -31 dirt
execute in minecraft:overworld run setblock 354 77 -31 coarse_dirt
execute in minecraft:overworld run fill 354 78 -31 354 144 -31 air
execute in minecraft:overworld run fill 354 58 -30 354 74 -30 stone
execute in minecraft:overworld run fill 354 75 -30 354 76 -30 dirt
execute in minecraft:overworld run setblock 354 77 -30 coarse_dirt
execute in minecraft:overworld run fill 354 78 -30 354 144 -30 air
execute in minecraft:overworld run fill 354 58 -29 354 73 -29 stone
execute in minecraft:overworld run fill 354 74 -29 354 75 -29 dirt
execute in minecraft:overworld run setblock 354 76 -29 coarse_dirt
execute in minecraft:overworld run fill 354 77 -29 354 144 -29 air
execute in minecraft:overworld run fill 354 58 -28 354 73 -28 stone
execute in minecraft:overworld run fill 354 74 -28 354 75 -28 dirt
execute in minecraft:overworld run setblock 354 76 -28 grass_block
execute in minecraft:overworld run fill 354 77 -28 354 144 -28 air
execute in minecraft:overworld run fill 354 58 -27 354 73 -27 stone
execute in minecraft:overworld run fill 354 74 -27 354 75 -27 dirt
execute in minecraft:overworld run setblock 354 76 -27 coarse_dirt
execute in minecraft:overworld run fill 354 77 -27 354 144 -27 air
execute in minecraft:overworld run fill 354 58 -26 354 72 -26 stone
execute in minecraft:overworld run fill 354 73 -26 354 74 -26 dirt
execute in minecraft:overworld run setblock 354 75 -26 grass_block
execute in minecraft:overworld run fill 354 76 -26 354 144 -26 air
execute in minecraft:overworld run fill 354 58 -25 354 72 -25 stone
execute in minecraft:overworld run fill 354 73 -25 354 74 -25 dirt
execute in minecraft:overworld run setblock 354 75 -25 coarse_dirt
execute in minecraft:overworld run fill 354 76 -25 354 144 -25 air
execute in minecraft:overworld run fill 354 58 -24 354 72 -24 stone
execute in minecraft:overworld run fill 354 73 -24 354 74 -24 dirt
execute in minecraft:overworld run setblock 354 75 -24 coarse_dirt
execute in minecraft:overworld run fill 354 76 -24 354 144 -24 air
execute in minecraft:overworld run setblock 354 76 -24 grass
execute in minecraft:overworld run fill 354 58 -23 354 71 -23 stone
execute in minecraft:overworld run fill 354 72 -23 354 73 -23 dirt
execute in minecraft:overworld run setblock 354 74 -23 grass_block
execute in minecraft:overworld run fill 354 75 -23 354 144 -23 air
execute in minecraft:overworld run fill 354 58 -22 354 71 -22 stone
execute in minecraft:overworld run fill 354 72 -22 354 73 -22 dirt
execute in minecraft:overworld run setblock 354 74 -22 grass_block
execute in minecraft:overworld run fill 354 75 -22 354 144 -22 air
execute in minecraft:overworld run setblock 354 75 -22 grass
execute in minecraft:overworld run fill 354 58 -21 354 71 -21 stone
execute in minecraft:overworld run fill 354 72 -21 354 73 -21 dirt
execute in minecraft:overworld run setblock 354 74 -21 coarse_dirt
execute in minecraft:overworld run fill 354 75 -21 354 144 -21 air
execute in minecraft:overworld run fill 354 58 -20 354 70 -20 stone
execute in minecraft:overworld run fill 354 71 -20 354 72 -20 dirt
execute in minecraft:overworld run setblock 354 73 -20 coarse_dirt
execute in minecraft:overworld run fill 354 74 -20 354 144 -20 air
execute in minecraft:overworld run fill 354 58 -19 354 70 -19 stone
execute in minecraft:overworld run fill 354 71 -19 354 72 -19 dirt
execute in minecraft:overworld run setblock 354 73 -19 coarse_dirt
execute in minecraft:overworld run fill 354 74 -19 354 144 -19 air
execute in minecraft:overworld run fill 354 58 -18 354 70 -18 stone
execute in minecraft:overworld run fill 354 71 -18 354 72 -18 dirt
execute in minecraft:overworld run setblock 354 73 -18 coarse_dirt
execute in minecraft:overworld run fill 354 74 -18 354 144 -18 air
execute in minecraft:overworld run fill 354 58 -17 354 69 -17 stone
execute in minecraft:overworld run fill 354 70 -17 354 71 -17 dirt
execute in minecraft:overworld run setblock 354 72 -17 coarse_dirt
execute in minecraft:overworld run fill 354 73 -17 354 144 -17 air
execute in minecraft:overworld run fill 354 58 -16 354 69 -16 stone
execute in minecraft:overworld run fill 354 70 -16 354 71 -16 dirt
execute in minecraft:overworld run setblock 354 72 -16 coarse_dirt
execute in minecraft:overworld run fill 354 73 -16 354 144 -16 air
execute in minecraft:overworld run fill 354 58 -15 354 68 -15 stone
execute in minecraft:overworld run fill 354 69 -15 354 70 -15 dirt
execute in minecraft:overworld run setblock 354 71 -15 grass_block
execute in minecraft:overworld run fill 354 72 -15 354 144 -15 air
execute in minecraft:overworld run fill 354 58 -14 354 68 -14 stone
execute in minecraft:overworld run fill 354 69 -14 354 70 -14 dirt
execute in minecraft:overworld run setblock 354 71 -14 coarse_dirt
execute in minecraft:overworld run fill 354 72 -14 354 144 -14 air
execute in minecraft:overworld run fill 354 58 -13 354 67 -13 stone
execute in minecraft:overworld run fill 354 68 -13 354 69 -13 dirt
execute in minecraft:overworld run setblock 354 70 -13 coarse_dirt
execute in minecraft:overworld run fill 354 71 -13 354 144 -13 air
execute in minecraft:overworld run fill 354 58 -12 354 67 -12 stone
execute in minecraft:overworld run fill 354 68 -12 354 69 -12 dirt
execute in minecraft:overworld run setblock 354 70 -12 coarse_dirt
schedule function blade_gallery:random/battlefield/part_28 1t replace
