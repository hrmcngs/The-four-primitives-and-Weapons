execute in minecraft:overworld run fill 372 69 3 372 144 3 air
execute in minecraft:overworld run fill 372 58 4 372 65 4 stone
execute in minecraft:overworld run fill 372 66 4 372 67 4 dirt
execute in minecraft:overworld run setblock 372 68 4 grass_block
execute in minecraft:overworld run fill 372 69 4 372 144 4 air
execute in minecraft:overworld run fill 372 58 5 372 65 5 stone
execute in minecraft:overworld run fill 372 66 5 372 67 5 dirt
execute in minecraft:overworld run setblock 372 68 5 grass_block
execute in minecraft:overworld run fill 372 69 5 372 144 5 air
execute in minecraft:overworld run fill 372 58 6 372 65 6 stone
execute in minecraft:overworld run fill 372 66 6 372 67 6 dirt
execute in minecraft:overworld run setblock 372 68 6 grass_block
execute in minecraft:overworld run fill 372 69 6 372 144 6 air
execute in minecraft:overworld run fill 372 58 7 372 65 7 stone
execute in minecraft:overworld run fill 372 66 7 372 67 7 dirt
execute in minecraft:overworld run setblock 372 68 7 grass_block
execute in minecraft:overworld run fill 372 69 7 372 144 7 air
execute in minecraft:overworld run setblock 372 69 7 grass
execute in minecraft:overworld run fill 372 58 8 372 65 8 stone
execute in minecraft:overworld run fill 372 66 8 372 67 8 dirt
execute in minecraft:overworld run setblock 372 68 8 grass_block
execute in minecraft:overworld run fill 372 69 8 372 144 8 air
execute in minecraft:overworld run fill 372 58 9 372 65 9 stone
execute in minecraft:overworld run fill 372 66 9 372 67 9 dirt
execute in minecraft:overworld run setblock 372 68 9 coarse_dirt
execute in minecraft:overworld run fill 372 69 9 372 144 9 air
execute in minecraft:overworld run fill 372 58 10 372 65 10 stone
execute in minecraft:overworld run fill 372 66 10 372 67 10 dirt
execute in minecraft:overworld run setblock 372 68 10 grass_block
execute in minecraft:overworld run fill 372 69 10 372 144 10 air
execute in minecraft:overworld run fill 372 58 11 372 66 11 stone
execute in minecraft:overworld run fill 372 67 11 372 68 11 dirt
execute in minecraft:overworld run setblock 372 69 11 coarse_dirt
execute in minecraft:overworld run fill 372 70 11 372 144 11 air
execute in minecraft:overworld run fill 372 58 12 372 66 12 stone
execute in minecraft:overworld run fill 372 67 12 372 68 12 dirt
execute in minecraft:overworld run setblock 372 69 12 coarse_dirt
execute in minecraft:overworld run fill 372 70 12 372 144 12 air
execute in minecraft:overworld run setblock 372 70 12 grass
execute in minecraft:overworld run fill 372 58 13 372 66 13 stone
execute in minecraft:overworld run fill 372 67 13 372 68 13 dirt
execute in minecraft:overworld run setblock 372 69 13 coarse_dirt
execute in minecraft:overworld run fill 372 70 13 372 144 13 air
execute in minecraft:overworld run setblock 372 70 13 grass
execute in minecraft:overworld run fill 372 58 14 372 67 14 stone
execute in minecraft:overworld run fill 372 68 14 372 69 14 dirt
execute in minecraft:overworld run setblock 372 70 14 grass_block
execute in minecraft:overworld run fill 372 71 14 372 144 14 air
execute in minecraft:overworld run fill 372 58 15 372 67 15 stone
execute in minecraft:overworld run fill 372 68 15 372 69 15 dirt
execute in minecraft:overworld run setblock 372 70 15 grass_block
execute in minecraft:overworld run fill 372 71 15 372 144 15 air
execute in minecraft:overworld run fill 372 58 16 372 67 16 stone
execute in minecraft:overworld run fill 372 68 16 372 69 16 dirt
execute in minecraft:overworld run setblock 372 70 16 coarse_dirt
execute in minecraft:overworld run fill 372 71 16 372 144 16 air
execute in minecraft:overworld run fill 372 58 17 372 67 17 stone
execute in minecraft:overworld run fill 372 68 17 372 69 17 dirt
execute in minecraft:overworld run setblock 372 70 17 coarse_dirt
execute in minecraft:overworld run fill 372 71 17 372 144 17 air
execute in minecraft:overworld run fill 372 58 18 372 68 18 stone
execute in minecraft:overworld run fill 372 69 18 372 70 18 dirt
execute in minecraft:overworld run setblock 372 71 18 coarse_dirt
execute in minecraft:overworld run fill 372 72 18 372 144 18 air
execute in minecraft:overworld run fill 372 58 19 372 68 19 stone
execute in minecraft:overworld run fill 372 69 19 372 70 19 dirt
execute in minecraft:overworld run setblock 372 71 19 coarse_dirt
execute in minecraft:overworld run fill 372 72 19 372 144 19 air
execute in minecraft:overworld run fill 372 58 20 372 68 20 stone
execute in minecraft:overworld run fill 372 69 20 372 70 20 dirt
execute in minecraft:overworld run setblock 372 71 20 coarse_dirt
execute in minecraft:overworld run fill 372 72 20 372 144 20 air
execute in minecraft:overworld run fill 372 58 21 372 68 21 stone
execute in minecraft:overworld run fill 372 69 21 372 70 21 dirt
execute in minecraft:overworld run setblock 372 71 21 coarse_dirt
execute in minecraft:overworld run fill 372 72 21 372 144 21 air
execute in minecraft:overworld run fill 372 58 22 372 68 22 stone
execute in minecraft:overworld run fill 372 69 22 372 70 22 dirt
execute in minecraft:overworld run setblock 372 71 22 coarse_dirt
execute in minecraft:overworld run fill 372 72 22 372 144 22 air
execute in minecraft:overworld run fill 372 58 23 372 68 23 stone
execute in minecraft:overworld run fill 372 69 23 372 70 23 dirt
execute in minecraft:overworld run setblock 372 71 23 grass_block
execute in minecraft:overworld run fill 372 72 23 372 144 23 air
execute in minecraft:overworld run fill 372 58 24 372 68 24 stone
execute in minecraft:overworld run fill 372 69 24 372 70 24 dirt
execute in minecraft:overworld run setblock 372 71 24 coarse_dirt
execute in minecraft:overworld run fill 372 72 24 372 144 24 air
execute in minecraft:overworld run fill 372 58 25 372 68 25 stone
execute in minecraft:overworld run fill 372 69 25 372 70 25 dirt
execute in minecraft:overworld run setblock 372 71 25 coarse_dirt
execute in minecraft:overworld run fill 372 72 25 372 144 25 air
execute in minecraft:overworld run setblock 372 72 25 mossy_cobblestone
execute in minecraft:overworld run fill 372 58 26 372 68 26 stone
execute in minecraft:overworld run fill 372 69 26 372 70 26 dirt
execute in minecraft:overworld run setblock 372 71 26 coarse_dirt
execute in minecraft:overworld run fill 372 72 26 372 144 26 air
execute in minecraft:overworld run fill 372 58 27 372 68 27 stone
execute in minecraft:overworld run fill 372 69 27 372 70 27 dirt
execute in minecraft:overworld run setblock 372 71 27 coarse_dirt
execute in minecraft:overworld run fill 372 72 27 372 144 27 air
execute in minecraft:overworld run fill 372 58 28 372 68 28 stone
execute in minecraft:overworld run fill 372 69 28 372 70 28 dirt
execute in minecraft:overworld run setblock 372 71 28 grass_block
execute in minecraft:overworld run fill 372 72 28 372 144 28 air
execute in minecraft:overworld run fill 372 58 29 372 68 29 stone
execute in minecraft:overworld run fill 372 69 29 372 70 29 dirt
execute in minecraft:overworld run setblock 372 71 29 coarse_dirt
execute in minecraft:overworld run fill 372 72 29 372 144 29 air
execute in minecraft:overworld run fill 372 58 30 372 68 30 stone
execute in minecraft:overworld run fill 372 69 30 372 70 30 dirt
execute in minecraft:overworld run setblock 372 71 30 coarse_dirt
execute in minecraft:overworld run fill 372 72 30 372 144 30 air
execute in minecraft:overworld run setblock 372 72 30 grass
execute in minecraft:overworld run fill 372 58 31 372 68 31 stone
execute in minecraft:overworld run fill 372 69 31 372 70 31 dirt
execute in minecraft:overworld run setblock 372 71 31 coarse_dirt
execute in minecraft:overworld run fill 372 72 31 372 144 31 air
execute in minecraft:overworld run fill 372 58 32 372 69 32 stone
execute in minecraft:overworld run fill 372 70 32 372 71 32 dirt
execute in minecraft:overworld run setblock 372 72 32 coarse_dirt
execute in minecraft:overworld run fill 372 73 32 372 144 32 air
execute in minecraft:overworld run setblock 372 73 32 grass
execute in minecraft:overworld run fill 372 58 33 372 69 33 stone
execute in minecraft:overworld run fill 372 70 33 372 71 33 dirt
execute in minecraft:overworld run setblock 372 72 33 coarse_dirt
execute in minecraft:overworld run fill 372 73 33 372 144 33 air
execute in minecraft:overworld run fill 372 58 34 372 69 34 stone
execute in minecraft:overworld run fill 372 70 34 372 71 34 dirt
execute in minecraft:overworld run setblock 372 72 34 grass_block
execute in minecraft:overworld run fill 372 73 34 372 144 34 air
execute in minecraft:overworld run fill 372 58 35 372 70 35 stone
execute in minecraft:overworld run fill 372 71 35 372 72 35 dirt
execute in minecraft:overworld run setblock 372 73 35 coarse_dirt
execute in minecraft:overworld run fill 372 74 35 372 144 35 air
execute in minecraft:overworld run fill 372 58 36 372 70 36 stone
execute in minecraft:overworld run fill 372 71 36 372 72 36 dirt
execute in minecraft:overworld run setblock 372 73 36 coarse_dirt
execute in minecraft:overworld run fill 372 74 36 372 144 36 air
execute in minecraft:overworld run fill 372 58 37 372 70 37 stone
execute in minecraft:overworld run fill 372 71 37 372 72 37 dirt
execute in minecraft:overworld run setblock 372 73 37 coarse_dirt
execute in minecraft:overworld run fill 372 74 37 372 144 37 air
execute in minecraft:overworld run fill 372 58 38 372 70 38 stone
execute in minecraft:overworld run fill 372 71 38 372 72 38 dirt
execute in minecraft:overworld run setblock 372 73 38 coarse_dirt
execute in minecraft:overworld run fill 372 74 38 372 144 38 air
execute in minecraft:overworld run fill 372 58 39 372 69 39 stone
execute in minecraft:overworld run fill 372 70 39 372 71 39 dirt
execute in minecraft:overworld run setblock 372 72 39 grass_block
execute in minecraft:overworld run fill 372 73 39 372 144 39 air
execute in minecraft:overworld run fill 372 58 40 372 68 40 stone
execute in minecraft:overworld run fill 372 69 40 372 70 40 dirt
execute in minecraft:overworld run setblock 372 71 40 coarse_dirt
execute in minecraft:overworld run fill 372 72 40 372 144 40 air
execute in minecraft:overworld run fill 372 58 41 372 67 41 stone
execute in minecraft:overworld run fill 372 68 41 372 69 41 dirt
execute in minecraft:overworld run setblock 372 70 41 coarse_dirt
execute in minecraft:overworld run fill 372 71 41 372 144 41 air
execute in minecraft:overworld run fill 372 58 42 372 66 42 stone
execute in minecraft:overworld run fill 372 67 42 372 68 42 dirt
execute in minecraft:overworld run setblock 372 69 42 grass_block
execute in minecraft:overworld run fill 372 70 42 372 144 42 air
execute in minecraft:overworld run fill 372 58 43 372 65 43 stone
execute in minecraft:overworld run fill 372 66 43 372 67 43 dirt
execute in minecraft:overworld run setblock 372 68 43 grass_block
execute in minecraft:overworld run fill 372 69 43 372 144 43 air
execute in minecraft:overworld run fill 372 58 44 372 64 44 stone
execute in minecraft:overworld run fill 372 65 44 372 66 44 dirt
execute in minecraft:overworld run setblock 372 67 44 coarse_dirt
execute in minecraft:overworld run fill 372 68 44 372 144 44 air
execute in minecraft:overworld run fill 372 58 45 372 64 45 stone
execute in minecraft:overworld run fill 372 65 45 372 66 45 dirt
execute in minecraft:overworld run setblock 372 67 45 coarse_dirt
execute in minecraft:overworld run fill 372 68 45 372 144 45 air
execute in minecraft:overworld run fill 372 58 46 372 63 46 stone
execute in minecraft:overworld run fill 372 64 46 372 65 46 dirt
execute in minecraft:overworld run setblock 372 66 46 grass_block
execute in minecraft:overworld run fill 372 67 46 372 144 46 air
execute in minecraft:overworld run fill 372 58 47 372 62 47 stone
execute in minecraft:overworld run fill 372 63 47 372 64 47 dirt
execute in minecraft:overworld run setblock 372 65 47 coarse_dirt
execute in minecraft:overworld run fill 372 66 47 372 144 47 air
execute in minecraft:overworld run fill 373 58 -48 373 61 -48 stone
execute in minecraft:overworld run fill 373 62 -48 373 63 -48 dirt
execute in minecraft:overworld run setblock 373 64 -48 coarse_dirt
execute in minecraft:overworld run fill 373 65 -48 373 144 -48 air
execute in minecraft:overworld run fill 373 58 -47 373 62 -47 stone
execute in minecraft:overworld run fill 373 63 -47 373 64 -47 dirt
execute in minecraft:overworld run setblock 373 65 -47 grass_block
execute in minecraft:overworld run fill 373 66 -47 373 144 -47 air
execute in minecraft:overworld run fill 373 58 -46 373 63 -46 stone
execute in minecraft:overworld run fill 373 64 -46 373 65 -46 dirt
execute in minecraft:overworld run setblock 373 66 -46 coarse_dirt
execute in minecraft:overworld run fill 373 67 -46 373 144 -46 air
execute in minecraft:overworld run fill 373 58 -45 373 63 -45 stone
execute in minecraft:overworld run fill 373 64 -45 373 65 -45 dirt
execute in minecraft:overworld run setblock 373 66 -45 grass_block
execute in minecraft:overworld run fill 373 67 -45 373 144 -45 air
execute in minecraft:overworld run fill 373 58 -44 373 64 -44 stone
execute in minecraft:overworld run fill 373 65 -44 373 66 -44 dirt
execute in minecraft:overworld run setblock 373 67 -44 coarse_dirt
execute in minecraft:overworld run fill 373 68 -44 373 144 -44 air
execute in minecraft:overworld run fill 373 58 -43 373 65 -43 stone
execute in minecraft:overworld run fill 373 66 -43 373 67 -43 dirt
execute in minecraft:overworld run setblock 373 68 -43 grass_block
execute in minecraft:overworld run fill 373 69 -43 373 144 -43 air
execute in minecraft:overworld run fill 373 58 -42 373 65 -42 stone
execute in minecraft:overworld run fill 373 66 -42 373 67 -42 dirt
execute in minecraft:overworld run setblock 373 68 -42 coarse_dirt
execute in minecraft:overworld run fill 373 69 -42 373 144 -42 air
execute in minecraft:overworld run fill 373 58 -41 373 66 -41 stone
execute in minecraft:overworld run fill 373 67 -41 373 68 -41 dirt
execute in minecraft:overworld run setblock 373 69 -41 coarse_dirt
execute in minecraft:overworld run fill 373 70 -41 373 144 -41 air
execute in minecraft:overworld run fill 373 58 -40 373 66 -40 stone
execute in minecraft:overworld run fill 373 67 -40 373 68 -40 dirt
execute in minecraft:overworld run setblock 373 69 -40 coarse_dirt
execute in minecraft:overworld run fill 373 70 -40 373 144 -40 air
execute in minecraft:overworld run setblock 373 70 -40 grass
execute in minecraft:overworld run fill 373 58 -39 373 67 -39 stone
execute in minecraft:overworld run fill 373 68 -39 373 69 -39 dirt
execute in minecraft:overworld run setblock 373 70 -39 coarse_dirt
execute in minecraft:overworld run fill 373 71 -39 373 144 -39 air
execute in minecraft:overworld run fill 373 58 -38 373 67 -38 stone
execute in minecraft:overworld run fill 373 68 -38 373 69 -38 dirt
execute in minecraft:overworld run setblock 373 70 -38 coarse_dirt
execute in minecraft:overworld run fill 373 71 -38 373 144 -38 air
execute in minecraft:overworld run fill 373 58 -37 373 67 -37 stone
execute in minecraft:overworld run fill 373 68 -37 373 69 -37 dirt
execute in minecraft:overworld run setblock 373 70 -37 coarse_dirt
execute in minecraft:overworld run fill 373 71 -37 373 144 -37 air
execute in minecraft:overworld run fill 373 58 -36 373 67 -36 stone
execute in minecraft:overworld run fill 373 68 -36 373 69 -36 dirt
execute in minecraft:overworld run setblock 373 70 -36 coarse_dirt
execute in minecraft:overworld run fill 373 71 -36 373 144 -36 air
execute in minecraft:overworld run fill 373 58 -35 373 67 -35 stone
execute in minecraft:overworld run fill 373 68 -35 373 69 -35 dirt
execute in minecraft:overworld run setblock 373 70 -35 grass_block
execute in minecraft:overworld run fill 373 71 -35 373 144 -35 air
execute in minecraft:overworld run setblock 373 71 -35 grass
execute in minecraft:overworld run fill 373 58 -34 373 68 -34 stone
execute in minecraft:overworld run fill 373 69 -34 373 70 -34 dirt
execute in minecraft:overworld run setblock 373 71 -34 coarse_dirt
execute in minecraft:overworld run fill 373 72 -34 373 144 -34 air
execute in minecraft:overworld run fill 373 58 -33 373 68 -33 stone
execute in minecraft:overworld run fill 373 69 -33 373 70 -33 dirt
execute in minecraft:overworld run setblock 373 71 -33 coarse_dirt
execute in minecraft:overworld run fill 373 72 -33 373 144 -33 air
execute in minecraft:overworld run fill 373 58 -32 373 68 -32 stone
execute in minecraft:overworld run fill 373 69 -32 373 70 -32 dirt
execute in minecraft:overworld run setblock 373 71 -32 coarse_dirt
execute in minecraft:overworld run fill 373 72 -32 373 144 -32 air
execute in minecraft:overworld run fill 373 58 -31 373 68 -31 stone
execute in minecraft:overworld run fill 373 69 -31 373 70 -31 dirt
execute in minecraft:overworld run setblock 373 71 -31 coarse_dirt
schedule function blade_gallery:random/battlefield/part_57 1t replace
