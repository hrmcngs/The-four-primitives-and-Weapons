data modify storage blade_gallery:state random_busy set value 1b
execute in minecraft:overworld run forceload add 336 -48 431 47
schedule function blade_gallery:random/battlefield/wait 1s replace
