execute in minecraft:overworld run fill 379 63 -47 379 64 -47 dirt
execute in minecraft:overworld run setblock 379 65 -47 coarse_dirt
execute in minecraft:overworld run fill 379 66 -47 379 144 -47 air
execute in minecraft:overworld run fill 379 58 -46 379 63 -46 stone
execute in minecraft:overworld run fill 379 64 -46 379 65 -46 dirt
execute in minecraft:overworld run setblock 379 66 -46 coarse_dirt
execute in minecraft:overworld run fill 379 67 -46 379 144 -46 air
execute in minecraft:overworld run fill 379 58 -45 379 64 -45 stone
execute in minecraft:overworld run fill 379 65 -45 379 66 -45 dirt
execute in minecraft:overworld run setblock 379 67 -45 coarse_dirt
execute in minecraft:overworld run fill 379 68 -45 379 144 -45 air
execute in minecraft:overworld run fill 379 58 -44 379 65 -44 stone
execute in minecraft:overworld run fill 379 66 -44 379 67 -44 dirt
execute in minecraft:overworld run setblock 379 68 -44 coarse_dirt
execute in minecraft:overworld run fill 379 69 -44 379 144 -44 air
execute in minecraft:overworld run fill 379 58 -43 379 66 -43 stone
execute in minecraft:overworld run fill 379 67 -43 379 68 -43 dirt
execute in minecraft:overworld run setblock 379 69 -43 grass_block
execute in minecraft:overworld run fill 379 70 -43 379 144 -43 air
execute in minecraft:overworld run fill 379 58 -42 379 66 -42 stone
execute in minecraft:overworld run fill 379 67 -42 379 68 -42 dirt
execute in minecraft:overworld run setblock 379 69 -42 grass_block
execute in minecraft:overworld run fill 379 70 -42 379 144 -42 air
execute in minecraft:overworld run fill 379 58 -41 379 66 -41 stone
execute in minecraft:overworld run fill 379 67 -41 379 68 -41 dirt
execute in minecraft:overworld run setblock 379 69 -41 grass_block
execute in minecraft:overworld run fill 379 70 -41 379 144 -41 air
execute in minecraft:overworld run fill 379 58 -40 379 66 -40 stone
execute in minecraft:overworld run fill 379 67 -40 379 68 -40 dirt
execute in minecraft:overworld run setblock 379 69 -40 grass_block
execute in minecraft:overworld run fill 379 70 -40 379 144 -40 air
execute in minecraft:overworld run fill 379 58 -39 379 66 -39 stone
execute in minecraft:overworld run fill 379 67 -39 379 68 -39 dirt
execute in minecraft:overworld run setblock 379 69 -39 coarse_dirt
execute in minecraft:overworld run fill 379 70 -39 379 144 -39 air
execute in minecraft:overworld run fill 379 58 -38 379 66 -38 stone
execute in minecraft:overworld run fill 379 67 -38 379 68 -38 dirt
execute in minecraft:overworld run setblock 379 69 -38 grass_block
execute in minecraft:overworld run fill 379 70 -38 379 144 -38 air
execute in minecraft:overworld run fill 379 58 -37 379 66 -37 stone
execute in minecraft:overworld run fill 379 67 -37 379 68 -37 dirt
execute in minecraft:overworld run setblock 379 69 -37 coarse_dirt
execute in minecraft:overworld run fill 379 70 -37 379 144 -37 air
execute in minecraft:overworld run fill 379 58 -36 379 65 -36 stone
execute in minecraft:overworld run fill 379 66 -36 379 67 -36 dirt
execute in minecraft:overworld run setblock 379 68 -36 coarse_dirt
execute in minecraft:overworld run fill 379 69 -36 379 144 -36 air
execute in minecraft:overworld run fill 379 58 -35 379 65 -35 stone
execute in minecraft:overworld run fill 379 66 -35 379 67 -35 dirt
execute in minecraft:overworld run setblock 379 68 -35 grass_block
execute in minecraft:overworld run fill 379 69 -35 379 144 -35 air
execute in minecraft:overworld run setblock 379 69 -35 grass
execute in minecraft:overworld run fill 379 58 -34 379 65 -34 stone
execute in minecraft:overworld run fill 379 66 -34 379 67 -34 dirt
execute in minecraft:overworld run setblock 379 68 -34 grass_block
execute in minecraft:overworld run fill 379 69 -34 379 144 -34 air
execute in minecraft:overworld run fill 379 58 -33 379 64 -33 stone
execute in minecraft:overworld run fill 379 65 -33 379 66 -33 dirt
execute in minecraft:overworld run setblock 379 67 -33 grass_block
execute in minecraft:overworld run fill 379 68 -33 379 144 -33 air
execute in minecraft:overworld run fill 379 58 -32 379 64 -32 stone
execute in minecraft:overworld run fill 379 65 -32 379 66 -32 dirt
execute in minecraft:overworld run setblock 379 67 -32 coarse_dirt
execute in minecraft:overworld run fill 379 68 -32 379 144 -32 air
execute in minecraft:overworld run fill 379 58 -31 379 64 -31 stone
execute in minecraft:overworld run fill 379 65 -31 379 66 -31 dirt
execute in minecraft:overworld run setblock 379 67 -31 coarse_dirt
execute in minecraft:overworld run fill 379 68 -31 379 144 -31 air
execute in minecraft:overworld run fill 379 58 -30 379 64 -30 stone
execute in minecraft:overworld run fill 379 65 -30 379 66 -30 dirt
execute in minecraft:overworld run setblock 379 67 -30 coarse_dirt
execute in minecraft:overworld run fill 379 68 -30 379 144 -30 air
execute in minecraft:overworld run fill 379 58 -29 379 64 -29 stone
execute in minecraft:overworld run fill 379 65 -29 379 66 -29 dirt
execute in minecraft:overworld run setblock 379 67 -29 coarse_dirt
execute in minecraft:overworld run fill 379 68 -29 379 144 -29 air
execute in minecraft:overworld run fill 379 58 -28 379 64 -28 stone
execute in minecraft:overworld run fill 379 65 -28 379 66 -28 dirt
execute in minecraft:overworld run setblock 379 67 -28 grass_block
execute in minecraft:overworld run fill 379 68 -28 379 144 -28 air
execute in minecraft:overworld run fill 379 58 -27 379 64 -27 stone
execute in minecraft:overworld run fill 379 65 -27 379 66 -27 dirt
execute in minecraft:overworld run setblock 379 67 -27 coarse_dirt
execute in minecraft:overworld run fill 379 68 -27 379 144 -27 air
execute in minecraft:overworld run fill 379 58 -26 379 64 -26 stone
execute in minecraft:overworld run fill 379 65 -26 379 66 -26 dirt
execute in minecraft:overworld run setblock 379 67 -26 coarse_dirt
execute in minecraft:overworld run fill 379 68 -26 379 144 -26 air
execute in minecraft:overworld run setblock 379 68 -26 grass
execute in minecraft:overworld run fill 379 58 -25 379 64 -25 stone
execute in minecraft:overworld run fill 379 65 -25 379 66 -25 dirt
execute in minecraft:overworld run setblock 379 67 -25 coarse_dirt
execute in minecraft:overworld run fill 379 68 -25 379 144 -25 air
execute in minecraft:overworld run setblock 379 68 -25 grass
execute in minecraft:overworld run fill 379 58 -24 379 64 -24 stone
execute in minecraft:overworld run fill 379 65 -24 379 66 -24 dirt
execute in minecraft:overworld run setblock 379 67 -24 coarse_dirt
execute in minecraft:overworld run fill 379 68 -24 379 144 -24 air
execute in minecraft:overworld run fill 379 58 -23 379 63 -23 stone
execute in minecraft:overworld run fill 379 64 -23 379 65 -23 dirt
execute in minecraft:overworld run setblock 379 66 -23 coarse_dirt
execute in minecraft:overworld run fill 379 67 -23 379 144 -23 air
execute in minecraft:overworld run fill 379 58 -22 379 63 -22 stone
execute in minecraft:overworld run fill 379 64 -22 379 65 -22 dirt
execute in minecraft:overworld run setblock 379 66 -22 coarse_dirt
execute in minecraft:overworld run fill 379 67 -22 379 144 -22 air
execute in minecraft:overworld run fill 379 58 -21 379 63 -21 stone
execute in minecraft:overworld run fill 379 64 -21 379 65 -21 dirt
execute in minecraft:overworld run setblock 379 66 -21 coarse_dirt
execute in minecraft:overworld run fill 379 67 -21 379 144 -21 air
execute in minecraft:overworld run fill 379 58 -20 379 63 -20 stone
execute in minecraft:overworld run fill 379 64 -20 379 65 -20 dirt
execute in minecraft:overworld run setblock 379 66 -20 coarse_dirt
execute in minecraft:overworld run fill 379 67 -20 379 144 -20 air
execute in minecraft:overworld run fill 379 58 -19 379 63 -19 stone
execute in minecraft:overworld run fill 379 64 -19 379 65 -19 dirt
execute in minecraft:overworld run setblock 379 66 -19 grass_block
execute in minecraft:overworld run fill 379 67 -19 379 144 -19 air
execute in minecraft:overworld run fill 379 58 -18 379 62 -18 stone
execute in minecraft:overworld run fill 379 63 -18 379 64 -18 dirt
execute in minecraft:overworld run setblock 379 65 -18 coarse_dirt
execute in minecraft:overworld run fill 379 66 -18 379 144 -18 air
execute in minecraft:overworld run fill 379 58 -17 379 63 -17 stone
execute in minecraft:overworld run fill 379 64 -17 379 65 -17 dirt
execute in minecraft:overworld run setblock 379 66 -17 coarse_dirt
execute in minecraft:overworld run fill 379 67 -17 379 144 -17 air
execute in minecraft:overworld run fill 379 58 -16 379 63 -16 stone
execute in minecraft:overworld run fill 379 64 -16 379 65 -16 dirt
execute in minecraft:overworld run setblock 379 66 -16 grass_block
execute in minecraft:overworld run fill 379 67 -16 379 144 -16 air
execute in minecraft:overworld run fill 379 58 -15 379 63 -15 stone
execute in minecraft:overworld run fill 379 64 -15 379 65 -15 dirt
execute in minecraft:overworld run setblock 379 66 -15 coarse_dirt
execute in minecraft:overworld run fill 379 67 -15 379 144 -15 air
execute in minecraft:overworld run fill 379 58 -14 379 63 -14 stone
execute in minecraft:overworld run fill 379 64 -14 379 65 -14 dirt
execute in minecraft:overworld run setblock 379 66 -14 grass_block
execute in minecraft:overworld run fill 379 67 -14 379 144 -14 air
execute in minecraft:overworld run fill 379 58 -13 379 63 -13 stone
execute in minecraft:overworld run fill 379 64 -13 379 65 -13 dirt
execute in minecraft:overworld run setblock 379 66 -13 coarse_dirt
execute in minecraft:overworld run fill 379 67 -13 379 144 -13 air
execute in minecraft:overworld run fill 379 58 -12 379 63 -12 stone
execute in minecraft:overworld run fill 379 64 -12 379 65 -12 dirt
execute in minecraft:overworld run setblock 379 66 -12 grass_block
execute in minecraft:overworld run fill 379 67 -12 379 144 -12 air
execute in minecraft:overworld run setblock 379 67 -12 mossy_cobblestone
execute in minecraft:overworld run fill 379 58 -11 379 63 -11 stone
execute in minecraft:overworld run fill 379 64 -11 379 65 -11 dirt
execute in minecraft:overworld run setblock 379 66 -11 coarse_dirt
execute in minecraft:overworld run fill 379 67 -11 379 144 -11 air
execute in minecraft:overworld run fill 379 58 -10 379 63 -10 stone
execute in minecraft:overworld run fill 379 64 -10 379 65 -10 dirt
execute in minecraft:overworld run setblock 379 66 -10 coarse_dirt
execute in minecraft:overworld run fill 379 67 -10 379 144 -10 air
execute in minecraft:overworld run fill 379 58 -9 379 64 -9 stone
execute in minecraft:overworld run fill 379 65 -9 379 66 -9 dirt
execute in minecraft:overworld run setblock 379 67 -9 coarse_dirt
execute in minecraft:overworld run fill 379 68 -9 379 144 -9 air
execute in minecraft:overworld run fill 379 58 -8 379 64 -8 stone
execute in minecraft:overworld run fill 379 65 -8 379 66 -8 dirt
execute in minecraft:overworld run setblock 379 67 -8 grass_block
execute in minecraft:overworld run fill 379 68 -8 379 144 -8 air
execute in minecraft:overworld run setblock 379 68 -8 grass
execute in minecraft:overworld run fill 379 58 -7 379 64 -7 stone
execute in minecraft:overworld run fill 379 65 -7 379 66 -7 dirt
execute in minecraft:overworld run setblock 379 67 -7 grass_block
execute in minecraft:overworld run fill 379 68 -7 379 144 -7 air
execute in minecraft:overworld run fill 379 58 -6 379 64 -6 stone
execute in minecraft:overworld run fill 379 65 -6 379 66 -6 dirt
execute in minecraft:overworld run setblock 379 67 -6 grass_block
execute in minecraft:overworld run fill 379 68 -6 379 144 -6 air
execute in minecraft:overworld run fill 379 58 -5 379 64 -5 stone
execute in minecraft:overworld run fill 379 65 -5 379 66 -5 dirt
execute in minecraft:overworld run setblock 379 67 -5 coarse_dirt
execute in minecraft:overworld run fill 379 68 -5 379 144 -5 air
execute in minecraft:overworld run fill 379 58 -4 379 64 -4 stone
execute in minecraft:overworld run fill 379 65 -4 379 66 -4 dirt
execute in minecraft:overworld run setblock 379 67 -4 coarse_dirt
execute in minecraft:overworld run fill 379 68 -4 379 144 -4 air
execute in minecraft:overworld run setblock 379 68 -4 grass
execute in minecraft:overworld run fill 379 58 -3 379 65 -3 stone
execute in minecraft:overworld run fill 379 66 -3 379 67 -3 dirt
execute in minecraft:overworld run setblock 379 68 -3 grass_block
execute in minecraft:overworld run fill 379 69 -3 379 144 -3 air
execute in minecraft:overworld run fill 379 58 -2 379 65 -2 stone
execute in minecraft:overworld run fill 379 66 -2 379 67 -2 dirt
execute in minecraft:overworld run setblock 379 68 -2 grass_block
execute in minecraft:overworld run fill 379 69 -2 379 144 -2 air
execute in minecraft:overworld run fill 379 58 -1 379 65 -1 stone
execute in minecraft:overworld run fill 379 66 -1 379 67 -1 dirt
execute in minecraft:overworld run setblock 379 68 -1 coarse_dirt
execute in minecraft:overworld run fill 379 69 -1 379 144 -1 air
execute in minecraft:overworld run fill 379 58 0 379 65 0 stone
execute in minecraft:overworld run fill 379 66 0 379 67 0 dirt
execute in minecraft:overworld run setblock 379 68 0 grass_block
execute in minecraft:overworld run fill 379 69 0 379 144 0 air
execute in minecraft:overworld run fill 379 58 1 379 65 1 stone
execute in minecraft:overworld run fill 379 66 1 379 67 1 dirt
execute in minecraft:overworld run setblock 379 68 1 coarse_dirt
execute in minecraft:overworld run fill 379 69 1 379 144 1 air
execute in minecraft:overworld run fill 379 58 2 379 65 2 stone
execute in minecraft:overworld run fill 379 66 2 379 67 2 dirt
execute in minecraft:overworld run setblock 379 68 2 grass_block
execute in minecraft:overworld run fill 379 69 2 379 144 2 air
execute in minecraft:overworld run fill 379 58 3 379 65 3 stone
execute in minecraft:overworld run fill 379 66 3 379 67 3 dirt
execute in minecraft:overworld run setblock 379 68 3 coarse_dirt
execute in minecraft:overworld run fill 379 69 3 379 144 3 air
execute in minecraft:overworld run fill 379 58 4 379 65 4 stone
execute in minecraft:overworld run fill 379 66 4 379 67 4 dirt
execute in minecraft:overworld run setblock 379 68 4 coarse_dirt
execute in minecraft:overworld run fill 379 69 4 379 144 4 air
execute in minecraft:overworld run fill 379 58 5 379 65 5 stone
execute in minecraft:overworld run fill 379 66 5 379 67 5 dirt
execute in minecraft:overworld run setblock 379 68 5 grass_block
execute in minecraft:overworld run fill 379 69 5 379 144 5 air
execute in minecraft:overworld run setblock 379 69 5 grass
execute in minecraft:overworld run fill 379 58 6 379 65 6 stone
execute in minecraft:overworld run fill 379 66 6 379 67 6 dirt
execute in minecraft:overworld run setblock 379 68 6 grass_block
execute in minecraft:overworld run fill 379 69 6 379 144 6 air
execute in minecraft:overworld run fill 379 58 7 379 65 7 stone
execute in minecraft:overworld run fill 379 66 7 379 67 7 dirt
execute in minecraft:overworld run setblock 379 68 7 coarse_dirt
execute in minecraft:overworld run fill 379 69 7 379 144 7 air
execute in minecraft:overworld run fill 379 58 8 379 65 8 stone
execute in minecraft:overworld run fill 379 66 8 379 67 8 dirt
execute in minecraft:overworld run setblock 379 68 8 coarse_dirt
execute in minecraft:overworld run fill 379 69 8 379 144 8 air
execute in minecraft:overworld run fill 379 58 9 379 65 9 stone
execute in minecraft:overworld run fill 379 66 9 379 67 9 dirt
execute in minecraft:overworld run setblock 379 68 9 coarse_dirt
execute in minecraft:overworld run fill 379 69 9 379 144 9 air
execute in minecraft:overworld run fill 379 58 10 379 65 10 stone
execute in minecraft:overworld run fill 379 66 10 379 67 10 dirt
execute in minecraft:overworld run setblock 379 68 10 grass_block
execute in minecraft:overworld run fill 379 69 10 379 144 10 air
execute in minecraft:overworld run fill 379 58 11 379 66 11 stone
execute in minecraft:overworld run fill 379 67 11 379 68 11 dirt
execute in minecraft:overworld run setblock 379 69 11 coarse_dirt
execute in minecraft:overworld run fill 379 70 11 379 144 11 air
execute in minecraft:overworld run fill 379 58 12 379 66 12 stone
execute in minecraft:overworld run fill 379 67 12 379 68 12 dirt
execute in minecraft:overworld run setblock 379 69 12 grass_block
execute in minecraft:overworld run fill 379 70 12 379 144 12 air
execute in minecraft:overworld run fill 379 58 13 379 66 13 stone
execute in minecraft:overworld run fill 379 67 13 379 68 13 dirt
execute in minecraft:overworld run setblock 379 69 13 coarse_dirt
execute in minecraft:overworld run fill 379 70 13 379 144 13 air
execute in minecraft:overworld run setblock 379 70 13 mossy_cobblestone
execute in minecraft:overworld run fill 379 58 14 379 67 14 stone
execute in minecraft:overworld run fill 379 68 14 379 69 14 dirt
execute in minecraft:overworld run setblock 379 70 14 coarse_dirt
execute in minecraft:overworld run fill 379 71 14 379 144 14 air
execute in minecraft:overworld run fill 379 58 15 379 67 15 stone
schedule function blade_gallery:random/battlefield/part_67 1t replace
