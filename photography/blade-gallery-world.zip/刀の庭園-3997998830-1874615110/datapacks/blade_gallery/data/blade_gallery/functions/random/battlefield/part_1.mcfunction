execute in minecraft:overworld run setblock 336 64 15 coarse_dirt
execute in minecraft:overworld run fill 336 65 15 336 144 15 air
execute in minecraft:overworld run fill 336 58 16 336 61 16 stone
execute in minecraft:overworld run fill 336 62 16 336 63 16 dirt
execute in minecraft:overworld run setblock 336 64 16 coarse_dirt
execute in minecraft:overworld run fill 336 65 16 336 144 16 air
execute in minecraft:overworld run fill 336 58 17 336 61 17 stone
execute in minecraft:overworld run fill 336 62 17 336 63 17 dirt
execute in minecraft:overworld run setblock 336 64 17 coarse_dirt
execute in minecraft:overworld run fill 336 65 17 336 144 17 air
execute in minecraft:overworld run fill 336 58 18 336 61 18 stone
execute in minecraft:overworld run fill 336 62 18 336 63 18 dirt
execute in minecraft:overworld run setblock 336 64 18 coarse_dirt
execute in minecraft:overworld run fill 336 65 18 336 144 18 air
execute in minecraft:overworld run fill 336 58 19 336 61 19 stone
execute in minecraft:overworld run fill 336 62 19 336 63 19 dirt
execute in minecraft:overworld run setblock 336 64 19 grass_block
execute in minecraft:overworld run fill 336 65 19 336 144 19 air
execute in minecraft:overworld run fill 336 58 20 336 61 20 stone
execute in minecraft:overworld run fill 336 62 20 336 63 20 dirt
execute in minecraft:overworld run setblock 336 64 20 coarse_dirt
execute in minecraft:overworld run fill 336 65 20 336 144 20 air
execute in minecraft:overworld run fill 336 58 21 336 61 21 stone
execute in minecraft:overworld run fill 336 62 21 336 63 21 dirt
execute in minecraft:overworld run setblock 336 64 21 coarse_dirt
execute in minecraft:overworld run fill 336 65 21 336 144 21 air
execute in minecraft:overworld run fill 336 58 22 336 61 22 stone
execute in minecraft:overworld run fill 336 62 22 336 63 22 dirt
execute in minecraft:overworld run setblock 336 64 22 grass_block
execute in minecraft:overworld run fill 336 65 22 336 144 22 air
execute in minecraft:overworld run fill 336 58 23 336 61 23 stone
execute in minecraft:overworld run fill 336 62 23 336 63 23 dirt
execute in minecraft:overworld run setblock 336 64 23 grass_block
execute in minecraft:overworld run fill 336 65 23 336 144 23 air
execute in minecraft:overworld run fill 336 58 24 336 61 24 stone
execute in minecraft:overworld run fill 336 62 24 336 63 24 dirt
execute in minecraft:overworld run setblock 336 64 24 grass_block
execute in minecraft:overworld run fill 336 65 24 336 144 24 air
execute in minecraft:overworld run fill 336 58 25 336 61 25 stone
execute in minecraft:overworld run fill 336 62 25 336 63 25 dirt
execute in minecraft:overworld run setblock 336 64 25 coarse_dirt
execute in minecraft:overworld run fill 336 65 25 336 144 25 air
execute in minecraft:overworld run fill 336 58 26 336 61 26 stone
execute in minecraft:overworld run fill 336 62 26 336 63 26 dirt
execute in minecraft:overworld run setblock 336 64 26 grass_block
execute in minecraft:overworld run fill 336 65 26 336 144 26 air
execute in minecraft:overworld run fill 336 58 27 336 61 27 stone
execute in minecraft:overworld run fill 336 62 27 336 63 27 dirt
execute in minecraft:overworld run setblock 336 64 27 coarse_dirt
execute in minecraft:overworld run fill 336 65 27 336 144 27 air
execute in minecraft:overworld run fill 336 58 28 336 61 28 stone
execute in minecraft:overworld run fill 336 62 28 336 63 28 dirt
execute in minecraft:overworld run setblock 336 64 28 grass_block
execute in minecraft:overworld run fill 336 65 28 336 144 28 air
execute in minecraft:overworld run fill 336 58 29 336 61 29 stone
execute in minecraft:overworld run fill 336 62 29 336 63 29 dirt
execute in minecraft:overworld run setblock 336 64 29 coarse_dirt
execute in minecraft:overworld run fill 336 65 29 336 144 29 air
execute in minecraft:overworld run fill 336 58 30 336 61 30 stone
execute in minecraft:overworld run fill 336 62 30 336 63 30 dirt
execute in minecraft:overworld run setblock 336 64 30 coarse_dirt
execute in minecraft:overworld run fill 336 65 30 336 144 30 air
execute in minecraft:overworld run fill 336 58 31 336 61 31 stone
execute in minecraft:overworld run fill 336 62 31 336 63 31 dirt
execute in minecraft:overworld run setblock 336 64 31 grass_block
execute in minecraft:overworld run fill 336 65 31 336 144 31 air
execute in minecraft:overworld run fill 336 58 32 336 61 32 stone
execute in minecraft:overworld run fill 336 62 32 336 63 32 dirt
execute in minecraft:overworld run setblock 336 64 32 coarse_dirt
execute in minecraft:overworld run fill 336 65 32 336 144 32 air
execute in minecraft:overworld run fill 336 58 33 336 61 33 stone
execute in minecraft:overworld run fill 336 62 33 336 63 33 dirt
execute in minecraft:overworld run setblock 336 64 33 coarse_dirt
execute in minecraft:overworld run fill 336 65 33 336 144 33 air
execute in minecraft:overworld run fill 336 58 34 336 61 34 stone
execute in minecraft:overworld run fill 336 62 34 336 63 34 dirt
execute in minecraft:overworld run setblock 336 64 34 coarse_dirt
execute in minecraft:overworld run fill 336 65 34 336 144 34 air
execute in minecraft:overworld run fill 336 58 35 336 61 35 stone
execute in minecraft:overworld run fill 336 62 35 336 63 35 dirt
execute in minecraft:overworld run setblock 336 64 35 coarse_dirt
execute in minecraft:overworld run fill 336 65 35 336 144 35 air
execute in minecraft:overworld run fill 336 58 36 336 61 36 stone
execute in minecraft:overworld run fill 336 62 36 336 63 36 dirt
execute in minecraft:overworld run setblock 336 64 36 grass_block
execute in minecraft:overworld run fill 336 65 36 336 144 36 air
execute in minecraft:overworld run fill 336 58 37 336 61 37 stone
execute in minecraft:overworld run fill 336 62 37 336 63 37 dirt
execute in minecraft:overworld run setblock 336 64 37 coarse_dirt
execute in minecraft:overworld run fill 336 65 37 336 144 37 air
execute in minecraft:overworld run fill 336 58 38 336 61 38 stone
execute in minecraft:overworld run fill 336 62 38 336 63 38 dirt
execute in minecraft:overworld run setblock 336 64 38 coarse_dirt
execute in minecraft:overworld run fill 336 65 38 336 144 38 air
execute in minecraft:overworld run fill 336 58 39 336 61 39 stone
execute in minecraft:overworld run fill 336 62 39 336 63 39 dirt
execute in minecraft:overworld run setblock 336 64 39 coarse_dirt
execute in minecraft:overworld run fill 336 65 39 336 144 39 air
execute in minecraft:overworld run fill 336 58 40 336 61 40 stone
execute in minecraft:overworld run fill 336 62 40 336 63 40 dirt
execute in minecraft:overworld run setblock 336 64 40 coarse_dirt
execute in minecraft:overworld run fill 336 65 40 336 144 40 air
execute in minecraft:overworld run fill 336 58 41 336 61 41 stone
execute in minecraft:overworld run fill 336 62 41 336 63 41 dirt
execute in minecraft:overworld run setblock 336 64 41 grass_block
execute in minecraft:overworld run fill 336 65 41 336 144 41 air
execute in minecraft:overworld run fill 336 58 42 336 61 42 stone
execute in minecraft:overworld run fill 336 62 42 336 63 42 dirt
execute in minecraft:overworld run setblock 336 64 42 coarse_dirt
execute in minecraft:overworld run fill 336 65 42 336 144 42 air
execute in minecraft:overworld run fill 336 58 43 336 61 43 stone
execute in minecraft:overworld run fill 336 62 43 336 63 43 dirt
execute in minecraft:overworld run setblock 336 64 43 grass_block
execute in minecraft:overworld run fill 336 65 43 336 144 43 air
execute in minecraft:overworld run fill 336 58 44 336 61 44 stone
execute in minecraft:overworld run fill 336 62 44 336 63 44 dirt
execute in minecraft:overworld run setblock 336 64 44 grass_block
execute in minecraft:overworld run fill 336 65 44 336 144 44 air
execute in minecraft:overworld run fill 336 58 45 336 61 45 stone
execute in minecraft:overworld run fill 336 62 45 336 63 45 dirt
execute in minecraft:overworld run setblock 336 64 45 coarse_dirt
execute in minecraft:overworld run fill 336 65 45 336 144 45 air
execute in minecraft:overworld run fill 336 58 46 336 61 46 stone
execute in minecraft:overworld run fill 336 62 46 336 63 46 dirt
execute in minecraft:overworld run setblock 336 64 46 coarse_dirt
execute in minecraft:overworld run fill 336 65 46 336 144 46 air
execute in minecraft:overworld run fill 336 58 47 336 61 47 stone
execute in minecraft:overworld run fill 336 62 47 336 63 47 dirt
execute in minecraft:overworld run setblock 336 64 47 coarse_dirt
execute in minecraft:overworld run fill 336 65 47 336 144 47 air
execute in minecraft:overworld run fill 337 58 -48 337 61 -48 stone
execute in minecraft:overworld run fill 337 62 -48 337 63 -48 dirt
execute in minecraft:overworld run setblock 337 64 -48 grass_block
execute in minecraft:overworld run fill 337 65 -48 337 144 -48 air
execute in minecraft:overworld run fill 337 58 -47 337 63 -47 stone
execute in minecraft:overworld run fill 337 64 -47 337 65 -47 dirt
execute in minecraft:overworld run setblock 337 66 -47 grass_block
execute in minecraft:overworld run fill 337 67 -47 337 144 -47 air
execute in minecraft:overworld run fill 337 58 -46 337 63 -46 stone
execute in minecraft:overworld run fill 337 64 -46 337 65 -46 dirt
execute in minecraft:overworld run setblock 337 66 -46 coarse_dirt
execute in minecraft:overworld run fill 337 67 -46 337 144 -46 air
execute in minecraft:overworld run fill 337 58 -45 337 63 -45 stone
execute in minecraft:overworld run fill 337 64 -45 337 65 -45 dirt
execute in minecraft:overworld run setblock 337 66 -45 grass_block
execute in minecraft:overworld run fill 337 67 -45 337 144 -45 air
execute in minecraft:overworld run fill 337 58 -44 337 63 -44 stone
execute in minecraft:overworld run fill 337 64 -44 337 65 -44 dirt
execute in minecraft:overworld run setblock 337 66 -44 coarse_dirt
execute in minecraft:overworld run fill 337 67 -44 337 144 -44 air
execute in minecraft:overworld run fill 337 58 -43 337 63 -43 stone
execute in minecraft:overworld run fill 337 64 -43 337 65 -43 dirt
execute in minecraft:overworld run setblock 337 66 -43 coarse_dirt
execute in minecraft:overworld run fill 337 67 -43 337 144 -43 air
execute in minecraft:overworld run fill 337 58 -42 337 63 -42 stone
execute in minecraft:overworld run fill 337 64 -42 337 65 -42 dirt
execute in minecraft:overworld run setblock 337 66 -42 coarse_dirt
execute in minecraft:overworld run fill 337 67 -42 337 144 -42 air
execute in minecraft:overworld run fill 337 58 -41 337 63 -41 stone
execute in minecraft:overworld run fill 337 64 -41 337 65 -41 dirt
execute in minecraft:overworld run setblock 337 66 -41 coarse_dirt
execute in minecraft:overworld run fill 337 67 -41 337 144 -41 air
execute in minecraft:overworld run fill 337 58 -40 337 63 -40 stone
execute in minecraft:overworld run fill 337 64 -40 337 65 -40 dirt
execute in minecraft:overworld run setblock 337 66 -40 coarse_dirt
execute in minecraft:overworld run fill 337 67 -40 337 144 -40 air
execute in minecraft:overworld run fill 337 58 -39 337 63 -39 stone
execute in minecraft:overworld run fill 337 64 -39 337 65 -39 dirt
execute in minecraft:overworld run setblock 337 66 -39 grass_block
execute in minecraft:overworld run fill 337 67 -39 337 144 -39 air
execute in minecraft:overworld run fill 337 58 -38 337 63 -38 stone
execute in minecraft:overworld run fill 337 64 -38 337 65 -38 dirt
execute in minecraft:overworld run setblock 337 66 -38 coarse_dirt
execute in minecraft:overworld run fill 337 67 -38 337 144 -38 air
execute in minecraft:overworld run fill 337 58 -37 337 63 -37 stone
execute in minecraft:overworld run fill 337 64 -37 337 65 -37 dirt
execute in minecraft:overworld run setblock 337 66 -37 coarse_dirt
execute in minecraft:overworld run fill 337 67 -37 337 144 -37 air
execute in minecraft:overworld run fill 337 58 -36 337 63 -36 stone
execute in minecraft:overworld run fill 337 64 -36 337 65 -36 dirt
execute in minecraft:overworld run setblock 337 66 -36 coarse_dirt
execute in minecraft:overworld run fill 337 67 -36 337 144 -36 air
execute in minecraft:overworld run fill 337 58 -35 337 62 -35 stone
execute in minecraft:overworld run fill 337 63 -35 337 64 -35 dirt
execute in minecraft:overworld run setblock 337 65 -35 grass_block
execute in minecraft:overworld run fill 337 66 -35 337 144 -35 air
execute in minecraft:overworld run fill 337 58 -34 337 62 -34 stone
execute in minecraft:overworld run fill 337 63 -34 337 64 -34 dirt
execute in minecraft:overworld run setblock 337 65 -34 coarse_dirt
execute in minecraft:overworld run fill 337 66 -34 337 144 -34 air
execute in minecraft:overworld run fill 337 58 -33 337 62 -33 stone
execute in minecraft:overworld run fill 337 63 -33 337 64 -33 dirt
execute in minecraft:overworld run setblock 337 65 -33 grass_block
execute in minecraft:overworld run fill 337 66 -33 337 144 -33 air
execute in minecraft:overworld run fill 337 58 -32 337 62 -32 stone
execute in minecraft:overworld run fill 337 63 -32 337 64 -32 dirt
execute in minecraft:overworld run setblock 337 65 -32 coarse_dirt
execute in minecraft:overworld run fill 337 66 -32 337 144 -32 air
execute in minecraft:overworld run fill 337 58 -31 337 62 -31 stone
execute in minecraft:overworld run fill 337 63 -31 337 64 -31 dirt
execute in minecraft:overworld run setblock 337 65 -31 coarse_dirt
execute in minecraft:overworld run fill 337 66 -31 337 144 -31 air
execute in minecraft:overworld run fill 337 58 -30 337 62 -30 stone
execute in minecraft:overworld run fill 337 63 -30 337 64 -30 dirt
execute in minecraft:overworld run setblock 337 65 -30 coarse_dirt
execute in minecraft:overworld run fill 337 66 -30 337 144 -30 air
execute in minecraft:overworld run fill 337 58 -29 337 62 -29 stone
execute in minecraft:overworld run fill 337 63 -29 337 64 -29 dirt
execute in minecraft:overworld run setblock 337 65 -29 grass_block
execute in minecraft:overworld run fill 337 66 -29 337 144 -29 air
execute in minecraft:overworld run fill 337 58 -28 337 62 -28 stone
execute in minecraft:overworld run fill 337 63 -28 337 64 -28 dirt
execute in minecraft:overworld run setblock 337 65 -28 coarse_dirt
execute in minecraft:overworld run fill 337 66 -28 337 144 -28 air
execute in minecraft:overworld run fill 337 58 -27 337 62 -27 stone
execute in minecraft:overworld run fill 337 63 -27 337 64 -27 dirt
execute in minecraft:overworld run setblock 337 65 -27 coarse_dirt
execute in minecraft:overworld run fill 337 66 -27 337 144 -27 air
execute in minecraft:overworld run fill 337 58 -26 337 62 -26 stone
execute in minecraft:overworld run fill 337 63 -26 337 64 -26 dirt
execute in minecraft:overworld run setblock 337 65 -26 grass_block
execute in minecraft:overworld run fill 337 66 -26 337 144 -26 air
execute in minecraft:overworld run fill 337 58 -25 337 62 -25 stone
execute in minecraft:overworld run fill 337 63 -25 337 64 -25 dirt
execute in minecraft:overworld run setblock 337 65 -25 grass_block
execute in minecraft:overworld run fill 337 66 -25 337 144 -25 air
execute in minecraft:overworld run fill 337 58 -24 337 62 -24 stone
execute in minecraft:overworld run fill 337 63 -24 337 64 -24 dirt
execute in minecraft:overworld run setblock 337 65 -24 grass_block
execute in minecraft:overworld run fill 337 66 -24 337 144 -24 air
execute in minecraft:overworld run fill 337 58 -23 337 62 -23 stone
execute in minecraft:overworld run fill 337 63 -23 337 64 -23 dirt
execute in minecraft:overworld run setblock 337 65 -23 coarse_dirt
execute in minecraft:overworld run fill 337 66 -23 337 144 -23 air
execute in minecraft:overworld run fill 337 58 -22 337 62 -22 stone
execute in minecraft:overworld run fill 337 63 -22 337 64 -22 dirt
execute in minecraft:overworld run setblock 337 65 -22 grass_block
execute in minecraft:overworld run fill 337 66 -22 337 144 -22 air
execute in minecraft:overworld run fill 337 58 -21 337 62 -21 stone
execute in minecraft:overworld run fill 337 63 -21 337 64 -21 dirt
execute in minecraft:overworld run setblock 337 65 -21 coarse_dirt
execute in minecraft:overworld run fill 337 66 -21 337 144 -21 air
execute in minecraft:overworld run fill 337 58 -20 337 62 -20 stone
execute in minecraft:overworld run fill 337 63 -20 337 64 -20 dirt
execute in minecraft:overworld run setblock 337 65 -20 grass_block
execute in minecraft:overworld run fill 337 66 -20 337 144 -20 air
execute in minecraft:overworld run fill 337 58 -19 337 62 -19 stone
execute in minecraft:overworld run fill 337 63 -19 337 64 -19 dirt
execute in minecraft:overworld run setblock 337 65 -19 grass_block
execute in minecraft:overworld run fill 337 66 -19 337 144 -19 air
execute in minecraft:overworld run fill 337 58 -18 337 62 -18 stone
execute in minecraft:overworld run fill 337 63 -18 337 64 -18 dirt
execute in minecraft:overworld run setblock 337 65 -18 grass_block
execute in minecraft:overworld run fill 337 66 -18 337 144 -18 air
execute in minecraft:overworld run fill 337 58 -17 337 62 -17 stone
execute in minecraft:overworld run fill 337 63 -17 337 64 -17 dirt
schedule function blade_gallery:random/battlefield/part_2 1t replace
