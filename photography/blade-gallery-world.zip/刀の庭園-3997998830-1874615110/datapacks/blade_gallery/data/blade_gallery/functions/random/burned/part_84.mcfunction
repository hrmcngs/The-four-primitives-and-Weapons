execute in minecraft:overworld run setblock 261 61 27 gravel
execute in minecraft:overworld run fill 261 62 27 261 144 27 air
execute in minecraft:overworld run fill 261 62 27 261 64 27 water
execute in minecraft:overworld run fill 261 58 28 261 57 28 stone
execute in minecraft:overworld run fill 261 58 28 261 59 28 dirt
execute in minecraft:overworld run setblock 261 60 28 gravel
execute in minecraft:overworld run fill 261 61 28 261 144 28 air
execute in minecraft:overworld run fill 261 61 28 261 64 28 water
execute in minecraft:overworld run fill 261 58 29 261 57 29 stone
execute in minecraft:overworld run fill 261 58 29 261 59 29 dirt
execute in minecraft:overworld run setblock 261 60 29 gravel
execute in minecraft:overworld run fill 261 61 29 261 144 29 air
execute in minecraft:overworld run fill 261 61 29 261 64 29 water
execute in minecraft:overworld run fill 261 58 30 261 57 30 stone
execute in minecraft:overworld run fill 261 58 30 261 59 30 dirt
execute in minecraft:overworld run setblock 261 60 30 gravel
execute in minecraft:overworld run fill 261 61 30 261 144 30 air
execute in minecraft:overworld run fill 261 61 30 261 64 30 water
execute in minecraft:overworld run fill 261 58 31 261 56 31 stone
execute in minecraft:overworld run fill 261 57 31 261 58 31 dirt
execute in minecraft:overworld run setblock 261 59 31 gravel
execute in minecraft:overworld run fill 261 60 31 261 144 31 air
execute in minecraft:overworld run fill 261 60 31 261 64 31 water
execute in minecraft:overworld run fill 261 58 32 261 56 32 stone
execute in minecraft:overworld run fill 261 57 32 261 58 32 dirt
execute in minecraft:overworld run setblock 261 59 32 gravel
execute in minecraft:overworld run fill 261 60 32 261 144 32 air
execute in minecraft:overworld run fill 261 60 32 261 64 32 water
execute in minecraft:overworld run fill 261 58 33 261 56 33 stone
execute in minecraft:overworld run fill 261 57 33 261 58 33 dirt
execute in minecraft:overworld run setblock 261 59 33 gravel
execute in minecraft:overworld run fill 261 60 33 261 144 33 air
execute in minecraft:overworld run fill 261 60 33 261 64 33 water
execute in minecraft:overworld run fill 261 58 34 261 55 34 stone
execute in minecraft:overworld run fill 261 56 34 261 57 34 dirt
execute in minecraft:overworld run setblock 261 58 34 gravel
execute in minecraft:overworld run fill 261 59 34 261 144 34 air
execute in minecraft:overworld run fill 261 59 34 261 64 34 water
execute in minecraft:overworld run fill 261 58 35 261 55 35 stone
execute in minecraft:overworld run fill 261 56 35 261 57 35 dirt
execute in minecraft:overworld run setblock 261 58 35 gravel
execute in minecraft:overworld run fill 261 59 35 261 144 35 air
execute in minecraft:overworld run fill 261 59 35 261 64 35 water
execute in minecraft:overworld run fill 261 58 36 261 55 36 stone
execute in minecraft:overworld run fill 261 56 36 261 57 36 dirt
execute in minecraft:overworld run setblock 261 58 36 gravel
execute in minecraft:overworld run fill 261 59 36 261 144 36 air
execute in minecraft:overworld run fill 261 59 36 261 64 36 water
execute in minecraft:overworld run fill 261 58 37 261 55 37 stone
execute in minecraft:overworld run fill 261 56 37 261 57 37 dirt
execute in minecraft:overworld run setblock 261 58 37 gravel
execute in minecraft:overworld run fill 261 59 37 261 144 37 air
execute in minecraft:overworld run fill 261 59 37 261 64 37 water
execute in minecraft:overworld run fill 261 58 38 261 55 38 stone
execute in minecraft:overworld run fill 261 56 38 261 57 38 dirt
execute in minecraft:overworld run setblock 261 58 38 gravel
execute in minecraft:overworld run fill 261 59 38 261 144 38 air
execute in minecraft:overworld run fill 261 59 38 261 64 38 water
execute in minecraft:overworld run fill 261 58 39 261 55 39 stone
execute in minecraft:overworld run fill 261 56 39 261 57 39 dirt
execute in minecraft:overworld run setblock 261 58 39 gravel
execute in minecraft:overworld run fill 261 59 39 261 144 39 air
execute in minecraft:overworld run fill 261 59 39 261 64 39 water
execute in minecraft:overworld run fill 261 58 40 261 56 40 stone
execute in minecraft:overworld run fill 261 57 40 261 58 40 dirt
execute in minecraft:overworld run setblock 261 59 40 gravel
execute in minecraft:overworld run fill 261 60 40 261 144 40 air
execute in minecraft:overworld run fill 261 60 40 261 64 40 water
execute in minecraft:overworld run fill 261 58 41 261 57 41 stone
execute in minecraft:overworld run fill 261 58 41 261 59 41 dirt
execute in minecraft:overworld run setblock 261 60 41 gravel
execute in minecraft:overworld run fill 261 61 41 261 144 41 air
execute in minecraft:overworld run fill 261 61 41 261 64 41 water
execute in minecraft:overworld run fill 261 58 42 261 58 42 stone
execute in minecraft:overworld run fill 261 59 42 261 60 42 dirt
execute in minecraft:overworld run setblock 261 61 42 gravel
execute in minecraft:overworld run fill 261 62 42 261 144 42 air
execute in minecraft:overworld run fill 261 62 42 261 64 42 water
execute in minecraft:overworld run fill 261 58 43 261 59 43 stone
execute in minecraft:overworld run fill 261 60 43 261 61 43 dirt
execute in minecraft:overworld run setblock 261 62 43 gravel
execute in minecraft:overworld run fill 261 63 43 261 144 43 air
execute in minecraft:overworld run fill 261 63 43 261 64 43 water
execute in minecraft:overworld run fill 261 58 44 261 59 44 stone
execute in minecraft:overworld run fill 261 60 44 261 61 44 dirt
execute in minecraft:overworld run setblock 261 62 44 gravel
execute in minecraft:overworld run fill 261 63 44 261 144 44 air
execute in minecraft:overworld run fill 261 63 44 261 64 44 water
execute in minecraft:overworld run fill 261 58 45 261 60 45 stone
execute in minecraft:overworld run fill 261 61 45 261 62 45 dirt
execute in minecraft:overworld run setblock 261 63 45 gravel
execute in minecraft:overworld run fill 261 64 45 261 144 45 air
execute in minecraft:overworld run fill 261 64 45 261 64 45 water
execute in minecraft:overworld run fill 261 58 46 261 60 46 stone
execute in minecraft:overworld run fill 261 61 46 261 62 46 dirt
execute in minecraft:overworld run setblock 261 63 46 gravel
execute in minecraft:overworld run fill 261 64 46 261 144 46 air
execute in minecraft:overworld run fill 261 64 46 261 64 46 water
execute in minecraft:overworld run fill 261 58 47 261 61 47 stone
execute in minecraft:overworld run fill 261 62 47 261 63 47 dirt
execute in minecraft:overworld run setblock 261 64 47 grass_block
execute in minecraft:overworld run fill 261 65 47 261 144 47 air
execute in minecraft:overworld run fill 262 58 -48 262 61 -48 stone
execute in minecraft:overworld run fill 262 62 -48 262 63 -48 dirt
execute in minecraft:overworld run setblock 262 64 -48 coarse_dirt
execute in minecraft:overworld run fill 262 65 -48 262 144 -48 air
execute in minecraft:overworld run fill 262 58 -47 262 63 -47 stone
execute in minecraft:overworld run fill 262 64 -47 262 65 -47 dirt
execute in minecraft:overworld run setblock 262 66 -47 coarse_dirt
execute in minecraft:overworld run fill 262 67 -47 262 144 -47 air
execute in minecraft:overworld run fill 262 58 -46 262 65 -46 stone
execute in minecraft:overworld run fill 262 66 -46 262 67 -46 dirt
execute in minecraft:overworld run setblock 262 68 -46 grass_block
execute in minecraft:overworld run fill 262 69 -46 262 144 -46 air
execute in minecraft:overworld run fill 262 58 -45 262 66 -45 stone
execute in minecraft:overworld run fill 262 67 -45 262 68 -45 dirt
execute in minecraft:overworld run setblock 262 69 -45 coarse_dirt
execute in minecraft:overworld run fill 262 70 -45 262 144 -45 air
execute in minecraft:overworld run fill 262 58 -44 262 68 -44 stone
execute in minecraft:overworld run fill 262 69 -44 262 70 -44 dirt
execute in minecraft:overworld run setblock 262 71 -44 coarse_dirt
execute in minecraft:overworld run fill 262 72 -44 262 144 -44 air
execute in minecraft:overworld run fill 262 58 -43 262 70 -43 stone
execute in minecraft:overworld run fill 262 71 -43 262 72 -43 dirt
execute in minecraft:overworld run setblock 262 73 -43 grass_block
execute in minecraft:overworld run fill 262 74 -43 262 144 -43 air
execute in minecraft:overworld run fill 262 58 -42 262 71 -42 stone
execute in minecraft:overworld run fill 262 72 -42 262 73 -42 dirt
execute in minecraft:overworld run setblock 262 74 -42 coarse_dirt
execute in minecraft:overworld run fill 262 75 -42 262 144 -42 air
execute in minecraft:overworld run fill 262 58 -41 262 73 -41 stone
execute in minecraft:overworld run fill 262 74 -41 262 75 -41 dirt
execute in minecraft:overworld run setblock 262 76 -41 grass_block
execute in minecraft:overworld run fill 262 77 -41 262 144 -41 air
execute in minecraft:overworld run fill 262 58 -40 262 75 -40 stone
execute in minecraft:overworld run fill 262 76 -40 262 77 -40 dirt
execute in minecraft:overworld run setblock 262 78 -40 coarse_dirt
execute in minecraft:overworld run fill 262 79 -40 262 144 -40 air
execute in minecraft:overworld run fill 262 58 -39 262 76 -39 stone
execute in minecraft:overworld run fill 262 77 -39 262 78 -39 dirt
execute in minecraft:overworld run setblock 262 79 -39 coarse_dirt
execute in minecraft:overworld run fill 262 80 -39 262 144 -39 air
execute in minecraft:overworld run fill 262 58 -38 262 78 -38 stone
execute in minecraft:overworld run fill 262 79 -38 262 80 -38 dirt
execute in minecraft:overworld run setblock 262 81 -38 coarse_dirt
execute in minecraft:overworld run fill 262 82 -38 262 144 -38 air
execute in minecraft:overworld run fill 262 58 -37 262 78 -37 stone
execute in minecraft:overworld run fill 262 79 -37 262 80 -37 dirt
execute in minecraft:overworld run setblock 262 81 -37 coarse_dirt
execute in minecraft:overworld run fill 262 82 -37 262 144 -37 air
execute in minecraft:overworld run fill 262 58 -36 262 77 -36 stone
execute in minecraft:overworld run fill 262 78 -36 262 79 -36 dirt
execute in minecraft:overworld run setblock 262 80 -36 coarse_dirt
execute in minecraft:overworld run fill 262 81 -36 262 144 -36 air
execute in minecraft:overworld run fill 262 58 -35 262 77 -35 stone
execute in minecraft:overworld run fill 262 78 -35 262 79 -35 dirt
execute in minecraft:overworld run setblock 262 80 -35 coarse_dirt
execute in minecraft:overworld run fill 262 81 -35 262 144 -35 air
execute in minecraft:overworld run fill 262 58 -34 262 77 -34 stone
execute in minecraft:overworld run fill 262 78 -34 262 79 -34 dirt
execute in minecraft:overworld run setblock 262 80 -34 grass_block
execute in minecraft:overworld run fill 262 81 -34 262 144 -34 air
execute in minecraft:overworld run fill 262 58 -33 262 77 -33 stone
execute in minecraft:overworld run fill 262 78 -33 262 79 -33 dirt
execute in minecraft:overworld run setblock 262 80 -33 grass_block
execute in minecraft:overworld run fill 262 81 -33 262 144 -33 air
execute in minecraft:overworld run fill 262 58 -32 262 76 -32 stone
execute in minecraft:overworld run fill 262 77 -32 262 78 -32 dirt
execute in minecraft:overworld run setblock 262 79 -32 coarse_dirt
execute in minecraft:overworld run fill 262 80 -32 262 144 -32 air
execute in minecraft:overworld run fill 262 58 -31 262 76 -31 stone
execute in minecraft:overworld run fill 262 77 -31 262 78 -31 dirt
execute in minecraft:overworld run setblock 262 79 -31 coarse_dirt
execute in minecraft:overworld run fill 262 80 -31 262 144 -31 air
execute in minecraft:overworld run fill 262 58 -30 262 76 -30 stone
execute in minecraft:overworld run fill 262 77 -30 262 78 -30 dirt
execute in minecraft:overworld run setblock 262 79 -30 grass_block
execute in minecraft:overworld run fill 262 80 -30 262 144 -30 air
execute in minecraft:overworld run fill 262 58 -29 262 75 -29 stone
execute in minecraft:overworld run fill 262 76 -29 262 77 -29 dirt
execute in minecraft:overworld run setblock 262 78 -29 grass_block
execute in minecraft:overworld run fill 262 79 -29 262 144 -29 air
execute in minecraft:overworld run fill 262 58 -28 262 75 -28 stone
execute in minecraft:overworld run fill 262 76 -28 262 77 -28 dirt
execute in minecraft:overworld run setblock 262 78 -28 coarse_dirt
execute in minecraft:overworld run fill 262 79 -28 262 144 -28 air
execute in minecraft:overworld run fill 262 58 -27 262 74 -27 stone
execute in minecraft:overworld run fill 262 75 -27 262 76 -27 dirt
execute in minecraft:overworld run setblock 262 77 -27 coarse_dirt
execute in minecraft:overworld run fill 262 78 -27 262 144 -27 air
execute in minecraft:overworld run fill 262 58 -26 262 73 -26 stone
execute in minecraft:overworld run fill 262 74 -26 262 75 -26 dirt
execute in minecraft:overworld run setblock 262 76 -26 grass_block
execute in minecraft:overworld run fill 262 77 -26 262 144 -26 air
execute in minecraft:overworld run fill 262 58 -25 262 72 -25 stone
execute in minecraft:overworld run fill 262 73 -25 262 74 -25 dirt
execute in minecraft:overworld run setblock 262 75 -25 coarse_dirt
execute in minecraft:overworld run fill 262 76 -25 262 144 -25 air
execute in minecraft:overworld run fill 262 58 -24 262 71 -24 stone
execute in minecraft:overworld run fill 262 72 -24 262 73 -24 dirt
execute in minecraft:overworld run setblock 262 74 -24 coarse_dirt
execute in minecraft:overworld run fill 262 75 -24 262 144 -24 air
execute in minecraft:overworld run fill 262 58 -23 262 70 -23 stone
execute in minecraft:overworld run fill 262 71 -23 262 72 -23 dirt
execute in minecraft:overworld run setblock 262 73 -23 coarse_dirt
execute in minecraft:overworld run fill 262 74 -23 262 144 -23 air
execute in minecraft:overworld run setblock 262 74 -23 grass
execute in minecraft:overworld run fill 262 58 -22 262 69 -22 stone
execute in minecraft:overworld run fill 262 70 -22 262 71 -22 dirt
execute in minecraft:overworld run setblock 262 72 -22 coarse_dirt
execute in minecraft:overworld run fill 262 73 -22 262 144 -22 air
execute in minecraft:overworld run fill 262 58 -21 262 67 -21 stone
execute in minecraft:overworld run fill 262 68 -21 262 69 -21 dirt
execute in minecraft:overworld run setblock 262 70 -21 coarse_dirt
execute in minecraft:overworld run fill 262 71 -21 262 144 -21 air
execute in minecraft:overworld run fill 262 58 -20 262 66 -20 stone
execute in minecraft:overworld run fill 262 67 -20 262 68 -20 dirt
execute in minecraft:overworld run setblock 262 69 -20 grass_block
execute in minecraft:overworld run fill 262 70 -20 262 144 -20 air
execute in minecraft:overworld run fill 262 58 -19 262 65 -19 stone
execute in minecraft:overworld run fill 262 66 -19 262 67 -19 dirt
execute in minecraft:overworld run setblock 262 68 -19 coarse_dirt
execute in minecraft:overworld run fill 262 69 -19 262 144 -19 air
execute in minecraft:overworld run fill 262 58 -18 262 64 -18 stone
execute in minecraft:overworld run fill 262 65 -18 262 66 -18 dirt
execute in minecraft:overworld run setblock 262 67 -18 grass_block
execute in minecraft:overworld run fill 262 68 -18 262 144 -18 air
execute in minecraft:overworld run setblock 262 68 -18 grass
execute in minecraft:overworld run fill 262 58 -17 262 63 -17 stone
execute in minecraft:overworld run fill 262 64 -17 262 65 -17 dirt
execute in minecraft:overworld run setblock 262 66 -17 coarse_dirt
execute in minecraft:overworld run fill 262 67 -17 262 144 -17 air
execute in minecraft:overworld run setblock 262 67 -17 grass
execute in minecraft:overworld run fill 262 58 -16 262 61 -16 stone
execute in minecraft:overworld run fill 262 62 -16 262 63 -16 dirt
execute in minecraft:overworld run setblock 262 64 -16 grass_block
execute in minecraft:overworld run fill 262 65 -16 262 144 -16 air
execute in minecraft:overworld run fill 262 58 -15 262 60 -15 stone
execute in minecraft:overworld run fill 262 61 -15 262 62 -15 dirt
execute in minecraft:overworld run setblock 262 63 -15 gravel
execute in minecraft:overworld run fill 262 64 -15 262 144 -15 air
execute in minecraft:overworld run fill 262 64 -15 262 64 -15 water
execute in minecraft:overworld run fill 262 58 -14 262 59 -14 stone
execute in minecraft:overworld run fill 262 60 -14 262 61 -14 dirt
execute in minecraft:overworld run setblock 262 62 -14 gravel
execute in minecraft:overworld run fill 262 63 -14 262 144 -14 air
execute in minecraft:overworld run fill 262 63 -14 262 64 -14 water
execute in minecraft:overworld run fill 262 58 -13 262 58 -13 stone
execute in minecraft:overworld run fill 262 59 -13 262 60 -13 dirt
execute in minecraft:overworld run setblock 262 61 -13 gravel
execute in minecraft:overworld run fill 262 62 -13 262 144 -13 air
execute in minecraft:overworld run fill 262 62 -13 262 64 -13 water
execute in minecraft:overworld run fill 262 58 -12 262 57 -12 stone
execute in minecraft:overworld run fill 262 58 -12 262 59 -12 dirt
execute in minecraft:overworld run setblock 262 60 -12 gravel
execute in minecraft:overworld run fill 262 61 -12 262 144 -12 air
schedule function blade_gallery:random/burned/part_85 1t replace
