execute in minecraft:overworld run setblock 364 72 24 coarse_dirt
execute in minecraft:overworld run fill 364 73 24 364 144 24 air
execute in minecraft:overworld run fill 364 58 25 364 69 25 stone
execute in minecraft:overworld run fill 364 70 25 364 71 25 dirt
execute in minecraft:overworld run setblock 364 72 25 coarse_dirt
execute in minecraft:overworld run fill 364 73 25 364 144 25 air
execute in minecraft:overworld run fill 364 58 26 364 69 26 stone
execute in minecraft:overworld run fill 364 70 26 364 71 26 dirt
execute in minecraft:overworld run setblock 364 72 26 coarse_dirt
execute in minecraft:overworld run fill 364 73 26 364 144 26 air
execute in minecraft:overworld run fill 364 58 27 364 69 27 stone
execute in minecraft:overworld run fill 364 70 27 364 71 27 dirt
execute in minecraft:overworld run setblock 364 72 27 coarse_dirt
execute in minecraft:overworld run fill 364 73 27 364 144 27 air
execute in minecraft:overworld run fill 364 58 28 364 69 28 stone
execute in minecraft:overworld run fill 364 70 28 364 71 28 dirt
execute in minecraft:overworld run setblock 364 72 28 grass_block
execute in minecraft:overworld run fill 364 73 28 364 144 28 air
execute in minecraft:overworld run fill 364 58 29 364 69 29 stone
execute in minecraft:overworld run fill 364 70 29 364 71 29 dirt
execute in minecraft:overworld run setblock 364 72 29 coarse_dirt
execute in minecraft:overworld run fill 364 73 29 364 144 29 air
execute in minecraft:overworld run setblock 364 73 29 grass
execute in minecraft:overworld run fill 364 58 30 364 69 30 stone
execute in minecraft:overworld run fill 364 70 30 364 71 30 dirt
execute in minecraft:overworld run setblock 364 72 30 grass_block
execute in minecraft:overworld run fill 364 73 30 364 144 30 air
execute in minecraft:overworld run fill 364 58 31 364 69 31 stone
execute in minecraft:overworld run fill 364 70 31 364 71 31 dirt
execute in minecraft:overworld run setblock 364 72 31 grass_block
execute in minecraft:overworld run fill 364 73 31 364 144 31 air
execute in minecraft:overworld run fill 364 58 32 364 69 32 stone
execute in minecraft:overworld run fill 364 70 32 364 71 32 dirt
execute in minecraft:overworld run setblock 364 72 32 coarse_dirt
execute in minecraft:overworld run fill 364 73 32 364 144 32 air
execute in minecraft:overworld run fill 364 58 33 364 70 33 stone
execute in minecraft:overworld run fill 364 71 33 364 72 33 dirt
execute in minecraft:overworld run setblock 364 73 33 coarse_dirt
execute in minecraft:overworld run fill 364 74 33 364 144 33 air
execute in minecraft:overworld run fill 364 58 34 364 70 34 stone
execute in minecraft:overworld run fill 364 71 34 364 72 34 dirt
execute in minecraft:overworld run setblock 364 73 34 grass_block
execute in minecraft:overworld run fill 364 74 34 364 144 34 air
execute in minecraft:overworld run fill 364 58 35 364 70 35 stone
execute in minecraft:overworld run fill 364 71 35 364 72 35 dirt
execute in minecraft:overworld run setblock 364 73 35 grass_block
execute in minecraft:overworld run fill 364 74 35 364 144 35 air
execute in minecraft:overworld run fill 364 58 36 364 70 36 stone
execute in minecraft:overworld run fill 364 71 36 364 72 36 dirt
execute in minecraft:overworld run setblock 364 73 36 coarse_dirt
execute in minecraft:overworld run fill 364 74 36 364 144 36 air
execute in minecraft:overworld run fill 364 58 37 364 70 37 stone
execute in minecraft:overworld run fill 364 71 37 364 72 37 dirt
execute in minecraft:overworld run setblock 364 73 37 coarse_dirt
execute in minecraft:overworld run fill 364 74 37 364 144 37 air
execute in minecraft:overworld run fill 364 58 38 364 70 38 stone
execute in minecraft:overworld run fill 364 71 38 364 72 38 dirt
execute in minecraft:overworld run setblock 364 73 38 coarse_dirt
execute in minecraft:overworld run fill 364 74 38 364 144 38 air
execute in minecraft:overworld run setblock 364 74 38 mossy_cobblestone
execute in minecraft:overworld run fill 364 58 39 364 69 39 stone
execute in minecraft:overworld run fill 364 70 39 364 71 39 dirt
execute in minecraft:overworld run setblock 364 72 39 grass_block
execute in minecraft:overworld run fill 364 73 39 364 144 39 air
execute in minecraft:overworld run fill 364 58 40 364 68 40 stone
execute in minecraft:overworld run fill 364 69 40 364 70 40 dirt
execute in minecraft:overworld run setblock 364 71 40 coarse_dirt
execute in minecraft:overworld run fill 364 72 40 364 144 40 air
execute in minecraft:overworld run fill 364 58 41 364 67 41 stone
execute in minecraft:overworld run fill 364 68 41 364 69 41 dirt
execute in minecraft:overworld run setblock 364 70 41 coarse_dirt
execute in minecraft:overworld run fill 364 71 41 364 144 41 air
execute in minecraft:overworld run setblock 364 71 41 grass
execute in minecraft:overworld run fill 364 58 42 364 66 42 stone
execute in minecraft:overworld run fill 364 67 42 364 68 42 dirt
execute in minecraft:overworld run setblock 364 69 42 coarse_dirt
execute in minecraft:overworld run fill 364 70 42 364 144 42 air
execute in minecraft:overworld run fill 364 58 43 364 65 43 stone
execute in minecraft:overworld run fill 364 66 43 364 67 43 dirt
execute in minecraft:overworld run setblock 364 68 43 coarse_dirt
execute in minecraft:overworld run fill 364 69 43 364 144 43 air
execute in minecraft:overworld run fill 364 58 44 364 64 44 stone
execute in minecraft:overworld run fill 364 65 44 364 66 44 dirt
execute in minecraft:overworld run setblock 364 67 44 coarse_dirt
execute in minecraft:overworld run fill 364 68 44 364 144 44 air
execute in minecraft:overworld run fill 364 58 45 364 64 45 stone
execute in minecraft:overworld run fill 364 65 45 364 66 45 dirt
execute in minecraft:overworld run setblock 364 67 45 grass_block
execute in minecraft:overworld run fill 364 68 45 364 144 45 air
execute in minecraft:overworld run fill 364 58 46 364 63 46 stone
execute in minecraft:overworld run fill 364 64 46 364 65 46 dirt
execute in minecraft:overworld run setblock 364 66 46 coarse_dirt
execute in minecraft:overworld run fill 364 67 46 364 144 46 air
execute in minecraft:overworld run fill 364 58 47 364 62 47 stone
execute in minecraft:overworld run fill 364 63 47 364 64 47 dirt
execute in minecraft:overworld run setblock 364 65 47 coarse_dirt
execute in minecraft:overworld run fill 364 66 47 364 144 47 air
execute in minecraft:overworld run fill 365 58 -48 365 61 -48 stone
execute in minecraft:overworld run fill 365 62 -48 365 63 -48 dirt
execute in minecraft:overworld run setblock 365 64 -48 coarse_dirt
execute in minecraft:overworld run fill 365 65 -48 365 144 -48 air
execute in minecraft:overworld run fill 365 58 -47 365 63 -47 stone
execute in minecraft:overworld run fill 365 64 -47 365 65 -47 dirt
execute in minecraft:overworld run setblock 365 66 -47 coarse_dirt
execute in minecraft:overworld run fill 365 67 -47 365 144 -47 air
execute in minecraft:overworld run fill 365 58 -46 365 64 -46 stone
execute in minecraft:overworld run fill 365 65 -46 365 66 -46 dirt
execute in minecraft:overworld run setblock 365 67 -46 coarse_dirt
execute in minecraft:overworld run fill 365 68 -46 365 144 -46 air
execute in minecraft:overworld run fill 365 58 -45 365 65 -45 stone
execute in minecraft:overworld run fill 365 66 -45 365 67 -45 dirt
execute in minecraft:overworld run setblock 365 68 -45 coarse_dirt
execute in minecraft:overworld run fill 365 69 -45 365 144 -45 air
execute in minecraft:overworld run fill 365 58 -44 365 67 -44 stone
execute in minecraft:overworld run fill 365 68 -44 365 69 -44 dirt
execute in minecraft:overworld run setblock 365 70 -44 grass_block
execute in minecraft:overworld run fill 365 71 -44 365 144 -44 air
execute in minecraft:overworld run fill 365 58 -43 365 68 -43 stone
execute in minecraft:overworld run fill 365 69 -43 365 70 -43 dirt
execute in minecraft:overworld run setblock 365 71 -43 coarse_dirt
execute in minecraft:overworld run fill 365 72 -43 365 144 -43 air
execute in minecraft:overworld run fill 365 58 -42 365 70 -42 stone
execute in minecraft:overworld run fill 365 71 -42 365 72 -42 dirt
execute in minecraft:overworld run setblock 365 73 -42 grass_block
execute in minecraft:overworld run fill 365 74 -42 365 144 -42 air
execute in minecraft:overworld run fill 365 58 -41 365 71 -41 stone
execute in minecraft:overworld run fill 365 72 -41 365 73 -41 dirt
execute in minecraft:overworld run setblock 365 74 -41 coarse_dirt
execute in minecraft:overworld run fill 365 75 -41 365 144 -41 air
execute in minecraft:overworld run fill 365 58 -40 365 72 -40 stone
execute in minecraft:overworld run fill 365 73 -40 365 74 -40 dirt
execute in minecraft:overworld run setblock 365 75 -40 grass_block
execute in minecraft:overworld run fill 365 76 -40 365 144 -40 air
execute in minecraft:overworld run fill 365 58 -39 365 73 -39 stone
execute in minecraft:overworld run fill 365 74 -39 365 75 -39 dirt
execute in minecraft:overworld run setblock 365 76 -39 coarse_dirt
execute in minecraft:overworld run fill 365 77 -39 365 144 -39 air
execute in minecraft:overworld run fill 365 58 -38 365 74 -38 stone
execute in minecraft:overworld run fill 365 75 -38 365 76 -38 dirt
execute in minecraft:overworld run setblock 365 77 -38 coarse_dirt
execute in minecraft:overworld run fill 365 78 -38 365 144 -38 air
execute in minecraft:overworld run fill 365 58 -37 365 74 -37 stone
execute in minecraft:overworld run fill 365 75 -37 365 76 -37 dirt
execute in minecraft:overworld run setblock 365 77 -37 coarse_dirt
execute in minecraft:overworld run fill 365 78 -37 365 144 -37 air
execute in minecraft:overworld run fill 365 58 -36 365 74 -36 stone
execute in minecraft:overworld run fill 365 75 -36 365 76 -36 dirt
execute in minecraft:overworld run setblock 365 77 -36 grass_block
execute in minecraft:overworld run fill 365 78 -36 365 144 -36 air
execute in minecraft:overworld run fill 365 58 -35 365 74 -35 stone
execute in minecraft:overworld run fill 365 75 -35 365 76 -35 dirt
execute in minecraft:overworld run setblock 365 77 -35 coarse_dirt
execute in minecraft:overworld run fill 365 78 -35 365 144 -35 air
execute in minecraft:overworld run fill 365 58 -34 365 73 -34 stone
execute in minecraft:overworld run fill 365 74 -34 365 75 -34 dirt
execute in minecraft:overworld run setblock 365 76 -34 coarse_dirt
execute in minecraft:overworld run fill 365 77 -34 365 144 -34 air
execute in minecraft:overworld run fill 365 58 -33 365 73 -33 stone
execute in minecraft:overworld run fill 365 74 -33 365 75 -33 dirt
execute in minecraft:overworld run setblock 365 76 -33 grass_block
execute in minecraft:overworld run fill 365 77 -33 365 144 -33 air
execute in minecraft:overworld run fill 365 58 -32 365 73 -32 stone
execute in minecraft:overworld run fill 365 74 -32 365 75 -32 dirt
execute in minecraft:overworld run setblock 365 76 -32 coarse_dirt
execute in minecraft:overworld run fill 365 77 -32 365 144 -32 air
execute in minecraft:overworld run fill 365 58 -31 365 73 -31 stone
execute in minecraft:overworld run fill 365 74 -31 365 75 -31 dirt
execute in minecraft:overworld run setblock 365 76 -31 grass_block
execute in minecraft:overworld run fill 365 77 -31 365 144 -31 air
execute in minecraft:overworld run fill 365 58 -30 365 73 -30 stone
execute in minecraft:overworld run fill 365 74 -30 365 75 -30 dirt
execute in minecraft:overworld run setblock 365 76 -30 coarse_dirt
execute in minecraft:overworld run fill 365 77 -30 365 144 -30 air
execute in minecraft:overworld run fill 365 58 -29 365 72 -29 stone
execute in minecraft:overworld run fill 365 73 -29 365 74 -29 dirt
execute in minecraft:overworld run setblock 365 75 -29 coarse_dirt
execute in minecraft:overworld run fill 365 76 -29 365 144 -29 air
execute in minecraft:overworld run fill 365 58 -28 365 72 -28 stone
execute in minecraft:overworld run fill 365 73 -28 365 74 -28 dirt
execute in minecraft:overworld run setblock 365 75 -28 coarse_dirt
execute in minecraft:overworld run fill 365 76 -28 365 144 -28 air
execute in minecraft:overworld run fill 365 58 -27 365 72 -27 stone
execute in minecraft:overworld run fill 365 73 -27 365 74 -27 dirt
execute in minecraft:overworld run setblock 365 75 -27 coarse_dirt
execute in minecraft:overworld run fill 365 76 -27 365 144 -27 air
execute in minecraft:overworld run fill 365 58 -26 365 72 -26 stone
execute in minecraft:overworld run fill 365 73 -26 365 74 -26 dirt
execute in minecraft:overworld run setblock 365 75 -26 grass_block
execute in minecraft:overworld run fill 365 76 -26 365 144 -26 air
execute in minecraft:overworld run fill 365 58 -25 365 71 -25 stone
execute in minecraft:overworld run fill 365 72 -25 365 73 -25 dirt
execute in minecraft:overworld run setblock 365 74 -25 coarse_dirt
execute in minecraft:overworld run fill 365 75 -25 365 144 -25 air
execute in minecraft:overworld run fill 365 58 -24 365 71 -24 stone
execute in minecraft:overworld run fill 365 72 -24 365 73 -24 dirt
execute in minecraft:overworld run setblock 365 74 -24 coarse_dirt
execute in minecraft:overworld run fill 365 75 -24 365 144 -24 air
execute in minecraft:overworld run fill 365 58 -23 365 71 -23 stone
execute in minecraft:overworld run fill 365 72 -23 365 73 -23 dirt
execute in minecraft:overworld run setblock 365 74 -23 coarse_dirt
execute in minecraft:overworld run fill 365 75 -23 365 144 -23 air
execute in minecraft:overworld run fill 365 58 -22 365 70 -22 stone
execute in minecraft:overworld run fill 365 71 -22 365 72 -22 dirt
execute in minecraft:overworld run setblock 365 73 -22 grass_block
execute in minecraft:overworld run fill 365 74 -22 365 144 -22 air
execute in minecraft:overworld run fill 365 58 -21 365 70 -21 stone
execute in minecraft:overworld run fill 365 71 -21 365 72 -21 dirt
execute in minecraft:overworld run setblock 365 73 -21 coarse_dirt
execute in minecraft:overworld run fill 365 74 -21 365 144 -21 air
execute in minecraft:overworld run fill 365 58 -20 365 69 -20 stone
execute in minecraft:overworld run fill 365 70 -20 365 71 -20 dirt
execute in minecraft:overworld run setblock 365 72 -20 coarse_dirt
execute in minecraft:overworld run fill 365 73 -20 365 144 -20 air
execute in minecraft:overworld run fill 365 58 -19 365 69 -19 stone
execute in minecraft:overworld run fill 365 70 -19 365 71 -19 dirt
execute in minecraft:overworld run setblock 365 72 -19 coarse_dirt
execute in minecraft:overworld run fill 365 73 -19 365 144 -19 air
execute in minecraft:overworld run setblock 365 73 -19 mossy_cobblestone
execute in minecraft:overworld run fill 365 58 -18 365 69 -18 stone
execute in minecraft:overworld run fill 365 70 -18 365 71 -18 dirt
execute in minecraft:overworld run setblock 365 72 -18 grass_block
execute in minecraft:overworld run fill 365 73 -18 365 144 -18 air
execute in minecraft:overworld run fill 365 58 -17 365 68 -17 stone
execute in minecraft:overworld run fill 365 69 -17 365 70 -17 dirt
execute in minecraft:overworld run setblock 365 71 -17 grass_block
execute in minecraft:overworld run fill 365 72 -17 365 144 -17 air
execute in minecraft:overworld run fill 365 58 -16 365 68 -16 stone
execute in minecraft:overworld run fill 365 69 -16 365 70 -16 dirt
execute in minecraft:overworld run setblock 365 71 -16 grass_block
execute in minecraft:overworld run fill 365 72 -16 365 144 -16 air
execute in minecraft:overworld run fill 365 58 -15 365 67 -15 stone
execute in minecraft:overworld run fill 365 68 -15 365 69 -15 dirt
execute in minecraft:overworld run setblock 365 70 -15 grass_block
execute in minecraft:overworld run fill 365 71 -15 365 144 -15 air
execute in minecraft:overworld run fill 365 58 -14 365 67 -14 stone
execute in minecraft:overworld run fill 365 68 -14 365 69 -14 dirt
execute in minecraft:overworld run setblock 365 70 -14 coarse_dirt
execute in minecraft:overworld run fill 365 71 -14 365 144 -14 air
execute in minecraft:overworld run fill 365 58 -13 365 66 -13 stone
execute in minecraft:overworld run fill 365 67 -13 365 68 -13 dirt
execute in minecraft:overworld run setblock 365 69 -13 coarse_dirt
execute in minecraft:overworld run fill 365 70 -13 365 144 -13 air
execute in minecraft:overworld run fill 365 58 -12 365 66 -12 stone
execute in minecraft:overworld run fill 365 67 -12 365 68 -12 dirt
execute in minecraft:overworld run setblock 365 69 -12 coarse_dirt
execute in minecraft:overworld run fill 365 70 -12 365 144 -12 air
execute in minecraft:overworld run fill 365 58 -11 365 66 -11 stone
execute in minecraft:overworld run fill 365 67 -11 365 68 -11 dirt
execute in minecraft:overworld run setblock 365 69 -11 grass_block
execute in minecraft:overworld run fill 365 70 -11 365 144 -11 air
execute in minecraft:overworld run fill 365 58 -10 365 66 -10 stone
execute in minecraft:overworld run fill 365 67 -10 365 68 -10 dirt
execute in minecraft:overworld run setblock 365 69 -10 grass_block
execute in minecraft:overworld run fill 365 70 -10 365 144 -10 air
execute in minecraft:overworld run fill 365 58 -9 365 66 -9 stone
execute in minecraft:overworld run fill 365 67 -9 365 68 -9 dirt
schedule function blade_gallery:random/battlefield/part_45 1t replace
