execute in minecraft:overworld run fill 360 58 -28 360 73 -28 stone
execute in minecraft:overworld run fill 360 74 -28 360 75 -28 dirt
execute in minecraft:overworld run setblock 360 76 -28 grass_block
execute in minecraft:overworld run fill 360 77 -28 360 144 -28 air
execute in minecraft:overworld run fill 360 58 -27 360 73 -27 stone
execute in minecraft:overworld run fill 360 74 -27 360 75 -27 dirt
execute in minecraft:overworld run setblock 360 76 -27 coarse_dirt
execute in minecraft:overworld run fill 360 77 -27 360 144 -27 air
execute in minecraft:overworld run fill 360 58 -26 360 73 -26 stone
execute in minecraft:overworld run fill 360 74 -26 360 75 -26 dirt
execute in minecraft:overworld run setblock 360 76 -26 coarse_dirt
execute in minecraft:overworld run fill 360 77 -26 360 144 -26 air
execute in minecraft:overworld run setblock 360 77 -26 mossy_cobblestone
execute in minecraft:overworld run fill 360 58 -25 360 72 -25 stone
execute in minecraft:overworld run fill 360 73 -25 360 74 -25 dirt
execute in minecraft:overworld run setblock 360 75 -25 coarse_dirt
execute in minecraft:overworld run fill 360 76 -25 360 144 -25 air
execute in minecraft:overworld run fill 360 58 -24 360 72 -24 stone
execute in minecraft:overworld run fill 360 73 -24 360 74 -24 dirt
execute in minecraft:overworld run setblock 360 75 -24 coarse_dirt
execute in minecraft:overworld run fill 360 76 -24 360 144 -24 air
execute in minecraft:overworld run fill 360 58 -23 360 72 -23 stone
execute in minecraft:overworld run fill 360 73 -23 360 74 -23 dirt
execute in minecraft:overworld run setblock 360 75 -23 grass_block
execute in minecraft:overworld run fill 360 76 -23 360 144 -23 air
execute in minecraft:overworld run fill 360 58 -22 360 72 -22 stone
execute in minecraft:overworld run fill 360 73 -22 360 74 -22 dirt
execute in minecraft:overworld run setblock 360 75 -22 coarse_dirt
execute in minecraft:overworld run fill 360 76 -22 360 144 -22 air
execute in minecraft:overworld run fill 360 58 -21 360 71 -21 stone
execute in minecraft:overworld run fill 360 72 -21 360 73 -21 dirt
execute in minecraft:overworld run setblock 360 74 -21 grass_block
execute in minecraft:overworld run fill 360 75 -21 360 144 -21 air
execute in minecraft:overworld run fill 360 58 -20 360 71 -20 stone
execute in minecraft:overworld run fill 360 72 -20 360 73 -20 dirt
execute in minecraft:overworld run setblock 360 74 -20 grass_block
execute in minecraft:overworld run fill 360 75 -20 360 144 -20 air
execute in minecraft:overworld run fill 360 58 -19 360 71 -19 stone
execute in minecraft:overworld run fill 360 72 -19 360 73 -19 dirt
execute in minecraft:overworld run setblock 360 74 -19 coarse_dirt
execute in minecraft:overworld run fill 360 75 -19 360 144 -19 air
execute in minecraft:overworld run fill 360 58 -18 360 70 -18 stone
execute in minecraft:overworld run fill 360 71 -18 360 72 -18 dirt
execute in minecraft:overworld run setblock 360 73 -18 grass_block
execute in minecraft:overworld run fill 360 74 -18 360 144 -18 air
execute in minecraft:overworld run fill 360 58 -17 360 70 -17 stone
execute in minecraft:overworld run fill 360 71 -17 360 72 -17 dirt
execute in minecraft:overworld run setblock 360 73 -17 coarse_dirt
execute in minecraft:overworld run fill 360 74 -17 360 144 -17 air
execute in minecraft:overworld run fill 360 58 -16 360 69 -16 stone
execute in minecraft:overworld run fill 360 70 -16 360 71 -16 dirt
execute in minecraft:overworld run setblock 360 72 -16 coarse_dirt
execute in minecraft:overworld run fill 360 73 -16 360 144 -16 air
execute in minecraft:overworld run fill 360 58 -15 360 68 -15 stone
execute in minecraft:overworld run fill 360 69 -15 360 70 -15 dirt
execute in minecraft:overworld run setblock 360 71 -15 grass_block
execute in minecraft:overworld run fill 360 72 -15 360 144 -15 air
execute in minecraft:overworld run fill 360 58 -14 360 68 -14 stone
execute in minecraft:overworld run fill 360 69 -14 360 70 -14 dirt
execute in minecraft:overworld run setblock 360 71 -14 coarse_dirt
execute in minecraft:overworld run fill 360 72 -14 360 144 -14 air
execute in minecraft:overworld run fill 360 58 -13 360 67 -13 stone
execute in minecraft:overworld run fill 360 68 -13 360 69 -13 dirt
execute in minecraft:overworld run setblock 360 70 -13 grass_block
execute in minecraft:overworld run fill 360 71 -13 360 144 -13 air
execute in minecraft:overworld run fill 360 58 -12 360 66 -12 stone
execute in minecraft:overworld run fill 360 67 -12 360 68 -12 dirt
execute in minecraft:overworld run setblock 360 69 -12 grass_block
execute in minecraft:overworld run fill 360 70 -12 360 144 -12 air
execute in minecraft:overworld run setblock 360 70 -12 grass
execute in minecraft:overworld run fill 360 58 -11 360 66 -11 stone
execute in minecraft:overworld run fill 360 67 -11 360 68 -11 dirt
execute in minecraft:overworld run setblock 360 69 -11 coarse_dirt
execute in minecraft:overworld run fill 360 70 -11 360 144 -11 air
execute in minecraft:overworld run fill 360 58 -10 360 65 -10 stone
execute in minecraft:overworld run fill 360 66 -10 360 67 -10 dirt
execute in minecraft:overworld run setblock 360 68 -10 coarse_dirt
execute in minecraft:overworld run fill 360 69 -10 360 144 -10 air
execute in minecraft:overworld run fill 360 58 -9 360 65 -9 stone
execute in minecraft:overworld run fill 360 66 -9 360 67 -9 dirt
execute in minecraft:overworld run setblock 360 68 -9 coarse_dirt
execute in minecraft:overworld run fill 360 69 -9 360 144 -9 air
execute in minecraft:overworld run setblock 360 69 -9 grass
execute in minecraft:overworld run fill 360 58 -8 360 65 -8 stone
execute in minecraft:overworld run fill 360 66 -8 360 67 -8 dirt
execute in minecraft:overworld run setblock 360 68 -8 grass_block
execute in minecraft:overworld run fill 360 69 -8 360 144 -8 air
execute in minecraft:overworld run fill 360 58 -7 360 65 -7 stone
execute in minecraft:overworld run fill 360 66 -7 360 67 -7 dirt
execute in minecraft:overworld run setblock 360 68 -7 grass_block
execute in minecraft:overworld run fill 360 69 -7 360 144 -7 air
execute in minecraft:overworld run fill 360 58 -6 360 65 -6 stone
execute in minecraft:overworld run fill 360 66 -6 360 67 -6 dirt
execute in minecraft:overworld run setblock 360 68 -6 coarse_dirt
execute in minecraft:overworld run fill 360 69 -6 360 144 -6 air
execute in minecraft:overworld run fill 360 58 -5 360 65 -5 stone
execute in minecraft:overworld run fill 360 66 -5 360 67 -5 dirt
execute in minecraft:overworld run setblock 360 68 -5 coarse_dirt
execute in minecraft:overworld run fill 360 69 -5 360 144 -5 air
execute in minecraft:overworld run fill 360 58 -4 360 65 -4 stone
execute in minecraft:overworld run fill 360 66 -4 360 67 -4 dirt
execute in minecraft:overworld run setblock 360 68 -4 grass_block
execute in minecraft:overworld run fill 360 69 -4 360 144 -4 air
execute in minecraft:overworld run fill 360 58 -3 360 65 -3 stone
execute in minecraft:overworld run fill 360 66 -3 360 67 -3 dirt
execute in minecraft:overworld run setblock 360 68 -3 coarse_dirt
execute in minecraft:overworld run fill 360 69 -3 360 144 -3 air
execute in minecraft:overworld run fill 360 58 -2 360 65 -2 stone
execute in minecraft:overworld run fill 360 66 -2 360 67 -2 dirt
execute in minecraft:overworld run setblock 360 68 -2 coarse_dirt
execute in minecraft:overworld run fill 360 69 -2 360 144 -2 air
execute in minecraft:overworld run fill 360 58 -1 360 65 -1 stone
execute in minecraft:overworld run fill 360 66 -1 360 67 -1 dirt
execute in minecraft:overworld run setblock 360 68 -1 coarse_dirt
execute in minecraft:overworld run fill 360 69 -1 360 144 -1 air
execute in minecraft:overworld run setblock 360 69 -1 grass
execute in minecraft:overworld run fill 360 58 0 360 65 0 stone
execute in minecraft:overworld run fill 360 66 0 360 67 0 dirt
execute in minecraft:overworld run setblock 360 68 0 grass_block
execute in minecraft:overworld run fill 360 69 0 360 144 0 air
execute in minecraft:overworld run fill 360 58 1 360 65 1 stone
execute in minecraft:overworld run fill 360 66 1 360 67 1 dirt
execute in minecraft:overworld run setblock 360 68 1 coarse_dirt
execute in minecraft:overworld run fill 360 69 1 360 144 1 air
execute in minecraft:overworld run fill 360 58 2 360 65 2 stone
execute in minecraft:overworld run fill 360 66 2 360 67 2 dirt
execute in minecraft:overworld run setblock 360 68 2 grass_block
execute in minecraft:overworld run fill 360 69 2 360 144 2 air
execute in minecraft:overworld run fill 360 58 3 360 66 3 stone
execute in minecraft:overworld run fill 360 67 3 360 68 3 dirt
execute in minecraft:overworld run setblock 360 69 3 grass_block
execute in minecraft:overworld run fill 360 70 3 360 144 3 air
execute in minecraft:overworld run fill 360 58 4 360 66 4 stone
execute in minecraft:overworld run fill 360 67 4 360 68 4 dirt
execute in minecraft:overworld run setblock 360 69 4 coarse_dirt
execute in minecraft:overworld run fill 360 70 4 360 144 4 air
execute in minecraft:overworld run fill 360 58 5 360 67 5 stone
execute in minecraft:overworld run fill 360 68 5 360 69 5 dirt
execute in minecraft:overworld run setblock 360 70 5 grass_block
execute in minecraft:overworld run fill 360 71 5 360 144 5 air
execute in minecraft:overworld run fill 360 58 6 360 67 6 stone
execute in minecraft:overworld run fill 360 68 6 360 69 6 dirt
execute in minecraft:overworld run setblock 360 70 6 grass_block
execute in minecraft:overworld run fill 360 71 6 360 144 6 air
execute in minecraft:overworld run setblock 360 71 6 grass
execute in minecraft:overworld run fill 360 58 7 360 67 7 stone
execute in minecraft:overworld run fill 360 68 7 360 69 7 dirt
execute in minecraft:overworld run setblock 360 70 7 coarse_dirt
execute in minecraft:overworld run fill 360 71 7 360 144 7 air
execute in minecraft:overworld run fill 360 58 8 360 68 8 stone
execute in minecraft:overworld run fill 360 69 8 360 70 8 dirt
execute in minecraft:overworld run setblock 360 71 8 grass_block
execute in minecraft:overworld run fill 360 72 8 360 144 8 air
execute in minecraft:overworld run fill 360 58 9 360 68 9 stone
execute in minecraft:overworld run fill 360 69 9 360 70 9 dirt
execute in minecraft:overworld run setblock 360 71 9 grass_block
execute in minecraft:overworld run fill 360 72 9 360 144 9 air
execute in minecraft:overworld run fill 360 58 10 360 68 10 stone
execute in minecraft:overworld run fill 360 69 10 360 70 10 dirt
execute in minecraft:overworld run setblock 360 71 10 grass_block
execute in minecraft:overworld run fill 360 72 10 360 144 10 air
execute in minecraft:overworld run fill 360 58 11 360 68 11 stone
execute in minecraft:overworld run fill 360 69 11 360 70 11 dirt
execute in minecraft:overworld run setblock 360 71 11 grass_block
execute in minecraft:overworld run fill 360 72 11 360 144 11 air
execute in minecraft:overworld run fill 360 58 12 360 68 12 stone
execute in minecraft:overworld run fill 360 69 12 360 70 12 dirt
execute in minecraft:overworld run setblock 360 71 12 coarse_dirt
execute in minecraft:overworld run fill 360 72 12 360 144 12 air
execute in minecraft:overworld run setblock 360 72 12 grass
execute in minecraft:overworld run fill 360 58 13 360 69 13 stone
execute in minecraft:overworld run fill 360 70 13 360 71 13 dirt
execute in minecraft:overworld run setblock 360 72 13 coarse_dirt
execute in minecraft:overworld run fill 360 73 13 360 144 13 air
execute in minecraft:overworld run fill 360 58 14 360 69 14 stone
execute in minecraft:overworld run fill 360 70 14 360 71 14 dirt
execute in minecraft:overworld run setblock 360 72 14 coarse_dirt
execute in minecraft:overworld run fill 360 73 14 360 144 14 air
execute in minecraft:overworld run fill 360 58 15 360 69 15 stone
execute in minecraft:overworld run fill 360 70 15 360 71 15 dirt
execute in minecraft:overworld run setblock 360 72 15 coarse_dirt
execute in minecraft:overworld run fill 360 73 15 360 144 15 air
execute in minecraft:overworld run fill 360 58 16 360 69 16 stone
execute in minecraft:overworld run fill 360 70 16 360 71 16 dirt
execute in minecraft:overworld run setblock 360 72 16 coarse_dirt
execute in minecraft:overworld run fill 360 73 16 360 144 16 air
execute in minecraft:overworld run fill 360 58 17 360 69 17 stone
execute in minecraft:overworld run fill 360 70 17 360 71 17 dirt
execute in minecraft:overworld run setblock 360 72 17 coarse_dirt
execute in minecraft:overworld run fill 360 73 17 360 144 17 air
execute in minecraft:overworld run fill 360 58 18 360 69 18 stone
execute in minecraft:overworld run fill 360 70 18 360 71 18 dirt
execute in minecraft:overworld run setblock 360 72 18 coarse_dirt
execute in minecraft:overworld run fill 360 73 18 360 144 18 air
execute in minecraft:overworld run fill 360 58 19 360 69 19 stone
execute in minecraft:overworld run fill 360 70 19 360 71 19 dirt
execute in minecraft:overworld run setblock 360 72 19 coarse_dirt
execute in minecraft:overworld run fill 360 73 19 360 144 19 air
execute in minecraft:overworld run fill 360 58 20 360 69 20 stone
execute in minecraft:overworld run fill 360 70 20 360 71 20 dirt
execute in minecraft:overworld run setblock 360 72 20 grass_block
execute in minecraft:overworld run fill 360 73 20 360 144 20 air
execute in minecraft:overworld run fill 360 58 21 360 69 21 stone
execute in minecraft:overworld run fill 360 70 21 360 71 21 dirt
execute in minecraft:overworld run setblock 360 72 21 coarse_dirt
execute in minecraft:overworld run fill 360 73 21 360 144 21 air
execute in minecraft:overworld run setblock 360 73 21 grass
execute in minecraft:overworld run fill 360 58 22 360 69 22 stone
execute in minecraft:overworld run fill 360 70 22 360 71 22 dirt
execute in minecraft:overworld run setblock 360 72 22 grass_block
execute in minecraft:overworld run fill 360 73 22 360 144 22 air
execute in minecraft:overworld run fill 360 58 23 360 69 23 stone
execute in minecraft:overworld run fill 360 70 23 360 71 23 dirt
execute in minecraft:overworld run setblock 360 72 23 coarse_dirt
execute in minecraft:overworld run fill 360 73 23 360 144 23 air
execute in minecraft:overworld run fill 360 58 24 360 69 24 stone
execute in minecraft:overworld run fill 360 70 24 360 71 24 dirt
execute in minecraft:overworld run setblock 360 72 24 coarse_dirt
execute in minecraft:overworld run fill 360 73 24 360 144 24 air
execute in minecraft:overworld run fill 360 58 25 360 69 25 stone
execute in minecraft:overworld run fill 360 70 25 360 71 25 dirt
execute in minecraft:overworld run setblock 360 72 25 grass_block
execute in minecraft:overworld run fill 360 73 25 360 144 25 air
execute in minecraft:overworld run fill 360 58 26 360 68 26 stone
execute in minecraft:overworld run fill 360 69 26 360 70 26 dirt
execute in minecraft:overworld run setblock 360 71 26 coarse_dirt
execute in minecraft:overworld run fill 360 72 26 360 144 26 air
execute in minecraft:overworld run fill 360 58 27 360 68 27 stone
execute in minecraft:overworld run fill 360 69 27 360 70 27 dirt
execute in minecraft:overworld run setblock 360 71 27 coarse_dirt
execute in minecraft:overworld run fill 360 72 27 360 144 27 air
execute in minecraft:overworld run fill 360 58 28 360 68 28 stone
execute in minecraft:overworld run fill 360 69 28 360 70 28 dirt
execute in minecraft:overworld run setblock 360 71 28 coarse_dirt
execute in minecraft:overworld run fill 360 72 28 360 144 28 air
execute in minecraft:overworld run fill 360 58 29 360 69 29 stone
execute in minecraft:overworld run fill 360 70 29 360 71 29 dirt
execute in minecraft:overworld run setblock 360 72 29 coarse_dirt
execute in minecraft:overworld run fill 360 73 29 360 144 29 air
execute in minecraft:overworld run fill 360 58 30 360 69 30 stone
execute in minecraft:overworld run fill 360 70 30 360 71 30 dirt
execute in minecraft:overworld run setblock 360 72 30 grass_block
execute in minecraft:overworld run fill 360 73 30 360 144 30 air
execute in minecraft:overworld run fill 360 58 31 360 69 31 stone
execute in minecraft:overworld run fill 360 70 31 360 71 31 dirt
execute in minecraft:overworld run setblock 360 72 31 coarse_dirt
execute in minecraft:overworld run fill 360 73 31 360 144 31 air
execute in minecraft:overworld run fill 360 58 32 360 69 32 stone
execute in minecraft:overworld run fill 360 70 32 360 71 32 dirt
execute in minecraft:overworld run setblock 360 72 32 grass_block
execute in minecraft:overworld run fill 360 73 32 360 144 32 air
execute in minecraft:overworld run setblock 360 73 32 grass
execute in minecraft:overworld run fill 360 58 33 360 69 33 stone
execute in minecraft:overworld run fill 360 70 33 360 71 33 dirt
execute in minecraft:overworld run setblock 360 72 33 coarse_dirt
execute in minecraft:overworld run fill 360 73 33 360 144 33 air
schedule function blade_gallery:random/battlefield/part_38 1t replace
