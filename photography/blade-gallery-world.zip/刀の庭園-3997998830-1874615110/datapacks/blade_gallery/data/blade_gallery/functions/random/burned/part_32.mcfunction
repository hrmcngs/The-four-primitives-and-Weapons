execute in minecraft:overworld run setblock 228 71 39 grass
execute in minecraft:overworld run fill 228 58 40 228 66 40 stone
execute in minecraft:overworld run fill 228 67 40 228 68 40 dirt
execute in minecraft:overworld run setblock 228 69 40 coarse_dirt
execute in minecraft:overworld run fill 228 70 40 228 144 40 air
execute in minecraft:overworld run fill 228 58 41 228 65 41 stone
execute in minecraft:overworld run fill 228 66 41 228 67 41 dirt
execute in minecraft:overworld run setblock 228 68 41 grass_block
execute in minecraft:overworld run fill 228 69 41 228 144 41 air
execute in minecraft:overworld run fill 228 58 42 228 64 42 stone
execute in minecraft:overworld run fill 228 65 42 228 66 42 dirt
execute in minecraft:overworld run setblock 228 67 42 coarse_dirt
execute in minecraft:overworld run fill 228 68 42 228 144 42 air
execute in minecraft:overworld run fill 228 58 43 228 63 43 stone
execute in minecraft:overworld run fill 228 64 43 228 65 43 dirt
execute in minecraft:overworld run setblock 228 66 43 coarse_dirt
execute in minecraft:overworld run fill 228 67 43 228 144 43 air
execute in minecraft:overworld run fill 228 58 44 228 62 44 stone
execute in minecraft:overworld run fill 228 63 44 228 64 44 dirt
execute in minecraft:overworld run setblock 228 65 44 coarse_dirt
execute in minecraft:overworld run fill 228 66 44 228 144 44 air
execute in minecraft:overworld run fill 228 58 45 228 62 45 stone
execute in minecraft:overworld run fill 228 63 45 228 64 45 dirt
execute in minecraft:overworld run setblock 228 65 45 grass_block
execute in minecraft:overworld run fill 228 66 45 228 144 45 air
execute in minecraft:overworld run fill 228 58 46 228 62 46 stone
execute in minecraft:overworld run fill 228 63 46 228 64 46 dirt
execute in minecraft:overworld run setblock 228 65 46 coarse_dirt
execute in minecraft:overworld run fill 228 66 46 228 144 46 air
execute in minecraft:overworld run fill 228 58 47 228 61 47 stone
execute in minecraft:overworld run fill 228 62 47 228 63 47 dirt
execute in minecraft:overworld run setblock 228 64 47 coarse_dirt
execute in minecraft:overworld run fill 228 65 47 228 144 47 air
execute in minecraft:overworld run fill 229 58 -48 229 61 -48 stone
execute in minecraft:overworld run fill 229 62 -48 229 63 -48 dirt
execute in minecraft:overworld run setblock 229 64 -48 coarse_dirt
execute in minecraft:overworld run fill 229 65 -48 229 144 -48 air
execute in minecraft:overworld run fill 229 58 -47 229 63 -47 stone
execute in minecraft:overworld run fill 229 64 -47 229 65 -47 dirt
execute in minecraft:overworld run setblock 229 66 -47 grass_block
execute in minecraft:overworld run fill 229 67 -47 229 144 -47 air
execute in minecraft:overworld run fill 229 58 -46 229 64 -46 stone
execute in minecraft:overworld run fill 229 65 -46 229 66 -46 dirt
execute in minecraft:overworld run setblock 229 67 -46 grass_block
execute in minecraft:overworld run fill 229 68 -46 229 144 -46 air
execute in minecraft:overworld run fill 229 58 -45 229 66 -45 stone
execute in minecraft:overworld run fill 229 67 -45 229 68 -45 dirt
execute in minecraft:overworld run setblock 229 69 -45 coarse_dirt
execute in minecraft:overworld run fill 229 70 -45 229 144 -45 air
execute in minecraft:overworld run fill 229 58 -44 229 67 -44 stone
execute in minecraft:overworld run fill 229 68 -44 229 69 -44 dirt
execute in minecraft:overworld run setblock 229 70 -44 grass_block
execute in minecraft:overworld run fill 229 71 -44 229 144 -44 air
execute in minecraft:overworld run fill 229 58 -43 229 68 -43 stone
execute in minecraft:overworld run fill 229 69 -43 229 70 -43 dirt
execute in minecraft:overworld run setblock 229 71 -43 coarse_dirt
execute in minecraft:overworld run fill 229 72 -43 229 144 -43 air
execute in minecraft:overworld run fill 229 58 -42 229 69 -42 stone
execute in minecraft:overworld run fill 229 70 -42 229 71 -42 dirt
execute in minecraft:overworld run setblock 229 72 -42 grass_block
execute in minecraft:overworld run fill 229 73 -42 229 144 -42 air
execute in minecraft:overworld run fill 229 58 -41 229 70 -41 stone
execute in minecraft:overworld run fill 229 71 -41 229 72 -41 dirt
execute in minecraft:overworld run setblock 229 73 -41 grass_block
execute in minecraft:overworld run fill 229 74 -41 229 144 -41 air
execute in minecraft:overworld run fill 229 58 -40 229 71 -40 stone
execute in minecraft:overworld run fill 229 72 -40 229 73 -40 dirt
execute in minecraft:overworld run setblock 229 74 -40 grass_block
execute in minecraft:overworld run fill 229 75 -40 229 144 -40 air
execute in minecraft:overworld run fill 229 58 -39 229 72 -39 stone
execute in minecraft:overworld run fill 229 73 -39 229 74 -39 dirt
execute in minecraft:overworld run setblock 229 75 -39 coarse_dirt
execute in minecraft:overworld run fill 229 76 -39 229 144 -39 air
execute in minecraft:overworld run fill 229 58 -38 229 72 -38 stone
execute in minecraft:overworld run fill 229 73 -38 229 74 -38 dirt
execute in minecraft:overworld run setblock 229 75 -38 coarse_dirt
execute in minecraft:overworld run fill 229 76 -38 229 144 -38 air
execute in minecraft:overworld run fill 229 58 -37 229 72 -37 stone
execute in minecraft:overworld run fill 229 73 -37 229 74 -37 dirt
execute in minecraft:overworld run setblock 229 75 -37 grass_block
execute in minecraft:overworld run fill 229 76 -37 229 144 -37 air
execute in minecraft:overworld run fill 229 58 -36 229 71 -36 stone
execute in minecraft:overworld run fill 229 72 -36 229 73 -36 dirt
execute in minecraft:overworld run setblock 229 74 -36 coarse_dirt
execute in minecraft:overworld run fill 229 75 -36 229 144 -36 air
execute in minecraft:overworld run fill 229 58 -35 229 71 -35 stone
execute in minecraft:overworld run fill 229 72 -35 229 73 -35 dirt
execute in minecraft:overworld run setblock 229 74 -35 grass_block
execute in minecraft:overworld run fill 229 75 -35 229 144 -35 air
execute in minecraft:overworld run fill 229 58 -34 229 70 -34 stone
execute in minecraft:overworld run fill 229 71 -34 229 72 -34 dirt
execute in minecraft:overworld run setblock 229 73 -34 grass_block
execute in minecraft:overworld run fill 229 74 -34 229 144 -34 air
execute in minecraft:overworld run fill 229 58 -33 229 70 -33 stone
execute in minecraft:overworld run fill 229 71 -33 229 72 -33 dirt
execute in minecraft:overworld run setblock 229 73 -33 coarse_dirt
execute in minecraft:overworld run fill 229 74 -33 229 144 -33 air
execute in minecraft:overworld run fill 229 58 -32 229 69 -32 stone
execute in minecraft:overworld run fill 229 70 -32 229 71 -32 dirt
execute in minecraft:overworld run setblock 229 72 -32 grass_block
execute in minecraft:overworld run fill 229 73 -32 229 144 -32 air
execute in minecraft:overworld run fill 229 58 -31 229 69 -31 stone
execute in minecraft:overworld run fill 229 70 -31 229 71 -31 dirt
execute in minecraft:overworld run setblock 229 72 -31 grass_block
execute in minecraft:overworld run fill 229 73 -31 229 144 -31 air
execute in minecraft:overworld run fill 229 58 -30 229 68 -30 stone
execute in minecraft:overworld run fill 229 69 -30 229 70 -30 dirt
execute in minecraft:overworld run setblock 229 71 -30 coarse_dirt
execute in minecraft:overworld run fill 229 72 -30 229 144 -30 air
execute in minecraft:overworld run setblock 229 72 -30 grass
execute in minecraft:overworld run fill 229 58 -29 229 68 -29 stone
execute in minecraft:overworld run fill 229 69 -29 229 70 -29 dirt
execute in minecraft:overworld run setblock 229 71 -29 coarse_dirt
execute in minecraft:overworld run fill 229 72 -29 229 144 -29 air
execute in minecraft:overworld run fill 229 58 -28 229 67 -28 stone
execute in minecraft:overworld run fill 229 68 -28 229 69 -28 dirt
execute in minecraft:overworld run setblock 229 70 -28 coarse_dirt
execute in minecraft:overworld run fill 229 71 -28 229 144 -28 air
execute in minecraft:overworld run fill 229 58 -27 229 67 -27 stone
execute in minecraft:overworld run fill 229 68 -27 229 69 -27 dirt
execute in minecraft:overworld run setblock 229 70 -27 coarse_dirt
execute in minecraft:overworld run fill 229 71 -27 229 144 -27 air
execute in minecraft:overworld run fill 229 58 -26 229 67 -26 stone
execute in minecraft:overworld run fill 229 68 -26 229 69 -26 dirt
execute in minecraft:overworld run setblock 229 70 -26 coarse_dirt
execute in minecraft:overworld run fill 229 71 -26 229 144 -26 air
execute in minecraft:overworld run fill 229 58 -25 229 67 -25 stone
execute in minecraft:overworld run fill 229 68 -25 229 69 -25 dirt
execute in minecraft:overworld run setblock 229 70 -25 coarse_dirt
execute in minecraft:overworld run fill 229 71 -25 229 144 -25 air
execute in minecraft:overworld run fill 229 58 -24 229 66 -24 stone
execute in minecraft:overworld run fill 229 67 -24 229 68 -24 dirt
execute in minecraft:overworld run setblock 229 69 -24 coarse_dirt
execute in minecraft:overworld run fill 229 70 -24 229 144 -24 air
execute in minecraft:overworld run setblock 229 70 -24 grass
execute in minecraft:overworld run fill 229 58 -23 229 66 -23 stone
execute in minecraft:overworld run fill 229 67 -23 229 68 -23 dirt
execute in minecraft:overworld run setblock 229 69 -23 grass_block
execute in minecraft:overworld run fill 229 70 -23 229 144 -23 air
execute in minecraft:overworld run fill 229 58 -22 229 66 -22 stone
execute in minecraft:overworld run fill 229 67 -22 229 68 -22 dirt
execute in minecraft:overworld run setblock 229 69 -22 grass_block
execute in minecraft:overworld run fill 229 70 -22 229 144 -22 air
execute in minecraft:overworld run fill 229 58 -21 229 66 -21 stone
execute in minecraft:overworld run fill 229 67 -21 229 68 -21 dirt
execute in minecraft:overworld run setblock 229 69 -21 coarse_dirt
execute in minecraft:overworld run fill 229 70 -21 229 144 -21 air
execute in minecraft:overworld run fill 229 58 -20 229 66 -20 stone
execute in minecraft:overworld run fill 229 67 -20 229 68 -20 dirt
execute in minecraft:overworld run setblock 229 69 -20 coarse_dirt
execute in minecraft:overworld run fill 229 70 -20 229 144 -20 air
execute in minecraft:overworld run fill 229 58 -19 229 66 -19 stone
execute in minecraft:overworld run fill 229 67 -19 229 68 -19 dirt
execute in minecraft:overworld run setblock 229 69 -19 coarse_dirt
execute in minecraft:overworld run fill 229 70 -19 229 144 -19 air
execute in minecraft:overworld run fill 229 58 -18 229 66 -18 stone
execute in minecraft:overworld run fill 229 67 -18 229 68 -18 dirt
execute in minecraft:overworld run setblock 229 69 -18 grass_block
execute in minecraft:overworld run fill 229 70 -18 229 144 -18 air
execute in minecraft:overworld run fill 229 58 -17 229 66 -17 stone
execute in minecraft:overworld run fill 229 67 -17 229 68 -17 dirt
execute in minecraft:overworld run setblock 229 69 -17 coarse_dirt
execute in minecraft:overworld run fill 229 70 -17 229 144 -17 air
execute in minecraft:overworld run fill 229 58 -16 229 65 -16 stone
execute in minecraft:overworld run fill 229 66 -16 229 67 -16 dirt
execute in minecraft:overworld run setblock 229 68 -16 coarse_dirt
execute in minecraft:overworld run fill 229 69 -16 229 144 -16 air
execute in minecraft:overworld run fill 229 58 -15 229 65 -15 stone
execute in minecraft:overworld run fill 229 66 -15 229 67 -15 dirt
execute in minecraft:overworld run setblock 229 68 -15 coarse_dirt
execute in minecraft:overworld run fill 229 69 -15 229 144 -15 air
execute in minecraft:overworld run fill 229 58 -14 229 65 -14 stone
execute in minecraft:overworld run fill 229 66 -14 229 67 -14 dirt
execute in minecraft:overworld run setblock 229 68 -14 coarse_dirt
execute in minecraft:overworld run fill 229 69 -14 229 144 -14 air
execute in minecraft:overworld run fill 229 58 -13 229 65 -13 stone
execute in minecraft:overworld run fill 229 66 -13 229 67 -13 dirt
execute in minecraft:overworld run setblock 229 68 -13 coarse_dirt
execute in minecraft:overworld run fill 229 69 -13 229 144 -13 air
execute in minecraft:overworld run fill 229 58 -12 229 64 -12 stone
execute in minecraft:overworld run fill 229 65 -12 229 66 -12 dirt
execute in minecraft:overworld run setblock 229 67 -12 grass_block
execute in minecraft:overworld run fill 229 68 -12 229 144 -12 air
execute in minecraft:overworld run fill 229 58 -11 229 64 -11 stone
execute in minecraft:overworld run fill 229 65 -11 229 66 -11 dirt
execute in minecraft:overworld run setblock 229 67 -11 coarse_dirt
execute in minecraft:overworld run fill 229 68 -11 229 144 -11 air
execute in minecraft:overworld run fill 229 58 -10 229 64 -10 stone
execute in minecraft:overworld run fill 229 65 -10 229 66 -10 dirt
execute in minecraft:overworld run setblock 229 67 -10 coarse_dirt
execute in minecraft:overworld run fill 229 68 -10 229 144 -10 air
execute in minecraft:overworld run fill 229 58 -9 229 65 -9 stone
execute in minecraft:overworld run fill 229 66 -9 229 67 -9 dirt
execute in minecraft:overworld run setblock 229 68 -9 coarse_dirt
execute in minecraft:overworld run fill 229 69 -9 229 144 -9 air
execute in minecraft:overworld run setblock 229 69 -9 grass
execute in minecraft:overworld run fill 229 58 -8 229 65 -8 stone
execute in minecraft:overworld run fill 229 66 -8 229 67 -8 dirt
execute in minecraft:overworld run setblock 229 68 -8 grass_block
execute in minecraft:overworld run fill 229 69 -8 229 144 -8 air
execute in minecraft:overworld run fill 229 58 -7 229 65 -7 stone
execute in minecraft:overworld run fill 229 66 -7 229 67 -7 dirt
execute in minecraft:overworld run setblock 229 68 -7 coarse_dirt
execute in minecraft:overworld run fill 229 69 -7 229 144 -7 air
execute in minecraft:overworld run fill 229 58 -6 229 65 -6 stone
execute in minecraft:overworld run fill 229 66 -6 229 67 -6 dirt
execute in minecraft:overworld run setblock 229 68 -6 coarse_dirt
execute in minecraft:overworld run fill 229 69 -6 229 144 -6 air
execute in minecraft:overworld run fill 229 58 -5 229 66 -5 stone
execute in minecraft:overworld run fill 229 67 -5 229 68 -5 dirt
execute in minecraft:overworld run setblock 229 69 -5 grass_block
execute in minecraft:overworld run fill 229 70 -5 229 144 -5 air
execute in minecraft:overworld run fill 229 58 -4 229 66 -4 stone
execute in minecraft:overworld run fill 229 67 -4 229 68 -4 dirt
execute in minecraft:overworld run setblock 229 69 -4 grass_block
execute in minecraft:overworld run fill 229 70 -4 229 144 -4 air
execute in minecraft:overworld run fill 229 58 -3 229 66 -3 stone
execute in minecraft:overworld run fill 229 67 -3 229 68 -3 dirt
execute in minecraft:overworld run setblock 229 69 -3 coarse_dirt
execute in minecraft:overworld run fill 229 70 -3 229 144 -3 air
execute in minecraft:overworld run fill 229 58 -2 229 66 -2 stone
execute in minecraft:overworld run fill 229 67 -2 229 68 -2 dirt
execute in minecraft:overworld run setblock 229 69 -2 coarse_dirt
execute in minecraft:overworld run fill 229 70 -2 229 144 -2 air
execute in minecraft:overworld run fill 229 58 -1 229 66 -1 stone
execute in minecraft:overworld run fill 229 67 -1 229 68 -1 dirt
execute in minecraft:overworld run setblock 229 69 -1 grass_block
execute in minecraft:overworld run fill 229 70 -1 229 144 -1 air
execute in minecraft:overworld run fill 229 58 0 229 66 0 stone
execute in minecraft:overworld run fill 229 67 0 229 68 0 dirt
execute in minecraft:overworld run setblock 229 69 0 coarse_dirt
execute in minecraft:overworld run fill 229 70 0 229 144 0 air
execute in minecraft:overworld run fill 229 58 1 229 66 1 stone
execute in minecraft:overworld run fill 229 67 1 229 68 1 dirt
execute in minecraft:overworld run setblock 229 69 1 coarse_dirt
execute in minecraft:overworld run fill 229 70 1 229 144 1 air
execute in minecraft:overworld run fill 229 58 2 229 66 2 stone
execute in minecraft:overworld run fill 229 67 2 229 68 2 dirt
execute in minecraft:overworld run setblock 229 69 2 grass_block
execute in minecraft:overworld run fill 229 70 2 229 144 2 air
execute in minecraft:overworld run fill 229 58 3 229 66 3 stone
execute in minecraft:overworld run fill 229 67 3 229 68 3 dirt
execute in minecraft:overworld run setblock 229 69 3 coarse_dirt
execute in minecraft:overworld run fill 229 70 3 229 144 3 air
execute in minecraft:overworld run fill 229 58 4 229 66 4 stone
execute in minecraft:overworld run fill 229 67 4 229 68 4 dirt
execute in minecraft:overworld run setblock 229 69 4 grass_block
execute in minecraft:overworld run fill 229 70 4 229 144 4 air
execute in minecraft:overworld run fill 229 58 5 229 66 5 stone
execute in minecraft:overworld run fill 229 67 5 229 68 5 dirt
execute in minecraft:overworld run setblock 229 69 5 coarse_dirt
execute in minecraft:overworld run fill 229 70 5 229 144 5 air
execute in minecraft:overworld run fill 229 58 6 229 66 6 stone
execute in minecraft:overworld run fill 229 67 6 229 68 6 dirt
execute in minecraft:overworld run setblock 229 69 6 grass_block
execute in minecraft:overworld run fill 229 70 6 229 144 6 air
schedule function blade_gallery:random/burned/part_33 1t replace
