execute in minecraft:overworld run fill 415 67 2 415 144 2 air
execute in minecraft:overworld run fill 415 58 3 415 63 3 stone
execute in minecraft:overworld run fill 415 64 3 415 65 3 dirt
execute in minecraft:overworld run setblock 415 66 3 coarse_dirt
execute in minecraft:overworld run fill 415 67 3 415 144 3 air
execute in minecraft:overworld run setblock 415 67 3 grass
execute in minecraft:overworld run fill 415 58 4 415 63 4 stone
execute in minecraft:overworld run fill 415 64 4 415 65 4 dirt
execute in minecraft:overworld run setblock 415 66 4 coarse_dirt
execute in minecraft:overworld run fill 415 67 4 415 144 4 air
execute in minecraft:overworld run fill 415 58 5 415 64 5 stone
execute in minecraft:overworld run fill 415 65 5 415 66 5 dirt
execute in minecraft:overworld run setblock 415 67 5 coarse_dirt
execute in minecraft:overworld run fill 415 68 5 415 144 5 air
execute in minecraft:overworld run fill 415 58 6 415 64 6 stone
execute in minecraft:overworld run fill 415 65 6 415 66 6 dirt
execute in minecraft:overworld run setblock 415 67 6 grass_block
execute in minecraft:overworld run fill 415 68 6 415 144 6 air
execute in minecraft:overworld run fill 415 58 7 415 64 7 stone
execute in minecraft:overworld run fill 415 65 7 415 66 7 dirt
execute in minecraft:overworld run setblock 415 67 7 grass_block
execute in minecraft:overworld run fill 415 68 7 415 144 7 air
execute in minecraft:overworld run fill 415 58 8 415 65 8 stone
execute in minecraft:overworld run fill 415 66 8 415 67 8 dirt
execute in minecraft:overworld run setblock 415 68 8 coarse_dirt
execute in minecraft:overworld run fill 415 69 8 415 144 8 air
execute in minecraft:overworld run fill 415 58 9 415 65 9 stone
execute in minecraft:overworld run fill 415 66 9 415 67 9 dirt
execute in minecraft:overworld run setblock 415 68 9 coarse_dirt
execute in minecraft:overworld run fill 415 69 9 415 144 9 air
execute in minecraft:overworld run fill 415 58 10 415 65 10 stone
execute in minecraft:overworld run fill 415 66 10 415 67 10 dirt
execute in minecraft:overworld run setblock 415 68 10 grass_block
execute in minecraft:overworld run fill 415 69 10 415 144 10 air
execute in minecraft:overworld run fill 415 58 11 415 66 11 stone
execute in minecraft:overworld run fill 415 67 11 415 68 11 dirt
execute in minecraft:overworld run setblock 415 69 11 coarse_dirt
execute in minecraft:overworld run fill 415 70 11 415 144 11 air
execute in minecraft:overworld run fill 415 58 12 415 66 12 stone
execute in minecraft:overworld run fill 415 67 12 415 68 12 dirt
execute in minecraft:overworld run setblock 415 69 12 coarse_dirt
execute in minecraft:overworld run fill 415 70 12 415 144 12 air
execute in minecraft:overworld run fill 415 58 13 415 66 13 stone
execute in minecraft:overworld run fill 415 67 13 415 68 13 dirt
execute in minecraft:overworld run setblock 415 69 13 coarse_dirt
execute in minecraft:overworld run fill 415 70 13 415 144 13 air
execute in minecraft:overworld run fill 415 58 14 415 67 14 stone
execute in minecraft:overworld run fill 415 68 14 415 69 14 dirt
execute in minecraft:overworld run setblock 415 70 14 coarse_dirt
execute in minecraft:overworld run fill 415 71 14 415 144 14 air
execute in minecraft:overworld run fill 415 58 15 415 67 15 stone
execute in minecraft:overworld run fill 415 68 15 415 69 15 dirt
execute in minecraft:overworld run setblock 415 70 15 coarse_dirt
execute in minecraft:overworld run fill 415 71 15 415 144 15 air
execute in minecraft:overworld run setblock 415 71 15 grass
execute in minecraft:overworld run fill 415 58 16 415 67 16 stone
execute in minecraft:overworld run fill 415 68 16 415 69 16 dirt
execute in minecraft:overworld run setblock 415 70 16 coarse_dirt
execute in minecraft:overworld run fill 415 71 16 415 144 16 air
execute in minecraft:overworld run fill 415 58 17 415 68 17 stone
execute in minecraft:overworld run fill 415 69 17 415 70 17 dirt
execute in minecraft:overworld run setblock 415 71 17 coarse_dirt
execute in minecraft:overworld run fill 415 72 17 415 144 17 air
execute in minecraft:overworld run fill 415 58 18 415 68 18 stone
execute in minecraft:overworld run fill 415 69 18 415 70 18 dirt
execute in minecraft:overworld run setblock 415 71 18 coarse_dirt
execute in minecraft:overworld run fill 415 72 18 415 144 18 air
execute in minecraft:overworld run fill 415 58 19 415 68 19 stone
execute in minecraft:overworld run fill 415 69 19 415 70 19 dirt
execute in minecraft:overworld run setblock 415 71 19 coarse_dirt
execute in minecraft:overworld run fill 415 72 19 415 144 19 air
execute in minecraft:overworld run fill 415 58 20 415 69 20 stone
execute in minecraft:overworld run fill 415 70 20 415 71 20 dirt
execute in minecraft:overworld run setblock 415 72 20 coarse_dirt
execute in minecraft:overworld run fill 415 73 20 415 144 20 air
execute in minecraft:overworld run fill 415 58 21 415 69 21 stone
execute in minecraft:overworld run fill 415 70 21 415 71 21 dirt
execute in minecraft:overworld run setblock 415 72 21 coarse_dirt
execute in minecraft:overworld run fill 415 73 21 415 144 21 air
execute in minecraft:overworld run setblock 415 73 21 grass
execute in minecraft:overworld run fill 415 58 22 415 70 22 stone
execute in minecraft:overworld run fill 415 71 22 415 72 22 dirt
execute in minecraft:overworld run setblock 415 73 22 coarse_dirt
execute in minecraft:overworld run fill 415 74 22 415 144 22 air
execute in minecraft:overworld run fill 415 58 23 415 70 23 stone
execute in minecraft:overworld run fill 415 71 23 415 72 23 dirt
execute in minecraft:overworld run setblock 415 73 23 coarse_dirt
execute in minecraft:overworld run fill 415 74 23 415 144 23 air
execute in minecraft:overworld run fill 415 58 24 415 70 24 stone
execute in minecraft:overworld run fill 415 71 24 415 72 24 dirt
execute in minecraft:overworld run setblock 415 73 24 coarse_dirt
execute in minecraft:overworld run fill 415 74 24 415 144 24 air
execute in minecraft:overworld run fill 415 58 25 415 71 25 stone
execute in minecraft:overworld run fill 415 72 25 415 73 25 dirt
execute in minecraft:overworld run setblock 415 74 25 coarse_dirt
execute in minecraft:overworld run fill 415 75 25 415 144 25 air
execute in minecraft:overworld run fill 415 58 26 415 71 26 stone
execute in minecraft:overworld run fill 415 72 26 415 73 26 dirt
execute in minecraft:overworld run setblock 415 74 26 coarse_dirt
execute in minecraft:overworld run fill 415 75 26 415 144 26 air
execute in minecraft:overworld run setblock 415 75 26 grass
execute in minecraft:overworld run fill 415 58 27 415 71 27 stone
execute in minecraft:overworld run fill 415 72 27 415 73 27 dirt
execute in minecraft:overworld run setblock 415 74 27 grass_block
execute in minecraft:overworld run fill 415 75 27 415 144 27 air
execute in minecraft:overworld run fill 415 58 28 415 71 28 stone
execute in minecraft:overworld run fill 415 72 28 415 73 28 dirt
execute in minecraft:overworld run setblock 415 74 28 coarse_dirt
execute in minecraft:overworld run fill 415 75 28 415 144 28 air
execute in minecraft:overworld run fill 415 58 29 415 71 29 stone
execute in minecraft:overworld run fill 415 72 29 415 73 29 dirt
execute in minecraft:overworld run setblock 415 74 29 coarse_dirt
execute in minecraft:overworld run fill 415 75 29 415 144 29 air
execute in minecraft:overworld run fill 415 58 30 415 71 30 stone
execute in minecraft:overworld run fill 415 72 30 415 73 30 dirt
execute in minecraft:overworld run setblock 415 74 30 coarse_dirt
execute in minecraft:overworld run fill 415 75 30 415 144 30 air
execute in minecraft:overworld run fill 415 58 31 415 71 31 stone
execute in minecraft:overworld run fill 415 72 31 415 73 31 dirt
execute in minecraft:overworld run setblock 415 74 31 grass_block
execute in minecraft:overworld run fill 415 75 31 415 144 31 air
execute in minecraft:overworld run fill 415 58 32 415 70 32 stone
execute in minecraft:overworld run fill 415 71 32 415 72 32 dirt
execute in minecraft:overworld run setblock 415 73 32 coarse_dirt
execute in minecraft:overworld run fill 415 74 32 415 144 32 air
execute in minecraft:overworld run fill 415 58 33 415 70 33 stone
execute in minecraft:overworld run fill 415 71 33 415 72 33 dirt
execute in minecraft:overworld run setblock 415 73 33 grass_block
execute in minecraft:overworld run fill 415 74 33 415 144 33 air
execute in minecraft:overworld run fill 415 58 34 415 70 34 stone
execute in minecraft:overworld run fill 415 71 34 415 72 34 dirt
execute in minecraft:overworld run setblock 415 73 34 grass_block
execute in minecraft:overworld run fill 415 74 34 415 144 34 air
execute in minecraft:overworld run fill 415 58 35 415 69 35 stone
execute in minecraft:overworld run fill 415 70 35 415 71 35 dirt
execute in minecraft:overworld run setblock 415 72 35 coarse_dirt
execute in minecraft:overworld run fill 415 73 35 415 144 35 air
execute in minecraft:overworld run fill 415 58 36 415 69 36 stone
execute in minecraft:overworld run fill 415 70 36 415 71 36 dirt
execute in minecraft:overworld run setblock 415 72 36 coarse_dirt
execute in minecraft:overworld run fill 415 73 36 415 144 36 air
execute in minecraft:overworld run fill 415 58 37 415 68 37 stone
execute in minecraft:overworld run fill 415 69 37 415 70 37 dirt
execute in minecraft:overworld run setblock 415 71 37 coarse_dirt
execute in minecraft:overworld run fill 415 72 37 415 144 37 air
execute in minecraft:overworld run fill 415 58 38 415 68 38 stone
execute in minecraft:overworld run fill 415 69 38 415 70 38 dirt
execute in minecraft:overworld run setblock 415 71 38 coarse_dirt
execute in minecraft:overworld run fill 415 72 38 415 144 38 air
execute in minecraft:overworld run fill 415 58 39 415 67 39 stone
execute in minecraft:overworld run fill 415 68 39 415 69 39 dirt
execute in minecraft:overworld run setblock 415 70 39 grass_block
execute in minecraft:overworld run fill 415 71 39 415 144 39 air
execute in minecraft:overworld run fill 415 58 40 415 66 40 stone
execute in minecraft:overworld run fill 415 67 40 415 68 40 dirt
execute in minecraft:overworld run setblock 415 69 40 grass_block
execute in minecraft:overworld run fill 415 70 40 415 144 40 air
execute in minecraft:overworld run fill 415 58 41 415 65 41 stone
execute in minecraft:overworld run fill 415 66 41 415 67 41 dirt
execute in minecraft:overworld run setblock 415 68 41 coarse_dirt
execute in minecraft:overworld run fill 415 69 41 415 144 41 air
execute in minecraft:overworld run fill 415 58 42 415 64 42 stone
execute in minecraft:overworld run fill 415 65 42 415 66 42 dirt
execute in minecraft:overworld run setblock 415 67 42 coarse_dirt
execute in minecraft:overworld run fill 415 68 42 415 144 42 air
execute in minecraft:overworld run fill 415 58 43 415 64 43 stone
execute in minecraft:overworld run fill 415 65 43 415 66 43 dirt
execute in minecraft:overworld run setblock 415 67 43 grass_block
execute in minecraft:overworld run fill 415 68 43 415 144 43 air
execute in minecraft:overworld run fill 415 58 44 415 63 44 stone
execute in minecraft:overworld run fill 415 64 44 415 65 44 dirt
execute in minecraft:overworld run setblock 415 66 44 coarse_dirt
execute in minecraft:overworld run fill 415 67 44 415 144 44 air
execute in minecraft:overworld run fill 415 58 45 415 62 45 stone
execute in minecraft:overworld run fill 415 63 45 415 64 45 dirt
execute in minecraft:overworld run setblock 415 65 45 coarse_dirt
execute in minecraft:overworld run fill 415 66 45 415 144 45 air
execute in minecraft:overworld run fill 415 58 46 415 62 46 stone
execute in minecraft:overworld run fill 415 63 46 415 64 46 dirt
execute in minecraft:overworld run setblock 415 65 46 coarse_dirt
execute in minecraft:overworld run fill 415 66 46 415 144 46 air
execute in minecraft:overworld run fill 415 58 47 415 61 47 stone
execute in minecraft:overworld run fill 415 62 47 415 63 47 dirt
execute in minecraft:overworld run setblock 415 64 47 coarse_dirt
execute in minecraft:overworld run fill 415 65 47 415 144 47 air
execute in minecraft:overworld run fill 416 58 -48 416 61 -48 stone
execute in minecraft:overworld run fill 416 62 -48 416 63 -48 dirt
execute in minecraft:overworld run setblock 416 64 -48 grass_block
execute in minecraft:overworld run fill 416 65 -48 416 144 -48 air
execute in minecraft:overworld run fill 416 58 -47 416 63 -47 stone
execute in minecraft:overworld run fill 416 64 -47 416 65 -47 dirt
execute in minecraft:overworld run setblock 416 66 -47 coarse_dirt
execute in minecraft:overworld run fill 416 67 -47 416 144 -47 air
execute in minecraft:overworld run fill 416 58 -46 416 64 -46 stone
execute in minecraft:overworld run fill 416 65 -46 416 66 -46 dirt
execute in minecraft:overworld run setblock 416 67 -46 coarse_dirt
execute in minecraft:overworld run fill 416 68 -46 416 144 -46 air
execute in minecraft:overworld run fill 416 58 -45 416 66 -45 stone
execute in minecraft:overworld run fill 416 67 -45 416 68 -45 dirt
execute in minecraft:overworld run setblock 416 69 -45 coarse_dirt
execute in minecraft:overworld run fill 416 70 -45 416 144 -45 air
execute in minecraft:overworld run fill 416 58 -44 416 67 -44 stone
execute in minecraft:overworld run fill 416 68 -44 416 69 -44 dirt
execute in minecraft:overworld run setblock 416 70 -44 coarse_dirt
execute in minecraft:overworld run fill 416 71 -44 416 144 -44 air
execute in minecraft:overworld run fill 416 58 -43 416 69 -43 stone
execute in minecraft:overworld run fill 416 70 -43 416 71 -43 dirt
execute in minecraft:overworld run setblock 416 72 -43 coarse_dirt
execute in minecraft:overworld run fill 416 73 -43 416 144 -43 air
execute in minecraft:overworld run fill 416 58 -42 416 70 -42 stone
execute in minecraft:overworld run fill 416 71 -42 416 72 -42 dirt
execute in minecraft:overworld run setblock 416 73 -42 coarse_dirt
execute in minecraft:overworld run fill 416 74 -42 416 144 -42 air
execute in minecraft:overworld run fill 416 58 -41 416 71 -41 stone
execute in minecraft:overworld run fill 416 72 -41 416 73 -41 dirt
execute in minecraft:overworld run setblock 416 74 -41 grass_block
execute in minecraft:overworld run fill 416 75 -41 416 144 -41 air
execute in minecraft:overworld run fill 416 58 -40 416 73 -40 stone
execute in minecraft:overworld run fill 416 74 -40 416 75 -40 dirt
execute in minecraft:overworld run setblock 416 76 -40 coarse_dirt
execute in minecraft:overworld run fill 416 77 -40 416 144 -40 air
execute in minecraft:overworld run fill 416 58 -39 416 74 -39 stone
execute in minecraft:overworld run fill 416 75 -39 416 76 -39 dirt
execute in minecraft:overworld run setblock 416 77 -39 coarse_dirt
execute in minecraft:overworld run fill 416 78 -39 416 144 -39 air
execute in minecraft:overworld run fill 416 58 -38 416 75 -38 stone
execute in minecraft:overworld run fill 416 76 -38 416 77 -38 dirt
execute in minecraft:overworld run setblock 416 78 -38 coarse_dirt
execute in minecraft:overworld run fill 416 79 -38 416 144 -38 air
execute in minecraft:overworld run fill 416 58 -37 416 75 -37 stone
execute in minecraft:overworld run fill 416 76 -37 416 77 -37 dirt
execute in minecraft:overworld run setblock 416 78 -37 grass_block
execute in minecraft:overworld run fill 416 79 -37 416 144 -37 air
execute in minecraft:overworld run fill 416 58 -36 416 74 -36 stone
execute in minecraft:overworld run fill 416 75 -36 416 76 -36 dirt
execute in minecraft:overworld run setblock 416 77 -36 grass_block
execute in minecraft:overworld run fill 416 78 -36 416 144 -36 air
execute in minecraft:overworld run fill 416 58 -35 416 74 -35 stone
execute in minecraft:overworld run fill 416 75 -35 416 76 -35 dirt
execute in minecraft:overworld run setblock 416 77 -35 grass_block
execute in minecraft:overworld run fill 416 78 -35 416 144 -35 air
execute in minecraft:overworld run fill 416 58 -34 416 73 -34 stone
execute in minecraft:overworld run fill 416 74 -34 416 75 -34 dirt
execute in minecraft:overworld run setblock 416 76 -34 grass_block
execute in minecraft:overworld run fill 416 77 -34 416 144 -34 air
execute in minecraft:overworld run fill 416 58 -33 416 73 -33 stone
execute in minecraft:overworld run fill 416 74 -33 416 75 -33 dirt
execute in minecraft:overworld run setblock 416 76 -33 coarse_dirt
execute in minecraft:overworld run fill 416 77 -33 416 144 -33 air
execute in minecraft:overworld run fill 416 58 -32 416 73 -32 stone
execute in minecraft:overworld run fill 416 74 -32 416 75 -32 dirt
execute in minecraft:overworld run setblock 416 76 -32 coarse_dirt
execute in minecraft:overworld run fill 416 77 -32 416 144 -32 air
execute in minecraft:overworld run fill 416 58 -31 416 72 -31 stone
execute in minecraft:overworld run fill 416 73 -31 416 74 -31 dirt
execute in minecraft:overworld run setblock 416 75 -31 grass_block
schedule function blade_gallery:random/battlefield/part_126 1t replace
