execute in minecraft:overworld run fill 390 63 20 390 144 20 air
execute in minecraft:overworld run fill 390 63 20 390 64 20 water
execute in minecraft:overworld run fill 390 58 21 390 59 21 stone
execute in minecraft:overworld run fill 390 60 21 390 61 21 dirt
execute in minecraft:overworld run setblock 390 62 21 gravel
execute in minecraft:overworld run fill 390 63 21 390 144 21 air
execute in minecraft:overworld run fill 390 63 21 390 64 21 water
execute in minecraft:overworld run fill 390 58 22 390 59 22 stone
execute in minecraft:overworld run fill 390 60 22 390 61 22 dirt
execute in minecraft:overworld run setblock 390 62 22 gravel
execute in minecraft:overworld run fill 390 63 22 390 144 22 air
execute in minecraft:overworld run fill 390 63 22 390 64 22 water
execute in minecraft:overworld run fill 390 58 23 390 59 23 stone
execute in minecraft:overworld run fill 390 60 23 390 61 23 dirt
execute in minecraft:overworld run setblock 390 62 23 gravel
execute in minecraft:overworld run fill 390 63 23 390 144 23 air
execute in minecraft:overworld run fill 390 63 23 390 64 23 water
execute in minecraft:overworld run fill 390 58 24 390 59 24 stone
execute in minecraft:overworld run fill 390 60 24 390 61 24 dirt
execute in minecraft:overworld run setblock 390 62 24 gravel
execute in minecraft:overworld run fill 390 63 24 390 144 24 air
execute in minecraft:overworld run fill 390 63 24 390 64 24 water
execute in minecraft:overworld run fill 390 58 25 390 59 25 stone
execute in minecraft:overworld run fill 390 60 25 390 61 25 dirt
execute in minecraft:overworld run setblock 390 62 25 gravel
execute in minecraft:overworld run fill 390 63 25 390 144 25 air
execute in minecraft:overworld run fill 390 63 25 390 64 25 water
execute in minecraft:overworld run fill 390 58 26 390 59 26 stone
execute in minecraft:overworld run fill 390 60 26 390 61 26 dirt
execute in minecraft:overworld run setblock 390 62 26 gravel
execute in minecraft:overworld run fill 390 63 26 390 144 26 air
execute in minecraft:overworld run fill 390 63 26 390 64 26 water
execute in minecraft:overworld run fill 390 58 27 390 58 27 stone
execute in minecraft:overworld run fill 390 59 27 390 60 27 dirt
execute in minecraft:overworld run setblock 390 61 27 gravel
execute in minecraft:overworld run fill 390 62 27 390 144 27 air
execute in minecraft:overworld run fill 390 62 27 390 64 27 water
execute in minecraft:overworld run fill 390 58 28 390 58 28 stone
execute in minecraft:overworld run fill 390 59 28 390 60 28 dirt
execute in minecraft:overworld run setblock 390 61 28 gravel
execute in minecraft:overworld run fill 390 62 28 390 144 28 air
execute in minecraft:overworld run fill 390 62 28 390 64 28 water
execute in minecraft:overworld run fill 390 58 29 390 58 29 stone
execute in minecraft:overworld run fill 390 59 29 390 60 29 dirt
execute in minecraft:overworld run setblock 390 61 29 gravel
execute in minecraft:overworld run fill 390 62 29 390 144 29 air
execute in minecraft:overworld run fill 390 62 29 390 64 29 water
execute in minecraft:overworld run fill 390 58 30 390 58 30 stone
execute in minecraft:overworld run fill 390 59 30 390 60 30 dirt
execute in minecraft:overworld run setblock 390 61 30 gravel
execute in minecraft:overworld run fill 390 62 30 390 144 30 air
execute in minecraft:overworld run fill 390 62 30 390 64 30 water
execute in minecraft:overworld run fill 390 58 31 390 58 31 stone
execute in minecraft:overworld run fill 390 59 31 390 60 31 dirt
execute in minecraft:overworld run setblock 390 61 31 gravel
execute in minecraft:overworld run fill 390 62 31 390 144 31 air
execute in minecraft:overworld run fill 390 62 31 390 64 31 water
execute in minecraft:overworld run fill 390 58 32 390 58 32 stone
execute in minecraft:overworld run fill 390 59 32 390 60 32 dirt
execute in minecraft:overworld run setblock 390 61 32 gravel
execute in minecraft:overworld run fill 390 62 32 390 144 32 air
execute in minecraft:overworld run fill 390 62 32 390 64 32 water
execute in minecraft:overworld run fill 390 58 33 390 58 33 stone
execute in minecraft:overworld run fill 390 59 33 390 60 33 dirt
execute in minecraft:overworld run setblock 390 61 33 gravel
execute in minecraft:overworld run fill 390 62 33 390 144 33 air
execute in minecraft:overworld run fill 390 62 33 390 64 33 water
execute in minecraft:overworld run fill 390 58 34 390 58 34 stone
execute in minecraft:overworld run fill 390 59 34 390 60 34 dirt
execute in minecraft:overworld run setblock 390 61 34 gravel
execute in minecraft:overworld run fill 390 62 34 390 144 34 air
execute in minecraft:overworld run fill 390 62 34 390 64 34 water
execute in minecraft:overworld run fill 390 58 35 390 58 35 stone
execute in minecraft:overworld run fill 390 59 35 390 60 35 dirt
execute in minecraft:overworld run setblock 390 61 35 gravel
execute in minecraft:overworld run fill 390 62 35 390 144 35 air
execute in minecraft:overworld run fill 390 62 35 390 64 35 water
execute in minecraft:overworld run fill 390 58 36 390 58 36 stone
execute in minecraft:overworld run fill 390 59 36 390 60 36 dirt
execute in minecraft:overworld run setblock 390 61 36 gravel
execute in minecraft:overworld run fill 390 62 36 390 144 36 air
execute in minecraft:overworld run fill 390 62 36 390 64 36 water
execute in minecraft:overworld run fill 390 58 37 390 59 37 stone
execute in minecraft:overworld run fill 390 60 37 390 61 37 dirt
execute in minecraft:overworld run setblock 390 62 37 gravel
execute in minecraft:overworld run fill 390 63 37 390 144 37 air
execute in minecraft:overworld run fill 390 63 37 390 64 37 water
execute in minecraft:overworld run fill 390 58 38 390 59 38 stone
execute in minecraft:overworld run fill 390 60 38 390 61 38 dirt
execute in minecraft:overworld run setblock 390 62 38 gravel
execute in minecraft:overworld run fill 390 63 38 390 144 38 air
execute in minecraft:overworld run fill 390 63 38 390 64 38 water
execute in minecraft:overworld run fill 390 58 39 390 59 39 stone
execute in minecraft:overworld run fill 390 60 39 390 61 39 dirt
execute in minecraft:overworld run setblock 390 62 39 gravel
execute in minecraft:overworld run fill 390 63 39 390 144 39 air
execute in minecraft:overworld run fill 390 63 39 390 64 39 water
execute in minecraft:overworld run fill 390 58 40 390 60 40 stone
execute in minecraft:overworld run fill 390 61 40 390 62 40 dirt
execute in minecraft:overworld run setblock 390 63 40 gravel
execute in minecraft:overworld run fill 390 64 40 390 144 40 air
execute in minecraft:overworld run fill 390 64 40 390 64 40 water
execute in minecraft:overworld run fill 390 58 41 390 60 41 stone
execute in minecraft:overworld run fill 390 61 41 390 62 41 dirt
execute in minecraft:overworld run setblock 390 63 41 gravel
execute in minecraft:overworld run fill 390 64 41 390 144 41 air
execute in minecraft:overworld run fill 390 64 41 390 64 41 water
execute in minecraft:overworld run fill 390 58 42 390 61 42 stone
execute in minecraft:overworld run fill 390 62 42 390 63 42 dirt
execute in minecraft:overworld run setblock 390 64 42 grass_block
execute in minecraft:overworld run fill 390 65 42 390 144 42 air
execute in minecraft:overworld run fill 390 58 43 390 61 43 stone
execute in minecraft:overworld run fill 390 62 43 390 63 43 dirt
execute in minecraft:overworld run setblock 390 64 43 grass_block
execute in minecraft:overworld run fill 390 65 43 390 144 43 air
execute in minecraft:overworld run fill 390 58 44 390 61 44 stone
execute in minecraft:overworld run fill 390 62 44 390 63 44 dirt
execute in minecraft:overworld run setblock 390 64 44 coarse_dirt
execute in minecraft:overworld run fill 390 65 44 390 144 44 air
execute in minecraft:overworld run fill 390 58 45 390 62 45 stone
execute in minecraft:overworld run fill 390 63 45 390 64 45 dirt
execute in minecraft:overworld run setblock 390 65 45 coarse_dirt
execute in minecraft:overworld run fill 390 66 45 390 144 45 air
execute in minecraft:overworld run fill 390 58 46 390 61 46 stone
execute in minecraft:overworld run fill 390 62 46 390 63 46 dirt
execute in minecraft:overworld run setblock 390 64 46 grass_block
execute in minecraft:overworld run fill 390 65 46 390 144 46 air
execute in minecraft:overworld run fill 390 58 47 390 61 47 stone
execute in minecraft:overworld run fill 390 62 47 390 63 47 dirt
execute in minecraft:overworld run setblock 390 64 47 coarse_dirt
execute in minecraft:overworld run fill 390 65 47 390 144 47 air
execute in minecraft:overworld run fill 391 58 -48 391 61 -48 stone
execute in minecraft:overworld run fill 391 62 -48 391 63 -48 dirt
execute in minecraft:overworld run setblock 391 64 -48 coarse_dirt
execute in minecraft:overworld run fill 391 65 -48 391 144 -48 air
execute in minecraft:overworld run fill 391 58 -47 391 62 -47 stone
execute in minecraft:overworld run fill 391 63 -47 391 64 -47 dirt
execute in minecraft:overworld run setblock 391 65 -47 coarse_dirt
execute in minecraft:overworld run fill 391 66 -47 391 144 -47 air
execute in minecraft:overworld run fill 391 58 -46 391 64 -46 stone
execute in minecraft:overworld run fill 391 65 -46 391 66 -46 dirt
execute in minecraft:overworld run setblock 391 67 -46 coarse_dirt
execute in minecraft:overworld run fill 391 68 -46 391 144 -46 air
execute in minecraft:overworld run fill 391 58 -45 391 65 -45 stone
execute in minecraft:overworld run fill 391 66 -45 391 67 -45 dirt
execute in minecraft:overworld run setblock 391 68 -45 coarse_dirt
execute in minecraft:overworld run fill 391 69 -45 391 144 -45 air
execute in minecraft:overworld run fill 391 58 -44 391 67 -44 stone
execute in minecraft:overworld run fill 391 68 -44 391 69 -44 dirt
execute in minecraft:overworld run setblock 391 70 -44 coarse_dirt
execute in minecraft:overworld run fill 391 71 -44 391 144 -44 air
execute in minecraft:overworld run fill 391 58 -43 391 68 -43 stone
execute in minecraft:overworld run fill 391 69 -43 391 70 -43 dirt
execute in minecraft:overworld run setblock 391 71 -43 coarse_dirt
execute in minecraft:overworld run fill 391 72 -43 391 144 -43 air
execute in minecraft:overworld run fill 391 58 -42 391 69 -42 stone
execute in minecraft:overworld run fill 391 70 -42 391 71 -42 dirt
execute in minecraft:overworld run setblock 391 72 -42 coarse_dirt
execute in minecraft:overworld run fill 391 73 -42 391 144 -42 air
execute in minecraft:overworld run fill 391 58 -41 391 70 -41 stone
execute in minecraft:overworld run fill 391 71 -41 391 72 -41 dirt
execute in minecraft:overworld run setblock 391 73 -41 coarse_dirt
execute in minecraft:overworld run fill 391 74 -41 391 144 -41 air
execute in minecraft:overworld run fill 391 58 -40 391 72 -40 stone
execute in minecraft:overworld run fill 391 73 -40 391 74 -40 dirt
execute in minecraft:overworld run setblock 391 75 -40 coarse_dirt
execute in minecraft:overworld run fill 391 76 -40 391 144 -40 air
execute in minecraft:overworld run fill 391 58 -39 391 73 -39 stone
execute in minecraft:overworld run fill 391 74 -39 391 75 -39 dirt
execute in minecraft:overworld run setblock 391 76 -39 coarse_dirt
execute in minecraft:overworld run fill 391 77 -39 391 144 -39 air
execute in minecraft:overworld run fill 391 58 -38 391 74 -38 stone
execute in minecraft:overworld run fill 391 75 -38 391 76 -38 dirt
execute in minecraft:overworld run setblock 391 77 -38 coarse_dirt
execute in minecraft:overworld run fill 391 78 -38 391 144 -38 air
execute in minecraft:overworld run fill 391 58 -37 391 74 -37 stone
execute in minecraft:overworld run fill 391 75 -37 391 76 -37 dirt
execute in minecraft:overworld run setblock 391 77 -37 coarse_dirt
execute in minecraft:overworld run fill 391 78 -37 391 144 -37 air
execute in minecraft:overworld run fill 391 58 -36 391 73 -36 stone
execute in minecraft:overworld run fill 391 74 -36 391 75 -36 dirt
execute in minecraft:overworld run setblock 391 76 -36 grass_block
execute in minecraft:overworld run fill 391 77 -36 391 144 -36 air
execute in minecraft:overworld run setblock 391 77 -36 grass
execute in minecraft:overworld run fill 391 58 -35 391 73 -35 stone
execute in minecraft:overworld run fill 391 74 -35 391 75 -35 dirt
execute in minecraft:overworld run setblock 391 76 -35 coarse_dirt
execute in minecraft:overworld run fill 391 77 -35 391 144 -35 air
execute in minecraft:overworld run fill 391 58 -34 391 73 -34 stone
execute in minecraft:overworld run fill 391 74 -34 391 75 -34 dirt
execute in minecraft:overworld run setblock 391 76 -34 coarse_dirt
execute in minecraft:overworld run fill 391 77 -34 391 144 -34 air
execute in minecraft:overworld run fill 391 58 -33 391 73 -33 stone
execute in minecraft:overworld run fill 391 74 -33 391 75 -33 dirt
execute in minecraft:overworld run setblock 391 76 -33 coarse_dirt
execute in minecraft:overworld run fill 391 77 -33 391 144 -33 air
execute in minecraft:overworld run fill 391 58 -32 391 72 -32 stone
execute in minecraft:overworld run fill 391 73 -32 391 74 -32 dirt
execute in minecraft:overworld run setblock 391 75 -32 grass_block
execute in minecraft:overworld run fill 391 76 -32 391 144 -32 air
execute in minecraft:overworld run fill 391 58 -31 391 72 -31 stone
execute in minecraft:overworld run fill 391 73 -31 391 74 -31 dirt
execute in minecraft:overworld run setblock 391 75 -31 grass_block
execute in minecraft:overworld run fill 391 76 -31 391 144 -31 air
execute in minecraft:overworld run setblock 391 76 -31 grass
execute in minecraft:overworld run fill 391 58 -30 391 72 -30 stone
execute in minecraft:overworld run fill 391 73 -30 391 74 -30 dirt
execute in minecraft:overworld run setblock 391 75 -30 coarse_dirt
execute in minecraft:overworld run fill 391 76 -30 391 144 -30 air
execute in minecraft:overworld run fill 391 58 -29 391 71 -29 stone
execute in minecraft:overworld run fill 391 72 -29 391 73 -29 dirt
execute in minecraft:overworld run setblock 391 74 -29 coarse_dirt
execute in minecraft:overworld run fill 391 75 -29 391 144 -29 air
execute in minecraft:overworld run fill 391 58 -28 391 70 -28 stone
execute in minecraft:overworld run fill 391 71 -28 391 72 -28 dirt
execute in minecraft:overworld run setblock 391 73 -28 coarse_dirt
execute in minecraft:overworld run fill 391 74 -28 391 144 -28 air
execute in minecraft:overworld run fill 391 58 -27 391 70 -27 stone
execute in minecraft:overworld run fill 391 71 -27 391 72 -27 dirt
execute in minecraft:overworld run setblock 391 73 -27 coarse_dirt
execute in minecraft:overworld run fill 391 74 -27 391 144 -27 air
execute in minecraft:overworld run fill 391 58 -26 391 69 -26 stone
execute in minecraft:overworld run fill 391 70 -26 391 71 -26 dirt
execute in minecraft:overworld run setblock 391 72 -26 coarse_dirt
execute in minecraft:overworld run fill 391 73 -26 391 144 -26 air
execute in minecraft:overworld run fill 391 58 -25 391 68 -25 stone
execute in minecraft:overworld run fill 391 69 -25 391 70 -25 dirt
execute in minecraft:overworld run setblock 391 71 -25 coarse_dirt
execute in minecraft:overworld run fill 391 72 -25 391 144 -25 air
execute in minecraft:overworld run fill 391 58 -24 391 67 -24 stone
execute in minecraft:overworld run fill 391 68 -24 391 69 -24 dirt
execute in minecraft:overworld run setblock 391 70 -24 grass_block
execute in minecraft:overworld run fill 391 71 -24 391 144 -24 air
execute in minecraft:overworld run fill 391 58 -23 391 66 -23 stone
execute in minecraft:overworld run fill 391 67 -23 391 68 -23 dirt
execute in minecraft:overworld run setblock 391 69 -23 coarse_dirt
execute in minecraft:overworld run fill 391 70 -23 391 144 -23 air
execute in minecraft:overworld run fill 391 58 -22 391 65 -22 stone
execute in minecraft:overworld run fill 391 66 -22 391 67 -22 dirt
execute in minecraft:overworld run setblock 391 68 -22 coarse_dirt
execute in minecraft:overworld run fill 391 69 -22 391 144 -22 air
execute in minecraft:overworld run fill 391 58 -21 391 64 -21 stone
execute in minecraft:overworld run fill 391 65 -21 391 66 -21 dirt
execute in minecraft:overworld run setblock 391 67 -21 coarse_dirt
execute in minecraft:overworld run fill 391 68 -21 391 144 -21 air
execute in minecraft:overworld run fill 391 58 -20 391 63 -20 stone
execute in minecraft:overworld run fill 391 64 -20 391 65 -20 dirt
execute in minecraft:overworld run setblock 391 66 -20 coarse_dirt
execute in minecraft:overworld run fill 391 67 -20 391 144 -20 air
execute in minecraft:overworld run fill 391 58 -19 391 62 -19 stone
execute in minecraft:overworld run fill 391 63 -19 391 64 -19 dirt
execute in minecraft:overworld run setblock 391 65 -19 coarse_dirt
execute in minecraft:overworld run fill 391 66 -19 391 144 -19 air
execute in minecraft:overworld run fill 391 58 -18 391 61 -18 stone
execute in minecraft:overworld run fill 391 62 -18 391 63 -18 dirt
execute in minecraft:overworld run setblock 391 64 -18 coarse_dirt
schedule function blade_gallery:random/battlefield/part_86 1t replace
