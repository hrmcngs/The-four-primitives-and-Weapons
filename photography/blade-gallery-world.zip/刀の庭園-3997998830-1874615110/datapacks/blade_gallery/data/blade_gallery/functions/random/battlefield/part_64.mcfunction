execute in minecraft:overworld run fill 377 58 22 377 68 22 stone
execute in minecraft:overworld run fill 377 69 22 377 70 22 dirt
execute in minecraft:overworld run setblock 377 71 22 coarse_dirt
execute in minecraft:overworld run fill 377 72 22 377 144 22 air
execute in minecraft:overworld run setblock 377 72 22 grass
execute in minecraft:overworld run fill 377 58 23 377 67 23 stone
execute in minecraft:overworld run fill 377 68 23 377 69 23 dirt
execute in minecraft:overworld run setblock 377 70 23 grass_block
execute in minecraft:overworld run fill 377 71 23 377 144 23 air
execute in minecraft:overworld run fill 377 58 24 377 67 24 stone
execute in minecraft:overworld run fill 377 68 24 377 69 24 dirt
execute in minecraft:overworld run setblock 377 70 24 grass_block
execute in minecraft:overworld run fill 377 71 24 377 144 24 air
execute in minecraft:overworld run fill 377 58 25 377 67 25 stone
execute in minecraft:overworld run fill 377 68 25 377 69 25 dirt
execute in minecraft:overworld run setblock 377 70 25 grass_block
execute in minecraft:overworld run fill 377 71 25 377 144 25 air
execute in minecraft:overworld run fill 377 58 26 377 67 26 stone
execute in minecraft:overworld run fill 377 68 26 377 69 26 dirt
execute in minecraft:overworld run setblock 377 70 26 grass_block
execute in minecraft:overworld run fill 377 71 26 377 144 26 air
execute in minecraft:overworld run setblock 377 71 26 grass
execute in minecraft:overworld run fill 377 58 27 377 67 27 stone
execute in minecraft:overworld run fill 377 68 27 377 69 27 dirt
execute in minecraft:overworld run setblock 377 70 27 coarse_dirt
execute in minecraft:overworld run fill 377 71 27 377 144 27 air
execute in minecraft:overworld run fill 377 58 28 377 67 28 stone
execute in minecraft:overworld run fill 377 68 28 377 69 28 dirt
execute in minecraft:overworld run setblock 377 70 28 grass_block
execute in minecraft:overworld run fill 377 71 28 377 144 28 air
execute in minecraft:overworld run fill 377 58 29 377 67 29 stone
execute in minecraft:overworld run fill 377 68 29 377 69 29 dirt
execute in minecraft:overworld run setblock 377 70 29 coarse_dirt
execute in minecraft:overworld run fill 377 71 29 377 144 29 air
execute in minecraft:overworld run fill 377 58 30 377 67 30 stone
execute in minecraft:overworld run fill 377 68 30 377 69 30 dirt
execute in minecraft:overworld run setblock 377 70 30 grass_block
execute in minecraft:overworld run fill 377 71 30 377 144 30 air
execute in minecraft:overworld run fill 377 58 31 377 67 31 stone
execute in minecraft:overworld run fill 377 68 31 377 69 31 dirt
execute in minecraft:overworld run setblock 377 70 31 coarse_dirt
execute in minecraft:overworld run fill 377 71 31 377 144 31 air
execute in minecraft:overworld run setblock 377 71 31 grass
execute in minecraft:overworld run fill 377 58 32 377 67 32 stone
execute in minecraft:overworld run fill 377 68 32 377 69 32 dirt
execute in minecraft:overworld run setblock 377 70 32 grass_block
execute in minecraft:overworld run fill 377 71 32 377 144 32 air
execute in minecraft:overworld run setblock 377 71 32 grass
execute in minecraft:overworld run fill 377 58 33 377 67 33 stone
execute in minecraft:overworld run fill 377 68 33 377 69 33 dirt
execute in minecraft:overworld run setblock 377 70 33 grass_block
execute in minecraft:overworld run fill 377 71 33 377 144 33 air
execute in minecraft:overworld run fill 377 58 34 377 67 34 stone
execute in minecraft:overworld run fill 377 68 34 377 69 34 dirt
execute in minecraft:overworld run setblock 377 70 34 coarse_dirt
execute in minecraft:overworld run fill 377 71 34 377 144 34 air
execute in minecraft:overworld run fill 377 58 35 377 67 35 stone
execute in minecraft:overworld run fill 377 68 35 377 69 35 dirt
execute in minecraft:overworld run setblock 377 70 35 grass_block
execute in minecraft:overworld run fill 377 71 35 377 144 35 air
execute in minecraft:overworld run setblock 377 71 35 mossy_cobblestone
execute in minecraft:overworld run fill 377 58 36 377 67 36 stone
execute in minecraft:overworld run fill 377 68 36 377 69 36 dirt
execute in minecraft:overworld run setblock 377 70 36 grass_block
execute in minecraft:overworld run fill 377 71 36 377 144 36 air
execute in minecraft:overworld run fill 377 58 37 377 67 37 stone
execute in minecraft:overworld run fill 377 68 37 377 69 37 dirt
execute in minecraft:overworld run setblock 377 70 37 coarse_dirt
execute in minecraft:overworld run fill 377 71 37 377 144 37 air
execute in minecraft:overworld run fill 377 58 38 377 67 38 stone
execute in minecraft:overworld run fill 377 68 38 377 69 38 dirt
execute in minecraft:overworld run setblock 377 70 38 coarse_dirt
execute in minecraft:overworld run fill 377 71 38 377 144 38 air
execute in minecraft:overworld run fill 377 58 39 377 66 39 stone
execute in minecraft:overworld run fill 377 67 39 377 68 39 dirt
execute in minecraft:overworld run setblock 377 69 39 grass_block
execute in minecraft:overworld run fill 377 70 39 377 144 39 air
execute in minecraft:overworld run fill 377 58 40 377 66 40 stone
execute in minecraft:overworld run fill 377 67 40 377 68 40 dirt
execute in minecraft:overworld run setblock 377 69 40 coarse_dirt
execute in minecraft:overworld run fill 377 70 40 377 144 40 air
execute in minecraft:overworld run fill 377 58 41 377 65 41 stone
execute in minecraft:overworld run fill 377 66 41 377 67 41 dirt
execute in minecraft:overworld run setblock 377 68 41 coarse_dirt
execute in minecraft:overworld run fill 377 69 41 377 144 41 air
execute in minecraft:overworld run fill 377 58 42 377 64 42 stone
execute in minecraft:overworld run fill 377 65 42 377 66 42 dirt
execute in minecraft:overworld run setblock 377 67 42 grass_block
execute in minecraft:overworld run fill 377 68 42 377 144 42 air
execute in minecraft:overworld run fill 377 58 43 377 63 43 stone
execute in minecraft:overworld run fill 377 64 43 377 65 43 dirt
execute in minecraft:overworld run setblock 377 66 43 coarse_dirt
execute in minecraft:overworld run fill 377 67 43 377 144 43 air
execute in minecraft:overworld run fill 377 58 44 377 63 44 stone
execute in minecraft:overworld run fill 377 64 44 377 65 44 dirt
execute in minecraft:overworld run setblock 377 66 44 coarse_dirt
execute in minecraft:overworld run fill 377 67 44 377 144 44 air
execute in minecraft:overworld run fill 377 58 45 377 62 45 stone
execute in minecraft:overworld run fill 377 63 45 377 64 45 dirt
execute in minecraft:overworld run setblock 377 65 45 coarse_dirt
execute in minecraft:overworld run fill 377 66 45 377 144 45 air
execute in minecraft:overworld run fill 377 58 46 377 62 46 stone
execute in minecraft:overworld run fill 377 63 46 377 64 46 dirt
execute in minecraft:overworld run setblock 377 65 46 grass_block
execute in minecraft:overworld run fill 377 66 46 377 144 46 air
execute in minecraft:overworld run fill 377 58 47 377 61 47 stone
execute in minecraft:overworld run fill 377 62 47 377 63 47 dirt
execute in minecraft:overworld run setblock 377 64 47 grass_block
execute in minecraft:overworld run fill 377 65 47 377 144 47 air
execute in minecraft:overworld run fill 378 58 -48 378 61 -48 stone
execute in minecraft:overworld run fill 378 62 -48 378 63 -48 dirt
execute in minecraft:overworld run setblock 378 64 -48 coarse_dirt
execute in minecraft:overworld run fill 378 65 -48 378 144 -48 air
execute in minecraft:overworld run fill 378 58 -47 378 62 -47 stone
execute in minecraft:overworld run fill 378 63 -47 378 64 -47 dirt
execute in minecraft:overworld run setblock 378 65 -47 grass_block
execute in minecraft:overworld run fill 378 66 -47 378 144 -47 air
execute in minecraft:overworld run fill 378 58 -46 378 63 -46 stone
execute in minecraft:overworld run fill 378 64 -46 378 65 -46 dirt
execute in minecraft:overworld run setblock 378 66 -46 grass_block
execute in minecraft:overworld run fill 378 67 -46 378 144 -46 air
execute in minecraft:overworld run fill 378 58 -45 378 64 -45 stone
execute in minecraft:overworld run fill 378 65 -45 378 66 -45 dirt
execute in minecraft:overworld run setblock 378 67 -45 coarse_dirt
execute in minecraft:overworld run fill 378 68 -45 378 144 -45 air
execute in minecraft:overworld run fill 378 58 -44 378 65 -44 stone
execute in minecraft:overworld run fill 378 66 -44 378 67 -44 dirt
execute in minecraft:overworld run setblock 378 68 -44 grass_block
execute in minecraft:overworld run fill 378 69 -44 378 144 -44 air
execute in minecraft:overworld run fill 378 58 -43 378 65 -43 stone
execute in minecraft:overworld run fill 378 66 -43 378 67 -43 dirt
execute in minecraft:overworld run setblock 378 68 -43 coarse_dirt
execute in minecraft:overworld run fill 378 69 -43 378 144 -43 air
execute in minecraft:overworld run fill 378 58 -42 378 66 -42 stone
execute in minecraft:overworld run fill 378 67 -42 378 68 -42 dirt
execute in minecraft:overworld run setblock 378 69 -42 coarse_dirt
execute in minecraft:overworld run fill 378 70 -42 378 144 -42 air
execute in minecraft:overworld run fill 378 58 -41 378 66 -41 stone
execute in minecraft:overworld run fill 378 67 -41 378 68 -41 dirt
execute in minecraft:overworld run setblock 378 69 -41 coarse_dirt
execute in minecraft:overworld run fill 378 70 -41 378 144 -41 air
execute in minecraft:overworld run fill 378 58 -40 378 66 -40 stone
execute in minecraft:overworld run fill 378 67 -40 378 68 -40 dirt
execute in minecraft:overworld run setblock 378 69 -40 coarse_dirt
execute in minecraft:overworld run fill 378 70 -40 378 144 -40 air
execute in minecraft:overworld run setblock 378 70 -40 mossy_cobblestone
execute in minecraft:overworld run fill 378 58 -39 378 66 -39 stone
execute in minecraft:overworld run fill 378 67 -39 378 68 -39 dirt
execute in minecraft:overworld run setblock 378 69 -39 coarse_dirt
execute in minecraft:overworld run fill 378 70 -39 378 144 -39 air
execute in minecraft:overworld run fill 378 58 -38 378 66 -38 stone
execute in minecraft:overworld run fill 378 67 -38 378 68 -38 dirt
execute in minecraft:overworld run setblock 378 69 -38 grass_block
execute in minecraft:overworld run fill 378 70 -38 378 144 -38 air
execute in minecraft:overworld run fill 378 58 -37 378 65 -37 stone
execute in minecraft:overworld run fill 378 66 -37 378 67 -37 dirt
execute in minecraft:overworld run setblock 378 68 -37 grass_block
execute in minecraft:overworld run fill 378 69 -37 378 144 -37 air
execute in minecraft:overworld run setblock 378 69 -37 grass
execute in minecraft:overworld run fill 378 58 -36 378 65 -36 stone
execute in minecraft:overworld run fill 378 66 -36 378 67 -36 dirt
execute in minecraft:overworld run setblock 378 68 -36 coarse_dirt
execute in minecraft:overworld run fill 378 69 -36 378 144 -36 air
execute in minecraft:overworld run fill 378 58 -35 378 65 -35 stone
execute in minecraft:overworld run fill 378 66 -35 378 67 -35 dirt
execute in minecraft:overworld run setblock 378 68 -35 coarse_dirt
execute in minecraft:overworld run fill 378 69 -35 378 144 -35 air
execute in minecraft:overworld run fill 378 58 -34 378 64 -34 stone
execute in minecraft:overworld run fill 378 65 -34 378 66 -34 dirt
execute in minecraft:overworld run setblock 378 67 -34 coarse_dirt
execute in minecraft:overworld run fill 378 68 -34 378 144 -34 air
execute in minecraft:overworld run setblock 378 68 -34 grass
execute in minecraft:overworld run fill 378 58 -33 378 64 -33 stone
execute in minecraft:overworld run fill 378 65 -33 378 66 -33 dirt
execute in minecraft:overworld run setblock 378 67 -33 coarse_dirt
execute in minecraft:overworld run fill 378 68 -33 378 144 -33 air
execute in minecraft:overworld run fill 378 58 -32 378 64 -32 stone
execute in minecraft:overworld run fill 378 65 -32 378 66 -32 dirt
execute in minecraft:overworld run setblock 378 67 -32 coarse_dirt
execute in minecraft:overworld run fill 378 68 -32 378 144 -32 air
execute in minecraft:overworld run fill 378 58 -31 378 65 -31 stone
execute in minecraft:overworld run fill 378 66 -31 378 67 -31 dirt
execute in minecraft:overworld run setblock 378 68 -31 coarse_dirt
execute in minecraft:overworld run fill 378 69 -31 378 144 -31 air
execute in minecraft:overworld run fill 378 58 -30 378 65 -30 stone
execute in minecraft:overworld run fill 378 66 -30 378 67 -30 dirt
execute in minecraft:overworld run setblock 378 68 -30 grass_block
execute in minecraft:overworld run fill 378 69 -30 378 144 -30 air
execute in minecraft:overworld run fill 378 58 -29 378 65 -29 stone
execute in minecraft:overworld run fill 378 66 -29 378 67 -29 dirt
execute in minecraft:overworld run setblock 378 68 -29 grass_block
execute in minecraft:overworld run fill 378 69 -29 378 144 -29 air
execute in minecraft:overworld run fill 378 58 -28 378 65 -28 stone
execute in minecraft:overworld run fill 378 66 -28 378 67 -28 dirt
execute in minecraft:overworld run setblock 378 68 -28 coarse_dirt
execute in minecraft:overworld run fill 378 69 -28 378 144 -28 air
execute in minecraft:overworld run fill 378 58 -27 378 65 -27 stone
execute in minecraft:overworld run fill 378 66 -27 378 67 -27 dirt
execute in minecraft:overworld run setblock 378 68 -27 grass_block
execute in minecraft:overworld run fill 378 69 -27 378 144 -27 air
execute in minecraft:overworld run fill 378 58 -26 378 65 -26 stone
execute in minecraft:overworld run fill 378 66 -26 378 67 -26 dirt
execute in minecraft:overworld run setblock 378 68 -26 coarse_dirt
execute in minecraft:overworld run fill 378 69 -26 378 144 -26 air
execute in minecraft:overworld run fill 378 58 -25 378 65 -25 stone
execute in minecraft:overworld run fill 378 66 -25 378 67 -25 dirt
execute in minecraft:overworld run setblock 378 68 -25 grass_block
execute in minecraft:overworld run fill 378 69 -25 378 144 -25 air
execute in minecraft:overworld run fill 378 58 -24 378 65 -24 stone
execute in minecraft:overworld run fill 378 66 -24 378 67 -24 dirt
execute in minecraft:overworld run setblock 378 68 -24 coarse_dirt
execute in minecraft:overworld run fill 378 69 -24 378 144 -24 air
execute in minecraft:overworld run setblock 378 69 -24 grass
execute in minecraft:overworld run fill 378 58 -23 378 64 -23 stone
execute in minecraft:overworld run fill 378 65 -23 378 66 -23 dirt
execute in minecraft:overworld run setblock 378 67 -23 grass_block
execute in minecraft:overworld run fill 378 68 -23 378 144 -23 air
execute in minecraft:overworld run fill 378 58 -22 378 64 -22 stone
execute in minecraft:overworld run fill 378 65 -22 378 66 -22 dirt
execute in minecraft:overworld run setblock 378 67 -22 grass_block
execute in minecraft:overworld run fill 378 68 -22 378 144 -22 air
execute in minecraft:overworld run fill 378 58 -21 378 64 -21 stone
execute in minecraft:overworld run fill 378 65 -21 378 66 -21 dirt
execute in minecraft:overworld run setblock 378 67 -21 grass_block
execute in minecraft:overworld run fill 378 68 -21 378 144 -21 air
execute in minecraft:overworld run fill 378 58 -20 378 64 -20 stone
execute in minecraft:overworld run fill 378 65 -20 378 66 -20 dirt
execute in minecraft:overworld run setblock 378 67 -20 coarse_dirt
execute in minecraft:overworld run fill 378 68 -20 378 144 -20 air
execute in minecraft:overworld run fill 378 58 -19 378 63 -19 stone
execute in minecraft:overworld run fill 378 64 -19 378 65 -19 dirt
execute in minecraft:overworld run setblock 378 66 -19 coarse_dirt
execute in minecraft:overworld run fill 378 67 -19 378 144 -19 air
execute in minecraft:overworld run fill 378 58 -18 378 63 -18 stone
execute in minecraft:overworld run fill 378 64 -18 378 65 -18 dirt
execute in minecraft:overworld run setblock 378 66 -18 coarse_dirt
execute in minecraft:overworld run fill 378 67 -18 378 144 -18 air
execute in minecraft:overworld run fill 378 58 -17 378 63 -17 stone
execute in minecraft:overworld run fill 378 64 -17 378 65 -17 dirt
execute in minecraft:overworld run setblock 378 66 -17 coarse_dirt
execute in minecraft:overworld run fill 378 67 -17 378 144 -17 air
execute in minecraft:overworld run setblock 378 67 -17 grass
execute in minecraft:overworld run fill 378 58 -16 378 63 -16 stone
execute in minecraft:overworld run fill 378 64 -16 378 65 -16 dirt
execute in minecraft:overworld run setblock 378 66 -16 coarse_dirt
execute in minecraft:overworld run fill 378 67 -16 378 144 -16 air
execute in minecraft:overworld run fill 378 58 -15 378 63 -15 stone
execute in minecraft:overworld run fill 378 64 -15 378 65 -15 dirt
execute in minecraft:overworld run setblock 378 66 -15 coarse_dirt
execute in minecraft:overworld run fill 378 67 -15 378 144 -15 air
execute in minecraft:overworld run fill 378 58 -14 378 64 -14 stone
execute in minecraft:overworld run fill 378 65 -14 378 66 -14 dirt
execute in minecraft:overworld run setblock 378 67 -14 coarse_dirt
execute in minecraft:overworld run fill 378 68 -14 378 144 -14 air
execute in minecraft:overworld run fill 378 58 -13 378 64 -13 stone
execute in minecraft:overworld run fill 378 65 -13 378 66 -13 dirt
schedule function blade_gallery:random/battlefield/part_65 1t replace
