execute in minecraft:overworld run setblock 337 65 -17 coarse_dirt
execute in minecraft:overworld run fill 337 66 -17 337 144 -17 air
execute in minecraft:overworld run fill 337 58 -16 337 62 -16 stone
execute in minecraft:overworld run fill 337 63 -16 337 64 -16 dirt
execute in minecraft:overworld run setblock 337 65 -16 coarse_dirt
execute in minecraft:overworld run fill 337 66 -16 337 144 -16 air
execute in minecraft:overworld run fill 337 58 -15 337 62 -15 stone
execute in minecraft:overworld run fill 337 63 -15 337 64 -15 dirt
execute in minecraft:overworld run setblock 337 65 -15 coarse_dirt
execute in minecraft:overworld run fill 337 66 -15 337 144 -15 air
execute in minecraft:overworld run fill 337 58 -14 337 62 -14 stone
execute in minecraft:overworld run fill 337 63 -14 337 64 -14 dirt
execute in minecraft:overworld run setblock 337 65 -14 coarse_dirt
execute in minecraft:overworld run fill 337 66 -14 337 144 -14 air
execute in minecraft:overworld run fill 337 58 -13 337 62 -13 stone
execute in minecraft:overworld run fill 337 63 -13 337 64 -13 dirt
execute in minecraft:overworld run setblock 337 65 -13 coarse_dirt
execute in minecraft:overworld run fill 337 66 -13 337 144 -13 air
execute in minecraft:overworld run fill 337 58 -12 337 62 -12 stone
execute in minecraft:overworld run fill 337 63 -12 337 64 -12 dirt
execute in minecraft:overworld run setblock 337 65 -12 coarse_dirt
execute in minecraft:overworld run fill 337 66 -12 337 144 -12 air
execute in minecraft:overworld run fill 337 58 -11 337 62 -11 stone
execute in minecraft:overworld run fill 337 63 -11 337 64 -11 dirt
execute in minecraft:overworld run setblock 337 65 -11 coarse_dirt
execute in minecraft:overworld run fill 337 66 -11 337 144 -11 air
execute in minecraft:overworld run fill 337 58 -10 337 62 -10 stone
execute in minecraft:overworld run fill 337 63 -10 337 64 -10 dirt
execute in minecraft:overworld run setblock 337 65 -10 coarse_dirt
execute in minecraft:overworld run fill 337 66 -10 337 144 -10 air
execute in minecraft:overworld run fill 337 58 -9 337 62 -9 stone
execute in minecraft:overworld run fill 337 63 -9 337 64 -9 dirt
execute in minecraft:overworld run setblock 337 65 -9 coarse_dirt
execute in minecraft:overworld run fill 337 66 -9 337 144 -9 air
execute in minecraft:overworld run fill 337 58 -8 337 62 -8 stone
execute in minecraft:overworld run fill 337 63 -8 337 64 -8 dirt
execute in minecraft:overworld run setblock 337 65 -8 coarse_dirt
execute in minecraft:overworld run fill 337 66 -8 337 144 -8 air
execute in minecraft:overworld run fill 337 58 -7 337 62 -7 stone
execute in minecraft:overworld run fill 337 63 -7 337 64 -7 dirt
execute in minecraft:overworld run setblock 337 65 -7 coarse_dirt
execute in minecraft:overworld run fill 337 66 -7 337 144 -7 air
execute in minecraft:overworld run fill 337 58 -6 337 62 -6 stone
execute in minecraft:overworld run fill 337 63 -6 337 64 -6 dirt
execute in minecraft:overworld run setblock 337 65 -6 coarse_dirt
execute in minecraft:overworld run fill 337 66 -6 337 144 -6 air
execute in minecraft:overworld run fill 337 58 -5 337 62 -5 stone
execute in minecraft:overworld run fill 337 63 -5 337 64 -5 dirt
execute in minecraft:overworld run setblock 337 65 -5 coarse_dirt
execute in minecraft:overworld run fill 337 66 -5 337 144 -5 air
execute in minecraft:overworld run fill 337 58 -4 337 62 -4 stone
execute in minecraft:overworld run fill 337 63 -4 337 64 -4 dirt
execute in minecraft:overworld run setblock 337 65 -4 coarse_dirt
execute in minecraft:overworld run fill 337 66 -4 337 144 -4 air
execute in minecraft:overworld run fill 337 58 -3 337 62 -3 stone
execute in minecraft:overworld run fill 337 63 -3 337 64 -3 dirt
execute in minecraft:overworld run setblock 337 65 -3 coarse_dirt
execute in minecraft:overworld run fill 337 66 -3 337 144 -3 air
execute in minecraft:overworld run fill 337 58 -2 337 62 -2 stone
execute in minecraft:overworld run fill 337 63 -2 337 64 -2 dirt
execute in minecraft:overworld run setblock 337 65 -2 grass_block
execute in minecraft:overworld run fill 337 66 -2 337 144 -2 air
execute in minecraft:overworld run fill 337 58 -1 337 62 -1 stone
execute in minecraft:overworld run fill 337 63 -1 337 64 -1 dirt
execute in minecraft:overworld run setblock 337 65 -1 coarse_dirt
execute in minecraft:overworld run fill 337 66 -1 337 144 -1 air
execute in minecraft:overworld run fill 337 58 0 337 62 0 stone
execute in minecraft:overworld run fill 337 63 0 337 64 0 dirt
execute in minecraft:overworld run setblock 337 65 0 coarse_dirt
execute in minecraft:overworld run fill 337 66 0 337 144 0 air
execute in minecraft:overworld run fill 337 58 1 337 62 1 stone
execute in minecraft:overworld run fill 337 63 1 337 64 1 dirt
execute in minecraft:overworld run setblock 337 65 1 coarse_dirt
execute in minecraft:overworld run fill 337 66 1 337 144 1 air
execute in minecraft:overworld run fill 337 58 2 337 62 2 stone
execute in minecraft:overworld run fill 337 63 2 337 64 2 dirt
execute in minecraft:overworld run setblock 337 65 2 coarse_dirt
execute in minecraft:overworld run fill 337 66 2 337 144 2 air
execute in minecraft:overworld run fill 337 58 3 337 62 3 stone
execute in minecraft:overworld run fill 337 63 3 337 64 3 dirt
execute in minecraft:overworld run setblock 337 65 3 grass_block
execute in minecraft:overworld run fill 337 66 3 337 144 3 air
execute in minecraft:overworld run fill 337 58 4 337 62 4 stone
execute in minecraft:overworld run fill 337 63 4 337 64 4 dirt
execute in minecraft:overworld run setblock 337 65 4 coarse_dirt
execute in minecraft:overworld run fill 337 66 4 337 144 4 air
execute in minecraft:overworld run fill 337 58 5 337 62 5 stone
execute in minecraft:overworld run fill 337 63 5 337 64 5 dirt
execute in minecraft:overworld run setblock 337 65 5 coarse_dirt
execute in minecraft:overworld run fill 337 66 5 337 144 5 air
execute in minecraft:overworld run fill 337 58 6 337 62 6 stone
execute in minecraft:overworld run fill 337 63 6 337 64 6 dirt
execute in minecraft:overworld run setblock 337 65 6 coarse_dirt
execute in minecraft:overworld run fill 337 66 6 337 144 6 air
execute in minecraft:overworld run fill 337 58 7 337 62 7 stone
execute in minecraft:overworld run fill 337 63 7 337 64 7 dirt
execute in minecraft:overworld run setblock 337 65 7 coarse_dirt
execute in minecraft:overworld run fill 337 66 7 337 144 7 air
execute in minecraft:overworld run fill 337 58 8 337 62 8 stone
execute in minecraft:overworld run fill 337 63 8 337 64 8 dirt
execute in minecraft:overworld run setblock 337 65 8 coarse_dirt
execute in minecraft:overworld run fill 337 66 8 337 144 8 air
execute in minecraft:overworld run fill 337 58 9 337 62 9 stone
execute in minecraft:overworld run fill 337 63 9 337 64 9 dirt
execute in minecraft:overworld run setblock 337 65 9 coarse_dirt
execute in minecraft:overworld run fill 337 66 9 337 144 9 air
execute in minecraft:overworld run fill 337 58 10 337 62 10 stone
execute in minecraft:overworld run fill 337 63 10 337 64 10 dirt
execute in minecraft:overworld run setblock 337 65 10 coarse_dirt
execute in minecraft:overworld run fill 337 66 10 337 144 10 air
execute in minecraft:overworld run fill 337 58 11 337 61 11 stone
execute in minecraft:overworld run fill 337 62 11 337 63 11 dirt
execute in minecraft:overworld run setblock 337 64 11 grass_block
execute in minecraft:overworld run fill 337 65 11 337 144 11 air
execute in minecraft:overworld run fill 337 58 12 337 61 12 stone
execute in minecraft:overworld run fill 337 62 12 337 63 12 dirt
execute in minecraft:overworld run setblock 337 64 12 coarse_dirt
execute in minecraft:overworld run fill 337 65 12 337 144 12 air
execute in minecraft:overworld run fill 337 58 13 337 61 13 stone
execute in minecraft:overworld run fill 337 62 13 337 63 13 dirt
execute in minecraft:overworld run setblock 337 64 13 coarse_dirt
execute in minecraft:overworld run fill 337 65 13 337 144 13 air
execute in minecraft:overworld run fill 337 58 14 337 61 14 stone
execute in minecraft:overworld run fill 337 62 14 337 63 14 dirt
execute in minecraft:overworld run setblock 337 64 14 grass_block
execute in minecraft:overworld run fill 337 65 14 337 144 14 air
execute in minecraft:overworld run fill 337 58 15 337 61 15 stone
execute in minecraft:overworld run fill 337 62 15 337 63 15 dirt
execute in minecraft:overworld run setblock 337 64 15 grass_block
execute in minecraft:overworld run fill 337 65 15 337 144 15 air
execute in minecraft:overworld run fill 337 58 16 337 61 16 stone
execute in minecraft:overworld run fill 337 62 16 337 63 16 dirt
execute in minecraft:overworld run setblock 337 64 16 coarse_dirt
execute in minecraft:overworld run fill 337 65 16 337 144 16 air
execute in minecraft:overworld run fill 337 58 17 337 61 17 stone
execute in minecraft:overworld run fill 337 62 17 337 63 17 dirt
execute in minecraft:overworld run setblock 337 64 17 coarse_dirt
execute in minecraft:overworld run fill 337 65 17 337 144 17 air
execute in minecraft:overworld run fill 337 58 18 337 61 18 stone
execute in minecraft:overworld run fill 337 62 18 337 63 18 dirt
execute in minecraft:overworld run setblock 337 64 18 coarse_dirt
execute in minecraft:overworld run fill 337 65 18 337 144 18 air
execute in minecraft:overworld run fill 337 58 19 337 61 19 stone
execute in minecraft:overworld run fill 337 62 19 337 63 19 dirt
execute in minecraft:overworld run setblock 337 64 19 coarse_dirt
execute in minecraft:overworld run fill 337 65 19 337 144 19 air
execute in minecraft:overworld run fill 337 58 20 337 61 20 stone
execute in minecraft:overworld run fill 337 62 20 337 63 20 dirt
execute in minecraft:overworld run setblock 337 64 20 coarse_dirt
execute in minecraft:overworld run fill 337 65 20 337 144 20 air
execute in minecraft:overworld run fill 337 58 21 337 61 21 stone
execute in minecraft:overworld run fill 337 62 21 337 63 21 dirt
execute in minecraft:overworld run setblock 337 64 21 coarse_dirt
execute in minecraft:overworld run fill 337 65 21 337 144 21 air
execute in minecraft:overworld run fill 337 58 22 337 61 22 stone
execute in minecraft:overworld run fill 337 62 22 337 63 22 dirt
execute in minecraft:overworld run setblock 337 64 22 coarse_dirt
execute in minecraft:overworld run fill 337 65 22 337 144 22 air
execute in minecraft:overworld run fill 337 58 23 337 61 23 stone
execute in minecraft:overworld run fill 337 62 23 337 63 23 dirt
execute in minecraft:overworld run setblock 337 64 23 coarse_dirt
execute in minecraft:overworld run fill 337 65 23 337 144 23 air
execute in minecraft:overworld run fill 337 58 24 337 61 24 stone
execute in minecraft:overworld run fill 337 62 24 337 63 24 dirt
execute in minecraft:overworld run setblock 337 64 24 coarse_dirt
execute in minecraft:overworld run fill 337 65 24 337 144 24 air
execute in minecraft:overworld run fill 337 58 25 337 61 25 stone
execute in minecraft:overworld run fill 337 62 25 337 63 25 dirt
execute in minecraft:overworld run setblock 337 64 25 coarse_dirt
execute in minecraft:overworld run fill 337 65 25 337 144 25 air
execute in minecraft:overworld run fill 337 58 26 337 61 26 stone
execute in minecraft:overworld run fill 337 62 26 337 63 26 dirt
execute in minecraft:overworld run setblock 337 64 26 coarse_dirt
execute in minecraft:overworld run fill 337 65 26 337 144 26 air
execute in minecraft:overworld run fill 337 58 27 337 61 27 stone
execute in minecraft:overworld run fill 337 62 27 337 63 27 dirt
execute in minecraft:overworld run setblock 337 64 27 grass_block
execute in minecraft:overworld run fill 337 65 27 337 144 27 air
execute in minecraft:overworld run fill 337 58 28 337 61 28 stone
execute in minecraft:overworld run fill 337 62 28 337 63 28 dirt
execute in minecraft:overworld run setblock 337 64 28 coarse_dirt
execute in minecraft:overworld run fill 337 65 28 337 144 28 air
execute in minecraft:overworld run fill 337 58 29 337 61 29 stone
execute in minecraft:overworld run fill 337 62 29 337 63 29 dirt
execute in minecraft:overworld run setblock 337 64 29 coarse_dirt
execute in minecraft:overworld run fill 337 65 29 337 144 29 air
execute in minecraft:overworld run fill 337 58 30 337 61 30 stone
execute in minecraft:overworld run fill 337 62 30 337 63 30 dirt
execute in minecraft:overworld run setblock 337 64 30 coarse_dirt
execute in minecraft:overworld run fill 337 65 30 337 144 30 air
execute in minecraft:overworld run fill 337 58 31 337 61 31 stone
execute in minecraft:overworld run fill 337 62 31 337 63 31 dirt
execute in minecraft:overworld run setblock 337 64 31 grass_block
execute in minecraft:overworld run fill 337 65 31 337 144 31 air
execute in minecraft:overworld run fill 337 58 32 337 61 32 stone
execute in minecraft:overworld run fill 337 62 32 337 63 32 dirt
execute in minecraft:overworld run setblock 337 64 32 grass_block
execute in minecraft:overworld run fill 337 65 32 337 144 32 air
execute in minecraft:overworld run fill 337 58 33 337 61 33 stone
execute in minecraft:overworld run fill 337 62 33 337 63 33 dirt
execute in minecraft:overworld run setblock 337 64 33 coarse_dirt
execute in minecraft:overworld run fill 337 65 33 337 144 33 air
execute in minecraft:overworld run fill 337 58 34 337 61 34 stone
execute in minecraft:overworld run fill 337 62 34 337 63 34 dirt
execute in minecraft:overworld run setblock 337 64 34 grass_block
execute in minecraft:overworld run fill 337 65 34 337 144 34 air
execute in minecraft:overworld run fill 337 58 35 337 61 35 stone
execute in minecraft:overworld run fill 337 62 35 337 63 35 dirt
execute in minecraft:overworld run setblock 337 64 35 grass_block
execute in minecraft:overworld run fill 337 65 35 337 144 35 air
execute in minecraft:overworld run fill 337 58 36 337 61 36 stone
execute in minecraft:overworld run fill 337 62 36 337 63 36 dirt
execute in minecraft:overworld run setblock 337 64 36 coarse_dirt
execute in minecraft:overworld run fill 337 65 36 337 144 36 air
execute in minecraft:overworld run fill 337 58 37 337 61 37 stone
execute in minecraft:overworld run fill 337 62 37 337 63 37 dirt
execute in minecraft:overworld run setblock 337 64 37 coarse_dirt
execute in minecraft:overworld run fill 337 65 37 337 144 37 air
execute in minecraft:overworld run fill 337 58 38 337 61 38 stone
execute in minecraft:overworld run fill 337 62 38 337 63 38 dirt
execute in minecraft:overworld run setblock 337 64 38 coarse_dirt
execute in minecraft:overworld run fill 337 65 38 337 144 38 air
execute in minecraft:overworld run fill 337 58 39 337 61 39 stone
execute in minecraft:overworld run fill 337 62 39 337 63 39 dirt
execute in minecraft:overworld run setblock 337 64 39 grass_block
execute in minecraft:overworld run fill 337 65 39 337 144 39 air
execute in minecraft:overworld run fill 337 58 40 337 61 40 stone
execute in minecraft:overworld run fill 337 62 40 337 63 40 dirt
execute in minecraft:overworld run setblock 337 64 40 grass_block
execute in minecraft:overworld run fill 337 65 40 337 144 40 air
execute in minecraft:overworld run fill 337 58 41 337 61 41 stone
execute in minecraft:overworld run fill 337 62 41 337 63 41 dirt
execute in minecraft:overworld run setblock 337 64 41 coarse_dirt
execute in minecraft:overworld run fill 337 65 41 337 144 41 air
execute in minecraft:overworld run fill 337 58 42 337 61 42 stone
execute in minecraft:overworld run fill 337 62 42 337 63 42 dirt
execute in minecraft:overworld run setblock 337 64 42 coarse_dirt
execute in minecraft:overworld run fill 337 65 42 337 144 42 air
execute in minecraft:overworld run fill 337 58 43 337 61 43 stone
execute in minecraft:overworld run fill 337 62 43 337 63 43 dirt
execute in minecraft:overworld run setblock 337 64 43 grass_block
execute in minecraft:overworld run fill 337 65 43 337 144 43 air
execute in minecraft:overworld run fill 337 58 44 337 61 44 stone
execute in minecraft:overworld run fill 337 62 44 337 63 44 dirt
execute in minecraft:overworld run setblock 337 64 44 grass_block
execute in minecraft:overworld run fill 337 65 44 337 144 44 air
execute in minecraft:overworld run fill 337 58 45 337 61 45 stone
execute in minecraft:overworld run fill 337 62 45 337 63 45 dirt
execute in minecraft:overworld run setblock 337 64 45 grass_block
execute in minecraft:overworld run fill 337 65 45 337 144 45 air
execute in minecraft:overworld run fill 337 58 46 337 61 46 stone
execute in minecraft:overworld run fill 337 62 46 337 63 46 dirt
execute in minecraft:overworld run setblock 337 64 46 coarse_dirt
execute in minecraft:overworld run fill 337 65 46 337 144 46 air
execute in minecraft:overworld run fill 337 58 47 337 61 47 stone
execute in minecraft:overworld run fill 337 62 47 337 63 47 dirt
schedule function blade_gallery:random/battlefield/part_3 1t replace
