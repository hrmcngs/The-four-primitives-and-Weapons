execute in minecraft:overworld run fill 349 71 28 349 144 28 air
execute in minecraft:overworld run fill 349 58 29 349 67 29 stone
execute in minecraft:overworld run fill 349 68 29 349 69 29 dirt
execute in minecraft:overworld run setblock 349 70 29 coarse_dirt
execute in minecraft:overworld run fill 349 71 29 349 144 29 air
execute in minecraft:overworld run fill 349 58 30 349 67 30 stone
execute in minecraft:overworld run fill 349 68 30 349 69 30 dirt
execute in minecraft:overworld run setblock 349 70 30 grass_block
execute in minecraft:overworld run fill 349 71 30 349 144 30 air
execute in minecraft:overworld run fill 349 58 31 349 67 31 stone
execute in minecraft:overworld run fill 349 68 31 349 69 31 dirt
execute in minecraft:overworld run setblock 349 70 31 coarse_dirt
execute in minecraft:overworld run fill 349 71 31 349 144 31 air
execute in minecraft:overworld run fill 349 58 32 349 67 32 stone
execute in minecraft:overworld run fill 349 68 32 349 69 32 dirt
execute in minecraft:overworld run setblock 349 70 32 coarse_dirt
execute in minecraft:overworld run fill 349 71 32 349 144 32 air
execute in minecraft:overworld run fill 349 58 33 349 67 33 stone
execute in minecraft:overworld run fill 349 68 33 349 69 33 dirt
execute in minecraft:overworld run setblock 349 70 33 grass_block
execute in minecraft:overworld run fill 349 71 33 349 144 33 air
execute in minecraft:overworld run fill 349 58 34 349 66 34 stone
execute in minecraft:overworld run fill 349 67 34 349 68 34 dirt
execute in minecraft:overworld run setblock 349 69 34 coarse_dirt
execute in minecraft:overworld run fill 349 70 34 349 144 34 air
execute in minecraft:overworld run fill 349 58 35 349 66 35 stone
execute in minecraft:overworld run fill 349 67 35 349 68 35 dirt
execute in minecraft:overworld run setblock 349 69 35 grass_block
execute in minecraft:overworld run fill 349 70 35 349 144 35 air
execute in minecraft:overworld run fill 349 58 36 349 66 36 stone
execute in minecraft:overworld run fill 349 67 36 349 68 36 dirt
execute in minecraft:overworld run setblock 349 69 36 coarse_dirt
execute in minecraft:overworld run fill 349 70 36 349 144 36 air
execute in minecraft:overworld run fill 349 58 37 349 66 37 stone
execute in minecraft:overworld run fill 349 67 37 349 68 37 dirt
execute in minecraft:overworld run setblock 349 69 37 coarse_dirt
execute in minecraft:overworld run fill 349 70 37 349 144 37 air
execute in minecraft:overworld run fill 349 58 38 349 66 38 stone
execute in minecraft:overworld run fill 349 67 38 349 68 38 dirt
execute in minecraft:overworld run setblock 349 69 38 coarse_dirt
execute in minecraft:overworld run fill 349 70 38 349 144 38 air
execute in minecraft:overworld run fill 349 58 39 349 66 39 stone
execute in minecraft:overworld run fill 349 67 39 349 68 39 dirt
execute in minecraft:overworld run setblock 349 69 39 coarse_dirt
execute in minecraft:overworld run fill 349 70 39 349 144 39 air
execute in minecraft:overworld run fill 349 58 40 349 65 40 stone
execute in minecraft:overworld run fill 349 66 40 349 67 40 dirt
execute in minecraft:overworld run setblock 349 68 40 coarse_dirt
execute in minecraft:overworld run fill 349 69 40 349 144 40 air
execute in minecraft:overworld run fill 349 58 41 349 65 41 stone
execute in minecraft:overworld run fill 349 66 41 349 67 41 dirt
execute in minecraft:overworld run setblock 349 68 41 grass_block
execute in minecraft:overworld run fill 349 69 41 349 144 41 air
execute in minecraft:overworld run fill 349 58 42 349 64 42 stone
execute in minecraft:overworld run fill 349 65 42 349 66 42 dirt
execute in minecraft:overworld run setblock 349 67 42 coarse_dirt
execute in minecraft:overworld run fill 349 68 42 349 144 42 air
execute in minecraft:overworld run fill 349 58 43 349 64 43 stone
execute in minecraft:overworld run fill 349 65 43 349 66 43 dirt
execute in minecraft:overworld run setblock 349 67 43 coarse_dirt
execute in minecraft:overworld run fill 349 68 43 349 144 43 air
execute in minecraft:overworld run fill 349 58 44 349 63 44 stone
execute in minecraft:overworld run fill 349 64 44 349 65 44 dirt
execute in minecraft:overworld run setblock 349 66 44 coarse_dirt
execute in minecraft:overworld run fill 349 67 44 349 144 44 air
execute in minecraft:overworld run fill 349 58 45 349 63 45 stone
execute in minecraft:overworld run fill 349 64 45 349 65 45 dirt
execute in minecraft:overworld run setblock 349 66 45 coarse_dirt
execute in minecraft:overworld run fill 349 67 45 349 144 45 air
execute in minecraft:overworld run fill 349 58 46 349 62 46 stone
execute in minecraft:overworld run fill 349 63 46 349 64 46 dirt
execute in minecraft:overworld run setblock 349 65 46 coarse_dirt
execute in minecraft:overworld run fill 349 66 46 349 144 46 air
execute in minecraft:overworld run fill 349 58 47 349 62 47 stone
execute in minecraft:overworld run fill 349 63 47 349 64 47 dirt
execute in minecraft:overworld run setblock 349 65 47 coarse_dirt
execute in minecraft:overworld run fill 349 66 47 349 144 47 air
execute in minecraft:overworld run fill 350 58 -48 350 61 -48 stone
execute in minecraft:overworld run fill 350 62 -48 350 63 -48 dirt
execute in minecraft:overworld run setblock 350 64 -48 coarse_dirt
execute in minecraft:overworld run fill 350 65 -48 350 144 -48 air
execute in minecraft:overworld run fill 350 58 -47 350 63 -47 stone
execute in minecraft:overworld run fill 350 64 -47 350 65 -47 dirt
execute in minecraft:overworld run setblock 350 66 -47 coarse_dirt
execute in minecraft:overworld run fill 350 67 -47 350 144 -47 air
execute in minecraft:overworld run fill 350 58 -46 350 65 -46 stone
execute in minecraft:overworld run fill 350 66 -46 350 67 -46 dirt
execute in minecraft:overworld run setblock 350 68 -46 coarse_dirt
execute in minecraft:overworld run fill 350 69 -46 350 144 -46 air
execute in minecraft:overworld run fill 350 58 -45 350 67 -45 stone
execute in minecraft:overworld run fill 350 68 -45 350 69 -45 dirt
execute in minecraft:overworld run setblock 350 70 -45 coarse_dirt
execute in minecraft:overworld run fill 350 71 -45 350 144 -45 air
execute in minecraft:overworld run fill 350 58 -44 350 68 -44 stone
execute in minecraft:overworld run fill 350 69 -44 350 70 -44 dirt
execute in minecraft:overworld run setblock 350 71 -44 coarse_dirt
execute in minecraft:overworld run fill 350 72 -44 350 144 -44 air
execute in minecraft:overworld run fill 350 58 -43 350 70 -43 stone
execute in minecraft:overworld run fill 350 71 -43 350 72 -43 dirt
execute in minecraft:overworld run setblock 350 73 -43 coarse_dirt
execute in minecraft:overworld run fill 350 74 -43 350 144 -43 air
execute in minecraft:overworld run fill 350 58 -42 350 71 -42 stone
execute in minecraft:overworld run fill 350 72 -42 350 73 -42 dirt
execute in minecraft:overworld run setblock 350 74 -42 coarse_dirt
execute in minecraft:overworld run fill 350 75 -42 350 144 -42 air
execute in minecraft:overworld run fill 350 58 -41 350 73 -41 stone
execute in minecraft:overworld run fill 350 74 -41 350 75 -41 dirt
execute in minecraft:overworld run setblock 350 76 -41 coarse_dirt
execute in minecraft:overworld run fill 350 77 -41 350 144 -41 air
execute in minecraft:overworld run fill 350 58 -40 350 74 -40 stone
execute in minecraft:overworld run fill 350 75 -40 350 76 -40 dirt
execute in minecraft:overworld run setblock 350 77 -40 coarse_dirt
execute in minecraft:overworld run fill 350 78 -40 350 144 -40 air
execute in minecraft:overworld run fill 350 58 -39 350 75 -39 stone
execute in minecraft:overworld run fill 350 76 -39 350 77 -39 dirt
execute in minecraft:overworld run setblock 350 78 -39 grass_block
execute in minecraft:overworld run fill 350 79 -39 350 144 -39 air
execute in minecraft:overworld run fill 350 58 -38 350 76 -38 stone
execute in minecraft:overworld run fill 350 77 -38 350 78 -38 dirt
execute in minecraft:overworld run setblock 350 79 -38 coarse_dirt
execute in minecraft:overworld run fill 350 80 -38 350 144 -38 air
execute in minecraft:overworld run fill 350 58 -37 350 75 -37 stone
execute in minecraft:overworld run fill 350 76 -37 350 77 -37 dirt
execute in minecraft:overworld run setblock 350 78 -37 grass_block
execute in minecraft:overworld run fill 350 79 -37 350 144 -37 air
execute in minecraft:overworld run fill 350 58 -36 350 75 -36 stone
execute in minecraft:overworld run fill 350 76 -36 350 77 -36 dirt
execute in minecraft:overworld run setblock 350 78 -36 coarse_dirt
execute in minecraft:overworld run fill 350 79 -36 350 144 -36 air
execute in minecraft:overworld run fill 350 58 -35 350 74 -35 stone
execute in minecraft:overworld run fill 350 75 -35 350 76 -35 dirt
execute in minecraft:overworld run setblock 350 77 -35 coarse_dirt
execute in minecraft:overworld run fill 350 78 -35 350 144 -35 air
execute in minecraft:overworld run fill 350 58 -34 350 74 -34 stone
execute in minecraft:overworld run fill 350 75 -34 350 76 -34 dirt
execute in minecraft:overworld run setblock 350 77 -34 coarse_dirt
execute in minecraft:overworld run fill 350 78 -34 350 144 -34 air
execute in minecraft:overworld run fill 350 58 -33 350 74 -33 stone
execute in minecraft:overworld run fill 350 75 -33 350 76 -33 dirt
execute in minecraft:overworld run setblock 350 77 -33 coarse_dirt
execute in minecraft:overworld run fill 350 78 -33 350 144 -33 air
execute in minecraft:overworld run fill 350 58 -32 350 74 -32 stone
execute in minecraft:overworld run fill 350 75 -32 350 76 -32 dirt
execute in minecraft:overworld run setblock 350 77 -32 coarse_dirt
execute in minecraft:overworld run fill 350 78 -32 350 144 -32 air
execute in minecraft:overworld run fill 350 58 -31 350 74 -31 stone
execute in minecraft:overworld run fill 350 75 -31 350 76 -31 dirt
execute in minecraft:overworld run setblock 350 77 -31 coarse_dirt
execute in minecraft:overworld run fill 350 78 -31 350 144 -31 air
execute in minecraft:overworld run fill 350 58 -30 350 74 -30 stone
execute in minecraft:overworld run fill 350 75 -30 350 76 -30 dirt
execute in minecraft:overworld run setblock 350 77 -30 coarse_dirt
execute in minecraft:overworld run fill 350 78 -30 350 144 -30 air
execute in minecraft:overworld run fill 350 58 -29 350 73 -29 stone
execute in minecraft:overworld run fill 350 74 -29 350 75 -29 dirt
execute in minecraft:overworld run setblock 350 76 -29 coarse_dirt
execute in minecraft:overworld run fill 350 77 -29 350 144 -29 air
execute in minecraft:overworld run fill 350 58 -28 350 73 -28 stone
execute in minecraft:overworld run fill 350 74 -28 350 75 -28 dirt
execute in minecraft:overworld run setblock 350 76 -28 coarse_dirt
execute in minecraft:overworld run fill 350 77 -28 350 144 -28 air
execute in minecraft:overworld run fill 350 58 -27 350 73 -27 stone
execute in minecraft:overworld run fill 350 74 -27 350 75 -27 dirt
execute in minecraft:overworld run setblock 350 76 -27 coarse_dirt
execute in minecraft:overworld run fill 350 77 -27 350 144 -27 air
execute in minecraft:overworld run fill 350 58 -26 350 73 -26 stone
execute in minecraft:overworld run fill 350 74 -26 350 75 -26 dirt
execute in minecraft:overworld run setblock 350 76 -26 coarse_dirt
execute in minecraft:overworld run fill 350 77 -26 350 144 -26 air
execute in minecraft:overworld run fill 350 58 -25 350 72 -25 stone
execute in minecraft:overworld run fill 350 73 -25 350 74 -25 dirt
execute in minecraft:overworld run setblock 350 75 -25 coarse_dirt
execute in minecraft:overworld run fill 350 76 -25 350 144 -25 air
execute in minecraft:overworld run fill 350 58 -24 350 72 -24 stone
execute in minecraft:overworld run fill 350 73 -24 350 74 -24 dirt
execute in minecraft:overworld run setblock 350 75 -24 grass_block
execute in minecraft:overworld run fill 350 76 -24 350 144 -24 air
execute in minecraft:overworld run fill 350 58 -23 350 71 -23 stone
execute in minecraft:overworld run fill 350 72 -23 350 73 -23 dirt
execute in minecraft:overworld run setblock 350 74 -23 coarse_dirt
execute in minecraft:overworld run fill 350 75 -23 350 144 -23 air
execute in minecraft:overworld run fill 350 58 -22 350 71 -22 stone
execute in minecraft:overworld run fill 350 72 -22 350 73 -22 dirt
execute in minecraft:overworld run setblock 350 74 -22 grass_block
execute in minecraft:overworld run fill 350 75 -22 350 144 -22 air
execute in minecraft:overworld run fill 350 58 -21 350 71 -21 stone
execute in minecraft:overworld run fill 350 72 -21 350 73 -21 dirt
execute in minecraft:overworld run setblock 350 74 -21 coarse_dirt
execute in minecraft:overworld run fill 350 75 -21 350 144 -21 air
execute in minecraft:overworld run fill 350 58 -20 350 70 -20 stone
execute in minecraft:overworld run fill 350 71 -20 350 72 -20 dirt
execute in minecraft:overworld run setblock 350 73 -20 coarse_dirt
execute in minecraft:overworld run fill 350 74 -20 350 144 -20 air
execute in minecraft:overworld run fill 350 58 -19 350 70 -19 stone
execute in minecraft:overworld run fill 350 71 -19 350 72 -19 dirt
execute in minecraft:overworld run setblock 350 73 -19 coarse_dirt
execute in minecraft:overworld run fill 350 74 -19 350 144 -19 air
execute in minecraft:overworld run fill 350 58 -18 350 70 -18 stone
execute in minecraft:overworld run fill 350 71 -18 350 72 -18 dirt
execute in minecraft:overworld run setblock 350 73 -18 coarse_dirt
execute in minecraft:overworld run fill 350 74 -18 350 144 -18 air
execute in minecraft:overworld run fill 350 58 -17 350 69 -17 stone
execute in minecraft:overworld run fill 350 70 -17 350 71 -17 dirt
execute in minecraft:overworld run setblock 350 72 -17 coarse_dirt
execute in minecraft:overworld run fill 350 73 -17 350 144 -17 air
execute in minecraft:overworld run fill 350 58 -16 350 69 -16 stone
execute in minecraft:overworld run fill 350 70 -16 350 71 -16 dirt
execute in minecraft:overworld run setblock 350 72 -16 grass_block
execute in minecraft:overworld run fill 350 73 -16 350 144 -16 air
execute in minecraft:overworld run fill 350 58 -15 350 68 -15 stone
execute in minecraft:overworld run fill 350 69 -15 350 70 -15 dirt
execute in minecraft:overworld run setblock 350 71 -15 grass_block
execute in minecraft:overworld run fill 350 72 -15 350 144 -15 air
execute in minecraft:overworld run fill 350 58 -14 350 68 -14 stone
execute in minecraft:overworld run fill 350 69 -14 350 70 -14 dirt
execute in minecraft:overworld run setblock 350 71 -14 coarse_dirt
execute in minecraft:overworld run fill 350 72 -14 350 144 -14 air
execute in minecraft:overworld run setblock 350 72 -14 grass
execute in minecraft:overworld run fill 350 58 -13 350 67 -13 stone
execute in minecraft:overworld run fill 350 68 -13 350 69 -13 dirt
execute in minecraft:overworld run setblock 350 70 -13 coarse_dirt
execute in minecraft:overworld run fill 350 71 -13 350 144 -13 air
execute in minecraft:overworld run fill 350 58 -12 350 67 -12 stone
execute in minecraft:overworld run fill 350 68 -12 350 69 -12 dirt
execute in minecraft:overworld run setblock 350 70 -12 grass_block
execute in minecraft:overworld run fill 350 71 -12 350 144 -12 air
execute in minecraft:overworld run setblock 350 71 -12 mossy_cobblestone
execute in minecraft:overworld run fill 350 58 -11 350 67 -11 stone
execute in minecraft:overworld run fill 350 68 -11 350 69 -11 dirt
execute in minecraft:overworld run setblock 350 70 -11 grass_block
execute in minecraft:overworld run fill 350 71 -11 350 144 -11 air
execute in minecraft:overworld run fill 350 58 -10 350 67 -10 stone
execute in minecraft:overworld run fill 350 68 -10 350 69 -10 dirt
execute in minecraft:overworld run setblock 350 70 -10 coarse_dirt
execute in minecraft:overworld run fill 350 71 -10 350 144 -10 air
execute in minecraft:overworld run fill 350 58 -9 350 67 -9 stone
execute in minecraft:overworld run fill 350 68 -9 350 69 -9 dirt
execute in minecraft:overworld run setblock 350 70 -9 coarse_dirt
execute in minecraft:overworld run fill 350 71 -9 350 144 -9 air
execute in minecraft:overworld run fill 350 58 -8 350 67 -8 stone
execute in minecraft:overworld run fill 350 68 -8 350 69 -8 dirt
execute in minecraft:overworld run setblock 350 70 -8 coarse_dirt
execute in minecraft:overworld run fill 350 71 -8 350 144 -8 air
execute in minecraft:overworld run fill 350 58 -7 350 67 -7 stone
execute in minecraft:overworld run fill 350 68 -7 350 69 -7 dirt
execute in minecraft:overworld run setblock 350 70 -7 coarse_dirt
execute in minecraft:overworld run fill 350 71 -7 350 144 -7 air
execute in minecraft:overworld run fill 350 58 -6 350 67 -6 stone
execute in minecraft:overworld run fill 350 68 -6 350 69 -6 dirt
execute in minecraft:overworld run setblock 350 70 -6 coarse_dirt
execute in minecraft:overworld run fill 350 71 -6 350 144 -6 air
execute in minecraft:overworld run setblock 350 71 -6 grass
execute in minecraft:overworld run fill 350 58 -5 350 67 -5 stone
execute in minecraft:overworld run fill 350 68 -5 350 69 -5 dirt
execute in minecraft:overworld run setblock 350 70 -5 grass_block
execute in minecraft:overworld run fill 350 71 -5 350 144 -5 air
schedule function blade_gallery:random/battlefield/part_22 1t replace
