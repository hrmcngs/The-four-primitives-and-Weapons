execute in minecraft:overworld run fill 377 67 -40 377 68 -40 dirt
execute in minecraft:overworld run setblock 377 69 -40 grass_block
execute in minecraft:overworld run fill 377 70 -40 377 144 -40 air
execute in minecraft:overworld run fill 377 58 -39 377 66 -39 stone
execute in minecraft:overworld run fill 377 67 -39 377 68 -39 dirt
execute in minecraft:overworld run setblock 377 69 -39 coarse_dirt
execute in minecraft:overworld run fill 377 70 -39 377 144 -39 air
execute in minecraft:overworld run fill 377 58 -38 377 66 -38 stone
execute in minecraft:overworld run fill 377 67 -38 377 68 -38 dirt
execute in minecraft:overworld run setblock 377 69 -38 coarse_dirt
execute in minecraft:overworld run fill 377 70 -38 377 144 -38 air
execute in minecraft:overworld run fill 377 58 -37 377 65 -37 stone
execute in minecraft:overworld run fill 377 66 -37 377 67 -37 dirt
execute in minecraft:overworld run setblock 377 68 -37 grass_block
execute in minecraft:overworld run fill 377 69 -37 377 144 -37 air
execute in minecraft:overworld run fill 377 58 -36 377 65 -36 stone
execute in minecraft:overworld run fill 377 66 -36 377 67 -36 dirt
execute in minecraft:overworld run setblock 377 68 -36 grass_block
execute in minecraft:overworld run fill 377 69 -36 377 144 -36 air
execute in minecraft:overworld run setblock 377 69 -36 grass
execute in minecraft:overworld run fill 377 58 -35 377 65 -35 stone
execute in minecraft:overworld run fill 377 66 -35 377 67 -35 dirt
execute in minecraft:overworld run setblock 377 68 -35 coarse_dirt
execute in minecraft:overworld run fill 377 69 -35 377 144 -35 air
execute in minecraft:overworld run fill 377 58 -34 377 65 -34 stone
execute in minecraft:overworld run fill 377 66 -34 377 67 -34 dirt
execute in minecraft:overworld run setblock 377 68 -34 coarse_dirt
execute in minecraft:overworld run fill 377 69 -34 377 144 -34 air
execute in minecraft:overworld run fill 377 58 -33 377 65 -33 stone
execute in minecraft:overworld run fill 377 66 -33 377 67 -33 dirt
execute in minecraft:overworld run setblock 377 68 -33 coarse_dirt
execute in minecraft:overworld run fill 377 69 -33 377 144 -33 air
execute in minecraft:overworld run fill 377 58 -32 377 65 -32 stone
execute in minecraft:overworld run fill 377 66 -32 377 67 -32 dirt
execute in minecraft:overworld run setblock 377 68 -32 coarse_dirt
execute in minecraft:overworld run fill 377 69 -32 377 144 -32 air
execute in minecraft:overworld run fill 377 58 -31 377 65 -31 stone
execute in minecraft:overworld run fill 377 66 -31 377 67 -31 dirt
execute in minecraft:overworld run setblock 377 68 -31 coarse_dirt
execute in minecraft:overworld run fill 377 69 -31 377 144 -31 air
execute in minecraft:overworld run fill 377 58 -30 377 65 -30 stone
execute in minecraft:overworld run fill 377 66 -30 377 67 -30 dirt
execute in minecraft:overworld run setblock 377 68 -30 coarse_dirt
execute in minecraft:overworld run fill 377 69 -30 377 144 -30 air
execute in minecraft:overworld run fill 377 58 -29 377 66 -29 stone
execute in minecraft:overworld run fill 377 67 -29 377 68 -29 dirt
execute in minecraft:overworld run setblock 377 69 -29 grass_block
execute in minecraft:overworld run fill 377 70 -29 377 144 -29 air
execute in minecraft:overworld run fill 377 58 -28 377 66 -28 stone
execute in minecraft:overworld run fill 377 67 -28 377 68 -28 dirt
execute in minecraft:overworld run setblock 377 69 -28 coarse_dirt
execute in minecraft:overworld run fill 377 70 -28 377 144 -28 air
execute in minecraft:overworld run setblock 377 70 -28 grass
execute in minecraft:overworld run fill 377 58 -27 377 66 -27 stone
execute in minecraft:overworld run fill 377 67 -27 377 68 -27 dirt
execute in minecraft:overworld run setblock 377 69 -27 coarse_dirt
execute in minecraft:overworld run fill 377 70 -27 377 144 -27 air
execute in minecraft:overworld run fill 377 58 -26 377 66 -26 stone
execute in minecraft:overworld run fill 377 67 -26 377 68 -26 dirt
execute in minecraft:overworld run setblock 377 69 -26 coarse_dirt
execute in minecraft:overworld run fill 377 70 -26 377 144 -26 air
execute in minecraft:overworld run fill 377 58 -25 377 66 -25 stone
execute in minecraft:overworld run fill 377 67 -25 377 68 -25 dirt
execute in minecraft:overworld run setblock 377 69 -25 coarse_dirt
execute in minecraft:overworld run fill 377 70 -25 377 144 -25 air
execute in minecraft:overworld run fill 377 58 -24 377 66 -24 stone
execute in minecraft:overworld run fill 377 67 -24 377 68 -24 dirt
execute in minecraft:overworld run setblock 377 69 -24 grass_block
execute in minecraft:overworld run fill 377 70 -24 377 144 -24 air
execute in minecraft:overworld run fill 377 58 -23 377 65 -23 stone
execute in minecraft:overworld run fill 377 66 -23 377 67 -23 dirt
execute in minecraft:overworld run setblock 377 68 -23 coarse_dirt
execute in minecraft:overworld run fill 377 69 -23 377 144 -23 air
execute in minecraft:overworld run fill 377 58 -22 377 65 -22 stone
execute in minecraft:overworld run fill 377 66 -22 377 67 -22 dirt
execute in minecraft:overworld run setblock 377 68 -22 grass_block
execute in minecraft:overworld run fill 377 69 -22 377 144 -22 air
execute in minecraft:overworld run setblock 377 69 -22 grass
execute in minecraft:overworld run fill 377 58 -21 377 65 -21 stone
execute in minecraft:overworld run fill 377 66 -21 377 67 -21 dirt
execute in minecraft:overworld run setblock 377 68 -21 coarse_dirt
execute in minecraft:overworld run fill 377 69 -21 377 144 -21 air
execute in minecraft:overworld run fill 377 58 -20 377 65 -20 stone
execute in minecraft:overworld run fill 377 66 -20 377 67 -20 dirt
execute in minecraft:overworld run setblock 377 68 -20 coarse_dirt
execute in minecraft:overworld run fill 377 69 -20 377 144 -20 air
execute in minecraft:overworld run fill 377 58 -19 377 64 -19 stone
execute in minecraft:overworld run fill 377 65 -19 377 66 -19 dirt
execute in minecraft:overworld run setblock 377 67 -19 coarse_dirt
execute in minecraft:overworld run fill 377 68 -19 377 144 -19 air
execute in minecraft:overworld run fill 377 58 -18 377 64 -18 stone
execute in minecraft:overworld run fill 377 65 -18 377 66 -18 dirt
execute in minecraft:overworld run setblock 377 67 -18 grass_block
execute in minecraft:overworld run fill 377 68 -18 377 144 -18 air
execute in minecraft:overworld run fill 377 58 -17 377 64 -17 stone
execute in minecraft:overworld run fill 377 65 -17 377 66 -17 dirt
execute in minecraft:overworld run setblock 377 67 -17 coarse_dirt
execute in minecraft:overworld run fill 377 68 -17 377 144 -17 air
execute in minecraft:overworld run fill 377 58 -16 377 64 -16 stone
execute in minecraft:overworld run fill 377 65 -16 377 66 -16 dirt
execute in minecraft:overworld run setblock 377 67 -16 coarse_dirt
execute in minecraft:overworld run fill 377 68 -16 377 144 -16 air
execute in minecraft:overworld run fill 377 58 -15 377 64 -15 stone
execute in minecraft:overworld run fill 377 65 -15 377 66 -15 dirt
execute in minecraft:overworld run setblock 377 67 -15 grass_block
execute in minecraft:overworld run fill 377 68 -15 377 144 -15 air
execute in minecraft:overworld run fill 377 58 -14 377 64 -14 stone
execute in minecraft:overworld run fill 377 65 -14 377 66 -14 dirt
execute in minecraft:overworld run setblock 377 67 -14 coarse_dirt
execute in minecraft:overworld run fill 377 68 -14 377 144 -14 air
execute in minecraft:overworld run setblock 377 68 -14 grass
execute in minecraft:overworld run fill 377 58 -13 377 64 -13 stone
execute in minecraft:overworld run fill 377 65 -13 377 66 -13 dirt
execute in minecraft:overworld run setblock 377 67 -13 grass_block
execute in minecraft:overworld run fill 377 68 -13 377 144 -13 air
execute in minecraft:overworld run fill 377 58 -12 377 64 -12 stone
execute in minecraft:overworld run fill 377 65 -12 377 66 -12 dirt
execute in minecraft:overworld run setblock 377 67 -12 coarse_dirt
execute in minecraft:overworld run fill 377 68 -12 377 144 -12 air
execute in minecraft:overworld run fill 377 58 -11 377 64 -11 stone
execute in minecraft:overworld run fill 377 65 -11 377 66 -11 dirt
execute in minecraft:overworld run setblock 377 67 -11 coarse_dirt
execute in minecraft:overworld run fill 377 68 -11 377 144 -11 air
execute in minecraft:overworld run setblock 377 68 -11 grass
execute in minecraft:overworld run fill 377 58 -10 377 64 -10 stone
execute in minecraft:overworld run fill 377 65 -10 377 66 -10 dirt
execute in minecraft:overworld run setblock 377 67 -10 coarse_dirt
execute in minecraft:overworld run fill 377 68 -10 377 144 -10 air
execute in minecraft:overworld run fill 377 58 -9 377 65 -9 stone
execute in minecraft:overworld run fill 377 66 -9 377 67 -9 dirt
execute in minecraft:overworld run setblock 377 68 -9 grass_block
execute in minecraft:overworld run fill 377 69 -9 377 144 -9 air
execute in minecraft:overworld run setblock 377 69 -9 grass
execute in minecraft:overworld run fill 377 58 -8 377 65 -8 stone
execute in minecraft:overworld run fill 377 66 -8 377 67 -8 dirt
execute in minecraft:overworld run setblock 377 68 -8 coarse_dirt
execute in minecraft:overworld run fill 377 69 -8 377 144 -8 air
execute in minecraft:overworld run setblock 377 69 -8 grass
execute in minecraft:overworld run fill 377 58 -7 377 65 -7 stone
execute in minecraft:overworld run fill 377 66 -7 377 67 -7 dirt
execute in minecraft:overworld run setblock 377 68 -7 grass_block
execute in minecraft:overworld run fill 377 69 -7 377 144 -7 air
execute in minecraft:overworld run fill 377 58 -6 377 65 -6 stone
execute in minecraft:overworld run fill 377 66 -6 377 67 -6 dirt
execute in minecraft:overworld run setblock 377 68 -6 coarse_dirt
execute in minecraft:overworld run fill 377 69 -6 377 144 -6 air
execute in minecraft:overworld run fill 377 58 -5 377 65 -5 stone
execute in minecraft:overworld run fill 377 66 -5 377 67 -5 dirt
execute in minecraft:overworld run setblock 377 68 -5 coarse_dirt
execute in minecraft:overworld run fill 377 69 -5 377 144 -5 air
execute in minecraft:overworld run fill 377 58 -4 377 65 -4 stone
execute in minecraft:overworld run fill 377 66 -4 377 67 -4 dirt
execute in minecraft:overworld run setblock 377 68 -4 coarse_dirt
execute in minecraft:overworld run fill 377 69 -4 377 144 -4 air
execute in minecraft:overworld run fill 377 58 -3 377 65 -3 stone
execute in minecraft:overworld run fill 377 66 -3 377 67 -3 dirt
execute in minecraft:overworld run setblock 377 68 -3 coarse_dirt
execute in minecraft:overworld run fill 377 69 -3 377 144 -3 air
execute in minecraft:overworld run fill 377 58 -2 377 65 -2 stone
execute in minecraft:overworld run fill 377 66 -2 377 67 -2 dirt
execute in minecraft:overworld run setblock 377 68 -2 grass_block
execute in minecraft:overworld run fill 377 69 -2 377 144 -2 air
execute in minecraft:overworld run fill 377 58 -1 377 65 -1 stone
execute in minecraft:overworld run fill 377 66 -1 377 67 -1 dirt
execute in minecraft:overworld run setblock 377 68 -1 grass_block
execute in minecraft:overworld run fill 377 69 -1 377 144 -1 air
execute in minecraft:overworld run fill 377 58 0 377 65 0 stone
execute in minecraft:overworld run fill 377 66 0 377 67 0 dirt
execute in minecraft:overworld run setblock 377 68 0 coarse_dirt
execute in minecraft:overworld run fill 377 69 0 377 144 0 air
execute in minecraft:overworld run fill 377 58 1 377 65 1 stone
execute in minecraft:overworld run fill 377 66 1 377 67 1 dirt
execute in minecraft:overworld run setblock 377 68 1 coarse_dirt
execute in minecraft:overworld run fill 377 69 1 377 144 1 air
execute in minecraft:overworld run fill 377 58 2 377 65 2 stone
execute in minecraft:overworld run fill 377 66 2 377 67 2 dirt
execute in minecraft:overworld run setblock 377 68 2 grass_block
execute in minecraft:overworld run fill 377 69 2 377 144 2 air
execute in minecraft:overworld run fill 377 58 3 377 65 3 stone
execute in minecraft:overworld run fill 377 66 3 377 67 3 dirt
execute in minecraft:overworld run setblock 377 68 3 coarse_dirt
execute in minecraft:overworld run fill 377 69 3 377 144 3 air
execute in minecraft:overworld run fill 377 58 4 377 65 4 stone
execute in minecraft:overworld run fill 377 66 4 377 67 4 dirt
execute in minecraft:overworld run setblock 377 68 4 grass_block
execute in minecraft:overworld run fill 377 69 4 377 144 4 air
execute in minecraft:overworld run fill 377 58 5 377 65 5 stone
execute in minecraft:overworld run fill 377 66 5 377 67 5 dirt
execute in minecraft:overworld run setblock 377 68 5 coarse_dirt
execute in minecraft:overworld run fill 377 69 5 377 144 5 air
execute in minecraft:overworld run fill 377 58 6 377 65 6 stone
execute in minecraft:overworld run fill 377 66 6 377 67 6 dirt
execute in minecraft:overworld run setblock 377 68 6 grass_block
execute in minecraft:overworld run fill 377 69 6 377 144 6 air
execute in minecraft:overworld run fill 377 58 7 377 65 7 stone
execute in minecraft:overworld run fill 377 66 7 377 67 7 dirt
execute in minecraft:overworld run setblock 377 68 7 coarse_dirt
execute in minecraft:overworld run fill 377 69 7 377 144 7 air
execute in minecraft:overworld run fill 377 58 8 377 65 8 stone
execute in minecraft:overworld run fill 377 66 8 377 67 8 dirt
execute in minecraft:overworld run setblock 377 68 8 coarse_dirt
execute in minecraft:overworld run fill 377 69 8 377 144 8 air
execute in minecraft:overworld run fill 377 58 9 377 66 9 stone
execute in minecraft:overworld run fill 377 67 9 377 68 9 dirt
execute in minecraft:overworld run setblock 377 69 9 grass_block
execute in minecraft:overworld run fill 377 70 9 377 144 9 air
execute in minecraft:overworld run fill 377 58 10 377 66 10 stone
execute in minecraft:overworld run fill 377 67 10 377 68 10 dirt
execute in minecraft:overworld run setblock 377 69 10 coarse_dirt
execute in minecraft:overworld run fill 377 70 10 377 144 10 air
execute in minecraft:overworld run setblock 377 70 10 mossy_cobblestone
execute in minecraft:overworld run fill 377 58 11 377 66 11 stone
execute in minecraft:overworld run fill 377 67 11 377 68 11 dirt
execute in minecraft:overworld run setblock 377 69 11 coarse_dirt
execute in minecraft:overworld run fill 377 70 11 377 144 11 air
execute in minecraft:overworld run setblock 377 70 11 grass
execute in minecraft:overworld run fill 377 58 12 377 66 12 stone
execute in minecraft:overworld run fill 377 67 12 377 68 12 dirt
execute in minecraft:overworld run setblock 377 69 12 grass_block
execute in minecraft:overworld run fill 377 70 12 377 144 12 air
execute in minecraft:overworld run fill 377 58 13 377 67 13 stone
execute in minecraft:overworld run fill 377 68 13 377 69 13 dirt
execute in minecraft:overworld run setblock 377 70 13 coarse_dirt
execute in minecraft:overworld run fill 377 71 13 377 144 13 air
execute in minecraft:overworld run fill 377 58 14 377 67 14 stone
execute in minecraft:overworld run fill 377 68 14 377 69 14 dirt
execute in minecraft:overworld run setblock 377 70 14 coarse_dirt
execute in minecraft:overworld run fill 377 71 14 377 144 14 air
execute in minecraft:overworld run fill 377 58 15 377 67 15 stone
execute in minecraft:overworld run fill 377 68 15 377 69 15 dirt
execute in minecraft:overworld run setblock 377 70 15 coarse_dirt
execute in minecraft:overworld run fill 377 71 15 377 144 15 air
execute in minecraft:overworld run fill 377 58 16 377 68 16 stone
execute in minecraft:overworld run fill 377 69 16 377 70 16 dirt
execute in minecraft:overworld run setblock 377 71 16 coarse_dirt
execute in minecraft:overworld run fill 377 72 16 377 144 16 air
execute in minecraft:overworld run fill 377 58 17 377 68 17 stone
execute in minecraft:overworld run fill 377 69 17 377 70 17 dirt
execute in minecraft:overworld run setblock 377 71 17 coarse_dirt
execute in minecraft:overworld run fill 377 72 17 377 144 17 air
execute in minecraft:overworld run fill 377 58 18 377 68 18 stone
execute in minecraft:overworld run fill 377 69 18 377 70 18 dirt
execute in minecraft:overworld run setblock 377 71 18 grass_block
execute in minecraft:overworld run fill 377 72 18 377 144 18 air
execute in minecraft:overworld run fill 377 58 19 377 68 19 stone
execute in minecraft:overworld run fill 377 69 19 377 70 19 dirt
execute in minecraft:overworld run setblock 377 71 19 coarse_dirt
execute in minecraft:overworld run fill 377 72 19 377 144 19 air
execute in minecraft:overworld run fill 377 58 20 377 68 20 stone
execute in minecraft:overworld run fill 377 69 20 377 70 20 dirt
execute in minecraft:overworld run setblock 377 71 20 coarse_dirt
execute in minecraft:overworld run fill 377 72 20 377 144 20 air
execute in minecraft:overworld run fill 377 58 21 377 68 21 stone
execute in minecraft:overworld run fill 377 69 21 377 70 21 dirt
execute in minecraft:overworld run setblock 377 71 21 coarse_dirt
execute in minecraft:overworld run fill 377 72 21 377 144 21 air
schedule function blade_gallery:random/battlefield/part_64 1t replace
