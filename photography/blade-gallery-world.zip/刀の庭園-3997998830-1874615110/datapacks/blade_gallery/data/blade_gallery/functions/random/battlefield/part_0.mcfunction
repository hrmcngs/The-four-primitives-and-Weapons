execute in minecraft:overworld run kill @e[type=the_four_primitives_and_weapons:stabbed_weapon,tag=blade_gallery.battlefield]
execute in minecraft:overworld run gamerule doFireTick false
execute in minecraft:overworld run fill 336 58 -48 336 61 -48 stone
execute in minecraft:overworld run fill 336 62 -48 336 63 -48 dirt
execute in minecraft:overworld run setblock 336 64 -48 coarse_dirt
execute in minecraft:overworld run fill 336 65 -48 336 144 -48 air
execute in minecraft:overworld run fill 336 58 -47 336 61 -47 stone
execute in minecraft:overworld run fill 336 62 -47 336 63 -47 dirt
execute in minecraft:overworld run setblock 336 64 -47 grass_block
execute in minecraft:overworld run fill 336 65 -47 336 144 -47 air
execute in minecraft:overworld run fill 336 58 -46 336 61 -46 stone
execute in minecraft:overworld run fill 336 62 -46 336 63 -46 dirt
execute in minecraft:overworld run setblock 336 64 -46 coarse_dirt
execute in minecraft:overworld run fill 336 65 -46 336 144 -46 air
execute in minecraft:overworld run fill 336 58 -45 336 61 -45 stone
execute in minecraft:overworld run fill 336 62 -45 336 63 -45 dirt
execute in minecraft:overworld run setblock 336 64 -45 grass_block
execute in minecraft:overworld run fill 336 65 -45 336 144 -45 air
execute in minecraft:overworld run fill 336 58 -44 336 61 -44 stone
execute in minecraft:overworld run fill 336 62 -44 336 63 -44 dirt
execute in minecraft:overworld run setblock 336 64 -44 coarse_dirt
execute in minecraft:overworld run fill 336 65 -44 336 144 -44 air
execute in minecraft:overworld run fill 336 58 -43 336 61 -43 stone
execute in minecraft:overworld run fill 336 62 -43 336 63 -43 dirt
execute in minecraft:overworld run setblock 336 64 -43 coarse_dirt
execute in minecraft:overworld run fill 336 65 -43 336 144 -43 air
execute in minecraft:overworld run fill 336 58 -42 336 61 -42 stone
execute in minecraft:overworld run fill 336 62 -42 336 63 -42 dirt
execute in minecraft:overworld run setblock 336 64 -42 coarse_dirt
execute in minecraft:overworld run fill 336 65 -42 336 144 -42 air
execute in minecraft:overworld run fill 336 58 -41 336 61 -41 stone
execute in minecraft:overworld run fill 336 62 -41 336 63 -41 dirt
execute in minecraft:overworld run setblock 336 64 -41 grass_block
execute in minecraft:overworld run fill 336 65 -41 336 144 -41 air
execute in minecraft:overworld run fill 336 58 -40 336 61 -40 stone
execute in minecraft:overworld run fill 336 62 -40 336 63 -40 dirt
execute in minecraft:overworld run setblock 336 64 -40 coarse_dirt
execute in minecraft:overworld run fill 336 65 -40 336 144 -40 air
execute in minecraft:overworld run fill 336 58 -39 336 61 -39 stone
execute in minecraft:overworld run fill 336 62 -39 336 63 -39 dirt
execute in minecraft:overworld run setblock 336 64 -39 grass_block
execute in minecraft:overworld run fill 336 65 -39 336 144 -39 air
execute in minecraft:overworld run fill 336 58 -38 336 61 -38 stone
execute in minecraft:overworld run fill 336 62 -38 336 63 -38 dirt
execute in minecraft:overworld run setblock 336 64 -38 coarse_dirt
execute in minecraft:overworld run fill 336 65 -38 336 144 -38 air
execute in minecraft:overworld run fill 336 58 -37 336 61 -37 stone
execute in minecraft:overworld run fill 336 62 -37 336 63 -37 dirt
execute in minecraft:overworld run setblock 336 64 -37 coarse_dirt
execute in minecraft:overworld run fill 336 65 -37 336 144 -37 air
execute in minecraft:overworld run fill 336 58 -36 336 61 -36 stone
execute in minecraft:overworld run fill 336 62 -36 336 63 -36 dirt
execute in minecraft:overworld run setblock 336 64 -36 coarse_dirt
execute in minecraft:overworld run fill 336 65 -36 336 144 -36 air
execute in minecraft:overworld run fill 336 58 -35 336 61 -35 stone
execute in minecraft:overworld run fill 336 62 -35 336 63 -35 dirt
execute in minecraft:overworld run setblock 336 64 -35 grass_block
execute in minecraft:overworld run fill 336 65 -35 336 144 -35 air
execute in minecraft:overworld run fill 336 58 -34 336 61 -34 stone
execute in minecraft:overworld run fill 336 62 -34 336 63 -34 dirt
execute in minecraft:overworld run setblock 336 64 -34 grass_block
execute in minecraft:overworld run fill 336 65 -34 336 144 -34 air
execute in minecraft:overworld run fill 336 58 -33 336 61 -33 stone
execute in minecraft:overworld run fill 336 62 -33 336 63 -33 dirt
execute in minecraft:overworld run setblock 336 64 -33 coarse_dirt
execute in minecraft:overworld run fill 336 65 -33 336 144 -33 air
execute in minecraft:overworld run fill 336 58 -32 336 61 -32 stone
execute in minecraft:overworld run fill 336 62 -32 336 63 -32 dirt
execute in minecraft:overworld run setblock 336 64 -32 coarse_dirt
execute in minecraft:overworld run fill 336 65 -32 336 144 -32 air
execute in minecraft:overworld run fill 336 58 -31 336 61 -31 stone
execute in minecraft:overworld run fill 336 62 -31 336 63 -31 dirt
execute in minecraft:overworld run setblock 336 64 -31 grass_block
execute in minecraft:overworld run fill 336 65 -31 336 144 -31 air
execute in minecraft:overworld run fill 336 58 -30 336 61 -30 stone
execute in minecraft:overworld run fill 336 62 -30 336 63 -30 dirt
execute in minecraft:overworld run setblock 336 64 -30 grass_block
execute in minecraft:overworld run fill 336 65 -30 336 144 -30 air
execute in minecraft:overworld run fill 336 58 -29 336 61 -29 stone
execute in minecraft:overworld run fill 336 62 -29 336 63 -29 dirt
execute in minecraft:overworld run setblock 336 64 -29 grass_block
execute in minecraft:overworld run fill 336 65 -29 336 144 -29 air
execute in minecraft:overworld run fill 336 58 -28 336 61 -28 stone
execute in minecraft:overworld run fill 336 62 -28 336 63 -28 dirt
execute in minecraft:overworld run setblock 336 64 -28 coarse_dirt
execute in minecraft:overworld run fill 336 65 -28 336 144 -28 air
execute in minecraft:overworld run fill 336 58 -27 336 61 -27 stone
execute in minecraft:overworld run fill 336 62 -27 336 63 -27 dirt
execute in minecraft:overworld run setblock 336 64 -27 coarse_dirt
execute in minecraft:overworld run fill 336 65 -27 336 144 -27 air
execute in minecraft:overworld run fill 336 58 -26 336 61 -26 stone
execute in minecraft:overworld run fill 336 62 -26 336 63 -26 dirt
execute in minecraft:overworld run setblock 336 64 -26 coarse_dirt
execute in minecraft:overworld run fill 336 65 -26 336 144 -26 air
execute in minecraft:overworld run fill 336 58 -25 336 61 -25 stone
execute in minecraft:overworld run fill 336 62 -25 336 63 -25 dirt
execute in minecraft:overworld run setblock 336 64 -25 coarse_dirt
execute in minecraft:overworld run fill 336 65 -25 336 144 -25 air
execute in minecraft:overworld run fill 336 58 -24 336 61 -24 stone
execute in minecraft:overworld run fill 336 62 -24 336 63 -24 dirt
execute in minecraft:overworld run setblock 336 64 -24 coarse_dirt
execute in minecraft:overworld run fill 336 65 -24 336 144 -24 air
execute in minecraft:overworld run fill 336 58 -23 336 61 -23 stone
execute in minecraft:overworld run fill 336 62 -23 336 63 -23 dirt
execute in minecraft:overworld run setblock 336 64 -23 coarse_dirt
execute in minecraft:overworld run fill 336 65 -23 336 144 -23 air
execute in minecraft:overworld run fill 336 58 -22 336 61 -22 stone
execute in minecraft:overworld run fill 336 62 -22 336 63 -22 dirt
execute in minecraft:overworld run setblock 336 64 -22 coarse_dirt
execute in minecraft:overworld run fill 336 65 -22 336 144 -22 air
execute in minecraft:overworld run fill 336 58 -21 336 61 -21 stone
execute in minecraft:overworld run fill 336 62 -21 336 63 -21 dirt
execute in minecraft:overworld run setblock 336 64 -21 coarse_dirt
execute in minecraft:overworld run fill 336 65 -21 336 144 -21 air
execute in minecraft:overworld run fill 336 58 -20 336 61 -20 stone
execute in minecraft:overworld run fill 336 62 -20 336 63 -20 dirt
execute in minecraft:overworld run setblock 336 64 -20 coarse_dirt
execute in minecraft:overworld run fill 336 65 -20 336 144 -20 air
execute in minecraft:overworld run fill 336 58 -19 336 61 -19 stone
execute in minecraft:overworld run fill 336 62 -19 336 63 -19 dirt
execute in minecraft:overworld run setblock 336 64 -19 coarse_dirt
execute in minecraft:overworld run fill 336 65 -19 336 144 -19 air
execute in minecraft:overworld run fill 336 58 -18 336 61 -18 stone
execute in minecraft:overworld run fill 336 62 -18 336 63 -18 dirt
execute in minecraft:overworld run setblock 336 64 -18 coarse_dirt
execute in minecraft:overworld run fill 336 65 -18 336 144 -18 air
execute in minecraft:overworld run fill 336 58 -17 336 61 -17 stone
execute in minecraft:overworld run fill 336 62 -17 336 63 -17 dirt
execute in minecraft:overworld run setblock 336 64 -17 coarse_dirt
execute in minecraft:overworld run fill 336 65 -17 336 144 -17 air
execute in minecraft:overworld run fill 336 58 -16 336 61 -16 stone
execute in minecraft:overworld run fill 336 62 -16 336 63 -16 dirt
execute in minecraft:overworld run setblock 336 64 -16 coarse_dirt
execute in minecraft:overworld run fill 336 65 -16 336 144 -16 air
execute in minecraft:overworld run fill 336 58 -15 336 61 -15 stone
execute in minecraft:overworld run fill 336 62 -15 336 63 -15 dirt
execute in minecraft:overworld run setblock 336 64 -15 grass_block
execute in minecraft:overworld run fill 336 65 -15 336 144 -15 air
execute in minecraft:overworld run fill 336 58 -14 336 61 -14 stone
execute in minecraft:overworld run fill 336 62 -14 336 63 -14 dirt
execute in minecraft:overworld run setblock 336 64 -14 coarse_dirt
execute in minecraft:overworld run fill 336 65 -14 336 144 -14 air
execute in minecraft:overworld run fill 336 58 -13 336 61 -13 stone
execute in minecraft:overworld run fill 336 62 -13 336 63 -13 dirt
execute in minecraft:overworld run setblock 336 64 -13 coarse_dirt
execute in minecraft:overworld run fill 336 65 -13 336 144 -13 air
execute in minecraft:overworld run fill 336 58 -12 336 61 -12 stone
execute in minecraft:overworld run fill 336 62 -12 336 63 -12 dirt
execute in minecraft:overworld run setblock 336 64 -12 coarse_dirt
execute in minecraft:overworld run fill 336 65 -12 336 144 -12 air
execute in minecraft:overworld run fill 336 58 -11 336 61 -11 stone
execute in minecraft:overworld run fill 336 62 -11 336 63 -11 dirt
execute in minecraft:overworld run setblock 336 64 -11 coarse_dirt
execute in minecraft:overworld run fill 336 65 -11 336 144 -11 air
execute in minecraft:overworld run fill 336 58 -10 336 61 -10 stone
execute in minecraft:overworld run fill 336 62 -10 336 63 -10 dirt
execute in minecraft:overworld run setblock 336 64 -10 grass_block
execute in minecraft:overworld run fill 336 65 -10 336 144 -10 air
execute in minecraft:overworld run fill 336 58 -9 336 61 -9 stone
execute in minecraft:overworld run fill 336 62 -9 336 63 -9 dirt
execute in minecraft:overworld run setblock 336 64 -9 grass_block
execute in minecraft:overworld run fill 336 65 -9 336 144 -9 air
execute in minecraft:overworld run fill 336 58 -8 336 61 -8 stone
execute in minecraft:overworld run fill 336 62 -8 336 63 -8 dirt
execute in minecraft:overworld run setblock 336 64 -8 coarse_dirt
execute in minecraft:overworld run fill 336 65 -8 336 144 -8 air
execute in minecraft:overworld run fill 336 58 -7 336 61 -7 stone
execute in minecraft:overworld run fill 336 62 -7 336 63 -7 dirt
execute in minecraft:overworld run setblock 336 64 -7 coarse_dirt
execute in minecraft:overworld run fill 336 65 -7 336 144 -7 air
execute in minecraft:overworld run fill 336 58 -6 336 61 -6 stone
execute in minecraft:overworld run fill 336 62 -6 336 63 -6 dirt
execute in minecraft:overworld run setblock 336 64 -6 coarse_dirt
execute in minecraft:overworld run fill 336 65 -6 336 144 -6 air
execute in minecraft:overworld run fill 336 58 -5 336 61 -5 stone
execute in minecraft:overworld run fill 336 62 -5 336 63 -5 dirt
execute in minecraft:overworld run setblock 336 64 -5 coarse_dirt
execute in minecraft:overworld run fill 336 65 -5 336 144 -5 air
execute in minecraft:overworld run fill 336 58 -4 336 61 -4 stone
execute in minecraft:overworld run fill 336 62 -4 336 63 -4 dirt
execute in minecraft:overworld run setblock 336 64 -4 coarse_dirt
execute in minecraft:overworld run fill 336 65 -4 336 144 -4 air
execute in minecraft:overworld run fill 336 58 -3 336 61 -3 stone
execute in minecraft:overworld run fill 336 62 -3 336 63 -3 dirt
execute in minecraft:overworld run setblock 336 64 -3 grass_block
execute in minecraft:overworld run fill 336 65 -3 336 144 -3 air
execute in minecraft:overworld run fill 336 58 -2 336 61 -2 stone
execute in minecraft:overworld run fill 336 62 -2 336 63 -2 dirt
execute in minecraft:overworld run setblock 336 64 -2 coarse_dirt
execute in minecraft:overworld run fill 336 65 -2 336 144 -2 air
execute in minecraft:overworld run fill 336 58 -1 336 61 -1 stone
execute in minecraft:overworld run fill 336 62 -1 336 63 -1 dirt
execute in minecraft:overworld run setblock 336 64 -1 grass_block
execute in minecraft:overworld run fill 336 65 -1 336 144 -1 air
execute in minecraft:overworld run fill 336 58 0 336 61 0 stone
execute in minecraft:overworld run fill 336 62 0 336 63 0 dirt
execute in minecraft:overworld run setblock 336 64 0 coarse_dirt
execute in minecraft:overworld run fill 336 65 0 336 144 0 air
execute in minecraft:overworld run fill 336 58 1 336 61 1 stone
execute in minecraft:overworld run fill 336 62 1 336 63 1 dirt
execute in minecraft:overworld run setblock 336 64 1 coarse_dirt
execute in minecraft:overworld run fill 336 65 1 336 144 1 air
execute in minecraft:overworld run fill 336 58 2 336 61 2 stone
execute in minecraft:overworld run fill 336 62 2 336 63 2 dirt
execute in minecraft:overworld run setblock 336 64 2 grass_block
execute in minecraft:overworld run fill 336 65 2 336 144 2 air
execute in minecraft:overworld run fill 336 58 3 336 61 3 stone
execute in minecraft:overworld run fill 336 62 3 336 63 3 dirt
execute in minecraft:overworld run setblock 336 64 3 coarse_dirt
execute in minecraft:overworld run fill 336 65 3 336 144 3 air
execute in minecraft:overworld run fill 336 58 4 336 61 4 stone
execute in minecraft:overworld run fill 336 62 4 336 63 4 dirt
execute in minecraft:overworld run setblock 336 64 4 coarse_dirt
execute in minecraft:overworld run fill 336 65 4 336 144 4 air
execute in minecraft:overworld run fill 336 58 5 336 61 5 stone
execute in minecraft:overworld run fill 336 62 5 336 63 5 dirt
execute in minecraft:overworld run setblock 336 64 5 coarse_dirt
execute in minecraft:overworld run fill 336 65 5 336 144 5 air
execute in minecraft:overworld run fill 336 58 6 336 61 6 stone
execute in minecraft:overworld run fill 336 62 6 336 63 6 dirt
execute in minecraft:overworld run setblock 336 64 6 grass_block
execute in minecraft:overworld run fill 336 65 6 336 144 6 air
execute in minecraft:overworld run fill 336 58 7 336 61 7 stone
execute in minecraft:overworld run fill 336 62 7 336 63 7 dirt
execute in minecraft:overworld run setblock 336 64 7 coarse_dirt
execute in minecraft:overworld run fill 336 65 7 336 144 7 air
execute in minecraft:overworld run fill 336 58 8 336 61 8 stone
execute in minecraft:overworld run fill 336 62 8 336 63 8 dirt
execute in minecraft:overworld run setblock 336 64 8 grass_block
execute in minecraft:overworld run fill 336 65 8 336 144 8 air
execute in minecraft:overworld run fill 336 58 9 336 61 9 stone
execute in minecraft:overworld run fill 336 62 9 336 63 9 dirt
execute in minecraft:overworld run setblock 336 64 9 coarse_dirt
execute in minecraft:overworld run fill 336 65 9 336 144 9 air
execute in minecraft:overworld run fill 336 58 10 336 61 10 stone
execute in minecraft:overworld run fill 336 62 10 336 63 10 dirt
execute in minecraft:overworld run setblock 336 64 10 coarse_dirt
execute in minecraft:overworld run fill 336 65 10 336 144 10 air
execute in minecraft:overworld run fill 336 58 11 336 61 11 stone
execute in minecraft:overworld run fill 336 62 11 336 63 11 dirt
execute in minecraft:overworld run setblock 336 64 11 coarse_dirt
execute in minecraft:overworld run fill 336 65 11 336 144 11 air
execute in minecraft:overworld run fill 336 58 12 336 61 12 stone
execute in minecraft:overworld run fill 336 62 12 336 63 12 dirt
execute in minecraft:overworld run setblock 336 64 12 coarse_dirt
execute in minecraft:overworld run fill 336 65 12 336 144 12 air
execute in minecraft:overworld run fill 336 58 13 336 61 13 stone
execute in minecraft:overworld run fill 336 62 13 336 63 13 dirt
execute in minecraft:overworld run setblock 336 64 13 coarse_dirt
execute in minecraft:overworld run fill 336 65 13 336 144 13 air
execute in minecraft:overworld run fill 336 58 14 336 61 14 stone
execute in minecraft:overworld run fill 336 62 14 336 63 14 dirt
execute in minecraft:overworld run setblock 336 64 14 coarse_dirt
execute in minecraft:overworld run fill 336 65 14 336 144 14 air
execute in minecraft:overworld run fill 336 58 15 336 61 15 stone
execute in minecraft:overworld run fill 336 62 15 336 63 15 dirt
schedule function blade_gallery:random/battlefield/part_1 1t replace
