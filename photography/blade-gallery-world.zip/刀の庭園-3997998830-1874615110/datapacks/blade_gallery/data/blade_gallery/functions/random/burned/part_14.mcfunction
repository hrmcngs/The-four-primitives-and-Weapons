execute in minecraft:overworld run setblock 217 68 -24 grass_block
execute in minecraft:overworld run fill 217 69 -24 217 144 -24 air
execute in minecraft:overworld run fill 217 58 -23 217 65 -23 stone
execute in minecraft:overworld run fill 217 66 -23 217 67 -23 dirt
execute in minecraft:overworld run setblock 217 68 -23 coarse_dirt
execute in minecraft:overworld run fill 217 69 -23 217 144 -23 air
execute in minecraft:overworld run fill 217 58 -22 217 65 -22 stone
execute in minecraft:overworld run fill 217 66 -22 217 67 -22 dirt
execute in minecraft:overworld run setblock 217 68 -22 grass_block
execute in minecraft:overworld run fill 217 69 -22 217 144 -22 air
execute in minecraft:overworld run fill 217 58 -21 217 66 -21 stone
execute in minecraft:overworld run fill 217 67 -21 217 68 -21 dirt
execute in minecraft:overworld run setblock 217 69 -21 coarse_dirt
execute in minecraft:overworld run fill 217 70 -21 217 144 -21 air
execute in minecraft:overworld run fill 217 58 -20 217 66 -20 stone
execute in minecraft:overworld run fill 217 67 -20 217 68 -20 dirt
execute in minecraft:overworld run setblock 217 69 -20 grass_block
execute in minecraft:overworld run fill 217 70 -20 217 144 -20 air
execute in minecraft:overworld run fill 217 58 -19 217 66 -19 stone
execute in minecraft:overworld run fill 217 67 -19 217 68 -19 dirt
execute in minecraft:overworld run setblock 217 69 -19 grass_block
execute in minecraft:overworld run fill 217 70 -19 217 144 -19 air
execute in minecraft:overworld run fill 217 58 -18 217 66 -18 stone
execute in minecraft:overworld run fill 217 67 -18 217 68 -18 dirt
execute in minecraft:overworld run setblock 217 69 -18 coarse_dirt
execute in minecraft:overworld run fill 217 70 -18 217 144 -18 air
execute in minecraft:overworld run fill 217 58 -17 217 66 -17 stone
execute in minecraft:overworld run fill 217 67 -17 217 68 -17 dirt
execute in minecraft:overworld run setblock 217 69 -17 coarse_dirt
execute in minecraft:overworld run fill 217 70 -17 217 144 -17 air
execute in minecraft:overworld run fill 217 58 -16 217 66 -16 stone
execute in minecraft:overworld run fill 217 67 -16 217 68 -16 dirt
execute in minecraft:overworld run setblock 217 69 -16 grass_block
execute in minecraft:overworld run fill 217 70 -16 217 144 -16 air
execute in minecraft:overworld run setblock 217 70 -16 grass
execute in minecraft:overworld run fill 217 58 -15 217 66 -15 stone
execute in minecraft:overworld run fill 217 67 -15 217 68 -15 dirt
execute in minecraft:overworld run setblock 217 69 -15 coarse_dirt
execute in minecraft:overworld run fill 217 70 -15 217 144 -15 air
execute in minecraft:overworld run fill 217 58 -14 217 65 -14 stone
execute in minecraft:overworld run fill 217 66 -14 217 67 -14 dirt
execute in minecraft:overworld run setblock 217 68 -14 coarse_dirt
execute in minecraft:overworld run fill 217 69 -14 217 144 -14 air
execute in minecraft:overworld run fill 217 58 -13 217 65 -13 stone
execute in minecraft:overworld run fill 217 66 -13 217 67 -13 dirt
execute in minecraft:overworld run setblock 217 68 -13 coarse_dirt
execute in minecraft:overworld run fill 217 69 -13 217 144 -13 air
execute in minecraft:overworld run fill 217 58 -12 217 65 -12 stone
execute in minecraft:overworld run fill 217 66 -12 217 67 -12 dirt
execute in minecraft:overworld run setblock 217 68 -12 coarse_dirt
execute in minecraft:overworld run fill 217 69 -12 217 144 -12 air
execute in minecraft:overworld run fill 217 58 -11 217 65 -11 stone
execute in minecraft:overworld run fill 217 66 -11 217 67 -11 dirt
execute in minecraft:overworld run setblock 217 68 -11 coarse_dirt
execute in minecraft:overworld run fill 217 69 -11 217 144 -11 air
execute in minecraft:overworld run fill 217 58 -10 217 66 -10 stone
execute in minecraft:overworld run fill 217 67 -10 217 68 -10 dirt
execute in minecraft:overworld run setblock 217 69 -10 coarse_dirt
execute in minecraft:overworld run fill 217 70 -10 217 144 -10 air
execute in minecraft:overworld run fill 217 58 -9 217 66 -9 stone
execute in minecraft:overworld run fill 217 67 -9 217 68 -9 dirt
execute in minecraft:overworld run setblock 217 69 -9 coarse_dirt
execute in minecraft:overworld run fill 217 70 -9 217 144 -9 air
execute in minecraft:overworld run fill 217 58 -8 217 66 -8 stone
execute in minecraft:overworld run fill 217 67 -8 217 68 -8 dirt
execute in minecraft:overworld run setblock 217 69 -8 grass_block
execute in minecraft:overworld run fill 217 70 -8 217 144 -8 air
execute in minecraft:overworld run fill 217 58 -7 217 66 -7 stone
execute in minecraft:overworld run fill 217 67 -7 217 68 -7 dirt
execute in minecraft:overworld run setblock 217 69 -7 coarse_dirt
execute in minecraft:overworld run fill 217 70 -7 217 144 -7 air
execute in minecraft:overworld run fill 217 58 -6 217 66 -6 stone
execute in minecraft:overworld run fill 217 67 -6 217 68 -6 dirt
execute in minecraft:overworld run setblock 217 69 -6 coarse_dirt
execute in minecraft:overworld run fill 217 70 -6 217 144 -6 air
execute in minecraft:overworld run fill 217 58 -5 217 67 -5 stone
execute in minecraft:overworld run fill 217 68 -5 217 69 -5 dirt
execute in minecraft:overworld run setblock 217 70 -5 grass_block
execute in minecraft:overworld run fill 217 71 -5 217 144 -5 air
execute in minecraft:overworld run fill 217 58 -4 217 67 -4 stone
execute in minecraft:overworld run fill 217 68 -4 217 69 -4 dirt
execute in minecraft:overworld run setblock 217 70 -4 grass_block
execute in minecraft:overworld run fill 217 71 -4 217 144 -4 air
execute in minecraft:overworld run fill 217 58 -3 217 67 -3 stone
execute in minecraft:overworld run fill 217 68 -3 217 69 -3 dirt
execute in minecraft:overworld run setblock 217 70 -3 coarse_dirt
execute in minecraft:overworld run fill 217 71 -3 217 144 -3 air
execute in minecraft:overworld run fill 217 58 -2 217 67 -2 stone
execute in minecraft:overworld run fill 217 68 -2 217 69 -2 dirt
execute in minecraft:overworld run setblock 217 70 -2 coarse_dirt
execute in minecraft:overworld run fill 217 71 -2 217 144 -2 air
execute in minecraft:overworld run fill 217 58 -1 217 67 -1 stone
execute in minecraft:overworld run fill 217 68 -1 217 69 -1 dirt
execute in minecraft:overworld run setblock 217 70 -1 coarse_dirt
execute in minecraft:overworld run fill 217 71 -1 217 144 -1 air
execute in minecraft:overworld run fill 217 58 0 217 67 0 stone
execute in minecraft:overworld run fill 217 68 0 217 69 0 dirt
execute in minecraft:overworld run setblock 217 70 0 coarse_dirt
execute in minecraft:overworld run fill 217 71 0 217 144 0 air
execute in minecraft:overworld run fill 217 58 1 217 67 1 stone
execute in minecraft:overworld run fill 217 68 1 217 69 1 dirt
execute in minecraft:overworld run setblock 217 70 1 coarse_dirt
execute in minecraft:overworld run fill 217 71 1 217 144 1 air
execute in minecraft:overworld run fill 217 58 2 217 67 2 stone
execute in minecraft:overworld run fill 217 68 2 217 69 2 dirt
execute in minecraft:overworld run setblock 217 70 2 coarse_dirt
execute in minecraft:overworld run fill 217 71 2 217 144 2 air
execute in minecraft:overworld run fill 217 58 3 217 67 3 stone
execute in minecraft:overworld run fill 217 68 3 217 69 3 dirt
execute in minecraft:overworld run setblock 217 70 3 grass_block
execute in minecraft:overworld run fill 217 71 3 217 144 3 air
execute in minecraft:overworld run fill 217 58 4 217 67 4 stone
execute in minecraft:overworld run fill 217 68 4 217 69 4 dirt
execute in minecraft:overworld run setblock 217 70 4 coarse_dirt
execute in minecraft:overworld run fill 217 71 4 217 144 4 air
execute in minecraft:overworld run fill 217 58 5 217 66 5 stone
execute in minecraft:overworld run fill 217 67 5 217 68 5 dirt
execute in minecraft:overworld run setblock 217 69 5 coarse_dirt
execute in minecraft:overworld run fill 217 70 5 217 144 5 air
execute in minecraft:overworld run fill 217 58 6 217 66 6 stone
execute in minecraft:overworld run fill 217 67 6 217 68 6 dirt
execute in minecraft:overworld run setblock 217 69 6 coarse_dirt
execute in minecraft:overworld run fill 217 70 6 217 144 6 air
execute in minecraft:overworld run fill 217 58 7 217 66 7 stone
execute in minecraft:overworld run fill 217 67 7 217 68 7 dirt
execute in minecraft:overworld run setblock 217 69 7 coarse_dirt
execute in minecraft:overworld run fill 217 70 7 217 144 7 air
execute in minecraft:overworld run fill 217 58 8 217 66 8 stone
execute in minecraft:overworld run fill 217 67 8 217 68 8 dirt
execute in minecraft:overworld run setblock 217 69 8 coarse_dirt
execute in minecraft:overworld run fill 217 70 8 217 144 8 air
execute in minecraft:overworld run fill 217 58 9 217 66 9 stone
execute in minecraft:overworld run fill 217 67 9 217 68 9 dirt
execute in minecraft:overworld run setblock 217 69 9 grass_block
execute in minecraft:overworld run fill 217 70 9 217 144 9 air
execute in minecraft:overworld run fill 217 58 10 217 66 10 stone
execute in minecraft:overworld run fill 217 67 10 217 68 10 dirt
execute in minecraft:overworld run setblock 217 69 10 coarse_dirt
execute in minecraft:overworld run fill 217 70 10 217 144 10 air
execute in minecraft:overworld run setblock 217 70 10 grass
execute in minecraft:overworld run fill 217 58 11 217 67 11 stone
execute in minecraft:overworld run fill 217 68 11 217 69 11 dirt
execute in minecraft:overworld run setblock 217 70 11 coarse_dirt
execute in minecraft:overworld run fill 217 71 11 217 144 11 air
execute in minecraft:overworld run fill 217 58 12 217 67 12 stone
execute in minecraft:overworld run fill 217 68 12 217 69 12 dirt
execute in minecraft:overworld run setblock 217 70 12 coarse_dirt
execute in minecraft:overworld run fill 217 71 12 217 144 12 air
execute in minecraft:overworld run fill 217 58 13 217 67 13 stone
execute in minecraft:overworld run fill 217 68 13 217 69 13 dirt
execute in minecraft:overworld run setblock 217 70 13 grass_block
execute in minecraft:overworld run fill 217 71 13 217 144 13 air
execute in minecraft:overworld run fill 217 58 14 217 68 14 stone
execute in minecraft:overworld run fill 217 69 14 217 70 14 dirt
execute in minecraft:overworld run setblock 217 71 14 coarse_dirt
execute in minecraft:overworld run fill 217 72 14 217 144 14 air
execute in minecraft:overworld run fill 217 58 15 217 68 15 stone
execute in minecraft:overworld run fill 217 69 15 217 70 15 dirt
execute in minecraft:overworld run setblock 217 71 15 coarse_dirt
execute in minecraft:overworld run fill 217 72 15 217 144 15 air
execute in minecraft:overworld run fill 217 58 16 217 68 16 stone
execute in minecraft:overworld run fill 217 69 16 217 70 16 dirt
execute in minecraft:overworld run setblock 217 71 16 grass_block
execute in minecraft:overworld run fill 217 72 16 217 144 16 air
execute in minecraft:overworld run fill 217 58 17 217 69 17 stone
execute in minecraft:overworld run fill 217 70 17 217 71 17 dirt
execute in minecraft:overworld run setblock 217 72 17 coarse_dirt
execute in minecraft:overworld run fill 217 73 17 217 144 17 air
execute in minecraft:overworld run fill 217 58 18 217 69 18 stone
execute in minecraft:overworld run fill 217 70 18 217 71 18 dirt
execute in minecraft:overworld run setblock 217 72 18 coarse_dirt
execute in minecraft:overworld run fill 217 73 18 217 144 18 air
execute in minecraft:overworld run fill 217 58 19 217 69 19 stone
execute in minecraft:overworld run fill 217 70 19 217 71 19 dirt
execute in minecraft:overworld run setblock 217 72 19 grass_block
execute in minecraft:overworld run fill 217 73 19 217 144 19 air
execute in minecraft:overworld run fill 217 58 20 217 69 20 stone
execute in minecraft:overworld run fill 217 70 20 217 71 20 dirt
execute in minecraft:overworld run setblock 217 72 20 grass_block
execute in minecraft:overworld run fill 217 73 20 217 144 20 air
execute in minecraft:overworld run fill 217 58 21 217 69 21 stone
execute in minecraft:overworld run fill 217 70 21 217 71 21 dirt
execute in minecraft:overworld run setblock 217 72 21 coarse_dirt
execute in minecraft:overworld run fill 217 73 21 217 144 21 air
execute in minecraft:overworld run setblock 217 73 21 mossy_cobblestone
execute in minecraft:overworld run fill 217 58 22 217 69 22 stone
execute in minecraft:overworld run fill 217 70 22 217 71 22 dirt
execute in minecraft:overworld run setblock 217 72 22 coarse_dirt
execute in minecraft:overworld run fill 217 73 22 217 144 22 air
execute in minecraft:overworld run fill 217 58 23 217 70 23 stone
execute in minecraft:overworld run fill 217 71 23 217 72 23 dirt
execute in minecraft:overworld run setblock 217 73 23 coarse_dirt
execute in minecraft:overworld run fill 217 74 23 217 144 23 air
execute in minecraft:overworld run fill 217 58 24 217 70 24 stone
execute in minecraft:overworld run fill 217 71 24 217 72 24 dirt
execute in minecraft:overworld run setblock 217 73 24 grass_block
execute in minecraft:overworld run fill 217 74 24 217 144 24 air
execute in minecraft:overworld run fill 217 58 25 217 70 25 stone
execute in minecraft:overworld run fill 217 71 25 217 72 25 dirt
execute in minecraft:overworld run setblock 217 73 25 coarse_dirt
execute in minecraft:overworld run fill 217 74 25 217 144 25 air
execute in minecraft:overworld run fill 217 58 26 217 70 26 stone
execute in minecraft:overworld run fill 217 71 26 217 72 26 dirt
execute in minecraft:overworld run setblock 217 73 26 coarse_dirt
execute in minecraft:overworld run fill 217 74 26 217 144 26 air
execute in minecraft:overworld run fill 217 58 27 217 70 27 stone
execute in minecraft:overworld run fill 217 71 27 217 72 27 dirt
execute in minecraft:overworld run setblock 217 73 27 coarse_dirt
execute in minecraft:overworld run fill 217 74 27 217 144 27 air
execute in minecraft:overworld run fill 217 58 28 217 70 28 stone
execute in minecraft:overworld run fill 217 71 28 217 72 28 dirt
execute in minecraft:overworld run setblock 217 73 28 coarse_dirt
execute in minecraft:overworld run fill 217 74 28 217 144 28 air
execute in minecraft:overworld run fill 217 58 29 217 70 29 stone
execute in minecraft:overworld run fill 217 71 29 217 72 29 dirt
execute in minecraft:overworld run setblock 217 73 29 coarse_dirt
execute in minecraft:overworld run fill 217 74 29 217 144 29 air
execute in minecraft:overworld run setblock 217 74 29 grass
execute in minecraft:overworld run fill 217 58 30 217 70 30 stone
execute in minecraft:overworld run fill 217 71 30 217 72 30 dirt
execute in minecraft:overworld run setblock 217 73 30 grass_block
execute in minecraft:overworld run fill 217 74 30 217 144 30 air
execute in minecraft:overworld run setblock 217 74 30 grass
execute in minecraft:overworld run fill 217 58 31 217 69 31 stone
execute in minecraft:overworld run fill 217 70 31 217 71 31 dirt
execute in minecraft:overworld run setblock 217 72 31 grass_block
execute in minecraft:overworld run fill 217 73 31 217 144 31 air
execute in minecraft:overworld run fill 217 58 32 217 69 32 stone
execute in minecraft:overworld run fill 217 70 32 217 71 32 dirt
execute in minecraft:overworld run setblock 217 72 32 grass_block
execute in minecraft:overworld run fill 217 73 32 217 144 32 air
execute in minecraft:overworld run setblock 217 73 32 grass
execute in minecraft:overworld run fill 217 58 33 217 69 33 stone
execute in minecraft:overworld run fill 217 70 33 217 71 33 dirt
execute in minecraft:overworld run setblock 217 72 33 grass_block
execute in minecraft:overworld run fill 217 73 33 217 144 33 air
execute in minecraft:overworld run fill 217 58 34 217 69 34 stone
execute in minecraft:overworld run fill 217 70 34 217 71 34 dirt
execute in minecraft:overworld run setblock 217 72 34 coarse_dirt
execute in minecraft:overworld run fill 217 73 34 217 144 34 air
execute in minecraft:overworld run fill 217 58 35 217 68 35 stone
execute in minecraft:overworld run fill 217 69 35 217 70 35 dirt
execute in minecraft:overworld run setblock 217 71 35 grass_block
execute in minecraft:overworld run fill 217 72 35 217 144 35 air
execute in minecraft:overworld run fill 217 58 36 217 68 36 stone
execute in minecraft:overworld run fill 217 69 36 217 70 36 dirt
execute in minecraft:overworld run setblock 217 71 36 grass_block
execute in minecraft:overworld run fill 217 72 36 217 144 36 air
execute in minecraft:overworld run fill 217 58 37 217 68 37 stone
execute in minecraft:overworld run fill 217 69 37 217 70 37 dirt
execute in minecraft:overworld run setblock 217 71 37 coarse_dirt
execute in minecraft:overworld run fill 217 72 37 217 144 37 air
execute in minecraft:overworld run fill 217 58 38 217 67 38 stone
execute in minecraft:overworld run fill 217 68 38 217 69 38 dirt
execute in minecraft:overworld run setblock 217 70 38 coarse_dirt
execute in minecraft:overworld run fill 217 71 38 217 144 38 air
schedule function blade_gallery:random/burned/part_15 1t replace
