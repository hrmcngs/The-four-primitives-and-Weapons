execute in minecraft:overworld run fill 427 70 -26 427 144 -26 air
execute in minecraft:overworld run fill 427 58 -25 427 65 -25 stone
execute in minecraft:overworld run fill 427 66 -25 427 67 -25 dirt
execute in minecraft:overworld run setblock 427 68 -25 coarse_dirt
execute in minecraft:overworld run fill 427 69 -25 427 144 -25 air
execute in minecraft:overworld run fill 427 58 -24 427 65 -24 stone
execute in minecraft:overworld run fill 427 66 -24 427 67 -24 dirt
execute in minecraft:overworld run setblock 427 68 -24 coarse_dirt
execute in minecraft:overworld run fill 427 69 -24 427 144 -24 air
execute in minecraft:overworld run fill 427 58 -23 427 65 -23 stone
execute in minecraft:overworld run fill 427 66 -23 427 67 -23 dirt
execute in minecraft:overworld run setblock 427 68 -23 coarse_dirt
execute in minecraft:overworld run fill 427 69 -23 427 144 -23 air
execute in minecraft:overworld run fill 427 58 -22 427 65 -22 stone
execute in minecraft:overworld run fill 427 66 -22 427 67 -22 dirt
execute in minecraft:overworld run setblock 427 68 -22 coarse_dirt
execute in minecraft:overworld run fill 427 69 -22 427 144 -22 air
execute in minecraft:overworld run fill 427 58 -21 427 65 -21 stone
execute in minecraft:overworld run fill 427 66 -21 427 67 -21 dirt
execute in minecraft:overworld run setblock 427 68 -21 coarse_dirt
execute in minecraft:overworld run fill 427 69 -21 427 144 -21 air
execute in minecraft:overworld run fill 427 58 -20 427 65 -20 stone
execute in minecraft:overworld run fill 427 66 -20 427 67 -20 dirt
execute in minecraft:overworld run setblock 427 68 -20 coarse_dirt
execute in minecraft:overworld run fill 427 69 -20 427 144 -20 air
execute in minecraft:overworld run fill 427 58 -19 427 65 -19 stone
execute in minecraft:overworld run fill 427 66 -19 427 67 -19 dirt
execute in minecraft:overworld run setblock 427 68 -19 coarse_dirt
execute in minecraft:overworld run fill 427 69 -19 427 144 -19 air
execute in minecraft:overworld run fill 427 58 -18 427 64 -18 stone
execute in minecraft:overworld run fill 427 65 -18 427 66 -18 dirt
execute in minecraft:overworld run setblock 427 67 -18 coarse_dirt
execute in minecraft:overworld run fill 427 68 -18 427 144 -18 air
execute in minecraft:overworld run fill 427 58 -17 427 64 -17 stone
execute in minecraft:overworld run fill 427 65 -17 427 66 -17 dirt
execute in minecraft:overworld run setblock 427 67 -17 coarse_dirt
execute in minecraft:overworld run fill 427 68 -17 427 144 -17 air
execute in minecraft:overworld run fill 427 58 -16 427 64 -16 stone
execute in minecraft:overworld run fill 427 65 -16 427 66 -16 dirt
execute in minecraft:overworld run setblock 427 67 -16 grass_block
execute in minecraft:overworld run fill 427 68 -16 427 144 -16 air
execute in minecraft:overworld run fill 427 58 -15 427 64 -15 stone
execute in minecraft:overworld run fill 427 65 -15 427 66 -15 dirt
execute in minecraft:overworld run setblock 427 67 -15 grass_block
execute in minecraft:overworld run fill 427 68 -15 427 144 -15 air
execute in minecraft:overworld run fill 427 58 -14 427 64 -14 stone
execute in minecraft:overworld run fill 427 65 -14 427 66 -14 dirt
execute in minecraft:overworld run setblock 427 67 -14 coarse_dirt
execute in minecraft:overworld run fill 427 68 -14 427 144 -14 air
execute in minecraft:overworld run fill 427 58 -13 427 64 -13 stone
execute in minecraft:overworld run fill 427 65 -13 427 66 -13 dirt
execute in minecraft:overworld run setblock 427 67 -13 grass_block
execute in minecraft:overworld run fill 427 68 -13 427 144 -13 air
execute in minecraft:overworld run fill 427 58 -12 427 63 -12 stone
execute in minecraft:overworld run fill 427 64 -12 427 65 -12 dirt
execute in minecraft:overworld run setblock 427 66 -12 coarse_dirt
execute in minecraft:overworld run fill 427 67 -12 427 144 -12 air
execute in minecraft:overworld run fill 427 58 -11 427 63 -11 stone
execute in minecraft:overworld run fill 427 64 -11 427 65 -11 dirt
execute in minecraft:overworld run setblock 427 66 -11 coarse_dirt
execute in minecraft:overworld run fill 427 67 -11 427 144 -11 air
execute in minecraft:overworld run fill 427 58 -10 427 63 -10 stone
execute in minecraft:overworld run fill 427 64 -10 427 65 -10 dirt
execute in minecraft:overworld run setblock 427 66 -10 coarse_dirt
execute in minecraft:overworld run fill 427 67 -10 427 144 -10 air
execute in minecraft:overworld run fill 427 58 -9 427 63 -9 stone
execute in minecraft:overworld run fill 427 64 -9 427 65 -9 dirt
execute in minecraft:overworld run setblock 427 66 -9 coarse_dirt
execute in minecraft:overworld run fill 427 67 -9 427 144 -9 air
execute in minecraft:overworld run fill 427 58 -8 427 63 -8 stone
execute in minecraft:overworld run fill 427 64 -8 427 65 -8 dirt
execute in minecraft:overworld run setblock 427 66 -8 grass_block
execute in minecraft:overworld run fill 427 67 -8 427 144 -8 air
execute in minecraft:overworld run fill 427 58 -7 427 63 -7 stone
execute in minecraft:overworld run fill 427 64 -7 427 65 -7 dirt
execute in minecraft:overworld run setblock 427 66 -7 grass_block
execute in minecraft:overworld run fill 427 67 -7 427 144 -7 air
execute in minecraft:overworld run fill 427 58 -6 427 63 -6 stone
execute in minecraft:overworld run fill 427 64 -6 427 65 -6 dirt
execute in minecraft:overworld run setblock 427 66 -6 grass_block
execute in minecraft:overworld run fill 427 67 -6 427 144 -6 air
execute in minecraft:overworld run fill 427 58 -5 427 63 -5 stone
execute in minecraft:overworld run fill 427 64 -5 427 65 -5 dirt
execute in minecraft:overworld run setblock 427 66 -5 grass_block
execute in minecraft:overworld run fill 427 67 -5 427 144 -5 air
execute in minecraft:overworld run fill 427 58 -4 427 63 -4 stone
execute in minecraft:overworld run fill 427 64 -4 427 65 -4 dirt
execute in minecraft:overworld run setblock 427 66 -4 coarse_dirt
execute in minecraft:overworld run fill 427 67 -4 427 144 -4 air
execute in minecraft:overworld run fill 427 58 -3 427 63 -3 stone
execute in minecraft:overworld run fill 427 64 -3 427 65 -3 dirt
execute in minecraft:overworld run setblock 427 66 -3 coarse_dirt
execute in minecraft:overworld run fill 427 67 -3 427 144 -3 air
execute in minecraft:overworld run fill 427 58 -2 427 63 -2 stone
execute in minecraft:overworld run fill 427 64 -2 427 65 -2 dirt
execute in minecraft:overworld run setblock 427 66 -2 coarse_dirt
execute in minecraft:overworld run fill 427 67 -2 427 144 -2 air
execute in minecraft:overworld run fill 427 58 -1 427 63 -1 stone
execute in minecraft:overworld run fill 427 64 -1 427 65 -1 dirt
execute in minecraft:overworld run setblock 427 66 -1 coarse_dirt
execute in minecraft:overworld run fill 427 67 -1 427 144 -1 air
execute in minecraft:overworld run fill 427 58 0 427 63 0 stone
execute in minecraft:overworld run fill 427 64 0 427 65 0 dirt
execute in minecraft:overworld run setblock 427 66 0 coarse_dirt
execute in minecraft:overworld run fill 427 67 0 427 144 0 air
execute in minecraft:overworld run fill 427 58 1 427 63 1 stone
execute in minecraft:overworld run fill 427 64 1 427 65 1 dirt
execute in minecraft:overworld run setblock 427 66 1 grass_block
execute in minecraft:overworld run fill 427 67 1 427 144 1 air
execute in minecraft:overworld run fill 427 58 2 427 63 2 stone
execute in minecraft:overworld run fill 427 64 2 427 65 2 dirt
execute in minecraft:overworld run setblock 427 66 2 grass_block
execute in minecraft:overworld run fill 427 67 2 427 144 2 air
execute in minecraft:overworld run fill 427 58 3 427 63 3 stone
execute in minecraft:overworld run fill 427 64 3 427 65 3 dirt
execute in minecraft:overworld run setblock 427 66 3 grass_block
execute in minecraft:overworld run fill 427 67 3 427 144 3 air
execute in minecraft:overworld run fill 427 58 4 427 63 4 stone
execute in minecraft:overworld run fill 427 64 4 427 65 4 dirt
execute in minecraft:overworld run setblock 427 66 4 coarse_dirt
execute in minecraft:overworld run fill 427 67 4 427 144 4 air
execute in minecraft:overworld run fill 427 58 5 427 63 5 stone
execute in minecraft:overworld run fill 427 64 5 427 65 5 dirt
execute in minecraft:overworld run setblock 427 66 5 coarse_dirt
execute in minecraft:overworld run fill 427 67 5 427 144 5 air
execute in minecraft:overworld run fill 427 58 6 427 63 6 stone
execute in minecraft:overworld run fill 427 64 6 427 65 6 dirt
execute in minecraft:overworld run setblock 427 66 6 coarse_dirt
execute in minecraft:overworld run fill 427 67 6 427 144 6 air
execute in minecraft:overworld run fill 427 58 7 427 63 7 stone
execute in minecraft:overworld run fill 427 64 7 427 65 7 dirt
execute in minecraft:overworld run setblock 427 66 7 coarse_dirt
execute in minecraft:overworld run fill 427 67 7 427 144 7 air
execute in minecraft:overworld run fill 427 58 8 427 64 8 stone
execute in minecraft:overworld run fill 427 65 8 427 66 8 dirt
execute in minecraft:overworld run setblock 427 67 8 grass_block
execute in minecraft:overworld run fill 427 68 8 427 144 8 air
execute in minecraft:overworld run fill 427 58 9 427 64 9 stone
execute in minecraft:overworld run fill 427 65 9 427 66 9 dirt
execute in minecraft:overworld run setblock 427 67 9 coarse_dirt
execute in minecraft:overworld run fill 427 68 9 427 144 9 air
execute in minecraft:overworld run fill 427 58 10 427 64 10 stone
execute in minecraft:overworld run fill 427 65 10 427 66 10 dirt
execute in minecraft:overworld run setblock 427 67 10 coarse_dirt
execute in minecraft:overworld run fill 427 68 10 427 144 10 air
execute in minecraft:overworld run fill 427 58 11 427 64 11 stone
execute in minecraft:overworld run fill 427 65 11 427 66 11 dirt
execute in minecraft:overworld run setblock 427 67 11 grass_block
execute in minecraft:overworld run fill 427 68 11 427 144 11 air
execute in minecraft:overworld run fill 427 58 12 427 64 12 stone
execute in minecraft:overworld run fill 427 65 12 427 66 12 dirt
execute in minecraft:overworld run setblock 427 67 12 coarse_dirt
execute in minecraft:overworld run fill 427 68 12 427 144 12 air
execute in minecraft:overworld run fill 427 58 13 427 64 13 stone
execute in minecraft:overworld run fill 427 65 13 427 66 13 dirt
execute in minecraft:overworld run setblock 427 67 13 coarse_dirt
execute in minecraft:overworld run fill 427 68 13 427 144 13 air
execute in minecraft:overworld run fill 427 58 14 427 64 14 stone
execute in minecraft:overworld run fill 427 65 14 427 66 14 dirt
execute in minecraft:overworld run setblock 427 67 14 coarse_dirt
execute in minecraft:overworld run fill 427 68 14 427 144 14 air
execute in minecraft:overworld run fill 427 58 15 427 65 15 stone
execute in minecraft:overworld run fill 427 66 15 427 67 15 dirt
execute in minecraft:overworld run setblock 427 68 15 coarse_dirt
execute in minecraft:overworld run fill 427 69 15 427 144 15 air
execute in minecraft:overworld run fill 427 58 16 427 65 16 stone
execute in minecraft:overworld run fill 427 66 16 427 67 16 dirt
execute in minecraft:overworld run setblock 427 68 16 coarse_dirt
execute in minecraft:overworld run fill 427 69 16 427 144 16 air
execute in minecraft:overworld run fill 427 58 17 427 65 17 stone
execute in minecraft:overworld run fill 427 66 17 427 67 17 dirt
execute in minecraft:overworld run setblock 427 68 17 grass_block
execute in minecraft:overworld run fill 427 69 17 427 144 17 air
execute in minecraft:overworld run fill 427 58 18 427 65 18 stone
execute in minecraft:overworld run fill 427 66 18 427 67 18 dirt
execute in minecraft:overworld run setblock 427 68 18 grass_block
execute in minecraft:overworld run fill 427 69 18 427 144 18 air
execute in minecraft:overworld run fill 427 58 19 427 65 19 stone
execute in minecraft:overworld run fill 427 66 19 427 67 19 dirt
execute in minecraft:overworld run setblock 427 68 19 coarse_dirt
execute in minecraft:overworld run fill 427 69 19 427 144 19 air
execute in minecraft:overworld run fill 427 58 20 427 65 20 stone
execute in minecraft:overworld run fill 427 66 20 427 67 20 dirt
execute in minecraft:overworld run setblock 427 68 20 grass_block
execute in minecraft:overworld run fill 427 69 20 427 144 20 air
execute in minecraft:overworld run fill 427 58 21 427 65 21 stone
execute in minecraft:overworld run fill 427 66 21 427 67 21 dirt
execute in minecraft:overworld run setblock 427 68 21 grass_block
execute in minecraft:overworld run fill 427 69 21 427 144 21 air
execute in minecraft:overworld run fill 427 58 22 427 66 22 stone
execute in minecraft:overworld run fill 427 67 22 427 68 22 dirt
execute in minecraft:overworld run setblock 427 69 22 coarse_dirt
execute in minecraft:overworld run fill 427 70 22 427 144 22 air
execute in minecraft:overworld run fill 427 58 23 427 66 23 stone
execute in minecraft:overworld run fill 427 67 23 427 68 23 dirt
execute in minecraft:overworld run setblock 427 69 23 grass_block
execute in minecraft:overworld run fill 427 70 23 427 144 23 air
execute in minecraft:overworld run fill 427 58 24 427 66 24 stone
execute in minecraft:overworld run fill 427 67 24 427 68 24 dirt
execute in minecraft:overworld run setblock 427 69 24 grass_block
execute in minecraft:overworld run fill 427 70 24 427 144 24 air
execute in minecraft:overworld run fill 427 58 25 427 66 25 stone
execute in minecraft:overworld run fill 427 67 25 427 68 25 dirt
execute in minecraft:overworld run setblock 427 69 25 coarse_dirt
execute in minecraft:overworld run fill 427 70 25 427 144 25 air
execute in minecraft:overworld run fill 427 58 26 427 66 26 stone
execute in minecraft:overworld run fill 427 67 26 427 68 26 dirt
execute in minecraft:overworld run setblock 427 69 26 coarse_dirt
execute in minecraft:overworld run fill 427 70 26 427 144 26 air
execute in minecraft:overworld run fill 427 58 27 427 66 27 stone
execute in minecraft:overworld run fill 427 67 27 427 68 27 dirt
execute in minecraft:overworld run setblock 427 69 27 grass_block
execute in minecraft:overworld run fill 427 70 27 427 144 27 air
execute in minecraft:overworld run fill 427 58 28 427 66 28 stone
execute in minecraft:overworld run fill 427 67 28 427 68 28 dirt
execute in minecraft:overworld run setblock 427 69 28 coarse_dirt
execute in minecraft:overworld run fill 427 70 28 427 144 28 air
execute in minecraft:overworld run fill 427 58 29 427 66 29 stone
execute in minecraft:overworld run fill 427 67 29 427 68 29 dirt
execute in minecraft:overworld run setblock 427 69 29 grass_block
execute in minecraft:overworld run fill 427 70 29 427 144 29 air
execute in minecraft:overworld run fill 427 58 30 427 66 30 stone
execute in minecraft:overworld run fill 427 67 30 427 68 30 dirt
execute in minecraft:overworld run setblock 427 69 30 coarse_dirt
execute in minecraft:overworld run fill 427 70 30 427 144 30 air
execute in minecraft:overworld run fill 427 58 31 427 66 31 stone
execute in minecraft:overworld run fill 427 67 31 427 68 31 dirt
execute in minecraft:overworld run setblock 427 69 31 coarse_dirt
execute in minecraft:overworld run fill 427 70 31 427 144 31 air
execute in minecraft:overworld run fill 427 58 32 427 66 32 stone
execute in minecraft:overworld run fill 427 67 32 427 68 32 dirt
execute in minecraft:overworld run setblock 427 69 32 coarse_dirt
execute in minecraft:overworld run fill 427 70 32 427 144 32 air
execute in minecraft:overworld run fill 427 58 33 427 66 33 stone
execute in minecraft:overworld run fill 427 67 33 427 68 33 dirt
execute in minecraft:overworld run setblock 427 69 33 coarse_dirt
execute in minecraft:overworld run fill 427 70 33 427 144 33 air
execute in minecraft:overworld run fill 427 58 34 427 66 34 stone
execute in minecraft:overworld run fill 427 67 34 427 68 34 dirt
execute in minecraft:overworld run setblock 427 69 34 coarse_dirt
execute in minecraft:overworld run fill 427 70 34 427 144 34 air
execute in minecraft:overworld run fill 427 58 35 427 65 35 stone
execute in minecraft:overworld run fill 427 66 35 427 67 35 dirt
execute in minecraft:overworld run setblock 427 68 35 coarse_dirt
execute in minecraft:overworld run fill 427 69 35 427 144 35 air
execute in minecraft:overworld run fill 427 58 36 427 65 36 stone
execute in minecraft:overworld run fill 427 66 36 427 67 36 dirt
execute in minecraft:overworld run setblock 427 68 36 coarse_dirt
execute in minecraft:overworld run fill 427 69 36 427 144 36 air
execute in minecraft:overworld run fill 427 58 37 427 65 37 stone
execute in minecraft:overworld run fill 427 66 37 427 67 37 dirt
execute in minecraft:overworld run setblock 427 68 37 coarse_dirt
execute in minecraft:overworld run fill 427 69 37 427 144 37 air
execute in minecraft:overworld run fill 427 58 38 427 65 38 stone
execute in minecraft:overworld run fill 427 66 38 427 67 38 dirt
execute in minecraft:overworld run setblock 427 68 38 coarse_dirt
schedule function blade_gallery:random/battlefield/part_144 1t replace
