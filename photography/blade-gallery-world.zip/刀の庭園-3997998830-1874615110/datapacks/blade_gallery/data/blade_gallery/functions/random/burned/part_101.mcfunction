execute in minecraft:overworld run setblock 271 61 12 gravel
execute in minecraft:overworld run fill 271 62 12 271 144 12 air
execute in minecraft:overworld run fill 271 62 12 271 64 12 water
execute in minecraft:overworld run fill 271 58 13 271 58 13 stone
execute in minecraft:overworld run fill 271 59 13 271 60 13 dirt
execute in minecraft:overworld run setblock 271 61 13 gravel
execute in minecraft:overworld run fill 271 62 13 271 144 13 air
execute in minecraft:overworld run fill 271 62 13 271 64 13 water
execute in minecraft:overworld run fill 271 58 14 271 58 14 stone
execute in minecraft:overworld run fill 271 59 14 271 60 14 dirt
execute in minecraft:overworld run setblock 271 61 14 gravel
execute in minecraft:overworld run fill 271 62 14 271 144 14 air
execute in minecraft:overworld run fill 271 62 14 271 64 14 water
execute in minecraft:overworld run fill 271 58 15 271 57 15 stone
execute in minecraft:overworld run fill 271 58 15 271 59 15 dirt
execute in minecraft:overworld run setblock 271 60 15 gravel
execute in minecraft:overworld run fill 271 61 15 271 144 15 air
execute in minecraft:overworld run fill 271 61 15 271 64 15 water
execute in minecraft:overworld run fill 271 58 16 271 57 16 stone
execute in minecraft:overworld run fill 271 58 16 271 59 16 dirt
execute in minecraft:overworld run setblock 271 60 16 gravel
execute in minecraft:overworld run fill 271 61 16 271 144 16 air
execute in minecraft:overworld run fill 271 61 16 271 64 16 water
execute in minecraft:overworld run fill 271 58 17 271 57 17 stone
execute in minecraft:overworld run fill 271 58 17 271 59 17 dirt
execute in minecraft:overworld run setblock 271 60 17 gravel
execute in minecraft:overworld run fill 271 61 17 271 144 17 air
execute in minecraft:overworld run fill 271 61 17 271 64 17 water
execute in minecraft:overworld run fill 271 58 18 271 57 18 stone
execute in minecraft:overworld run fill 271 58 18 271 59 18 dirt
execute in minecraft:overworld run setblock 271 60 18 gravel
execute in minecraft:overworld run fill 271 61 18 271 144 18 air
execute in minecraft:overworld run fill 271 61 18 271 64 18 water
execute in minecraft:overworld run fill 271 58 19 271 57 19 stone
execute in minecraft:overworld run fill 271 58 19 271 59 19 dirt
execute in minecraft:overworld run setblock 271 60 19 gravel
execute in minecraft:overworld run fill 271 61 19 271 144 19 air
execute in minecraft:overworld run fill 271 61 19 271 64 19 water
execute in minecraft:overworld run fill 271 58 20 271 57 20 stone
execute in minecraft:overworld run fill 271 58 20 271 59 20 dirt
execute in minecraft:overworld run setblock 271 60 20 gravel
execute in minecraft:overworld run fill 271 61 20 271 144 20 air
execute in minecraft:overworld run fill 271 61 20 271 64 20 water
execute in minecraft:overworld run fill 271 58 21 271 57 21 stone
execute in minecraft:overworld run fill 271 58 21 271 59 21 dirt
execute in minecraft:overworld run setblock 271 60 21 gravel
execute in minecraft:overworld run fill 271 61 21 271 144 21 air
execute in minecraft:overworld run fill 271 61 21 271 64 21 water
execute in minecraft:overworld run fill 271 58 22 271 57 22 stone
execute in minecraft:overworld run fill 271 58 22 271 59 22 dirt
execute in minecraft:overworld run setblock 271 60 22 gravel
execute in minecraft:overworld run fill 271 61 22 271 144 22 air
execute in minecraft:overworld run fill 271 61 22 271 64 22 water
execute in minecraft:overworld run fill 271 58 23 271 57 23 stone
execute in minecraft:overworld run fill 271 58 23 271 59 23 dirt
execute in minecraft:overworld run setblock 271 60 23 gravel
execute in minecraft:overworld run fill 271 61 23 271 144 23 air
execute in minecraft:overworld run fill 271 61 23 271 64 23 water
execute in minecraft:overworld run fill 271 58 24 271 58 24 stone
execute in minecraft:overworld run fill 271 59 24 271 60 24 dirt
execute in minecraft:overworld run setblock 271 61 24 gravel
execute in minecraft:overworld run fill 271 62 24 271 144 24 air
execute in minecraft:overworld run fill 271 62 24 271 64 24 water
execute in minecraft:overworld run fill 271 58 25 271 58 25 stone
execute in minecraft:overworld run fill 271 59 25 271 60 25 dirt
execute in minecraft:overworld run setblock 271 61 25 gravel
execute in minecraft:overworld run fill 271 62 25 271 144 25 air
execute in minecraft:overworld run fill 271 62 25 271 64 25 water
execute in minecraft:overworld run fill 271 58 26 271 58 26 stone
execute in minecraft:overworld run fill 271 59 26 271 60 26 dirt
execute in minecraft:overworld run setblock 271 61 26 gravel
execute in minecraft:overworld run fill 271 62 26 271 144 26 air
execute in minecraft:overworld run fill 271 62 26 271 64 26 water
execute in minecraft:overworld run fill 271 58 27 271 59 27 stone
execute in minecraft:overworld run fill 271 60 27 271 61 27 dirt
execute in minecraft:overworld run setblock 271 62 27 gravel
execute in minecraft:overworld run fill 271 63 27 271 144 27 air
execute in minecraft:overworld run fill 271 63 27 271 64 27 water
execute in minecraft:overworld run fill 271 58 28 271 59 28 stone
execute in minecraft:overworld run fill 271 60 28 271 61 28 dirt
execute in minecraft:overworld run setblock 271 62 28 gravel
execute in minecraft:overworld run fill 271 63 28 271 144 28 air
execute in minecraft:overworld run fill 271 63 28 271 64 28 water
execute in minecraft:overworld run fill 271 58 29 271 59 29 stone
execute in minecraft:overworld run fill 271 60 29 271 61 29 dirt
execute in minecraft:overworld run setblock 271 62 29 gravel
execute in minecraft:overworld run fill 271 63 29 271 144 29 air
execute in minecraft:overworld run fill 271 63 29 271 64 29 water
execute in minecraft:overworld run fill 271 58 30 271 59 30 stone
execute in minecraft:overworld run fill 271 60 30 271 61 30 dirt
execute in minecraft:overworld run setblock 271 62 30 gravel
execute in minecraft:overworld run fill 271 63 30 271 144 30 air
execute in minecraft:overworld run fill 271 63 30 271 64 30 water
execute in minecraft:overworld run fill 271 58 31 271 60 31 stone
execute in minecraft:overworld run fill 271 61 31 271 62 31 dirt
execute in minecraft:overworld run setblock 271 63 31 gravel
execute in minecraft:overworld run fill 271 64 31 271 144 31 air
execute in minecraft:overworld run fill 271 64 31 271 64 31 water
execute in minecraft:overworld run fill 271 58 32 271 60 32 stone
execute in minecraft:overworld run fill 271 61 32 271 62 32 dirt
execute in minecraft:overworld run setblock 271 63 32 gravel
execute in minecraft:overworld run fill 271 64 32 271 144 32 air
execute in minecraft:overworld run fill 271 64 32 271 64 32 water
execute in minecraft:overworld run fill 271 58 33 271 60 33 stone
execute in minecraft:overworld run fill 271 61 33 271 62 33 dirt
execute in minecraft:overworld run setblock 271 63 33 gravel
execute in minecraft:overworld run fill 271 64 33 271 144 33 air
execute in minecraft:overworld run fill 271 64 33 271 64 33 water
execute in minecraft:overworld run fill 271 58 34 271 61 34 stone
execute in minecraft:overworld run fill 271 62 34 271 63 34 dirt
execute in minecraft:overworld run setblock 271 64 34 grass_block
execute in minecraft:overworld run fill 271 65 34 271 144 34 air
execute in minecraft:overworld run fill 271 58 35 271 61 35 stone
execute in minecraft:overworld run fill 271 62 35 271 63 35 dirt
execute in minecraft:overworld run setblock 271 64 35 grass_block
execute in minecraft:overworld run fill 271 65 35 271 144 35 air
execute in minecraft:overworld run fill 271 58 36 271 61 36 stone
execute in minecraft:overworld run fill 271 62 36 271 63 36 dirt
execute in minecraft:overworld run setblock 271 64 36 grass_block
execute in minecraft:overworld run fill 271 65 36 271 144 36 air
execute in minecraft:overworld run fill 271 58 37 271 61 37 stone
execute in minecraft:overworld run fill 271 62 37 271 63 37 dirt
execute in minecraft:overworld run setblock 271 64 37 grass_block
execute in minecraft:overworld run fill 271 65 37 271 144 37 air
execute in minecraft:overworld run fill 271 58 38 271 61 38 stone
execute in minecraft:overworld run fill 271 62 38 271 63 38 dirt
execute in minecraft:overworld run setblock 271 64 38 coarse_dirt
execute in minecraft:overworld run fill 271 65 38 271 144 38 air
execute in minecraft:overworld run fill 271 58 39 271 61 39 stone
execute in minecraft:overworld run fill 271 62 39 271 63 39 dirt
execute in minecraft:overworld run setblock 271 64 39 coarse_dirt
execute in minecraft:overworld run fill 271 65 39 271 144 39 air
execute in minecraft:overworld run fill 271 58 40 271 61 40 stone
execute in minecraft:overworld run fill 271 62 40 271 63 40 dirt
execute in minecraft:overworld run setblock 271 64 40 coarse_dirt
execute in minecraft:overworld run fill 271 65 40 271 144 40 air
execute in minecraft:overworld run fill 271 58 41 271 61 41 stone
execute in minecraft:overworld run fill 271 62 41 271 63 41 dirt
execute in minecraft:overworld run setblock 271 64 41 coarse_dirt
execute in minecraft:overworld run fill 271 65 41 271 144 41 air
execute in minecraft:overworld run fill 271 58 42 271 61 42 stone
execute in minecraft:overworld run fill 271 62 42 271 63 42 dirt
execute in minecraft:overworld run setblock 271 64 42 coarse_dirt
execute in minecraft:overworld run fill 271 65 42 271 144 42 air
execute in minecraft:overworld run fill 271 58 43 271 61 43 stone
execute in minecraft:overworld run fill 271 62 43 271 63 43 dirt
execute in minecraft:overworld run setblock 271 64 43 coarse_dirt
execute in minecraft:overworld run fill 271 65 43 271 144 43 air
execute in minecraft:overworld run fill 271 58 44 271 61 44 stone
execute in minecraft:overworld run fill 271 62 44 271 63 44 dirt
execute in minecraft:overworld run setblock 271 64 44 coarse_dirt
execute in minecraft:overworld run fill 271 65 44 271 144 44 air
execute in minecraft:overworld run fill 271 58 45 271 61 45 stone
execute in minecraft:overworld run fill 271 62 45 271 63 45 dirt
execute in minecraft:overworld run setblock 271 64 45 grass_block
execute in minecraft:overworld run fill 271 65 45 271 144 45 air
execute in minecraft:overworld run fill 271 58 46 271 61 46 stone
execute in minecraft:overworld run fill 271 62 46 271 63 46 dirt
execute in minecraft:overworld run setblock 271 64 46 grass_block
execute in minecraft:overworld run fill 271 65 46 271 144 46 air
execute in minecraft:overworld run fill 271 58 47 271 61 47 stone
execute in minecraft:overworld run fill 271 62 47 271 63 47 dirt
execute in minecraft:overworld run setblock 271 64 47 grass_block
execute in minecraft:overworld run fill 271 65 47 271 144 47 air
execute in minecraft:overworld run fill 272 58 -48 272 61 -48 stone
execute in minecraft:overworld run fill 272 62 -48 272 63 -48 dirt
execute in minecraft:overworld run setblock 272 64 -48 grass_block
execute in minecraft:overworld run fill 272 65 -48 272 144 -48 air
execute in minecraft:overworld run fill 272 58 -47 272 63 -47 stone
execute in minecraft:overworld run fill 272 64 -47 272 65 -47 dirt
execute in minecraft:overworld run setblock 272 66 -47 coarse_dirt
execute in minecraft:overworld run fill 272 67 -47 272 144 -47 air
execute in minecraft:overworld run fill 272 58 -46 272 65 -46 stone
execute in minecraft:overworld run fill 272 66 -46 272 67 -46 dirt
execute in minecraft:overworld run setblock 272 68 -46 coarse_dirt
execute in minecraft:overworld run fill 272 69 -46 272 144 -46 air
execute in minecraft:overworld run fill 272 58 -45 272 67 -45 stone
execute in minecraft:overworld run fill 272 68 -45 272 69 -45 dirt
execute in minecraft:overworld run setblock 272 70 -45 coarse_dirt
execute in minecraft:overworld run fill 272 71 -45 272 144 -45 air
execute in minecraft:overworld run fill 272 58 -44 272 69 -44 stone
execute in minecraft:overworld run fill 272 70 -44 272 71 -44 dirt
execute in minecraft:overworld run setblock 272 72 -44 coarse_dirt
execute in minecraft:overworld run fill 272 73 -44 272 144 -44 air
execute in minecraft:overworld run fill 272 58 -43 272 71 -43 stone
execute in minecraft:overworld run fill 272 72 -43 272 73 -43 dirt
execute in minecraft:overworld run setblock 272 74 -43 coarse_dirt
execute in minecraft:overworld run fill 272 75 -43 272 144 -43 air
execute in minecraft:overworld run fill 272 58 -42 272 73 -42 stone
execute in minecraft:overworld run fill 272 74 -42 272 75 -42 dirt
execute in minecraft:overworld run setblock 272 76 -42 coarse_dirt
execute in minecraft:overworld run fill 272 77 -42 272 144 -42 air
execute in minecraft:overworld run fill 272 58 -41 272 74 -41 stone
execute in minecraft:overworld run fill 272 75 -41 272 76 -41 dirt
execute in minecraft:overworld run setblock 272 77 -41 grass_block
execute in minecraft:overworld run fill 272 78 -41 272 144 -41 air
execute in minecraft:overworld run fill 272 58 -40 272 76 -40 stone
execute in minecraft:overworld run fill 272 77 -40 272 78 -40 dirt
execute in minecraft:overworld run setblock 272 79 -40 grass_block
execute in minecraft:overworld run fill 272 80 -40 272 144 -40 air
execute in minecraft:overworld run fill 272 58 -39 272 77 -39 stone
execute in minecraft:overworld run fill 272 78 -39 272 79 -39 dirt
execute in minecraft:overworld run setblock 272 80 -39 coarse_dirt
execute in minecraft:overworld run fill 272 81 -39 272 144 -39 air
execute in minecraft:overworld run setblock 272 81 -39 grass
execute in minecraft:overworld run fill 272 58 -38 272 78 -38 stone
execute in minecraft:overworld run fill 272 79 -38 272 80 -38 dirt
execute in minecraft:overworld run setblock 272 81 -38 grass_block
execute in minecraft:overworld run fill 272 82 -38 272 144 -38 air
execute in minecraft:overworld run setblock 272 82 -38 grass
execute in minecraft:overworld run fill 272 58 -37 272 78 -37 stone
execute in minecraft:overworld run fill 272 79 -37 272 80 -37 dirt
execute in minecraft:overworld run setblock 272 81 -37 grass_block
execute in minecraft:overworld run fill 272 82 -37 272 144 -37 air
execute in minecraft:overworld run setblock 272 82 -37 grass
execute in minecraft:overworld run fill 272 58 -36 272 77 -36 stone
execute in minecraft:overworld run fill 272 78 -36 272 79 -36 dirt
execute in minecraft:overworld run setblock 272 80 -36 coarse_dirt
execute in minecraft:overworld run fill 272 81 -36 272 144 -36 air
execute in minecraft:overworld run fill 272 58 -35 272 77 -35 stone
execute in minecraft:overworld run fill 272 78 -35 272 79 -35 dirt
execute in minecraft:overworld run setblock 272 80 -35 coarse_dirt
execute in minecraft:overworld run fill 272 81 -35 272 144 -35 air
execute in minecraft:overworld run fill 272 58 -34 272 77 -34 stone
execute in minecraft:overworld run fill 272 78 -34 272 79 -34 dirt
execute in minecraft:overworld run setblock 272 80 -34 grass_block
execute in minecraft:overworld run fill 272 81 -34 272 144 -34 air
execute in minecraft:overworld run fill 272 58 -33 272 76 -33 stone
execute in minecraft:overworld run fill 272 77 -33 272 78 -33 dirt
execute in minecraft:overworld run setblock 272 79 -33 coarse_dirt
execute in minecraft:overworld run fill 272 80 -33 272 144 -33 air
execute in minecraft:overworld run fill 272 58 -32 272 76 -32 stone
execute in minecraft:overworld run fill 272 77 -32 272 78 -32 dirt
execute in minecraft:overworld run setblock 272 79 -32 coarse_dirt
execute in minecraft:overworld run fill 272 80 -32 272 144 -32 air
execute in minecraft:overworld run fill 272 58 -31 272 76 -31 stone
execute in minecraft:overworld run fill 272 77 -31 272 78 -31 dirt
execute in minecraft:overworld run setblock 272 79 -31 coarse_dirt
execute in minecraft:overworld run fill 272 80 -31 272 144 -31 air
execute in minecraft:overworld run fill 272 58 -30 272 75 -30 stone
execute in minecraft:overworld run fill 272 76 -30 272 77 -30 dirt
execute in minecraft:overworld run setblock 272 78 -30 coarse_dirt
execute in minecraft:overworld run fill 272 79 -30 272 144 -30 air
execute in minecraft:overworld run fill 272 58 -29 272 75 -29 stone
execute in minecraft:overworld run fill 272 76 -29 272 77 -29 dirt
execute in minecraft:overworld run setblock 272 78 -29 coarse_dirt
execute in minecraft:overworld run fill 272 79 -29 272 144 -29 air
execute in minecraft:overworld run fill 272 58 -28 272 75 -28 stone
execute in minecraft:overworld run fill 272 76 -28 272 77 -28 dirt
execute in minecraft:overworld run setblock 272 78 -28 coarse_dirt
execute in minecraft:overworld run fill 272 79 -28 272 144 -28 air
execute in minecraft:overworld run fill 272 58 -27 272 74 -27 stone
execute in minecraft:overworld run fill 272 75 -27 272 76 -27 dirt
execute in minecraft:overworld run setblock 272 77 -27 grass_block
execute in minecraft:overworld run fill 272 78 -27 272 144 -27 air
execute in minecraft:overworld run fill 272 58 -26 272 74 -26 stone
schedule function blade_gallery:random/burned/part_102 1t replace
