execute in minecraft:overworld run fill 351 58 25 351 68 25 stone
execute in minecraft:overworld run fill 351 69 25 351 70 25 dirt
execute in minecraft:overworld run setblock 351 71 25 coarse_dirt
execute in minecraft:overworld run fill 351 72 25 351 144 25 air
execute in minecraft:overworld run fill 351 58 26 351 68 26 stone
execute in minecraft:overworld run fill 351 69 26 351 70 26 dirt
execute in minecraft:overworld run setblock 351 71 26 coarse_dirt
execute in minecraft:overworld run fill 351 72 26 351 144 26 air
execute in minecraft:overworld run fill 351 58 27 351 68 27 stone
execute in minecraft:overworld run fill 351 69 27 351 70 27 dirt
execute in minecraft:overworld run setblock 351 71 27 coarse_dirt
execute in minecraft:overworld run fill 351 72 27 351 144 27 air
execute in minecraft:overworld run setblock 351 72 27 grass
execute in minecraft:overworld run fill 351 58 28 351 68 28 stone
execute in minecraft:overworld run fill 351 69 28 351 70 28 dirt
execute in minecraft:overworld run setblock 351 71 28 coarse_dirt
execute in minecraft:overworld run fill 351 72 28 351 144 28 air
execute in minecraft:overworld run fill 351 58 29 351 68 29 stone
execute in minecraft:overworld run fill 351 69 29 351 70 29 dirt
execute in minecraft:overworld run setblock 351 71 29 coarse_dirt
execute in minecraft:overworld run fill 351 72 29 351 144 29 air
execute in minecraft:overworld run fill 351 58 30 351 68 30 stone
execute in minecraft:overworld run fill 351 69 30 351 70 30 dirt
execute in minecraft:overworld run setblock 351 71 30 coarse_dirt
execute in minecraft:overworld run fill 351 72 30 351 144 30 air
execute in minecraft:overworld run fill 351 58 31 351 68 31 stone
execute in minecraft:overworld run fill 351 69 31 351 70 31 dirt
execute in minecraft:overworld run setblock 351 71 31 coarse_dirt
execute in minecraft:overworld run fill 351 72 31 351 144 31 air
execute in minecraft:overworld run fill 351 58 32 351 67 32 stone
execute in minecraft:overworld run fill 351 68 32 351 69 32 dirt
execute in minecraft:overworld run setblock 351 70 32 coarse_dirt
execute in minecraft:overworld run fill 351 71 32 351 144 32 air
execute in minecraft:overworld run fill 351 58 33 351 67 33 stone
execute in minecraft:overworld run fill 351 68 33 351 69 33 dirt
execute in minecraft:overworld run setblock 351 70 33 grass_block
execute in minecraft:overworld run fill 351 71 33 351 144 33 air
execute in minecraft:overworld run fill 351 58 34 351 67 34 stone
execute in minecraft:overworld run fill 351 68 34 351 69 34 dirt
execute in minecraft:overworld run setblock 351 70 34 grass_block
execute in minecraft:overworld run fill 351 71 34 351 144 34 air
execute in minecraft:overworld run fill 351 58 35 351 67 35 stone
execute in minecraft:overworld run fill 351 68 35 351 69 35 dirt
execute in minecraft:overworld run setblock 351 70 35 coarse_dirt
execute in minecraft:overworld run fill 351 71 35 351 144 35 air
execute in minecraft:overworld run fill 351 58 36 351 67 36 stone
execute in minecraft:overworld run fill 351 68 36 351 69 36 dirt
execute in minecraft:overworld run setblock 351 70 36 coarse_dirt
execute in minecraft:overworld run fill 351 71 36 351 144 36 air
execute in minecraft:overworld run fill 351 58 37 351 67 37 stone
execute in minecraft:overworld run fill 351 68 37 351 69 37 dirt
execute in minecraft:overworld run setblock 351 70 37 coarse_dirt
execute in minecraft:overworld run fill 351 71 37 351 144 37 air
execute in minecraft:overworld run fill 351 58 38 351 67 38 stone
execute in minecraft:overworld run fill 351 68 38 351 69 38 dirt
execute in minecraft:overworld run setblock 351 70 38 coarse_dirt
execute in minecraft:overworld run fill 351 71 38 351 144 38 air
execute in minecraft:overworld run setblock 351 71 38 mossy_cobblestone
execute in minecraft:overworld run fill 351 58 39 351 66 39 stone
execute in minecraft:overworld run fill 351 67 39 351 68 39 dirt
execute in minecraft:overworld run setblock 351 69 39 coarse_dirt
execute in minecraft:overworld run fill 351 70 39 351 144 39 air
execute in minecraft:overworld run setblock 351 70 39 grass
execute in minecraft:overworld run fill 351 58 40 351 66 40 stone
execute in minecraft:overworld run fill 351 67 40 351 68 40 dirt
execute in minecraft:overworld run setblock 351 69 40 grass_block
execute in minecraft:overworld run fill 351 70 40 351 144 40 air
execute in minecraft:overworld run fill 351 58 41 351 65 41 stone
execute in minecraft:overworld run fill 351 66 41 351 67 41 dirt
execute in minecraft:overworld run setblock 351 68 41 coarse_dirt
execute in minecraft:overworld run fill 351 69 41 351 144 41 air
execute in minecraft:overworld run setblock 351 69 41 grass
execute in minecraft:overworld run fill 351 58 42 351 65 42 stone
execute in minecraft:overworld run fill 351 66 42 351 67 42 dirt
execute in minecraft:overworld run setblock 351 68 42 coarse_dirt
execute in minecraft:overworld run fill 351 69 42 351 144 42 air
execute in minecraft:overworld run fill 351 58 43 351 64 43 stone
execute in minecraft:overworld run fill 351 65 43 351 66 43 dirt
execute in minecraft:overworld run setblock 351 67 43 grass_block
execute in minecraft:overworld run fill 351 68 43 351 144 43 air
execute in minecraft:overworld run fill 351 58 44 351 63 44 stone
execute in minecraft:overworld run fill 351 64 44 351 65 44 dirt
execute in minecraft:overworld run setblock 351 66 44 grass_block
execute in minecraft:overworld run fill 351 67 44 351 144 44 air
execute in minecraft:overworld run fill 351 58 45 351 63 45 stone
execute in minecraft:overworld run fill 351 64 45 351 65 45 dirt
execute in minecraft:overworld run setblock 351 66 45 grass_block
execute in minecraft:overworld run fill 351 67 45 351 144 45 air
execute in minecraft:overworld run fill 351 58 46 351 62 46 stone
execute in minecraft:overworld run fill 351 63 46 351 64 46 dirt
execute in minecraft:overworld run setblock 351 65 46 grass_block
execute in minecraft:overworld run fill 351 66 46 351 144 46 air
execute in minecraft:overworld run fill 351 58 47 351 62 47 stone
execute in minecraft:overworld run fill 351 63 47 351 64 47 dirt
execute in minecraft:overworld run setblock 351 65 47 coarse_dirt
execute in minecraft:overworld run fill 351 66 47 351 144 47 air
execute in minecraft:overworld run fill 352 58 -48 352 61 -48 stone
execute in minecraft:overworld run fill 352 62 -48 352 63 -48 dirt
execute in minecraft:overworld run setblock 352 64 -48 coarse_dirt
execute in minecraft:overworld run fill 352 65 -48 352 144 -48 air
execute in minecraft:overworld run fill 352 58 -47 352 63 -47 stone
execute in minecraft:overworld run fill 352 64 -47 352 65 -47 dirt
execute in minecraft:overworld run setblock 352 66 -47 coarse_dirt
execute in minecraft:overworld run fill 352 67 -47 352 144 -47 air
execute in minecraft:overworld run fill 352 58 -46 352 65 -46 stone
execute in minecraft:overworld run fill 352 66 -46 352 67 -46 dirt
execute in minecraft:overworld run setblock 352 68 -46 grass_block
execute in minecraft:overworld run fill 352 69 -46 352 144 -46 air
execute in minecraft:overworld run fill 352 58 -45 352 67 -45 stone
execute in minecraft:overworld run fill 352 68 -45 352 69 -45 dirt
execute in minecraft:overworld run setblock 352 70 -45 coarse_dirt
execute in minecraft:overworld run fill 352 71 -45 352 144 -45 air
execute in minecraft:overworld run fill 352 58 -44 352 68 -44 stone
execute in minecraft:overworld run fill 352 69 -44 352 70 -44 dirt
execute in minecraft:overworld run setblock 352 71 -44 grass_block
execute in minecraft:overworld run fill 352 72 -44 352 144 -44 air
execute in minecraft:overworld run fill 352 58 -43 352 70 -43 stone
execute in minecraft:overworld run fill 352 71 -43 352 72 -43 dirt
execute in minecraft:overworld run setblock 352 73 -43 coarse_dirt
execute in minecraft:overworld run fill 352 74 -43 352 144 -43 air
execute in minecraft:overworld run fill 352 58 -42 352 71 -42 stone
execute in minecraft:overworld run fill 352 72 -42 352 73 -42 dirt
execute in minecraft:overworld run setblock 352 74 -42 grass_block
execute in minecraft:overworld run fill 352 75 -42 352 144 -42 air
execute in minecraft:overworld run fill 352 58 -41 352 73 -41 stone
execute in minecraft:overworld run fill 352 74 -41 352 75 -41 dirt
execute in minecraft:overworld run setblock 352 76 -41 grass_block
execute in minecraft:overworld run fill 352 77 -41 352 144 -41 air
execute in minecraft:overworld run fill 352 58 -40 352 74 -40 stone
execute in minecraft:overworld run fill 352 75 -40 352 76 -40 dirt
execute in minecraft:overworld run setblock 352 77 -40 grass_block
execute in minecraft:overworld run fill 352 78 -40 352 144 -40 air
execute in minecraft:overworld run fill 352 58 -39 352 75 -39 stone
execute in minecraft:overworld run fill 352 76 -39 352 77 -39 dirt
execute in minecraft:overworld run setblock 352 78 -39 coarse_dirt
execute in minecraft:overworld run fill 352 79 -39 352 144 -39 air
execute in minecraft:overworld run fill 352 58 -38 352 75 -38 stone
execute in minecraft:overworld run fill 352 76 -38 352 77 -38 dirt
execute in minecraft:overworld run setblock 352 78 -38 coarse_dirt
execute in minecraft:overworld run fill 352 79 -38 352 144 -38 air
execute in minecraft:overworld run fill 352 58 -37 352 75 -37 stone
execute in minecraft:overworld run fill 352 76 -37 352 77 -37 dirt
execute in minecraft:overworld run setblock 352 78 -37 coarse_dirt
execute in minecraft:overworld run fill 352 79 -37 352 144 -37 air
execute in minecraft:overworld run fill 352 58 -36 352 75 -36 stone
execute in minecraft:overworld run fill 352 76 -36 352 77 -36 dirt
execute in minecraft:overworld run setblock 352 78 -36 coarse_dirt
execute in minecraft:overworld run fill 352 79 -36 352 144 -36 air
execute in minecraft:overworld run fill 352 58 -35 352 74 -35 stone
execute in minecraft:overworld run fill 352 75 -35 352 76 -35 dirt
execute in minecraft:overworld run setblock 352 77 -35 coarse_dirt
execute in minecraft:overworld run fill 352 78 -35 352 144 -35 air
execute in minecraft:overworld run fill 352 58 -34 352 74 -34 stone
execute in minecraft:overworld run fill 352 75 -34 352 76 -34 dirt
execute in minecraft:overworld run setblock 352 77 -34 coarse_dirt
execute in minecraft:overworld run fill 352 78 -34 352 144 -34 air
execute in minecraft:overworld run fill 352 58 -33 352 74 -33 stone
execute in minecraft:overworld run fill 352 75 -33 352 76 -33 dirt
execute in minecraft:overworld run setblock 352 77 -33 grass_block
execute in minecraft:overworld run fill 352 78 -33 352 144 -33 air
execute in minecraft:overworld run fill 352 58 -32 352 74 -32 stone
execute in minecraft:overworld run fill 352 75 -32 352 76 -32 dirt
execute in minecraft:overworld run setblock 352 77 -32 coarse_dirt
execute in minecraft:overworld run fill 352 78 -32 352 144 -32 air
execute in minecraft:overworld run fill 352 58 -31 352 74 -31 stone
execute in minecraft:overworld run fill 352 75 -31 352 76 -31 dirt
execute in minecraft:overworld run setblock 352 77 -31 coarse_dirt
execute in minecraft:overworld run fill 352 78 -31 352 144 -31 air
execute in minecraft:overworld run fill 352 58 -30 352 74 -30 stone
execute in minecraft:overworld run fill 352 75 -30 352 76 -30 dirt
execute in minecraft:overworld run setblock 352 77 -30 coarse_dirt
execute in minecraft:overworld run fill 352 78 -30 352 144 -30 air
execute in minecraft:overworld run fill 352 58 -29 352 73 -29 stone
execute in minecraft:overworld run fill 352 74 -29 352 75 -29 dirt
execute in minecraft:overworld run setblock 352 76 -29 coarse_dirt
execute in minecraft:overworld run fill 352 77 -29 352 144 -29 air
execute in minecraft:overworld run fill 352 58 -28 352 73 -28 stone
execute in minecraft:overworld run fill 352 74 -28 352 75 -28 dirt
execute in minecraft:overworld run setblock 352 76 -28 grass_block
execute in minecraft:overworld run fill 352 77 -28 352 144 -28 air
execute in minecraft:overworld run fill 352 58 -27 352 73 -27 stone
execute in minecraft:overworld run fill 352 74 -27 352 75 -27 dirt
execute in minecraft:overworld run setblock 352 76 -27 coarse_dirt
execute in minecraft:overworld run fill 352 77 -27 352 144 -27 air
execute in minecraft:overworld run fill 352 58 -26 352 72 -26 stone
execute in minecraft:overworld run fill 352 73 -26 352 74 -26 dirt
execute in minecraft:overworld run setblock 352 75 -26 coarse_dirt
execute in minecraft:overworld run fill 352 76 -26 352 144 -26 air
execute in minecraft:overworld run fill 352 58 -25 352 72 -25 stone
execute in minecraft:overworld run fill 352 73 -25 352 74 -25 dirt
execute in minecraft:overworld run setblock 352 75 -25 coarse_dirt
execute in minecraft:overworld run fill 352 76 -25 352 144 -25 air
execute in minecraft:overworld run fill 352 58 -24 352 72 -24 stone
execute in minecraft:overworld run fill 352 73 -24 352 74 -24 dirt
execute in minecraft:overworld run setblock 352 75 -24 coarse_dirt
execute in minecraft:overworld run fill 352 76 -24 352 144 -24 air
execute in minecraft:overworld run fill 352 58 -23 352 71 -23 stone
execute in minecraft:overworld run fill 352 72 -23 352 73 -23 dirt
execute in minecraft:overworld run setblock 352 74 -23 grass_block
execute in minecraft:overworld run fill 352 75 -23 352 144 -23 air
execute in minecraft:overworld run fill 352 58 -22 352 71 -22 stone
execute in minecraft:overworld run fill 352 72 -22 352 73 -22 dirt
execute in minecraft:overworld run setblock 352 74 -22 coarse_dirt
execute in minecraft:overworld run fill 352 75 -22 352 144 -22 air
execute in minecraft:overworld run setblock 352 75 -22 mossy_cobblestone
execute in minecraft:overworld run fill 352 58 -21 352 71 -21 stone
execute in minecraft:overworld run fill 352 72 -21 352 73 -21 dirt
execute in minecraft:overworld run setblock 352 74 -21 coarse_dirt
execute in minecraft:overworld run fill 352 75 -21 352 144 -21 air
execute in minecraft:overworld run fill 352 58 -20 352 70 -20 stone
execute in minecraft:overworld run fill 352 71 -20 352 72 -20 dirt
execute in minecraft:overworld run setblock 352 73 -20 grass_block
execute in minecraft:overworld run fill 352 74 -20 352 144 -20 air
execute in minecraft:overworld run fill 352 58 -19 352 70 -19 stone
execute in minecraft:overworld run fill 352 71 -19 352 72 -19 dirt
execute in minecraft:overworld run setblock 352 73 -19 coarse_dirt
execute in minecraft:overworld run fill 352 74 -19 352 144 -19 air
execute in minecraft:overworld run fill 352 58 -18 352 69 -18 stone
execute in minecraft:overworld run fill 352 70 -18 352 71 -18 dirt
execute in minecraft:overworld run setblock 352 72 -18 grass_block
execute in minecraft:overworld run fill 352 73 -18 352 144 -18 air
execute in minecraft:overworld run fill 352 58 -17 352 69 -17 stone
execute in minecraft:overworld run fill 352 70 -17 352 71 -17 dirt
execute in minecraft:overworld run setblock 352 72 -17 coarse_dirt
execute in minecraft:overworld run fill 352 73 -17 352 144 -17 air
execute in minecraft:overworld run fill 352 58 -16 352 69 -16 stone
execute in minecraft:overworld run fill 352 70 -16 352 71 -16 dirt
execute in minecraft:overworld run setblock 352 72 -16 grass_block
execute in minecraft:overworld run fill 352 73 -16 352 144 -16 air
execute in minecraft:overworld run fill 352 58 -15 352 68 -15 stone
execute in minecraft:overworld run fill 352 69 -15 352 70 -15 dirt
execute in minecraft:overworld run setblock 352 71 -15 grass_block
execute in minecraft:overworld run fill 352 72 -15 352 144 -15 air
execute in minecraft:overworld run fill 352 58 -14 352 68 -14 stone
execute in minecraft:overworld run fill 352 69 -14 352 70 -14 dirt
execute in minecraft:overworld run setblock 352 71 -14 coarse_dirt
execute in minecraft:overworld run fill 352 72 -14 352 144 -14 air
execute in minecraft:overworld run fill 352 58 -13 352 67 -13 stone
execute in minecraft:overworld run fill 352 68 -13 352 69 -13 dirt
execute in minecraft:overworld run setblock 352 70 -13 grass_block
execute in minecraft:overworld run fill 352 71 -13 352 144 -13 air
execute in minecraft:overworld run fill 352 58 -12 352 67 -12 stone
execute in minecraft:overworld run fill 352 68 -12 352 69 -12 dirt
execute in minecraft:overworld run setblock 352 70 -12 coarse_dirt
execute in minecraft:overworld run fill 352 71 -12 352 144 -12 air
execute in minecraft:overworld run fill 352 58 -11 352 67 -11 stone
execute in minecraft:overworld run fill 352 68 -11 352 69 -11 dirt
execute in minecraft:overworld run setblock 352 70 -11 grass_block
execute in minecraft:overworld run fill 352 71 -11 352 144 -11 air
execute in minecraft:overworld run fill 352 58 -10 352 67 -10 stone
execute in minecraft:overworld run fill 352 68 -10 352 69 -10 dirt
execute in minecraft:overworld run setblock 352 70 -10 coarse_dirt
execute in minecraft:overworld run fill 352 71 -10 352 144 -10 air
execute in minecraft:overworld run fill 352 58 -9 352 67 -9 stone
execute in minecraft:overworld run fill 352 68 -9 352 69 -9 dirt
execute in minecraft:overworld run setblock 352 70 -9 coarse_dirt
schedule function blade_gallery:random/battlefield/part_25 1t replace
