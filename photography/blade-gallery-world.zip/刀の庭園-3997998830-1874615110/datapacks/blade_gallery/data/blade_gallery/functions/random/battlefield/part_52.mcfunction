execute in minecraft:overworld run setblock 369 69 43 coarse_dirt
execute in minecraft:overworld run fill 369 70 43 369 144 43 air
execute in minecraft:overworld run fill 369 58 44 369 65 44 stone
execute in minecraft:overworld run fill 369 66 44 369 67 44 dirt
execute in minecraft:overworld run setblock 369 68 44 grass_block
execute in minecraft:overworld run fill 369 69 44 369 144 44 air
execute in minecraft:overworld run fill 369 58 45 369 64 45 stone
execute in minecraft:overworld run fill 369 65 45 369 66 45 dirt
execute in minecraft:overworld run setblock 369 67 45 coarse_dirt
execute in minecraft:overworld run fill 369 68 45 369 144 45 air
execute in minecraft:overworld run fill 369 58 46 369 63 46 stone
execute in minecraft:overworld run fill 369 64 46 369 65 46 dirt
execute in minecraft:overworld run setblock 369 66 46 coarse_dirt
execute in minecraft:overworld run fill 369 67 46 369 144 46 air
execute in minecraft:overworld run fill 369 58 47 369 62 47 stone
execute in minecraft:overworld run fill 369 63 47 369 64 47 dirt
execute in minecraft:overworld run setblock 369 65 47 grass_block
execute in minecraft:overworld run fill 369 66 47 369 144 47 air
execute in minecraft:overworld run fill 370 58 -48 370 61 -48 stone
execute in minecraft:overworld run fill 370 62 -48 370 63 -48 dirt
execute in minecraft:overworld run setblock 370 64 -48 coarse_dirt
execute in minecraft:overworld run fill 370 65 -48 370 144 -48 air
execute in minecraft:overworld run fill 370 58 -47 370 62 -47 stone
execute in minecraft:overworld run fill 370 63 -47 370 64 -47 dirt
execute in minecraft:overworld run setblock 370 65 -47 grass_block
execute in minecraft:overworld run fill 370 66 -47 370 144 -47 air
execute in minecraft:overworld run fill 370 58 -46 370 63 -46 stone
execute in minecraft:overworld run fill 370 64 -46 370 65 -46 dirt
execute in minecraft:overworld run setblock 370 66 -46 coarse_dirt
execute in minecraft:overworld run fill 370 67 -46 370 144 -46 air
execute in minecraft:overworld run fill 370 58 -45 370 64 -45 stone
execute in minecraft:overworld run fill 370 65 -45 370 66 -45 dirt
execute in minecraft:overworld run setblock 370 67 -45 coarse_dirt
execute in minecraft:overworld run fill 370 68 -45 370 144 -45 air
execute in minecraft:overworld run fill 370 58 -44 370 65 -44 stone
execute in minecraft:overworld run fill 370 66 -44 370 67 -44 dirt
execute in minecraft:overworld run setblock 370 68 -44 coarse_dirt
execute in minecraft:overworld run fill 370 69 -44 370 144 -44 air
execute in minecraft:overworld run fill 370 58 -43 370 66 -43 stone
execute in minecraft:overworld run fill 370 67 -43 370 68 -43 dirt
execute in minecraft:overworld run setblock 370 69 -43 coarse_dirt
execute in minecraft:overworld run fill 370 70 -43 370 144 -43 air
execute in minecraft:overworld run fill 370 58 -42 370 67 -42 stone
execute in minecraft:overworld run fill 370 68 -42 370 69 -42 dirt
execute in minecraft:overworld run setblock 370 70 -42 coarse_dirt
execute in minecraft:overworld run fill 370 71 -42 370 144 -42 air
execute in minecraft:overworld run fill 370 58 -41 370 68 -41 stone
execute in minecraft:overworld run fill 370 69 -41 370 70 -41 dirt
execute in minecraft:overworld run setblock 370 71 -41 grass_block
execute in minecraft:overworld run fill 370 72 -41 370 144 -41 air
execute in minecraft:overworld run fill 370 58 -40 370 69 -40 stone
execute in minecraft:overworld run fill 370 70 -40 370 71 -40 dirt
execute in minecraft:overworld run setblock 370 72 -40 coarse_dirt
execute in minecraft:overworld run fill 370 73 -40 370 144 -40 air
execute in minecraft:overworld run fill 370 58 -39 370 69 -39 stone
execute in minecraft:overworld run fill 370 70 -39 370 71 -39 dirt
execute in minecraft:overworld run setblock 370 72 -39 coarse_dirt
execute in minecraft:overworld run fill 370 73 -39 370 144 -39 air
execute in minecraft:overworld run fill 370 58 -38 370 70 -38 stone
execute in minecraft:overworld run fill 370 71 -38 370 72 -38 dirt
execute in minecraft:overworld run setblock 370 73 -38 coarse_dirt
execute in minecraft:overworld run fill 370 74 -38 370 144 -38 air
execute in minecraft:overworld run fill 370 58 -37 370 70 -37 stone
execute in minecraft:overworld run fill 370 71 -37 370 72 -37 dirt
execute in minecraft:overworld run setblock 370 73 -37 grass_block
execute in minecraft:overworld run fill 370 74 -37 370 144 -37 air
execute in minecraft:overworld run fill 370 58 -36 370 71 -36 stone
execute in minecraft:overworld run fill 370 72 -36 370 73 -36 dirt
execute in minecraft:overworld run setblock 370 74 -36 coarse_dirt
execute in minecraft:overworld run fill 370 75 -36 370 144 -36 air
execute in minecraft:overworld run fill 370 58 -35 370 71 -35 stone
execute in minecraft:overworld run fill 370 72 -35 370 73 -35 dirt
execute in minecraft:overworld run setblock 370 74 -35 coarse_dirt
execute in minecraft:overworld run fill 370 75 -35 370 144 -35 air
execute in minecraft:overworld run fill 370 58 -34 370 71 -34 stone
execute in minecraft:overworld run fill 370 72 -34 370 73 -34 dirt
execute in minecraft:overworld run setblock 370 74 -34 coarse_dirt
execute in minecraft:overworld run fill 370 75 -34 370 144 -34 air
execute in minecraft:overworld run fill 370 58 -33 370 71 -33 stone
execute in minecraft:overworld run fill 370 72 -33 370 73 -33 dirt
execute in minecraft:overworld run setblock 370 74 -33 coarse_dirt
execute in minecraft:overworld run fill 370 75 -33 370 144 -33 air
execute in minecraft:overworld run fill 370 58 -32 370 71 -32 stone
execute in minecraft:overworld run fill 370 72 -32 370 73 -32 dirt
execute in minecraft:overworld run setblock 370 74 -32 coarse_dirt
execute in minecraft:overworld run fill 370 75 -32 370 144 -32 air
execute in minecraft:overworld run fill 370 58 -31 370 71 -31 stone
execute in minecraft:overworld run fill 370 72 -31 370 73 -31 dirt
execute in minecraft:overworld run setblock 370 74 -31 coarse_dirt
execute in minecraft:overworld run fill 370 75 -31 370 144 -31 air
execute in minecraft:overworld run fill 370 58 -30 370 70 -30 stone
execute in minecraft:overworld run fill 370 71 -30 370 72 -30 dirt
execute in minecraft:overworld run setblock 370 73 -30 coarse_dirt
execute in minecraft:overworld run fill 370 74 -30 370 144 -30 air
execute in minecraft:overworld run fill 370 58 -29 370 70 -29 stone
execute in minecraft:overworld run fill 370 71 -29 370 72 -29 dirt
execute in minecraft:overworld run setblock 370 73 -29 coarse_dirt
execute in minecraft:overworld run fill 370 74 -29 370 144 -29 air
execute in minecraft:overworld run fill 370 58 -28 370 70 -28 stone
execute in minecraft:overworld run fill 370 71 -28 370 72 -28 dirt
execute in minecraft:overworld run setblock 370 73 -28 coarse_dirt
execute in minecraft:overworld run fill 370 74 -28 370 144 -28 air
execute in minecraft:overworld run fill 370 58 -27 370 70 -27 stone
execute in minecraft:overworld run fill 370 71 -27 370 72 -27 dirt
execute in minecraft:overworld run setblock 370 73 -27 coarse_dirt
execute in minecraft:overworld run fill 370 74 -27 370 144 -27 air
execute in minecraft:overworld run fill 370 58 -26 370 70 -26 stone
execute in minecraft:overworld run fill 370 71 -26 370 72 -26 dirt
execute in minecraft:overworld run setblock 370 73 -26 coarse_dirt
execute in minecraft:overworld run fill 370 74 -26 370 144 -26 air
execute in minecraft:overworld run fill 370 58 -25 370 70 -25 stone
execute in minecraft:overworld run fill 370 71 -25 370 72 -25 dirt
execute in minecraft:overworld run setblock 370 73 -25 coarse_dirt
execute in minecraft:overworld run fill 370 74 -25 370 144 -25 air
execute in minecraft:overworld run fill 370 58 -24 370 69 -24 stone
execute in minecraft:overworld run fill 370 70 -24 370 71 -24 dirt
execute in minecraft:overworld run setblock 370 72 -24 grass_block
execute in minecraft:overworld run fill 370 73 -24 370 144 -24 air
execute in minecraft:overworld run fill 370 58 -23 370 69 -23 stone
execute in minecraft:overworld run fill 370 70 -23 370 71 -23 dirt
execute in minecraft:overworld run setblock 370 72 -23 coarse_dirt
execute in minecraft:overworld run fill 370 73 -23 370 144 -23 air
execute in minecraft:overworld run fill 370 58 -22 370 69 -22 stone
execute in minecraft:overworld run fill 370 70 -22 370 71 -22 dirt
execute in minecraft:overworld run setblock 370 72 -22 grass_block
execute in minecraft:overworld run fill 370 73 -22 370 144 -22 air
execute in minecraft:overworld run fill 370 58 -21 370 68 -21 stone
execute in minecraft:overworld run fill 370 69 -21 370 70 -21 dirt
execute in minecraft:overworld run setblock 370 71 -21 coarse_dirt
execute in minecraft:overworld run fill 370 72 -21 370 144 -21 air
execute in minecraft:overworld run fill 370 58 -20 370 68 -20 stone
execute in minecraft:overworld run fill 370 69 -20 370 70 -20 dirt
execute in minecraft:overworld run setblock 370 71 -20 coarse_dirt
execute in minecraft:overworld run fill 370 72 -20 370 144 -20 air
execute in minecraft:overworld run fill 370 58 -19 370 68 -19 stone
execute in minecraft:overworld run fill 370 69 -19 370 70 -19 dirt
execute in minecraft:overworld run setblock 370 71 -19 coarse_dirt
execute in minecraft:overworld run fill 370 72 -19 370 144 -19 air
execute in minecraft:overworld run fill 370 58 -18 370 67 -18 stone
execute in minecraft:overworld run fill 370 68 -18 370 69 -18 dirt
execute in minecraft:overworld run setblock 370 70 -18 coarse_dirt
execute in minecraft:overworld run fill 370 71 -18 370 144 -18 air
execute in minecraft:overworld run setblock 370 71 -18 grass
execute in minecraft:overworld run fill 370 58 -17 370 67 -17 stone
execute in minecraft:overworld run fill 370 68 -17 370 69 -17 dirt
execute in minecraft:overworld run setblock 370 70 -17 coarse_dirt
execute in minecraft:overworld run fill 370 71 -17 370 144 -17 air
execute in minecraft:overworld run fill 370 58 -16 370 67 -16 stone
execute in minecraft:overworld run fill 370 68 -16 370 69 -16 dirt
execute in minecraft:overworld run setblock 370 70 -16 coarse_dirt
execute in minecraft:overworld run fill 370 71 -16 370 144 -16 air
execute in minecraft:overworld run fill 370 58 -15 370 66 -15 stone
execute in minecraft:overworld run fill 370 67 -15 370 68 -15 dirt
execute in minecraft:overworld run setblock 370 69 -15 coarse_dirt
execute in minecraft:overworld run fill 370 70 -15 370 144 -15 air
execute in minecraft:overworld run fill 370 58 -14 370 66 -14 stone
execute in minecraft:overworld run fill 370 67 -14 370 68 -14 dirt
execute in minecraft:overworld run setblock 370 69 -14 coarse_dirt
execute in minecraft:overworld run fill 370 70 -14 370 144 -14 air
execute in minecraft:overworld run fill 370 58 -13 370 66 -13 stone
execute in minecraft:overworld run fill 370 67 -13 370 68 -13 dirt
execute in minecraft:overworld run setblock 370 69 -13 coarse_dirt
execute in minecraft:overworld run fill 370 70 -13 370 144 -13 air
execute in minecraft:overworld run fill 370 58 -12 370 66 -12 stone
execute in minecraft:overworld run fill 370 67 -12 370 68 -12 dirt
execute in minecraft:overworld run setblock 370 69 -12 grass_block
execute in minecraft:overworld run fill 370 70 -12 370 144 -12 air
execute in minecraft:overworld run fill 370 58 -11 370 66 -11 stone
execute in minecraft:overworld run fill 370 67 -11 370 68 -11 dirt
execute in minecraft:overworld run setblock 370 69 -11 coarse_dirt
execute in minecraft:overworld run fill 370 70 -11 370 144 -11 air
execute in minecraft:overworld run fill 370 58 -10 370 66 -10 stone
execute in minecraft:overworld run fill 370 67 -10 370 68 -10 dirt
execute in minecraft:overworld run setblock 370 69 -10 coarse_dirt
execute in minecraft:overworld run fill 370 70 -10 370 144 -10 air
execute in minecraft:overworld run fill 370 58 -9 370 66 -9 stone
execute in minecraft:overworld run fill 370 67 -9 370 68 -9 dirt
execute in minecraft:overworld run setblock 370 69 -9 coarse_dirt
execute in minecraft:overworld run fill 370 70 -9 370 144 -9 air
execute in minecraft:overworld run setblock 370 70 -9 grass
execute in minecraft:overworld run fill 370 58 -8 370 66 -8 stone
execute in minecraft:overworld run fill 370 67 -8 370 68 -8 dirt
execute in minecraft:overworld run setblock 370 69 -8 coarse_dirt
execute in minecraft:overworld run fill 370 70 -8 370 144 -8 air
execute in minecraft:overworld run fill 370 58 -7 370 65 -7 stone
execute in minecraft:overworld run fill 370 66 -7 370 67 -7 dirt
execute in minecraft:overworld run setblock 370 68 -7 coarse_dirt
execute in minecraft:overworld run fill 370 69 -7 370 144 -7 air
execute in minecraft:overworld run fill 370 58 -6 370 65 -6 stone
execute in minecraft:overworld run fill 370 66 -6 370 67 -6 dirt
execute in minecraft:overworld run setblock 370 68 -6 grass_block
execute in minecraft:overworld run fill 370 69 -6 370 144 -6 air
execute in minecraft:overworld run fill 370 58 -5 370 65 -5 stone
execute in minecraft:overworld run fill 370 66 -5 370 67 -5 dirt
execute in minecraft:overworld run setblock 370 68 -5 coarse_dirt
execute in minecraft:overworld run fill 370 69 -5 370 144 -5 air
execute in minecraft:overworld run setblock 370 69 -5 mossy_cobblestone
execute in minecraft:overworld run fill 370 58 -4 370 65 -4 stone
execute in minecraft:overworld run fill 370 66 -4 370 67 -4 dirt
execute in minecraft:overworld run setblock 370 68 -4 coarse_dirt
execute in minecraft:overworld run fill 370 69 -4 370 144 -4 air
execute in minecraft:overworld run fill 370 58 -3 370 65 -3 stone
execute in minecraft:overworld run fill 370 66 -3 370 67 -3 dirt
execute in minecraft:overworld run setblock 370 68 -3 grass_block
execute in minecraft:overworld run fill 370 69 -3 370 144 -3 air
execute in minecraft:overworld run fill 370 58 -2 370 65 -2 stone
execute in minecraft:overworld run fill 370 66 -2 370 67 -2 dirt
execute in minecraft:overworld run setblock 370 68 -2 coarse_dirt
execute in minecraft:overworld run fill 370 69 -2 370 144 -2 air
execute in minecraft:overworld run fill 370 58 -1 370 65 -1 stone
execute in minecraft:overworld run fill 370 66 -1 370 67 -1 dirt
execute in minecraft:overworld run setblock 370 68 -1 grass_block
execute in minecraft:overworld run fill 370 69 -1 370 144 -1 air
execute in minecraft:overworld run fill 370 58 0 370 65 0 stone
execute in minecraft:overworld run fill 370 66 0 370 67 0 dirt
execute in minecraft:overworld run setblock 370 68 0 coarse_dirt
execute in minecraft:overworld run fill 370 69 0 370 144 0 air
execute in minecraft:overworld run setblock 370 69 0 grass
execute in minecraft:overworld run fill 370 58 1 370 65 1 stone
execute in minecraft:overworld run fill 370 66 1 370 67 1 dirt
execute in minecraft:overworld run setblock 370 68 1 grass_block
execute in minecraft:overworld run fill 370 69 1 370 144 1 air
execute in minecraft:overworld run setblock 370 69 1 grass
execute in minecraft:overworld run fill 370 58 2 370 65 2 stone
execute in minecraft:overworld run fill 370 66 2 370 67 2 dirt
execute in minecraft:overworld run setblock 370 68 2 coarse_dirt
execute in minecraft:overworld run fill 370 69 2 370 144 2 air
execute in minecraft:overworld run fill 370 58 3 370 65 3 stone
execute in minecraft:overworld run fill 370 66 3 370 67 3 dirt
execute in minecraft:overworld run setblock 370 68 3 coarse_dirt
execute in minecraft:overworld run fill 370 69 3 370 144 3 air
execute in minecraft:overworld run fill 370 58 4 370 65 4 stone
execute in minecraft:overworld run fill 370 66 4 370 67 4 dirt
execute in minecraft:overworld run setblock 370 68 4 coarse_dirt
execute in minecraft:overworld run fill 370 69 4 370 144 4 air
execute in minecraft:overworld run fill 370 58 5 370 65 5 stone
execute in minecraft:overworld run fill 370 66 5 370 67 5 dirt
execute in minecraft:overworld run setblock 370 68 5 coarse_dirt
execute in minecraft:overworld run fill 370 69 5 370 144 5 air
execute in minecraft:overworld run fill 370 58 6 370 65 6 stone
execute in minecraft:overworld run fill 370 66 6 370 67 6 dirt
execute in minecraft:overworld run setblock 370 68 6 coarse_dirt
execute in minecraft:overworld run fill 370 69 6 370 144 6 air
execute in minecraft:overworld run fill 370 58 7 370 65 7 stone
execute in minecraft:overworld run fill 370 66 7 370 67 7 dirt
execute in minecraft:overworld run setblock 370 68 7 grass_block
execute in minecraft:overworld run fill 370 69 7 370 144 7 air
execute in minecraft:overworld run fill 370 58 8 370 65 8 stone
execute in minecraft:overworld run fill 370 66 8 370 67 8 dirt
execute in minecraft:overworld run setblock 370 68 8 grass_block
execute in minecraft:overworld run fill 370 69 8 370 144 8 air
execute in minecraft:overworld run fill 370 58 9 370 65 9 stone
execute in minecraft:overworld run fill 370 66 9 370 67 9 dirt
execute in minecraft:overworld run setblock 370 68 9 grass_block
execute in minecraft:overworld run fill 370 69 9 370 144 9 air
execute in minecraft:overworld run fill 370 58 10 370 65 10 stone
schedule function blade_gallery:random/battlefield/part_53 1t replace
