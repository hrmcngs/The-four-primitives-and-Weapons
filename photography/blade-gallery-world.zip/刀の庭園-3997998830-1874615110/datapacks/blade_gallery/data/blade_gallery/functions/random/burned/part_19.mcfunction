execute in minecraft:overworld run fill 220 58 -2 220 67 -2 stone
execute in minecraft:overworld run fill 220 68 -2 220 69 -2 dirt
execute in minecraft:overworld run setblock 220 70 -2 grass_block
execute in minecraft:overworld run fill 220 71 -2 220 144 -2 air
execute in minecraft:overworld run fill 220 58 -1 220 67 -1 stone
execute in minecraft:overworld run fill 220 68 -1 220 69 -1 dirt
execute in minecraft:overworld run setblock 220 70 -1 coarse_dirt
execute in minecraft:overworld run fill 220 71 -1 220 144 -1 air
execute in minecraft:overworld run fill 220 58 0 220 67 0 stone
execute in minecraft:overworld run fill 220 68 0 220 69 0 dirt
execute in minecraft:overworld run setblock 220 70 0 coarse_dirt
execute in minecraft:overworld run fill 220 71 0 220 144 0 air
execute in minecraft:overworld run fill 220 58 1 220 67 1 stone
execute in minecraft:overworld run fill 220 68 1 220 69 1 dirt
execute in minecraft:overworld run setblock 220 70 1 coarse_dirt
execute in minecraft:overworld run fill 220 71 1 220 144 1 air
execute in minecraft:overworld run fill 220 58 2 220 67 2 stone
execute in minecraft:overworld run fill 220 68 2 220 69 2 dirt
execute in minecraft:overworld run setblock 220 70 2 coarse_dirt
execute in minecraft:overworld run fill 220 71 2 220 144 2 air
execute in minecraft:overworld run fill 220 58 3 220 67 3 stone
execute in minecraft:overworld run fill 220 68 3 220 69 3 dirt
execute in minecraft:overworld run setblock 220 70 3 grass_block
execute in minecraft:overworld run fill 220 71 3 220 144 3 air
execute in minecraft:overworld run fill 220 58 4 220 67 4 stone
execute in minecraft:overworld run fill 220 68 4 220 69 4 dirt
execute in minecraft:overworld run setblock 220 70 4 coarse_dirt
execute in minecraft:overworld run fill 220 71 4 220 144 4 air
execute in minecraft:overworld run fill 220 58 5 220 67 5 stone
execute in minecraft:overworld run fill 220 68 5 220 69 5 dirt
execute in minecraft:overworld run setblock 220 70 5 coarse_dirt
execute in minecraft:overworld run fill 220 71 5 220 144 5 air
execute in minecraft:overworld run fill 220 58 6 220 67 6 stone
execute in minecraft:overworld run fill 220 68 6 220 69 6 dirt
execute in minecraft:overworld run setblock 220 70 6 coarse_dirt
execute in minecraft:overworld run fill 220 71 6 220 144 6 air
execute in minecraft:overworld run fill 220 58 7 220 67 7 stone
execute in minecraft:overworld run fill 220 68 7 220 69 7 dirt
execute in minecraft:overworld run setblock 220 70 7 coarse_dirt
execute in minecraft:overworld run fill 220 71 7 220 144 7 air
execute in minecraft:overworld run fill 220 58 8 220 67 8 stone
execute in minecraft:overworld run fill 220 68 8 220 69 8 dirt
execute in minecraft:overworld run setblock 220 70 8 grass_block
execute in minecraft:overworld run fill 220 71 8 220 144 8 air
execute in minecraft:overworld run setblock 220 71 8 grass
execute in minecraft:overworld run fill 220 58 9 220 67 9 stone
execute in minecraft:overworld run fill 220 68 9 220 69 9 dirt
execute in minecraft:overworld run setblock 220 70 9 coarse_dirt
execute in minecraft:overworld run fill 220 71 9 220 144 9 air
execute in minecraft:overworld run fill 220 58 10 220 67 10 stone
execute in minecraft:overworld run fill 220 68 10 220 69 10 dirt
execute in minecraft:overworld run setblock 220 70 10 coarse_dirt
execute in minecraft:overworld run fill 220 71 10 220 144 10 air
execute in minecraft:overworld run fill 220 58 11 220 67 11 stone
execute in minecraft:overworld run fill 220 68 11 220 69 11 dirt
execute in minecraft:overworld run setblock 220 70 11 coarse_dirt
execute in minecraft:overworld run fill 220 71 11 220 144 11 air
execute in minecraft:overworld run fill 220 58 12 220 68 12 stone
execute in minecraft:overworld run fill 220 69 12 220 70 12 dirt
execute in minecraft:overworld run setblock 220 71 12 coarse_dirt
execute in minecraft:overworld run fill 220 72 12 220 144 12 air
execute in minecraft:overworld run fill 220 58 13 220 68 13 stone
execute in minecraft:overworld run fill 220 69 13 220 70 13 dirt
execute in minecraft:overworld run setblock 220 71 13 coarse_dirt
execute in minecraft:overworld run fill 220 72 13 220 144 13 air
execute in minecraft:overworld run fill 220 58 14 220 69 14 stone
execute in minecraft:overworld run fill 220 70 14 220 71 14 dirt
execute in minecraft:overworld run setblock 220 72 14 coarse_dirt
execute in minecraft:overworld run fill 220 73 14 220 144 14 air
execute in minecraft:overworld run fill 220 58 15 220 69 15 stone
execute in minecraft:overworld run fill 220 70 15 220 71 15 dirt
execute in minecraft:overworld run setblock 220 72 15 grass_block
execute in minecraft:overworld run fill 220 73 15 220 144 15 air
execute in minecraft:overworld run setblock 220 73 15 grass
execute in minecraft:overworld run fill 220 58 16 220 69 16 stone
execute in minecraft:overworld run fill 220 70 16 220 71 16 dirt
execute in minecraft:overworld run setblock 220 72 16 coarse_dirt
execute in minecraft:overworld run fill 220 73 16 220 144 16 air
execute in minecraft:overworld run fill 220 58 17 220 70 17 stone
execute in minecraft:overworld run fill 220 71 17 220 72 17 dirt
execute in minecraft:overworld run setblock 220 73 17 coarse_dirt
execute in minecraft:overworld run fill 220 74 17 220 144 17 air
execute in minecraft:overworld run fill 220 58 18 220 70 18 stone
execute in minecraft:overworld run fill 220 71 18 220 72 18 dirt
execute in minecraft:overworld run setblock 220 73 18 grass_block
execute in minecraft:overworld run fill 220 74 18 220 144 18 air
execute in minecraft:overworld run setblock 220 74 18 grass
execute in minecraft:overworld run fill 220 58 19 220 70 19 stone
execute in minecraft:overworld run fill 220 71 19 220 72 19 dirt
execute in minecraft:overworld run setblock 220 73 19 coarse_dirt
execute in minecraft:overworld run fill 220 74 19 220 144 19 air
execute in minecraft:overworld run fill 220 58 20 220 70 20 stone
execute in minecraft:overworld run fill 220 71 20 220 72 20 dirt
execute in minecraft:overworld run setblock 220 73 20 coarse_dirt
execute in minecraft:overworld run fill 220 74 20 220 144 20 air
execute in minecraft:overworld run fill 220 58 21 220 70 21 stone
execute in minecraft:overworld run fill 220 71 21 220 72 21 dirt
execute in minecraft:overworld run setblock 220 73 21 coarse_dirt
execute in minecraft:overworld run fill 220 74 21 220 144 21 air
execute in minecraft:overworld run fill 220 58 22 220 70 22 stone
execute in minecraft:overworld run fill 220 71 22 220 72 22 dirt
execute in minecraft:overworld run setblock 220 73 22 coarse_dirt
execute in minecraft:overworld run fill 220 74 22 220 144 22 air
execute in minecraft:overworld run fill 220 58 23 220 71 23 stone
execute in minecraft:overworld run fill 220 72 23 220 73 23 dirt
execute in minecraft:overworld run setblock 220 74 23 coarse_dirt
execute in minecraft:overworld run fill 220 75 23 220 144 23 air
execute in minecraft:overworld run fill 220 58 24 220 71 24 stone
execute in minecraft:overworld run fill 220 72 24 220 73 24 dirt
execute in minecraft:overworld run setblock 220 74 24 coarse_dirt
execute in minecraft:overworld run fill 220 75 24 220 144 24 air
execute in minecraft:overworld run fill 220 58 25 220 71 25 stone
execute in minecraft:overworld run fill 220 72 25 220 73 25 dirt
execute in minecraft:overworld run setblock 220 74 25 grass_block
execute in minecraft:overworld run fill 220 75 25 220 144 25 air
execute in minecraft:overworld run fill 220 58 26 220 71 26 stone
execute in minecraft:overworld run fill 220 72 26 220 73 26 dirt
execute in minecraft:overworld run setblock 220 74 26 coarse_dirt
execute in minecraft:overworld run fill 220 75 26 220 144 26 air
execute in minecraft:overworld run fill 220 58 27 220 71 27 stone
execute in minecraft:overworld run fill 220 72 27 220 73 27 dirt
execute in minecraft:overworld run setblock 220 74 27 coarse_dirt
execute in minecraft:overworld run fill 220 75 27 220 144 27 air
execute in minecraft:overworld run fill 220 58 28 220 71 28 stone
execute in minecraft:overworld run fill 220 72 28 220 73 28 dirt
execute in minecraft:overworld run setblock 220 74 28 coarse_dirt
execute in minecraft:overworld run fill 220 75 28 220 144 28 air
execute in minecraft:overworld run fill 220 58 29 220 71 29 stone
execute in minecraft:overworld run fill 220 72 29 220 73 29 dirt
execute in minecraft:overworld run setblock 220 74 29 coarse_dirt
execute in minecraft:overworld run fill 220 75 29 220 144 29 air
execute in minecraft:overworld run fill 220 58 30 220 71 30 stone
execute in minecraft:overworld run fill 220 72 30 220 73 30 dirt
execute in minecraft:overworld run setblock 220 74 30 grass_block
execute in minecraft:overworld run fill 220 75 30 220 144 30 air
execute in minecraft:overworld run fill 220 58 31 220 70 31 stone
execute in minecraft:overworld run fill 220 71 31 220 72 31 dirt
execute in minecraft:overworld run setblock 220 73 31 coarse_dirt
execute in minecraft:overworld run fill 220 74 31 220 144 31 air
execute in minecraft:overworld run fill 220 58 32 220 70 32 stone
execute in minecraft:overworld run fill 220 71 32 220 72 32 dirt
execute in minecraft:overworld run setblock 220 73 32 coarse_dirt
execute in minecraft:overworld run fill 220 74 32 220 144 32 air
execute in minecraft:overworld run fill 220 58 33 220 70 33 stone
execute in minecraft:overworld run fill 220 71 33 220 72 33 dirt
execute in minecraft:overworld run setblock 220 73 33 coarse_dirt
execute in minecraft:overworld run fill 220 74 33 220 144 33 air
execute in minecraft:overworld run fill 220 58 34 220 70 34 stone
execute in minecraft:overworld run fill 220 71 34 220 72 34 dirt
execute in minecraft:overworld run setblock 220 73 34 coarse_dirt
execute in minecraft:overworld run fill 220 74 34 220 144 34 air
execute in minecraft:overworld run fill 220 58 35 220 69 35 stone
execute in minecraft:overworld run fill 220 70 35 220 71 35 dirt
execute in minecraft:overworld run setblock 220 72 35 grass_block
execute in minecraft:overworld run fill 220 73 35 220 144 35 air
execute in minecraft:overworld run fill 220 58 36 220 69 36 stone
execute in minecraft:overworld run fill 220 70 36 220 71 36 dirt
execute in minecraft:overworld run setblock 220 72 36 coarse_dirt
execute in minecraft:overworld run fill 220 73 36 220 144 36 air
execute in minecraft:overworld run fill 220 58 37 220 69 37 stone
execute in minecraft:overworld run fill 220 70 37 220 71 37 dirt
execute in minecraft:overworld run setblock 220 72 37 grass_block
execute in minecraft:overworld run fill 220 73 37 220 144 37 air
execute in minecraft:overworld run fill 220 58 38 220 68 38 stone
execute in minecraft:overworld run fill 220 69 38 220 70 38 dirt
execute in minecraft:overworld run setblock 220 71 38 coarse_dirt
execute in minecraft:overworld run fill 220 72 38 220 144 38 air
execute in minecraft:overworld run fill 220 58 39 220 67 39 stone
execute in minecraft:overworld run fill 220 68 39 220 69 39 dirt
execute in minecraft:overworld run setblock 220 70 39 grass_block
execute in minecraft:overworld run fill 220 71 39 220 144 39 air
execute in minecraft:overworld run fill 220 58 40 220 66 40 stone
execute in minecraft:overworld run fill 220 67 40 220 68 40 dirt
execute in minecraft:overworld run setblock 220 69 40 coarse_dirt
execute in minecraft:overworld run fill 220 70 40 220 144 40 air
execute in minecraft:overworld run setblock 220 70 40 grass
execute in minecraft:overworld run fill 220 58 41 220 65 41 stone
execute in minecraft:overworld run fill 220 66 41 220 67 41 dirt
execute in minecraft:overworld run setblock 220 68 41 coarse_dirt
execute in minecraft:overworld run fill 220 69 41 220 144 41 air
execute in minecraft:overworld run fill 220 58 42 220 64 42 stone
execute in minecraft:overworld run fill 220 65 42 220 66 42 dirt
execute in minecraft:overworld run setblock 220 67 42 grass_block
execute in minecraft:overworld run fill 220 68 42 220 144 42 air
execute in minecraft:overworld run fill 220 58 43 220 63 43 stone
execute in minecraft:overworld run fill 220 64 43 220 65 43 dirt
execute in minecraft:overworld run setblock 220 66 43 grass_block
execute in minecraft:overworld run fill 220 67 43 220 144 43 air
execute in minecraft:overworld run fill 220 58 44 220 63 44 stone
execute in minecraft:overworld run fill 220 64 44 220 65 44 dirt
execute in minecraft:overworld run setblock 220 66 44 coarse_dirt
execute in minecraft:overworld run fill 220 67 44 220 144 44 air
execute in minecraft:overworld run fill 220 58 45 220 62 45 stone
execute in minecraft:overworld run fill 220 63 45 220 64 45 dirt
execute in minecraft:overworld run setblock 220 65 45 coarse_dirt
execute in minecraft:overworld run fill 220 66 45 220 144 45 air
execute in minecraft:overworld run fill 220 58 46 220 62 46 stone
execute in minecraft:overworld run fill 220 63 46 220 64 46 dirt
execute in minecraft:overworld run setblock 220 65 46 coarse_dirt
execute in minecraft:overworld run fill 220 66 46 220 144 46 air
execute in minecraft:overworld run fill 220 58 47 220 61 47 stone
execute in minecraft:overworld run fill 220 62 47 220 63 47 dirt
execute in minecraft:overworld run setblock 220 64 47 coarse_dirt
execute in minecraft:overworld run fill 220 65 47 220 144 47 air
execute in minecraft:overworld run fill 221 58 -48 221 61 -48 stone
execute in minecraft:overworld run fill 221 62 -48 221 63 -48 dirt
execute in minecraft:overworld run setblock 221 64 -48 grass_block
execute in minecraft:overworld run fill 221 65 -48 221 144 -48 air
execute in minecraft:overworld run fill 221 58 -47 221 63 -47 stone
execute in minecraft:overworld run fill 221 64 -47 221 65 -47 dirt
execute in minecraft:overworld run setblock 221 66 -47 coarse_dirt
execute in minecraft:overworld run fill 221 67 -47 221 144 -47 air
execute in minecraft:overworld run fill 221 58 -46 221 64 -46 stone
execute in minecraft:overworld run fill 221 65 -46 221 66 -46 dirt
execute in minecraft:overworld run setblock 221 67 -46 coarse_dirt
execute in minecraft:overworld run fill 221 68 -46 221 144 -46 air
execute in minecraft:overworld run fill 221 58 -45 221 66 -45 stone
execute in minecraft:overworld run fill 221 67 -45 221 68 -45 dirt
execute in minecraft:overworld run setblock 221 69 -45 coarse_dirt
execute in minecraft:overworld run fill 221 70 -45 221 144 -45 air
execute in minecraft:overworld run fill 221 58 -44 221 67 -44 stone
execute in minecraft:overworld run fill 221 68 -44 221 69 -44 dirt
execute in minecraft:overworld run setblock 221 70 -44 grass_block
execute in minecraft:overworld run fill 221 71 -44 221 144 -44 air
execute in minecraft:overworld run fill 221 58 -43 221 68 -43 stone
execute in minecraft:overworld run fill 221 69 -43 221 70 -43 dirt
execute in minecraft:overworld run setblock 221 71 -43 coarse_dirt
execute in minecraft:overworld run fill 221 72 -43 221 144 -43 air
execute in minecraft:overworld run fill 221 58 -42 221 69 -42 stone
execute in minecraft:overworld run fill 221 70 -42 221 71 -42 dirt
execute in minecraft:overworld run setblock 221 72 -42 coarse_dirt
execute in minecraft:overworld run fill 221 73 -42 221 144 -42 air
execute in minecraft:overworld run fill 221 58 -41 221 70 -41 stone
execute in minecraft:overworld run fill 221 71 -41 221 72 -41 dirt
execute in minecraft:overworld run setblock 221 73 -41 coarse_dirt
execute in minecraft:overworld run fill 221 74 -41 221 144 -41 air
execute in minecraft:overworld run setblock 221 74 -41 grass
execute in minecraft:overworld run fill 221 58 -40 221 70 -40 stone
execute in minecraft:overworld run fill 221 71 -40 221 72 -40 dirt
execute in minecraft:overworld run setblock 221 73 -40 grass_block
execute in minecraft:overworld run fill 221 74 -40 221 144 -40 air
execute in minecraft:overworld run fill 221 58 -39 221 71 -39 stone
execute in minecraft:overworld run fill 221 72 -39 221 73 -39 dirt
execute in minecraft:overworld run setblock 221 74 -39 coarse_dirt
execute in minecraft:overworld run fill 221 75 -39 221 144 -39 air
execute in minecraft:overworld run fill 221 58 -38 221 71 -38 stone
execute in minecraft:overworld run fill 221 72 -38 221 73 -38 dirt
execute in minecraft:overworld run setblock 221 74 -38 coarse_dirt
execute in minecraft:overworld run fill 221 75 -38 221 144 -38 air
execute in minecraft:overworld run fill 221 58 -37 221 70 -37 stone
execute in minecraft:overworld run fill 221 71 -37 221 72 -37 dirt
execute in minecraft:overworld run setblock 221 73 -37 coarse_dirt
execute in minecraft:overworld run fill 221 74 -37 221 144 -37 air
execute in minecraft:overworld run setblock 221 74 -37 mossy_cobblestone
execute in minecraft:overworld run fill 221 58 -36 221 70 -36 stone
execute in minecraft:overworld run fill 221 71 -36 221 72 -36 dirt
schedule function blade_gallery:random/burned/part_20 1t replace
