execute in minecraft:overworld run fill 294 69 30 294 144 30 air
execute in minecraft:overworld run fill 294 58 31 294 65 31 stone
execute in minecraft:overworld run fill 294 66 31 294 67 31 dirt
execute in minecraft:overworld run setblock 294 68 31 coarse_dirt
execute in minecraft:overworld run fill 294 69 31 294 144 31 air
execute in minecraft:overworld run fill 294 58 32 294 65 32 stone
execute in minecraft:overworld run fill 294 66 32 294 67 32 dirt
execute in minecraft:overworld run setblock 294 68 32 coarse_dirt
execute in minecraft:overworld run fill 294 69 32 294 144 32 air
execute in minecraft:overworld run fill 294 58 33 294 65 33 stone
execute in minecraft:overworld run fill 294 66 33 294 67 33 dirt
execute in minecraft:overworld run setblock 294 68 33 grass_block
execute in minecraft:overworld run fill 294 69 33 294 144 33 air
execute in minecraft:overworld run fill 294 58 34 294 64 34 stone
execute in minecraft:overworld run fill 294 65 34 294 66 34 dirt
execute in minecraft:overworld run setblock 294 67 34 coarse_dirt
execute in minecraft:overworld run fill 294 68 34 294 144 34 air
execute in minecraft:overworld run fill 294 58 35 294 64 35 stone
execute in minecraft:overworld run fill 294 65 35 294 66 35 dirt
execute in minecraft:overworld run setblock 294 67 35 grass_block
execute in minecraft:overworld run fill 294 68 35 294 144 35 air
execute in minecraft:overworld run fill 294 58 36 294 64 36 stone
execute in minecraft:overworld run fill 294 65 36 294 66 36 dirt
execute in minecraft:overworld run setblock 294 67 36 grass_block
execute in minecraft:overworld run fill 294 68 36 294 144 36 air
execute in minecraft:overworld run fill 294 58 37 294 64 37 stone
execute in minecraft:overworld run fill 294 65 37 294 66 37 dirt
execute in minecraft:overworld run setblock 294 67 37 coarse_dirt
execute in minecraft:overworld run fill 294 68 37 294 144 37 air
execute in minecraft:overworld run fill 294 58 38 294 64 38 stone
execute in minecraft:overworld run fill 294 65 38 294 66 38 dirt
execute in minecraft:overworld run setblock 294 67 38 coarse_dirt
execute in minecraft:overworld run fill 294 68 38 294 144 38 air
execute in minecraft:overworld run setblock 294 68 38 grass
execute in minecraft:overworld run fill 294 58 39 294 64 39 stone
execute in minecraft:overworld run fill 294 65 39 294 66 39 dirt
execute in minecraft:overworld run setblock 294 67 39 coarse_dirt
execute in minecraft:overworld run fill 294 68 39 294 144 39 air
execute in minecraft:overworld run fill 294 58 40 294 63 40 stone
execute in minecraft:overworld run fill 294 64 40 294 65 40 dirt
execute in minecraft:overworld run setblock 294 66 40 grass_block
execute in minecraft:overworld run fill 294 67 40 294 144 40 air
execute in minecraft:overworld run fill 294 58 41 294 63 41 stone
execute in minecraft:overworld run fill 294 64 41 294 65 41 dirt
execute in minecraft:overworld run setblock 294 66 41 grass_block
execute in minecraft:overworld run fill 294 67 41 294 144 41 air
execute in minecraft:overworld run fill 294 58 42 294 63 42 stone
execute in minecraft:overworld run fill 294 64 42 294 65 42 dirt
execute in minecraft:overworld run setblock 294 66 42 grass_block
execute in minecraft:overworld run fill 294 67 42 294 144 42 air
execute in minecraft:overworld run fill 294 58 43 294 62 43 stone
execute in minecraft:overworld run fill 294 63 43 294 64 43 dirt
execute in minecraft:overworld run setblock 294 65 43 coarse_dirt
execute in minecraft:overworld run fill 294 66 43 294 144 43 air
execute in minecraft:overworld run fill 294 58 44 294 62 44 stone
execute in minecraft:overworld run fill 294 63 44 294 64 44 dirt
execute in minecraft:overworld run setblock 294 65 44 coarse_dirt
execute in minecraft:overworld run fill 294 66 44 294 144 44 air
execute in minecraft:overworld run fill 294 58 45 294 62 45 stone
execute in minecraft:overworld run fill 294 63 45 294 64 45 dirt
execute in minecraft:overworld run setblock 294 65 45 grass_block
execute in minecraft:overworld run fill 294 66 45 294 144 45 air
execute in minecraft:overworld run fill 294 58 46 294 61 46 stone
execute in minecraft:overworld run fill 294 62 46 294 63 46 dirt
execute in minecraft:overworld run setblock 294 64 46 coarse_dirt
execute in minecraft:overworld run fill 294 65 46 294 144 46 air
execute in minecraft:overworld run fill 294 58 47 294 61 47 stone
execute in minecraft:overworld run fill 294 62 47 294 63 47 dirt
execute in minecraft:overworld run setblock 294 64 47 coarse_dirt
execute in minecraft:overworld run fill 294 65 47 294 144 47 air
execute in minecraft:overworld run fill 295 58 -48 295 61 -48 stone
execute in minecraft:overworld run fill 295 62 -48 295 63 -48 dirt
execute in minecraft:overworld run setblock 295 64 -48 coarse_dirt
execute in minecraft:overworld run fill 295 65 -48 295 144 -48 air
execute in minecraft:overworld run fill 295 58 -47 295 63 -47 stone
execute in minecraft:overworld run fill 295 64 -47 295 65 -47 dirt
execute in minecraft:overworld run setblock 295 66 -47 coarse_dirt
execute in minecraft:overworld run fill 295 67 -47 295 144 -47 air
execute in minecraft:overworld run fill 295 58 -46 295 65 -46 stone
execute in minecraft:overworld run fill 295 66 -46 295 67 -46 dirt
execute in minecraft:overworld run setblock 295 68 -46 grass_block
execute in minecraft:overworld run fill 295 69 -46 295 144 -46 air
execute in minecraft:overworld run fill 295 58 -45 295 67 -45 stone
execute in minecraft:overworld run fill 295 68 -45 295 69 -45 dirt
execute in minecraft:overworld run setblock 295 70 -45 coarse_dirt
execute in minecraft:overworld run fill 295 71 -45 295 144 -45 air
execute in minecraft:overworld run fill 295 58 -44 295 69 -44 stone
execute in minecraft:overworld run fill 295 70 -44 295 71 -44 dirt
execute in minecraft:overworld run setblock 295 72 -44 coarse_dirt
execute in minecraft:overworld run fill 295 73 -44 295 144 -44 air
execute in minecraft:overworld run fill 295 58 -43 295 71 -43 stone
execute in minecraft:overworld run fill 295 72 -43 295 73 -43 dirt
execute in minecraft:overworld run setblock 295 74 -43 coarse_dirt
execute in minecraft:overworld run fill 295 75 -43 295 144 -43 air
execute in minecraft:overworld run fill 295 58 -42 295 72 -42 stone
execute in minecraft:overworld run fill 295 73 -42 295 74 -42 dirt
execute in minecraft:overworld run setblock 295 75 -42 grass_block
execute in minecraft:overworld run fill 295 76 -42 295 144 -42 air
execute in minecraft:overworld run fill 295 58 -41 295 74 -41 stone
execute in minecraft:overworld run fill 295 75 -41 295 76 -41 dirt
execute in minecraft:overworld run setblock 295 77 -41 coarse_dirt
execute in minecraft:overworld run fill 295 78 -41 295 144 -41 air
execute in minecraft:overworld run fill 295 58 -40 295 76 -40 stone
execute in minecraft:overworld run fill 295 77 -40 295 78 -40 dirt
execute in minecraft:overworld run setblock 295 79 -40 coarse_dirt
execute in minecraft:overworld run fill 295 80 -40 295 144 -40 air
execute in minecraft:overworld run fill 295 58 -39 295 78 -39 stone
execute in minecraft:overworld run fill 295 79 -39 295 80 -39 dirt
execute in minecraft:overworld run setblock 295 81 -39 coarse_dirt
execute in minecraft:overworld run fill 295 82 -39 295 144 -39 air
execute in minecraft:overworld run fill 295 58 -38 295 77 -38 stone
execute in minecraft:overworld run fill 295 78 -38 295 79 -38 dirt
execute in minecraft:overworld run setblock 295 80 -38 coarse_dirt
execute in minecraft:overworld run fill 295 81 -38 295 144 -38 air
execute in minecraft:overworld run fill 295 58 -37 295 77 -37 stone
execute in minecraft:overworld run fill 295 78 -37 295 79 -37 dirt
execute in minecraft:overworld run setblock 295 80 -37 coarse_dirt
execute in minecraft:overworld run fill 295 81 -37 295 144 -37 air
execute in minecraft:overworld run fill 295 58 -36 295 77 -36 stone
execute in minecraft:overworld run fill 295 78 -36 295 79 -36 dirt
execute in minecraft:overworld run setblock 295 80 -36 coarse_dirt
execute in minecraft:overworld run fill 295 81 -36 295 144 -36 air
execute in minecraft:overworld run fill 295 58 -35 295 77 -35 stone
execute in minecraft:overworld run fill 295 78 -35 295 79 -35 dirt
execute in minecraft:overworld run setblock 295 80 -35 coarse_dirt
execute in minecraft:overworld run fill 295 81 -35 295 144 -35 air
execute in minecraft:overworld run fill 295 58 -34 295 76 -34 stone
execute in minecraft:overworld run fill 295 77 -34 295 78 -34 dirt
execute in minecraft:overworld run setblock 295 79 -34 coarse_dirt
execute in minecraft:overworld run fill 295 80 -34 295 144 -34 air
execute in minecraft:overworld run fill 295 58 -33 295 76 -33 stone
execute in minecraft:overworld run fill 295 77 -33 295 78 -33 dirt
execute in minecraft:overworld run setblock 295 79 -33 coarse_dirt
execute in minecraft:overworld run fill 295 80 -33 295 144 -33 air
execute in minecraft:overworld run fill 295 58 -32 295 76 -32 stone
execute in minecraft:overworld run fill 295 77 -32 295 78 -32 dirt
execute in minecraft:overworld run setblock 295 79 -32 grass_block
execute in minecraft:overworld run fill 295 80 -32 295 144 -32 air
execute in minecraft:overworld run fill 295 58 -31 295 75 -31 stone
execute in minecraft:overworld run fill 295 76 -31 295 77 -31 dirt
execute in minecraft:overworld run setblock 295 78 -31 coarse_dirt
execute in minecraft:overworld run fill 295 79 -31 295 144 -31 air
execute in minecraft:overworld run fill 295 58 -30 295 75 -30 stone
execute in minecraft:overworld run fill 295 76 -30 295 77 -30 dirt
execute in minecraft:overworld run setblock 295 78 -30 coarse_dirt
execute in minecraft:overworld run fill 295 79 -30 295 144 -30 air
execute in minecraft:overworld run fill 295 58 -29 295 74 -29 stone
execute in minecraft:overworld run fill 295 75 -29 295 76 -29 dirt
execute in minecraft:overworld run setblock 295 77 -29 coarse_dirt
execute in minecraft:overworld run fill 295 78 -29 295 144 -29 air
execute in minecraft:overworld run fill 295 58 -28 295 74 -28 stone
execute in minecraft:overworld run fill 295 75 -28 295 76 -28 dirt
execute in minecraft:overworld run setblock 295 77 -28 coarse_dirt
execute in minecraft:overworld run fill 295 78 -28 295 144 -28 air
execute in minecraft:overworld run fill 295 58 -27 295 74 -27 stone
execute in minecraft:overworld run fill 295 75 -27 295 76 -27 dirt
execute in minecraft:overworld run setblock 295 77 -27 coarse_dirt
execute in minecraft:overworld run fill 295 78 -27 295 144 -27 air
execute in minecraft:overworld run fill 295 58 -26 295 73 -26 stone
execute in minecraft:overworld run fill 295 74 -26 295 75 -26 dirt
execute in minecraft:overworld run setblock 295 76 -26 coarse_dirt
execute in minecraft:overworld run fill 295 77 -26 295 144 -26 air
execute in minecraft:overworld run setblock 295 77 -26 grass
execute in minecraft:overworld run fill 295 58 -25 295 73 -25 stone
execute in minecraft:overworld run fill 295 74 -25 295 75 -25 dirt
execute in minecraft:overworld run setblock 295 76 -25 grass_block
execute in minecraft:overworld run fill 295 77 -25 295 144 -25 air
execute in minecraft:overworld run fill 295 58 -24 295 72 -24 stone
execute in minecraft:overworld run fill 295 73 -24 295 74 -24 dirt
execute in minecraft:overworld run setblock 295 75 -24 grass_block
execute in minecraft:overworld run fill 295 76 -24 295 144 -24 air
execute in minecraft:overworld run fill 295 58 -23 295 72 -23 stone
execute in minecraft:overworld run fill 295 73 -23 295 74 -23 dirt
execute in minecraft:overworld run setblock 295 75 -23 coarse_dirt
execute in minecraft:overworld run fill 295 76 -23 295 144 -23 air
execute in minecraft:overworld run fill 295 58 -22 295 71 -22 stone
execute in minecraft:overworld run fill 295 72 -22 295 73 -22 dirt
execute in minecraft:overworld run setblock 295 74 -22 coarse_dirt
execute in minecraft:overworld run fill 295 75 -22 295 144 -22 air
execute in minecraft:overworld run fill 295 58 -21 295 71 -21 stone
execute in minecraft:overworld run fill 295 72 -21 295 73 -21 dirt
execute in minecraft:overworld run setblock 295 74 -21 grass_block
execute in minecraft:overworld run fill 295 75 -21 295 144 -21 air
execute in minecraft:overworld run setblock 295 75 -21 mossy_cobblestone
execute in minecraft:overworld run fill 295 58 -20 295 70 -20 stone
execute in minecraft:overworld run fill 295 71 -20 295 72 -20 dirt
execute in minecraft:overworld run setblock 295 73 -20 grass_block
execute in minecraft:overworld run fill 295 74 -20 295 144 -20 air
execute in minecraft:overworld run setblock 295 74 -20 grass
execute in minecraft:overworld run fill 295 58 -19 295 70 -19 stone
execute in minecraft:overworld run fill 295 71 -19 295 72 -19 dirt
execute in minecraft:overworld run setblock 295 73 -19 coarse_dirt
execute in minecraft:overworld run fill 295 74 -19 295 144 -19 air
execute in minecraft:overworld run fill 295 58 -18 295 70 -18 stone
execute in minecraft:overworld run fill 295 71 -18 295 72 -18 dirt
execute in minecraft:overworld run setblock 295 73 -18 grass_block
execute in minecraft:overworld run fill 295 74 -18 295 144 -18 air
execute in minecraft:overworld run fill 295 58 -17 295 69 -17 stone
execute in minecraft:overworld run fill 295 70 -17 295 71 -17 dirt
execute in minecraft:overworld run setblock 295 72 -17 coarse_dirt
execute in minecraft:overworld run fill 295 73 -17 295 144 -17 air
execute in minecraft:overworld run fill 295 58 -16 295 69 -16 stone
execute in minecraft:overworld run fill 295 70 -16 295 71 -16 dirt
execute in minecraft:overworld run setblock 295 72 -16 coarse_dirt
execute in minecraft:overworld run fill 295 73 -16 295 144 -16 air
execute in minecraft:overworld run fill 295 58 -15 295 68 -15 stone
execute in minecraft:overworld run fill 295 69 -15 295 70 -15 dirt
execute in minecraft:overworld run setblock 295 71 -15 grass_block
execute in minecraft:overworld run fill 295 72 -15 295 144 -15 air
execute in minecraft:overworld run fill 295 58 -14 295 68 -14 stone
execute in minecraft:overworld run fill 295 69 -14 295 70 -14 dirt
execute in minecraft:overworld run setblock 295 71 -14 coarse_dirt
execute in minecraft:overworld run fill 295 72 -14 295 144 -14 air
execute in minecraft:overworld run fill 295 58 -13 295 68 -13 stone
execute in minecraft:overworld run fill 295 69 -13 295 70 -13 dirt
execute in minecraft:overworld run setblock 295 71 -13 coarse_dirt
execute in minecraft:overworld run fill 295 72 -13 295 144 -13 air
execute in minecraft:overworld run fill 295 58 -12 295 67 -12 stone
execute in minecraft:overworld run fill 295 68 -12 295 69 -12 dirt
execute in minecraft:overworld run setblock 295 70 -12 coarse_dirt
execute in minecraft:overworld run fill 295 71 -12 295 144 -12 air
execute in minecraft:overworld run fill 295 58 -11 295 67 -11 stone
execute in minecraft:overworld run fill 295 68 -11 295 69 -11 dirt
execute in minecraft:overworld run setblock 295 70 -11 coarse_dirt
execute in minecraft:overworld run fill 295 71 -11 295 144 -11 air
execute in minecraft:overworld run fill 295 58 -10 295 67 -10 stone
execute in minecraft:overworld run fill 295 68 -10 295 69 -10 dirt
execute in minecraft:overworld run setblock 295 70 -10 coarse_dirt
execute in minecraft:overworld run fill 295 71 -10 295 144 -10 air
execute in minecraft:overworld run fill 295 58 -9 295 67 -9 stone
execute in minecraft:overworld run fill 295 68 -9 295 69 -9 dirt
execute in minecraft:overworld run setblock 295 70 -9 grass_block
execute in minecraft:overworld run fill 295 71 -9 295 144 -9 air
execute in minecraft:overworld run fill 295 58 -8 295 67 -8 stone
execute in minecraft:overworld run fill 295 68 -8 295 69 -8 dirt
execute in minecraft:overworld run setblock 295 70 -8 grass_block
execute in minecraft:overworld run fill 295 71 -8 295 144 -8 air
execute in minecraft:overworld run setblock 295 71 -8 grass
execute in minecraft:overworld run fill 295 58 -7 295 67 -7 stone
execute in minecraft:overworld run fill 295 68 -7 295 69 -7 dirt
execute in minecraft:overworld run setblock 295 70 -7 coarse_dirt
execute in minecraft:overworld run fill 295 71 -7 295 144 -7 air
execute in minecraft:overworld run fill 295 58 -6 295 67 -6 stone
execute in minecraft:overworld run fill 295 68 -6 295 69 -6 dirt
execute in minecraft:overworld run setblock 295 70 -6 grass_block
execute in minecraft:overworld run fill 295 71 -6 295 144 -6 air
execute in minecraft:overworld run fill 295 58 -5 295 68 -5 stone
execute in minecraft:overworld run fill 295 69 -5 295 70 -5 dirt
execute in minecraft:overworld run setblock 295 71 -5 grass_block
execute in minecraft:overworld run fill 295 72 -5 295 144 -5 air
execute in minecraft:overworld run fill 295 58 -4 295 68 -4 stone
execute in minecraft:overworld run fill 295 69 -4 295 70 -4 dirt
execute in minecraft:overworld run setblock 295 71 -4 coarse_dirt
execute in minecraft:overworld run fill 295 72 -4 295 144 -4 air
execute in minecraft:overworld run fill 295 58 -3 295 68 -3 stone
execute in minecraft:overworld run fill 295 69 -3 295 70 -3 dirt
schedule function blade_gallery:random/burned/part_138 1t replace
