execute in minecraft:overworld run setblock 337 64 47 coarse_dirt
execute in minecraft:overworld run fill 337 65 47 337 144 47 air
execute in minecraft:overworld run fill 338 58 -48 338 61 -48 stone
execute in minecraft:overworld run fill 338 62 -48 338 63 -48 dirt
execute in minecraft:overworld run setblock 338 64 -48 coarse_dirt
execute in minecraft:overworld run fill 338 65 -48 338 144 -48 air
execute in minecraft:overworld run fill 338 58 -47 338 63 -47 stone
execute in minecraft:overworld run fill 338 64 -47 338 65 -47 dirt
execute in minecraft:overworld run setblock 338 66 -47 coarse_dirt
execute in minecraft:overworld run fill 338 67 -47 338 144 -47 air
execute in minecraft:overworld run fill 338 58 -46 338 65 -46 stone
execute in minecraft:overworld run fill 338 66 -46 338 67 -46 dirt
execute in minecraft:overworld run setblock 338 68 -46 coarse_dirt
execute in minecraft:overworld run fill 338 69 -46 338 144 -46 air
execute in minecraft:overworld run fill 338 58 -45 338 65 -45 stone
execute in minecraft:overworld run fill 338 66 -45 338 67 -45 dirt
execute in minecraft:overworld run setblock 338 68 -45 grass_block
execute in minecraft:overworld run fill 338 69 -45 338 144 -45 air
execute in minecraft:overworld run fill 338 58 -44 338 65 -44 stone
execute in minecraft:overworld run fill 338 66 -44 338 67 -44 dirt
execute in minecraft:overworld run setblock 338 68 -44 grass_block
execute in minecraft:overworld run fill 338 69 -44 338 144 -44 air
execute in minecraft:overworld run fill 338 58 -43 338 65 -43 stone
execute in minecraft:overworld run fill 338 66 -43 338 67 -43 dirt
execute in minecraft:overworld run setblock 338 68 -43 grass_block
execute in minecraft:overworld run fill 338 69 -43 338 144 -43 air
execute in minecraft:overworld run fill 338 58 -42 338 64 -42 stone
execute in minecraft:overworld run fill 338 65 -42 338 66 -42 dirt
execute in minecraft:overworld run setblock 338 67 -42 coarse_dirt
execute in minecraft:overworld run fill 338 68 -42 338 144 -42 air
execute in minecraft:overworld run fill 338 58 -41 338 64 -41 stone
execute in minecraft:overworld run fill 338 65 -41 338 66 -41 dirt
execute in minecraft:overworld run setblock 338 67 -41 coarse_dirt
execute in minecraft:overworld run fill 338 68 -41 338 144 -41 air
execute in minecraft:overworld run fill 338 58 -40 338 64 -40 stone
execute in minecraft:overworld run fill 338 65 -40 338 66 -40 dirt
execute in minecraft:overworld run setblock 338 67 -40 grass_block
execute in minecraft:overworld run fill 338 68 -40 338 144 -40 air
execute in minecraft:overworld run fill 338 58 -39 338 64 -39 stone
execute in minecraft:overworld run fill 338 65 -39 338 66 -39 dirt
execute in minecraft:overworld run setblock 338 67 -39 grass_block
execute in minecraft:overworld run fill 338 68 -39 338 144 -39 air
execute in minecraft:overworld run fill 338 58 -38 338 64 -38 stone
execute in minecraft:overworld run fill 338 65 -38 338 66 -38 dirt
execute in minecraft:overworld run setblock 338 67 -38 coarse_dirt
execute in minecraft:overworld run fill 338 68 -38 338 144 -38 air
execute in minecraft:overworld run fill 338 58 -37 338 64 -37 stone
execute in minecraft:overworld run fill 338 65 -37 338 66 -37 dirt
execute in minecraft:overworld run setblock 338 67 -37 grass_block
execute in minecraft:overworld run fill 338 68 -37 338 144 -37 air
execute in minecraft:overworld run fill 338 58 -36 338 64 -36 stone
execute in minecraft:overworld run fill 338 65 -36 338 66 -36 dirt
execute in minecraft:overworld run setblock 338 67 -36 coarse_dirt
execute in minecraft:overworld run fill 338 68 -36 338 144 -36 air
execute in minecraft:overworld run fill 338 58 -35 338 64 -35 stone
execute in minecraft:overworld run fill 338 65 -35 338 66 -35 dirt
execute in minecraft:overworld run setblock 338 67 -35 coarse_dirt
execute in minecraft:overworld run fill 338 68 -35 338 144 -35 air
execute in minecraft:overworld run fill 338 58 -34 338 64 -34 stone
execute in minecraft:overworld run fill 338 65 -34 338 66 -34 dirt
execute in minecraft:overworld run setblock 338 67 -34 grass_block
execute in minecraft:overworld run fill 338 68 -34 338 144 -34 air
execute in minecraft:overworld run fill 338 58 -33 338 64 -33 stone
execute in minecraft:overworld run fill 338 65 -33 338 66 -33 dirt
execute in minecraft:overworld run setblock 338 67 -33 coarse_dirt
execute in minecraft:overworld run fill 338 68 -33 338 144 -33 air
execute in minecraft:overworld run fill 338 58 -32 338 64 -32 stone
execute in minecraft:overworld run fill 338 65 -32 338 66 -32 dirt
execute in minecraft:overworld run setblock 338 67 -32 grass_block
execute in minecraft:overworld run fill 338 68 -32 338 144 -32 air
execute in minecraft:overworld run fill 338 58 -31 338 64 -31 stone
execute in minecraft:overworld run fill 338 65 -31 338 66 -31 dirt
execute in minecraft:overworld run setblock 338 67 -31 grass_block
execute in minecraft:overworld run fill 338 68 -31 338 144 -31 air
execute in minecraft:overworld run fill 338 58 -30 338 64 -30 stone
execute in minecraft:overworld run fill 338 65 -30 338 66 -30 dirt
execute in minecraft:overworld run setblock 338 67 -30 coarse_dirt
execute in minecraft:overworld run fill 338 68 -30 338 144 -30 air
execute in minecraft:overworld run fill 338 58 -29 338 64 -29 stone
execute in minecraft:overworld run fill 338 65 -29 338 66 -29 dirt
execute in minecraft:overworld run setblock 338 67 -29 coarse_dirt
execute in minecraft:overworld run fill 338 68 -29 338 144 -29 air
execute in minecraft:overworld run fill 338 58 -28 338 64 -28 stone
execute in minecraft:overworld run fill 338 65 -28 338 66 -28 dirt
execute in minecraft:overworld run setblock 338 67 -28 grass_block
execute in minecraft:overworld run fill 338 68 -28 338 144 -28 air
execute in minecraft:overworld run fill 338 58 -27 338 63 -27 stone
execute in minecraft:overworld run fill 338 64 -27 338 65 -27 dirt
execute in minecraft:overworld run setblock 338 66 -27 coarse_dirt
execute in minecraft:overworld run fill 338 67 -27 338 144 -27 air
execute in minecraft:overworld run fill 338 58 -26 338 63 -26 stone
execute in minecraft:overworld run fill 338 64 -26 338 65 -26 dirt
execute in minecraft:overworld run setblock 338 66 -26 coarse_dirt
execute in minecraft:overworld run fill 338 67 -26 338 144 -26 air
execute in minecraft:overworld run fill 338 58 -25 338 63 -25 stone
execute in minecraft:overworld run fill 338 64 -25 338 65 -25 dirt
execute in minecraft:overworld run setblock 338 66 -25 coarse_dirt
execute in minecraft:overworld run fill 338 67 -25 338 144 -25 air
execute in minecraft:overworld run fill 338 58 -24 338 63 -24 stone
execute in minecraft:overworld run fill 338 64 -24 338 65 -24 dirt
execute in minecraft:overworld run setblock 338 66 -24 grass_block
execute in minecraft:overworld run fill 338 67 -24 338 144 -24 air
execute in minecraft:overworld run fill 338 58 -23 338 63 -23 stone
execute in minecraft:overworld run fill 338 64 -23 338 65 -23 dirt
execute in minecraft:overworld run setblock 338 66 -23 coarse_dirt
execute in minecraft:overworld run fill 338 67 -23 338 144 -23 air
execute in minecraft:overworld run fill 338 58 -22 338 63 -22 stone
execute in minecraft:overworld run fill 338 64 -22 338 65 -22 dirt
execute in minecraft:overworld run setblock 338 66 -22 grass_block
execute in minecraft:overworld run fill 338 67 -22 338 144 -22 air
execute in minecraft:overworld run fill 338 58 -21 338 63 -21 stone
execute in minecraft:overworld run fill 338 64 -21 338 65 -21 dirt
execute in minecraft:overworld run setblock 338 66 -21 grass_block
execute in minecraft:overworld run fill 338 67 -21 338 144 -21 air
execute in minecraft:overworld run fill 338 58 -20 338 63 -20 stone
execute in minecraft:overworld run fill 338 64 -20 338 65 -20 dirt
execute in minecraft:overworld run setblock 338 66 -20 coarse_dirt
execute in minecraft:overworld run fill 338 67 -20 338 144 -20 air
execute in minecraft:overworld run fill 338 58 -19 338 63 -19 stone
execute in minecraft:overworld run fill 338 64 -19 338 65 -19 dirt
execute in minecraft:overworld run setblock 338 66 -19 grass_block
execute in minecraft:overworld run fill 338 67 -19 338 144 -19 air
execute in minecraft:overworld run fill 338 58 -18 338 63 -18 stone
execute in minecraft:overworld run fill 338 64 -18 338 65 -18 dirt
execute in minecraft:overworld run setblock 338 66 -18 coarse_dirt
execute in minecraft:overworld run fill 338 67 -18 338 144 -18 air
execute in minecraft:overworld run fill 338 58 -17 338 63 -17 stone
execute in minecraft:overworld run fill 338 64 -17 338 65 -17 dirt
execute in minecraft:overworld run setblock 338 66 -17 grass_block
execute in minecraft:overworld run fill 338 67 -17 338 144 -17 air
execute in minecraft:overworld run fill 338 58 -16 338 63 -16 stone
execute in minecraft:overworld run fill 338 64 -16 338 65 -16 dirt
execute in minecraft:overworld run setblock 338 66 -16 coarse_dirt
execute in minecraft:overworld run fill 338 67 -16 338 144 -16 air
execute in minecraft:overworld run fill 338 58 -15 338 63 -15 stone
execute in minecraft:overworld run fill 338 64 -15 338 65 -15 dirt
execute in minecraft:overworld run setblock 338 66 -15 coarse_dirt
execute in minecraft:overworld run fill 338 67 -15 338 144 -15 air
execute in minecraft:overworld run fill 338 58 -14 338 62 -14 stone
execute in minecraft:overworld run fill 338 63 -14 338 64 -14 dirt
execute in minecraft:overworld run setblock 338 65 -14 grass_block
execute in minecraft:overworld run fill 338 66 -14 338 144 -14 air
execute in minecraft:overworld run fill 338 58 -13 338 62 -13 stone
execute in minecraft:overworld run fill 338 63 -13 338 64 -13 dirt
execute in minecraft:overworld run setblock 338 65 -13 grass_block
execute in minecraft:overworld run fill 338 66 -13 338 144 -13 air
execute in minecraft:overworld run fill 338 58 -12 338 62 -12 stone
execute in minecraft:overworld run fill 338 63 -12 338 64 -12 dirt
execute in minecraft:overworld run setblock 338 65 -12 coarse_dirt
execute in minecraft:overworld run fill 338 66 -12 338 144 -12 air
execute in minecraft:overworld run fill 338 58 -11 338 62 -11 stone
execute in minecraft:overworld run fill 338 63 -11 338 64 -11 dirt
execute in minecraft:overworld run setblock 338 65 -11 coarse_dirt
execute in minecraft:overworld run fill 338 66 -11 338 144 -11 air
execute in minecraft:overworld run fill 338 58 -10 338 62 -10 stone
execute in minecraft:overworld run fill 338 63 -10 338 64 -10 dirt
execute in minecraft:overworld run setblock 338 65 -10 coarse_dirt
execute in minecraft:overworld run fill 338 66 -10 338 144 -10 air
execute in minecraft:overworld run fill 338 58 -9 338 62 -9 stone
execute in minecraft:overworld run fill 338 63 -9 338 64 -9 dirt
execute in minecraft:overworld run setblock 338 65 -9 coarse_dirt
execute in minecraft:overworld run fill 338 66 -9 338 144 -9 air
execute in minecraft:overworld run fill 338 58 -8 338 62 -8 stone
execute in minecraft:overworld run fill 338 63 -8 338 64 -8 dirt
execute in minecraft:overworld run setblock 338 65 -8 coarse_dirt
execute in minecraft:overworld run fill 338 66 -8 338 144 -8 air
execute in minecraft:overworld run fill 338 58 -7 338 62 -7 stone
execute in minecraft:overworld run fill 338 63 -7 338 64 -7 dirt
execute in minecraft:overworld run setblock 338 65 -7 coarse_dirt
execute in minecraft:overworld run fill 338 66 -7 338 144 -7 air
execute in minecraft:overworld run fill 338 58 -6 338 62 -6 stone
execute in minecraft:overworld run fill 338 63 -6 338 64 -6 dirt
execute in minecraft:overworld run setblock 338 65 -6 coarse_dirt
execute in minecraft:overworld run fill 338 66 -6 338 144 -6 air
execute in minecraft:overworld run fill 338 58 -5 338 62 -5 stone
execute in minecraft:overworld run fill 338 63 -5 338 64 -5 dirt
execute in minecraft:overworld run setblock 338 65 -5 grass_block
execute in minecraft:overworld run fill 338 66 -5 338 144 -5 air
execute in minecraft:overworld run fill 338 58 -4 338 62 -4 stone
execute in minecraft:overworld run fill 338 63 -4 338 64 -4 dirt
execute in minecraft:overworld run setblock 338 65 -4 coarse_dirt
execute in minecraft:overworld run fill 338 66 -4 338 144 -4 air
execute in minecraft:overworld run fill 338 58 -3 338 62 -3 stone
execute in minecraft:overworld run fill 338 63 -3 338 64 -3 dirt
execute in minecraft:overworld run setblock 338 65 -3 grass_block
execute in minecraft:overworld run fill 338 66 -3 338 144 -3 air
execute in minecraft:overworld run fill 338 58 -2 338 62 -2 stone
execute in minecraft:overworld run fill 338 63 -2 338 64 -2 dirt
execute in minecraft:overworld run setblock 338 65 -2 coarse_dirt
execute in minecraft:overworld run fill 338 66 -2 338 144 -2 air
execute in minecraft:overworld run fill 338 58 -1 338 62 -1 stone
execute in minecraft:overworld run fill 338 63 -1 338 64 -1 dirt
execute in minecraft:overworld run setblock 338 65 -1 coarse_dirt
execute in minecraft:overworld run fill 338 66 -1 338 144 -1 air
execute in minecraft:overworld run fill 338 58 0 338 62 0 stone
execute in minecraft:overworld run fill 338 63 0 338 64 0 dirt
execute in minecraft:overworld run setblock 338 65 0 grass_block
execute in minecraft:overworld run fill 338 66 0 338 144 0 air
execute in minecraft:overworld run fill 338 58 1 338 62 1 stone
execute in minecraft:overworld run fill 338 63 1 338 64 1 dirt
execute in minecraft:overworld run setblock 338 65 1 grass_block
execute in minecraft:overworld run fill 338 66 1 338 144 1 air
execute in minecraft:overworld run fill 338 58 2 338 62 2 stone
execute in minecraft:overworld run fill 338 63 2 338 64 2 dirt
execute in minecraft:overworld run setblock 338 65 2 grass_block
execute in minecraft:overworld run fill 338 66 2 338 144 2 air
execute in minecraft:overworld run fill 338 58 3 338 62 3 stone
execute in minecraft:overworld run fill 338 63 3 338 64 3 dirt
execute in minecraft:overworld run setblock 338 65 3 coarse_dirt
execute in minecraft:overworld run fill 338 66 3 338 144 3 air
execute in minecraft:overworld run fill 338 58 4 338 62 4 stone
execute in minecraft:overworld run fill 338 63 4 338 64 4 dirt
execute in minecraft:overworld run setblock 338 65 4 coarse_dirt
execute in minecraft:overworld run fill 338 66 4 338 144 4 air
execute in minecraft:overworld run fill 338 58 5 338 62 5 stone
execute in minecraft:overworld run fill 338 63 5 338 64 5 dirt
execute in minecraft:overworld run setblock 338 65 5 coarse_dirt
execute in minecraft:overworld run fill 338 66 5 338 144 5 air
execute in minecraft:overworld run fill 338 58 6 338 62 6 stone
execute in minecraft:overworld run fill 338 63 6 338 64 6 dirt
execute in minecraft:overworld run setblock 338 65 6 grass_block
execute in minecraft:overworld run fill 338 66 6 338 144 6 air
execute in minecraft:overworld run fill 338 58 7 338 62 7 stone
execute in minecraft:overworld run fill 338 63 7 338 64 7 dirt
execute in minecraft:overworld run setblock 338 65 7 coarse_dirt
execute in minecraft:overworld run fill 338 66 7 338 144 7 air
execute in minecraft:overworld run fill 338 58 8 338 62 8 stone
execute in minecraft:overworld run fill 338 63 8 338 64 8 dirt
execute in minecraft:overworld run setblock 338 65 8 coarse_dirt
execute in minecraft:overworld run fill 338 66 8 338 144 8 air
execute in minecraft:overworld run fill 338 58 9 338 62 9 stone
execute in minecraft:overworld run fill 338 63 9 338 64 9 dirt
execute in minecraft:overworld run setblock 338 65 9 coarse_dirt
execute in minecraft:overworld run fill 338 66 9 338 144 9 air
execute in minecraft:overworld run fill 338 58 10 338 62 10 stone
execute in minecraft:overworld run fill 338 63 10 338 64 10 dirt
execute in minecraft:overworld run setblock 338 65 10 coarse_dirt
execute in minecraft:overworld run fill 338 66 10 338 144 10 air
execute in minecraft:overworld run fill 338 58 11 338 62 11 stone
execute in minecraft:overworld run fill 338 63 11 338 64 11 dirt
execute in minecraft:overworld run setblock 338 65 11 coarse_dirt
execute in minecraft:overworld run fill 338 66 11 338 144 11 air
execute in minecraft:overworld run fill 338 58 12 338 62 12 stone
execute in minecraft:overworld run fill 338 63 12 338 64 12 dirt
execute in minecraft:overworld run setblock 338 65 12 coarse_dirt
execute in minecraft:overworld run fill 338 66 12 338 144 12 air
execute in minecraft:overworld run fill 338 58 13 338 62 13 stone
execute in minecraft:overworld run fill 338 63 13 338 64 13 dirt
execute in minecraft:overworld run setblock 338 65 13 coarse_dirt
execute in minecraft:overworld run fill 338 66 13 338 144 13 air
execute in minecraft:overworld run fill 338 58 14 338 62 14 stone
execute in minecraft:overworld run fill 338 63 14 338 64 14 dirt
execute in minecraft:overworld run setblock 338 65 14 coarse_dirt
execute in minecraft:overworld run fill 338 66 14 338 144 14 air
execute in minecraft:overworld run fill 338 58 15 338 62 15 stone
execute in minecraft:overworld run fill 338 63 15 338 64 15 dirt
schedule function blade_gallery:random/battlefield/part_4 1t replace
