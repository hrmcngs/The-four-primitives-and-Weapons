execute in minecraft:overworld run fill 345 58 39 345 64 39 stone
execute in minecraft:overworld run fill 345 65 39 345 66 39 dirt
execute in minecraft:overworld run setblock 345 67 39 coarse_dirt
execute in minecraft:overworld run fill 345 68 39 345 144 39 air
execute in minecraft:overworld run fill 345 58 40 345 64 40 stone
execute in minecraft:overworld run fill 345 65 40 345 66 40 dirt
execute in minecraft:overworld run setblock 345 67 40 coarse_dirt
execute in minecraft:overworld run fill 345 68 40 345 144 40 air
execute in minecraft:overworld run setblock 345 68 40 grass
execute in minecraft:overworld run fill 345 58 41 345 64 41 stone
execute in minecraft:overworld run fill 345 65 41 345 66 41 dirt
execute in minecraft:overworld run setblock 345 67 41 coarse_dirt
execute in minecraft:overworld run fill 345 68 41 345 144 41 air
execute in minecraft:overworld run fill 345 58 42 345 63 42 stone
execute in minecraft:overworld run fill 345 64 42 345 65 42 dirt
execute in minecraft:overworld run setblock 345 66 42 coarse_dirt
execute in minecraft:overworld run fill 345 67 42 345 144 42 air
execute in minecraft:overworld run fill 345 58 43 345 63 43 stone
execute in minecraft:overworld run fill 345 64 43 345 65 43 dirt
execute in minecraft:overworld run setblock 345 66 43 grass_block
execute in minecraft:overworld run fill 345 67 43 345 144 43 air
execute in minecraft:overworld run fill 345 58 44 345 63 44 stone
execute in minecraft:overworld run fill 345 64 44 345 65 44 dirt
execute in minecraft:overworld run setblock 345 66 44 coarse_dirt
execute in minecraft:overworld run fill 345 67 44 345 144 44 air
execute in minecraft:overworld run fill 345 58 45 345 62 45 stone
execute in minecraft:overworld run fill 345 63 45 345 64 45 dirt
execute in minecraft:overworld run setblock 345 65 45 coarse_dirt
execute in minecraft:overworld run fill 345 66 45 345 144 45 air
execute in minecraft:overworld run fill 345 58 46 345 62 46 stone
execute in minecraft:overworld run fill 345 63 46 345 64 46 dirt
execute in minecraft:overworld run setblock 345 65 46 grass_block
execute in minecraft:overworld run fill 345 66 46 345 144 46 air
execute in minecraft:overworld run fill 345 58 47 345 61 47 stone
execute in minecraft:overworld run fill 345 62 47 345 63 47 dirt
execute in minecraft:overworld run setblock 345 64 47 grass_block
execute in minecraft:overworld run fill 345 65 47 345 144 47 air
execute in minecraft:overworld run fill 346 58 -48 346 61 -48 stone
execute in minecraft:overworld run fill 346 62 -48 346 63 -48 dirt
execute in minecraft:overworld run setblock 346 64 -48 coarse_dirt
execute in minecraft:overworld run fill 346 65 -48 346 144 -48 air
execute in minecraft:overworld run fill 346 58 -47 346 63 -47 stone
execute in minecraft:overworld run fill 346 64 -47 346 65 -47 dirt
execute in minecraft:overworld run setblock 346 66 -47 coarse_dirt
execute in minecraft:overworld run fill 346 67 -47 346 144 -47 air
execute in minecraft:overworld run fill 346 58 -46 346 65 -46 stone
execute in minecraft:overworld run fill 346 66 -46 346 67 -46 dirt
execute in minecraft:overworld run setblock 346 68 -46 grass_block
execute in minecraft:overworld run fill 346 69 -46 346 144 -46 air
execute in minecraft:overworld run fill 346 58 -45 346 66 -45 stone
execute in minecraft:overworld run fill 346 67 -45 346 68 -45 dirt
execute in minecraft:overworld run setblock 346 69 -45 coarse_dirt
execute in minecraft:overworld run fill 346 70 -45 346 144 -45 air
execute in minecraft:overworld run fill 346 58 -44 346 68 -44 stone
execute in minecraft:overworld run fill 346 69 -44 346 70 -44 dirt
execute in minecraft:overworld run setblock 346 71 -44 grass_block
execute in minecraft:overworld run fill 346 72 -44 346 144 -44 air
execute in minecraft:overworld run fill 346 58 -43 346 70 -43 stone
execute in minecraft:overworld run fill 346 71 -43 346 72 -43 dirt
execute in minecraft:overworld run setblock 346 73 -43 coarse_dirt
execute in minecraft:overworld run fill 346 74 -43 346 144 -43 air
execute in minecraft:overworld run fill 346 58 -42 346 71 -42 stone
execute in minecraft:overworld run fill 346 72 -42 346 73 -42 dirt
execute in minecraft:overworld run setblock 346 74 -42 coarse_dirt
execute in minecraft:overworld run fill 346 75 -42 346 144 -42 air
execute in minecraft:overworld run fill 346 58 -41 346 73 -41 stone
execute in minecraft:overworld run fill 346 74 -41 346 75 -41 dirt
execute in minecraft:overworld run setblock 346 76 -41 coarse_dirt
execute in minecraft:overworld run fill 346 77 -41 346 144 -41 air
execute in minecraft:overworld run fill 346 58 -40 346 74 -40 stone
execute in minecraft:overworld run fill 346 75 -40 346 76 -40 dirt
execute in minecraft:overworld run setblock 346 77 -40 coarse_dirt
execute in minecraft:overworld run fill 346 78 -40 346 144 -40 air
execute in minecraft:overworld run fill 346 58 -39 346 76 -39 stone
execute in minecraft:overworld run fill 346 77 -39 346 78 -39 dirt
execute in minecraft:overworld run setblock 346 79 -39 coarse_dirt
execute in minecraft:overworld run fill 346 80 -39 346 144 -39 air
execute in minecraft:overworld run fill 346 58 -38 346 77 -38 stone
execute in minecraft:overworld run fill 346 78 -38 346 79 -38 dirt
execute in minecraft:overworld run setblock 346 80 -38 coarse_dirt
execute in minecraft:overworld run fill 346 81 -38 346 144 -38 air
execute in minecraft:overworld run fill 346 58 -37 346 76 -37 stone
execute in minecraft:overworld run fill 346 77 -37 346 78 -37 dirt
execute in minecraft:overworld run setblock 346 79 -37 grass_block
execute in minecraft:overworld run fill 346 80 -37 346 144 -37 air
execute in minecraft:overworld run fill 346 58 -36 346 76 -36 stone
execute in minecraft:overworld run fill 346 77 -36 346 78 -36 dirt
execute in minecraft:overworld run setblock 346 79 -36 coarse_dirt
execute in minecraft:overworld run fill 346 80 -36 346 144 -36 air
execute in minecraft:overworld run fill 346 58 -35 346 76 -35 stone
execute in minecraft:overworld run fill 346 77 -35 346 78 -35 dirt
execute in minecraft:overworld run setblock 346 79 -35 coarse_dirt
execute in minecraft:overworld run fill 346 80 -35 346 144 -35 air
execute in minecraft:overworld run setblock 346 80 -35 grass
execute in minecraft:overworld run fill 346 58 -34 346 76 -34 stone
execute in minecraft:overworld run fill 346 77 -34 346 78 -34 dirt
execute in minecraft:overworld run setblock 346 79 -34 grass_block
execute in minecraft:overworld run fill 346 80 -34 346 144 -34 air
execute in minecraft:overworld run fill 346 58 -33 346 75 -33 stone
execute in minecraft:overworld run fill 346 76 -33 346 77 -33 dirt
execute in minecraft:overworld run setblock 346 78 -33 coarse_dirt
execute in minecraft:overworld run fill 346 79 -33 346 144 -33 air
execute in minecraft:overworld run fill 346 58 -32 346 75 -32 stone
execute in minecraft:overworld run fill 346 76 -32 346 77 -32 dirt
execute in minecraft:overworld run setblock 346 78 -32 coarse_dirt
execute in minecraft:overworld run fill 346 79 -32 346 144 -32 air
execute in minecraft:overworld run fill 346 58 -31 346 75 -31 stone
execute in minecraft:overworld run fill 346 76 -31 346 77 -31 dirt
execute in minecraft:overworld run setblock 346 78 -31 coarse_dirt
execute in minecraft:overworld run fill 346 79 -31 346 144 -31 air
execute in minecraft:overworld run fill 346 58 -30 346 74 -30 stone
execute in minecraft:overworld run fill 346 75 -30 346 76 -30 dirt
execute in minecraft:overworld run setblock 346 77 -30 grass_block
execute in minecraft:overworld run fill 346 78 -30 346 144 -30 air
execute in minecraft:overworld run fill 346 58 -29 346 74 -29 stone
execute in minecraft:overworld run fill 346 75 -29 346 76 -29 dirt
execute in minecraft:overworld run setblock 346 77 -29 coarse_dirt
execute in minecraft:overworld run fill 346 78 -29 346 144 -29 air
execute in minecraft:overworld run fill 346 58 -28 346 74 -28 stone
execute in minecraft:overworld run fill 346 75 -28 346 76 -28 dirt
execute in minecraft:overworld run setblock 346 77 -28 grass_block
execute in minecraft:overworld run fill 346 78 -28 346 144 -28 air
execute in minecraft:overworld run fill 346 58 -27 346 73 -27 stone
execute in minecraft:overworld run fill 346 74 -27 346 75 -27 dirt
execute in minecraft:overworld run setblock 346 76 -27 coarse_dirt
execute in minecraft:overworld run fill 346 77 -27 346 144 -27 air
execute in minecraft:overworld run fill 346 58 -26 346 73 -26 stone
execute in minecraft:overworld run fill 346 74 -26 346 75 -26 dirt
execute in minecraft:overworld run setblock 346 76 -26 grass_block
execute in minecraft:overworld run fill 346 77 -26 346 144 -26 air
execute in minecraft:overworld run fill 346 58 -25 346 73 -25 stone
execute in minecraft:overworld run fill 346 74 -25 346 75 -25 dirt
execute in minecraft:overworld run setblock 346 76 -25 coarse_dirt
execute in minecraft:overworld run fill 346 77 -25 346 144 -25 air
execute in minecraft:overworld run setblock 346 77 -25 grass
execute in minecraft:overworld run fill 346 58 -24 346 72 -24 stone
execute in minecraft:overworld run fill 346 73 -24 346 74 -24 dirt
execute in minecraft:overworld run setblock 346 75 -24 coarse_dirt
execute in minecraft:overworld run fill 346 76 -24 346 144 -24 air
execute in minecraft:overworld run fill 346 58 -23 346 72 -23 stone
execute in minecraft:overworld run fill 346 73 -23 346 74 -23 dirt
execute in minecraft:overworld run setblock 346 75 -23 grass_block
execute in minecraft:overworld run fill 346 76 -23 346 144 -23 air
execute in minecraft:overworld run fill 346 58 -22 346 72 -22 stone
execute in minecraft:overworld run fill 346 73 -22 346 74 -22 dirt
execute in minecraft:overworld run setblock 346 75 -22 coarse_dirt
execute in minecraft:overworld run fill 346 76 -22 346 144 -22 air
execute in minecraft:overworld run fill 346 58 -21 346 72 -21 stone
execute in minecraft:overworld run fill 346 73 -21 346 74 -21 dirt
execute in minecraft:overworld run setblock 346 75 -21 grass_block
execute in minecraft:overworld run fill 346 76 -21 346 144 -21 air
execute in minecraft:overworld run fill 346 58 -20 346 71 -20 stone
execute in minecraft:overworld run fill 346 72 -20 346 73 -20 dirt
execute in minecraft:overworld run setblock 346 74 -20 coarse_dirt
execute in minecraft:overworld run fill 346 75 -20 346 144 -20 air
execute in minecraft:overworld run fill 346 58 -19 346 71 -19 stone
execute in minecraft:overworld run fill 346 72 -19 346 73 -19 dirt
execute in minecraft:overworld run setblock 346 74 -19 coarse_dirt
execute in minecraft:overworld run fill 346 75 -19 346 144 -19 air
execute in minecraft:overworld run fill 346 58 -18 346 70 -18 stone
execute in minecraft:overworld run fill 346 71 -18 346 72 -18 dirt
execute in minecraft:overworld run setblock 346 73 -18 coarse_dirt
execute in minecraft:overworld run fill 346 74 -18 346 144 -18 air
execute in minecraft:overworld run setblock 346 74 -18 grass
execute in minecraft:overworld run fill 346 58 -17 346 70 -17 stone
execute in minecraft:overworld run fill 346 71 -17 346 72 -17 dirt
execute in minecraft:overworld run setblock 346 73 -17 grass_block
execute in minecraft:overworld run fill 346 74 -17 346 144 -17 air
execute in minecraft:overworld run fill 346 58 -16 346 69 -16 stone
execute in minecraft:overworld run fill 346 70 -16 346 71 -16 dirt
execute in minecraft:overworld run setblock 346 72 -16 coarse_dirt
execute in minecraft:overworld run fill 346 73 -16 346 144 -16 air
execute in minecraft:overworld run fill 346 58 -15 346 69 -15 stone
execute in minecraft:overworld run fill 346 70 -15 346 71 -15 dirt
execute in minecraft:overworld run setblock 346 72 -15 grass_block
execute in minecraft:overworld run fill 346 73 -15 346 144 -15 air
execute in minecraft:overworld run fill 346 58 -14 346 68 -14 stone
execute in minecraft:overworld run fill 346 69 -14 346 70 -14 dirt
execute in minecraft:overworld run setblock 346 71 -14 coarse_dirt
execute in minecraft:overworld run fill 346 72 -14 346 144 -14 air
execute in minecraft:overworld run fill 346 58 -13 346 68 -13 stone
execute in minecraft:overworld run fill 346 69 -13 346 70 -13 dirt
execute in minecraft:overworld run setblock 346 71 -13 coarse_dirt
execute in minecraft:overworld run fill 346 72 -13 346 144 -13 air
execute in minecraft:overworld run fill 346 58 -12 346 67 -12 stone
execute in minecraft:overworld run fill 346 68 -12 346 69 -12 dirt
execute in minecraft:overworld run setblock 346 70 -12 coarse_dirt
execute in minecraft:overworld run fill 346 71 -12 346 144 -12 air
execute in minecraft:overworld run fill 346 58 -11 346 67 -11 stone
execute in minecraft:overworld run fill 346 68 -11 346 69 -11 dirt
execute in minecraft:overworld run setblock 346 70 -11 coarse_dirt
execute in minecraft:overworld run fill 346 71 -11 346 144 -11 air
execute in minecraft:overworld run fill 346 58 -10 346 67 -10 stone
execute in minecraft:overworld run fill 346 68 -10 346 69 -10 dirt
execute in minecraft:overworld run setblock 346 70 -10 coarse_dirt
execute in minecraft:overworld run fill 346 71 -10 346 144 -10 air
execute in minecraft:overworld run fill 346 58 -9 346 67 -9 stone
execute in minecraft:overworld run fill 346 68 -9 346 69 -9 dirt
execute in minecraft:overworld run setblock 346 70 -9 coarse_dirt
execute in minecraft:overworld run fill 346 71 -9 346 144 -9 air
execute in minecraft:overworld run fill 346 58 -8 346 67 -8 stone
execute in minecraft:overworld run fill 346 68 -8 346 69 -8 dirt
execute in minecraft:overworld run setblock 346 70 -8 coarse_dirt
execute in minecraft:overworld run fill 346 71 -8 346 144 -8 air
execute in minecraft:overworld run fill 346 58 -7 346 67 -7 stone
execute in minecraft:overworld run fill 346 68 -7 346 69 -7 dirt
execute in minecraft:overworld run setblock 346 70 -7 coarse_dirt
execute in minecraft:overworld run fill 346 71 -7 346 144 -7 air
execute in minecraft:overworld run fill 346 58 -6 346 67 -6 stone
execute in minecraft:overworld run fill 346 68 -6 346 69 -6 dirt
execute in minecraft:overworld run setblock 346 70 -6 coarse_dirt
execute in minecraft:overworld run fill 346 71 -6 346 144 -6 air
execute in minecraft:overworld run fill 346 58 -5 346 67 -5 stone
execute in minecraft:overworld run fill 346 68 -5 346 69 -5 dirt
execute in minecraft:overworld run setblock 346 70 -5 coarse_dirt
execute in minecraft:overworld run fill 346 71 -5 346 144 -5 air
execute in minecraft:overworld run fill 346 58 -4 346 67 -4 stone
execute in minecraft:overworld run fill 346 68 -4 346 69 -4 dirt
execute in minecraft:overworld run setblock 346 70 -4 grass_block
execute in minecraft:overworld run fill 346 71 -4 346 144 -4 air
execute in minecraft:overworld run fill 346 58 -3 346 67 -3 stone
execute in minecraft:overworld run fill 346 68 -3 346 69 -3 dirt
execute in minecraft:overworld run setblock 346 70 -3 coarse_dirt
execute in minecraft:overworld run fill 346 71 -3 346 144 -3 air
execute in minecraft:overworld run fill 346 58 -2 346 67 -2 stone
execute in minecraft:overworld run fill 346 68 -2 346 69 -2 dirt
execute in minecraft:overworld run setblock 346 70 -2 coarse_dirt
execute in minecraft:overworld run fill 346 71 -2 346 144 -2 air
execute in minecraft:overworld run setblock 346 71 -2 grass
execute in minecraft:overworld run fill 346 58 -1 346 67 -1 stone
execute in minecraft:overworld run fill 346 68 -1 346 69 -1 dirt
execute in minecraft:overworld run setblock 346 70 -1 coarse_dirt
execute in minecraft:overworld run fill 346 71 -1 346 144 -1 air
execute in minecraft:overworld run setblock 346 71 -1 grass
execute in minecraft:overworld run fill 346 58 0 346 67 0 stone
execute in minecraft:overworld run fill 346 68 0 346 69 0 dirt
execute in minecraft:overworld run setblock 346 70 0 coarse_dirt
execute in minecraft:overworld run fill 346 71 0 346 144 0 air
execute in minecraft:overworld run fill 346 58 1 346 67 1 stone
execute in minecraft:overworld run fill 346 68 1 346 69 1 dirt
execute in minecraft:overworld run setblock 346 70 1 coarse_dirt
execute in minecraft:overworld run fill 346 71 1 346 144 1 air
execute in minecraft:overworld run fill 346 58 2 346 67 2 stone
execute in minecraft:overworld run fill 346 68 2 346 69 2 dirt
execute in minecraft:overworld run setblock 346 70 2 grass_block
execute in minecraft:overworld run fill 346 71 2 346 144 2 air
execute in minecraft:overworld run fill 346 58 3 346 67 3 stone
execute in minecraft:overworld run fill 346 68 3 346 69 3 dirt
execute in minecraft:overworld run setblock 346 70 3 coarse_dirt
execute in minecraft:overworld run fill 346 71 3 346 144 3 air
execute in minecraft:overworld run fill 346 58 4 346 67 4 stone
execute in minecraft:overworld run fill 346 68 4 346 69 4 dirt
execute in minecraft:overworld run setblock 346 70 4 coarse_dirt
execute in minecraft:overworld run fill 346 71 4 346 144 4 air
execute in minecraft:overworld run fill 346 58 5 346 67 5 stone
execute in minecraft:overworld run fill 346 68 5 346 69 5 dirt
schedule function blade_gallery:random/battlefield/part_16 1t replace
