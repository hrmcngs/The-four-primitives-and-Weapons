execute in minecraft:overworld run fill 395 68 41 395 144 41 air
execute in minecraft:overworld run fill 395 58 42 395 64 42 stone
execute in minecraft:overworld run fill 395 65 42 395 66 42 dirt
execute in minecraft:overworld run setblock 395 67 42 coarse_dirt
execute in minecraft:overworld run fill 395 68 42 395 144 42 air
execute in minecraft:overworld run fill 395 58 43 395 64 43 stone
execute in minecraft:overworld run fill 395 65 43 395 66 43 dirt
execute in minecraft:overworld run setblock 395 67 43 grass_block
execute in minecraft:overworld run fill 395 68 43 395 144 43 air
execute in minecraft:overworld run fill 395 58 44 395 63 44 stone
execute in minecraft:overworld run fill 395 64 44 395 65 44 dirt
execute in minecraft:overworld run setblock 395 66 44 coarse_dirt
execute in minecraft:overworld run fill 395 67 44 395 144 44 air
execute in minecraft:overworld run fill 395 58 45 395 63 45 stone
execute in minecraft:overworld run fill 395 64 45 395 65 45 dirt
execute in minecraft:overworld run setblock 395 66 45 coarse_dirt
execute in minecraft:overworld run fill 395 67 45 395 144 45 air
execute in minecraft:overworld run fill 395 58 46 395 62 46 stone
execute in minecraft:overworld run fill 395 63 46 395 64 46 dirt
execute in minecraft:overworld run setblock 395 65 46 coarse_dirt
execute in minecraft:overworld run fill 395 66 46 395 144 46 air
execute in minecraft:overworld run fill 395 58 47 395 62 47 stone
execute in minecraft:overworld run fill 395 63 47 395 64 47 dirt
execute in minecraft:overworld run setblock 395 65 47 grass_block
execute in minecraft:overworld run fill 395 66 47 395 144 47 air
execute in minecraft:overworld run fill 396 58 -48 396 61 -48 stone
execute in minecraft:overworld run fill 396 62 -48 396 63 -48 dirt
execute in minecraft:overworld run setblock 396 64 -48 coarse_dirt
execute in minecraft:overworld run fill 396 65 -48 396 144 -48 air
execute in minecraft:overworld run fill 396 58 -47 396 62 -47 stone
execute in minecraft:overworld run fill 396 63 -47 396 64 -47 dirt
execute in minecraft:overworld run setblock 396 65 -47 grass_block
execute in minecraft:overworld run fill 396 66 -47 396 144 -47 air
execute in minecraft:overworld run fill 396 58 -46 396 64 -46 stone
execute in minecraft:overworld run fill 396 65 -46 396 66 -46 dirt
execute in minecraft:overworld run setblock 396 67 -46 grass_block
execute in minecraft:overworld run fill 396 68 -46 396 144 -46 air
execute in minecraft:overworld run fill 396 58 -45 396 65 -45 stone
execute in minecraft:overworld run fill 396 66 -45 396 67 -45 dirt
execute in minecraft:overworld run setblock 396 68 -45 grass_block
execute in minecraft:overworld run fill 396 69 -45 396 144 -45 air
execute in minecraft:overworld run fill 396 58 -44 396 66 -44 stone
execute in minecraft:overworld run fill 396 67 -44 396 68 -44 dirt
execute in minecraft:overworld run setblock 396 69 -44 coarse_dirt
execute in minecraft:overworld run fill 396 70 -44 396 144 -44 air
execute in minecraft:overworld run fill 396 58 -43 396 67 -43 stone
execute in minecraft:overworld run fill 396 68 -43 396 69 -43 dirt
execute in minecraft:overworld run setblock 396 70 -43 grass_block
execute in minecraft:overworld run fill 396 71 -43 396 144 -43 air
execute in minecraft:overworld run fill 396 58 -42 396 69 -42 stone
execute in minecraft:overworld run fill 396 70 -42 396 71 -42 dirt
execute in minecraft:overworld run setblock 396 72 -42 coarse_dirt
execute in minecraft:overworld run fill 396 73 -42 396 144 -42 air
execute in minecraft:overworld run fill 396 58 -41 396 70 -41 stone
execute in minecraft:overworld run fill 396 71 -41 396 72 -41 dirt
execute in minecraft:overworld run setblock 396 73 -41 coarse_dirt
execute in minecraft:overworld run fill 396 74 -41 396 144 -41 air
execute in minecraft:overworld run fill 396 58 -40 396 71 -40 stone
execute in minecraft:overworld run fill 396 72 -40 396 73 -40 dirt
execute in minecraft:overworld run setblock 396 74 -40 coarse_dirt
execute in minecraft:overworld run fill 396 75 -40 396 144 -40 air
execute in minecraft:overworld run fill 396 58 -39 396 73 -39 stone
execute in minecraft:overworld run fill 396 74 -39 396 75 -39 dirt
execute in minecraft:overworld run setblock 396 76 -39 coarse_dirt
execute in minecraft:overworld run fill 396 77 -39 396 144 -39 air
execute in minecraft:overworld run fill 396 58 -38 396 74 -38 stone
execute in minecraft:overworld run fill 396 75 -38 396 76 -38 dirt
execute in minecraft:overworld run setblock 396 77 -38 coarse_dirt
execute in minecraft:overworld run fill 396 78 -38 396 144 -38 air
execute in minecraft:overworld run fill 396 58 -37 396 74 -37 stone
execute in minecraft:overworld run fill 396 75 -37 396 76 -37 dirt
execute in minecraft:overworld run setblock 396 77 -37 coarse_dirt
execute in minecraft:overworld run fill 396 78 -37 396 144 -37 air
execute in minecraft:overworld run fill 396 58 -36 396 74 -36 stone
execute in minecraft:overworld run fill 396 75 -36 396 76 -36 dirt
execute in minecraft:overworld run setblock 396 77 -36 coarse_dirt
execute in minecraft:overworld run fill 396 78 -36 396 144 -36 air
execute in minecraft:overworld run setblock 396 78 -36 grass
execute in minecraft:overworld run fill 396 58 -35 396 74 -35 stone
execute in minecraft:overworld run fill 396 75 -35 396 76 -35 dirt
execute in minecraft:overworld run setblock 396 77 -35 grass_block
execute in minecraft:overworld run fill 396 78 -35 396 144 -35 air
execute in minecraft:overworld run fill 396 58 -34 396 74 -34 stone
execute in minecraft:overworld run fill 396 75 -34 396 76 -34 dirt
execute in minecraft:overworld run setblock 396 77 -34 coarse_dirt
execute in minecraft:overworld run fill 396 78 -34 396 144 -34 air
execute in minecraft:overworld run setblock 396 78 -34 grass
execute in minecraft:overworld run fill 396 58 -33 396 73 -33 stone
execute in minecraft:overworld run fill 396 74 -33 396 75 -33 dirt
execute in minecraft:overworld run setblock 396 76 -33 coarse_dirt
execute in minecraft:overworld run fill 396 77 -33 396 144 -33 air
execute in minecraft:overworld run fill 396 58 -32 396 73 -32 stone
execute in minecraft:overworld run fill 396 74 -32 396 75 -32 dirt
execute in minecraft:overworld run setblock 396 76 -32 grass_block
execute in minecraft:overworld run fill 396 77 -32 396 144 -32 air
execute in minecraft:overworld run fill 396 58 -31 396 72 -31 stone
execute in minecraft:overworld run fill 396 73 -31 396 74 -31 dirt
execute in minecraft:overworld run setblock 396 75 -31 grass_block
execute in minecraft:overworld run fill 396 76 -31 396 144 -31 air
execute in minecraft:overworld run fill 396 58 -30 396 72 -30 stone
execute in minecraft:overworld run fill 396 73 -30 396 74 -30 dirt
execute in minecraft:overworld run setblock 396 75 -30 coarse_dirt
execute in minecraft:overworld run fill 396 76 -30 396 144 -30 air
execute in minecraft:overworld run fill 396 58 -29 396 71 -29 stone
execute in minecraft:overworld run fill 396 72 -29 396 73 -29 dirt
execute in minecraft:overworld run setblock 396 74 -29 coarse_dirt
execute in minecraft:overworld run fill 396 75 -29 396 144 -29 air
execute in minecraft:overworld run fill 396 58 -28 396 71 -28 stone
execute in minecraft:overworld run fill 396 72 -28 396 73 -28 dirt
execute in minecraft:overworld run setblock 396 74 -28 grass_block
execute in minecraft:overworld run fill 396 75 -28 396 144 -28 air
execute in minecraft:overworld run fill 396 58 -27 396 70 -27 stone
execute in minecraft:overworld run fill 396 71 -27 396 72 -27 dirt
execute in minecraft:overworld run setblock 396 73 -27 coarse_dirt
execute in minecraft:overworld run fill 396 74 -27 396 144 -27 air
execute in minecraft:overworld run fill 396 58 -26 396 70 -26 stone
execute in minecraft:overworld run fill 396 71 -26 396 72 -26 dirt
execute in minecraft:overworld run setblock 396 73 -26 coarse_dirt
execute in minecraft:overworld run fill 396 74 -26 396 144 -26 air
execute in minecraft:overworld run fill 396 58 -25 396 70 -25 stone
execute in minecraft:overworld run fill 396 71 -25 396 72 -25 dirt
execute in minecraft:overworld run setblock 396 73 -25 grass_block
execute in minecraft:overworld run fill 396 74 -25 396 144 -25 air
execute in minecraft:overworld run fill 396 58 -24 396 69 -24 stone
execute in minecraft:overworld run fill 396 70 -24 396 71 -24 dirt
execute in minecraft:overworld run setblock 396 72 -24 coarse_dirt
execute in minecraft:overworld run fill 396 73 -24 396 144 -24 air
execute in minecraft:overworld run fill 396 58 -23 396 69 -23 stone
execute in minecraft:overworld run fill 396 70 -23 396 71 -23 dirt
execute in minecraft:overworld run setblock 396 72 -23 coarse_dirt
execute in minecraft:overworld run fill 396 73 -23 396 144 -23 air
execute in minecraft:overworld run fill 396 58 -22 396 69 -22 stone
execute in minecraft:overworld run fill 396 70 -22 396 71 -22 dirt
execute in minecraft:overworld run setblock 396 72 -22 coarse_dirt
execute in minecraft:overworld run fill 396 73 -22 396 144 -22 air
execute in minecraft:overworld run fill 396 58 -21 396 68 -21 stone
execute in minecraft:overworld run fill 396 69 -21 396 70 -21 dirt
execute in minecraft:overworld run setblock 396 71 -21 coarse_dirt
execute in minecraft:overworld run fill 396 72 -21 396 144 -21 air
execute in minecraft:overworld run fill 396 58 -20 396 68 -20 stone
execute in minecraft:overworld run fill 396 69 -20 396 70 -20 dirt
execute in minecraft:overworld run setblock 396 71 -20 coarse_dirt
execute in minecraft:overworld run fill 396 72 -20 396 144 -20 air
execute in minecraft:overworld run fill 396 58 -19 396 67 -19 stone
execute in minecraft:overworld run fill 396 68 -19 396 69 -19 dirt
execute in minecraft:overworld run setblock 396 70 -19 grass_block
execute in minecraft:overworld run fill 396 71 -19 396 144 -19 air
execute in minecraft:overworld run fill 396 58 -18 396 66 -18 stone
execute in minecraft:overworld run fill 396 67 -18 396 68 -18 dirt
execute in minecraft:overworld run setblock 396 69 -18 grass_block
execute in minecraft:overworld run fill 396 70 -18 396 144 -18 air
execute in minecraft:overworld run fill 396 58 -17 396 65 -17 stone
execute in minecraft:overworld run fill 396 66 -17 396 67 -17 dirt
execute in minecraft:overworld run setblock 396 68 -17 coarse_dirt
execute in minecraft:overworld run fill 396 69 -17 396 144 -17 air
execute in minecraft:overworld run fill 396 58 -16 396 65 -16 stone
execute in minecraft:overworld run fill 396 66 -16 396 67 -16 dirt
execute in minecraft:overworld run setblock 396 68 -16 coarse_dirt
execute in minecraft:overworld run fill 396 69 -16 396 144 -16 air
execute in minecraft:overworld run fill 396 58 -15 396 64 -15 stone
execute in minecraft:overworld run fill 396 65 -15 396 66 -15 dirt
execute in minecraft:overworld run setblock 396 67 -15 grass_block
execute in minecraft:overworld run fill 396 68 -15 396 144 -15 air
execute in minecraft:overworld run fill 396 58 -14 396 63 -14 stone
execute in minecraft:overworld run fill 396 64 -14 396 65 -14 dirt
execute in minecraft:overworld run setblock 396 66 -14 grass_block
execute in minecraft:overworld run fill 396 67 -14 396 144 -14 air
execute in minecraft:overworld run fill 396 58 -13 396 62 -13 stone
execute in minecraft:overworld run fill 396 63 -13 396 64 -13 dirt
execute in minecraft:overworld run setblock 396 65 -13 coarse_dirt
execute in minecraft:overworld run fill 396 66 -13 396 144 -13 air
execute in minecraft:overworld run fill 396 58 -12 396 61 -12 stone
execute in minecraft:overworld run fill 396 62 -12 396 63 -12 dirt
execute in minecraft:overworld run setblock 396 64 -12 grass_block
execute in minecraft:overworld run fill 396 65 -12 396 144 -12 air
execute in minecraft:overworld run fill 396 58 -11 396 60 -11 stone
execute in minecraft:overworld run fill 396 61 -11 396 62 -11 dirt
execute in minecraft:overworld run setblock 396 63 -11 gravel
execute in minecraft:overworld run fill 396 64 -11 396 144 -11 air
execute in minecraft:overworld run fill 396 64 -11 396 64 -11 water
execute in minecraft:overworld run fill 396 58 -10 396 59 -10 stone
execute in minecraft:overworld run fill 396 60 -10 396 61 -10 dirt
execute in minecraft:overworld run setblock 396 62 -10 gravel
execute in minecraft:overworld run fill 396 63 -10 396 144 -10 air
execute in minecraft:overworld run fill 396 63 -10 396 64 -10 water
execute in minecraft:overworld run fill 396 58 -9 396 59 -9 stone
execute in minecraft:overworld run fill 396 60 -9 396 61 -9 dirt
execute in minecraft:overworld run setblock 396 62 -9 gravel
execute in minecraft:overworld run fill 396 63 -9 396 144 -9 air
execute in minecraft:overworld run fill 396 63 -9 396 64 -9 water
execute in minecraft:overworld run fill 396 58 -8 396 58 -8 stone
execute in minecraft:overworld run fill 396 59 -8 396 60 -8 dirt
execute in minecraft:overworld run setblock 396 61 -8 gravel
execute in minecraft:overworld run fill 396 62 -8 396 144 -8 air
execute in minecraft:overworld run fill 396 62 -8 396 64 -8 water
execute in minecraft:overworld run fill 396 58 -7 396 58 -7 stone
execute in minecraft:overworld run fill 396 59 -7 396 60 -7 dirt
execute in minecraft:overworld run setblock 396 61 -7 gravel
execute in minecraft:overworld run fill 396 62 -7 396 144 -7 air
execute in minecraft:overworld run fill 396 62 -7 396 64 -7 water
execute in minecraft:overworld run fill 396 58 -6 396 57 -6 stone
execute in minecraft:overworld run fill 396 58 -6 396 59 -6 dirt
execute in minecraft:overworld run setblock 396 60 -6 gravel
execute in minecraft:overworld run fill 396 61 -6 396 144 -6 air
execute in minecraft:overworld run fill 396 61 -6 396 64 -6 water
execute in minecraft:overworld run fill 396 58 -5 396 56 -5 stone
execute in minecraft:overworld run fill 396 57 -5 396 58 -5 dirt
execute in minecraft:overworld run setblock 396 59 -5 gravel
execute in minecraft:overworld run fill 396 60 -5 396 144 -5 air
execute in minecraft:overworld run fill 396 60 -5 396 64 -5 water
execute in minecraft:overworld run fill 396 58 -4 396 56 -4 stone
execute in minecraft:overworld run fill 396 57 -4 396 58 -4 dirt
execute in minecraft:overworld run setblock 396 59 -4 gravel
execute in minecraft:overworld run fill 396 60 -4 396 144 -4 air
execute in minecraft:overworld run fill 396 60 -4 396 64 -4 water
execute in minecraft:overworld run fill 396 58 -3 396 55 -3 stone
execute in minecraft:overworld run fill 396 56 -3 396 57 -3 dirt
execute in minecraft:overworld run setblock 396 58 -3 gravel
execute in minecraft:overworld run fill 396 59 -3 396 144 -3 air
execute in minecraft:overworld run fill 396 59 -3 396 64 -3 water
execute in minecraft:overworld run fill 396 58 -2 396 55 -2 stone
execute in minecraft:overworld run fill 396 56 -2 396 57 -2 dirt
execute in minecraft:overworld run setblock 396 58 -2 gravel
execute in minecraft:overworld run fill 396 59 -2 396 144 -2 air
execute in minecraft:overworld run fill 396 59 -2 396 64 -2 water
execute in minecraft:overworld run fill 396 58 -1 396 54 -1 stone
execute in minecraft:overworld run fill 396 55 -1 396 56 -1 dirt
execute in minecraft:overworld run setblock 396 57 -1 gravel
execute in minecraft:overworld run fill 396 58 -1 396 144 -1 air
execute in minecraft:overworld run fill 396 58 -1 396 64 -1 water
execute in minecraft:overworld run fill 396 58 0 396 54 0 stone
execute in minecraft:overworld run fill 396 55 0 396 56 0 dirt
execute in minecraft:overworld run setblock 396 57 0 gravel
execute in minecraft:overworld run fill 396 58 0 396 144 0 air
execute in minecraft:overworld run fill 396 58 0 396 64 0 water
execute in minecraft:overworld run fill 396 58 1 396 54 1 stone
execute in minecraft:overworld run fill 396 55 1 396 56 1 dirt
execute in minecraft:overworld run setblock 396 57 1 gravel
execute in minecraft:overworld run fill 396 58 1 396 144 1 air
execute in minecraft:overworld run fill 396 58 1 396 64 1 water
execute in minecraft:overworld run fill 396 58 2 396 54 2 stone
execute in minecraft:overworld run fill 396 55 2 396 56 2 dirt
execute in minecraft:overworld run setblock 396 57 2 gravel
execute in minecraft:overworld run fill 396 58 2 396 144 2 air
execute in minecraft:overworld run fill 396 58 2 396 64 2 water
execute in minecraft:overworld run fill 396 58 3 396 54 3 stone
execute in minecraft:overworld run fill 396 55 3 396 56 3 dirt
execute in minecraft:overworld run setblock 396 57 3 gravel
execute in minecraft:overworld run fill 396 58 3 396 144 3 air
execute in minecraft:overworld run fill 396 58 3 396 64 3 water
execute in minecraft:overworld run fill 396 58 4 396 54 4 stone
execute in minecraft:overworld run fill 396 55 4 396 56 4 dirt
execute in minecraft:overworld run setblock 396 57 4 gravel
execute in minecraft:overworld run fill 396 58 4 396 144 4 air
execute in minecraft:overworld run fill 396 58 4 396 64 4 water
execute in minecraft:overworld run fill 396 58 5 396 54 5 stone
schedule function blade_gallery:random/battlefield/part_95 1t replace
