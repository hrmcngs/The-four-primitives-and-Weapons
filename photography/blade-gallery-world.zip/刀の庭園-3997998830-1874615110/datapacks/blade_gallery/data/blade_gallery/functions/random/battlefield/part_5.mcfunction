execute in minecraft:overworld run setblock 339 67 -17 coarse_dirt
execute in minecraft:overworld run fill 339 68 -17 339 144 -17 air
execute in minecraft:overworld run fill 339 58 -16 339 64 -16 stone
execute in minecraft:overworld run fill 339 65 -16 339 66 -16 dirt
execute in minecraft:overworld run setblock 339 67 -16 coarse_dirt
execute in minecraft:overworld run fill 339 68 -16 339 144 -16 air
execute in minecraft:overworld run fill 339 58 -15 339 63 -15 stone
execute in minecraft:overworld run fill 339 64 -15 339 65 -15 dirt
execute in minecraft:overworld run setblock 339 66 -15 coarse_dirt
execute in minecraft:overworld run fill 339 67 -15 339 144 -15 air
execute in minecraft:overworld run fill 339 58 -14 339 63 -14 stone
execute in minecraft:overworld run fill 339 64 -14 339 65 -14 dirt
execute in minecraft:overworld run setblock 339 66 -14 coarse_dirt
execute in minecraft:overworld run fill 339 67 -14 339 144 -14 air
execute in minecraft:overworld run fill 339 58 -13 339 63 -13 stone
execute in minecraft:overworld run fill 339 64 -13 339 65 -13 dirt
execute in minecraft:overworld run setblock 339 66 -13 coarse_dirt
execute in minecraft:overworld run fill 339 67 -13 339 144 -13 air
execute in minecraft:overworld run fill 339 58 -12 339 63 -12 stone
execute in minecraft:overworld run fill 339 64 -12 339 65 -12 dirt
execute in minecraft:overworld run setblock 339 66 -12 coarse_dirt
execute in minecraft:overworld run fill 339 67 -12 339 144 -12 air
execute in minecraft:overworld run fill 339 58 -11 339 63 -11 stone
execute in minecraft:overworld run fill 339 64 -11 339 65 -11 dirt
execute in minecraft:overworld run setblock 339 66 -11 coarse_dirt
execute in minecraft:overworld run fill 339 67 -11 339 144 -11 air
execute in minecraft:overworld run fill 339 58 -10 339 63 -10 stone
execute in minecraft:overworld run fill 339 64 -10 339 65 -10 dirt
execute in minecraft:overworld run setblock 339 66 -10 grass_block
execute in minecraft:overworld run fill 339 67 -10 339 144 -10 air
execute in minecraft:overworld run fill 339 58 -9 339 63 -9 stone
execute in minecraft:overworld run fill 339 64 -9 339 65 -9 dirt
execute in minecraft:overworld run setblock 339 66 -9 coarse_dirt
execute in minecraft:overworld run fill 339 67 -9 339 144 -9 air
execute in minecraft:overworld run fill 339 58 -8 339 63 -8 stone
execute in minecraft:overworld run fill 339 64 -8 339 65 -8 dirt
execute in minecraft:overworld run setblock 339 66 -8 coarse_dirt
execute in minecraft:overworld run fill 339 67 -8 339 144 -8 air
execute in minecraft:overworld run fill 339 58 -7 339 63 -7 stone
execute in minecraft:overworld run fill 339 64 -7 339 65 -7 dirt
execute in minecraft:overworld run setblock 339 66 -7 coarse_dirt
execute in minecraft:overworld run fill 339 67 -7 339 144 -7 air
execute in minecraft:overworld run fill 339 58 -6 339 63 -6 stone
execute in minecraft:overworld run fill 339 64 -6 339 65 -6 dirt
execute in minecraft:overworld run setblock 339 66 -6 coarse_dirt
execute in minecraft:overworld run fill 339 67 -6 339 144 -6 air
execute in minecraft:overworld run fill 339 58 -5 339 63 -5 stone
execute in minecraft:overworld run fill 339 64 -5 339 65 -5 dirt
execute in minecraft:overworld run setblock 339 66 -5 coarse_dirt
execute in minecraft:overworld run fill 339 67 -5 339 144 -5 air
execute in minecraft:overworld run fill 339 58 -4 339 63 -4 stone
execute in minecraft:overworld run fill 339 64 -4 339 65 -4 dirt
execute in minecraft:overworld run setblock 339 66 -4 grass_block
execute in minecraft:overworld run fill 339 67 -4 339 144 -4 air
execute in minecraft:overworld run fill 339 58 -3 339 63 -3 stone
execute in minecraft:overworld run fill 339 64 -3 339 65 -3 dirt
execute in minecraft:overworld run setblock 339 66 -3 grass_block
execute in minecraft:overworld run fill 339 67 -3 339 144 -3 air
execute in minecraft:overworld run fill 339 58 -2 339 63 -2 stone
execute in minecraft:overworld run fill 339 64 -2 339 65 -2 dirt
execute in minecraft:overworld run setblock 339 66 -2 grass_block
execute in minecraft:overworld run fill 339 67 -2 339 144 -2 air
execute in minecraft:overworld run fill 339 58 -1 339 63 -1 stone
execute in minecraft:overworld run fill 339 64 -1 339 65 -1 dirt
execute in minecraft:overworld run setblock 339 66 -1 grass_block
execute in minecraft:overworld run fill 339 67 -1 339 144 -1 air
execute in minecraft:overworld run fill 339 58 0 339 63 0 stone
execute in minecraft:overworld run fill 339 64 0 339 65 0 dirt
execute in minecraft:overworld run setblock 339 66 0 coarse_dirt
execute in minecraft:overworld run fill 339 67 0 339 144 0 air
execute in minecraft:overworld run fill 339 58 1 339 63 1 stone
execute in minecraft:overworld run fill 339 64 1 339 65 1 dirt
execute in minecraft:overworld run setblock 339 66 1 coarse_dirt
execute in minecraft:overworld run fill 339 67 1 339 144 1 air
execute in minecraft:overworld run fill 339 58 2 339 63 2 stone
execute in minecraft:overworld run fill 339 64 2 339 65 2 dirt
execute in minecraft:overworld run setblock 339 66 2 coarse_dirt
execute in minecraft:overworld run fill 339 67 2 339 144 2 air
execute in minecraft:overworld run fill 339 58 3 339 63 3 stone
execute in minecraft:overworld run fill 339 64 3 339 65 3 dirt
execute in minecraft:overworld run setblock 339 66 3 grass_block
execute in minecraft:overworld run fill 339 67 3 339 144 3 air
execute in minecraft:overworld run fill 339 58 4 339 63 4 stone
execute in minecraft:overworld run fill 339 64 4 339 65 4 dirt
execute in minecraft:overworld run setblock 339 66 4 grass_block
execute in minecraft:overworld run fill 339 67 4 339 144 4 air
execute in minecraft:overworld run fill 339 58 5 339 63 5 stone
execute in minecraft:overworld run fill 339 64 5 339 65 5 dirt
execute in minecraft:overworld run setblock 339 66 5 coarse_dirt
execute in minecraft:overworld run fill 339 67 5 339 144 5 air
execute in minecraft:overworld run fill 339 58 6 339 63 6 stone
execute in minecraft:overworld run fill 339 64 6 339 65 6 dirt
execute in minecraft:overworld run setblock 339 66 6 grass_block
execute in minecraft:overworld run fill 339 67 6 339 144 6 air
execute in minecraft:overworld run fill 339 58 7 339 63 7 stone
execute in minecraft:overworld run fill 339 64 7 339 65 7 dirt
execute in minecraft:overworld run setblock 339 66 7 coarse_dirt
execute in minecraft:overworld run fill 339 67 7 339 144 7 air
execute in minecraft:overworld run fill 339 58 8 339 63 8 stone
execute in minecraft:overworld run fill 339 64 8 339 65 8 dirt
execute in minecraft:overworld run setblock 339 66 8 coarse_dirt
execute in minecraft:overworld run fill 339 67 8 339 144 8 air
execute in minecraft:overworld run fill 339 58 9 339 63 9 stone
execute in minecraft:overworld run fill 339 64 9 339 65 9 dirt
execute in minecraft:overworld run setblock 339 66 9 coarse_dirt
execute in minecraft:overworld run fill 339 67 9 339 144 9 air
execute in minecraft:overworld run fill 339 58 10 339 63 10 stone
execute in minecraft:overworld run fill 339 64 10 339 65 10 dirt
execute in minecraft:overworld run setblock 339 66 10 grass_block
execute in minecraft:overworld run fill 339 67 10 339 144 10 air
execute in minecraft:overworld run fill 339 58 11 339 62 11 stone
execute in minecraft:overworld run fill 339 63 11 339 64 11 dirt
execute in minecraft:overworld run setblock 339 65 11 coarse_dirt
execute in minecraft:overworld run fill 339 66 11 339 144 11 air
execute in minecraft:overworld run fill 339 58 12 339 62 12 stone
execute in minecraft:overworld run fill 339 63 12 339 64 12 dirt
execute in minecraft:overworld run setblock 339 65 12 coarse_dirt
execute in minecraft:overworld run fill 339 66 12 339 144 12 air
execute in minecraft:overworld run fill 339 58 13 339 62 13 stone
execute in minecraft:overworld run fill 339 63 13 339 64 13 dirt
execute in minecraft:overworld run setblock 339 65 13 coarse_dirt
execute in minecraft:overworld run fill 339 66 13 339 144 13 air
execute in minecraft:overworld run fill 339 58 14 339 62 14 stone
execute in minecraft:overworld run fill 339 63 14 339 64 14 dirt
execute in minecraft:overworld run setblock 339 65 14 grass_block
execute in minecraft:overworld run fill 339 66 14 339 144 14 air
execute in minecraft:overworld run fill 339 58 15 339 62 15 stone
execute in minecraft:overworld run fill 339 63 15 339 64 15 dirt
execute in minecraft:overworld run setblock 339 65 15 coarse_dirt
execute in minecraft:overworld run fill 339 66 15 339 144 15 air
execute in minecraft:overworld run fill 339 58 16 339 62 16 stone
execute in minecraft:overworld run fill 339 63 16 339 64 16 dirt
execute in minecraft:overworld run setblock 339 65 16 grass_block
execute in minecraft:overworld run fill 339 66 16 339 144 16 air
execute in minecraft:overworld run fill 339 58 17 339 62 17 stone
execute in minecraft:overworld run fill 339 63 17 339 64 17 dirt
execute in minecraft:overworld run setblock 339 65 17 coarse_dirt
execute in minecraft:overworld run fill 339 66 17 339 144 17 air
execute in minecraft:overworld run fill 339 58 18 339 62 18 stone
execute in minecraft:overworld run fill 339 63 18 339 64 18 dirt
execute in minecraft:overworld run setblock 339 65 18 coarse_dirt
execute in minecraft:overworld run fill 339 66 18 339 144 18 air
execute in minecraft:overworld run fill 339 58 19 339 62 19 stone
execute in minecraft:overworld run fill 339 63 19 339 64 19 dirt
execute in minecraft:overworld run setblock 339 65 19 grass_block
execute in minecraft:overworld run fill 339 66 19 339 144 19 air
execute in minecraft:overworld run fill 339 58 20 339 62 20 stone
execute in minecraft:overworld run fill 339 63 20 339 64 20 dirt
execute in minecraft:overworld run setblock 339 65 20 coarse_dirt
execute in minecraft:overworld run fill 339 66 20 339 144 20 air
execute in minecraft:overworld run fill 339 58 21 339 62 21 stone
execute in minecraft:overworld run fill 339 63 21 339 64 21 dirt
execute in minecraft:overworld run setblock 339 65 21 coarse_dirt
execute in minecraft:overworld run fill 339 66 21 339 144 21 air
execute in minecraft:overworld run fill 339 58 22 339 62 22 stone
execute in minecraft:overworld run fill 339 63 22 339 64 22 dirt
execute in minecraft:overworld run setblock 339 65 22 coarse_dirt
execute in minecraft:overworld run fill 339 66 22 339 144 22 air
execute in minecraft:overworld run fill 339 58 23 339 62 23 stone
execute in minecraft:overworld run fill 339 63 23 339 64 23 dirt
execute in minecraft:overworld run setblock 339 65 23 coarse_dirt
execute in minecraft:overworld run fill 339 66 23 339 144 23 air
execute in minecraft:overworld run fill 339 58 24 339 62 24 stone
execute in minecraft:overworld run fill 339 63 24 339 64 24 dirt
execute in minecraft:overworld run setblock 339 65 24 coarse_dirt
execute in minecraft:overworld run fill 339 66 24 339 144 24 air
execute in minecraft:overworld run fill 339 58 25 339 62 25 stone
execute in minecraft:overworld run fill 339 63 25 339 64 25 dirt
execute in minecraft:overworld run setblock 339 65 25 grass_block
execute in minecraft:overworld run fill 339 66 25 339 144 25 air
execute in minecraft:overworld run fill 339 58 26 339 62 26 stone
execute in minecraft:overworld run fill 339 63 26 339 64 26 dirt
execute in minecraft:overworld run setblock 339 65 26 coarse_dirt
execute in minecraft:overworld run fill 339 66 26 339 144 26 air
execute in minecraft:overworld run fill 339 58 27 339 62 27 stone
execute in minecraft:overworld run fill 339 63 27 339 64 27 dirt
execute in minecraft:overworld run setblock 339 65 27 coarse_dirt
execute in minecraft:overworld run fill 339 66 27 339 144 27 air
execute in minecraft:overworld run fill 339 58 28 339 62 28 stone
execute in minecraft:overworld run fill 339 63 28 339 64 28 dirt
execute in minecraft:overworld run setblock 339 65 28 coarse_dirt
execute in minecraft:overworld run fill 339 66 28 339 144 28 air
execute in minecraft:overworld run fill 339 58 29 339 62 29 stone
execute in minecraft:overworld run fill 339 63 29 339 64 29 dirt
execute in minecraft:overworld run setblock 339 65 29 coarse_dirt
execute in minecraft:overworld run fill 339 66 29 339 144 29 air
execute in minecraft:overworld run fill 339 58 30 339 62 30 stone
execute in minecraft:overworld run fill 339 63 30 339 64 30 dirt
execute in minecraft:overworld run setblock 339 65 30 grass_block
execute in minecraft:overworld run fill 339 66 30 339 144 30 air
execute in minecraft:overworld run fill 339 58 31 339 62 31 stone
execute in minecraft:overworld run fill 339 63 31 339 64 31 dirt
execute in minecraft:overworld run setblock 339 65 31 coarse_dirt
execute in minecraft:overworld run fill 339 66 31 339 144 31 air
execute in minecraft:overworld run fill 339 58 32 339 62 32 stone
execute in minecraft:overworld run fill 339 63 32 339 64 32 dirt
execute in minecraft:overworld run setblock 339 65 32 coarse_dirt
execute in minecraft:overworld run fill 339 66 32 339 144 32 air
execute in minecraft:overworld run fill 339 58 33 339 62 33 stone
execute in minecraft:overworld run fill 339 63 33 339 64 33 dirt
execute in minecraft:overworld run setblock 339 65 33 grass_block
execute in minecraft:overworld run fill 339 66 33 339 144 33 air
execute in minecraft:overworld run fill 339 58 34 339 62 34 stone
execute in minecraft:overworld run fill 339 63 34 339 64 34 dirt
execute in minecraft:overworld run setblock 339 65 34 grass_block
execute in minecraft:overworld run fill 339 66 34 339 144 34 air
execute in minecraft:overworld run fill 339 58 35 339 62 35 stone
execute in minecraft:overworld run fill 339 63 35 339 64 35 dirt
execute in minecraft:overworld run setblock 339 65 35 coarse_dirt
execute in minecraft:overworld run fill 339 66 35 339 144 35 air
execute in minecraft:overworld run fill 339 58 36 339 62 36 stone
execute in minecraft:overworld run fill 339 63 36 339 64 36 dirt
execute in minecraft:overworld run setblock 339 65 36 coarse_dirt
execute in minecraft:overworld run fill 339 66 36 339 144 36 air
execute in minecraft:overworld run fill 339 58 37 339 62 37 stone
execute in minecraft:overworld run fill 339 63 37 339 64 37 dirt
execute in minecraft:overworld run setblock 339 65 37 coarse_dirt
execute in minecraft:overworld run fill 339 66 37 339 144 37 air
execute in minecraft:overworld run fill 339 58 38 339 62 38 stone
execute in minecraft:overworld run fill 339 63 38 339 64 38 dirt
execute in minecraft:overworld run setblock 339 65 38 grass_block
execute in minecraft:overworld run fill 339 66 38 339 144 38 air
execute in minecraft:overworld run fill 339 58 39 339 62 39 stone
execute in minecraft:overworld run fill 339 63 39 339 64 39 dirt
execute in minecraft:overworld run setblock 339 65 39 coarse_dirt
execute in minecraft:overworld run fill 339 66 39 339 144 39 air
execute in minecraft:overworld run fill 339 58 40 339 62 40 stone
execute in minecraft:overworld run fill 339 63 40 339 64 40 dirt
execute in minecraft:overworld run setblock 339 65 40 coarse_dirt
execute in minecraft:overworld run fill 339 66 40 339 144 40 air
execute in minecraft:overworld run fill 339 58 41 339 62 41 stone
execute in minecraft:overworld run fill 339 63 41 339 64 41 dirt
execute in minecraft:overworld run setblock 339 65 41 coarse_dirt
execute in minecraft:overworld run fill 339 66 41 339 144 41 air
execute in minecraft:overworld run fill 339 58 42 339 62 42 stone
execute in minecraft:overworld run fill 339 63 42 339 64 42 dirt
execute in minecraft:overworld run setblock 339 65 42 coarse_dirt
execute in minecraft:overworld run fill 339 66 42 339 144 42 air
execute in minecraft:overworld run fill 339 58 43 339 62 43 stone
execute in minecraft:overworld run fill 339 63 43 339 64 43 dirt
execute in minecraft:overworld run setblock 339 65 43 coarse_dirt
execute in minecraft:overworld run fill 339 66 43 339 144 43 air
execute in minecraft:overworld run fill 339 58 44 339 62 44 stone
execute in minecraft:overworld run fill 339 63 44 339 64 44 dirt
execute in minecraft:overworld run setblock 339 65 44 coarse_dirt
execute in minecraft:overworld run fill 339 66 44 339 144 44 air
execute in minecraft:overworld run fill 339 58 45 339 62 45 stone
execute in minecraft:overworld run fill 339 63 45 339 64 45 dirt
execute in minecraft:overworld run setblock 339 65 45 grass_block
execute in minecraft:overworld run fill 339 66 45 339 144 45 air
execute in minecraft:overworld run fill 339 58 46 339 62 46 stone
execute in minecraft:overworld run fill 339 63 46 339 64 46 dirt
execute in minecraft:overworld run setblock 339 65 46 coarse_dirt
execute in minecraft:overworld run fill 339 66 46 339 144 46 air
execute in minecraft:overworld run fill 339 58 47 339 61 47 stone
execute in minecraft:overworld run fill 339 62 47 339 63 47 dirt
schedule function blade_gallery:random/battlefield/part_6 1t replace
