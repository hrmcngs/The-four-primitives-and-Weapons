execute in minecraft:overworld run fill 255 63 40 255 144 40 air
execute in minecraft:overworld run fill 255 63 40 255 64 40 water
execute in minecraft:overworld run fill 255 58 41 255 59 41 stone
execute in minecraft:overworld run fill 255 60 41 255 61 41 dirt
execute in minecraft:overworld run setblock 255 62 41 gravel
execute in minecraft:overworld run fill 255 63 41 255 144 41 air
execute in minecraft:overworld run fill 255 63 41 255 64 41 water
execute in minecraft:overworld run fill 255 58 42 255 59 42 stone
execute in minecraft:overworld run fill 255 60 42 255 61 42 dirt
execute in minecraft:overworld run setblock 255 62 42 gravel
execute in minecraft:overworld run fill 255 63 42 255 144 42 air
execute in minecraft:overworld run fill 255 63 42 255 64 42 water
execute in minecraft:overworld run fill 255 58 43 255 59 43 stone
execute in minecraft:overworld run fill 255 60 43 255 61 43 dirt
execute in minecraft:overworld run setblock 255 62 43 gravel
execute in minecraft:overworld run fill 255 63 43 255 144 43 air
execute in minecraft:overworld run fill 255 63 43 255 64 43 water
execute in minecraft:overworld run fill 255 58 44 255 59 44 stone
execute in minecraft:overworld run fill 255 60 44 255 61 44 dirt
execute in minecraft:overworld run setblock 255 62 44 gravel
execute in minecraft:overworld run fill 255 63 44 255 144 44 air
execute in minecraft:overworld run fill 255 63 44 255 64 44 water
execute in minecraft:overworld run fill 255 58 45 255 59 45 stone
execute in minecraft:overworld run fill 255 60 45 255 61 45 dirt
execute in minecraft:overworld run setblock 255 62 45 gravel
execute in minecraft:overworld run fill 255 63 45 255 144 45 air
execute in minecraft:overworld run fill 255 63 45 255 64 45 water
execute in minecraft:overworld run fill 255 58 46 255 60 46 stone
execute in minecraft:overworld run fill 255 61 46 255 62 46 dirt
execute in minecraft:overworld run setblock 255 63 46 gravel
execute in minecraft:overworld run fill 255 64 46 255 144 46 air
execute in minecraft:overworld run fill 255 64 46 255 64 46 water
execute in minecraft:overworld run fill 255 58 47 255 60 47 stone
execute in minecraft:overworld run fill 255 61 47 255 62 47 dirt
execute in minecraft:overworld run setblock 255 63 47 gravel
execute in minecraft:overworld run fill 255 64 47 255 144 47 air
execute in minecraft:overworld run fill 255 64 47 255 64 47 water
execute in minecraft:overworld run fill 256 58 -48 256 61 -48 stone
execute in minecraft:overworld run fill 256 62 -48 256 63 -48 dirt
execute in minecraft:overworld run setblock 256 64 -48 coarse_dirt
execute in minecraft:overworld run fill 256 65 -48 256 144 -48 air
execute in minecraft:overworld run fill 256 58 -47 256 62 -47 stone
execute in minecraft:overworld run fill 256 63 -47 256 64 -47 dirt
execute in minecraft:overworld run setblock 256 65 -47 coarse_dirt
execute in minecraft:overworld run fill 256 66 -47 256 144 -47 air
execute in minecraft:overworld run fill 256 58 -46 256 64 -46 stone
execute in minecraft:overworld run fill 256 65 -46 256 66 -46 dirt
execute in minecraft:overworld run setblock 256 67 -46 coarse_dirt
execute in minecraft:overworld run fill 256 68 -46 256 144 -46 air
execute in minecraft:overworld run fill 256 58 -45 256 65 -45 stone
execute in minecraft:overworld run fill 256 66 -45 256 67 -45 dirt
execute in minecraft:overworld run setblock 256 68 -45 coarse_dirt
execute in minecraft:overworld run fill 256 69 -45 256 144 -45 air
execute in minecraft:overworld run fill 256 58 -44 256 67 -44 stone
execute in minecraft:overworld run fill 256 68 -44 256 69 -44 dirt
execute in minecraft:overworld run setblock 256 70 -44 grass_block
execute in minecraft:overworld run fill 256 71 -44 256 144 -44 air
execute in minecraft:overworld run fill 256 58 -43 256 68 -43 stone
execute in minecraft:overworld run fill 256 69 -43 256 70 -43 dirt
execute in minecraft:overworld run setblock 256 71 -43 coarse_dirt
execute in minecraft:overworld run fill 256 72 -43 256 144 -43 air
execute in minecraft:overworld run fill 256 58 -42 256 69 -42 stone
execute in minecraft:overworld run fill 256 70 -42 256 71 -42 dirt
execute in minecraft:overworld run setblock 256 72 -42 grass_block
execute in minecraft:overworld run fill 256 73 -42 256 144 -42 air
execute in minecraft:overworld run fill 256 58 -41 256 71 -41 stone
execute in minecraft:overworld run fill 256 72 -41 256 73 -41 dirt
execute in minecraft:overworld run setblock 256 74 -41 coarse_dirt
execute in minecraft:overworld run fill 256 75 -41 256 144 -41 air
execute in minecraft:overworld run fill 256 58 -40 256 72 -40 stone
execute in minecraft:overworld run fill 256 73 -40 256 74 -40 dirt
execute in minecraft:overworld run setblock 256 75 -40 grass_block
execute in minecraft:overworld run fill 256 76 -40 256 144 -40 air
execute in minecraft:overworld run fill 256 58 -39 256 73 -39 stone
execute in minecraft:overworld run fill 256 74 -39 256 75 -39 dirt
execute in minecraft:overworld run setblock 256 76 -39 grass_block
execute in minecraft:overworld run fill 256 77 -39 256 144 -39 air
execute in minecraft:overworld run fill 256 58 -38 256 74 -38 stone
execute in minecraft:overworld run fill 256 75 -38 256 76 -38 dirt
execute in minecraft:overworld run setblock 256 77 -38 grass_block
execute in minecraft:overworld run fill 256 78 -38 256 144 -38 air
execute in minecraft:overworld run fill 256 58 -37 256 74 -37 stone
execute in minecraft:overworld run fill 256 75 -37 256 76 -37 dirt
execute in minecraft:overworld run setblock 256 77 -37 grass_block
execute in minecraft:overworld run fill 256 78 -37 256 144 -37 air
execute in minecraft:overworld run fill 256 58 -36 256 73 -36 stone
execute in minecraft:overworld run fill 256 74 -36 256 75 -36 dirt
execute in minecraft:overworld run setblock 256 76 -36 grass_block
execute in minecraft:overworld run fill 256 77 -36 256 144 -36 air
execute in minecraft:overworld run fill 256 58 -35 256 73 -35 stone
execute in minecraft:overworld run fill 256 74 -35 256 75 -35 dirt
execute in minecraft:overworld run setblock 256 76 -35 grass_block
execute in minecraft:overworld run fill 256 77 -35 256 144 -35 air
execute in minecraft:overworld run fill 256 58 -34 256 72 -34 stone
execute in minecraft:overworld run fill 256 73 -34 256 74 -34 dirt
execute in minecraft:overworld run setblock 256 75 -34 coarse_dirt
execute in minecraft:overworld run fill 256 76 -34 256 144 -34 air
execute in minecraft:overworld run fill 256 58 -33 256 72 -33 stone
execute in minecraft:overworld run fill 256 73 -33 256 74 -33 dirt
execute in minecraft:overworld run setblock 256 75 -33 coarse_dirt
execute in minecraft:overworld run fill 256 76 -33 256 144 -33 air
execute in minecraft:overworld run fill 256 58 -32 256 71 -32 stone
execute in minecraft:overworld run fill 256 72 -32 256 73 -32 dirt
execute in minecraft:overworld run setblock 256 74 -32 grass_block
execute in minecraft:overworld run fill 256 75 -32 256 144 -32 air
execute in minecraft:overworld run fill 256 58 -31 256 71 -31 stone
execute in minecraft:overworld run fill 256 72 -31 256 73 -31 dirt
execute in minecraft:overworld run setblock 256 74 -31 grass_block
execute in minecraft:overworld run fill 256 75 -31 256 144 -31 air
execute in minecraft:overworld run fill 256 58 -30 256 70 -30 stone
execute in minecraft:overworld run fill 256 71 -30 256 72 -30 dirt
execute in minecraft:overworld run setblock 256 73 -30 coarse_dirt
execute in minecraft:overworld run fill 256 74 -30 256 144 -30 air
execute in minecraft:overworld run fill 256 58 -29 256 70 -29 stone
execute in minecraft:overworld run fill 256 71 -29 256 72 -29 dirt
execute in minecraft:overworld run setblock 256 73 -29 grass_block
execute in minecraft:overworld run fill 256 74 -29 256 144 -29 air
execute in minecraft:overworld run fill 256 58 -28 256 69 -28 stone
execute in minecraft:overworld run fill 256 70 -28 256 71 -28 dirt
execute in minecraft:overworld run setblock 256 72 -28 grass_block
execute in minecraft:overworld run fill 256 73 -28 256 144 -28 air
execute in minecraft:overworld run fill 256 58 -27 256 69 -27 stone
execute in minecraft:overworld run fill 256 70 -27 256 71 -27 dirt
execute in minecraft:overworld run setblock 256 72 -27 coarse_dirt
execute in minecraft:overworld run fill 256 73 -27 256 144 -27 air
execute in minecraft:overworld run fill 256 58 -26 256 68 -26 stone
execute in minecraft:overworld run fill 256 69 -26 256 70 -26 dirt
execute in minecraft:overworld run setblock 256 71 -26 coarse_dirt
execute in minecraft:overworld run fill 256 72 -26 256 144 -26 air
execute in minecraft:overworld run fill 256 58 -25 256 67 -25 stone
execute in minecraft:overworld run fill 256 68 -25 256 69 -25 dirt
execute in minecraft:overworld run setblock 256 70 -25 coarse_dirt
execute in minecraft:overworld run fill 256 71 -25 256 144 -25 air
execute in minecraft:overworld run fill 256 58 -24 256 66 -24 stone
execute in minecraft:overworld run fill 256 67 -24 256 68 -24 dirt
execute in minecraft:overworld run setblock 256 69 -24 coarse_dirt
execute in minecraft:overworld run fill 256 70 -24 256 144 -24 air
execute in minecraft:overworld run fill 256 58 -23 256 65 -23 stone
execute in minecraft:overworld run fill 256 66 -23 256 67 -23 dirt
execute in minecraft:overworld run setblock 256 68 -23 coarse_dirt
execute in minecraft:overworld run fill 256 69 -23 256 144 -23 air
execute in minecraft:overworld run setblock 256 69 -23 grass
execute in minecraft:overworld run fill 256 58 -22 256 64 -22 stone
execute in minecraft:overworld run fill 256 65 -22 256 66 -22 dirt
execute in minecraft:overworld run setblock 256 67 -22 coarse_dirt
execute in minecraft:overworld run fill 256 68 -22 256 144 -22 air
execute in minecraft:overworld run fill 256 58 -21 256 63 -21 stone
execute in minecraft:overworld run fill 256 64 -21 256 65 -21 dirt
execute in minecraft:overworld run setblock 256 66 -21 coarse_dirt
execute in minecraft:overworld run fill 256 67 -21 256 144 -21 air
execute in minecraft:overworld run fill 256 58 -20 256 63 -20 stone
execute in minecraft:overworld run fill 256 64 -20 256 65 -20 dirt
execute in minecraft:overworld run setblock 256 66 -20 coarse_dirt
execute in minecraft:overworld run fill 256 67 -20 256 144 -20 air
execute in minecraft:overworld run fill 256 58 -19 256 62 -19 stone
execute in minecraft:overworld run fill 256 63 -19 256 64 -19 dirt
execute in minecraft:overworld run setblock 256 65 -19 coarse_dirt
execute in minecraft:overworld run fill 256 66 -19 256 144 -19 air
execute in minecraft:overworld run fill 256 58 -18 256 61 -18 stone
execute in minecraft:overworld run fill 256 62 -18 256 63 -18 dirt
execute in minecraft:overworld run setblock 256 64 -18 coarse_dirt
execute in minecraft:overworld run fill 256 65 -18 256 144 -18 air
execute in minecraft:overworld run fill 256 58 -17 256 61 -17 stone
execute in minecraft:overworld run fill 256 62 -17 256 63 -17 dirt
execute in minecraft:overworld run setblock 256 64 -17 coarse_dirt
execute in minecraft:overworld run fill 256 65 -17 256 144 -17 air
execute in minecraft:overworld run fill 256 58 -16 256 60 -16 stone
execute in minecraft:overworld run fill 256 61 -16 256 62 -16 dirt
execute in minecraft:overworld run setblock 256 63 -16 gravel
execute in minecraft:overworld run fill 256 64 -16 256 144 -16 air
execute in minecraft:overworld run fill 256 64 -16 256 64 -16 water
execute in minecraft:overworld run fill 256 58 -15 256 60 -15 stone
execute in minecraft:overworld run fill 256 61 -15 256 62 -15 dirt
execute in minecraft:overworld run setblock 256 63 -15 gravel
execute in minecraft:overworld run fill 256 64 -15 256 144 -15 air
execute in minecraft:overworld run fill 256 64 -15 256 64 -15 water
execute in minecraft:overworld run fill 256 58 -14 256 60 -14 stone
execute in minecraft:overworld run fill 256 61 -14 256 62 -14 dirt
execute in minecraft:overworld run setblock 256 63 -14 gravel
execute in minecraft:overworld run fill 256 64 -14 256 144 -14 air
execute in minecraft:overworld run fill 256 64 -14 256 64 -14 water
execute in minecraft:overworld run fill 256 58 -13 256 59 -13 stone
execute in minecraft:overworld run fill 256 60 -13 256 61 -13 dirt
execute in minecraft:overworld run setblock 256 62 -13 gravel
execute in minecraft:overworld run fill 256 63 -13 256 144 -13 air
execute in minecraft:overworld run fill 256 63 -13 256 64 -13 water
execute in minecraft:overworld run fill 256 58 -12 256 59 -12 stone
execute in minecraft:overworld run fill 256 60 -12 256 61 -12 dirt
execute in minecraft:overworld run setblock 256 62 -12 gravel
execute in minecraft:overworld run fill 256 63 -12 256 144 -12 air
execute in minecraft:overworld run fill 256 63 -12 256 64 -12 water
execute in minecraft:overworld run fill 256 58 -11 256 59 -11 stone
execute in minecraft:overworld run fill 256 60 -11 256 61 -11 dirt
execute in minecraft:overworld run setblock 256 62 -11 gravel
execute in minecraft:overworld run fill 256 63 -11 256 144 -11 air
execute in minecraft:overworld run fill 256 63 -11 256 64 -11 water
execute in minecraft:overworld run fill 256 58 -10 256 59 -10 stone
execute in minecraft:overworld run fill 256 60 -10 256 61 -10 dirt
execute in minecraft:overworld run setblock 256 62 -10 gravel
execute in minecraft:overworld run fill 256 63 -10 256 144 -10 air
execute in minecraft:overworld run fill 256 63 -10 256 64 -10 water
execute in minecraft:overworld run fill 256 58 -9 256 59 -9 stone
execute in minecraft:overworld run fill 256 60 -9 256 61 -9 dirt
execute in minecraft:overworld run setblock 256 62 -9 gravel
execute in minecraft:overworld run fill 256 63 -9 256 144 -9 air
execute in minecraft:overworld run fill 256 63 -9 256 64 -9 water
execute in minecraft:overworld run fill 256 58 -8 256 59 -8 stone
execute in minecraft:overworld run fill 256 60 -8 256 61 -8 dirt
execute in minecraft:overworld run setblock 256 62 -8 gravel
execute in minecraft:overworld run fill 256 63 -8 256 144 -8 air
execute in minecraft:overworld run fill 256 63 -8 256 64 -8 water
execute in minecraft:overworld run fill 256 58 -7 256 59 -7 stone
execute in minecraft:overworld run fill 256 60 -7 256 61 -7 dirt
execute in minecraft:overworld run setblock 256 62 -7 gravel
execute in minecraft:overworld run fill 256 63 -7 256 144 -7 air
execute in minecraft:overworld run fill 256 63 -7 256 64 -7 water
execute in minecraft:overworld run fill 256 58 -6 256 58 -6 stone
execute in minecraft:overworld run fill 256 59 -6 256 60 -6 dirt
execute in minecraft:overworld run setblock 256 61 -6 gravel
execute in minecraft:overworld run fill 256 62 -6 256 144 -6 air
execute in minecraft:overworld run fill 256 62 -6 256 64 -6 water
execute in minecraft:overworld run fill 256 58 -5 256 58 -5 stone
execute in minecraft:overworld run fill 256 59 -5 256 60 -5 dirt
execute in minecraft:overworld run setblock 256 61 -5 gravel
execute in minecraft:overworld run fill 256 62 -5 256 144 -5 air
execute in minecraft:overworld run fill 256 62 -5 256 64 -5 water
execute in minecraft:overworld run fill 256 58 -4 256 58 -4 stone
execute in minecraft:overworld run fill 256 59 -4 256 60 -4 dirt
execute in minecraft:overworld run setblock 256 61 -4 gravel
execute in minecraft:overworld run fill 256 62 -4 256 144 -4 air
execute in minecraft:overworld run fill 256 62 -4 256 64 -4 water
execute in minecraft:overworld run fill 256 58 -3 256 58 -3 stone
execute in minecraft:overworld run fill 256 59 -3 256 60 -3 dirt
execute in minecraft:overworld run setblock 256 61 -3 gravel
execute in minecraft:overworld run fill 256 62 -3 256 144 -3 air
execute in minecraft:overworld run fill 256 62 -3 256 64 -3 water
execute in minecraft:overworld run fill 256 58 -2 256 58 -2 stone
execute in minecraft:overworld run fill 256 59 -2 256 60 -2 dirt
execute in minecraft:overworld run setblock 256 61 -2 gravel
execute in minecraft:overworld run fill 256 62 -2 256 144 -2 air
execute in minecraft:overworld run fill 256 62 -2 256 64 -2 water
execute in minecraft:overworld run fill 256 58 -1 256 58 -1 stone
execute in minecraft:overworld run fill 256 59 -1 256 60 -1 dirt
execute in minecraft:overworld run setblock 256 61 -1 gravel
execute in minecraft:overworld run fill 256 62 -1 256 144 -1 air
execute in minecraft:overworld run fill 256 62 -1 256 64 -1 water
execute in minecraft:overworld run fill 256 58 0 256 58 0 stone
execute in minecraft:overworld run fill 256 59 0 256 60 0 dirt
execute in minecraft:overworld run setblock 256 61 0 gravel
execute in minecraft:overworld run fill 256 62 0 256 144 0 air
execute in minecraft:overworld run fill 256 62 0 256 64 0 water
execute in minecraft:overworld run fill 256 58 1 256 58 1 stone
execute in minecraft:overworld run fill 256 59 1 256 60 1 dirt
execute in minecraft:overworld run setblock 256 61 1 gravel
execute in minecraft:overworld run fill 256 62 1 256 144 1 air
execute in minecraft:overworld run fill 256 62 1 256 64 1 water
schedule function blade_gallery:random/burned/part_75 1t replace
