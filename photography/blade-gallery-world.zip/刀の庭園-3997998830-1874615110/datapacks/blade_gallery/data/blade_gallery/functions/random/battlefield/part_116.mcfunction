execute in minecraft:overworld run fill 409 58 16 409 66 16 stone
execute in minecraft:overworld run fill 409 67 16 409 68 16 dirt
execute in minecraft:overworld run setblock 409 69 16 grass_block
execute in minecraft:overworld run fill 409 70 16 409 144 16 air
execute in minecraft:overworld run fill 409 58 17 409 66 17 stone
execute in minecraft:overworld run fill 409 67 17 409 68 17 dirt
execute in minecraft:overworld run setblock 409 69 17 coarse_dirt
execute in minecraft:overworld run fill 409 70 17 409 144 17 air
execute in minecraft:overworld run fill 409 58 18 409 66 18 stone
execute in minecraft:overworld run fill 409 67 18 409 68 18 dirt
execute in minecraft:overworld run setblock 409 69 18 coarse_dirt
execute in minecraft:overworld run fill 409 70 18 409 144 18 air
execute in minecraft:overworld run fill 409 58 19 409 67 19 stone
execute in minecraft:overworld run fill 409 68 19 409 69 19 dirt
execute in minecraft:overworld run setblock 409 70 19 coarse_dirt
execute in minecraft:overworld run fill 409 71 19 409 144 19 air
execute in minecraft:overworld run fill 409 58 20 409 67 20 stone
execute in minecraft:overworld run fill 409 68 20 409 69 20 dirt
execute in minecraft:overworld run setblock 409 70 20 grass_block
execute in minecraft:overworld run fill 409 71 20 409 144 20 air
execute in minecraft:overworld run fill 409 58 21 409 68 21 stone
execute in minecraft:overworld run fill 409 69 21 409 70 21 dirt
execute in minecraft:overworld run setblock 409 71 21 grass_block
execute in minecraft:overworld run fill 409 72 21 409 144 21 air
execute in minecraft:overworld run setblock 409 72 21 grass
execute in minecraft:overworld run fill 409 58 22 409 68 22 stone
execute in minecraft:overworld run fill 409 69 22 409 70 22 dirt
execute in minecraft:overworld run setblock 409 71 22 grass_block
execute in minecraft:overworld run fill 409 72 22 409 144 22 air
execute in minecraft:overworld run fill 409 58 23 409 68 23 stone
execute in minecraft:overworld run fill 409 69 23 409 70 23 dirt
execute in minecraft:overworld run setblock 409 71 23 coarse_dirt
execute in minecraft:overworld run fill 409 72 23 409 144 23 air
execute in minecraft:overworld run fill 409 58 24 409 69 24 stone
execute in minecraft:overworld run fill 409 70 24 409 71 24 dirt
execute in minecraft:overworld run setblock 409 72 24 coarse_dirt
execute in minecraft:overworld run fill 409 73 24 409 144 24 air
execute in minecraft:overworld run setblock 409 73 24 grass
execute in minecraft:overworld run fill 409 58 25 409 69 25 stone
execute in minecraft:overworld run fill 409 70 25 409 71 25 dirt
execute in minecraft:overworld run setblock 409 72 25 coarse_dirt
execute in minecraft:overworld run fill 409 73 25 409 144 25 air
execute in minecraft:overworld run fill 409 58 26 409 69 26 stone
execute in minecraft:overworld run fill 409 70 26 409 71 26 dirt
execute in minecraft:overworld run setblock 409 72 26 coarse_dirt
execute in minecraft:overworld run fill 409 73 26 409 144 26 air
execute in minecraft:overworld run fill 409 58 27 409 69 27 stone
execute in minecraft:overworld run fill 409 70 27 409 71 27 dirt
execute in minecraft:overworld run setblock 409 72 27 coarse_dirt
execute in minecraft:overworld run fill 409 73 27 409 144 27 air
execute in minecraft:overworld run fill 409 58 28 409 69 28 stone
execute in minecraft:overworld run fill 409 70 28 409 71 28 dirt
execute in minecraft:overworld run setblock 409 72 28 coarse_dirt
execute in minecraft:overworld run fill 409 73 28 409 144 28 air
execute in minecraft:overworld run fill 409 58 29 409 69 29 stone
execute in minecraft:overworld run fill 409 70 29 409 71 29 dirt
execute in minecraft:overworld run setblock 409 72 29 coarse_dirt
execute in minecraft:overworld run fill 409 73 29 409 144 29 air
execute in minecraft:overworld run fill 409 58 30 409 69 30 stone
execute in minecraft:overworld run fill 409 70 30 409 71 30 dirt
execute in minecraft:overworld run setblock 409 72 30 coarse_dirt
execute in minecraft:overworld run fill 409 73 30 409 144 30 air
execute in minecraft:overworld run fill 409 58 31 409 69 31 stone
execute in minecraft:overworld run fill 409 70 31 409 71 31 dirt
execute in minecraft:overworld run setblock 409 72 31 grass_block
execute in minecraft:overworld run fill 409 73 31 409 144 31 air
execute in minecraft:overworld run fill 409 58 32 409 68 32 stone
execute in minecraft:overworld run fill 409 69 32 409 70 32 dirt
execute in minecraft:overworld run setblock 409 71 32 coarse_dirt
execute in minecraft:overworld run fill 409 72 32 409 144 32 air
execute in minecraft:overworld run fill 409 58 33 409 68 33 stone
execute in minecraft:overworld run fill 409 69 33 409 70 33 dirt
execute in minecraft:overworld run setblock 409 71 33 grass_block
execute in minecraft:overworld run fill 409 72 33 409 144 33 air
execute in minecraft:overworld run setblock 409 72 33 grass
execute in minecraft:overworld run fill 409 58 34 409 68 34 stone
execute in minecraft:overworld run fill 409 69 34 409 70 34 dirt
execute in minecraft:overworld run setblock 409 71 34 coarse_dirt
execute in minecraft:overworld run fill 409 72 34 409 144 34 air
execute in minecraft:overworld run fill 409 58 35 409 68 35 stone
execute in minecraft:overworld run fill 409 69 35 409 70 35 dirt
execute in minecraft:overworld run setblock 409 71 35 coarse_dirt
execute in minecraft:overworld run fill 409 72 35 409 144 35 air
execute in minecraft:overworld run fill 409 58 36 409 67 36 stone
execute in minecraft:overworld run fill 409 68 36 409 69 36 dirt
execute in minecraft:overworld run setblock 409 70 36 coarse_dirt
execute in minecraft:overworld run fill 409 71 36 409 144 36 air
execute in minecraft:overworld run fill 409 58 37 409 67 37 stone
execute in minecraft:overworld run fill 409 68 37 409 69 37 dirt
execute in minecraft:overworld run setblock 409 70 37 coarse_dirt
execute in minecraft:overworld run fill 409 71 37 409 144 37 air
execute in minecraft:overworld run fill 409 58 38 409 67 38 stone
execute in minecraft:overworld run fill 409 68 38 409 69 38 dirt
execute in minecraft:overworld run setblock 409 70 38 coarse_dirt
execute in minecraft:overworld run fill 409 71 38 409 144 38 air
execute in minecraft:overworld run fill 409 58 39 409 66 39 stone
execute in minecraft:overworld run fill 409 67 39 409 68 39 dirt
execute in minecraft:overworld run setblock 409 69 39 coarse_dirt
execute in minecraft:overworld run fill 409 70 39 409 144 39 air
execute in minecraft:overworld run fill 409 58 40 409 66 40 stone
execute in minecraft:overworld run fill 409 67 40 409 68 40 dirt
execute in minecraft:overworld run setblock 409 69 40 coarse_dirt
execute in minecraft:overworld run fill 409 70 40 409 144 40 air
execute in minecraft:overworld run fill 409 58 41 409 65 41 stone
execute in minecraft:overworld run fill 409 66 41 409 67 41 dirt
execute in minecraft:overworld run setblock 409 68 41 coarse_dirt
execute in minecraft:overworld run fill 409 69 41 409 144 41 air
execute in minecraft:overworld run fill 409 58 42 409 65 42 stone
execute in minecraft:overworld run fill 409 66 42 409 67 42 dirt
execute in minecraft:overworld run setblock 409 68 42 grass_block
execute in minecraft:overworld run fill 409 69 42 409 144 42 air
execute in minecraft:overworld run fill 409 58 43 409 64 43 stone
execute in minecraft:overworld run fill 409 65 43 409 66 43 dirt
execute in minecraft:overworld run setblock 409 67 43 grass_block
execute in minecraft:overworld run fill 409 68 43 409 144 43 air
execute in minecraft:overworld run fill 409 58 44 409 63 44 stone
execute in minecraft:overworld run fill 409 64 44 409 65 44 dirt
execute in minecraft:overworld run setblock 409 66 44 coarse_dirt
execute in minecraft:overworld run fill 409 67 44 409 144 44 air
execute in minecraft:overworld run fill 409 58 45 409 63 45 stone
execute in minecraft:overworld run fill 409 64 45 409 65 45 dirt
execute in minecraft:overworld run setblock 409 66 45 coarse_dirt
execute in minecraft:overworld run fill 409 67 45 409 144 45 air
execute in minecraft:overworld run fill 409 58 46 409 62 46 stone
execute in minecraft:overworld run fill 409 63 46 409 64 46 dirt
execute in minecraft:overworld run setblock 409 65 46 coarse_dirt
execute in minecraft:overworld run fill 409 66 46 409 144 46 air
execute in minecraft:overworld run fill 409 58 47 409 61 47 stone
execute in minecraft:overworld run fill 409 62 47 409 63 47 dirt
execute in minecraft:overworld run setblock 409 64 47 coarse_dirt
execute in minecraft:overworld run fill 409 65 47 409 144 47 air
execute in minecraft:overworld run fill 410 58 -48 410 61 -48 stone
execute in minecraft:overworld run fill 410 62 -48 410 63 -48 dirt
execute in minecraft:overworld run setblock 410 64 -48 coarse_dirt
execute in minecraft:overworld run fill 410 65 -48 410 144 -48 air
execute in minecraft:overworld run fill 410 58 -47 410 63 -47 stone
execute in minecraft:overworld run fill 410 64 -47 410 65 -47 dirt
execute in minecraft:overworld run setblock 410 66 -47 coarse_dirt
execute in minecraft:overworld run fill 410 67 -47 410 144 -47 air
execute in minecraft:overworld run fill 410 58 -46 410 64 -46 stone
execute in minecraft:overworld run fill 410 65 -46 410 66 -46 dirt
execute in minecraft:overworld run setblock 410 67 -46 coarse_dirt
execute in minecraft:overworld run fill 410 68 -46 410 144 -46 air
execute in minecraft:overworld run fill 410 58 -45 410 66 -45 stone
execute in minecraft:overworld run fill 410 67 -45 410 68 -45 dirt
execute in minecraft:overworld run setblock 410 69 -45 grass_block
execute in minecraft:overworld run fill 410 70 -45 410 144 -45 air
execute in minecraft:overworld run fill 410 58 -44 410 67 -44 stone
execute in minecraft:overworld run fill 410 68 -44 410 69 -44 dirt
execute in minecraft:overworld run setblock 410 70 -44 coarse_dirt
execute in minecraft:overworld run fill 410 71 -44 410 144 -44 air
execute in minecraft:overworld run fill 410 58 -43 410 69 -43 stone
execute in minecraft:overworld run fill 410 70 -43 410 71 -43 dirt
execute in minecraft:overworld run setblock 410 72 -43 grass_block
execute in minecraft:overworld run fill 410 73 -43 410 144 -43 air
execute in minecraft:overworld run fill 410 58 -42 410 70 -42 stone
execute in minecraft:overworld run fill 410 71 -42 410 72 -42 dirt
execute in minecraft:overworld run setblock 410 73 -42 grass_block
execute in minecraft:overworld run fill 410 74 -42 410 144 -42 air
execute in minecraft:overworld run fill 410 58 -41 410 72 -41 stone
execute in minecraft:overworld run fill 410 73 -41 410 74 -41 dirt
execute in minecraft:overworld run setblock 410 75 -41 coarse_dirt
execute in minecraft:overworld run fill 410 76 -41 410 144 -41 air
execute in minecraft:overworld run fill 410 58 -40 410 73 -40 stone
execute in minecraft:overworld run fill 410 74 -40 410 75 -40 dirt
execute in minecraft:overworld run setblock 410 76 -40 grass_block
execute in minecraft:overworld run fill 410 77 -40 410 144 -40 air
execute in minecraft:overworld run setblock 410 77 -40 grass
execute in minecraft:overworld run fill 410 58 -39 410 74 -39 stone
execute in minecraft:overworld run fill 410 75 -39 410 76 -39 dirt
execute in minecraft:overworld run setblock 410 77 -39 coarse_dirt
execute in minecraft:overworld run fill 410 78 -39 410 144 -39 air
execute in minecraft:overworld run fill 410 58 -38 410 75 -38 stone
execute in minecraft:overworld run fill 410 76 -38 410 77 -38 dirt
execute in minecraft:overworld run setblock 410 78 -38 grass_block
execute in minecraft:overworld run fill 410 79 -38 410 144 -38 air
execute in minecraft:overworld run fill 410 58 -37 410 75 -37 stone
execute in minecraft:overworld run fill 410 76 -37 410 77 -37 dirt
execute in minecraft:overworld run setblock 410 78 -37 coarse_dirt
execute in minecraft:overworld run fill 410 79 -37 410 144 -37 air
execute in minecraft:overworld run setblock 410 79 -37 grass
execute in minecraft:overworld run fill 410 58 -36 410 75 -36 stone
execute in minecraft:overworld run fill 410 76 -36 410 77 -36 dirt
execute in minecraft:overworld run setblock 410 78 -36 grass_block
execute in minecraft:overworld run fill 410 79 -36 410 144 -36 air
execute in minecraft:overworld run fill 410 58 -35 410 74 -35 stone
execute in minecraft:overworld run fill 410 75 -35 410 76 -35 dirt
execute in minecraft:overworld run setblock 410 77 -35 coarse_dirt
execute in minecraft:overworld run fill 410 78 -35 410 144 -35 air
execute in minecraft:overworld run fill 410 58 -34 410 74 -34 stone
execute in minecraft:overworld run fill 410 75 -34 410 76 -34 dirt
execute in minecraft:overworld run setblock 410 77 -34 grass_block
execute in minecraft:overworld run fill 410 78 -34 410 144 -34 air
execute in minecraft:overworld run fill 410 58 -33 410 73 -33 stone
execute in minecraft:overworld run fill 410 74 -33 410 75 -33 dirt
execute in minecraft:overworld run setblock 410 76 -33 grass_block
execute in minecraft:overworld run fill 410 77 -33 410 144 -33 air
execute in minecraft:overworld run fill 410 58 -32 410 73 -32 stone
execute in minecraft:overworld run fill 410 74 -32 410 75 -32 dirt
execute in minecraft:overworld run setblock 410 76 -32 coarse_dirt
execute in minecraft:overworld run fill 410 77 -32 410 144 -32 air
execute in minecraft:overworld run fill 410 58 -31 410 73 -31 stone
execute in minecraft:overworld run fill 410 74 -31 410 75 -31 dirt
execute in minecraft:overworld run setblock 410 76 -31 coarse_dirt
execute in minecraft:overworld run fill 410 77 -31 410 144 -31 air
execute in minecraft:overworld run fill 410 58 -30 410 72 -30 stone
execute in minecraft:overworld run fill 410 73 -30 410 74 -30 dirt
execute in minecraft:overworld run setblock 410 75 -30 coarse_dirt
execute in minecraft:overworld run fill 410 76 -30 410 144 -30 air
execute in minecraft:overworld run setblock 410 76 -30 mossy_cobblestone
execute in minecraft:overworld run fill 410 58 -29 410 72 -29 stone
execute in minecraft:overworld run fill 410 73 -29 410 74 -29 dirt
execute in minecraft:overworld run setblock 410 75 -29 grass_block
execute in minecraft:overworld run fill 410 76 -29 410 144 -29 air
execute in minecraft:overworld run setblock 410 76 -29 grass
execute in minecraft:overworld run fill 410 58 -28 410 71 -28 stone
execute in minecraft:overworld run fill 410 72 -28 410 73 -28 dirt
execute in minecraft:overworld run setblock 410 74 -28 coarse_dirt
execute in minecraft:overworld run fill 410 75 -28 410 144 -28 air
execute in minecraft:overworld run fill 410 58 -27 410 71 -27 stone
execute in minecraft:overworld run fill 410 72 -27 410 73 -27 dirt
execute in minecraft:overworld run setblock 410 74 -27 coarse_dirt
execute in minecraft:overworld run fill 410 75 -27 410 144 -27 air
execute in minecraft:overworld run fill 410 58 -26 410 71 -26 stone
execute in minecraft:overworld run fill 410 72 -26 410 73 -26 dirt
execute in minecraft:overworld run setblock 410 74 -26 coarse_dirt
execute in minecraft:overworld run fill 410 75 -26 410 144 -26 air
execute in minecraft:overworld run setblock 410 75 -26 grass
execute in minecraft:overworld run fill 410 58 -25 410 70 -25 stone
execute in minecraft:overworld run fill 410 71 -25 410 72 -25 dirt
execute in minecraft:overworld run setblock 410 73 -25 coarse_dirt
execute in minecraft:overworld run fill 410 74 -25 410 144 -25 air
execute in minecraft:overworld run fill 410 58 -24 410 70 -24 stone
execute in minecraft:overworld run fill 410 71 -24 410 72 -24 dirt
execute in minecraft:overworld run setblock 410 73 -24 coarse_dirt
execute in minecraft:overworld run fill 410 74 -24 410 144 -24 air
execute in minecraft:overworld run fill 410 58 -23 410 70 -23 stone
execute in minecraft:overworld run fill 410 71 -23 410 72 -23 dirt
execute in minecraft:overworld run setblock 410 73 -23 coarse_dirt
execute in minecraft:overworld run fill 410 74 -23 410 144 -23 air
execute in minecraft:overworld run fill 410 58 -22 410 70 -22 stone
execute in minecraft:overworld run fill 410 71 -22 410 72 -22 dirt
execute in minecraft:overworld run setblock 410 73 -22 coarse_dirt
execute in minecraft:overworld run fill 410 74 -22 410 144 -22 air
execute in minecraft:overworld run fill 410 58 -21 410 69 -21 stone
execute in minecraft:overworld run fill 410 70 -21 410 71 -21 dirt
execute in minecraft:overworld run setblock 410 72 -21 coarse_dirt
execute in minecraft:overworld run fill 410 73 -21 410 144 -21 air
execute in minecraft:overworld run fill 410 58 -20 410 69 -20 stone
execute in minecraft:overworld run fill 410 70 -20 410 71 -20 dirt
execute in minecraft:overworld run setblock 410 72 -20 coarse_dirt
execute in minecraft:overworld run fill 410 73 -20 410 144 -20 air
execute in minecraft:overworld run fill 410 58 -19 410 69 -19 stone
execute in minecraft:overworld run fill 410 70 -19 410 71 -19 dirt
execute in minecraft:overworld run setblock 410 72 -19 grass_block
execute in minecraft:overworld run fill 410 73 -19 410 144 -19 air
schedule function blade_gallery:random/battlefield/part_117 1t replace
