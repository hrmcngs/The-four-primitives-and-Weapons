execute in minecraft:overworld run fill 223 74 -41 223 144 -41 air
execute in minecraft:overworld run fill 223 58 -40 223 70 -40 stone
execute in minecraft:overworld run fill 223 71 -40 223 72 -40 dirt
execute in minecraft:overworld run setblock 223 73 -40 coarse_dirt
execute in minecraft:overworld run fill 223 74 -40 223 144 -40 air
execute in minecraft:overworld run fill 223 58 -39 223 71 -39 stone
execute in minecraft:overworld run fill 223 72 -39 223 73 -39 dirt
execute in minecraft:overworld run setblock 223 74 -39 grass_block
execute in minecraft:overworld run fill 223 75 -39 223 144 -39 air
execute in minecraft:overworld run fill 223 58 -38 223 71 -38 stone
execute in minecraft:overworld run fill 223 72 -38 223 73 -38 dirt
execute in minecraft:overworld run setblock 223 74 -38 grass_block
execute in minecraft:overworld run fill 223 75 -38 223 144 -38 air
execute in minecraft:overworld run fill 223 58 -37 223 70 -37 stone
execute in minecraft:overworld run fill 223 71 -37 223 72 -37 dirt
execute in minecraft:overworld run setblock 223 73 -37 coarse_dirt
execute in minecraft:overworld run fill 223 74 -37 223 144 -37 air
execute in minecraft:overworld run fill 223 58 -36 223 70 -36 stone
execute in minecraft:overworld run fill 223 71 -36 223 72 -36 dirt
execute in minecraft:overworld run setblock 223 73 -36 coarse_dirt
execute in minecraft:overworld run fill 223 74 -36 223 144 -36 air
execute in minecraft:overworld run fill 223 58 -35 223 69 -35 stone
execute in minecraft:overworld run fill 223 70 -35 223 71 -35 dirt
execute in minecraft:overworld run setblock 223 72 -35 grass_block
execute in minecraft:overworld run fill 223 73 -35 223 144 -35 air
execute in minecraft:overworld run fill 223 58 -34 223 68 -34 stone
execute in minecraft:overworld run fill 223 69 -34 223 70 -34 dirt
execute in minecraft:overworld run setblock 223 71 -34 coarse_dirt
execute in minecraft:overworld run fill 223 72 -34 223 144 -34 air
execute in minecraft:overworld run fill 223 58 -33 223 68 -33 stone
execute in minecraft:overworld run fill 223 69 -33 223 70 -33 dirt
execute in minecraft:overworld run setblock 223 71 -33 coarse_dirt
execute in minecraft:overworld run fill 223 72 -33 223 144 -33 air
execute in minecraft:overworld run fill 223 58 -32 223 67 -32 stone
execute in minecraft:overworld run fill 223 68 -32 223 69 -32 dirt
execute in minecraft:overworld run setblock 223 70 -32 coarse_dirt
execute in minecraft:overworld run fill 223 71 -32 223 144 -32 air
execute in minecraft:overworld run fill 223 58 -31 223 67 -31 stone
execute in minecraft:overworld run fill 223 68 -31 223 69 -31 dirt
execute in minecraft:overworld run setblock 223 70 -31 coarse_dirt
execute in minecraft:overworld run fill 223 71 -31 223 144 -31 air
execute in minecraft:overworld run fill 223 58 -30 223 67 -30 stone
execute in minecraft:overworld run fill 223 68 -30 223 69 -30 dirt
execute in minecraft:overworld run setblock 223 70 -30 grass_block
execute in minecraft:overworld run fill 223 71 -30 223 144 -30 air
execute in minecraft:overworld run setblock 223 71 -30 grass
execute in minecraft:overworld run fill 223 58 -29 223 66 -29 stone
execute in minecraft:overworld run fill 223 67 -29 223 68 -29 dirt
execute in minecraft:overworld run setblock 223 69 -29 coarse_dirt
execute in minecraft:overworld run fill 223 70 -29 223 144 -29 air
execute in minecraft:overworld run fill 223 58 -28 223 66 -28 stone
execute in minecraft:overworld run fill 223 67 -28 223 68 -28 dirt
execute in minecraft:overworld run setblock 223 69 -28 coarse_dirt
execute in minecraft:overworld run fill 223 70 -28 223 144 -28 air
execute in minecraft:overworld run fill 223 58 -27 223 66 -27 stone
execute in minecraft:overworld run fill 223 67 -27 223 68 -27 dirt
execute in minecraft:overworld run setblock 223 69 -27 coarse_dirt
execute in minecraft:overworld run fill 223 70 -27 223 144 -27 air
execute in minecraft:overworld run fill 223 58 -26 223 66 -26 stone
execute in minecraft:overworld run fill 223 67 -26 223 68 -26 dirt
execute in minecraft:overworld run setblock 223 69 -26 coarse_dirt
execute in minecraft:overworld run fill 223 70 -26 223 144 -26 air
execute in minecraft:overworld run fill 223 58 -25 223 65 -25 stone
execute in minecraft:overworld run fill 223 66 -25 223 67 -25 dirt
execute in minecraft:overworld run setblock 223 68 -25 coarse_dirt
execute in minecraft:overworld run fill 223 69 -25 223 144 -25 air
execute in minecraft:overworld run fill 223 58 -24 223 65 -24 stone
execute in minecraft:overworld run fill 223 66 -24 223 67 -24 dirt
execute in minecraft:overworld run setblock 223 68 -24 coarse_dirt
execute in minecraft:overworld run fill 223 69 -24 223 144 -24 air
execute in minecraft:overworld run fill 223 58 -23 223 66 -23 stone
execute in minecraft:overworld run fill 223 67 -23 223 68 -23 dirt
execute in minecraft:overworld run setblock 223 69 -23 coarse_dirt
execute in minecraft:overworld run fill 223 70 -23 223 144 -23 air
execute in minecraft:overworld run fill 223 58 -22 223 66 -22 stone
execute in minecraft:overworld run fill 223 67 -22 223 68 -22 dirt
execute in minecraft:overworld run setblock 223 69 -22 grass_block
execute in minecraft:overworld run fill 223 70 -22 223 144 -22 air
execute in minecraft:overworld run fill 223 58 -21 223 66 -21 stone
execute in minecraft:overworld run fill 223 67 -21 223 68 -21 dirt
execute in minecraft:overworld run setblock 223 69 -21 grass_block
execute in minecraft:overworld run fill 223 70 -21 223 144 -21 air
execute in minecraft:overworld run fill 223 58 -20 223 66 -20 stone
execute in minecraft:overworld run fill 223 67 -20 223 68 -20 dirt
execute in minecraft:overworld run setblock 223 69 -20 coarse_dirt
execute in minecraft:overworld run fill 223 70 -20 223 144 -20 air
execute in minecraft:overworld run fill 223 58 -19 223 66 -19 stone
execute in minecraft:overworld run fill 223 67 -19 223 68 -19 dirt
execute in minecraft:overworld run setblock 223 69 -19 coarse_dirt
execute in minecraft:overworld run fill 223 70 -19 223 144 -19 air
execute in minecraft:overworld run fill 223 58 -18 223 66 -18 stone
execute in minecraft:overworld run fill 223 67 -18 223 68 -18 dirt
execute in minecraft:overworld run setblock 223 69 -18 coarse_dirt
execute in minecraft:overworld run fill 223 70 -18 223 144 -18 air
execute in minecraft:overworld run fill 223 58 -17 223 66 -17 stone
execute in minecraft:overworld run fill 223 67 -17 223 68 -17 dirt
execute in minecraft:overworld run setblock 223 69 -17 coarse_dirt
execute in minecraft:overworld run fill 223 70 -17 223 144 -17 air
execute in minecraft:overworld run fill 223 58 -16 223 66 -16 stone
execute in minecraft:overworld run fill 223 67 -16 223 68 -16 dirt
execute in minecraft:overworld run setblock 223 69 -16 grass_block
execute in minecraft:overworld run fill 223 70 -16 223 144 -16 air
execute in minecraft:overworld run fill 223 58 -15 223 65 -15 stone
execute in minecraft:overworld run fill 223 66 -15 223 67 -15 dirt
execute in minecraft:overworld run setblock 223 68 -15 grass_block
execute in minecraft:overworld run fill 223 69 -15 223 144 -15 air
execute in minecraft:overworld run fill 223 58 -14 223 65 -14 stone
execute in minecraft:overworld run fill 223 66 -14 223 67 -14 dirt
execute in minecraft:overworld run setblock 223 68 -14 coarse_dirt
execute in minecraft:overworld run fill 223 69 -14 223 144 -14 air
execute in minecraft:overworld run fill 223 58 -13 223 65 -13 stone
execute in minecraft:overworld run fill 223 66 -13 223 67 -13 dirt
execute in minecraft:overworld run setblock 223 68 -13 grass_block
execute in minecraft:overworld run fill 223 69 -13 223 144 -13 air
execute in minecraft:overworld run fill 223 58 -12 223 64 -12 stone
execute in minecraft:overworld run fill 223 65 -12 223 66 -12 dirt
execute in minecraft:overworld run setblock 223 67 -12 coarse_dirt
execute in minecraft:overworld run fill 223 68 -12 223 144 -12 air
execute in minecraft:overworld run fill 223 58 -11 223 64 -11 stone
execute in minecraft:overworld run fill 223 65 -11 223 66 -11 dirt
execute in minecraft:overworld run setblock 223 67 -11 coarse_dirt
execute in minecraft:overworld run fill 223 68 -11 223 144 -11 air
execute in minecraft:overworld run fill 223 58 -10 223 64 -10 stone
execute in minecraft:overworld run fill 223 65 -10 223 66 -10 dirt
execute in minecraft:overworld run setblock 223 67 -10 grass_block
execute in minecraft:overworld run fill 223 68 -10 223 144 -10 air
execute in minecraft:overworld run fill 223 58 -9 223 65 -9 stone
execute in minecraft:overworld run fill 223 66 -9 223 67 -9 dirt
execute in minecraft:overworld run setblock 223 68 -9 coarse_dirt
execute in minecraft:overworld run fill 223 69 -9 223 144 -9 air
execute in minecraft:overworld run fill 223 58 -8 223 65 -8 stone
execute in minecraft:overworld run fill 223 66 -8 223 67 -8 dirt
execute in minecraft:overworld run setblock 223 68 -8 coarse_dirt
execute in minecraft:overworld run fill 223 69 -8 223 144 -8 air
execute in minecraft:overworld run setblock 223 69 -8 grass
execute in minecraft:overworld run fill 223 58 -7 223 65 -7 stone
execute in minecraft:overworld run fill 223 66 -7 223 67 -7 dirt
execute in minecraft:overworld run setblock 223 68 -7 grass_block
execute in minecraft:overworld run fill 223 69 -7 223 144 -7 air
execute in minecraft:overworld run fill 223 58 -6 223 66 -6 stone
execute in minecraft:overworld run fill 223 67 -6 223 68 -6 dirt
execute in minecraft:overworld run setblock 223 69 -6 coarse_dirt
execute in minecraft:overworld run fill 223 70 -6 223 144 -6 air
execute in minecraft:overworld run fill 223 58 -5 223 66 -5 stone
execute in minecraft:overworld run fill 223 67 -5 223 68 -5 dirt
execute in minecraft:overworld run setblock 223 69 -5 coarse_dirt
execute in minecraft:overworld run fill 223 70 -5 223 144 -5 air
execute in minecraft:overworld run fill 223 58 -4 223 67 -4 stone
execute in minecraft:overworld run fill 223 68 -4 223 69 -4 dirt
execute in minecraft:overworld run setblock 223 70 -4 coarse_dirt
execute in minecraft:overworld run fill 223 71 -4 223 144 -4 air
execute in minecraft:overworld run fill 223 58 -3 223 67 -3 stone
execute in minecraft:overworld run fill 223 68 -3 223 69 -3 dirt
execute in minecraft:overworld run setblock 223 70 -3 grass_block
execute in minecraft:overworld run fill 223 71 -3 223 144 -3 air
execute in minecraft:overworld run fill 223 58 -2 223 67 -2 stone
execute in minecraft:overworld run fill 223 68 -2 223 69 -2 dirt
execute in minecraft:overworld run setblock 223 70 -2 grass_block
execute in minecraft:overworld run fill 223 71 -2 223 144 -2 air
execute in minecraft:overworld run fill 223 58 -1 223 68 -1 stone
execute in minecraft:overworld run fill 223 69 -1 223 70 -1 dirt
execute in minecraft:overworld run setblock 223 71 -1 coarse_dirt
execute in minecraft:overworld run fill 223 72 -1 223 144 -1 air
execute in minecraft:overworld run fill 223 58 0 223 68 0 stone
execute in minecraft:overworld run fill 223 69 0 223 70 0 dirt
execute in minecraft:overworld run setblock 223 71 0 grass_block
execute in minecraft:overworld run fill 223 72 0 223 144 0 air
execute in minecraft:overworld run fill 223 58 1 223 68 1 stone
execute in minecraft:overworld run fill 223 69 1 223 70 1 dirt
execute in minecraft:overworld run setblock 223 71 1 coarse_dirt
execute in minecraft:overworld run fill 223 72 1 223 144 1 air
execute in minecraft:overworld run fill 223 58 2 223 67 2 stone
execute in minecraft:overworld run fill 223 68 2 223 69 2 dirt
execute in minecraft:overworld run setblock 223 70 2 coarse_dirt
execute in minecraft:overworld run fill 223 71 2 223 144 2 air
execute in minecraft:overworld run fill 223 58 3 223 67 3 stone
execute in minecraft:overworld run fill 223 68 3 223 69 3 dirt
execute in minecraft:overworld run setblock 223 70 3 coarse_dirt
execute in minecraft:overworld run fill 223 71 3 223 144 3 air
execute in minecraft:overworld run fill 223 58 4 223 67 4 stone
execute in minecraft:overworld run fill 223 68 4 223 69 4 dirt
execute in minecraft:overworld run setblock 223 70 4 coarse_dirt
execute in minecraft:overworld run fill 223 71 4 223 144 4 air
execute in minecraft:overworld run fill 223 58 5 223 67 5 stone
execute in minecraft:overworld run fill 223 68 5 223 69 5 dirt
execute in minecraft:overworld run setblock 223 70 5 coarse_dirt
execute in minecraft:overworld run fill 223 71 5 223 144 5 air
execute in minecraft:overworld run setblock 223 71 5 grass
execute in minecraft:overworld run fill 223 58 6 223 66 6 stone
execute in minecraft:overworld run fill 223 67 6 223 68 6 dirt
execute in minecraft:overworld run setblock 223 69 6 coarse_dirt
execute in minecraft:overworld run fill 223 70 6 223 144 6 air
execute in minecraft:overworld run setblock 223 70 6 mossy_cobblestone
execute in minecraft:overworld run fill 223 58 7 223 66 7 stone
execute in minecraft:overworld run fill 223 67 7 223 68 7 dirt
execute in minecraft:overworld run setblock 223 69 7 coarse_dirt
execute in minecraft:overworld run fill 223 70 7 223 144 7 air
execute in minecraft:overworld run fill 223 58 8 223 66 8 stone
execute in minecraft:overworld run fill 223 67 8 223 68 8 dirt
execute in minecraft:overworld run setblock 223 69 8 coarse_dirt
execute in minecraft:overworld run fill 223 70 8 223 144 8 air
execute in minecraft:overworld run fill 223 58 9 223 66 9 stone
execute in minecraft:overworld run fill 223 67 9 223 68 9 dirt
execute in minecraft:overworld run setblock 223 69 9 grass_block
execute in minecraft:overworld run fill 223 70 9 223 144 9 air
execute in minecraft:overworld run fill 223 58 10 223 67 10 stone
execute in minecraft:overworld run fill 223 68 10 223 69 10 dirt
execute in minecraft:overworld run setblock 223 70 10 coarse_dirt
execute in minecraft:overworld run fill 223 71 10 223 144 10 air
execute in minecraft:overworld run fill 223 58 11 223 67 11 stone
execute in minecraft:overworld run fill 223 68 11 223 69 11 dirt
execute in minecraft:overworld run setblock 223 70 11 coarse_dirt
execute in minecraft:overworld run fill 223 71 11 223 144 11 air
execute in minecraft:overworld run setblock 223 71 11 grass
execute in minecraft:overworld run fill 223 58 12 223 67 12 stone
execute in minecraft:overworld run fill 223 68 12 223 69 12 dirt
execute in minecraft:overworld run setblock 223 70 12 grass_block
execute in minecraft:overworld run fill 223 71 12 223 144 12 air
execute in minecraft:overworld run setblock 223 71 12 grass
execute in minecraft:overworld run fill 223 58 13 223 68 13 stone
execute in minecraft:overworld run fill 223 69 13 223 70 13 dirt
execute in minecraft:overworld run setblock 223 71 13 coarse_dirt
execute in minecraft:overworld run fill 223 72 13 223 144 13 air
execute in minecraft:overworld run fill 223 58 14 223 68 14 stone
execute in minecraft:overworld run fill 223 69 14 223 70 14 dirt
execute in minecraft:overworld run setblock 223 71 14 coarse_dirt
execute in minecraft:overworld run fill 223 72 14 223 144 14 air
execute in minecraft:overworld run fill 223 58 15 223 69 15 stone
execute in minecraft:overworld run fill 223 70 15 223 71 15 dirt
execute in minecraft:overworld run setblock 223 72 15 coarse_dirt
execute in minecraft:overworld run fill 223 73 15 223 144 15 air
execute in minecraft:overworld run fill 223 58 16 223 69 16 stone
execute in minecraft:overworld run fill 223 70 16 223 71 16 dirt
execute in minecraft:overworld run setblock 223 72 16 coarse_dirt
execute in minecraft:overworld run fill 223 73 16 223 144 16 air
execute in minecraft:overworld run fill 223 58 17 223 69 17 stone
execute in minecraft:overworld run fill 223 70 17 223 71 17 dirt
execute in minecraft:overworld run setblock 223 72 17 coarse_dirt
execute in minecraft:overworld run fill 223 73 17 223 144 17 air
execute in minecraft:overworld run fill 223 58 18 223 70 18 stone
execute in minecraft:overworld run fill 223 71 18 223 72 18 dirt
execute in minecraft:overworld run setblock 223 73 18 coarse_dirt
execute in minecraft:overworld run fill 223 74 18 223 144 18 air
execute in minecraft:overworld run fill 223 58 19 223 70 19 stone
execute in minecraft:overworld run fill 223 71 19 223 72 19 dirt
execute in minecraft:overworld run setblock 223 73 19 coarse_dirt
execute in minecraft:overworld run fill 223 74 19 223 144 19 air
execute in minecraft:overworld run fill 223 58 20 223 70 20 stone
execute in minecraft:overworld run fill 223 71 20 223 72 20 dirt
execute in minecraft:overworld run setblock 223 73 20 grass_block
execute in minecraft:overworld run fill 223 74 20 223 144 20 air
execute in minecraft:overworld run fill 223 58 21 223 70 21 stone
execute in minecraft:overworld run fill 223 71 21 223 72 21 dirt
execute in minecraft:overworld run setblock 223 73 21 coarse_dirt
execute in minecraft:overworld run fill 223 74 21 223 144 21 air
execute in minecraft:overworld run fill 223 58 22 223 70 22 stone
schedule function blade_gallery:random/burned/part_24 1t replace
