execute in minecraft:overworld run fill 398 69 39 398 144 39 air
execute in minecraft:overworld run fill 398 58 40 398 65 40 stone
execute in minecraft:overworld run fill 398 66 40 398 67 40 dirt
execute in minecraft:overworld run setblock 398 68 40 grass_block
execute in minecraft:overworld run fill 398 69 40 398 144 40 air
execute in minecraft:overworld run fill 398 58 41 398 65 41 stone
execute in minecraft:overworld run fill 398 66 41 398 67 41 dirt
execute in minecraft:overworld run setblock 398 68 41 coarse_dirt
execute in minecraft:overworld run fill 398 69 41 398 144 41 air
execute in minecraft:overworld run fill 398 58 42 398 65 42 stone
execute in minecraft:overworld run fill 398 66 42 398 67 42 dirt
execute in minecraft:overworld run setblock 398 68 42 coarse_dirt
execute in minecraft:overworld run fill 398 69 42 398 144 42 air
execute in minecraft:overworld run fill 398 58 43 398 64 43 stone
execute in minecraft:overworld run fill 398 65 43 398 66 43 dirt
execute in minecraft:overworld run setblock 398 67 43 coarse_dirt
execute in minecraft:overworld run fill 398 68 43 398 144 43 air
execute in minecraft:overworld run fill 398 58 44 398 64 44 stone
execute in minecraft:overworld run fill 398 65 44 398 66 44 dirt
execute in minecraft:overworld run setblock 398 67 44 grass_block
execute in minecraft:overworld run fill 398 68 44 398 144 44 air
execute in minecraft:overworld run fill 398 58 45 398 63 45 stone
execute in minecraft:overworld run fill 398 64 45 398 65 45 dirt
execute in minecraft:overworld run setblock 398 66 45 grass_block
execute in minecraft:overworld run fill 398 67 45 398 144 45 air
execute in minecraft:overworld run fill 398 58 46 398 63 46 stone
execute in minecraft:overworld run fill 398 64 46 398 65 46 dirt
execute in minecraft:overworld run setblock 398 66 46 coarse_dirt
execute in minecraft:overworld run fill 398 67 46 398 144 46 air
execute in minecraft:overworld run fill 398 58 47 398 62 47 stone
execute in minecraft:overworld run fill 398 63 47 398 64 47 dirt
execute in minecraft:overworld run setblock 398 65 47 grass_block
execute in minecraft:overworld run fill 398 66 47 398 144 47 air
execute in minecraft:overworld run fill 399 58 -48 399 61 -48 stone
execute in minecraft:overworld run fill 399 62 -48 399 63 -48 dirt
execute in minecraft:overworld run setblock 399 64 -48 coarse_dirt
execute in minecraft:overworld run fill 399 65 -48 399 144 -48 air
execute in minecraft:overworld run fill 399 58 -47 399 62 -47 stone
execute in minecraft:overworld run fill 399 63 -47 399 64 -47 dirt
execute in minecraft:overworld run setblock 399 65 -47 grass_block
execute in minecraft:overworld run fill 399 66 -47 399 144 -47 air
execute in minecraft:overworld run fill 399 58 -46 399 64 -46 stone
execute in minecraft:overworld run fill 399 65 -46 399 66 -46 dirt
execute in minecraft:overworld run setblock 399 67 -46 grass_block
execute in minecraft:overworld run fill 399 68 -46 399 144 -46 air
execute in minecraft:overworld run fill 399 58 -45 399 65 -45 stone
execute in minecraft:overworld run fill 399 66 -45 399 67 -45 dirt
execute in minecraft:overworld run setblock 399 68 -45 coarse_dirt
execute in minecraft:overworld run fill 399 69 -45 399 144 -45 air
execute in minecraft:overworld run fill 399 58 -44 399 66 -44 stone
execute in minecraft:overworld run fill 399 67 -44 399 68 -44 dirt
execute in minecraft:overworld run setblock 399 69 -44 grass_block
execute in minecraft:overworld run fill 399 70 -44 399 144 -44 air
execute in minecraft:overworld run fill 399 58 -43 399 68 -43 stone
execute in minecraft:overworld run fill 399 69 -43 399 70 -43 dirt
execute in minecraft:overworld run setblock 399 71 -43 coarse_dirt
execute in minecraft:overworld run fill 399 72 -43 399 144 -43 air
execute in minecraft:overworld run fill 399 58 -42 399 69 -42 stone
execute in minecraft:overworld run fill 399 70 -42 399 71 -42 dirt
execute in minecraft:overworld run setblock 399 72 -42 coarse_dirt
execute in minecraft:overworld run fill 399 73 -42 399 144 -42 air
execute in minecraft:overworld run fill 399 58 -41 399 71 -41 stone
execute in minecraft:overworld run fill 399 72 -41 399 73 -41 dirt
execute in minecraft:overworld run setblock 399 74 -41 coarse_dirt
execute in minecraft:overworld run fill 399 75 -41 399 144 -41 air
execute in minecraft:overworld run fill 399 58 -40 399 72 -40 stone
execute in minecraft:overworld run fill 399 73 -40 399 74 -40 dirt
execute in minecraft:overworld run setblock 399 75 -40 grass_block
execute in minecraft:overworld run fill 399 76 -40 399 144 -40 air
execute in minecraft:overworld run fill 399 58 -39 399 73 -39 stone
execute in minecraft:overworld run fill 399 74 -39 399 75 -39 dirt
execute in minecraft:overworld run setblock 399 76 -39 coarse_dirt
execute in minecraft:overworld run fill 399 77 -39 399 144 -39 air
execute in minecraft:overworld run fill 399 58 -38 399 75 -38 stone
execute in minecraft:overworld run fill 399 76 -38 399 77 -38 dirt
execute in minecraft:overworld run setblock 399 78 -38 coarse_dirt
execute in minecraft:overworld run fill 399 79 -38 399 144 -38 air
execute in minecraft:overworld run fill 399 58 -37 399 75 -37 stone
execute in minecraft:overworld run fill 399 76 -37 399 77 -37 dirt
execute in minecraft:overworld run setblock 399 78 -37 coarse_dirt
execute in minecraft:overworld run fill 399 79 -37 399 144 -37 air
execute in minecraft:overworld run fill 399 58 -36 399 74 -36 stone
execute in minecraft:overworld run fill 399 75 -36 399 76 -36 dirt
execute in minecraft:overworld run setblock 399 77 -36 coarse_dirt
execute in minecraft:overworld run fill 399 78 -36 399 144 -36 air
execute in minecraft:overworld run fill 399 58 -35 399 74 -35 stone
execute in minecraft:overworld run fill 399 75 -35 399 76 -35 dirt
execute in minecraft:overworld run setblock 399 77 -35 coarse_dirt
execute in minecraft:overworld run fill 399 78 -35 399 144 -35 air
execute in minecraft:overworld run fill 399 58 -34 399 74 -34 stone
execute in minecraft:overworld run fill 399 75 -34 399 76 -34 dirt
execute in minecraft:overworld run setblock 399 77 -34 grass_block
execute in minecraft:overworld run fill 399 78 -34 399 144 -34 air
execute in minecraft:overworld run fill 399 58 -33 399 74 -33 stone
execute in minecraft:overworld run fill 399 75 -33 399 76 -33 dirt
execute in minecraft:overworld run setblock 399 77 -33 coarse_dirt
execute in minecraft:overworld run fill 399 78 -33 399 144 -33 air
execute in minecraft:overworld run fill 399 58 -32 399 73 -32 stone
execute in minecraft:overworld run fill 399 74 -32 399 75 -32 dirt
execute in minecraft:overworld run setblock 399 76 -32 coarse_dirt
execute in minecraft:overworld run fill 399 77 -32 399 144 -32 air
execute in minecraft:overworld run fill 399 58 -31 399 73 -31 stone
execute in minecraft:overworld run fill 399 74 -31 399 75 -31 dirt
execute in minecraft:overworld run setblock 399 76 -31 coarse_dirt
execute in minecraft:overworld run fill 399 77 -31 399 144 -31 air
execute in minecraft:overworld run fill 399 58 -30 399 72 -30 stone
execute in minecraft:overworld run fill 399 73 -30 399 74 -30 dirt
execute in minecraft:overworld run setblock 399 75 -30 coarse_dirt
execute in minecraft:overworld run fill 399 76 -30 399 144 -30 air
execute in minecraft:overworld run fill 399 58 -29 399 72 -29 stone
execute in minecraft:overworld run fill 399 73 -29 399 74 -29 dirt
execute in minecraft:overworld run setblock 399 75 -29 coarse_dirt
execute in minecraft:overworld run fill 399 76 -29 399 144 -29 air
execute in minecraft:overworld run fill 399 58 -28 399 71 -28 stone
execute in minecraft:overworld run fill 399 72 -28 399 73 -28 dirt
execute in minecraft:overworld run setblock 399 74 -28 coarse_dirt
execute in minecraft:overworld run fill 399 75 -28 399 144 -28 air
execute in minecraft:overworld run setblock 399 75 -28 grass
execute in minecraft:overworld run fill 399 58 -27 399 71 -27 stone
execute in minecraft:overworld run fill 399 72 -27 399 73 -27 dirt
execute in minecraft:overworld run setblock 399 74 -27 coarse_dirt
execute in minecraft:overworld run fill 399 75 -27 399 144 -27 air
execute in minecraft:overworld run fill 399 58 -26 399 71 -26 stone
execute in minecraft:overworld run fill 399 72 -26 399 73 -26 dirt
execute in minecraft:overworld run setblock 399 74 -26 grass_block
execute in minecraft:overworld run fill 399 75 -26 399 144 -26 air
execute in minecraft:overworld run fill 399 58 -25 399 70 -25 stone
execute in minecraft:overworld run fill 399 71 -25 399 72 -25 dirt
execute in minecraft:overworld run setblock 399 73 -25 coarse_dirt
execute in minecraft:overworld run fill 399 74 -25 399 144 -25 air
execute in minecraft:overworld run fill 399 58 -24 399 70 -24 stone
execute in minecraft:overworld run fill 399 71 -24 399 72 -24 dirt
execute in minecraft:overworld run setblock 399 73 -24 grass_block
execute in minecraft:overworld run fill 399 74 -24 399 144 -24 air
execute in minecraft:overworld run fill 399 58 -23 399 70 -23 stone
execute in minecraft:overworld run fill 399 71 -23 399 72 -23 dirt
execute in minecraft:overworld run setblock 399 73 -23 grass_block
execute in minecraft:overworld run fill 399 74 -23 399 144 -23 air
execute in minecraft:overworld run fill 399 58 -22 399 70 -22 stone
execute in minecraft:overworld run fill 399 71 -22 399 72 -22 dirt
execute in minecraft:overworld run setblock 399 73 -22 coarse_dirt
execute in minecraft:overworld run fill 399 74 -22 399 144 -22 air
execute in minecraft:overworld run fill 399 58 -21 399 69 -21 stone
execute in minecraft:overworld run fill 399 70 -21 399 71 -21 dirt
execute in minecraft:overworld run setblock 399 72 -21 coarse_dirt
execute in minecraft:overworld run fill 399 73 -21 399 144 -21 air
execute in minecraft:overworld run fill 399 58 -20 399 69 -20 stone
execute in minecraft:overworld run fill 399 70 -20 399 71 -20 dirt
execute in minecraft:overworld run setblock 399 72 -20 coarse_dirt
execute in minecraft:overworld run fill 399 73 -20 399 144 -20 air
execute in minecraft:overworld run fill 399 58 -19 399 68 -19 stone
execute in minecraft:overworld run fill 399 69 -19 399 70 -19 dirt
execute in minecraft:overworld run setblock 399 71 -19 grass_block
execute in minecraft:overworld run fill 399 72 -19 399 144 -19 air
execute in minecraft:overworld run fill 399 58 -18 399 68 -18 stone
execute in minecraft:overworld run fill 399 69 -18 399 70 -18 dirt
execute in minecraft:overworld run setblock 399 71 -18 coarse_dirt
execute in minecraft:overworld run fill 399 72 -18 399 144 -18 air
execute in minecraft:overworld run fill 399 58 -17 399 67 -17 stone
execute in minecraft:overworld run fill 399 68 -17 399 69 -17 dirt
execute in minecraft:overworld run setblock 399 70 -17 coarse_dirt
execute in minecraft:overworld run fill 399 71 -17 399 144 -17 air
execute in minecraft:overworld run setblock 399 71 -17 grass
execute in minecraft:overworld run fill 399 58 -16 399 66 -16 stone
execute in minecraft:overworld run fill 399 67 -16 399 68 -16 dirt
execute in minecraft:overworld run setblock 399 69 -16 grass_block
execute in minecraft:overworld run fill 399 70 -16 399 144 -16 air
execute in minecraft:overworld run setblock 399 70 -16 grass
execute in minecraft:overworld run fill 399 58 -15 399 65 -15 stone
execute in minecraft:overworld run fill 399 66 -15 399 67 -15 dirt
execute in minecraft:overworld run setblock 399 68 -15 coarse_dirt
execute in minecraft:overworld run fill 399 69 -15 399 144 -15 air
execute in minecraft:overworld run fill 399 58 -14 399 65 -14 stone
execute in minecraft:overworld run fill 399 66 -14 399 67 -14 dirt
execute in minecraft:overworld run setblock 399 68 -14 coarse_dirt
execute in minecraft:overworld run fill 399 69 -14 399 144 -14 air
execute in minecraft:overworld run fill 399 58 -13 399 64 -13 stone
execute in minecraft:overworld run fill 399 65 -13 399 66 -13 dirt
execute in minecraft:overworld run setblock 399 67 -13 coarse_dirt
execute in minecraft:overworld run fill 399 68 -13 399 144 -13 air
execute in minecraft:overworld run fill 399 58 -12 399 63 -12 stone
execute in minecraft:overworld run fill 399 64 -12 399 65 -12 dirt
execute in minecraft:overworld run setblock 399 66 -12 grass_block
execute in minecraft:overworld run fill 399 67 -12 399 144 -12 air
execute in minecraft:overworld run fill 399 58 -11 399 62 -11 stone
execute in minecraft:overworld run fill 399 63 -11 399 64 -11 dirt
execute in minecraft:overworld run setblock 399 65 -11 coarse_dirt
execute in minecraft:overworld run fill 399 66 -11 399 144 -11 air
execute in minecraft:overworld run fill 399 58 -10 399 62 -10 stone
execute in minecraft:overworld run fill 399 63 -10 399 64 -10 dirt
execute in minecraft:overworld run setblock 399 65 -10 coarse_dirt
execute in minecraft:overworld run fill 399 66 -10 399 144 -10 air
execute in minecraft:overworld run fill 399 58 -9 399 61 -9 stone
execute in minecraft:overworld run fill 399 62 -9 399 63 -9 dirt
execute in minecraft:overworld run setblock 399 64 -9 coarse_dirt
execute in minecraft:overworld run fill 399 65 -9 399 144 -9 air
execute in minecraft:overworld run fill 399 58 -8 399 60 -8 stone
execute in minecraft:overworld run fill 399 61 -8 399 62 -8 dirt
execute in minecraft:overworld run setblock 399 63 -8 gravel
execute in minecraft:overworld run fill 399 64 -8 399 144 -8 air
execute in minecraft:overworld run fill 399 64 -8 399 64 -8 water
execute in minecraft:overworld run fill 399 58 -7 399 60 -7 stone
execute in minecraft:overworld run fill 399 61 -7 399 62 -7 dirt
execute in minecraft:overworld run setblock 399 63 -7 gravel
execute in minecraft:overworld run fill 399 64 -7 399 144 -7 air
execute in minecraft:overworld run fill 399 64 -7 399 64 -7 water
execute in minecraft:overworld run fill 399 58 -6 399 59 -6 stone
execute in minecraft:overworld run fill 399 60 -6 399 61 -6 dirt
execute in minecraft:overworld run setblock 399 62 -6 gravel
execute in minecraft:overworld run fill 399 63 -6 399 144 -6 air
execute in minecraft:overworld run fill 399 63 -6 399 64 -6 water
execute in minecraft:overworld run fill 399 58 -5 399 59 -5 stone
execute in minecraft:overworld run fill 399 60 -5 399 61 -5 dirt
execute in minecraft:overworld run setblock 399 62 -5 gravel
execute in minecraft:overworld run fill 399 63 -5 399 144 -5 air
execute in minecraft:overworld run fill 399 63 -5 399 64 -5 water
execute in minecraft:overworld run fill 399 58 -4 399 58 -4 stone
execute in minecraft:overworld run fill 399 59 -4 399 60 -4 dirt
execute in minecraft:overworld run setblock 399 61 -4 gravel
execute in minecraft:overworld run fill 399 62 -4 399 144 -4 air
execute in minecraft:overworld run fill 399 62 -4 399 64 -4 water
execute in minecraft:overworld run fill 399 58 -3 399 57 -3 stone
execute in minecraft:overworld run fill 399 58 -3 399 59 -3 dirt
execute in minecraft:overworld run setblock 399 60 -3 gravel
execute in minecraft:overworld run fill 399 61 -3 399 144 -3 air
execute in minecraft:overworld run fill 399 61 -3 399 64 -3 water
execute in minecraft:overworld run fill 399 58 -2 399 57 -2 stone
execute in minecraft:overworld run fill 399 58 -2 399 59 -2 dirt
execute in minecraft:overworld run setblock 399 60 -2 gravel
execute in minecraft:overworld run fill 399 61 -2 399 144 -2 air
execute in minecraft:overworld run fill 399 61 -2 399 64 -2 water
execute in minecraft:overworld run fill 399 58 -1 399 56 -1 stone
execute in minecraft:overworld run fill 399 57 -1 399 58 -1 dirt
execute in minecraft:overworld run setblock 399 59 -1 gravel
execute in minecraft:overworld run fill 399 60 -1 399 144 -1 air
execute in minecraft:overworld run fill 399 60 -1 399 64 -1 water
execute in minecraft:overworld run fill 399 58 0 399 56 0 stone
execute in minecraft:overworld run fill 399 57 0 399 58 0 dirt
execute in minecraft:overworld run setblock 399 59 0 gravel
execute in minecraft:overworld run fill 399 60 0 399 144 0 air
execute in minecraft:overworld run fill 399 60 0 399 64 0 water
execute in minecraft:overworld run fill 399 58 1 399 56 1 stone
execute in minecraft:overworld run fill 399 57 1 399 58 1 dirt
execute in minecraft:overworld run setblock 399 59 1 gravel
execute in minecraft:overworld run fill 399 60 1 399 144 1 air
execute in minecraft:overworld run fill 399 60 1 399 64 1 water
execute in minecraft:overworld run fill 399 58 2 399 56 2 stone
execute in minecraft:overworld run fill 399 57 2 399 58 2 dirt
execute in minecraft:overworld run setblock 399 59 2 gravel
execute in minecraft:overworld run fill 399 60 2 399 144 2 air
execute in minecraft:overworld run fill 399 60 2 399 64 2 water
execute in minecraft:overworld run fill 399 58 3 399 56 3 stone
execute in minecraft:overworld run fill 399 57 3 399 58 3 dirt
execute in minecraft:overworld run setblock 399 59 3 gravel
execute in minecraft:overworld run fill 399 60 3 399 144 3 air
execute in minecraft:overworld run fill 399 60 3 399 64 3 water
schedule function blade_gallery:random/battlefield/part_100 1t replace
