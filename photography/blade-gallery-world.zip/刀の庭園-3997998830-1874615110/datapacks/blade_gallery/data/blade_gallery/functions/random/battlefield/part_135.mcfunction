execute in minecraft:overworld run fill 422 58 -46 422 64 -46 stone
execute in minecraft:overworld run fill 422 65 -46 422 66 -46 dirt
execute in minecraft:overworld run setblock 422 67 -46 coarse_dirt
execute in minecraft:overworld run fill 422 68 -46 422 144 -46 air
execute in minecraft:overworld run fill 422 58 -45 422 66 -45 stone
execute in minecraft:overworld run fill 422 67 -45 422 68 -45 dirt
execute in minecraft:overworld run setblock 422 69 -45 coarse_dirt
execute in minecraft:overworld run fill 422 70 -45 422 144 -45 air
execute in minecraft:overworld run fill 422 58 -44 422 67 -44 stone
execute in minecraft:overworld run fill 422 68 -44 422 69 -44 dirt
execute in minecraft:overworld run setblock 422 70 -44 coarse_dirt
execute in minecraft:overworld run fill 422 71 -44 422 144 -44 air
execute in minecraft:overworld run fill 422 58 -43 422 69 -43 stone
execute in minecraft:overworld run fill 422 70 -43 422 71 -43 dirt
execute in minecraft:overworld run setblock 422 72 -43 coarse_dirt
execute in minecraft:overworld run fill 422 73 -43 422 144 -43 air
execute in minecraft:overworld run fill 422 58 -42 422 70 -42 stone
execute in minecraft:overworld run fill 422 71 -42 422 72 -42 dirt
execute in minecraft:overworld run setblock 422 73 -42 coarse_dirt
execute in minecraft:overworld run fill 422 74 -42 422 144 -42 air
execute in minecraft:overworld run fill 422 58 -41 422 72 -41 stone
execute in minecraft:overworld run fill 422 73 -41 422 74 -41 dirt
execute in minecraft:overworld run setblock 422 75 -41 grass_block
execute in minecraft:overworld run fill 422 76 -41 422 144 -41 air
execute in minecraft:overworld run fill 422 58 -40 422 73 -40 stone
execute in minecraft:overworld run fill 422 74 -40 422 75 -40 dirt
execute in minecraft:overworld run setblock 422 76 -40 coarse_dirt
execute in minecraft:overworld run fill 422 77 -40 422 144 -40 air
execute in minecraft:overworld run setblock 422 77 -40 grass
execute in minecraft:overworld run fill 422 58 -39 422 74 -39 stone
execute in minecraft:overworld run fill 422 75 -39 422 76 -39 dirt
execute in minecraft:overworld run setblock 422 77 -39 grass_block
execute in minecraft:overworld run fill 422 78 -39 422 144 -39 air
execute in minecraft:overworld run fill 422 58 -38 422 76 -38 stone
execute in minecraft:overworld run fill 422 77 -38 422 78 -38 dirt
execute in minecraft:overworld run setblock 422 79 -38 coarse_dirt
execute in minecraft:overworld run fill 422 80 -38 422 144 -38 air
execute in minecraft:overworld run fill 422 58 -37 422 75 -37 stone
execute in minecraft:overworld run fill 422 76 -37 422 77 -37 dirt
execute in minecraft:overworld run setblock 422 78 -37 grass_block
execute in minecraft:overworld run fill 422 79 -37 422 144 -37 air
execute in minecraft:overworld run fill 422 58 -36 422 75 -36 stone
execute in minecraft:overworld run fill 422 76 -36 422 77 -36 dirt
execute in minecraft:overworld run setblock 422 78 -36 coarse_dirt
execute in minecraft:overworld run fill 422 79 -36 422 144 -36 air
execute in minecraft:overworld run fill 422 58 -35 422 75 -35 stone
execute in minecraft:overworld run fill 422 76 -35 422 77 -35 dirt
execute in minecraft:overworld run setblock 422 78 -35 coarse_dirt
execute in minecraft:overworld run fill 422 79 -35 422 144 -35 air
execute in minecraft:overworld run fill 422 58 -34 422 74 -34 stone
execute in minecraft:overworld run fill 422 75 -34 422 76 -34 dirt
execute in minecraft:overworld run setblock 422 77 -34 coarse_dirt
execute in minecraft:overworld run fill 422 78 -34 422 144 -34 air
execute in minecraft:overworld run fill 422 58 -33 422 74 -33 stone
execute in minecraft:overworld run fill 422 75 -33 422 76 -33 dirt
execute in minecraft:overworld run setblock 422 77 -33 coarse_dirt
execute in minecraft:overworld run fill 422 78 -33 422 144 -33 air
execute in minecraft:overworld run fill 422 58 -32 422 73 -32 stone
execute in minecraft:overworld run fill 422 74 -32 422 75 -32 dirt
execute in minecraft:overworld run setblock 422 76 -32 grass_block
execute in minecraft:overworld run fill 422 77 -32 422 144 -32 air
execute in minecraft:overworld run fill 422 58 -31 422 73 -31 stone
execute in minecraft:overworld run fill 422 74 -31 422 75 -31 dirt
execute in minecraft:overworld run setblock 422 76 -31 coarse_dirt
execute in minecraft:overworld run fill 422 77 -31 422 144 -31 air
execute in minecraft:overworld run fill 422 58 -30 422 72 -30 stone
execute in minecraft:overworld run fill 422 73 -30 422 74 -30 dirt
execute in minecraft:overworld run setblock 422 75 -30 coarse_dirt
execute in minecraft:overworld run fill 422 76 -30 422 144 -30 air
execute in minecraft:overworld run fill 422 58 -29 422 72 -29 stone
execute in minecraft:overworld run fill 422 73 -29 422 74 -29 dirt
execute in minecraft:overworld run setblock 422 75 -29 grass_block
execute in minecraft:overworld run fill 422 76 -29 422 144 -29 air
execute in minecraft:overworld run fill 422 58 -28 422 72 -28 stone
execute in minecraft:overworld run fill 422 73 -28 422 74 -28 dirt
execute in minecraft:overworld run setblock 422 75 -28 coarse_dirt
execute in minecraft:overworld run fill 422 76 -28 422 144 -28 air
execute in minecraft:overworld run fill 422 58 -27 422 71 -27 stone
execute in minecraft:overworld run fill 422 72 -27 422 73 -27 dirt
execute in minecraft:overworld run setblock 422 74 -27 coarse_dirt
execute in minecraft:overworld run fill 422 75 -27 422 144 -27 air
execute in minecraft:overworld run fill 422 58 -26 422 71 -26 stone
execute in minecraft:overworld run fill 422 72 -26 422 73 -26 dirt
execute in minecraft:overworld run setblock 422 74 -26 coarse_dirt
execute in minecraft:overworld run fill 422 75 -26 422 144 -26 air
execute in minecraft:overworld run fill 422 58 -25 422 71 -25 stone
execute in minecraft:overworld run fill 422 72 -25 422 73 -25 dirt
execute in minecraft:overworld run setblock 422 74 -25 grass_block
execute in minecraft:overworld run fill 422 75 -25 422 144 -25 air
execute in minecraft:overworld run setblock 422 75 -25 grass
execute in minecraft:overworld run fill 422 58 -24 422 70 -24 stone
execute in minecraft:overworld run fill 422 71 -24 422 72 -24 dirt
execute in minecraft:overworld run setblock 422 73 -24 coarse_dirt
execute in minecraft:overworld run fill 422 74 -24 422 144 -24 air
execute in minecraft:overworld run fill 422 58 -23 422 70 -23 stone
execute in minecraft:overworld run fill 422 71 -23 422 72 -23 dirt
execute in minecraft:overworld run setblock 422 73 -23 coarse_dirt
execute in minecraft:overworld run fill 422 74 -23 422 144 -23 air
execute in minecraft:overworld run fill 422 58 -22 422 70 -22 stone
execute in minecraft:overworld run fill 422 71 -22 422 72 -22 dirt
execute in minecraft:overworld run setblock 422 73 -22 coarse_dirt
execute in minecraft:overworld run fill 422 74 -22 422 144 -22 air
execute in minecraft:overworld run fill 422 58 -21 422 69 -21 stone
execute in minecraft:overworld run fill 422 70 -21 422 71 -21 dirt
execute in minecraft:overworld run setblock 422 72 -21 coarse_dirt
execute in minecraft:overworld run fill 422 73 -21 422 144 -21 air
execute in minecraft:overworld run fill 422 58 -20 422 69 -20 stone
execute in minecraft:overworld run fill 422 70 -20 422 71 -20 dirt
execute in minecraft:overworld run setblock 422 72 -20 coarse_dirt
execute in minecraft:overworld run fill 422 73 -20 422 144 -20 air
execute in minecraft:overworld run fill 422 58 -19 422 69 -19 stone
execute in minecraft:overworld run fill 422 70 -19 422 71 -19 dirt
execute in minecraft:overworld run setblock 422 72 -19 grass_block
execute in minecraft:overworld run fill 422 73 -19 422 144 -19 air
execute in minecraft:overworld run setblock 422 73 -19 grass
execute in minecraft:overworld run fill 422 58 -18 422 68 -18 stone
execute in minecraft:overworld run fill 422 69 -18 422 70 -18 dirt
execute in minecraft:overworld run setblock 422 71 -18 coarse_dirt
execute in minecraft:overworld run fill 422 72 -18 422 144 -18 air
execute in minecraft:overworld run fill 422 58 -17 422 68 -17 stone
execute in minecraft:overworld run fill 422 69 -17 422 70 -17 dirt
execute in minecraft:overworld run setblock 422 71 -17 coarse_dirt
execute in minecraft:overworld run fill 422 72 -17 422 144 -17 air
execute in minecraft:overworld run fill 422 58 -16 422 67 -16 stone
execute in minecraft:overworld run fill 422 68 -16 422 69 -16 dirt
execute in minecraft:overworld run setblock 422 70 -16 grass_block
execute in minecraft:overworld run fill 422 71 -16 422 144 -16 air
execute in minecraft:overworld run setblock 422 71 -16 grass
execute in minecraft:overworld run fill 422 58 -15 422 67 -15 stone
execute in minecraft:overworld run fill 422 68 -15 422 69 -15 dirt
execute in minecraft:overworld run setblock 422 70 -15 grass_block
execute in minecraft:overworld run fill 422 71 -15 422 144 -15 air
execute in minecraft:overworld run setblock 422 71 -15 mossy_cobblestone
execute in minecraft:overworld run fill 422 58 -14 422 67 -14 stone
execute in minecraft:overworld run fill 422 68 -14 422 69 -14 dirt
execute in minecraft:overworld run setblock 422 70 -14 grass_block
execute in minecraft:overworld run fill 422 71 -14 422 144 -14 air
execute in minecraft:overworld run fill 422 58 -13 422 66 -13 stone
execute in minecraft:overworld run fill 422 67 -13 422 68 -13 dirt
execute in minecraft:overworld run setblock 422 69 -13 grass_block
execute in minecraft:overworld run fill 422 70 -13 422 144 -13 air
execute in minecraft:overworld run fill 422 58 -12 422 66 -12 stone
execute in minecraft:overworld run fill 422 67 -12 422 68 -12 dirt
execute in minecraft:overworld run setblock 422 69 -12 coarse_dirt
execute in minecraft:overworld run fill 422 70 -12 422 144 -12 air
execute in minecraft:overworld run fill 422 58 -11 422 66 -11 stone
execute in minecraft:overworld run fill 422 67 -11 422 68 -11 dirt
execute in minecraft:overworld run setblock 422 69 -11 grass_block
execute in minecraft:overworld run fill 422 70 -11 422 144 -11 air
execute in minecraft:overworld run fill 422 58 -10 422 66 -10 stone
execute in minecraft:overworld run fill 422 67 -10 422 68 -10 dirt
execute in minecraft:overworld run setblock 422 69 -10 coarse_dirt
execute in minecraft:overworld run fill 422 70 -10 422 144 -10 air
execute in minecraft:overworld run fill 422 58 -9 422 65 -9 stone
execute in minecraft:overworld run fill 422 66 -9 422 67 -9 dirt
execute in minecraft:overworld run setblock 422 68 -9 coarse_dirt
execute in minecraft:overworld run fill 422 69 -9 422 144 -9 air
execute in minecraft:overworld run fill 422 58 -8 422 65 -8 stone
execute in minecraft:overworld run fill 422 66 -8 422 67 -8 dirt
execute in minecraft:overworld run setblock 422 68 -8 coarse_dirt
execute in minecraft:overworld run fill 422 69 -8 422 144 -8 air
execute in minecraft:overworld run fill 422 58 -7 422 65 -7 stone
execute in minecraft:overworld run fill 422 66 -7 422 67 -7 dirt
execute in minecraft:overworld run setblock 422 68 -7 coarse_dirt
execute in minecraft:overworld run fill 422 69 -7 422 144 -7 air
execute in minecraft:overworld run fill 422 58 -6 422 65 -6 stone
execute in minecraft:overworld run fill 422 66 -6 422 67 -6 dirt
execute in minecraft:overworld run setblock 422 68 -6 coarse_dirt
execute in minecraft:overworld run fill 422 69 -6 422 144 -6 air
execute in minecraft:overworld run setblock 422 69 -6 grass
execute in minecraft:overworld run fill 422 58 -5 422 65 -5 stone
execute in minecraft:overworld run fill 422 66 -5 422 67 -5 dirt
execute in minecraft:overworld run setblock 422 68 -5 grass_block
execute in minecraft:overworld run fill 422 69 -5 422 144 -5 air
execute in minecraft:overworld run setblock 422 69 -5 grass
execute in minecraft:overworld run fill 422 58 -4 422 64 -4 stone
execute in minecraft:overworld run fill 422 65 -4 422 66 -4 dirt
execute in minecraft:overworld run setblock 422 67 -4 coarse_dirt
execute in minecraft:overworld run fill 422 68 -4 422 144 -4 air
execute in minecraft:overworld run fill 422 58 -3 422 64 -3 stone
execute in minecraft:overworld run fill 422 65 -3 422 66 -3 dirt
execute in minecraft:overworld run setblock 422 67 -3 coarse_dirt
execute in minecraft:overworld run fill 422 68 -3 422 144 -3 air
execute in minecraft:overworld run fill 422 58 -2 422 64 -2 stone
execute in minecraft:overworld run fill 422 65 -2 422 66 -2 dirt
execute in minecraft:overworld run setblock 422 67 -2 coarse_dirt
execute in minecraft:overworld run fill 422 68 -2 422 144 -2 air
execute in minecraft:overworld run fill 422 58 -1 422 64 -1 stone
execute in minecraft:overworld run fill 422 65 -1 422 66 -1 dirt
execute in minecraft:overworld run setblock 422 67 -1 grass_block
execute in minecraft:overworld run fill 422 68 -1 422 144 -1 air
execute in minecraft:overworld run fill 422 58 0 422 64 0 stone
execute in minecraft:overworld run fill 422 65 0 422 66 0 dirt
execute in minecraft:overworld run setblock 422 67 0 grass_block
execute in minecraft:overworld run fill 422 68 0 422 144 0 air
execute in minecraft:overworld run fill 422 58 1 422 64 1 stone
execute in minecraft:overworld run fill 422 65 1 422 66 1 dirt
execute in minecraft:overworld run setblock 422 67 1 coarse_dirt
execute in minecraft:overworld run fill 422 68 1 422 144 1 air
execute in minecraft:overworld run fill 422 58 2 422 64 2 stone
execute in minecraft:overworld run fill 422 65 2 422 66 2 dirt
execute in minecraft:overworld run setblock 422 67 2 coarse_dirt
execute in minecraft:overworld run fill 422 68 2 422 144 2 air
execute in minecraft:overworld run fill 422 58 3 422 64 3 stone
execute in minecraft:overworld run fill 422 65 3 422 66 3 dirt
execute in minecraft:overworld run setblock 422 67 3 coarse_dirt
execute in minecraft:overworld run fill 422 68 3 422 144 3 air
execute in minecraft:overworld run fill 422 58 4 422 64 4 stone
execute in minecraft:overworld run fill 422 65 4 422 66 4 dirt
execute in minecraft:overworld run setblock 422 67 4 coarse_dirt
execute in minecraft:overworld run fill 422 68 4 422 144 4 air
execute in minecraft:overworld run fill 422 58 5 422 64 5 stone
execute in minecraft:overworld run fill 422 65 5 422 66 5 dirt
execute in minecraft:overworld run setblock 422 67 5 coarse_dirt
execute in minecraft:overworld run fill 422 68 5 422 144 5 air
execute in minecraft:overworld run fill 422 58 6 422 65 6 stone
execute in minecraft:overworld run fill 422 66 6 422 67 6 dirt
execute in minecraft:overworld run setblock 422 68 6 grass_block
execute in minecraft:overworld run fill 422 69 6 422 144 6 air
execute in minecraft:overworld run fill 422 58 7 422 65 7 stone
execute in minecraft:overworld run fill 422 66 7 422 67 7 dirt
execute in minecraft:overworld run setblock 422 68 7 coarse_dirt
execute in minecraft:overworld run fill 422 69 7 422 144 7 air
execute in minecraft:overworld run fill 422 58 8 422 65 8 stone
execute in minecraft:overworld run fill 422 66 8 422 67 8 dirt
execute in minecraft:overworld run setblock 422 68 8 coarse_dirt
execute in minecraft:overworld run fill 422 69 8 422 144 8 air
execute in minecraft:overworld run fill 422 58 9 422 66 9 stone
execute in minecraft:overworld run fill 422 67 9 422 68 9 dirt
execute in minecraft:overworld run setblock 422 69 9 coarse_dirt
execute in minecraft:overworld run fill 422 70 9 422 144 9 air
execute in minecraft:overworld run fill 422 58 10 422 66 10 stone
execute in minecraft:overworld run fill 422 67 10 422 68 10 dirt
execute in minecraft:overworld run setblock 422 69 10 coarse_dirt
execute in minecraft:overworld run fill 422 70 10 422 144 10 air
execute in minecraft:overworld run fill 422 58 11 422 66 11 stone
execute in minecraft:overworld run fill 422 67 11 422 68 11 dirt
execute in minecraft:overworld run setblock 422 69 11 coarse_dirt
execute in minecraft:overworld run fill 422 70 11 422 144 11 air
execute in minecraft:overworld run fill 422 58 12 422 67 12 stone
execute in minecraft:overworld run fill 422 68 12 422 69 12 dirt
execute in minecraft:overworld run setblock 422 70 12 coarse_dirt
execute in minecraft:overworld run fill 422 71 12 422 144 12 air
execute in minecraft:overworld run fill 422 58 13 422 67 13 stone
execute in minecraft:overworld run fill 422 68 13 422 69 13 dirt
execute in minecraft:overworld run setblock 422 70 13 coarse_dirt
execute in minecraft:overworld run fill 422 71 13 422 144 13 air
execute in minecraft:overworld run fill 422 58 14 422 68 14 stone
execute in minecraft:overworld run fill 422 69 14 422 70 14 dirt
execute in minecraft:overworld run setblock 422 71 14 coarse_dirt
execute in minecraft:overworld run fill 422 72 14 422 144 14 air
execute in minecraft:overworld run fill 422 58 15 422 68 15 stone
execute in minecraft:overworld run fill 422 69 15 422 70 15 dirt
execute in minecraft:overworld run setblock 422 71 15 coarse_dirt
execute in minecraft:overworld run fill 422 72 15 422 144 15 air
execute in minecraft:overworld run fill 422 58 16 422 69 16 stone
schedule function blade_gallery:random/battlefield/part_136 1t replace
