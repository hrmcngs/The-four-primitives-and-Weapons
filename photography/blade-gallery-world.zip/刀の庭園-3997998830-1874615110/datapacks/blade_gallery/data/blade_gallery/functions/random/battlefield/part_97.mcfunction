execute in minecraft:overworld run fill 397 62 20 397 64 20 water
execute in minecraft:overworld run fill 397 58 21 397 58 21 stone
execute in minecraft:overworld run fill 397 59 21 397 60 21 dirt
execute in minecraft:overworld run setblock 397 61 21 gravel
execute in minecraft:overworld run fill 397 62 21 397 144 21 air
execute in minecraft:overworld run fill 397 62 21 397 64 21 water
execute in minecraft:overworld run fill 397 58 22 397 58 22 stone
execute in minecraft:overworld run fill 397 59 22 397 60 22 dirt
execute in minecraft:overworld run setblock 397 61 22 gravel
execute in minecraft:overworld run fill 397 62 22 397 144 22 air
execute in minecraft:overworld run fill 397 62 22 397 64 22 water
execute in minecraft:overworld run fill 397 58 23 397 59 23 stone
execute in minecraft:overworld run fill 397 60 23 397 61 23 dirt
execute in minecraft:overworld run setblock 397 62 23 gravel
execute in minecraft:overworld run fill 397 63 23 397 144 23 air
execute in minecraft:overworld run fill 397 63 23 397 64 23 water
execute in minecraft:overworld run fill 397 58 24 397 59 24 stone
execute in minecraft:overworld run fill 397 60 24 397 61 24 dirt
execute in minecraft:overworld run setblock 397 62 24 gravel
execute in minecraft:overworld run fill 397 63 24 397 144 24 air
execute in minecraft:overworld run fill 397 63 24 397 64 24 water
execute in minecraft:overworld run fill 397 58 25 397 59 25 stone
execute in minecraft:overworld run fill 397 60 25 397 61 25 dirt
execute in minecraft:overworld run setblock 397 62 25 gravel
execute in minecraft:overworld run fill 397 63 25 397 144 25 air
execute in minecraft:overworld run fill 397 63 25 397 64 25 water
execute in minecraft:overworld run fill 397 58 26 397 59 26 stone
execute in minecraft:overworld run fill 397 60 26 397 61 26 dirt
execute in minecraft:overworld run setblock 397 62 26 gravel
execute in minecraft:overworld run fill 397 63 26 397 144 26 air
execute in minecraft:overworld run fill 397 63 26 397 64 26 water
execute in minecraft:overworld run fill 397 58 27 397 59 27 stone
execute in minecraft:overworld run fill 397 60 27 397 61 27 dirt
execute in minecraft:overworld run setblock 397 62 27 gravel
execute in minecraft:overworld run fill 397 63 27 397 144 27 air
execute in minecraft:overworld run fill 397 63 27 397 64 27 water
execute in minecraft:overworld run fill 397 58 28 397 60 28 stone
execute in minecraft:overworld run fill 397 61 28 397 62 28 dirt
execute in minecraft:overworld run setblock 397 63 28 gravel
execute in minecraft:overworld run fill 397 64 28 397 144 28 air
execute in minecraft:overworld run fill 397 64 28 397 64 28 water
execute in minecraft:overworld run fill 397 58 29 397 60 29 stone
execute in minecraft:overworld run fill 397 61 29 397 62 29 dirt
execute in minecraft:overworld run setblock 397 63 29 gravel
execute in minecraft:overworld run fill 397 64 29 397 144 29 air
execute in minecraft:overworld run fill 397 64 29 397 64 29 water
execute in minecraft:overworld run fill 397 58 30 397 60 30 stone
execute in minecraft:overworld run fill 397 61 30 397 62 30 dirt
execute in minecraft:overworld run setblock 397 63 30 gravel
execute in minecraft:overworld run fill 397 64 30 397 144 30 air
execute in minecraft:overworld run fill 397 64 30 397 64 30 water
execute in minecraft:overworld run fill 397 58 31 397 61 31 stone
execute in minecraft:overworld run fill 397 62 31 397 63 31 dirt
execute in minecraft:overworld run setblock 397 64 31 coarse_dirt
execute in minecraft:overworld run fill 397 65 31 397 144 31 air
execute in minecraft:overworld run fill 397 58 32 397 61 32 stone
execute in minecraft:overworld run fill 397 62 32 397 63 32 dirt
execute in minecraft:overworld run setblock 397 64 32 grass_block
execute in minecraft:overworld run fill 397 65 32 397 144 32 air
execute in minecraft:overworld run fill 397 58 33 397 61 33 stone
execute in minecraft:overworld run fill 397 62 33 397 63 33 dirt
execute in minecraft:overworld run setblock 397 64 33 grass_block
execute in minecraft:overworld run fill 397 65 33 397 144 33 air
execute in minecraft:overworld run fill 397 58 34 397 62 34 stone
execute in minecraft:overworld run fill 397 63 34 397 64 34 dirt
execute in minecraft:overworld run setblock 397 65 34 grass_block
execute in minecraft:overworld run fill 397 66 34 397 144 34 air
execute in minecraft:overworld run fill 397 58 35 397 62 35 stone
execute in minecraft:overworld run fill 397 63 35 397 64 35 dirt
execute in minecraft:overworld run setblock 397 65 35 coarse_dirt
execute in minecraft:overworld run fill 397 66 35 397 144 35 air
execute in minecraft:overworld run setblock 397 66 35 grass
execute in minecraft:overworld run fill 397 58 36 397 63 36 stone
execute in minecraft:overworld run fill 397 64 36 397 65 36 dirt
execute in minecraft:overworld run setblock 397 66 36 grass_block
execute in minecraft:overworld run fill 397 67 36 397 144 36 air
execute in minecraft:overworld run fill 397 58 37 397 64 37 stone
execute in minecraft:overworld run fill 397 65 37 397 66 37 dirt
execute in minecraft:overworld run setblock 397 67 37 coarse_dirt
execute in minecraft:overworld run fill 397 68 37 397 144 37 air
execute in minecraft:overworld run fill 397 58 38 397 64 38 stone
execute in minecraft:overworld run fill 397 65 38 397 66 38 dirt
execute in minecraft:overworld run setblock 397 67 38 grass_block
execute in minecraft:overworld run fill 397 68 38 397 144 38 air
execute in minecraft:overworld run fill 397 58 39 397 65 39 stone
execute in minecraft:overworld run fill 397 66 39 397 67 39 dirt
execute in minecraft:overworld run setblock 397 68 39 coarse_dirt
execute in minecraft:overworld run fill 397 69 39 397 144 39 air
execute in minecraft:overworld run fill 397 58 40 397 65 40 stone
execute in minecraft:overworld run fill 397 66 40 397 67 40 dirt
execute in minecraft:overworld run setblock 397 68 40 grass_block
execute in minecraft:overworld run fill 397 69 40 397 144 40 air
execute in minecraft:overworld run fill 397 58 41 397 65 41 stone
execute in minecraft:overworld run fill 397 66 41 397 67 41 dirt
execute in minecraft:overworld run setblock 397 68 41 grass_block
execute in minecraft:overworld run fill 397 69 41 397 144 41 air
execute in minecraft:overworld run fill 397 58 42 397 65 42 stone
execute in minecraft:overworld run fill 397 66 42 397 67 42 dirt
execute in minecraft:overworld run setblock 397 68 42 coarse_dirt
execute in minecraft:overworld run fill 397 69 42 397 144 42 air
execute in minecraft:overworld run fill 397 58 43 397 64 43 stone
execute in minecraft:overworld run fill 397 65 43 397 66 43 dirt
execute in minecraft:overworld run setblock 397 67 43 grass_block
execute in minecraft:overworld run fill 397 68 43 397 144 43 air
execute in minecraft:overworld run fill 397 58 44 397 64 44 stone
execute in minecraft:overworld run fill 397 65 44 397 66 44 dirt
execute in minecraft:overworld run setblock 397 67 44 coarse_dirt
execute in minecraft:overworld run fill 397 68 44 397 144 44 air
execute in minecraft:overworld run fill 397 58 45 397 63 45 stone
execute in minecraft:overworld run fill 397 64 45 397 65 45 dirt
execute in minecraft:overworld run setblock 397 66 45 coarse_dirt
execute in minecraft:overworld run fill 397 67 45 397 144 45 air
execute in minecraft:overworld run fill 397 58 46 397 63 46 stone
execute in minecraft:overworld run fill 397 64 46 397 65 46 dirt
execute in minecraft:overworld run setblock 397 66 46 grass_block
execute in minecraft:overworld run fill 397 67 46 397 144 46 air
execute in minecraft:overworld run fill 397 58 47 397 62 47 stone
execute in minecraft:overworld run fill 397 63 47 397 64 47 dirt
execute in minecraft:overworld run setblock 397 65 47 coarse_dirt
execute in minecraft:overworld run fill 397 66 47 397 144 47 air
execute in minecraft:overworld run fill 398 58 -48 398 61 -48 stone
execute in minecraft:overworld run fill 398 62 -48 398 63 -48 dirt
execute in minecraft:overworld run setblock 398 64 -48 grass_block
execute in minecraft:overworld run fill 398 65 -48 398 144 -48 air
execute in minecraft:overworld run fill 398 58 -47 398 62 -47 stone
execute in minecraft:overworld run fill 398 63 -47 398 64 -47 dirt
execute in minecraft:overworld run setblock 398 65 -47 coarse_dirt
execute in minecraft:overworld run fill 398 66 -47 398 144 -47 air
execute in minecraft:overworld run fill 398 58 -46 398 64 -46 stone
execute in minecraft:overworld run fill 398 65 -46 398 66 -46 dirt
execute in minecraft:overworld run setblock 398 67 -46 grass_block
execute in minecraft:overworld run fill 398 68 -46 398 144 -46 air
execute in minecraft:overworld run fill 398 58 -45 398 65 -45 stone
execute in minecraft:overworld run fill 398 66 -45 398 67 -45 dirt
execute in minecraft:overworld run setblock 398 68 -45 coarse_dirt
execute in minecraft:overworld run fill 398 69 -45 398 144 -45 air
execute in minecraft:overworld run fill 398 58 -44 398 66 -44 stone
execute in minecraft:overworld run fill 398 67 -44 398 68 -44 dirt
execute in minecraft:overworld run setblock 398 69 -44 coarse_dirt
execute in minecraft:overworld run fill 398 70 -44 398 144 -44 air
execute in minecraft:overworld run fill 398 58 -43 398 68 -43 stone
execute in minecraft:overworld run fill 398 69 -43 398 70 -43 dirt
execute in minecraft:overworld run setblock 398 71 -43 coarse_dirt
execute in minecraft:overworld run fill 398 72 -43 398 144 -43 air
execute in minecraft:overworld run fill 398 58 -42 398 69 -42 stone
execute in minecraft:overworld run fill 398 70 -42 398 71 -42 dirt
execute in minecraft:overworld run setblock 398 72 -42 grass_block
execute in minecraft:overworld run fill 398 73 -42 398 144 -42 air
execute in minecraft:overworld run fill 398 58 -41 398 70 -41 stone
execute in minecraft:overworld run fill 398 71 -41 398 72 -41 dirt
execute in minecraft:overworld run setblock 398 73 -41 coarse_dirt
execute in minecraft:overworld run fill 398 74 -41 398 144 -41 air
execute in minecraft:overworld run fill 398 58 -40 398 72 -40 stone
execute in minecraft:overworld run fill 398 73 -40 398 74 -40 dirt
execute in minecraft:overworld run setblock 398 75 -40 coarse_dirt
execute in minecraft:overworld run fill 398 76 -40 398 144 -40 air
execute in minecraft:overworld run fill 398 58 -39 398 73 -39 stone
execute in minecraft:overworld run fill 398 74 -39 398 75 -39 dirt
execute in minecraft:overworld run setblock 398 76 -39 coarse_dirt
execute in minecraft:overworld run fill 398 77 -39 398 144 -39 air
execute in minecraft:overworld run fill 398 58 -38 398 74 -38 stone
execute in minecraft:overworld run fill 398 75 -38 398 76 -38 dirt
execute in minecraft:overworld run setblock 398 77 -38 grass_block
execute in minecraft:overworld run fill 398 78 -38 398 144 -38 air
execute in minecraft:overworld run fill 398 58 -37 398 74 -37 stone
execute in minecraft:overworld run fill 398 75 -37 398 76 -37 dirt
execute in minecraft:overworld run setblock 398 77 -37 grass_block
execute in minecraft:overworld run fill 398 78 -37 398 144 -37 air
execute in minecraft:overworld run fill 398 58 -36 398 74 -36 stone
execute in minecraft:overworld run fill 398 75 -36 398 76 -36 dirt
execute in minecraft:overworld run setblock 398 77 -36 grass_block
execute in minecraft:overworld run fill 398 78 -36 398 144 -36 air
execute in minecraft:overworld run fill 398 58 -35 398 74 -35 stone
execute in minecraft:overworld run fill 398 75 -35 398 76 -35 dirt
execute in minecraft:overworld run setblock 398 77 -35 grass_block
execute in minecraft:overworld run fill 398 78 -35 398 144 -35 air
execute in minecraft:overworld run fill 398 58 -34 398 74 -34 stone
execute in minecraft:overworld run fill 398 75 -34 398 76 -34 dirt
execute in minecraft:overworld run setblock 398 77 -34 coarse_dirt
execute in minecraft:overworld run fill 398 78 -34 398 144 -34 air
execute in minecraft:overworld run setblock 398 78 -34 grass
execute in minecraft:overworld run fill 398 58 -33 398 73 -33 stone
execute in minecraft:overworld run fill 398 74 -33 398 75 -33 dirt
execute in minecraft:overworld run setblock 398 76 -33 grass_block
execute in minecraft:overworld run fill 398 77 -33 398 144 -33 air
execute in minecraft:overworld run fill 398 58 -32 398 73 -32 stone
execute in minecraft:overworld run fill 398 74 -32 398 75 -32 dirt
execute in minecraft:overworld run setblock 398 76 -32 coarse_dirt
execute in minecraft:overworld run fill 398 77 -32 398 144 -32 air
execute in minecraft:overworld run fill 398 58 -31 398 73 -31 stone
execute in minecraft:overworld run fill 398 74 -31 398 75 -31 dirt
execute in minecraft:overworld run setblock 398 76 -31 coarse_dirt
execute in minecraft:overworld run fill 398 77 -31 398 144 -31 air
execute in minecraft:overworld run setblock 398 77 -31 grass
execute in minecraft:overworld run fill 398 58 -30 398 72 -30 stone
execute in minecraft:overworld run fill 398 73 -30 398 74 -30 dirt
execute in minecraft:overworld run setblock 398 75 -30 grass_block
execute in minecraft:overworld run fill 398 76 -30 398 144 -30 air
execute in minecraft:overworld run fill 398 58 -29 398 72 -29 stone
execute in minecraft:overworld run fill 398 73 -29 398 74 -29 dirt
execute in minecraft:overworld run setblock 398 75 -29 coarse_dirt
execute in minecraft:overworld run fill 398 76 -29 398 144 -29 air
execute in minecraft:overworld run fill 398 58 -28 398 71 -28 stone
execute in minecraft:overworld run fill 398 72 -28 398 73 -28 dirt
execute in minecraft:overworld run setblock 398 74 -28 coarse_dirt
execute in minecraft:overworld run fill 398 75 -28 398 144 -28 air
execute in minecraft:overworld run fill 398 58 -27 398 71 -27 stone
execute in minecraft:overworld run fill 398 72 -27 398 73 -27 dirt
execute in minecraft:overworld run setblock 398 74 -27 grass_block
execute in minecraft:overworld run fill 398 75 -27 398 144 -27 air
execute in minecraft:overworld run fill 398 58 -26 398 70 -26 stone
execute in minecraft:overworld run fill 398 71 -26 398 72 -26 dirt
execute in minecraft:overworld run setblock 398 73 -26 coarse_dirt
execute in minecraft:overworld run fill 398 74 -26 398 144 -26 air
execute in minecraft:overworld run fill 398 58 -25 398 70 -25 stone
execute in minecraft:overworld run fill 398 71 -25 398 72 -25 dirt
execute in minecraft:overworld run setblock 398 73 -25 coarse_dirt
execute in minecraft:overworld run fill 398 74 -25 398 144 -25 air
execute in minecraft:overworld run fill 398 58 -24 398 70 -24 stone
execute in minecraft:overworld run fill 398 71 -24 398 72 -24 dirt
execute in minecraft:overworld run setblock 398 73 -24 coarse_dirt
execute in minecraft:overworld run fill 398 74 -24 398 144 -24 air
execute in minecraft:overworld run fill 398 58 -23 398 70 -23 stone
execute in minecraft:overworld run fill 398 71 -23 398 72 -23 dirt
execute in minecraft:overworld run setblock 398 73 -23 coarse_dirt
execute in minecraft:overworld run fill 398 74 -23 398 144 -23 air
execute in minecraft:overworld run fill 398 58 -22 398 69 -22 stone
execute in minecraft:overworld run fill 398 70 -22 398 71 -22 dirt
execute in minecraft:overworld run setblock 398 72 -22 grass_block
execute in minecraft:overworld run fill 398 73 -22 398 144 -22 air
execute in minecraft:overworld run fill 398 58 -21 398 69 -21 stone
execute in minecraft:overworld run fill 398 70 -21 398 71 -21 dirt
execute in minecraft:overworld run setblock 398 72 -21 coarse_dirt
execute in minecraft:overworld run fill 398 73 -21 398 144 -21 air
execute in minecraft:overworld run fill 398 58 -20 398 69 -20 stone
execute in minecraft:overworld run fill 398 70 -20 398 71 -20 dirt
execute in minecraft:overworld run setblock 398 72 -20 coarse_dirt
execute in minecraft:overworld run fill 398 73 -20 398 144 -20 air
execute in minecraft:overworld run fill 398 58 -19 398 68 -19 stone
execute in minecraft:overworld run fill 398 69 -19 398 70 -19 dirt
execute in minecraft:overworld run setblock 398 71 -19 coarse_dirt
execute in minecraft:overworld run fill 398 72 -19 398 144 -19 air
execute in minecraft:overworld run fill 398 58 -18 398 67 -18 stone
execute in minecraft:overworld run fill 398 68 -18 398 69 -18 dirt
execute in minecraft:overworld run setblock 398 70 -18 coarse_dirt
execute in minecraft:overworld run fill 398 71 -18 398 144 -18 air
execute in minecraft:overworld run fill 398 58 -17 398 67 -17 stone
execute in minecraft:overworld run fill 398 68 -17 398 69 -17 dirt
execute in minecraft:overworld run setblock 398 70 -17 grass_block
execute in minecraft:overworld run fill 398 71 -17 398 144 -17 air
execute in minecraft:overworld run fill 398 58 -16 398 66 -16 stone
execute in minecraft:overworld run fill 398 67 -16 398 68 -16 dirt
execute in minecraft:overworld run setblock 398 69 -16 coarse_dirt
execute in minecraft:overworld run fill 398 70 -16 398 144 -16 air
execute in minecraft:overworld run setblock 398 70 -16 mossy_cobblestone
execute in minecraft:overworld run fill 398 58 -15 398 65 -15 stone
schedule function blade_gallery:random/battlefield/part_98 1t replace
