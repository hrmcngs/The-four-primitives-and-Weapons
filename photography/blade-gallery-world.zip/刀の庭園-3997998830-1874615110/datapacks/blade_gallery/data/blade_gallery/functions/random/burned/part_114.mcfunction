execute in minecraft:overworld run fill 279 65 40 279 144 40 air
execute in minecraft:overworld run fill 279 58 41 279 61 41 stone
execute in minecraft:overworld run fill 279 62 41 279 63 41 dirt
execute in minecraft:overworld run setblock 279 64 41 coarse_dirt
execute in minecraft:overworld run fill 279 65 41 279 144 41 air
execute in minecraft:overworld run fill 279 58 42 279 61 42 stone
execute in minecraft:overworld run fill 279 62 42 279 63 42 dirt
execute in minecraft:overworld run setblock 279 64 42 coarse_dirt
execute in minecraft:overworld run fill 279 65 42 279 144 42 air
execute in minecraft:overworld run fill 279 58 43 279 61 43 stone
execute in minecraft:overworld run fill 279 62 43 279 63 43 dirt
execute in minecraft:overworld run setblock 279 64 43 grass_block
execute in minecraft:overworld run fill 279 65 43 279 144 43 air
execute in minecraft:overworld run fill 279 58 44 279 61 44 stone
execute in minecraft:overworld run fill 279 62 44 279 63 44 dirt
execute in minecraft:overworld run setblock 279 64 44 coarse_dirt
execute in minecraft:overworld run fill 279 65 44 279 144 44 air
execute in minecraft:overworld run fill 279 58 45 279 61 45 stone
execute in minecraft:overworld run fill 279 62 45 279 63 45 dirt
execute in minecraft:overworld run setblock 279 64 45 grass_block
execute in minecraft:overworld run fill 279 65 45 279 144 45 air
execute in minecraft:overworld run fill 279 58 46 279 61 46 stone
execute in minecraft:overworld run fill 279 62 46 279 63 46 dirt
execute in minecraft:overworld run setblock 279 64 46 coarse_dirt
execute in minecraft:overworld run fill 279 65 46 279 144 46 air
execute in minecraft:overworld run fill 279 58 47 279 61 47 stone
execute in minecraft:overworld run fill 279 62 47 279 63 47 dirt
execute in minecraft:overworld run setblock 279 64 47 coarse_dirt
execute in minecraft:overworld run fill 279 65 47 279 144 47 air
execute in minecraft:overworld run fill 280 58 -48 280 61 -48 stone
execute in minecraft:overworld run fill 280 62 -48 280 63 -48 dirt
execute in minecraft:overworld run setblock 280 64 -48 coarse_dirt
execute in minecraft:overworld run fill 280 65 -48 280 144 -48 air
execute in minecraft:overworld run fill 280 58 -47 280 63 -47 stone
execute in minecraft:overworld run fill 280 64 -47 280 65 -47 dirt
execute in minecraft:overworld run setblock 280 66 -47 grass_block
execute in minecraft:overworld run fill 280 67 -47 280 144 -47 air
execute in minecraft:overworld run fill 280 58 -46 280 66 -46 stone
execute in minecraft:overworld run fill 280 67 -46 280 68 -46 dirt
execute in minecraft:overworld run setblock 280 69 -46 coarse_dirt
execute in minecraft:overworld run fill 280 70 -46 280 144 -46 air
execute in minecraft:overworld run fill 280 58 -45 280 68 -45 stone
execute in minecraft:overworld run fill 280 69 -45 280 70 -45 dirt
execute in minecraft:overworld run setblock 280 71 -45 coarse_dirt
execute in minecraft:overworld run fill 280 72 -45 280 144 -45 air
execute in minecraft:overworld run fill 280 58 -44 280 70 -44 stone
execute in minecraft:overworld run fill 280 71 -44 280 72 -44 dirt
execute in minecraft:overworld run setblock 280 73 -44 coarse_dirt
execute in minecraft:overworld run fill 280 74 -44 280 144 -44 air
execute in minecraft:overworld run fill 280 58 -43 280 72 -43 stone
execute in minecraft:overworld run fill 280 73 -43 280 74 -43 dirt
execute in minecraft:overworld run setblock 280 75 -43 grass_block
execute in minecraft:overworld run fill 280 76 -43 280 144 -43 air
execute in minecraft:overworld run fill 280 58 -42 280 73 -42 stone
execute in minecraft:overworld run fill 280 74 -42 280 75 -42 dirt
execute in minecraft:overworld run setblock 280 76 -42 coarse_dirt
execute in minecraft:overworld run fill 280 77 -42 280 144 -42 air
execute in minecraft:overworld run fill 280 58 -41 280 75 -41 stone
execute in minecraft:overworld run fill 280 76 -41 280 77 -41 dirt
execute in minecraft:overworld run setblock 280 78 -41 coarse_dirt
execute in minecraft:overworld run fill 280 79 -41 280 144 -41 air
execute in minecraft:overworld run fill 280 58 -40 280 77 -40 stone
execute in minecraft:overworld run fill 280 78 -40 280 79 -40 dirt
execute in minecraft:overworld run setblock 280 80 -40 coarse_dirt
execute in minecraft:overworld run fill 280 81 -40 280 144 -40 air
execute in minecraft:overworld run fill 280 58 -39 280 78 -39 stone
execute in minecraft:overworld run fill 280 79 -39 280 80 -39 dirt
execute in minecraft:overworld run setblock 280 81 -39 coarse_dirt
execute in minecraft:overworld run fill 280 82 -39 280 144 -39 air
execute in minecraft:overworld run fill 280 58 -38 280 79 -38 stone
execute in minecraft:overworld run fill 280 80 -38 280 81 -38 dirt
execute in minecraft:overworld run setblock 280 82 -38 grass_block
execute in minecraft:overworld run fill 280 83 -38 280 144 -38 air
execute in minecraft:overworld run fill 280 58 -37 280 79 -37 stone
execute in minecraft:overworld run fill 280 80 -37 280 81 -37 dirt
execute in minecraft:overworld run setblock 280 82 -37 coarse_dirt
execute in minecraft:overworld run fill 280 83 -37 280 144 -37 air
execute in minecraft:overworld run fill 280 58 -36 280 78 -36 stone
execute in minecraft:overworld run fill 280 79 -36 280 80 -36 dirt
execute in minecraft:overworld run setblock 280 81 -36 grass_block
execute in minecraft:overworld run fill 280 82 -36 280 144 -36 air
execute in minecraft:overworld run fill 280 58 -35 280 78 -35 stone
execute in minecraft:overworld run fill 280 79 -35 280 80 -35 dirt
execute in minecraft:overworld run setblock 280 81 -35 coarse_dirt
execute in minecraft:overworld run fill 280 82 -35 280 144 -35 air
execute in minecraft:overworld run fill 280 58 -34 280 78 -34 stone
execute in minecraft:overworld run fill 280 79 -34 280 80 -34 dirt
execute in minecraft:overworld run setblock 280 81 -34 coarse_dirt
execute in minecraft:overworld run fill 280 82 -34 280 144 -34 air
execute in minecraft:overworld run fill 280 58 -33 280 77 -33 stone
execute in minecraft:overworld run fill 280 78 -33 280 79 -33 dirt
execute in minecraft:overworld run setblock 280 80 -33 coarse_dirt
execute in minecraft:overworld run fill 280 81 -33 280 144 -33 air
execute in minecraft:overworld run fill 280 58 -32 280 77 -32 stone
execute in minecraft:overworld run fill 280 78 -32 280 79 -32 dirt
execute in minecraft:overworld run setblock 280 80 -32 coarse_dirt
execute in minecraft:overworld run fill 280 81 -32 280 144 -32 air
execute in minecraft:overworld run setblock 280 81 -32 grass
execute in minecraft:overworld run fill 280 58 -31 280 77 -31 stone
execute in minecraft:overworld run fill 280 78 -31 280 79 -31 dirt
execute in minecraft:overworld run setblock 280 80 -31 coarse_dirt
execute in minecraft:overworld run fill 280 81 -31 280 144 -31 air
execute in minecraft:overworld run fill 280 58 -30 280 76 -30 stone
execute in minecraft:overworld run fill 280 77 -30 280 78 -30 dirt
execute in minecraft:overworld run setblock 280 79 -30 coarse_dirt
execute in minecraft:overworld run fill 280 80 -30 280 144 -30 air
execute in minecraft:overworld run fill 280 58 -29 280 76 -29 stone
execute in minecraft:overworld run fill 280 77 -29 280 78 -29 dirt
execute in minecraft:overworld run setblock 280 79 -29 coarse_dirt
execute in minecraft:overworld run fill 280 80 -29 280 144 -29 air
execute in minecraft:overworld run fill 280 58 -28 280 76 -28 stone
execute in minecraft:overworld run fill 280 77 -28 280 78 -28 dirt
execute in minecraft:overworld run setblock 280 79 -28 grass_block
execute in minecraft:overworld run fill 280 80 -28 280 144 -28 air
execute in minecraft:overworld run fill 280 58 -27 280 75 -27 stone
execute in minecraft:overworld run fill 280 76 -27 280 77 -27 dirt
execute in minecraft:overworld run setblock 280 78 -27 coarse_dirt
execute in minecraft:overworld run fill 280 79 -27 280 144 -27 air
execute in minecraft:overworld run fill 280 58 -26 280 75 -26 stone
execute in minecraft:overworld run fill 280 76 -26 280 77 -26 dirt
execute in minecraft:overworld run setblock 280 78 -26 grass_block
execute in minecraft:overworld run fill 280 79 -26 280 144 -26 air
execute in minecraft:overworld run fill 280 58 -25 280 75 -25 stone
execute in minecraft:overworld run fill 280 76 -25 280 77 -25 dirt
execute in minecraft:overworld run setblock 280 78 -25 coarse_dirt
execute in minecraft:overworld run fill 280 79 -25 280 144 -25 air
execute in minecraft:overworld run fill 280 58 -24 280 74 -24 stone
execute in minecraft:overworld run fill 280 75 -24 280 76 -24 dirt
execute in minecraft:overworld run setblock 280 77 -24 grass_block
execute in minecraft:overworld run fill 280 78 -24 280 144 -24 air
execute in minecraft:overworld run fill 280 58 -23 280 74 -23 stone
execute in minecraft:overworld run fill 280 75 -23 280 76 -23 dirt
execute in minecraft:overworld run setblock 280 77 -23 grass_block
execute in minecraft:overworld run fill 280 78 -23 280 144 -23 air
execute in minecraft:overworld run setblock 280 78 -23 grass
execute in minecraft:overworld run fill 280 58 -22 280 74 -22 stone
execute in minecraft:overworld run fill 280 75 -22 280 76 -22 dirt
execute in minecraft:overworld run setblock 280 77 -22 grass_block
execute in minecraft:overworld run fill 280 78 -22 280 144 -22 air
execute in minecraft:overworld run fill 280 58 -21 280 74 -21 stone
execute in minecraft:overworld run fill 280 75 -21 280 76 -21 dirt
execute in minecraft:overworld run setblock 280 77 -21 coarse_dirt
execute in minecraft:overworld run fill 280 78 -21 280 144 -21 air
execute in minecraft:overworld run fill 280 58 -20 280 73 -20 stone
execute in minecraft:overworld run fill 280 74 -20 280 75 -20 dirt
execute in minecraft:overworld run setblock 280 76 -20 grass_block
execute in minecraft:overworld run fill 280 77 -20 280 144 -20 air
execute in minecraft:overworld run fill 280 58 -19 280 73 -19 stone
execute in minecraft:overworld run fill 280 74 -19 280 75 -19 dirt
execute in minecraft:overworld run setblock 280 76 -19 coarse_dirt
execute in minecraft:overworld run fill 280 77 -19 280 144 -19 air
execute in minecraft:overworld run fill 280 58 -18 280 72 -18 stone
execute in minecraft:overworld run fill 280 73 -18 280 74 -18 dirt
execute in minecraft:overworld run setblock 280 75 -18 grass_block
execute in minecraft:overworld run fill 280 76 -18 280 144 -18 air
execute in minecraft:overworld run fill 280 58 -17 280 72 -17 stone
execute in minecraft:overworld run fill 280 73 -17 280 74 -17 dirt
execute in minecraft:overworld run setblock 280 75 -17 grass_block
execute in minecraft:overworld run fill 280 76 -17 280 144 -17 air
execute in minecraft:overworld run fill 280 58 -16 280 71 -16 stone
execute in minecraft:overworld run fill 280 72 -16 280 73 -16 dirt
execute in minecraft:overworld run setblock 280 74 -16 coarse_dirt
execute in minecraft:overworld run fill 280 75 -16 280 144 -16 air
execute in minecraft:overworld run fill 280 58 -15 280 71 -15 stone
execute in minecraft:overworld run fill 280 72 -15 280 73 -15 dirt
execute in minecraft:overworld run setblock 280 74 -15 coarse_dirt
execute in minecraft:overworld run fill 280 75 -15 280 144 -15 air
execute in minecraft:overworld run fill 280 58 -14 280 70 -14 stone
execute in minecraft:overworld run fill 280 71 -14 280 72 -14 dirt
execute in minecraft:overworld run setblock 280 73 -14 coarse_dirt
execute in minecraft:overworld run fill 280 74 -14 280 144 -14 air
execute in minecraft:overworld run fill 280 58 -13 280 69 -13 stone
execute in minecraft:overworld run fill 280 70 -13 280 71 -13 dirt
execute in minecraft:overworld run setblock 280 72 -13 coarse_dirt
execute in minecraft:overworld run fill 280 73 -13 280 144 -13 air
execute in minecraft:overworld run fill 280 58 -12 280 68 -12 stone
execute in minecraft:overworld run fill 280 69 -12 280 70 -12 dirt
execute in minecraft:overworld run setblock 280 71 -12 grass_block
execute in minecraft:overworld run fill 280 72 -12 280 144 -12 air
execute in minecraft:overworld run fill 280 58 -11 280 68 -11 stone
execute in minecraft:overworld run fill 280 69 -11 280 70 -11 dirt
execute in minecraft:overworld run setblock 280 71 -11 coarse_dirt
execute in minecraft:overworld run fill 280 72 -11 280 144 -11 air
execute in minecraft:overworld run setblock 280 72 -11 mossy_cobblestone
execute in minecraft:overworld run fill 280 58 -10 280 68 -10 stone
execute in minecraft:overworld run fill 280 69 -10 280 70 -10 dirt
execute in minecraft:overworld run setblock 280 71 -10 coarse_dirt
execute in minecraft:overworld run fill 280 72 -10 280 144 -10 air
execute in minecraft:overworld run fill 280 58 -9 280 68 -9 stone
execute in minecraft:overworld run fill 280 69 -9 280 70 -9 dirt
execute in minecraft:overworld run setblock 280 71 -9 coarse_dirt
execute in minecraft:overworld run fill 280 72 -9 280 144 -9 air
execute in minecraft:overworld run fill 280 58 -8 280 68 -8 stone
execute in minecraft:overworld run fill 280 69 -8 280 70 -8 dirt
execute in minecraft:overworld run setblock 280 71 -8 coarse_dirt
execute in minecraft:overworld run fill 280 72 -8 280 144 -8 air
execute in minecraft:overworld run fill 280 58 -7 280 68 -7 stone
execute in minecraft:overworld run fill 280 69 -7 280 70 -7 dirt
execute in minecraft:overworld run setblock 280 71 -7 coarse_dirt
execute in minecraft:overworld run fill 280 72 -7 280 144 -7 air
execute in minecraft:overworld run fill 280 58 -6 280 68 -6 stone
execute in minecraft:overworld run fill 280 69 -6 280 70 -6 dirt
execute in minecraft:overworld run setblock 280 71 -6 coarse_dirt
execute in minecraft:overworld run fill 280 72 -6 280 144 -6 air
execute in minecraft:overworld run fill 280 58 -5 280 68 -5 stone
execute in minecraft:overworld run fill 280 69 -5 280 70 -5 dirt
execute in minecraft:overworld run setblock 280 71 -5 coarse_dirt
execute in minecraft:overworld run fill 280 72 -5 280 144 -5 air
execute in minecraft:overworld run fill 280 58 -4 280 68 -4 stone
execute in minecraft:overworld run fill 280 69 -4 280 70 -4 dirt
execute in minecraft:overworld run setblock 280 71 -4 grass_block
execute in minecraft:overworld run fill 280 72 -4 280 144 -4 air
execute in minecraft:overworld run fill 280 58 -3 280 67 -3 stone
execute in minecraft:overworld run fill 280 68 -3 280 69 -3 dirt
execute in minecraft:overworld run setblock 280 70 -3 coarse_dirt
execute in minecraft:overworld run fill 280 71 -3 280 144 -3 air
execute in minecraft:overworld run fill 280 58 -2 280 67 -2 stone
execute in minecraft:overworld run fill 280 68 -2 280 69 -2 dirt
execute in minecraft:overworld run setblock 280 70 -2 grass_block
execute in minecraft:overworld run fill 280 71 -2 280 144 -2 air
execute in minecraft:overworld run fill 280 58 -1 280 67 -1 stone
execute in minecraft:overworld run fill 280 68 -1 280 69 -1 dirt
execute in minecraft:overworld run setblock 280 70 -1 grass_block
execute in minecraft:overworld run fill 280 71 -1 280 144 -1 air
execute in minecraft:overworld run fill 280 58 0 280 67 0 stone
execute in minecraft:overworld run fill 280 68 0 280 69 0 dirt
execute in minecraft:overworld run setblock 280 70 0 coarse_dirt
execute in minecraft:overworld run fill 280 71 0 280 144 0 air
execute in minecraft:overworld run fill 280 58 1 280 67 1 stone
execute in minecraft:overworld run fill 280 68 1 280 69 1 dirt
execute in minecraft:overworld run setblock 280 70 1 coarse_dirt
execute in minecraft:overworld run fill 280 71 1 280 144 1 air
execute in minecraft:overworld run fill 280 58 2 280 67 2 stone
execute in minecraft:overworld run fill 280 68 2 280 69 2 dirt
execute in minecraft:overworld run setblock 280 70 2 grass_block
execute in minecraft:overworld run fill 280 71 2 280 144 2 air
execute in minecraft:overworld run fill 280 58 3 280 67 3 stone
execute in minecraft:overworld run fill 280 68 3 280 69 3 dirt
execute in minecraft:overworld run setblock 280 70 3 coarse_dirt
execute in minecraft:overworld run fill 280 71 3 280 144 3 air
execute in minecraft:overworld run fill 280 58 4 280 67 4 stone
execute in minecraft:overworld run fill 280 68 4 280 69 4 dirt
execute in minecraft:overworld run setblock 280 70 4 coarse_dirt
execute in minecraft:overworld run fill 280 71 4 280 144 4 air
execute in minecraft:overworld run fill 280 58 5 280 66 5 stone
execute in minecraft:overworld run fill 280 67 5 280 68 5 dirt
execute in minecraft:overworld run setblock 280 69 5 coarse_dirt
execute in minecraft:overworld run fill 280 70 5 280 144 5 air
execute in minecraft:overworld run fill 280 58 6 280 66 6 stone
execute in minecraft:overworld run fill 280 67 6 280 68 6 dirt
execute in minecraft:overworld run setblock 280 69 6 grass_block
execute in minecraft:overworld run fill 280 70 6 280 144 6 air
execute in minecraft:overworld run fill 280 58 7 280 66 7 stone
execute in minecraft:overworld run fill 280 67 7 280 68 7 dirt
execute in minecraft:overworld run setblock 280 69 7 grass_block
execute in minecraft:overworld run fill 280 70 7 280 144 7 air
schedule function blade_gallery:random/burned/part_115 1t replace
