execute in minecraft:overworld run setblock 292 76 -21 mossy_cobblestone
execute in minecraft:overworld run setblock 263 79 -27 mossy_cobblestone
execute in minecraft:overworld run setblock 279 70 5 mossy_cobblestone
execute in minecraft:overworld run setblock 235 74 -26 mossy_cobblestone
execute in minecraft:overworld run setblock 287 78 -29 mossy_cobblestone
execute in minecraft:overworld run setblock 231 69 -14 mossy_cobblestone
execute in minecraft:overworld run setblock 223 69 -9 mossy_cobblestone
execute in minecraft:overworld run setblock 283 68 18 campfire[lit=true,signal_fire=false]
execute in minecraft:overworld run setblock 255 68 19 mossy_cobblestone
execute in minecraft:overworld run setblock 288 68 29 mossy_cobblestone
execute in minecraft:overworld run setblock 216 70 0 mossy_cobblestone
execute in minecraft:overworld run setblock 218 70 -28 mossy_cobblestone
execute in minecraft:overworld run setblock 239 71 -18 mossy_cobblestone
execute in minecraft:overworld run setblock 287 71 7 mossy_cobblestone
execute in minecraft:overworld run setblock 277 66 23 mossy_cobblestone
execute in minecraft:overworld run setblock 293 69 30 mossy_cobblestone
execute in minecraft:overworld run setblock 216 68 -26 campfire[lit=true,signal_fire=false]
execute in minecraft:overworld run setblock 236 77 -35 mossy_cobblestone
execute in minecraft:overworld run setblock 242 74 -25 mossy_cobblestone
execute in minecraft:overworld run setblock 285 79 -29 mossy_cobblestone
execute in minecraft:overworld run setblock 223 69 -13 mossy_cobblestone
execute in minecraft:overworld run setblock 293 69 22 mossy_cobblestone
execute in minecraft:overworld run setblock 234 69 -7 mossy_cobblestone
execute in minecraft:overworld run setblock 295 79 -31 campfire[lit=true,signal_fire=false]
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 259.5 76.1 -27.5 {Tags:["blade_gallery.burned"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:69f,StabYaw:266f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 238.5 73.1 -22.5 {Tags:["blade_gallery.burned"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:31f,StabYaw:102f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 231.5 69.1 -7.5 {Tags:["blade_gallery.burned"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:14f,StabYaw:92f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 250.5 66.1 -7.5 {Tags:["blade_gallery.burned"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:67f,StabYaw:57f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 253.5 66.1 -15.5 {Tags:["blade_gallery.burned"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:38f,StabYaw:332f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 230.5 71.1 10.5 {Tags:["blade_gallery.burned"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:36f,StabYaw:129f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 251.5 69.1 27.5 {Tags:["blade_gallery.burned"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:33f,StabYaw:123f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run forceload remove 208 -48 303 47
tellraw @a {"text":"撮影エリア burned の生成が完了しました","color":"green"}
data remove storage blade_gallery:state random_busy
execute if data storage blade_gallery:state random_all run function blade_gallery:random/battlefield/start
# Next scene continues only during full generation.
