execute in minecraft:overworld run fill 257 64 20 257 65 20 dirt
execute in minecraft:overworld run setblock 257 66 20 coarse_dirt
execute in minecraft:overworld run fill 257 67 20 257 144 20 air
execute in minecraft:overworld run fill 257 58 21 257 63 21 stone
execute in minecraft:overworld run fill 257 64 21 257 65 21 dirt
execute in minecraft:overworld run setblock 257 66 21 coarse_dirt
execute in minecraft:overworld run fill 257 67 21 257 144 21 air
execute in minecraft:overworld run fill 257 58 22 257 63 22 stone
execute in minecraft:overworld run fill 257 64 22 257 65 22 dirt
execute in minecraft:overworld run setblock 257 66 22 grass_block
execute in minecraft:overworld run fill 257 67 22 257 144 22 air
execute in minecraft:overworld run fill 257 58 23 257 63 23 stone
execute in minecraft:overworld run fill 257 64 23 257 65 23 dirt
execute in minecraft:overworld run setblock 257 66 23 grass_block
execute in minecraft:overworld run fill 257 67 23 257 144 23 air
execute in minecraft:overworld run fill 257 58 24 257 63 24 stone
execute in minecraft:overworld run fill 257 64 24 257 65 24 dirt
execute in minecraft:overworld run setblock 257 66 24 grass_block
execute in minecraft:overworld run fill 257 67 24 257 144 24 air
execute in minecraft:overworld run fill 257 58 25 257 62 25 stone
execute in minecraft:overworld run fill 257 63 25 257 64 25 dirt
execute in minecraft:overworld run setblock 257 65 25 coarse_dirt
execute in minecraft:overworld run fill 257 66 25 257 144 25 air
execute in minecraft:overworld run fill 257 58 26 257 62 26 stone
execute in minecraft:overworld run fill 257 63 26 257 64 26 dirt
execute in minecraft:overworld run setblock 257 65 26 coarse_dirt
execute in minecraft:overworld run fill 257 66 26 257 144 26 air
execute in minecraft:overworld run fill 257 58 27 257 62 27 stone
execute in minecraft:overworld run fill 257 63 27 257 64 27 dirt
execute in minecraft:overworld run setblock 257 65 27 coarse_dirt
execute in minecraft:overworld run fill 257 66 27 257 144 27 air
execute in minecraft:overworld run fill 257 58 28 257 62 28 stone
execute in minecraft:overworld run fill 257 63 28 257 64 28 dirt
execute in minecraft:overworld run setblock 257 65 28 grass_block
execute in minecraft:overworld run fill 257 66 28 257 144 28 air
execute in minecraft:overworld run fill 257 58 29 257 61 29 stone
execute in minecraft:overworld run fill 257 62 29 257 63 29 dirt
execute in minecraft:overworld run setblock 257 64 29 coarse_dirt
execute in minecraft:overworld run fill 257 65 29 257 144 29 air
execute in minecraft:overworld run fill 257 58 30 257 61 30 stone
execute in minecraft:overworld run fill 257 62 30 257 63 30 dirt
execute in minecraft:overworld run setblock 257 64 30 coarse_dirt
execute in minecraft:overworld run fill 257 65 30 257 144 30 air
execute in minecraft:overworld run fill 257 58 31 257 61 31 stone
execute in minecraft:overworld run fill 257 62 31 257 63 31 dirt
execute in minecraft:overworld run setblock 257 64 31 coarse_dirt
execute in minecraft:overworld run fill 257 65 31 257 144 31 air
execute in minecraft:overworld run fill 257 58 32 257 60 32 stone
execute in minecraft:overworld run fill 257 61 32 257 62 32 dirt
execute in minecraft:overworld run setblock 257 63 32 gravel
execute in minecraft:overworld run fill 257 64 32 257 144 32 air
execute in minecraft:overworld run fill 257 64 32 257 64 32 water
execute in minecraft:overworld run fill 257 58 33 257 60 33 stone
execute in minecraft:overworld run fill 257 61 33 257 62 33 dirt
execute in minecraft:overworld run setblock 257 63 33 gravel
execute in minecraft:overworld run fill 257 64 33 257 144 33 air
execute in minecraft:overworld run fill 257 64 33 257 64 33 water
execute in minecraft:overworld run fill 257 58 34 257 59 34 stone
execute in minecraft:overworld run fill 257 60 34 257 61 34 dirt
execute in minecraft:overworld run setblock 257 62 34 gravel
execute in minecraft:overworld run fill 257 63 34 257 144 34 air
execute in minecraft:overworld run fill 257 63 34 257 64 34 water
execute in minecraft:overworld run fill 257 58 35 257 59 35 stone
execute in minecraft:overworld run fill 257 60 35 257 61 35 dirt
execute in minecraft:overworld run setblock 257 62 35 gravel
execute in minecraft:overworld run fill 257 63 35 257 144 35 air
execute in minecraft:overworld run fill 257 63 35 257 64 35 water
execute in minecraft:overworld run fill 257 58 36 257 58 36 stone
execute in minecraft:overworld run fill 257 59 36 257 60 36 dirt
execute in minecraft:overworld run setblock 257 61 36 gravel
execute in minecraft:overworld run fill 257 62 36 257 144 36 air
execute in minecraft:overworld run fill 257 62 36 257 64 36 water
execute in minecraft:overworld run fill 257 58 37 257 58 37 stone
execute in minecraft:overworld run fill 257 59 37 257 60 37 dirt
execute in minecraft:overworld run setblock 257 61 37 gravel
execute in minecraft:overworld run fill 257 62 37 257 144 37 air
execute in minecraft:overworld run fill 257 62 37 257 64 37 water
execute in minecraft:overworld run fill 257 58 38 257 57 38 stone
execute in minecraft:overworld run fill 257 58 38 257 59 38 dirt
execute in minecraft:overworld run setblock 257 60 38 gravel
execute in minecraft:overworld run fill 257 61 38 257 144 38 air
execute in minecraft:overworld run fill 257 61 38 257 64 38 water
execute in minecraft:overworld run fill 257 58 39 257 57 39 stone
execute in minecraft:overworld run fill 257 58 39 257 59 39 dirt
execute in minecraft:overworld run setblock 257 60 39 gravel
execute in minecraft:overworld run fill 257 61 39 257 144 39 air
execute in minecraft:overworld run fill 257 61 39 257 64 39 water
execute in minecraft:overworld run fill 257 58 40 257 57 40 stone
execute in minecraft:overworld run fill 257 58 40 257 59 40 dirt
execute in minecraft:overworld run setblock 257 60 40 gravel
execute in minecraft:overworld run fill 257 61 40 257 144 40 air
execute in minecraft:overworld run fill 257 61 40 257 64 40 water
execute in minecraft:overworld run fill 257 58 41 257 58 41 stone
execute in minecraft:overworld run fill 257 59 41 257 60 41 dirt
execute in minecraft:overworld run setblock 257 61 41 gravel
execute in minecraft:overworld run fill 257 62 41 257 144 41 air
execute in minecraft:overworld run fill 257 62 41 257 64 41 water
execute in minecraft:overworld run fill 257 58 42 257 58 42 stone
execute in minecraft:overworld run fill 257 59 42 257 60 42 dirt
execute in minecraft:overworld run setblock 257 61 42 gravel
execute in minecraft:overworld run fill 257 62 42 257 144 42 air
execute in minecraft:overworld run fill 257 62 42 257 64 42 water
execute in minecraft:overworld run fill 257 58 43 257 58 43 stone
execute in minecraft:overworld run fill 257 59 43 257 60 43 dirt
execute in minecraft:overworld run setblock 257 61 43 gravel
execute in minecraft:overworld run fill 257 62 43 257 144 43 air
execute in minecraft:overworld run fill 257 62 43 257 64 43 water
execute in minecraft:overworld run fill 257 58 44 257 59 44 stone
execute in minecraft:overworld run fill 257 60 44 257 61 44 dirt
execute in minecraft:overworld run setblock 257 62 44 gravel
execute in minecraft:overworld run fill 257 63 44 257 144 44 air
execute in minecraft:overworld run fill 257 63 44 257 64 44 water
execute in minecraft:overworld run fill 257 58 45 257 59 45 stone
execute in minecraft:overworld run fill 257 60 45 257 61 45 dirt
execute in minecraft:overworld run setblock 257 62 45 gravel
execute in minecraft:overworld run fill 257 63 45 257 144 45 air
execute in minecraft:overworld run fill 257 63 45 257 64 45 water
execute in minecraft:overworld run fill 257 58 46 257 60 46 stone
execute in minecraft:overworld run fill 257 61 46 257 62 46 dirt
execute in minecraft:overworld run setblock 257 63 46 gravel
execute in minecraft:overworld run fill 257 64 46 257 144 46 air
execute in minecraft:overworld run fill 257 64 46 257 64 46 water
execute in minecraft:overworld run fill 257 58 47 257 60 47 stone
execute in minecraft:overworld run fill 257 61 47 257 62 47 dirt
execute in minecraft:overworld run setblock 257 63 47 gravel
execute in minecraft:overworld run fill 257 64 47 257 144 47 air
execute in minecraft:overworld run fill 257 64 47 257 64 47 water
execute in minecraft:overworld run fill 258 58 -48 258 61 -48 stone
execute in minecraft:overworld run fill 258 62 -48 258 63 -48 dirt
execute in minecraft:overworld run setblock 258 64 -48 coarse_dirt
execute in minecraft:overworld run fill 258 65 -48 258 144 -48 air
execute in minecraft:overworld run fill 258 58 -47 258 63 -47 stone
execute in minecraft:overworld run fill 258 64 -47 258 65 -47 dirt
execute in minecraft:overworld run setblock 258 66 -47 coarse_dirt
execute in minecraft:overworld run fill 258 67 -47 258 144 -47 air
execute in minecraft:overworld run fill 258 58 -46 258 64 -46 stone
execute in minecraft:overworld run fill 258 65 -46 258 66 -46 dirt
execute in minecraft:overworld run setblock 258 67 -46 grass_block
execute in minecraft:overworld run fill 258 68 -46 258 144 -46 air
execute in minecraft:overworld run fill 258 58 -45 258 66 -45 stone
execute in minecraft:overworld run fill 258 67 -45 258 68 -45 dirt
execute in minecraft:overworld run setblock 258 69 -45 coarse_dirt
execute in minecraft:overworld run fill 258 70 -45 258 144 -45 air
execute in minecraft:overworld run fill 258 58 -44 258 67 -44 stone
execute in minecraft:overworld run fill 258 68 -44 258 69 -44 dirt
execute in minecraft:overworld run setblock 258 70 -44 coarse_dirt
execute in minecraft:overworld run fill 258 71 -44 258 144 -44 air
execute in minecraft:overworld run fill 258 58 -43 258 69 -43 stone
execute in minecraft:overworld run fill 258 70 -43 258 71 -43 dirt
execute in minecraft:overworld run setblock 258 72 -43 grass_block
execute in minecraft:overworld run fill 258 73 -43 258 144 -43 air
execute in minecraft:overworld run fill 258 58 -42 258 70 -42 stone
execute in minecraft:overworld run fill 258 71 -42 258 72 -42 dirt
execute in minecraft:overworld run setblock 258 73 -42 coarse_dirt
execute in minecraft:overworld run fill 258 74 -42 258 144 -42 air
execute in minecraft:overworld run fill 258 58 -41 258 72 -41 stone
execute in minecraft:overworld run fill 258 73 -41 258 74 -41 dirt
execute in minecraft:overworld run setblock 258 75 -41 coarse_dirt
execute in minecraft:overworld run fill 258 76 -41 258 144 -41 air
execute in minecraft:overworld run fill 258 58 -40 258 73 -40 stone
execute in minecraft:overworld run fill 258 74 -40 258 75 -40 dirt
execute in minecraft:overworld run setblock 258 76 -40 coarse_dirt
execute in minecraft:overworld run fill 258 77 -40 258 144 -40 air
execute in minecraft:overworld run fill 258 58 -39 258 74 -39 stone
execute in minecraft:overworld run fill 258 75 -39 258 76 -39 dirt
execute in minecraft:overworld run setblock 258 77 -39 coarse_dirt
execute in minecraft:overworld run fill 258 78 -39 258 144 -39 air
execute in minecraft:overworld run setblock 258 78 -39 grass
execute in minecraft:overworld run fill 258 58 -38 258 76 -38 stone
execute in minecraft:overworld run fill 258 77 -38 258 78 -38 dirt
execute in minecraft:overworld run setblock 258 79 -38 coarse_dirt
execute in minecraft:overworld run fill 258 80 -38 258 144 -38 air
execute in minecraft:overworld run fill 258 58 -37 258 75 -37 stone
execute in minecraft:overworld run fill 258 76 -37 258 77 -37 dirt
execute in minecraft:overworld run setblock 258 78 -37 grass_block
execute in minecraft:overworld run fill 258 79 -37 258 144 -37 air
execute in minecraft:overworld run fill 258 58 -36 258 75 -36 stone
execute in minecraft:overworld run fill 258 76 -36 258 77 -36 dirt
execute in minecraft:overworld run setblock 258 78 -36 coarse_dirt
execute in minecraft:overworld run fill 258 79 -36 258 144 -36 air
execute in minecraft:overworld run fill 258 58 -35 258 75 -35 stone
execute in minecraft:overworld run fill 258 76 -35 258 77 -35 dirt
execute in minecraft:overworld run setblock 258 78 -35 coarse_dirt
execute in minecraft:overworld run fill 258 79 -35 258 144 -35 air
execute in minecraft:overworld run fill 258 58 -34 258 74 -34 stone
execute in minecraft:overworld run fill 258 75 -34 258 76 -34 dirt
execute in minecraft:overworld run setblock 258 77 -34 coarse_dirt
execute in minecraft:overworld run fill 258 78 -34 258 144 -34 air
execute in minecraft:overworld run fill 258 58 -33 258 74 -33 stone
execute in minecraft:overworld run fill 258 75 -33 258 76 -33 dirt
execute in minecraft:overworld run setblock 258 77 -33 grass_block
execute in minecraft:overworld run fill 258 78 -33 258 144 -33 air
execute in minecraft:overworld run fill 258 58 -32 258 74 -32 stone
execute in minecraft:overworld run fill 258 75 -32 258 76 -32 dirt
execute in minecraft:overworld run setblock 258 77 -32 grass_block
execute in minecraft:overworld run fill 258 78 -32 258 144 -32 air
execute in minecraft:overworld run fill 258 58 -31 258 73 -31 stone
execute in minecraft:overworld run fill 258 74 -31 258 75 -31 dirt
execute in minecraft:overworld run setblock 258 76 -31 coarse_dirt
execute in minecraft:overworld run fill 258 77 -31 258 144 -31 air
execute in minecraft:overworld run setblock 258 77 -31 grass
execute in minecraft:overworld run fill 258 58 -30 258 73 -30 stone
execute in minecraft:overworld run fill 258 74 -30 258 75 -30 dirt
execute in minecraft:overworld run setblock 258 76 -30 coarse_dirt
execute in minecraft:overworld run fill 258 77 -30 258 144 -30 air
execute in minecraft:overworld run fill 258 58 -29 258 72 -29 stone
execute in minecraft:overworld run fill 258 73 -29 258 74 -29 dirt
execute in minecraft:overworld run setblock 258 75 -29 coarse_dirt
execute in minecraft:overworld run fill 258 76 -29 258 144 -29 air
execute in minecraft:overworld run fill 258 58 -28 258 71 -28 stone
execute in minecraft:overworld run fill 258 72 -28 258 73 -28 dirt
execute in minecraft:overworld run setblock 258 74 -28 coarse_dirt
execute in minecraft:overworld run fill 258 75 -28 258 144 -28 air
execute in minecraft:overworld run fill 258 58 -27 258 71 -27 stone
execute in minecraft:overworld run fill 258 72 -27 258 73 -27 dirt
execute in minecraft:overworld run setblock 258 74 -27 grass_block
execute in minecraft:overworld run fill 258 75 -27 258 144 -27 air
execute in minecraft:overworld run setblock 258 75 -27 grass
execute in minecraft:overworld run fill 258 58 -26 258 70 -26 stone
execute in minecraft:overworld run fill 258 71 -26 258 72 -26 dirt
execute in minecraft:overworld run setblock 258 73 -26 grass_block
execute in minecraft:overworld run fill 258 74 -26 258 144 -26 air
execute in minecraft:overworld run fill 258 58 -25 258 69 -25 stone
execute in minecraft:overworld run fill 258 70 -25 258 71 -25 dirt
execute in minecraft:overworld run setblock 258 72 -25 coarse_dirt
execute in minecraft:overworld run fill 258 73 -25 258 144 -25 air
execute in minecraft:overworld run fill 258 58 -24 258 67 -24 stone
execute in minecraft:overworld run fill 258 68 -24 258 69 -24 dirt
execute in minecraft:overworld run setblock 258 70 -24 coarse_dirt
execute in minecraft:overworld run fill 258 71 -24 258 144 -24 air
execute in minecraft:overworld run fill 258 58 -23 258 66 -23 stone
execute in minecraft:overworld run fill 258 67 -23 258 68 -23 dirt
execute in minecraft:overworld run setblock 258 69 -23 coarse_dirt
execute in minecraft:overworld run fill 258 70 -23 258 144 -23 air
execute in minecraft:overworld run fill 258 58 -22 258 65 -22 stone
execute in minecraft:overworld run fill 258 66 -22 258 67 -22 dirt
execute in minecraft:overworld run setblock 258 68 -22 grass_block
execute in minecraft:overworld run fill 258 69 -22 258 144 -22 air
execute in minecraft:overworld run setblock 258 69 -22 grass
execute in minecraft:overworld run fill 258 58 -21 258 64 -21 stone
execute in minecraft:overworld run fill 258 65 -21 258 66 -21 dirt
execute in minecraft:overworld run setblock 258 67 -21 grass_block
execute in minecraft:overworld run fill 258 68 -21 258 144 -21 air
execute in minecraft:overworld run fill 258 58 -20 258 63 -20 stone
execute in minecraft:overworld run fill 258 64 -20 258 65 -20 dirt
execute in minecraft:overworld run setblock 258 66 -20 grass_block
execute in minecraft:overworld run fill 258 67 -20 258 144 -20 air
execute in minecraft:overworld run fill 258 58 -19 258 62 -19 stone
execute in minecraft:overworld run fill 258 63 -19 258 64 -19 dirt
execute in minecraft:overworld run setblock 258 65 -19 coarse_dirt
execute in minecraft:overworld run fill 258 66 -19 258 144 -19 air
execute in minecraft:overworld run fill 258 58 -18 258 61 -18 stone
execute in minecraft:overworld run fill 258 62 -18 258 63 -18 dirt
execute in minecraft:overworld run setblock 258 64 -18 coarse_dirt
execute in minecraft:overworld run fill 258 65 -18 258 144 -18 air
execute in minecraft:overworld run fill 258 58 -17 258 61 -17 stone
schedule function blade_gallery:random/burned/part_78 1t replace
