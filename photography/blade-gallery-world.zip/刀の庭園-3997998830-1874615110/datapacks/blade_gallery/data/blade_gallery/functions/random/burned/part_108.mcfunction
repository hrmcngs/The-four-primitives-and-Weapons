execute in minecraft:overworld run fill 276 65 -48 276 144 -48 air
execute in minecraft:overworld run fill 276 58 -47 276 63 -47 stone
execute in minecraft:overworld run fill 276 64 -47 276 65 -47 dirt
execute in minecraft:overworld run setblock 276 66 -47 coarse_dirt
execute in minecraft:overworld run fill 276 67 -47 276 144 -47 air
execute in minecraft:overworld run fill 276 58 -46 276 65 -46 stone
execute in minecraft:overworld run fill 276 66 -46 276 67 -46 dirt
execute in minecraft:overworld run setblock 276 68 -46 grass_block
execute in minecraft:overworld run fill 276 69 -46 276 144 -46 air
execute in minecraft:overworld run fill 276 58 -45 276 68 -45 stone
execute in minecraft:overworld run fill 276 69 -45 276 70 -45 dirt
execute in minecraft:overworld run setblock 276 71 -45 coarse_dirt
execute in minecraft:overworld run fill 276 72 -45 276 144 -45 air
execute in minecraft:overworld run fill 276 58 -44 276 70 -44 stone
execute in minecraft:overworld run fill 276 71 -44 276 72 -44 dirt
execute in minecraft:overworld run setblock 276 73 -44 coarse_dirt
execute in minecraft:overworld run fill 276 74 -44 276 144 -44 air
execute in minecraft:overworld run fill 276 58 -43 276 71 -43 stone
execute in minecraft:overworld run fill 276 72 -43 276 73 -43 dirt
execute in minecraft:overworld run setblock 276 74 -43 coarse_dirt
execute in minecraft:overworld run fill 276 75 -43 276 144 -43 air
execute in minecraft:overworld run fill 276 58 -42 276 73 -42 stone
execute in minecraft:overworld run fill 276 74 -42 276 75 -42 dirt
execute in minecraft:overworld run setblock 276 76 -42 grass_block
execute in minecraft:overworld run fill 276 77 -42 276 144 -42 air
execute in minecraft:overworld run fill 276 58 -41 276 75 -41 stone
execute in minecraft:overworld run fill 276 76 -41 276 77 -41 dirt
execute in minecraft:overworld run setblock 276 78 -41 coarse_dirt
execute in minecraft:overworld run fill 276 79 -41 276 144 -41 air
execute in minecraft:overworld run fill 276 58 -40 276 76 -40 stone
execute in minecraft:overworld run fill 276 77 -40 276 78 -40 dirt
execute in minecraft:overworld run setblock 276 79 -40 grass_block
execute in minecraft:overworld run fill 276 80 -40 276 144 -40 air
execute in minecraft:overworld run fill 276 58 -39 276 78 -39 stone
execute in minecraft:overworld run fill 276 79 -39 276 80 -39 dirt
execute in minecraft:overworld run setblock 276 81 -39 coarse_dirt
execute in minecraft:overworld run fill 276 82 -39 276 144 -39 air
execute in minecraft:overworld run fill 276 58 -38 276 79 -38 stone
execute in minecraft:overworld run fill 276 80 -38 276 81 -38 dirt
execute in minecraft:overworld run setblock 276 82 -38 coarse_dirt
execute in minecraft:overworld run fill 276 83 -38 276 144 -38 air
execute in minecraft:overworld run fill 276 58 -37 276 78 -37 stone
execute in minecraft:overworld run fill 276 79 -37 276 80 -37 dirt
execute in minecraft:overworld run setblock 276 81 -37 coarse_dirt
execute in minecraft:overworld run fill 276 82 -37 276 144 -37 air
execute in minecraft:overworld run fill 276 58 -36 276 78 -36 stone
execute in minecraft:overworld run fill 276 79 -36 276 80 -36 dirt
execute in minecraft:overworld run setblock 276 81 -36 coarse_dirt
execute in minecraft:overworld run fill 276 82 -36 276 144 -36 air
execute in minecraft:overworld run fill 276 58 -35 276 78 -35 stone
execute in minecraft:overworld run fill 276 79 -35 276 80 -35 dirt
execute in minecraft:overworld run setblock 276 81 -35 grass_block
execute in minecraft:overworld run fill 276 82 -35 276 144 -35 air
execute in minecraft:overworld run fill 276 58 -34 276 77 -34 stone
execute in minecraft:overworld run fill 276 78 -34 276 79 -34 dirt
execute in minecraft:overworld run setblock 276 80 -34 coarse_dirt
execute in minecraft:overworld run fill 276 81 -34 276 144 -34 air
execute in minecraft:overworld run setblock 276 81 -34 grass
execute in minecraft:overworld run fill 276 58 -33 276 77 -33 stone
execute in minecraft:overworld run fill 276 78 -33 276 79 -33 dirt
execute in minecraft:overworld run setblock 276 80 -33 coarse_dirt
execute in minecraft:overworld run fill 276 81 -33 276 144 -33 air
execute in minecraft:overworld run fill 276 58 -32 276 77 -32 stone
execute in minecraft:overworld run fill 276 78 -32 276 79 -32 dirt
execute in minecraft:overworld run setblock 276 80 -32 coarse_dirt
execute in minecraft:overworld run fill 276 81 -32 276 144 -32 air
execute in minecraft:overworld run setblock 276 81 -32 grass
execute in minecraft:overworld run fill 276 58 -31 276 76 -31 stone
execute in minecraft:overworld run fill 276 77 -31 276 78 -31 dirt
execute in minecraft:overworld run setblock 276 79 -31 coarse_dirt
execute in minecraft:overworld run fill 276 80 -31 276 144 -31 air
execute in minecraft:overworld run fill 276 58 -30 276 76 -30 stone
execute in minecraft:overworld run fill 276 77 -30 276 78 -30 dirt
execute in minecraft:overworld run setblock 276 79 -30 coarse_dirt
execute in minecraft:overworld run fill 276 80 -30 276 144 -30 air
execute in minecraft:overworld run fill 276 58 -29 276 76 -29 stone
execute in minecraft:overworld run fill 276 77 -29 276 78 -29 dirt
execute in minecraft:overworld run setblock 276 79 -29 coarse_dirt
execute in minecraft:overworld run fill 276 80 -29 276 144 -29 air
execute in minecraft:overworld run fill 276 58 -28 276 75 -28 stone
execute in minecraft:overworld run fill 276 76 -28 276 77 -28 dirt
execute in minecraft:overworld run setblock 276 78 -28 coarse_dirt
execute in minecraft:overworld run fill 276 79 -28 276 144 -28 air
execute in minecraft:overworld run fill 276 58 -27 276 75 -27 stone
execute in minecraft:overworld run fill 276 76 -27 276 77 -27 dirt
execute in minecraft:overworld run setblock 276 78 -27 grass_block
execute in minecraft:overworld run fill 276 79 -27 276 144 -27 air
execute in minecraft:overworld run fill 276 58 -26 276 75 -26 stone
execute in minecraft:overworld run fill 276 76 -26 276 77 -26 dirt
execute in minecraft:overworld run setblock 276 78 -26 coarse_dirt
execute in minecraft:overworld run fill 276 79 -26 276 144 -26 air
execute in minecraft:overworld run fill 276 58 -25 276 74 -25 stone
execute in minecraft:overworld run fill 276 75 -25 276 76 -25 dirt
execute in minecraft:overworld run setblock 276 77 -25 coarse_dirt
execute in minecraft:overworld run fill 276 78 -25 276 144 -25 air
execute in minecraft:overworld run fill 276 58 -24 276 74 -24 stone
execute in minecraft:overworld run fill 276 75 -24 276 76 -24 dirt
execute in minecraft:overworld run setblock 276 77 -24 coarse_dirt
execute in minecraft:overworld run fill 276 78 -24 276 144 -24 air
execute in minecraft:overworld run fill 276 58 -23 276 74 -23 stone
execute in minecraft:overworld run fill 276 75 -23 276 76 -23 dirt
execute in minecraft:overworld run setblock 276 77 -23 coarse_dirt
execute in minecraft:overworld run fill 276 78 -23 276 144 -23 air
execute in minecraft:overworld run fill 276 58 -22 276 73 -22 stone
execute in minecraft:overworld run fill 276 74 -22 276 75 -22 dirt
execute in minecraft:overworld run setblock 276 76 -22 grass_block
execute in minecraft:overworld run fill 276 77 -22 276 144 -22 air
execute in minecraft:overworld run fill 276 58 -21 276 73 -21 stone
execute in minecraft:overworld run fill 276 74 -21 276 75 -21 dirt
execute in minecraft:overworld run setblock 276 76 -21 grass_block
execute in minecraft:overworld run fill 276 77 -21 276 144 -21 air
execute in minecraft:overworld run fill 276 58 -20 276 73 -20 stone
execute in minecraft:overworld run fill 276 74 -20 276 75 -20 dirt
execute in minecraft:overworld run setblock 276 76 -20 coarse_dirt
execute in minecraft:overworld run fill 276 77 -20 276 144 -20 air
execute in minecraft:overworld run fill 276 58 -19 276 72 -19 stone
execute in minecraft:overworld run fill 276 73 -19 276 74 -19 dirt
execute in minecraft:overworld run setblock 276 75 -19 coarse_dirt
execute in minecraft:overworld run fill 276 76 -19 276 144 -19 air
execute in minecraft:overworld run fill 276 58 -18 276 72 -18 stone
execute in minecraft:overworld run fill 276 73 -18 276 74 -18 dirt
execute in minecraft:overworld run setblock 276 75 -18 coarse_dirt
execute in minecraft:overworld run fill 276 76 -18 276 144 -18 air
execute in minecraft:overworld run fill 276 58 -17 276 71 -17 stone
execute in minecraft:overworld run fill 276 72 -17 276 73 -17 dirt
execute in minecraft:overworld run setblock 276 74 -17 coarse_dirt
execute in minecraft:overworld run fill 276 75 -17 276 144 -17 air
execute in minecraft:overworld run fill 276 58 -16 276 71 -16 stone
execute in minecraft:overworld run fill 276 72 -16 276 73 -16 dirt
execute in minecraft:overworld run setblock 276 74 -16 grass_block
execute in minecraft:overworld run fill 276 75 -16 276 144 -16 air
execute in minecraft:overworld run fill 276 58 -15 276 70 -15 stone
execute in minecraft:overworld run fill 276 71 -15 276 72 -15 dirt
execute in minecraft:overworld run setblock 276 73 -15 grass_block
execute in minecraft:overworld run fill 276 74 -15 276 144 -15 air
execute in minecraft:overworld run fill 276 58 -14 276 69 -14 stone
execute in minecraft:overworld run fill 276 70 -14 276 71 -14 dirt
execute in minecraft:overworld run setblock 276 72 -14 grass_block
execute in minecraft:overworld run fill 276 73 -14 276 144 -14 air
execute in minecraft:overworld run fill 276 58 -13 276 69 -13 stone
execute in minecraft:overworld run fill 276 70 -13 276 71 -13 dirt
execute in minecraft:overworld run setblock 276 72 -13 grass_block
execute in minecraft:overworld run fill 276 73 -13 276 144 -13 air
execute in minecraft:overworld run fill 276 58 -12 276 68 -12 stone
execute in minecraft:overworld run fill 276 69 -12 276 70 -12 dirt
execute in minecraft:overworld run setblock 276 71 -12 coarse_dirt
execute in minecraft:overworld run fill 276 72 -12 276 144 -12 air
execute in minecraft:overworld run fill 276 58 -11 276 67 -11 stone
execute in minecraft:overworld run fill 276 68 -11 276 69 -11 dirt
execute in minecraft:overworld run setblock 276 70 -11 coarse_dirt
execute in minecraft:overworld run fill 276 71 -11 276 144 -11 air
execute in minecraft:overworld run fill 276 58 -10 276 67 -10 stone
execute in minecraft:overworld run fill 276 68 -10 276 69 -10 dirt
execute in minecraft:overworld run setblock 276 70 -10 coarse_dirt
execute in minecraft:overworld run fill 276 71 -10 276 144 -10 air
execute in minecraft:overworld run fill 276 58 -9 276 67 -9 stone
execute in minecraft:overworld run fill 276 68 -9 276 69 -9 dirt
execute in minecraft:overworld run setblock 276 70 -9 grass_block
execute in minecraft:overworld run fill 276 71 -9 276 144 -9 air
execute in minecraft:overworld run fill 276 58 -8 276 67 -8 stone
execute in minecraft:overworld run fill 276 68 -8 276 69 -8 dirt
execute in minecraft:overworld run setblock 276 70 -8 coarse_dirt
execute in minecraft:overworld run fill 276 71 -8 276 144 -8 air
execute in minecraft:overworld run fill 276 58 -7 276 66 -7 stone
execute in minecraft:overworld run fill 276 67 -7 276 68 -7 dirt
execute in minecraft:overworld run setblock 276 69 -7 grass_block
execute in minecraft:overworld run fill 276 70 -7 276 144 -7 air
execute in minecraft:overworld run fill 276 58 -6 276 66 -6 stone
execute in minecraft:overworld run fill 276 67 -6 276 68 -6 dirt
execute in minecraft:overworld run setblock 276 69 -6 grass_block
execute in minecraft:overworld run fill 276 70 -6 276 144 -6 air
execute in minecraft:overworld run fill 276 58 -5 276 66 -5 stone
execute in minecraft:overworld run fill 276 67 -5 276 68 -5 dirt
execute in minecraft:overworld run setblock 276 69 -5 coarse_dirt
execute in minecraft:overworld run fill 276 70 -5 276 144 -5 air
execute in minecraft:overworld run fill 276 58 -4 276 66 -4 stone
execute in minecraft:overworld run fill 276 67 -4 276 68 -4 dirt
execute in minecraft:overworld run setblock 276 69 -4 grass_block
execute in minecraft:overworld run fill 276 70 -4 276 144 -4 air
execute in minecraft:overworld run fill 276 58 -3 276 66 -3 stone
execute in minecraft:overworld run fill 276 67 -3 276 68 -3 dirt
execute in minecraft:overworld run setblock 276 69 -3 grass_block
execute in minecraft:overworld run fill 276 70 -3 276 144 -3 air
execute in minecraft:overworld run setblock 276 70 -3 grass
execute in minecraft:overworld run fill 276 58 -2 276 66 -2 stone
execute in minecraft:overworld run fill 276 67 -2 276 68 -2 dirt
execute in minecraft:overworld run setblock 276 69 -2 coarse_dirt
execute in minecraft:overworld run fill 276 70 -2 276 144 -2 air
execute in minecraft:overworld run fill 276 58 -1 276 65 -1 stone
execute in minecraft:overworld run fill 276 66 -1 276 67 -1 dirt
execute in minecraft:overworld run setblock 276 68 -1 grass_block
execute in minecraft:overworld run fill 276 69 -1 276 144 -1 air
execute in minecraft:overworld run fill 276 58 0 276 65 0 stone
execute in minecraft:overworld run fill 276 66 0 276 67 0 dirt
execute in minecraft:overworld run setblock 276 68 0 coarse_dirt
execute in minecraft:overworld run fill 276 69 0 276 144 0 air
execute in minecraft:overworld run fill 276 58 1 276 65 1 stone
execute in minecraft:overworld run fill 276 66 1 276 67 1 dirt
execute in minecraft:overworld run setblock 276 68 1 coarse_dirt
execute in minecraft:overworld run fill 276 69 1 276 144 1 air
execute in minecraft:overworld run fill 276 58 2 276 65 2 stone
execute in minecraft:overworld run fill 276 66 2 276 67 2 dirt
execute in minecraft:overworld run setblock 276 68 2 coarse_dirt
execute in minecraft:overworld run fill 276 69 2 276 144 2 air
execute in minecraft:overworld run fill 276 58 3 276 65 3 stone
execute in minecraft:overworld run fill 276 66 3 276 67 3 dirt
execute in minecraft:overworld run setblock 276 68 3 grass_block
execute in minecraft:overworld run fill 276 69 3 276 144 3 air
execute in minecraft:overworld run fill 276 58 4 276 64 4 stone
execute in minecraft:overworld run fill 276 65 4 276 66 4 dirt
execute in minecraft:overworld run setblock 276 67 4 coarse_dirt
execute in minecraft:overworld run fill 276 68 4 276 144 4 air
execute in minecraft:overworld run setblock 276 68 4 grass
execute in minecraft:overworld run fill 276 58 5 276 64 5 stone
execute in minecraft:overworld run fill 276 65 5 276 66 5 dirt
execute in minecraft:overworld run setblock 276 67 5 coarse_dirt
execute in minecraft:overworld run fill 276 68 5 276 144 5 air
execute in minecraft:overworld run fill 276 58 6 276 64 6 stone
execute in minecraft:overworld run fill 276 65 6 276 66 6 dirt
execute in minecraft:overworld run setblock 276 67 6 grass_block
execute in minecraft:overworld run fill 276 68 6 276 144 6 air
execute in minecraft:overworld run fill 276 58 7 276 64 7 stone
execute in minecraft:overworld run fill 276 65 7 276 66 7 dirt
execute in minecraft:overworld run setblock 276 67 7 coarse_dirt
execute in minecraft:overworld run fill 276 68 7 276 144 7 air
execute in minecraft:overworld run fill 276 58 8 276 63 8 stone
execute in minecraft:overworld run fill 276 64 8 276 65 8 dirt
execute in minecraft:overworld run setblock 276 66 8 coarse_dirt
execute in minecraft:overworld run fill 276 67 8 276 144 8 air
execute in minecraft:overworld run fill 276 58 9 276 63 9 stone
execute in minecraft:overworld run fill 276 64 9 276 65 9 dirt
execute in minecraft:overworld run setblock 276 66 9 grass_block
execute in minecraft:overworld run fill 276 67 9 276 144 9 air
execute in minecraft:overworld run fill 276 58 10 276 63 10 stone
execute in minecraft:overworld run fill 276 64 10 276 65 10 dirt
execute in minecraft:overworld run setblock 276 66 10 coarse_dirt
execute in minecraft:overworld run fill 276 67 10 276 144 10 air
execute in minecraft:overworld run fill 276 58 11 276 62 11 stone
execute in minecraft:overworld run fill 276 63 11 276 64 11 dirt
execute in minecraft:overworld run setblock 276 65 11 coarse_dirt
execute in minecraft:overworld run fill 276 66 11 276 144 11 air
execute in minecraft:overworld run fill 276 58 12 276 62 12 stone
execute in minecraft:overworld run fill 276 63 12 276 64 12 dirt
execute in minecraft:overworld run setblock 276 65 12 coarse_dirt
execute in minecraft:overworld run fill 276 66 12 276 144 12 air
execute in minecraft:overworld run fill 276 58 13 276 62 13 stone
execute in minecraft:overworld run fill 276 63 13 276 64 13 dirt
execute in minecraft:overworld run setblock 276 65 13 coarse_dirt
execute in minecraft:overworld run fill 276 66 13 276 144 13 air
execute in minecraft:overworld run fill 276 58 14 276 62 14 stone
execute in minecraft:overworld run fill 276 63 14 276 64 14 dirt
execute in minecraft:overworld run setblock 276 65 14 coarse_dirt
execute in minecraft:overworld run fill 276 66 14 276 144 14 air
execute in minecraft:overworld run fill 276 58 15 276 62 15 stone
execute in minecraft:overworld run fill 276 63 15 276 64 15 dirt
execute in minecraft:overworld run setblock 276 65 15 coarse_dirt
schedule function blade_gallery:random/burned/part_109 1t replace
