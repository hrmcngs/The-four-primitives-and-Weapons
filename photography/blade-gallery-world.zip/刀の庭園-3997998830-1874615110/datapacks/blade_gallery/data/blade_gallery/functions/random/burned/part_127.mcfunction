execute in minecraft:overworld run fill 288 58 -15 288 70 -15 stone
execute in minecraft:overworld run fill 288 71 -15 288 72 -15 dirt
execute in minecraft:overworld run setblock 288 73 -15 coarse_dirt
execute in minecraft:overworld run fill 288 74 -15 288 144 -15 air
execute in minecraft:overworld run fill 288 58 -14 288 70 -14 stone
execute in minecraft:overworld run fill 288 71 -14 288 72 -14 dirt
execute in minecraft:overworld run setblock 288 73 -14 grass_block
execute in minecraft:overworld run fill 288 74 -14 288 144 -14 air
execute in minecraft:overworld run setblock 288 74 -14 mossy_cobblestone
execute in minecraft:overworld run fill 288 58 -13 288 70 -13 stone
execute in minecraft:overworld run fill 288 71 -13 288 72 -13 dirt
execute in minecraft:overworld run setblock 288 73 -13 coarse_dirt
execute in minecraft:overworld run fill 288 74 -13 288 144 -13 air
execute in minecraft:overworld run fill 288 58 -12 288 69 -12 stone
execute in minecraft:overworld run fill 288 70 -12 288 71 -12 dirt
execute in minecraft:overworld run setblock 288 72 -12 coarse_dirt
execute in minecraft:overworld run fill 288 73 -12 288 144 -12 air
execute in minecraft:overworld run fill 288 58 -11 288 70 -11 stone
execute in minecraft:overworld run fill 288 71 -11 288 72 -11 dirt
execute in minecraft:overworld run setblock 288 73 -11 grass_block
execute in minecraft:overworld run fill 288 74 -11 288 144 -11 air
execute in minecraft:overworld run fill 288 58 -10 288 70 -10 stone
execute in minecraft:overworld run fill 288 71 -10 288 72 -10 dirt
execute in minecraft:overworld run setblock 288 73 -10 coarse_dirt
execute in minecraft:overworld run fill 288 74 -10 288 144 -10 air
execute in minecraft:overworld run fill 288 58 -9 288 70 -9 stone
execute in minecraft:overworld run fill 288 71 -9 288 72 -9 dirt
execute in minecraft:overworld run setblock 288 73 -9 grass_block
execute in minecraft:overworld run fill 288 74 -9 288 144 -9 air
execute in minecraft:overworld run fill 288 58 -8 288 70 -8 stone
execute in minecraft:overworld run fill 288 71 -8 288 72 -8 dirt
execute in minecraft:overworld run setblock 288 73 -8 coarse_dirt
execute in minecraft:overworld run fill 288 74 -8 288 144 -8 air
execute in minecraft:overworld run fill 288 58 -7 288 70 -7 stone
execute in minecraft:overworld run fill 288 71 -7 288 72 -7 dirt
execute in minecraft:overworld run setblock 288 73 -7 coarse_dirt
execute in minecraft:overworld run fill 288 74 -7 288 144 -7 air
execute in minecraft:overworld run fill 288 58 -6 288 70 -6 stone
execute in minecraft:overworld run fill 288 71 -6 288 72 -6 dirt
execute in minecraft:overworld run setblock 288 73 -6 grass_block
execute in minecraft:overworld run fill 288 74 -6 288 144 -6 air
execute in minecraft:overworld run fill 288 58 -5 288 70 -5 stone
execute in minecraft:overworld run fill 288 71 -5 288 72 -5 dirt
execute in minecraft:overworld run setblock 288 73 -5 coarse_dirt
execute in minecraft:overworld run fill 288 74 -5 288 144 -5 air
execute in minecraft:overworld run fill 288 58 -4 288 70 -4 stone
execute in minecraft:overworld run fill 288 71 -4 288 72 -4 dirt
execute in minecraft:overworld run setblock 288 73 -4 coarse_dirt
execute in minecraft:overworld run fill 288 74 -4 288 144 -4 air
execute in minecraft:overworld run fill 288 58 -3 288 70 -3 stone
execute in minecraft:overworld run fill 288 71 -3 288 72 -3 dirt
execute in minecraft:overworld run setblock 288 73 -3 coarse_dirt
execute in minecraft:overworld run fill 288 74 -3 288 144 -3 air
execute in minecraft:overworld run setblock 288 74 -3 grass
execute in minecraft:overworld run fill 288 58 -2 288 70 -2 stone
execute in minecraft:overworld run fill 288 71 -2 288 72 -2 dirt
execute in minecraft:overworld run setblock 288 73 -2 grass_block
execute in minecraft:overworld run fill 288 74 -2 288 144 -2 air
execute in minecraft:overworld run fill 288 58 -1 288 70 -1 stone
execute in minecraft:overworld run fill 288 71 -1 288 72 -1 dirt
execute in minecraft:overworld run setblock 288 73 -1 coarse_dirt
execute in minecraft:overworld run fill 288 74 -1 288 144 -1 air
execute in minecraft:overworld run fill 288 58 0 288 70 0 stone
execute in minecraft:overworld run fill 288 71 0 288 72 0 dirt
execute in minecraft:overworld run setblock 288 73 0 coarse_dirt
execute in minecraft:overworld run fill 288 74 0 288 144 0 air
execute in minecraft:overworld run fill 288 58 1 288 70 1 stone
execute in minecraft:overworld run fill 288 71 1 288 72 1 dirt
execute in minecraft:overworld run setblock 288 73 1 coarse_dirt
execute in minecraft:overworld run fill 288 74 1 288 144 1 air
execute in minecraft:overworld run fill 288 58 2 288 69 2 stone
execute in minecraft:overworld run fill 288 70 2 288 71 2 dirt
execute in minecraft:overworld run setblock 288 72 2 coarse_dirt
execute in minecraft:overworld run fill 288 73 2 288 144 2 air
execute in minecraft:overworld run fill 288 58 3 288 69 3 stone
execute in minecraft:overworld run fill 288 70 3 288 71 3 dirt
execute in minecraft:overworld run setblock 288 72 3 coarse_dirt
execute in minecraft:overworld run fill 288 73 3 288 144 3 air
execute in minecraft:overworld run fill 288 58 4 288 69 4 stone
execute in minecraft:overworld run fill 288 70 4 288 71 4 dirt
execute in minecraft:overworld run setblock 288 72 4 coarse_dirt
execute in minecraft:overworld run fill 288 73 4 288 144 4 air
execute in minecraft:overworld run fill 288 58 5 288 68 5 stone
execute in minecraft:overworld run fill 288 69 5 288 70 5 dirt
execute in minecraft:overworld run setblock 288 71 5 coarse_dirt
execute in minecraft:overworld run fill 288 72 5 288 144 5 air
execute in minecraft:overworld run fill 288 58 6 288 67 6 stone
execute in minecraft:overworld run fill 288 68 6 288 69 6 dirt
execute in minecraft:overworld run setblock 288 70 6 coarse_dirt
execute in minecraft:overworld run fill 288 71 6 288 144 6 air
execute in minecraft:overworld run fill 288 58 7 288 67 7 stone
execute in minecraft:overworld run fill 288 68 7 288 69 7 dirt
execute in minecraft:overworld run setblock 288 70 7 grass_block
execute in minecraft:overworld run fill 288 71 7 288 144 7 air
execute in minecraft:overworld run fill 288 58 8 288 67 8 stone
execute in minecraft:overworld run fill 288 68 8 288 69 8 dirt
execute in minecraft:overworld run setblock 288 70 8 grass_block
execute in minecraft:overworld run fill 288 71 8 288 144 8 air
execute in minecraft:overworld run fill 288 58 9 288 66 9 stone
execute in minecraft:overworld run fill 288 67 9 288 68 9 dirt
execute in minecraft:overworld run setblock 288 69 9 grass_block
execute in minecraft:overworld run fill 288 70 9 288 144 9 air
execute in minecraft:overworld run fill 288 58 10 288 66 10 stone
execute in minecraft:overworld run fill 288 67 10 288 68 10 dirt
execute in minecraft:overworld run setblock 288 69 10 grass_block
execute in minecraft:overworld run fill 288 70 10 288 144 10 air
execute in minecraft:overworld run fill 288 58 11 288 66 11 stone
execute in minecraft:overworld run fill 288 67 11 288 68 11 dirt
execute in minecraft:overworld run setblock 288 69 11 coarse_dirt
execute in minecraft:overworld run fill 288 70 11 288 144 11 air
execute in minecraft:overworld run setblock 288 70 11 mossy_cobblestone
execute in minecraft:overworld run fill 288 58 12 288 66 12 stone
execute in minecraft:overworld run fill 288 67 12 288 68 12 dirt
execute in minecraft:overworld run setblock 288 69 12 coarse_dirt
execute in minecraft:overworld run fill 288 70 12 288 144 12 air
execute in minecraft:overworld run fill 288 58 13 288 66 13 stone
execute in minecraft:overworld run fill 288 67 13 288 68 13 dirt
execute in minecraft:overworld run setblock 288 69 13 coarse_dirt
execute in minecraft:overworld run fill 288 70 13 288 144 13 air
execute in minecraft:overworld run fill 288 58 14 288 66 14 stone
execute in minecraft:overworld run fill 288 67 14 288 68 14 dirt
execute in minecraft:overworld run setblock 288 69 14 coarse_dirt
execute in minecraft:overworld run fill 288 70 14 288 144 14 air
execute in minecraft:overworld run fill 288 58 15 288 65 15 stone
execute in minecraft:overworld run fill 288 66 15 288 67 15 dirt
execute in minecraft:overworld run setblock 288 68 15 grass_block
execute in minecraft:overworld run fill 288 69 15 288 144 15 air
execute in minecraft:overworld run fill 288 58 16 288 65 16 stone
execute in minecraft:overworld run fill 288 66 16 288 67 16 dirt
execute in minecraft:overworld run setblock 288 68 16 grass_block
execute in minecraft:overworld run fill 288 69 16 288 144 16 air
execute in minecraft:overworld run fill 288 58 17 288 65 17 stone
execute in minecraft:overworld run fill 288 66 17 288 67 17 dirt
execute in minecraft:overworld run setblock 288 68 17 grass_block
execute in minecraft:overworld run fill 288 69 17 288 144 17 air
execute in minecraft:overworld run fill 288 58 18 288 65 18 stone
execute in minecraft:overworld run fill 288 66 18 288 67 18 dirt
execute in minecraft:overworld run setblock 288 68 18 coarse_dirt
execute in minecraft:overworld run fill 288 69 18 288 144 18 air
execute in minecraft:overworld run fill 288 58 19 288 65 19 stone
execute in minecraft:overworld run fill 288 66 19 288 67 19 dirt
execute in minecraft:overworld run setblock 288 68 19 coarse_dirt
execute in minecraft:overworld run fill 288 69 19 288 144 19 air
execute in minecraft:overworld run fill 288 58 20 288 65 20 stone
execute in minecraft:overworld run fill 288 66 20 288 67 20 dirt
execute in minecraft:overworld run setblock 288 68 20 grass_block
execute in minecraft:overworld run fill 288 69 20 288 144 20 air
execute in minecraft:overworld run fill 288 58 21 288 65 21 stone
execute in minecraft:overworld run fill 288 66 21 288 67 21 dirt
execute in minecraft:overworld run setblock 288 68 21 grass_block
execute in minecraft:overworld run fill 288 69 21 288 144 21 air
execute in minecraft:overworld run fill 288 58 22 288 65 22 stone
execute in minecraft:overworld run fill 288 66 22 288 67 22 dirt
execute in minecraft:overworld run setblock 288 68 22 coarse_dirt
execute in minecraft:overworld run fill 288 69 22 288 144 22 air
execute in minecraft:overworld run fill 288 58 23 288 65 23 stone
execute in minecraft:overworld run fill 288 66 23 288 67 23 dirt
execute in minecraft:overworld run setblock 288 68 23 grass_block
execute in minecraft:overworld run fill 288 69 23 288 144 23 air
execute in minecraft:overworld run fill 288 58 24 288 65 24 stone
execute in minecraft:overworld run fill 288 66 24 288 67 24 dirt
execute in minecraft:overworld run setblock 288 68 24 grass_block
execute in minecraft:overworld run fill 288 69 24 288 144 24 air
execute in minecraft:overworld run fill 288 58 25 288 65 25 stone
execute in minecraft:overworld run fill 288 66 25 288 67 25 dirt
execute in minecraft:overworld run setblock 288 68 25 grass_block
execute in minecraft:overworld run fill 288 69 25 288 144 25 air
execute in minecraft:overworld run fill 288 58 26 288 65 26 stone
execute in minecraft:overworld run fill 288 66 26 288 67 26 dirt
execute in minecraft:overworld run setblock 288 68 26 grass_block
execute in minecraft:overworld run fill 288 69 26 288 144 26 air
execute in minecraft:overworld run fill 288 58 27 288 65 27 stone
execute in minecraft:overworld run fill 288 66 27 288 67 27 dirt
execute in minecraft:overworld run setblock 288 68 27 coarse_dirt
execute in minecraft:overworld run fill 288 69 27 288 144 27 air
execute in minecraft:overworld run setblock 288 69 27 grass
execute in minecraft:overworld run fill 288 58 28 288 65 28 stone
execute in minecraft:overworld run fill 288 66 28 288 67 28 dirt
execute in minecraft:overworld run setblock 288 68 28 coarse_dirt
execute in minecraft:overworld run fill 288 69 28 288 144 28 air
execute in minecraft:overworld run fill 288 58 29 288 64 29 stone
execute in minecraft:overworld run fill 288 65 29 288 66 29 dirt
execute in minecraft:overworld run setblock 288 67 29 coarse_dirt
execute in minecraft:overworld run fill 288 68 29 288 144 29 air
execute in minecraft:overworld run fill 288 58 30 288 64 30 stone
execute in minecraft:overworld run fill 288 65 30 288 66 30 dirt
execute in minecraft:overworld run setblock 288 67 30 grass_block
execute in minecraft:overworld run fill 288 68 30 288 144 30 air
execute in minecraft:overworld run fill 288 58 31 288 64 31 stone
execute in minecraft:overworld run fill 288 65 31 288 66 31 dirt
execute in minecraft:overworld run setblock 288 67 31 coarse_dirt
execute in minecraft:overworld run fill 288 68 31 288 144 31 air
execute in minecraft:overworld run fill 288 58 32 288 63 32 stone
execute in minecraft:overworld run fill 288 64 32 288 65 32 dirt
execute in minecraft:overworld run setblock 288 66 32 coarse_dirt
execute in minecraft:overworld run fill 288 67 32 288 144 32 air
execute in minecraft:overworld run fill 288 58 33 288 63 33 stone
execute in minecraft:overworld run fill 288 64 33 288 65 33 dirt
execute in minecraft:overworld run setblock 288 66 33 coarse_dirt
execute in minecraft:overworld run fill 288 67 33 288 144 33 air
execute in minecraft:overworld run setblock 288 67 33 mossy_cobblestone
execute in minecraft:overworld run fill 288 58 34 288 63 34 stone
execute in minecraft:overworld run fill 288 64 34 288 65 34 dirt
execute in minecraft:overworld run setblock 288 66 34 coarse_dirt
execute in minecraft:overworld run fill 288 67 34 288 144 34 air
execute in minecraft:overworld run setblock 288 67 34 mossy_cobblestone
execute in minecraft:overworld run fill 288 58 35 288 62 35 stone
execute in minecraft:overworld run fill 288 63 35 288 64 35 dirt
execute in minecraft:overworld run setblock 288 65 35 coarse_dirt
execute in minecraft:overworld run fill 288 66 35 288 144 35 air
execute in minecraft:overworld run fill 288 58 36 288 62 36 stone
execute in minecraft:overworld run fill 288 63 36 288 64 36 dirt
execute in minecraft:overworld run setblock 288 65 36 grass_block
execute in minecraft:overworld run fill 288 66 36 288 144 36 air
execute in minecraft:overworld run fill 288 58 37 288 62 37 stone
execute in minecraft:overworld run fill 288 63 37 288 64 37 dirt
execute in minecraft:overworld run setblock 288 65 37 coarse_dirt
execute in minecraft:overworld run fill 288 66 37 288 144 37 air
execute in minecraft:overworld run fill 288 58 38 288 62 38 stone
execute in minecraft:overworld run fill 288 63 38 288 64 38 dirt
execute in minecraft:overworld run setblock 288 65 38 coarse_dirt
execute in minecraft:overworld run fill 288 66 38 288 144 38 air
execute in minecraft:overworld run setblock 288 66 38 grass
execute in minecraft:overworld run fill 288 58 39 288 62 39 stone
execute in minecraft:overworld run fill 288 63 39 288 64 39 dirt
execute in minecraft:overworld run setblock 288 65 39 coarse_dirt
execute in minecraft:overworld run fill 288 66 39 288 144 39 air
execute in minecraft:overworld run fill 288 58 40 288 62 40 stone
execute in minecraft:overworld run fill 288 63 40 288 64 40 dirt
execute in minecraft:overworld run setblock 288 65 40 coarse_dirt
execute in minecraft:overworld run fill 288 66 40 288 144 40 air
execute in minecraft:overworld run fill 288 58 41 288 62 41 stone
execute in minecraft:overworld run fill 288 63 41 288 64 41 dirt
execute in minecraft:overworld run setblock 288 65 41 coarse_dirt
execute in minecraft:overworld run fill 288 66 41 288 144 41 air
execute in minecraft:overworld run setblock 288 66 41 grass
execute in minecraft:overworld run fill 288 58 42 288 62 42 stone
execute in minecraft:overworld run fill 288 63 42 288 64 42 dirt
execute in minecraft:overworld run setblock 288 65 42 coarse_dirt
execute in minecraft:overworld run fill 288 66 42 288 144 42 air
execute in minecraft:overworld run fill 288 58 43 288 62 43 stone
execute in minecraft:overworld run fill 288 63 43 288 64 43 dirt
execute in minecraft:overworld run setblock 288 65 43 coarse_dirt
execute in minecraft:overworld run fill 288 66 43 288 144 43 air
execute in minecraft:overworld run fill 288 58 44 288 62 44 stone
execute in minecraft:overworld run fill 288 63 44 288 64 44 dirt
execute in minecraft:overworld run setblock 288 65 44 coarse_dirt
execute in minecraft:overworld run fill 288 66 44 288 144 44 air
execute in minecraft:overworld run fill 288 58 45 288 62 45 stone
execute in minecraft:overworld run fill 288 63 45 288 64 45 dirt
execute in minecraft:overworld run setblock 288 65 45 grass_block
execute in minecraft:overworld run fill 288 66 45 288 144 45 air
execute in minecraft:overworld run fill 288 58 46 288 61 46 stone
execute in minecraft:overworld run fill 288 62 46 288 63 46 dirt
execute in minecraft:overworld run setblock 288 64 46 grass_block
execute in minecraft:overworld run fill 288 65 46 288 144 46 air
schedule function blade_gallery:random/burned/part_128 1t replace
