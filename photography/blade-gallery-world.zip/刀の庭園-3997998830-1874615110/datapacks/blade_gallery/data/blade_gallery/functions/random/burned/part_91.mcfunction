execute in minecraft:overworld run fill 265 59 27 265 64 27 water
execute in minecraft:overworld run fill 265 58 28 265 55 28 stone
execute in minecraft:overworld run fill 265 56 28 265 57 28 dirt
execute in minecraft:overworld run setblock 265 58 28 gravel
execute in minecraft:overworld run fill 265 59 28 265 144 28 air
execute in minecraft:overworld run fill 265 59 28 265 64 28 water
execute in minecraft:overworld run fill 265 58 29 265 55 29 stone
execute in minecraft:overworld run fill 265 56 29 265 57 29 dirt
execute in minecraft:overworld run setblock 265 58 29 gravel
execute in minecraft:overworld run fill 265 59 29 265 144 29 air
execute in minecraft:overworld run fill 265 59 29 265 64 29 water
execute in minecraft:overworld run fill 265 58 30 265 55 30 stone
execute in minecraft:overworld run fill 265 56 30 265 57 30 dirt
execute in minecraft:overworld run setblock 265 58 30 gravel
execute in minecraft:overworld run fill 265 59 30 265 144 30 air
execute in minecraft:overworld run fill 265 59 30 265 64 30 water
execute in minecraft:overworld run fill 265 58 31 265 55 31 stone
execute in minecraft:overworld run fill 265 56 31 265 57 31 dirt
execute in minecraft:overworld run setblock 265 58 31 gravel
execute in minecraft:overworld run fill 265 59 31 265 144 31 air
execute in minecraft:overworld run fill 265 59 31 265 64 31 water
execute in minecraft:overworld run fill 265 58 32 265 55 32 stone
execute in minecraft:overworld run fill 265 56 32 265 57 32 dirt
execute in minecraft:overworld run setblock 265 58 32 gravel
execute in minecraft:overworld run fill 265 59 32 265 144 32 air
execute in minecraft:overworld run fill 265 59 32 265 64 32 water
execute in minecraft:overworld run fill 265 58 33 265 55 33 stone
execute in minecraft:overworld run fill 265 56 33 265 57 33 dirt
execute in minecraft:overworld run setblock 265 58 33 gravel
execute in minecraft:overworld run fill 265 59 33 265 144 33 air
execute in minecraft:overworld run fill 265 59 33 265 64 33 water
execute in minecraft:overworld run fill 265 58 34 265 56 34 stone
execute in minecraft:overworld run fill 265 57 34 265 58 34 dirt
execute in minecraft:overworld run setblock 265 59 34 gravel
execute in minecraft:overworld run fill 265 60 34 265 144 34 air
execute in minecraft:overworld run fill 265 60 34 265 64 34 water
execute in minecraft:overworld run fill 265 58 35 265 56 35 stone
execute in minecraft:overworld run fill 265 57 35 265 58 35 dirt
execute in minecraft:overworld run setblock 265 59 35 gravel
execute in minecraft:overworld run fill 265 60 35 265 144 35 air
execute in minecraft:overworld run fill 265 60 35 265 64 35 water
execute in minecraft:overworld run fill 265 58 36 265 56 36 stone
execute in minecraft:overworld run fill 265 57 36 265 58 36 dirt
execute in minecraft:overworld run setblock 265 59 36 gravel
execute in minecraft:overworld run fill 265 60 36 265 144 36 air
execute in minecraft:overworld run fill 265 60 36 265 64 36 water
execute in minecraft:overworld run fill 265 58 37 265 56 37 stone
execute in minecraft:overworld run fill 265 57 37 265 58 37 dirt
execute in minecraft:overworld run setblock 265 59 37 gravel
execute in minecraft:overworld run fill 265 60 37 265 144 37 air
execute in minecraft:overworld run fill 265 60 37 265 64 37 water
execute in minecraft:overworld run fill 265 58 38 265 57 38 stone
execute in minecraft:overworld run fill 265 58 38 265 59 38 dirt
execute in minecraft:overworld run setblock 265 60 38 gravel
execute in minecraft:overworld run fill 265 61 38 265 144 38 air
execute in minecraft:overworld run fill 265 61 38 265 64 38 water
execute in minecraft:overworld run fill 265 58 39 265 57 39 stone
execute in minecraft:overworld run fill 265 58 39 265 59 39 dirt
execute in minecraft:overworld run setblock 265 60 39 gravel
execute in minecraft:overworld run fill 265 61 39 265 144 39 air
execute in minecraft:overworld run fill 265 61 39 265 64 39 water
execute in minecraft:overworld run fill 265 58 40 265 58 40 stone
execute in minecraft:overworld run fill 265 59 40 265 60 40 dirt
execute in minecraft:overworld run setblock 265 61 40 gravel
execute in minecraft:overworld run fill 265 62 40 265 144 40 air
execute in minecraft:overworld run fill 265 62 40 265 64 40 water
execute in minecraft:overworld run fill 265 58 41 265 59 41 stone
execute in minecraft:overworld run fill 265 60 41 265 61 41 dirt
execute in minecraft:overworld run setblock 265 62 41 gravel
execute in minecraft:overworld run fill 265 63 41 265 144 41 air
execute in minecraft:overworld run fill 265 63 41 265 64 41 water
execute in minecraft:overworld run fill 265 58 42 265 59 42 stone
execute in minecraft:overworld run fill 265 60 42 265 61 42 dirt
execute in minecraft:overworld run setblock 265 62 42 gravel
execute in minecraft:overworld run fill 265 63 42 265 144 42 air
execute in minecraft:overworld run fill 265 63 42 265 64 42 water
execute in minecraft:overworld run fill 265 58 43 265 60 43 stone
execute in minecraft:overworld run fill 265 61 43 265 62 43 dirt
execute in minecraft:overworld run setblock 265 63 43 gravel
execute in minecraft:overworld run fill 265 64 43 265 144 43 air
execute in minecraft:overworld run fill 265 64 43 265 64 43 water
execute in minecraft:overworld run fill 265 58 44 265 60 44 stone
execute in minecraft:overworld run fill 265 61 44 265 62 44 dirt
execute in minecraft:overworld run setblock 265 63 44 gravel
execute in minecraft:overworld run fill 265 64 44 265 144 44 air
execute in minecraft:overworld run fill 265 64 44 265 64 44 water
execute in minecraft:overworld run fill 265 58 45 265 61 45 stone
execute in minecraft:overworld run fill 265 62 45 265 63 45 dirt
execute in minecraft:overworld run setblock 265 64 45 coarse_dirt
execute in minecraft:overworld run fill 265 65 45 265 144 45 air
execute in minecraft:overworld run fill 265 58 46 265 61 46 stone
execute in minecraft:overworld run fill 265 62 46 265 63 46 dirt
execute in minecraft:overworld run setblock 265 64 46 grass_block
execute in minecraft:overworld run fill 265 65 46 265 144 46 air
execute in minecraft:overworld run fill 265 58 47 265 61 47 stone
execute in minecraft:overworld run fill 265 62 47 265 63 47 dirt
execute in minecraft:overworld run setblock 265 64 47 coarse_dirt
execute in minecraft:overworld run fill 265 65 47 265 144 47 air
execute in minecraft:overworld run fill 266 58 -48 266 61 -48 stone
execute in minecraft:overworld run fill 266 62 -48 266 63 -48 dirt
execute in minecraft:overworld run setblock 266 64 -48 coarse_dirt
execute in minecraft:overworld run fill 266 65 -48 266 144 -48 air
execute in minecraft:overworld run fill 266 58 -47 266 63 -47 stone
execute in minecraft:overworld run fill 266 64 -47 266 65 -47 dirt
execute in minecraft:overworld run setblock 266 66 -47 coarse_dirt
execute in minecraft:overworld run fill 266 67 -47 266 144 -47 air
execute in minecraft:overworld run fill 266 58 -46 266 65 -46 stone
execute in minecraft:overworld run fill 266 66 -46 266 67 -46 dirt
execute in minecraft:overworld run setblock 266 68 -46 grass_block
execute in minecraft:overworld run fill 266 69 -46 266 144 -46 air
execute in minecraft:overworld run fill 266 58 -45 266 67 -45 stone
execute in minecraft:overworld run fill 266 68 -45 266 69 -45 dirt
execute in minecraft:overworld run setblock 266 70 -45 coarse_dirt
execute in minecraft:overworld run fill 266 71 -45 266 144 -45 air
execute in minecraft:overworld run fill 266 58 -44 266 68 -44 stone
execute in minecraft:overworld run fill 266 69 -44 266 70 -44 dirt
execute in minecraft:overworld run setblock 266 71 -44 grass_block
execute in minecraft:overworld run fill 266 72 -44 266 144 -44 air
execute in minecraft:overworld run fill 266 58 -43 266 70 -43 stone
execute in minecraft:overworld run fill 266 71 -43 266 72 -43 dirt
execute in minecraft:overworld run setblock 266 73 -43 coarse_dirt
execute in minecraft:overworld run fill 266 74 -43 266 144 -43 air
execute in minecraft:overworld run fill 266 58 -42 266 72 -42 stone
execute in minecraft:overworld run fill 266 73 -42 266 74 -42 dirt
execute in minecraft:overworld run setblock 266 75 -42 grass_block
execute in minecraft:overworld run fill 266 76 -42 266 144 -42 air
execute in minecraft:overworld run fill 266 58 -41 266 74 -41 stone
execute in minecraft:overworld run fill 266 75 -41 266 76 -41 dirt
execute in minecraft:overworld run setblock 266 77 -41 coarse_dirt
execute in minecraft:overworld run fill 266 78 -41 266 144 -41 air
execute in minecraft:overworld run setblock 266 78 -41 grass
execute in minecraft:overworld run fill 266 58 -40 266 75 -40 stone
execute in minecraft:overworld run fill 266 76 -40 266 77 -40 dirt
execute in minecraft:overworld run setblock 266 78 -40 coarse_dirt
execute in minecraft:overworld run fill 266 79 -40 266 144 -40 air
execute in minecraft:overworld run fill 266 58 -39 266 77 -39 stone
execute in minecraft:overworld run fill 266 78 -39 266 79 -39 dirt
execute in minecraft:overworld run setblock 266 80 -39 coarse_dirt
execute in minecraft:overworld run fill 266 81 -39 266 144 -39 air
execute in minecraft:overworld run fill 266 58 -38 266 78 -38 stone
execute in minecraft:overworld run fill 266 79 -38 266 80 -38 dirt
execute in minecraft:overworld run setblock 266 81 -38 grass_block
execute in minecraft:overworld run fill 266 82 -38 266 144 -38 air
execute in minecraft:overworld run fill 266 58 -37 266 78 -37 stone
execute in minecraft:overworld run fill 266 79 -37 266 80 -37 dirt
execute in minecraft:overworld run setblock 266 81 -37 grass_block
execute in minecraft:overworld run fill 266 82 -37 266 144 -37 air
execute in minecraft:overworld run setblock 266 82 -37 grass
execute in minecraft:overworld run fill 266 58 -36 266 78 -36 stone
execute in minecraft:overworld run fill 266 79 -36 266 80 -36 dirt
execute in minecraft:overworld run setblock 266 81 -36 coarse_dirt
execute in minecraft:overworld run fill 266 82 -36 266 144 -36 air
execute in minecraft:overworld run fill 266 58 -35 266 77 -35 stone
execute in minecraft:overworld run fill 266 78 -35 266 79 -35 dirt
execute in minecraft:overworld run setblock 266 80 -35 grass_block
execute in minecraft:overworld run fill 266 81 -35 266 144 -35 air
execute in minecraft:overworld run fill 266 58 -34 266 77 -34 stone
execute in minecraft:overworld run fill 266 78 -34 266 79 -34 dirt
execute in minecraft:overworld run setblock 266 80 -34 coarse_dirt
execute in minecraft:overworld run fill 266 81 -34 266 144 -34 air
execute in minecraft:overworld run fill 266 58 -33 266 77 -33 stone
execute in minecraft:overworld run fill 266 78 -33 266 79 -33 dirt
execute in minecraft:overworld run setblock 266 80 -33 coarse_dirt
execute in minecraft:overworld run fill 266 81 -33 266 144 -33 air
execute in minecraft:overworld run fill 266 58 -32 266 77 -32 stone
execute in minecraft:overworld run fill 266 78 -32 266 79 -32 dirt
execute in minecraft:overworld run setblock 266 80 -32 grass_block
execute in minecraft:overworld run fill 266 81 -32 266 144 -32 air
execute in minecraft:overworld run setblock 266 81 -32 grass
execute in minecraft:overworld run fill 266 58 -31 266 76 -31 stone
execute in minecraft:overworld run fill 266 77 -31 266 78 -31 dirt
execute in minecraft:overworld run setblock 266 79 -31 grass_block
execute in minecraft:overworld run fill 266 80 -31 266 144 -31 air
execute in minecraft:overworld run fill 266 58 -30 266 76 -30 stone
execute in minecraft:overworld run fill 266 77 -30 266 78 -30 dirt
execute in minecraft:overworld run setblock 266 79 -30 coarse_dirt
execute in minecraft:overworld run fill 266 80 -30 266 144 -30 air
execute in minecraft:overworld run fill 266 58 -29 266 76 -29 stone
execute in minecraft:overworld run fill 266 77 -29 266 78 -29 dirt
execute in minecraft:overworld run setblock 266 79 -29 coarse_dirt
execute in minecraft:overworld run fill 266 80 -29 266 144 -29 air
execute in minecraft:overworld run fill 266 58 -28 266 75 -28 stone
execute in minecraft:overworld run fill 266 76 -28 266 77 -28 dirt
execute in minecraft:overworld run setblock 266 78 -28 coarse_dirt
execute in minecraft:overworld run fill 266 79 -28 266 144 -28 air
execute in minecraft:overworld run setblock 266 79 -28 grass
execute in minecraft:overworld run fill 266 58 -27 266 75 -27 stone
execute in minecraft:overworld run fill 266 76 -27 266 77 -27 dirt
execute in minecraft:overworld run setblock 266 78 -27 grass_block
execute in minecraft:overworld run fill 266 79 -27 266 144 -27 air
execute in minecraft:overworld run fill 266 58 -26 266 74 -26 stone
execute in minecraft:overworld run fill 266 75 -26 266 76 -26 dirt
execute in minecraft:overworld run setblock 266 77 -26 coarse_dirt
execute in minecraft:overworld run fill 266 78 -26 266 144 -26 air
execute in minecraft:overworld run fill 266 58 -25 266 73 -25 stone
execute in minecraft:overworld run fill 266 74 -25 266 75 -25 dirt
execute in minecraft:overworld run setblock 266 76 -25 coarse_dirt
execute in minecraft:overworld run fill 266 77 -25 266 144 -25 air
execute in minecraft:overworld run setblock 266 77 -25 grass
execute in minecraft:overworld run fill 266 58 -24 266 73 -24 stone
execute in minecraft:overworld run fill 266 74 -24 266 75 -24 dirt
execute in minecraft:overworld run setblock 266 76 -24 grass_block
execute in minecraft:overworld run fill 266 77 -24 266 144 -24 air
execute in minecraft:overworld run fill 266 58 -23 266 72 -23 stone
execute in minecraft:overworld run fill 266 73 -23 266 74 -23 dirt
execute in minecraft:overworld run setblock 266 75 -23 grass_block
execute in minecraft:overworld run fill 266 76 -23 266 144 -23 air
execute in minecraft:overworld run fill 266 58 -22 266 71 -22 stone
execute in minecraft:overworld run fill 266 72 -22 266 73 -22 dirt
execute in minecraft:overworld run setblock 266 74 -22 coarse_dirt
execute in minecraft:overworld run fill 266 75 -22 266 144 -22 air
execute in minecraft:overworld run fill 266 58 -21 266 70 -21 stone
execute in minecraft:overworld run fill 266 71 -21 266 72 -21 dirt
execute in minecraft:overworld run setblock 266 73 -21 coarse_dirt
execute in minecraft:overworld run fill 266 74 -21 266 144 -21 air
execute in minecraft:overworld run setblock 266 74 -21 grass
execute in minecraft:overworld run fill 266 58 -20 266 69 -20 stone
execute in minecraft:overworld run fill 266 70 -20 266 71 -20 dirt
execute in minecraft:overworld run setblock 266 72 -20 grass_block
execute in minecraft:overworld run fill 266 73 -20 266 144 -20 air
execute in minecraft:overworld run setblock 266 73 -20 grass
execute in minecraft:overworld run fill 266 58 -19 266 68 -19 stone
execute in minecraft:overworld run fill 266 69 -19 266 70 -19 dirt
execute in minecraft:overworld run setblock 266 71 -19 coarse_dirt
execute in minecraft:overworld run fill 266 72 -19 266 144 -19 air
execute in minecraft:overworld run setblock 266 72 -19 grass
execute in minecraft:overworld run fill 266 58 -18 266 67 -18 stone
execute in minecraft:overworld run fill 266 68 -18 266 69 -18 dirt
execute in minecraft:overworld run setblock 266 70 -18 coarse_dirt
execute in minecraft:overworld run fill 266 71 -18 266 144 -18 air
execute in minecraft:overworld run fill 266 58 -17 266 66 -17 stone
execute in minecraft:overworld run fill 266 67 -17 266 68 -17 dirt
execute in minecraft:overworld run setblock 266 69 -17 coarse_dirt
execute in minecraft:overworld run fill 266 70 -17 266 144 -17 air
execute in minecraft:overworld run fill 266 58 -16 266 65 -16 stone
execute in minecraft:overworld run fill 266 66 -16 266 67 -16 dirt
execute in minecraft:overworld run setblock 266 68 -16 coarse_dirt
execute in minecraft:overworld run fill 266 69 -16 266 144 -16 air
execute in minecraft:overworld run fill 266 58 -15 266 64 -15 stone
execute in minecraft:overworld run fill 266 65 -15 266 66 -15 dirt
execute in minecraft:overworld run setblock 266 67 -15 coarse_dirt
execute in minecraft:overworld run fill 266 68 -15 266 144 -15 air
execute in minecraft:overworld run setblock 266 68 -15 grass
execute in minecraft:overworld run fill 266 58 -14 266 62 -14 stone
execute in minecraft:overworld run fill 266 63 -14 266 64 -14 dirt
execute in minecraft:overworld run setblock 266 65 -14 coarse_dirt
execute in minecraft:overworld run fill 266 66 -14 266 144 -14 air
execute in minecraft:overworld run fill 266 58 -13 266 61 -13 stone
execute in minecraft:overworld run fill 266 62 -13 266 63 -13 dirt
execute in minecraft:overworld run setblock 266 64 -13 grass_block
execute in minecraft:overworld run fill 266 65 -13 266 144 -13 air
execute in minecraft:overworld run fill 266 58 -12 266 60 -12 stone
execute in minecraft:overworld run fill 266 61 -12 266 62 -12 dirt
execute in minecraft:overworld run setblock 266 63 -12 gravel
execute in minecraft:overworld run fill 266 64 -12 266 144 -12 air
execute in minecraft:overworld run fill 266 64 -12 266 64 -12 water
schedule function blade_gallery:random/burned/part_92 1t replace
