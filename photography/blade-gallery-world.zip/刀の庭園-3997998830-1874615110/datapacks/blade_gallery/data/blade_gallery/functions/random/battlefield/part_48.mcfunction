execute in minecraft:overworld run fill 367 70 -14 367 144 -14 air
execute in minecraft:overworld run setblock 367 70 -14 grass
execute in minecraft:overworld run fill 367 58 -13 367 66 -13 stone
execute in minecraft:overworld run fill 367 67 -13 367 68 -13 dirt
execute in minecraft:overworld run setblock 367 69 -13 coarse_dirt
execute in minecraft:overworld run fill 367 70 -13 367 144 -13 air
execute in minecraft:overworld run fill 367 58 -12 367 66 -12 stone
execute in minecraft:overworld run fill 367 67 -12 367 68 -12 dirt
execute in minecraft:overworld run setblock 367 69 -12 grass_block
execute in minecraft:overworld run fill 367 70 -12 367 144 -12 air
execute in minecraft:overworld run fill 367 58 -11 367 66 -11 stone
execute in minecraft:overworld run fill 367 67 -11 367 68 -11 dirt
execute in minecraft:overworld run setblock 367 69 -11 grass_block
execute in minecraft:overworld run fill 367 70 -11 367 144 -11 air
execute in minecraft:overworld run fill 367 58 -10 367 66 -10 stone
execute in minecraft:overworld run fill 367 67 -10 367 68 -10 dirt
execute in minecraft:overworld run setblock 367 69 -10 coarse_dirt
execute in minecraft:overworld run fill 367 70 -10 367 144 -10 air
execute in minecraft:overworld run fill 367 58 -9 367 66 -9 stone
execute in minecraft:overworld run fill 367 67 -9 367 68 -9 dirt
execute in minecraft:overworld run setblock 367 69 -9 coarse_dirt
execute in minecraft:overworld run fill 367 70 -9 367 144 -9 air
execute in minecraft:overworld run fill 367 58 -8 367 66 -8 stone
execute in minecraft:overworld run fill 367 67 -8 367 68 -8 dirt
execute in minecraft:overworld run setblock 367 69 -8 coarse_dirt
execute in minecraft:overworld run fill 367 70 -8 367 144 -8 air
execute in minecraft:overworld run fill 367 58 -7 367 66 -7 stone
execute in minecraft:overworld run fill 367 67 -7 367 68 -7 dirt
execute in minecraft:overworld run setblock 367 69 -7 grass_block
execute in minecraft:overworld run fill 367 70 -7 367 144 -7 air
execute in minecraft:overworld run fill 367 58 -6 367 66 -6 stone
execute in minecraft:overworld run fill 367 67 -6 367 68 -6 dirt
execute in minecraft:overworld run setblock 367 69 -6 grass_block
execute in minecraft:overworld run fill 367 70 -6 367 144 -6 air
execute in minecraft:overworld run fill 367 58 -5 367 65 -5 stone
execute in minecraft:overworld run fill 367 66 -5 367 67 -5 dirt
execute in minecraft:overworld run setblock 367 68 -5 grass_block
execute in minecraft:overworld run fill 367 69 -5 367 144 -5 air
execute in minecraft:overworld run fill 367 58 -4 367 65 -4 stone
execute in minecraft:overworld run fill 367 66 -4 367 67 -4 dirt
execute in minecraft:overworld run setblock 367 68 -4 coarse_dirt
execute in minecraft:overworld run fill 367 69 -4 367 144 -4 air
execute in minecraft:overworld run fill 367 58 -3 367 65 -3 stone
execute in minecraft:overworld run fill 367 66 -3 367 67 -3 dirt
execute in minecraft:overworld run setblock 367 68 -3 grass_block
execute in minecraft:overworld run fill 367 69 -3 367 144 -3 air
execute in minecraft:overworld run fill 367 58 -2 367 65 -2 stone
execute in minecraft:overworld run fill 367 66 -2 367 67 -2 dirt
execute in minecraft:overworld run setblock 367 68 -2 grass_block
execute in minecraft:overworld run fill 367 69 -2 367 144 -2 air
execute in minecraft:overworld run fill 367 58 -1 367 65 -1 stone
execute in minecraft:overworld run fill 367 66 -1 367 67 -1 dirt
execute in minecraft:overworld run setblock 367 68 -1 coarse_dirt
execute in minecraft:overworld run fill 367 69 -1 367 144 -1 air
execute in minecraft:overworld run fill 367 58 0 367 65 0 stone
execute in minecraft:overworld run fill 367 66 0 367 67 0 dirt
execute in minecraft:overworld run setblock 367 68 0 grass_block
execute in minecraft:overworld run fill 367 69 0 367 144 0 air
execute in minecraft:overworld run fill 367 58 1 367 65 1 stone
execute in minecraft:overworld run fill 367 66 1 367 67 1 dirt
execute in minecraft:overworld run setblock 367 68 1 coarse_dirt
execute in minecraft:overworld run fill 367 69 1 367 144 1 air
execute in minecraft:overworld run fill 367 58 2 367 65 2 stone
execute in minecraft:overworld run fill 367 66 2 367 67 2 dirt
execute in minecraft:overworld run setblock 367 68 2 grass_block
execute in minecraft:overworld run fill 367 69 2 367 144 2 air
execute in minecraft:overworld run fill 367 58 3 367 65 3 stone
execute in minecraft:overworld run fill 367 66 3 367 67 3 dirt
execute in minecraft:overworld run setblock 367 68 3 coarse_dirt
execute in minecraft:overworld run fill 367 69 3 367 144 3 air
execute in minecraft:overworld run fill 367 58 4 367 65 4 stone
execute in minecraft:overworld run fill 367 66 4 367 67 4 dirt
execute in minecraft:overworld run setblock 367 68 4 coarse_dirt
execute in minecraft:overworld run fill 367 69 4 367 144 4 air
execute in minecraft:overworld run fill 367 58 5 367 65 5 stone
execute in minecraft:overworld run fill 367 66 5 367 67 5 dirt
execute in minecraft:overworld run setblock 367 68 5 grass_block
execute in minecraft:overworld run fill 367 69 5 367 144 5 air
execute in minecraft:overworld run fill 367 58 6 367 65 6 stone
execute in minecraft:overworld run fill 367 66 6 367 67 6 dirt
execute in minecraft:overworld run setblock 367 68 6 grass_block
execute in minecraft:overworld run fill 367 69 6 367 144 6 air
execute in minecraft:overworld run fill 367 58 7 367 65 7 stone
execute in minecraft:overworld run fill 367 66 7 367 67 7 dirt
execute in minecraft:overworld run setblock 367 68 7 coarse_dirt
execute in minecraft:overworld run fill 367 69 7 367 144 7 air
execute in minecraft:overworld run fill 367 58 8 367 66 8 stone
execute in minecraft:overworld run fill 367 67 8 367 68 8 dirt
execute in minecraft:overworld run setblock 367 69 8 grass_block
execute in minecraft:overworld run fill 367 70 8 367 144 8 air
execute in minecraft:overworld run setblock 367 70 8 grass
execute in minecraft:overworld run fill 367 58 9 367 66 9 stone
execute in minecraft:overworld run fill 367 67 9 367 68 9 dirt
execute in minecraft:overworld run setblock 367 69 9 coarse_dirt
execute in minecraft:overworld run fill 367 70 9 367 144 9 air
execute in minecraft:overworld run fill 367 58 10 367 66 10 stone
execute in minecraft:overworld run fill 367 67 10 367 68 10 dirt
execute in minecraft:overworld run setblock 367 69 10 coarse_dirt
execute in minecraft:overworld run fill 367 70 10 367 144 10 air
execute in minecraft:overworld run fill 367 58 11 367 66 11 stone
execute in minecraft:overworld run fill 367 67 11 367 68 11 dirt
execute in minecraft:overworld run setblock 367 69 11 coarse_dirt
execute in minecraft:overworld run fill 367 70 11 367 144 11 air
execute in minecraft:overworld run fill 367 58 12 367 66 12 stone
execute in minecraft:overworld run fill 367 67 12 367 68 12 dirt
execute in minecraft:overworld run setblock 367 69 12 grass_block
execute in minecraft:overworld run fill 367 70 12 367 144 12 air
execute in minecraft:overworld run fill 367 58 13 367 67 13 stone
execute in minecraft:overworld run fill 367 68 13 367 69 13 dirt
execute in minecraft:overworld run setblock 367 70 13 coarse_dirt
execute in minecraft:overworld run fill 367 71 13 367 144 13 air
execute in minecraft:overworld run setblock 367 71 13 grass
execute in minecraft:overworld run fill 367 58 14 367 67 14 stone
execute in minecraft:overworld run fill 367 68 14 367 69 14 dirt
execute in minecraft:overworld run setblock 367 70 14 coarse_dirt
execute in minecraft:overworld run fill 367 71 14 367 144 14 air
execute in minecraft:overworld run fill 367 58 15 367 67 15 stone
execute in minecraft:overworld run fill 367 68 15 367 69 15 dirt
execute in minecraft:overworld run setblock 367 70 15 coarse_dirt
execute in minecraft:overworld run fill 367 71 15 367 144 15 air
execute in minecraft:overworld run fill 367 58 16 367 67 16 stone
execute in minecraft:overworld run fill 367 68 16 367 69 16 dirt
execute in minecraft:overworld run setblock 367 70 16 coarse_dirt
execute in minecraft:overworld run fill 367 71 16 367 144 16 air
execute in minecraft:overworld run fill 367 58 17 367 68 17 stone
execute in minecraft:overworld run fill 367 69 17 367 70 17 dirt
execute in minecraft:overworld run setblock 367 71 17 coarse_dirt
execute in minecraft:overworld run fill 367 72 17 367 144 17 air
execute in minecraft:overworld run fill 367 58 18 367 68 18 stone
execute in minecraft:overworld run fill 367 69 18 367 70 18 dirt
execute in minecraft:overworld run setblock 367 71 18 coarse_dirt
execute in minecraft:overworld run fill 367 72 18 367 144 18 air
execute in minecraft:overworld run fill 367 58 19 367 68 19 stone
execute in minecraft:overworld run fill 367 69 19 367 70 19 dirt
execute in minecraft:overworld run setblock 367 71 19 coarse_dirt
execute in minecraft:overworld run fill 367 72 19 367 144 19 air
execute in minecraft:overworld run fill 367 58 20 367 68 20 stone
execute in minecraft:overworld run fill 367 69 20 367 70 20 dirt
execute in minecraft:overworld run setblock 367 71 20 coarse_dirt
execute in minecraft:overworld run fill 367 72 20 367 144 20 air
execute in minecraft:overworld run fill 367 58 21 367 68 21 stone
execute in minecraft:overworld run fill 367 69 21 367 70 21 dirt
execute in minecraft:overworld run setblock 367 71 21 grass_block
execute in minecraft:overworld run fill 367 72 21 367 144 21 air
execute in minecraft:overworld run fill 367 58 22 367 68 22 stone
execute in minecraft:overworld run fill 367 69 22 367 70 22 dirt
execute in minecraft:overworld run setblock 367 71 22 coarse_dirt
execute in minecraft:overworld run fill 367 72 22 367 144 22 air
execute in minecraft:overworld run fill 367 58 23 367 68 23 stone
execute in minecraft:overworld run fill 367 69 23 367 70 23 dirt
execute in minecraft:overworld run setblock 367 71 23 coarse_dirt
execute in minecraft:overworld run fill 367 72 23 367 144 23 air
execute in minecraft:overworld run fill 367 58 24 367 68 24 stone
execute in minecraft:overworld run fill 367 69 24 367 70 24 dirt
execute in minecraft:overworld run setblock 367 71 24 coarse_dirt
execute in minecraft:overworld run fill 367 72 24 367 144 24 air
execute in minecraft:overworld run fill 367 58 25 367 68 25 stone
execute in minecraft:overworld run fill 367 69 25 367 70 25 dirt
execute in minecraft:overworld run setblock 367 71 25 coarse_dirt
execute in minecraft:overworld run fill 367 72 25 367 144 25 air
execute in minecraft:overworld run fill 367 58 26 367 68 26 stone
execute in minecraft:overworld run fill 367 69 26 367 70 26 dirt
execute in minecraft:overworld run setblock 367 71 26 grass_block
execute in minecraft:overworld run fill 367 72 26 367 144 26 air
execute in minecraft:overworld run fill 367 58 27 367 68 27 stone
execute in minecraft:overworld run fill 367 69 27 367 70 27 dirt
execute in minecraft:overworld run setblock 367 71 27 grass_block
execute in minecraft:overworld run fill 367 72 27 367 144 27 air
execute in minecraft:overworld run fill 367 58 28 367 68 28 stone
execute in minecraft:overworld run fill 367 69 28 367 70 28 dirt
execute in minecraft:overworld run setblock 367 71 28 grass_block
execute in minecraft:overworld run fill 367 72 28 367 144 28 air
execute in minecraft:overworld run fill 367 58 29 367 69 29 stone
execute in minecraft:overworld run fill 367 70 29 367 71 29 dirt
execute in minecraft:overworld run setblock 367 72 29 coarse_dirt
execute in minecraft:overworld run fill 367 73 29 367 144 29 air
execute in minecraft:overworld run fill 367 58 30 367 69 30 stone
execute in minecraft:overworld run fill 367 70 30 367 71 30 dirt
execute in minecraft:overworld run setblock 367 72 30 coarse_dirt
execute in minecraft:overworld run fill 367 73 30 367 144 30 air
execute in minecraft:overworld run setblock 367 73 30 grass
execute in minecraft:overworld run fill 367 58 31 367 69 31 stone
execute in minecraft:overworld run fill 367 70 31 367 71 31 dirt
execute in minecraft:overworld run setblock 367 72 31 coarse_dirt
execute in minecraft:overworld run fill 367 73 31 367 144 31 air
execute in minecraft:overworld run fill 367 58 32 367 70 32 stone
execute in minecraft:overworld run fill 367 71 32 367 72 32 dirt
execute in minecraft:overworld run setblock 367 73 32 coarse_dirt
execute in minecraft:overworld run fill 367 74 32 367 144 32 air
execute in minecraft:overworld run fill 367 58 33 367 70 33 stone
execute in minecraft:overworld run fill 367 71 33 367 72 33 dirt
execute in minecraft:overworld run setblock 367 73 33 coarse_dirt
execute in minecraft:overworld run fill 367 74 33 367 144 33 air
execute in minecraft:overworld run fill 367 58 34 367 70 34 stone
execute in minecraft:overworld run fill 367 71 34 367 72 34 dirt
execute in minecraft:overworld run setblock 367 73 34 grass_block
execute in minecraft:overworld run fill 367 74 34 367 144 34 air
execute in minecraft:overworld run fill 367 58 35 367 70 35 stone
execute in minecraft:overworld run fill 367 71 35 367 72 35 dirt
execute in minecraft:overworld run setblock 367 73 35 grass_block
execute in minecraft:overworld run fill 367 74 35 367 144 35 air
execute in minecraft:overworld run fill 367 58 36 367 71 36 stone
execute in minecraft:overworld run fill 367 72 36 367 73 36 dirt
execute in minecraft:overworld run setblock 367 74 36 coarse_dirt
execute in minecraft:overworld run fill 367 75 36 367 144 36 air
execute in minecraft:overworld run fill 367 58 37 367 71 37 stone
execute in minecraft:overworld run fill 367 72 37 367 73 37 dirt
execute in minecraft:overworld run setblock 367 74 37 grass_block
execute in minecraft:overworld run fill 367 75 37 367 144 37 air
execute in minecraft:overworld run fill 367 58 38 367 71 38 stone
execute in minecraft:overworld run fill 367 72 38 367 73 38 dirt
execute in minecraft:overworld run setblock 367 74 38 coarse_dirt
execute in minecraft:overworld run fill 367 75 38 367 144 38 air
execute in minecraft:overworld run fill 367 58 39 367 70 39 stone
execute in minecraft:overworld run fill 367 71 39 367 72 39 dirt
execute in minecraft:overworld run setblock 367 73 39 coarse_dirt
execute in minecraft:overworld run fill 367 74 39 367 144 39 air
execute in minecraft:overworld run fill 367 58 40 367 69 40 stone
execute in minecraft:overworld run fill 367 70 40 367 71 40 dirt
execute in minecraft:overworld run setblock 367 72 40 coarse_dirt
execute in minecraft:overworld run fill 367 73 40 367 144 40 air
execute in minecraft:overworld run fill 367 58 41 367 68 41 stone
execute in minecraft:overworld run fill 367 69 41 367 70 41 dirt
execute in minecraft:overworld run setblock 367 71 41 coarse_dirt
execute in minecraft:overworld run fill 367 72 41 367 144 41 air
execute in minecraft:overworld run fill 367 58 42 367 67 42 stone
execute in minecraft:overworld run fill 367 68 42 367 69 42 dirt
execute in minecraft:overworld run setblock 367 70 42 coarse_dirt
execute in minecraft:overworld run fill 367 71 42 367 144 42 air
execute in minecraft:overworld run fill 367 58 43 367 66 43 stone
execute in minecraft:overworld run fill 367 67 43 367 68 43 dirt
execute in minecraft:overworld run setblock 367 69 43 grass_block
execute in minecraft:overworld run fill 367 70 43 367 144 43 air
execute in minecraft:overworld run fill 367 58 44 367 65 44 stone
execute in minecraft:overworld run fill 367 66 44 367 67 44 dirt
execute in minecraft:overworld run setblock 367 68 44 coarse_dirt
execute in minecraft:overworld run fill 367 69 44 367 144 44 air
execute in minecraft:overworld run fill 367 58 45 367 64 45 stone
execute in minecraft:overworld run fill 367 65 45 367 66 45 dirt
execute in minecraft:overworld run setblock 367 67 45 coarse_dirt
execute in minecraft:overworld run fill 367 68 45 367 144 45 air
execute in minecraft:overworld run fill 367 58 46 367 63 46 stone
execute in minecraft:overworld run fill 367 64 46 367 65 46 dirt
execute in minecraft:overworld run setblock 367 66 46 coarse_dirt
execute in minecraft:overworld run fill 367 67 46 367 144 46 air
execute in minecraft:overworld run fill 367 58 47 367 62 47 stone
execute in minecraft:overworld run fill 367 63 47 367 64 47 dirt
execute in minecraft:overworld run setblock 367 65 47 coarse_dirt
execute in minecraft:overworld run fill 367 66 47 367 144 47 air
execute in minecraft:overworld run fill 368 58 -48 368 61 -48 stone
execute in minecraft:overworld run fill 368 62 -48 368 63 -48 dirt
execute in minecraft:overworld run setblock 368 64 -48 grass_block
execute in minecraft:overworld run fill 368 65 -48 368 144 -48 air
execute in minecraft:overworld run fill 368 58 -47 368 62 -47 stone
execute in minecraft:overworld run fill 368 63 -47 368 64 -47 dirt
execute in minecraft:overworld run setblock 368 65 -47 coarse_dirt
schedule function blade_gallery:random/battlefield/part_49 1t replace
