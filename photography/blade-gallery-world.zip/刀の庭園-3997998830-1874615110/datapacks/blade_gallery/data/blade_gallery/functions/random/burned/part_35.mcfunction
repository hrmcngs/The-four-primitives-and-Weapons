execute in minecraft:overworld run setblock 230 72 35 coarse_dirt
execute in minecraft:overworld run fill 230 73 35 230 144 35 air
execute in minecraft:overworld run fill 230 58 36 230 69 36 stone
execute in minecraft:overworld run fill 230 70 36 230 71 36 dirt
execute in minecraft:overworld run setblock 230 72 36 coarse_dirt
execute in minecraft:overworld run fill 230 73 36 230 144 36 air
execute in minecraft:overworld run setblock 230 73 36 grass
execute in minecraft:overworld run fill 230 58 37 230 68 37 stone
execute in minecraft:overworld run fill 230 69 37 230 70 37 dirt
execute in minecraft:overworld run setblock 230 71 37 coarse_dirt
execute in minecraft:overworld run fill 230 72 37 230 144 37 air
execute in minecraft:overworld run fill 230 58 38 230 68 38 stone
execute in minecraft:overworld run fill 230 69 38 230 70 38 dirt
execute in minecraft:overworld run setblock 230 71 38 coarse_dirt
execute in minecraft:overworld run fill 230 72 38 230 144 38 air
execute in minecraft:overworld run fill 230 58 39 230 67 39 stone
execute in minecraft:overworld run fill 230 68 39 230 69 39 dirt
execute in minecraft:overworld run setblock 230 70 39 coarse_dirt
execute in minecraft:overworld run fill 230 71 39 230 144 39 air
execute in minecraft:overworld run fill 230 58 40 230 66 40 stone
execute in minecraft:overworld run fill 230 67 40 230 68 40 dirt
execute in minecraft:overworld run setblock 230 69 40 coarse_dirt
execute in minecraft:overworld run fill 230 70 40 230 144 40 air
execute in minecraft:overworld run fill 230 58 41 230 65 41 stone
execute in minecraft:overworld run fill 230 66 41 230 67 41 dirt
execute in minecraft:overworld run setblock 230 68 41 coarse_dirt
execute in minecraft:overworld run fill 230 69 41 230 144 41 air
execute in minecraft:overworld run setblock 230 69 41 grass
execute in minecraft:overworld run fill 230 58 42 230 64 42 stone
execute in minecraft:overworld run fill 230 65 42 230 66 42 dirt
execute in minecraft:overworld run setblock 230 67 42 coarse_dirt
execute in minecraft:overworld run fill 230 68 42 230 144 42 air
execute in minecraft:overworld run fill 230 58 43 230 63 43 stone
execute in minecraft:overworld run fill 230 64 43 230 65 43 dirt
execute in minecraft:overworld run setblock 230 66 43 grass_block
execute in minecraft:overworld run fill 230 67 43 230 144 43 air
execute in minecraft:overworld run fill 230 58 44 230 63 44 stone
execute in minecraft:overworld run fill 230 64 44 230 65 44 dirt
execute in minecraft:overworld run setblock 230 66 44 coarse_dirt
execute in minecraft:overworld run fill 230 67 44 230 144 44 air
execute in minecraft:overworld run fill 230 58 45 230 62 45 stone
execute in minecraft:overworld run fill 230 63 45 230 64 45 dirt
execute in minecraft:overworld run setblock 230 65 45 coarse_dirt
execute in minecraft:overworld run fill 230 66 45 230 144 45 air
execute in minecraft:overworld run fill 230 58 46 230 62 46 stone
execute in minecraft:overworld run fill 230 63 46 230 64 46 dirt
execute in minecraft:overworld run setblock 230 65 46 coarse_dirt
execute in minecraft:overworld run fill 230 66 46 230 144 46 air
execute in minecraft:overworld run fill 230 58 47 230 61 47 stone
execute in minecraft:overworld run fill 230 62 47 230 63 47 dirt
execute in minecraft:overworld run setblock 230 64 47 grass_block
execute in minecraft:overworld run fill 230 65 47 230 144 47 air
execute in minecraft:overworld run fill 231 58 -48 231 61 -48 stone
execute in minecraft:overworld run fill 231 62 -48 231 63 -48 dirt
execute in minecraft:overworld run setblock 231 64 -48 coarse_dirt
execute in minecraft:overworld run fill 231 65 -48 231 144 -48 air
execute in minecraft:overworld run fill 231 58 -47 231 63 -47 stone
execute in minecraft:overworld run fill 231 64 -47 231 65 -47 dirt
execute in minecraft:overworld run setblock 231 66 -47 grass_block
execute in minecraft:overworld run fill 231 67 -47 231 144 -47 air
execute in minecraft:overworld run fill 231 58 -46 231 64 -46 stone
execute in minecraft:overworld run fill 231 65 -46 231 66 -46 dirt
execute in minecraft:overworld run setblock 231 67 -46 grass_block
execute in minecraft:overworld run fill 231 68 -46 231 144 -46 air
execute in minecraft:overworld run fill 231 58 -45 231 66 -45 stone
execute in minecraft:overworld run fill 231 67 -45 231 68 -45 dirt
execute in minecraft:overworld run setblock 231 69 -45 coarse_dirt
execute in minecraft:overworld run fill 231 70 -45 231 144 -45 air
execute in minecraft:overworld run fill 231 58 -44 231 67 -44 stone
execute in minecraft:overworld run fill 231 68 -44 231 69 -44 dirt
execute in minecraft:overworld run setblock 231 70 -44 grass_block
execute in minecraft:overworld run fill 231 71 -44 231 144 -44 air
execute in minecraft:overworld run fill 231 58 -43 231 68 -43 stone
execute in minecraft:overworld run fill 231 69 -43 231 70 -43 dirt
execute in minecraft:overworld run setblock 231 71 -43 grass_block
execute in minecraft:overworld run fill 231 72 -43 231 144 -43 air
execute in minecraft:overworld run fill 231 58 -42 231 70 -42 stone
execute in minecraft:overworld run fill 231 71 -42 231 72 -42 dirt
execute in minecraft:overworld run setblock 231 73 -42 grass_block
execute in minecraft:overworld run fill 231 74 -42 231 144 -42 air
execute in minecraft:overworld run fill 231 58 -41 231 71 -41 stone
execute in minecraft:overworld run fill 231 72 -41 231 73 -41 dirt
execute in minecraft:overworld run setblock 231 74 -41 coarse_dirt
execute in minecraft:overworld run fill 231 75 -41 231 144 -41 air
execute in minecraft:overworld run fill 231 58 -40 231 72 -40 stone
execute in minecraft:overworld run fill 231 73 -40 231 74 -40 dirt
execute in minecraft:overworld run setblock 231 75 -40 coarse_dirt
execute in minecraft:overworld run fill 231 76 -40 231 144 -40 air
execute in minecraft:overworld run fill 231 58 -39 231 73 -39 stone
execute in minecraft:overworld run fill 231 74 -39 231 75 -39 dirt
execute in minecraft:overworld run setblock 231 76 -39 grass_block
execute in minecraft:overworld run fill 231 77 -39 231 144 -39 air
execute in minecraft:overworld run setblock 231 77 -39 grass
execute in minecraft:overworld run fill 231 58 -38 231 74 -38 stone
execute in minecraft:overworld run fill 231 75 -38 231 76 -38 dirt
execute in minecraft:overworld run setblock 231 77 -38 coarse_dirt
execute in minecraft:overworld run fill 231 78 -38 231 144 -38 air
execute in minecraft:overworld run fill 231 58 -37 231 73 -37 stone
execute in minecraft:overworld run fill 231 74 -37 231 75 -37 dirt
execute in minecraft:overworld run setblock 231 76 -37 grass_block
execute in minecraft:overworld run fill 231 77 -37 231 144 -37 air
execute in minecraft:overworld run fill 231 58 -36 231 72 -36 stone
execute in minecraft:overworld run fill 231 73 -36 231 74 -36 dirt
execute in minecraft:overworld run setblock 231 75 -36 coarse_dirt
execute in minecraft:overworld run fill 231 76 -36 231 144 -36 air
execute in minecraft:overworld run fill 231 58 -35 231 72 -35 stone
execute in minecraft:overworld run fill 231 73 -35 231 74 -35 dirt
execute in minecraft:overworld run setblock 231 75 -35 coarse_dirt
execute in minecraft:overworld run fill 231 76 -35 231 144 -35 air
execute in minecraft:overworld run fill 231 58 -34 231 71 -34 stone
execute in minecraft:overworld run fill 231 72 -34 231 73 -34 dirt
execute in minecraft:overworld run setblock 231 74 -34 coarse_dirt
execute in minecraft:overworld run fill 231 75 -34 231 144 -34 air
execute in minecraft:overworld run fill 231 58 -33 231 71 -33 stone
execute in minecraft:overworld run fill 231 72 -33 231 73 -33 dirt
execute in minecraft:overworld run setblock 231 74 -33 grass_block
execute in minecraft:overworld run fill 231 75 -33 231 144 -33 air
execute in minecraft:overworld run fill 231 58 -32 231 70 -32 stone
execute in minecraft:overworld run fill 231 71 -32 231 72 -32 dirt
execute in minecraft:overworld run setblock 231 73 -32 coarse_dirt
execute in minecraft:overworld run fill 231 74 -32 231 144 -32 air
execute in minecraft:overworld run fill 231 58 -31 231 70 -31 stone
execute in minecraft:overworld run fill 231 71 -31 231 72 -31 dirt
execute in minecraft:overworld run setblock 231 73 -31 coarse_dirt
execute in minecraft:overworld run fill 231 74 -31 231 144 -31 air
execute in minecraft:overworld run setblock 231 74 -31 grass
execute in minecraft:overworld run fill 231 58 -30 231 69 -30 stone
execute in minecraft:overworld run fill 231 70 -30 231 71 -30 dirt
execute in minecraft:overworld run setblock 231 72 -30 grass_block
execute in minecraft:overworld run fill 231 73 -30 231 144 -30 air
execute in minecraft:overworld run setblock 231 73 -30 grass
execute in minecraft:overworld run fill 231 58 -29 231 69 -29 stone
execute in minecraft:overworld run fill 231 70 -29 231 71 -29 dirt
execute in minecraft:overworld run setblock 231 72 -29 coarse_dirt
execute in minecraft:overworld run fill 231 73 -29 231 144 -29 air
execute in minecraft:overworld run fill 231 58 -28 231 68 -28 stone
execute in minecraft:overworld run fill 231 69 -28 231 70 -28 dirt
execute in minecraft:overworld run setblock 231 71 -28 grass_block
execute in minecraft:overworld run fill 231 72 -28 231 144 -28 air
execute in minecraft:overworld run setblock 231 72 -28 mossy_cobblestone
execute in minecraft:overworld run fill 231 58 -27 231 68 -27 stone
execute in minecraft:overworld run fill 231 69 -27 231 70 -27 dirt
execute in minecraft:overworld run setblock 231 71 -27 coarse_dirt
execute in minecraft:overworld run fill 231 72 -27 231 144 -27 air
execute in minecraft:overworld run fill 231 58 -26 231 68 -26 stone
execute in minecraft:overworld run fill 231 69 -26 231 70 -26 dirt
execute in minecraft:overworld run setblock 231 71 -26 coarse_dirt
execute in minecraft:overworld run fill 231 72 -26 231 144 -26 air
execute in minecraft:overworld run setblock 231 72 -26 grass
execute in minecraft:overworld run fill 231 58 -25 231 67 -25 stone
execute in minecraft:overworld run fill 231 68 -25 231 69 -25 dirt
execute in minecraft:overworld run setblock 231 70 -25 coarse_dirt
execute in minecraft:overworld run fill 231 71 -25 231 144 -25 air
execute in minecraft:overworld run fill 231 58 -24 231 67 -24 stone
execute in minecraft:overworld run fill 231 68 -24 231 69 -24 dirt
execute in minecraft:overworld run setblock 231 70 -24 coarse_dirt
execute in minecraft:overworld run fill 231 71 -24 231 144 -24 air
execute in minecraft:overworld run fill 231 58 -23 231 67 -23 stone
execute in minecraft:overworld run fill 231 68 -23 231 69 -23 dirt
execute in minecraft:overworld run setblock 231 70 -23 coarse_dirt
execute in minecraft:overworld run fill 231 71 -23 231 144 -23 air
execute in minecraft:overworld run fill 231 58 -22 231 67 -22 stone
execute in minecraft:overworld run fill 231 68 -22 231 69 -22 dirt
execute in minecraft:overworld run setblock 231 70 -22 coarse_dirt
execute in minecraft:overworld run fill 231 71 -22 231 144 -22 air
execute in minecraft:overworld run fill 231 58 -21 231 66 -21 stone
execute in minecraft:overworld run fill 231 67 -21 231 68 -21 dirt
execute in minecraft:overworld run setblock 231 69 -21 coarse_dirt
execute in minecraft:overworld run fill 231 70 -21 231 144 -21 air
execute in minecraft:overworld run fill 231 58 -20 231 66 -20 stone
execute in minecraft:overworld run fill 231 67 -20 231 68 -20 dirt
execute in minecraft:overworld run setblock 231 69 -20 coarse_dirt
execute in minecraft:overworld run fill 231 70 -20 231 144 -20 air
execute in minecraft:overworld run fill 231 58 -19 231 66 -19 stone
execute in minecraft:overworld run fill 231 67 -19 231 68 -19 dirt
execute in minecraft:overworld run setblock 231 69 -19 coarse_dirt
execute in minecraft:overworld run fill 231 70 -19 231 144 -19 air
execute in minecraft:overworld run fill 231 58 -18 231 66 -18 stone
execute in minecraft:overworld run fill 231 67 -18 231 68 -18 dirt
execute in minecraft:overworld run setblock 231 69 -18 coarse_dirt
execute in minecraft:overworld run fill 231 70 -18 231 144 -18 air
execute in minecraft:overworld run fill 231 58 -17 231 66 -17 stone
execute in minecraft:overworld run fill 231 67 -17 231 68 -17 dirt
execute in minecraft:overworld run setblock 231 69 -17 coarse_dirt
execute in minecraft:overworld run fill 231 70 -17 231 144 -17 air
execute in minecraft:overworld run fill 231 58 -16 231 65 -16 stone
execute in minecraft:overworld run fill 231 66 -16 231 67 -16 dirt
execute in minecraft:overworld run setblock 231 68 -16 coarse_dirt
execute in minecraft:overworld run fill 231 69 -16 231 144 -16 air
execute in minecraft:overworld run fill 231 58 -15 231 65 -15 stone
execute in minecraft:overworld run fill 231 66 -15 231 67 -15 dirt
execute in minecraft:overworld run setblock 231 68 -15 coarse_dirt
execute in minecraft:overworld run fill 231 69 -15 231 144 -15 air
execute in minecraft:overworld run fill 231 58 -14 231 65 -14 stone
execute in minecraft:overworld run fill 231 66 -14 231 67 -14 dirt
execute in minecraft:overworld run setblock 231 68 -14 coarse_dirt
execute in minecraft:overworld run fill 231 69 -14 231 144 -14 air
execute in minecraft:overworld run fill 231 58 -13 231 65 -13 stone
execute in minecraft:overworld run fill 231 66 -13 231 67 -13 dirt
execute in minecraft:overworld run setblock 231 68 -13 grass_block
execute in minecraft:overworld run fill 231 69 -13 231 144 -13 air
execute in minecraft:overworld run fill 231 58 -12 231 64 -12 stone
execute in minecraft:overworld run fill 231 65 -12 231 66 -12 dirt
execute in minecraft:overworld run setblock 231 67 -12 grass_block
execute in minecraft:overworld run fill 231 68 -12 231 144 -12 air
execute in minecraft:overworld run fill 231 58 -11 231 64 -11 stone
execute in minecraft:overworld run fill 231 65 -11 231 66 -11 dirt
execute in minecraft:overworld run setblock 231 67 -11 coarse_dirt
execute in minecraft:overworld run fill 231 68 -11 231 144 -11 air
execute in minecraft:overworld run fill 231 58 -10 231 65 -10 stone
execute in minecraft:overworld run fill 231 66 -10 231 67 -10 dirt
execute in minecraft:overworld run setblock 231 68 -10 grass_block
execute in minecraft:overworld run fill 231 69 -10 231 144 -10 air
execute in minecraft:overworld run fill 231 58 -9 231 65 -9 stone
execute in minecraft:overworld run fill 231 66 -9 231 67 -9 dirt
execute in minecraft:overworld run setblock 231 68 -9 grass_block
execute in minecraft:overworld run fill 231 69 -9 231 144 -9 air
execute in minecraft:overworld run setblock 231 69 -9 grass
execute in minecraft:overworld run fill 231 58 -8 231 65 -8 stone
execute in minecraft:overworld run fill 231 66 -8 231 67 -8 dirt
execute in minecraft:overworld run setblock 231 68 -8 grass_block
execute in minecraft:overworld run fill 231 69 -8 231 144 -8 air
execute in minecraft:overworld run fill 231 58 -7 231 65 -7 stone
execute in minecraft:overworld run fill 231 66 -7 231 67 -7 dirt
execute in minecraft:overworld run setblock 231 68 -7 coarse_dirt
execute in minecraft:overworld run fill 231 69 -7 231 144 -7 air
execute in minecraft:overworld run fill 231 58 -6 231 65 -6 stone
execute in minecraft:overworld run fill 231 66 -6 231 67 -6 dirt
execute in minecraft:overworld run setblock 231 68 -6 coarse_dirt
execute in minecraft:overworld run fill 231 69 -6 231 144 -6 air
execute in minecraft:overworld run fill 231 58 -5 231 65 -5 stone
execute in minecraft:overworld run fill 231 66 -5 231 67 -5 dirt
execute in minecraft:overworld run setblock 231 68 -5 coarse_dirt
execute in minecraft:overworld run fill 231 69 -5 231 144 -5 air
execute in minecraft:overworld run fill 231 58 -4 231 65 -4 stone
execute in minecraft:overworld run fill 231 66 -4 231 67 -4 dirt
execute in minecraft:overworld run setblock 231 68 -4 grass_block
execute in minecraft:overworld run fill 231 69 -4 231 144 -4 air
execute in minecraft:overworld run setblock 231 69 -4 grass
execute in minecraft:overworld run fill 231 58 -3 231 65 -3 stone
execute in minecraft:overworld run fill 231 66 -3 231 67 -3 dirt
execute in minecraft:overworld run setblock 231 68 -3 coarse_dirt
execute in minecraft:overworld run fill 231 69 -3 231 144 -3 air
execute in minecraft:overworld run fill 231 58 -2 231 65 -2 stone
execute in minecraft:overworld run fill 231 66 -2 231 67 -2 dirt
execute in minecraft:overworld run setblock 231 68 -2 coarse_dirt
execute in minecraft:overworld run fill 231 69 -2 231 144 -2 air
execute in minecraft:overworld run fill 231 58 -1 231 65 -1 stone
execute in minecraft:overworld run fill 231 66 -1 231 67 -1 dirt
execute in minecraft:overworld run setblock 231 68 -1 coarse_dirt
execute in minecraft:overworld run fill 231 69 -1 231 144 -1 air
execute in minecraft:overworld run fill 231 58 0 231 65 0 stone
execute in minecraft:overworld run fill 231 66 0 231 67 0 dirt
execute in minecraft:overworld run setblock 231 68 0 coarse_dirt
execute in minecraft:overworld run fill 231 69 0 231 144 0 air
execute in minecraft:overworld run fill 231 58 1 231 65 1 stone
schedule function blade_gallery:random/burned/part_36 1t replace
