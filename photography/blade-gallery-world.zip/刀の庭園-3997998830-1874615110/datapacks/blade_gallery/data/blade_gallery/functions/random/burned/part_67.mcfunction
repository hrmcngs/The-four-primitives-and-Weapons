execute in minecraft:overworld run fill 251 63 9 251 64 9 dirt
execute in minecraft:overworld run setblock 251 65 9 grass_block
execute in minecraft:overworld run fill 251 66 9 251 144 9 air
execute in minecraft:overworld run fill 251 58 10 251 63 10 stone
execute in minecraft:overworld run fill 251 64 10 251 65 10 dirt
execute in minecraft:overworld run setblock 251 66 10 coarse_dirt
execute in minecraft:overworld run fill 251 67 10 251 144 10 air
execute in minecraft:overworld run setblock 251 67 10 grass
execute in minecraft:overworld run fill 251 58 11 251 63 11 stone
execute in minecraft:overworld run fill 251 64 11 251 65 11 dirt
execute in minecraft:overworld run setblock 251 66 11 coarse_dirt
execute in minecraft:overworld run fill 251 67 11 251 144 11 air
execute in minecraft:overworld run fill 251 58 12 251 63 12 stone
execute in minecraft:overworld run fill 251 64 12 251 65 12 dirt
execute in minecraft:overworld run setblock 251 66 12 coarse_dirt
execute in minecraft:overworld run fill 251 67 12 251 144 12 air
execute in minecraft:overworld run fill 251 58 13 251 63 13 stone
execute in minecraft:overworld run fill 251 64 13 251 65 13 dirt
execute in minecraft:overworld run setblock 251 66 13 grass_block
execute in minecraft:overworld run fill 251 67 13 251 144 13 air
execute in minecraft:overworld run fill 251 58 14 251 64 14 stone
execute in minecraft:overworld run fill 251 65 14 251 66 14 dirt
execute in minecraft:overworld run setblock 251 67 14 coarse_dirt
execute in minecraft:overworld run fill 251 68 14 251 144 14 air
execute in minecraft:overworld run fill 251 58 15 251 64 15 stone
execute in minecraft:overworld run fill 251 65 15 251 66 15 dirt
execute in minecraft:overworld run setblock 251 67 15 coarse_dirt
execute in minecraft:overworld run fill 251 68 15 251 144 15 air
execute in minecraft:overworld run fill 251 58 16 251 64 16 stone
execute in minecraft:overworld run fill 251 65 16 251 66 16 dirt
execute in minecraft:overworld run setblock 251 67 16 coarse_dirt
execute in minecraft:overworld run fill 251 68 16 251 144 16 air
execute in minecraft:overworld run setblock 251 68 16 grass
execute in minecraft:overworld run fill 251 58 17 251 64 17 stone
execute in minecraft:overworld run fill 251 65 17 251 66 17 dirt
execute in minecraft:overworld run setblock 251 67 17 coarse_dirt
execute in minecraft:overworld run fill 251 68 17 251 144 17 air
execute in minecraft:overworld run fill 251 58 18 251 64 18 stone
execute in minecraft:overworld run fill 251 65 18 251 66 18 dirt
execute in minecraft:overworld run setblock 251 67 18 coarse_dirt
execute in minecraft:overworld run fill 251 68 18 251 144 18 air
execute in minecraft:overworld run setblock 251 68 18 grass
execute in minecraft:overworld run fill 251 58 19 251 65 19 stone
execute in minecraft:overworld run fill 251 66 19 251 67 19 dirt
execute in minecraft:overworld run setblock 251 68 19 coarse_dirt
execute in minecraft:overworld run fill 251 69 19 251 144 19 air
execute in minecraft:overworld run fill 251 58 20 251 65 20 stone
execute in minecraft:overworld run fill 251 66 20 251 67 20 dirt
execute in minecraft:overworld run setblock 251 68 20 coarse_dirt
execute in minecraft:overworld run fill 251 69 20 251 144 20 air
execute in minecraft:overworld run fill 251 58 21 251 65 21 stone
execute in minecraft:overworld run fill 251 66 21 251 67 21 dirt
execute in minecraft:overworld run setblock 251 68 21 coarse_dirt
execute in minecraft:overworld run fill 251 69 21 251 144 21 air
execute in minecraft:overworld run fill 251 58 22 251 65 22 stone
execute in minecraft:overworld run fill 251 66 22 251 67 22 dirt
execute in minecraft:overworld run setblock 251 68 22 grass_block
execute in minecraft:overworld run fill 251 69 22 251 144 22 air
execute in minecraft:overworld run fill 251 58 23 251 65 23 stone
execute in minecraft:overworld run fill 251 66 23 251 67 23 dirt
execute in minecraft:overworld run setblock 251 68 23 grass_block
execute in minecraft:overworld run fill 251 69 23 251 144 23 air
execute in minecraft:overworld run setblock 251 69 23 grass
execute in minecraft:overworld run fill 251 58 24 251 65 24 stone
execute in minecraft:overworld run fill 251 66 24 251 67 24 dirt
execute in minecraft:overworld run setblock 251 68 24 grass_block
execute in minecraft:overworld run fill 251 69 24 251 144 24 air
execute in minecraft:overworld run fill 251 58 25 251 65 25 stone
execute in minecraft:overworld run fill 251 66 25 251 67 25 dirt
execute in minecraft:overworld run setblock 251 68 25 coarse_dirt
execute in minecraft:overworld run fill 251 69 25 251 144 25 air
execute in minecraft:overworld run fill 251 58 26 251 65 26 stone
execute in minecraft:overworld run fill 251 66 26 251 67 26 dirt
execute in minecraft:overworld run setblock 251 68 26 grass_block
execute in minecraft:overworld run fill 251 69 26 251 144 26 air
execute in minecraft:overworld run fill 251 58 27 251 65 27 stone
execute in minecraft:overworld run fill 251 66 27 251 67 27 dirt
execute in minecraft:overworld run setblock 251 68 27 coarse_dirt
execute in minecraft:overworld run fill 251 69 27 251 144 27 air
execute in minecraft:overworld run fill 251 58 28 251 65 28 stone
execute in minecraft:overworld run fill 251 66 28 251 67 28 dirt
execute in minecraft:overworld run setblock 251 68 28 coarse_dirt
execute in minecraft:overworld run fill 251 69 28 251 144 28 air
execute in minecraft:overworld run setblock 251 69 28 grass
execute in minecraft:overworld run fill 251 58 29 251 65 29 stone
execute in minecraft:overworld run fill 251 66 29 251 67 29 dirt
execute in minecraft:overworld run setblock 251 68 29 coarse_dirt
execute in minecraft:overworld run fill 251 69 29 251 144 29 air
execute in minecraft:overworld run fill 251 58 30 251 65 30 stone
execute in minecraft:overworld run fill 251 66 30 251 67 30 dirt
execute in minecraft:overworld run setblock 251 68 30 grass_block
execute in minecraft:overworld run fill 251 69 30 251 144 30 air
execute in minecraft:overworld run fill 251 58 31 251 65 31 stone
execute in minecraft:overworld run fill 251 66 31 251 67 31 dirt
execute in minecraft:overworld run setblock 251 68 31 coarse_dirt
execute in minecraft:overworld run fill 251 69 31 251 144 31 air
execute in minecraft:overworld run setblock 251 69 31 grass
execute in minecraft:overworld run fill 251 58 32 251 65 32 stone
execute in minecraft:overworld run fill 251 66 32 251 67 32 dirt
execute in minecraft:overworld run setblock 251 68 32 coarse_dirt
execute in minecraft:overworld run fill 251 69 32 251 144 32 air
execute in minecraft:overworld run setblock 251 69 32 grass
execute in minecraft:overworld run fill 251 58 33 251 65 33 stone
execute in minecraft:overworld run fill 251 66 33 251 67 33 dirt
execute in minecraft:overworld run setblock 251 68 33 coarse_dirt
execute in minecraft:overworld run fill 251 69 33 251 144 33 air
execute in minecraft:overworld run fill 251 58 34 251 65 34 stone
execute in minecraft:overworld run fill 251 66 34 251 67 34 dirt
execute in minecraft:overworld run setblock 251 68 34 grass_block
execute in minecraft:overworld run fill 251 69 34 251 144 34 air
execute in minecraft:overworld run fill 251 58 35 251 65 35 stone
execute in minecraft:overworld run fill 251 66 35 251 67 35 dirt
execute in minecraft:overworld run setblock 251 68 35 coarse_dirt
execute in minecraft:overworld run fill 251 69 35 251 144 35 air
execute in minecraft:overworld run fill 251 58 36 251 64 36 stone
execute in minecraft:overworld run fill 251 65 36 251 66 36 dirt
execute in minecraft:overworld run setblock 251 67 36 coarse_dirt
execute in minecraft:overworld run fill 251 68 36 251 144 36 air
execute in minecraft:overworld run fill 251 58 37 251 64 37 stone
execute in minecraft:overworld run fill 251 65 37 251 66 37 dirt
execute in minecraft:overworld run setblock 251 67 37 grass_block
execute in minecraft:overworld run fill 251 68 37 251 144 37 air
execute in minecraft:overworld run fill 251 58 38 251 63 38 stone
execute in minecraft:overworld run fill 251 64 38 251 65 38 dirt
execute in minecraft:overworld run setblock 251 66 38 coarse_dirt
execute in minecraft:overworld run fill 251 67 38 251 144 38 air
execute in minecraft:overworld run fill 251 58 39 251 63 39 stone
execute in minecraft:overworld run fill 251 64 39 251 65 39 dirt
execute in minecraft:overworld run setblock 251 66 39 coarse_dirt
execute in minecraft:overworld run fill 251 67 39 251 144 39 air
execute in minecraft:overworld run fill 251 58 40 251 62 40 stone
execute in minecraft:overworld run fill 251 63 40 251 64 40 dirt
execute in minecraft:overworld run setblock 251 65 40 grass_block
execute in minecraft:overworld run fill 251 66 40 251 144 40 air
execute in minecraft:overworld run fill 251 58 41 251 61 41 stone
execute in minecraft:overworld run fill 251 62 41 251 63 41 dirt
execute in minecraft:overworld run setblock 251 64 41 coarse_dirt
execute in minecraft:overworld run fill 251 65 41 251 144 41 air
execute in minecraft:overworld run fill 251 58 42 251 61 42 stone
execute in minecraft:overworld run fill 251 62 42 251 63 42 dirt
execute in minecraft:overworld run setblock 251 64 42 coarse_dirt
execute in minecraft:overworld run fill 251 65 42 251 144 42 air
execute in minecraft:overworld run fill 251 58 43 251 61 43 stone
execute in minecraft:overworld run fill 251 62 43 251 63 43 dirt
execute in minecraft:overworld run setblock 251 64 43 coarse_dirt
execute in minecraft:overworld run fill 251 65 43 251 144 43 air
execute in minecraft:overworld run fill 251 58 44 251 60 44 stone
execute in minecraft:overworld run fill 251 61 44 251 62 44 dirt
execute in minecraft:overworld run setblock 251 63 44 gravel
execute in minecraft:overworld run fill 251 64 44 251 144 44 air
execute in minecraft:overworld run fill 251 64 44 251 64 44 water
execute in minecraft:overworld run fill 251 58 45 251 60 45 stone
execute in minecraft:overworld run fill 251 61 45 251 62 45 dirt
execute in minecraft:overworld run setblock 251 63 45 gravel
execute in minecraft:overworld run fill 251 64 45 251 144 45 air
execute in minecraft:overworld run fill 251 64 45 251 64 45 water
execute in minecraft:overworld run fill 251 58 46 251 60 46 stone
execute in minecraft:overworld run fill 251 61 46 251 62 46 dirt
execute in minecraft:overworld run setblock 251 63 46 gravel
execute in minecraft:overworld run fill 251 64 46 251 144 46 air
execute in minecraft:overworld run fill 251 64 46 251 64 46 water
execute in minecraft:overworld run fill 251 58 47 251 61 47 stone
execute in minecraft:overworld run fill 251 62 47 251 63 47 dirt
execute in minecraft:overworld run setblock 251 64 47 grass_block
execute in minecraft:overworld run fill 251 65 47 251 144 47 air
execute in minecraft:overworld run fill 252 58 -48 252 61 -48 stone
execute in minecraft:overworld run fill 252 62 -48 252 63 -48 dirt
execute in minecraft:overworld run setblock 252 64 -48 coarse_dirt
execute in minecraft:overworld run fill 252 65 -48 252 144 -48 air
execute in minecraft:overworld run fill 252 58 -47 252 62 -47 stone
execute in minecraft:overworld run fill 252 63 -47 252 64 -47 dirt
execute in minecraft:overworld run setblock 252 65 -47 grass_block
execute in minecraft:overworld run fill 252 66 -47 252 144 -47 air
execute in minecraft:overworld run fill 252 58 -46 252 63 -46 stone
execute in minecraft:overworld run fill 252 64 -46 252 65 -46 dirt
execute in minecraft:overworld run setblock 252 66 -46 grass_block
execute in minecraft:overworld run fill 252 67 -46 252 144 -46 air
execute in minecraft:overworld run fill 252 58 -45 252 64 -45 stone
execute in minecraft:overworld run fill 252 65 -45 252 66 -45 dirt
execute in minecraft:overworld run setblock 252 67 -45 grass_block
execute in minecraft:overworld run fill 252 68 -45 252 144 -45 air
execute in minecraft:overworld run fill 252 58 -44 252 65 -44 stone
execute in minecraft:overworld run fill 252 66 -44 252 67 -44 dirt
execute in minecraft:overworld run setblock 252 68 -44 coarse_dirt
execute in minecraft:overworld run fill 252 69 -44 252 144 -44 air
execute in minecraft:overworld run fill 252 58 -43 252 66 -43 stone
execute in minecraft:overworld run fill 252 67 -43 252 68 -43 dirt
execute in minecraft:overworld run setblock 252 69 -43 coarse_dirt
execute in minecraft:overworld run fill 252 70 -43 252 144 -43 air
execute in minecraft:overworld run fill 252 58 -42 252 67 -42 stone
execute in minecraft:overworld run fill 252 68 -42 252 69 -42 dirt
execute in minecraft:overworld run setblock 252 70 -42 coarse_dirt
execute in minecraft:overworld run fill 252 71 -42 252 144 -42 air
execute in minecraft:overworld run fill 252 58 -41 252 68 -41 stone
execute in minecraft:overworld run fill 252 69 -41 252 70 -41 dirt
execute in minecraft:overworld run setblock 252 71 -41 grass_block
execute in minecraft:overworld run fill 252 72 -41 252 144 -41 air
execute in minecraft:overworld run fill 252 58 -40 252 69 -40 stone
execute in minecraft:overworld run fill 252 70 -40 252 71 -40 dirt
execute in minecraft:overworld run setblock 252 72 -40 grass_block
execute in minecraft:overworld run fill 252 73 -40 252 144 -40 air
execute in minecraft:overworld run setblock 252 73 -40 grass
execute in minecraft:overworld run fill 252 58 -39 252 69 -39 stone
execute in minecraft:overworld run fill 252 70 -39 252 71 -39 dirt
execute in minecraft:overworld run setblock 252 72 -39 coarse_dirt
execute in minecraft:overworld run fill 252 73 -39 252 144 -39 air
execute in minecraft:overworld run fill 252 58 -38 252 70 -38 stone
execute in minecraft:overworld run fill 252 71 -38 252 72 -38 dirt
execute in minecraft:overworld run setblock 252 73 -38 coarse_dirt
execute in minecraft:overworld run fill 252 74 -38 252 144 -38 air
execute in minecraft:overworld run fill 252 58 -37 252 70 -37 stone
execute in minecraft:overworld run fill 252 71 -37 252 72 -37 dirt
execute in minecraft:overworld run setblock 252 73 -37 coarse_dirt
execute in minecraft:overworld run fill 252 74 -37 252 144 -37 air
execute in minecraft:overworld run fill 252 58 -36 252 69 -36 stone
execute in minecraft:overworld run fill 252 70 -36 252 71 -36 dirt
execute in minecraft:overworld run setblock 252 72 -36 coarse_dirt
execute in minecraft:overworld run fill 252 73 -36 252 144 -36 air
execute in minecraft:overworld run fill 252 58 -35 252 69 -35 stone
execute in minecraft:overworld run fill 252 70 -35 252 71 -35 dirt
execute in minecraft:overworld run setblock 252 72 -35 coarse_dirt
execute in minecraft:overworld run fill 252 73 -35 252 144 -35 air
execute in minecraft:overworld run fill 252 58 -34 252 69 -34 stone
execute in minecraft:overworld run fill 252 70 -34 252 71 -34 dirt
execute in minecraft:overworld run setblock 252 72 -34 coarse_dirt
execute in minecraft:overworld run fill 252 73 -34 252 144 -34 air
execute in minecraft:overworld run fill 252 58 -33 252 69 -33 stone
execute in minecraft:overworld run fill 252 70 -33 252 71 -33 dirt
execute in minecraft:overworld run setblock 252 72 -33 grass_block
execute in minecraft:overworld run fill 252 73 -33 252 144 -33 air
execute in minecraft:overworld run fill 252 58 -32 252 68 -32 stone
execute in minecraft:overworld run fill 252 69 -32 252 70 -32 dirt
execute in minecraft:overworld run setblock 252 71 -32 coarse_dirt
execute in minecraft:overworld run fill 252 72 -32 252 144 -32 air
execute in minecraft:overworld run fill 252 58 -31 252 68 -31 stone
execute in minecraft:overworld run fill 252 69 -31 252 70 -31 dirt
execute in minecraft:overworld run setblock 252 71 -31 grass_block
execute in minecraft:overworld run fill 252 72 -31 252 144 -31 air
execute in minecraft:overworld run fill 252 58 -30 252 68 -30 stone
execute in minecraft:overworld run fill 252 69 -30 252 70 -30 dirt
execute in minecraft:overworld run setblock 252 71 -30 grass_block
execute in minecraft:overworld run fill 252 72 -30 252 144 -30 air
execute in minecraft:overworld run fill 252 58 -29 252 68 -29 stone
execute in minecraft:overworld run fill 252 69 -29 252 70 -29 dirt
execute in minecraft:overworld run setblock 252 71 -29 coarse_dirt
execute in minecraft:overworld run fill 252 72 -29 252 144 -29 air
execute in minecraft:overworld run fill 252 58 -28 252 68 -28 stone
execute in minecraft:overworld run fill 252 69 -28 252 70 -28 dirt
execute in minecraft:overworld run setblock 252 71 -28 coarse_dirt
execute in minecraft:overworld run fill 252 72 -28 252 144 -28 air
execute in minecraft:overworld run setblock 252 72 -28 grass
execute in minecraft:overworld run fill 252 58 -27 252 67 -27 stone
execute in minecraft:overworld run fill 252 68 -27 252 69 -27 dirt
execute in minecraft:overworld run setblock 252 70 -27 coarse_dirt
execute in minecraft:overworld run fill 252 71 -27 252 144 -27 air
execute in minecraft:overworld run fill 252 58 -26 252 67 -26 stone
schedule function blade_gallery:random/burned/part_68 1t replace
