execute in minecraft:overworld run fill 384 65 27 384 66 27 dirt
execute in minecraft:overworld run setblock 384 67 27 grass_block
execute in minecraft:overworld run fill 384 68 27 384 144 27 air
execute in minecraft:overworld run fill 384 58 28 384 63 28 stone
execute in minecraft:overworld run fill 384 64 28 384 65 28 dirt
execute in minecraft:overworld run setblock 384 66 28 grass_block
execute in minecraft:overworld run fill 384 67 28 384 144 28 air
execute in minecraft:overworld run fill 384 58 29 384 63 29 stone
execute in minecraft:overworld run fill 384 64 29 384 65 29 dirt
execute in minecraft:overworld run setblock 384 66 29 coarse_dirt
execute in minecraft:overworld run fill 384 67 29 384 144 29 air
execute in minecraft:overworld run fill 384 58 30 384 63 30 stone
execute in minecraft:overworld run fill 384 64 30 384 65 30 dirt
execute in minecraft:overworld run setblock 384 66 30 coarse_dirt
execute in minecraft:overworld run fill 384 67 30 384 144 30 air
execute in minecraft:overworld run fill 384 58 31 384 63 31 stone
execute in minecraft:overworld run fill 384 64 31 384 65 31 dirt
execute in minecraft:overworld run setblock 384 66 31 coarse_dirt
execute in minecraft:overworld run fill 384 67 31 384 144 31 air
execute in minecraft:overworld run fill 384 58 32 384 63 32 stone
execute in minecraft:overworld run fill 384 64 32 384 65 32 dirt
execute in minecraft:overworld run setblock 384 66 32 coarse_dirt
execute in minecraft:overworld run fill 384 67 32 384 144 32 air
execute in minecraft:overworld run fill 384 58 33 384 63 33 stone
execute in minecraft:overworld run fill 384 64 33 384 65 33 dirt
execute in minecraft:overworld run setblock 384 66 33 coarse_dirt
execute in minecraft:overworld run fill 384 67 33 384 144 33 air
execute in minecraft:overworld run fill 384 58 34 384 63 34 stone
execute in minecraft:overworld run fill 384 64 34 384 65 34 dirt
execute in minecraft:overworld run setblock 384 66 34 grass_block
execute in minecraft:overworld run fill 384 67 34 384 144 34 air
execute in minecraft:overworld run fill 384 58 35 384 62 35 stone
execute in minecraft:overworld run fill 384 63 35 384 64 35 dirt
execute in minecraft:overworld run setblock 384 65 35 grass_block
execute in minecraft:overworld run fill 384 66 35 384 144 35 air
execute in minecraft:overworld run fill 384 58 36 384 62 36 stone
execute in minecraft:overworld run fill 384 63 36 384 64 36 dirt
execute in minecraft:overworld run setblock 384 65 36 grass_block
execute in minecraft:overworld run fill 384 66 36 384 144 36 air
execute in minecraft:overworld run fill 384 58 37 384 62 37 stone
execute in minecraft:overworld run fill 384 63 37 384 64 37 dirt
execute in minecraft:overworld run setblock 384 65 37 grass_block
execute in minecraft:overworld run fill 384 66 37 384 144 37 air
execute in minecraft:overworld run fill 384 58 38 384 62 38 stone
execute in minecraft:overworld run fill 384 63 38 384 64 38 dirt
execute in minecraft:overworld run setblock 384 65 38 coarse_dirt
execute in minecraft:overworld run fill 384 66 38 384 144 38 air
execute in minecraft:overworld run fill 384 58 39 384 61 39 stone
execute in minecraft:overworld run fill 384 62 39 384 63 39 dirt
execute in minecraft:overworld run setblock 384 64 39 coarse_dirt
execute in minecraft:overworld run fill 384 65 39 384 144 39 air
execute in minecraft:overworld run fill 384 58 40 384 61 40 stone
execute in minecraft:overworld run fill 384 62 40 384 63 40 dirt
execute in minecraft:overworld run setblock 384 64 40 grass_block
execute in minecraft:overworld run fill 384 65 40 384 144 40 air
execute in minecraft:overworld run fill 384 58 41 384 61 41 stone
execute in minecraft:overworld run fill 384 62 41 384 63 41 dirt
execute in minecraft:overworld run setblock 384 64 41 coarse_dirt
execute in minecraft:overworld run fill 384 65 41 384 144 41 air
execute in minecraft:overworld run fill 384 58 42 384 61 42 stone
execute in minecraft:overworld run fill 384 62 42 384 63 42 dirt
execute in minecraft:overworld run setblock 384 64 42 grass_block
execute in minecraft:overworld run fill 384 65 42 384 144 42 air
execute in minecraft:overworld run fill 384 58 43 384 61 43 stone
execute in minecraft:overworld run fill 384 62 43 384 63 43 dirt
execute in minecraft:overworld run setblock 384 64 43 grass_block
execute in minecraft:overworld run fill 384 65 43 384 144 43 air
execute in minecraft:overworld run fill 384 58 44 384 61 44 stone
execute in minecraft:overworld run fill 384 62 44 384 63 44 dirt
execute in minecraft:overworld run setblock 384 64 44 grass_block
execute in minecraft:overworld run fill 384 65 44 384 144 44 air
execute in minecraft:overworld run fill 384 58 45 384 61 45 stone
execute in minecraft:overworld run fill 384 62 45 384 63 45 dirt
execute in minecraft:overworld run setblock 384 64 45 grass_block
execute in minecraft:overworld run fill 384 65 45 384 144 45 air
execute in minecraft:overworld run fill 384 58 46 384 61 46 stone
execute in minecraft:overworld run fill 384 62 46 384 63 46 dirt
execute in minecraft:overworld run setblock 384 64 46 coarse_dirt
execute in minecraft:overworld run fill 384 65 46 384 144 46 air
execute in minecraft:overworld run fill 384 58 47 384 61 47 stone
execute in minecraft:overworld run fill 384 62 47 384 63 47 dirt
execute in minecraft:overworld run setblock 384 64 47 coarse_dirt
execute in minecraft:overworld run fill 384 65 47 384 144 47 air
execute in minecraft:overworld run fill 385 58 -48 385 61 -48 stone
execute in minecraft:overworld run fill 385 62 -48 385 63 -48 dirt
execute in minecraft:overworld run setblock 385 64 -48 coarse_dirt
execute in minecraft:overworld run fill 385 65 -48 385 144 -48 air
execute in minecraft:overworld run fill 385 58 -47 385 62 -47 stone
execute in minecraft:overworld run fill 385 63 -47 385 64 -47 dirt
execute in minecraft:overworld run setblock 385 65 -47 coarse_dirt
execute in minecraft:overworld run fill 385 66 -47 385 144 -47 air
execute in minecraft:overworld run fill 385 58 -46 385 64 -46 stone
execute in minecraft:overworld run fill 385 65 -46 385 66 -46 dirt
execute in minecraft:overworld run setblock 385 67 -46 grass_block
execute in minecraft:overworld run fill 385 68 -46 385 144 -46 air
execute in minecraft:overworld run fill 385 58 -45 385 65 -45 stone
execute in minecraft:overworld run fill 385 66 -45 385 67 -45 dirt
execute in minecraft:overworld run setblock 385 68 -45 coarse_dirt
execute in minecraft:overworld run fill 385 69 -45 385 144 -45 air
execute in minecraft:overworld run fill 385 58 -44 385 67 -44 stone
execute in minecraft:overworld run fill 385 68 -44 385 69 -44 dirt
execute in minecraft:overworld run setblock 385 70 -44 grass_block
execute in minecraft:overworld run fill 385 71 -44 385 144 -44 air
execute in minecraft:overworld run fill 385 58 -43 385 68 -43 stone
execute in minecraft:overworld run fill 385 69 -43 385 70 -43 dirt
execute in minecraft:overworld run setblock 385 71 -43 grass_block
execute in minecraft:overworld run fill 385 72 -43 385 144 -43 air
execute in minecraft:overworld run fill 385 58 -42 385 69 -42 stone
execute in minecraft:overworld run fill 385 70 -42 385 71 -42 dirt
execute in minecraft:overworld run setblock 385 72 -42 grass_block
execute in minecraft:overworld run fill 385 73 -42 385 144 -42 air
execute in minecraft:overworld run fill 385 58 -41 385 70 -41 stone
execute in minecraft:overworld run fill 385 71 -41 385 72 -41 dirt
execute in minecraft:overworld run setblock 385 73 -41 coarse_dirt
execute in minecraft:overworld run fill 385 74 -41 385 144 -41 air
execute in minecraft:overworld run fill 385 58 -40 385 70 -40 stone
execute in minecraft:overworld run fill 385 71 -40 385 72 -40 dirt
execute in minecraft:overworld run setblock 385 73 -40 coarse_dirt
execute in minecraft:overworld run fill 385 74 -40 385 144 -40 air
execute in minecraft:overworld run fill 385 58 -39 385 71 -39 stone
execute in minecraft:overworld run fill 385 72 -39 385 73 -39 dirt
execute in minecraft:overworld run setblock 385 74 -39 coarse_dirt
execute in minecraft:overworld run fill 385 75 -39 385 144 -39 air
execute in minecraft:overworld run setblock 385 75 -39 grass
execute in minecraft:overworld run fill 385 58 -38 385 72 -38 stone
execute in minecraft:overworld run fill 385 73 -38 385 74 -38 dirt
execute in minecraft:overworld run setblock 385 75 -38 grass_block
execute in minecraft:overworld run fill 385 76 -38 385 144 -38 air
execute in minecraft:overworld run setblock 385 76 -38 grass
execute in minecraft:overworld run fill 385 58 -37 385 71 -37 stone
execute in minecraft:overworld run fill 385 72 -37 385 73 -37 dirt
execute in minecraft:overworld run setblock 385 74 -37 grass_block
execute in minecraft:overworld run fill 385 75 -37 385 144 -37 air
execute in minecraft:overworld run fill 385 58 -36 385 70 -36 stone
execute in minecraft:overworld run fill 385 71 -36 385 72 -36 dirt
execute in minecraft:overworld run setblock 385 73 -36 coarse_dirt
execute in minecraft:overworld run fill 385 74 -36 385 144 -36 air
execute in minecraft:overworld run fill 385 58 -35 385 70 -35 stone
execute in minecraft:overworld run fill 385 71 -35 385 72 -35 dirt
execute in minecraft:overworld run setblock 385 73 -35 coarse_dirt
execute in minecraft:overworld run fill 385 74 -35 385 144 -35 air
execute in minecraft:overworld run fill 385 58 -34 385 69 -34 stone
execute in minecraft:overworld run fill 385 70 -34 385 71 -34 dirt
execute in minecraft:overworld run setblock 385 72 -34 coarse_dirt
execute in minecraft:overworld run fill 385 73 -34 385 144 -34 air
execute in minecraft:overworld run fill 385 58 -33 385 69 -33 stone
execute in minecraft:overworld run fill 385 70 -33 385 71 -33 dirt
execute in minecraft:overworld run setblock 385 72 -33 coarse_dirt
execute in minecraft:overworld run fill 385 73 -33 385 144 -33 air
execute in minecraft:overworld run fill 385 58 -32 385 69 -32 stone
execute in minecraft:overworld run fill 385 70 -32 385 71 -32 dirt
execute in minecraft:overworld run setblock 385 72 -32 grass_block
execute in minecraft:overworld run fill 385 73 -32 385 144 -32 air
execute in minecraft:overworld run setblock 385 73 -32 mossy_cobblestone
execute in minecraft:overworld run fill 385 58 -31 385 68 -31 stone
execute in minecraft:overworld run fill 385 69 -31 385 70 -31 dirt
execute in minecraft:overworld run setblock 385 71 -31 coarse_dirt
execute in minecraft:overworld run fill 385 72 -31 385 144 -31 air
execute in minecraft:overworld run fill 385 58 -30 385 68 -30 stone
execute in minecraft:overworld run fill 385 69 -30 385 70 -30 dirt
execute in minecraft:overworld run setblock 385 71 -30 coarse_dirt
execute in minecraft:overworld run fill 385 72 -30 385 144 -30 air
execute in minecraft:overworld run fill 385 58 -29 385 67 -29 stone
execute in minecraft:overworld run fill 385 68 -29 385 69 -29 dirt
execute in minecraft:overworld run setblock 385 70 -29 coarse_dirt
execute in minecraft:overworld run fill 385 71 -29 385 144 -29 air
execute in minecraft:overworld run fill 385 58 -28 385 66 -28 stone
execute in minecraft:overworld run fill 385 67 -28 385 68 -28 dirt
execute in minecraft:overworld run setblock 385 69 -28 grass_block
execute in minecraft:overworld run fill 385 70 -28 385 144 -28 air
execute in minecraft:overworld run fill 385 58 -27 385 66 -27 stone
execute in minecraft:overworld run fill 385 67 -27 385 68 -27 dirt
execute in minecraft:overworld run setblock 385 69 -27 grass_block
execute in minecraft:overworld run fill 385 70 -27 385 144 -27 air
execute in minecraft:overworld run fill 385 58 -26 385 65 -26 stone
execute in minecraft:overworld run fill 385 66 -26 385 67 -26 dirt
execute in minecraft:overworld run setblock 385 68 -26 coarse_dirt
execute in minecraft:overworld run fill 385 69 -26 385 144 -26 air
execute in minecraft:overworld run fill 385 58 -25 385 64 -25 stone
execute in minecraft:overworld run fill 385 65 -25 385 66 -25 dirt
execute in minecraft:overworld run setblock 385 67 -25 coarse_dirt
execute in minecraft:overworld run fill 385 68 -25 385 144 -25 air
execute in minecraft:overworld run fill 385 58 -24 385 63 -24 stone
execute in minecraft:overworld run fill 385 64 -24 385 65 -24 dirt
execute in minecraft:overworld run setblock 385 66 -24 grass_block
execute in minecraft:overworld run fill 385 67 -24 385 144 -24 air
execute in minecraft:overworld run fill 385 58 -23 385 62 -23 stone
execute in minecraft:overworld run fill 385 63 -23 385 64 -23 dirt
execute in minecraft:overworld run setblock 385 65 -23 coarse_dirt
execute in minecraft:overworld run fill 385 66 -23 385 144 -23 air
execute in minecraft:overworld run setblock 385 66 -23 grass
execute in minecraft:overworld run fill 385 58 -22 385 61 -22 stone
execute in minecraft:overworld run fill 385 62 -22 385 63 -22 dirt
execute in minecraft:overworld run setblock 385 64 -22 coarse_dirt
execute in minecraft:overworld run fill 385 65 -22 385 144 -22 air
execute in minecraft:overworld run fill 385 58 -21 385 60 -21 stone
execute in minecraft:overworld run fill 385 61 -21 385 62 -21 dirt
execute in minecraft:overworld run setblock 385 63 -21 gravel
execute in minecraft:overworld run fill 385 64 -21 385 144 -21 air
execute in minecraft:overworld run fill 385 64 -21 385 64 -21 water
execute in minecraft:overworld run fill 385 58 -20 385 59 -20 stone
execute in minecraft:overworld run fill 385 60 -20 385 61 -20 dirt
execute in minecraft:overworld run setblock 385 62 -20 gravel
execute in minecraft:overworld run fill 385 63 -20 385 144 -20 air
execute in minecraft:overworld run fill 385 63 -20 385 64 -20 water
execute in minecraft:overworld run fill 385 58 -19 385 59 -19 stone
execute in minecraft:overworld run fill 385 60 -19 385 61 -19 dirt
execute in minecraft:overworld run setblock 385 62 -19 gravel
execute in minecraft:overworld run fill 385 63 -19 385 144 -19 air
execute in minecraft:overworld run fill 385 63 -19 385 64 -19 water
execute in minecraft:overworld run fill 385 58 -18 385 58 -18 stone
execute in minecraft:overworld run fill 385 59 -18 385 60 -18 dirt
execute in minecraft:overworld run setblock 385 61 -18 gravel
execute in minecraft:overworld run fill 385 62 -18 385 144 -18 air
execute in minecraft:overworld run fill 385 62 -18 385 64 -18 water
execute in minecraft:overworld run fill 385 58 -17 385 58 -17 stone
execute in minecraft:overworld run fill 385 59 -17 385 60 -17 dirt
execute in minecraft:overworld run setblock 385 61 -17 gravel
execute in minecraft:overworld run fill 385 62 -17 385 144 -17 air
execute in minecraft:overworld run fill 385 62 -17 385 64 -17 water
execute in minecraft:overworld run fill 385 58 -16 385 58 -16 stone
execute in minecraft:overworld run fill 385 59 -16 385 60 -16 dirt
execute in minecraft:overworld run setblock 385 61 -16 gravel
execute in minecraft:overworld run fill 385 62 -16 385 144 -16 air
execute in minecraft:overworld run fill 385 62 -16 385 64 -16 water
execute in minecraft:overworld run fill 385 58 -15 385 58 -15 stone
execute in minecraft:overworld run fill 385 59 -15 385 60 -15 dirt
execute in minecraft:overworld run setblock 385 61 -15 gravel
execute in minecraft:overworld run fill 385 62 -15 385 144 -15 air
execute in minecraft:overworld run fill 385 62 -15 385 64 -15 water
execute in minecraft:overworld run fill 385 58 -14 385 57 -14 stone
execute in minecraft:overworld run fill 385 58 -14 385 59 -14 dirt
execute in minecraft:overworld run setblock 385 60 -14 gravel
execute in minecraft:overworld run fill 385 61 -14 385 144 -14 air
execute in minecraft:overworld run fill 385 61 -14 385 64 -14 water
execute in minecraft:overworld run fill 385 58 -13 385 57 -13 stone
execute in minecraft:overworld run fill 385 58 -13 385 59 -13 dirt
execute in minecraft:overworld run setblock 385 60 -13 gravel
execute in minecraft:overworld run fill 385 61 -13 385 144 -13 air
execute in minecraft:overworld run fill 385 61 -13 385 64 -13 water
execute in minecraft:overworld run fill 385 58 -12 385 57 -12 stone
execute in minecraft:overworld run fill 385 58 -12 385 59 -12 dirt
execute in minecraft:overworld run setblock 385 60 -12 gravel
execute in minecraft:overworld run fill 385 61 -12 385 144 -12 air
execute in minecraft:overworld run fill 385 61 -12 385 64 -12 water
execute in minecraft:overworld run fill 385 58 -11 385 57 -11 stone
execute in minecraft:overworld run fill 385 58 -11 385 59 -11 dirt
execute in minecraft:overworld run setblock 385 60 -11 gravel
execute in minecraft:overworld run fill 385 61 -11 385 144 -11 air
execute in minecraft:overworld run fill 385 61 -11 385 64 -11 water
execute in minecraft:overworld run fill 385 58 -10 385 58 -10 stone
execute in minecraft:overworld run fill 385 59 -10 385 60 -10 dirt
execute in minecraft:overworld run setblock 385 61 -10 gravel
execute in minecraft:overworld run fill 385 62 -10 385 144 -10 air
execute in minecraft:overworld run fill 385 62 -10 385 64 -10 water
execute in minecraft:overworld run fill 385 58 -9 385 58 -9 stone
schedule function blade_gallery:random/battlefield/part_76 1t replace
