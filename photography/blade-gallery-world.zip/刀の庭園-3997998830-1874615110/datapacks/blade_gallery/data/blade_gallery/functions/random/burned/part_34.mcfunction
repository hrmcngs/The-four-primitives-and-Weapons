execute in minecraft:overworld run fill 230 58 -26 230 67 -26 stone
execute in minecraft:overworld run fill 230 68 -26 230 69 -26 dirt
execute in minecraft:overworld run setblock 230 70 -26 grass_block
execute in minecraft:overworld run fill 230 71 -26 230 144 -26 air
execute in minecraft:overworld run fill 230 58 -25 230 67 -25 stone
execute in minecraft:overworld run fill 230 68 -25 230 69 -25 dirt
execute in minecraft:overworld run setblock 230 70 -25 grass_block
execute in minecraft:overworld run fill 230 71 -25 230 144 -25 air
execute in minecraft:overworld run setblock 230 71 -25 grass
execute in minecraft:overworld run fill 230 58 -24 230 67 -24 stone
execute in minecraft:overworld run fill 230 68 -24 230 69 -24 dirt
execute in minecraft:overworld run setblock 230 70 -24 grass_block
execute in minecraft:overworld run fill 230 71 -24 230 144 -24 air
execute in minecraft:overworld run fill 230 58 -23 230 67 -23 stone
execute in minecraft:overworld run fill 230 68 -23 230 69 -23 dirt
execute in minecraft:overworld run setblock 230 70 -23 grass_block
execute in minecraft:overworld run fill 230 71 -23 230 144 -23 air
execute in minecraft:overworld run fill 230 58 -22 230 66 -22 stone
execute in minecraft:overworld run fill 230 67 -22 230 68 -22 dirt
execute in minecraft:overworld run setblock 230 69 -22 coarse_dirt
execute in minecraft:overworld run fill 230 70 -22 230 144 -22 air
execute in minecraft:overworld run fill 230 58 -21 230 66 -21 stone
execute in minecraft:overworld run fill 230 67 -21 230 68 -21 dirt
execute in minecraft:overworld run setblock 230 69 -21 coarse_dirt
execute in minecraft:overworld run fill 230 70 -21 230 144 -21 air
execute in minecraft:overworld run setblock 230 70 -21 grass
execute in minecraft:overworld run fill 230 58 -20 230 66 -20 stone
execute in minecraft:overworld run fill 230 67 -20 230 68 -20 dirt
execute in minecraft:overworld run setblock 230 69 -20 grass_block
execute in minecraft:overworld run fill 230 70 -20 230 144 -20 air
execute in minecraft:overworld run fill 230 58 -19 230 66 -19 stone
execute in minecraft:overworld run fill 230 67 -19 230 68 -19 dirt
execute in minecraft:overworld run setblock 230 69 -19 coarse_dirt
execute in minecraft:overworld run fill 230 70 -19 230 144 -19 air
execute in minecraft:overworld run fill 230 58 -18 230 66 -18 stone
execute in minecraft:overworld run fill 230 67 -18 230 68 -18 dirt
execute in minecraft:overworld run setblock 230 69 -18 grass_block
execute in minecraft:overworld run fill 230 70 -18 230 144 -18 air
execute in minecraft:overworld run fill 230 58 -17 230 66 -17 stone
execute in minecraft:overworld run fill 230 67 -17 230 68 -17 dirt
execute in minecraft:overworld run setblock 230 69 -17 coarse_dirt
execute in minecraft:overworld run fill 230 70 -17 230 144 -17 air
execute in minecraft:overworld run fill 230 58 -16 230 65 -16 stone
execute in minecraft:overworld run fill 230 66 -16 230 67 -16 dirt
execute in minecraft:overworld run setblock 230 68 -16 grass_block
execute in minecraft:overworld run fill 230 69 -16 230 144 -16 air
execute in minecraft:overworld run fill 230 58 -15 230 65 -15 stone
execute in minecraft:overworld run fill 230 66 -15 230 67 -15 dirt
execute in minecraft:overworld run setblock 230 68 -15 grass_block
execute in minecraft:overworld run fill 230 69 -15 230 144 -15 air
execute in minecraft:overworld run fill 230 58 -14 230 65 -14 stone
execute in minecraft:overworld run fill 230 66 -14 230 67 -14 dirt
execute in minecraft:overworld run setblock 230 68 -14 coarse_dirt
execute in minecraft:overworld run fill 230 69 -14 230 144 -14 air
execute in minecraft:overworld run fill 230 58 -13 230 65 -13 stone
execute in minecraft:overworld run fill 230 66 -13 230 67 -13 dirt
execute in minecraft:overworld run setblock 230 68 -13 coarse_dirt
execute in minecraft:overworld run fill 230 69 -13 230 144 -13 air
execute in minecraft:overworld run fill 230 58 -12 230 64 -12 stone
execute in minecraft:overworld run fill 230 65 -12 230 66 -12 dirt
execute in minecraft:overworld run setblock 230 67 -12 grass_block
execute in minecraft:overworld run fill 230 68 -12 230 144 -12 air
execute in minecraft:overworld run setblock 230 68 -12 mossy_cobblestone
execute in minecraft:overworld run fill 230 58 -11 230 64 -11 stone
execute in minecraft:overworld run fill 230 65 -11 230 66 -11 dirt
execute in minecraft:overworld run setblock 230 67 -11 coarse_dirt
execute in minecraft:overworld run fill 230 68 -11 230 144 -11 air
execute in minecraft:overworld run setblock 230 68 -11 mossy_cobblestone
execute in minecraft:overworld run fill 230 58 -10 230 65 -10 stone
execute in minecraft:overworld run fill 230 66 -10 230 67 -10 dirt
execute in minecraft:overworld run setblock 230 68 -10 grass_block
execute in minecraft:overworld run fill 230 69 -10 230 144 -10 air
execute in minecraft:overworld run fill 230 58 -9 230 65 -9 stone
execute in minecraft:overworld run fill 230 66 -9 230 67 -9 dirt
execute in minecraft:overworld run setblock 230 68 -9 grass_block
execute in minecraft:overworld run fill 230 69 -9 230 144 -9 air
execute in minecraft:overworld run fill 230 58 -8 230 65 -8 stone
execute in minecraft:overworld run fill 230 66 -8 230 67 -8 dirt
execute in minecraft:overworld run setblock 230 68 -8 coarse_dirt
execute in minecraft:overworld run fill 230 69 -8 230 144 -8 air
execute in minecraft:overworld run fill 230 58 -7 230 65 -7 stone
execute in minecraft:overworld run fill 230 66 -7 230 67 -7 dirt
execute in minecraft:overworld run setblock 230 68 -7 grass_block
execute in minecraft:overworld run fill 230 69 -7 230 144 -7 air
execute in minecraft:overworld run fill 230 58 -6 230 65 -6 stone
execute in minecraft:overworld run fill 230 66 -6 230 67 -6 dirt
execute in minecraft:overworld run setblock 230 68 -6 grass_block
execute in minecraft:overworld run fill 230 69 -6 230 144 -6 air
execute in minecraft:overworld run setblock 230 69 -6 grass
execute in minecraft:overworld run fill 230 58 -5 230 65 -5 stone
execute in minecraft:overworld run fill 230 66 -5 230 67 -5 dirt
execute in minecraft:overworld run setblock 230 68 -5 grass_block
execute in minecraft:overworld run fill 230 69 -5 230 144 -5 air
execute in minecraft:overworld run setblock 230 69 -5 grass
execute in minecraft:overworld run fill 230 58 -4 230 66 -4 stone
execute in minecraft:overworld run fill 230 67 -4 230 68 -4 dirt
execute in minecraft:overworld run setblock 230 69 -4 coarse_dirt
execute in minecraft:overworld run fill 230 70 -4 230 144 -4 air
execute in minecraft:overworld run setblock 230 70 -4 grass
execute in minecraft:overworld run fill 230 58 -3 230 66 -3 stone
execute in minecraft:overworld run fill 230 67 -3 230 68 -3 dirt
execute in minecraft:overworld run setblock 230 69 -3 coarse_dirt
execute in minecraft:overworld run fill 230 70 -3 230 144 -3 air
execute in minecraft:overworld run fill 230 58 -2 230 66 -2 stone
execute in minecraft:overworld run fill 230 67 -2 230 68 -2 dirt
execute in minecraft:overworld run setblock 230 69 -2 coarse_dirt
execute in minecraft:overworld run fill 230 70 -2 230 144 -2 air
execute in minecraft:overworld run fill 230 58 -1 230 66 -1 stone
execute in minecraft:overworld run fill 230 67 -1 230 68 -1 dirt
execute in minecraft:overworld run setblock 230 69 -1 coarse_dirt
execute in minecraft:overworld run fill 230 70 -1 230 144 -1 air
execute in minecraft:overworld run fill 230 58 0 230 66 0 stone
execute in minecraft:overworld run fill 230 67 0 230 68 0 dirt
execute in minecraft:overworld run setblock 230 69 0 grass_block
execute in minecraft:overworld run fill 230 70 0 230 144 0 air
execute in minecraft:overworld run fill 230 58 1 230 66 1 stone
execute in minecraft:overworld run fill 230 67 1 230 68 1 dirt
execute in minecraft:overworld run setblock 230 69 1 coarse_dirt
execute in minecraft:overworld run fill 230 70 1 230 144 1 air
execute in minecraft:overworld run fill 230 58 2 230 66 2 stone
execute in minecraft:overworld run fill 230 67 2 230 68 2 dirt
execute in minecraft:overworld run setblock 230 69 2 coarse_dirt
execute in minecraft:overworld run fill 230 70 2 230 144 2 air
execute in minecraft:overworld run fill 230 58 3 230 66 3 stone
execute in minecraft:overworld run fill 230 67 3 230 68 3 dirt
execute in minecraft:overworld run setblock 230 69 3 coarse_dirt
execute in minecraft:overworld run fill 230 70 3 230 144 3 air
execute in minecraft:overworld run fill 230 58 4 230 66 4 stone
execute in minecraft:overworld run fill 230 67 4 230 68 4 dirt
execute in minecraft:overworld run setblock 230 69 4 grass_block
execute in minecraft:overworld run fill 230 70 4 230 144 4 air
execute in minecraft:overworld run setblock 230 70 4 mossy_cobblestone
execute in minecraft:overworld run fill 230 58 5 230 66 5 stone
execute in minecraft:overworld run fill 230 67 5 230 68 5 dirt
execute in minecraft:overworld run setblock 230 69 5 coarse_dirt
execute in minecraft:overworld run fill 230 70 5 230 144 5 air
execute in minecraft:overworld run fill 230 58 6 230 66 6 stone
execute in minecraft:overworld run fill 230 67 6 230 68 6 dirt
execute in minecraft:overworld run setblock 230 69 6 grass_block
execute in minecraft:overworld run fill 230 70 6 230 144 6 air
execute in minecraft:overworld run fill 230 58 7 230 66 7 stone
execute in minecraft:overworld run fill 230 67 7 230 68 7 dirt
execute in minecraft:overworld run setblock 230 69 7 coarse_dirt
execute in minecraft:overworld run fill 230 70 7 230 144 7 air
execute in minecraft:overworld run fill 230 58 8 230 66 8 stone
execute in minecraft:overworld run fill 230 67 8 230 68 8 dirt
execute in minecraft:overworld run setblock 230 69 8 coarse_dirt
execute in minecraft:overworld run fill 230 70 8 230 144 8 air
execute in minecraft:overworld run setblock 230 70 8 grass
execute in minecraft:overworld run fill 230 58 9 230 66 9 stone
execute in minecraft:overworld run fill 230 67 9 230 68 9 dirt
execute in minecraft:overworld run setblock 230 69 9 coarse_dirt
execute in minecraft:overworld run fill 230 70 9 230 144 9 air
execute in minecraft:overworld run fill 230 58 10 230 67 10 stone
execute in minecraft:overworld run fill 230 68 10 230 69 10 dirt
execute in minecraft:overworld run setblock 230 70 10 grass_block
execute in minecraft:overworld run fill 230 71 10 230 144 10 air
execute in minecraft:overworld run fill 230 58 11 230 67 11 stone
execute in minecraft:overworld run fill 230 68 11 230 69 11 dirt
execute in minecraft:overworld run setblock 230 70 11 coarse_dirt
execute in minecraft:overworld run fill 230 71 11 230 144 11 air
execute in minecraft:overworld run fill 230 58 12 230 67 12 stone
execute in minecraft:overworld run fill 230 68 12 230 69 12 dirt
execute in minecraft:overworld run setblock 230 70 12 coarse_dirt
execute in minecraft:overworld run fill 230 71 12 230 144 12 air
execute in minecraft:overworld run fill 230 58 13 230 68 13 stone
execute in minecraft:overworld run fill 230 69 13 230 70 13 dirt
execute in minecraft:overworld run setblock 230 71 13 coarse_dirt
execute in minecraft:overworld run fill 230 72 13 230 144 13 air
execute in minecraft:overworld run fill 230 58 14 230 68 14 stone
execute in minecraft:overworld run fill 230 69 14 230 70 14 dirt
execute in minecraft:overworld run setblock 230 71 14 grass_block
execute in minecraft:overworld run fill 230 72 14 230 144 14 air
execute in minecraft:overworld run fill 230 58 15 230 68 15 stone
execute in minecraft:overworld run fill 230 69 15 230 70 15 dirt
execute in minecraft:overworld run setblock 230 71 15 coarse_dirt
execute in minecraft:overworld run fill 230 72 15 230 144 15 air
execute in minecraft:overworld run fill 230 58 16 230 68 16 stone
execute in minecraft:overworld run fill 230 69 16 230 70 16 dirt
execute in minecraft:overworld run setblock 230 71 16 coarse_dirt
execute in minecraft:overworld run fill 230 72 16 230 144 16 air
execute in minecraft:overworld run fill 230 58 17 230 69 17 stone
execute in minecraft:overworld run fill 230 70 17 230 71 17 dirt
execute in minecraft:overworld run setblock 230 72 17 grass_block
execute in minecraft:overworld run fill 230 73 17 230 144 17 air
execute in minecraft:overworld run fill 230 58 18 230 69 18 stone
execute in minecraft:overworld run fill 230 70 18 230 71 18 dirt
execute in minecraft:overworld run setblock 230 72 18 coarse_dirt
execute in minecraft:overworld run fill 230 73 18 230 144 18 air
execute in minecraft:overworld run fill 230 58 19 230 69 19 stone
execute in minecraft:overworld run fill 230 70 19 230 71 19 dirt
execute in minecraft:overworld run setblock 230 72 19 coarse_dirt
execute in minecraft:overworld run fill 230 73 19 230 144 19 air
execute in minecraft:overworld run fill 230 58 20 230 69 20 stone
execute in minecraft:overworld run fill 230 70 20 230 71 20 dirt
execute in minecraft:overworld run setblock 230 72 20 grass_block
execute in minecraft:overworld run fill 230 73 20 230 144 20 air
execute in minecraft:overworld run fill 230 58 21 230 69 21 stone
execute in minecraft:overworld run fill 230 70 21 230 71 21 dirt
execute in minecraft:overworld run setblock 230 72 21 coarse_dirt
execute in minecraft:overworld run fill 230 73 21 230 144 21 air
execute in minecraft:overworld run fill 230 58 22 230 70 22 stone
execute in minecraft:overworld run fill 230 71 22 230 72 22 dirt
execute in minecraft:overworld run setblock 230 73 22 coarse_dirt
execute in minecraft:overworld run fill 230 74 22 230 144 22 air
execute in minecraft:overworld run fill 230 58 23 230 70 23 stone
execute in minecraft:overworld run fill 230 71 23 230 72 23 dirt
execute in minecraft:overworld run setblock 230 73 23 coarse_dirt
execute in minecraft:overworld run fill 230 74 23 230 144 23 air
execute in minecraft:overworld run fill 230 58 24 230 70 24 stone
execute in minecraft:overworld run fill 230 71 24 230 72 24 dirt
execute in minecraft:overworld run setblock 230 73 24 coarse_dirt
execute in minecraft:overworld run fill 230 74 24 230 144 24 air
execute in minecraft:overworld run fill 230 58 25 230 70 25 stone
execute in minecraft:overworld run fill 230 71 25 230 72 25 dirt
execute in minecraft:overworld run setblock 230 73 25 coarse_dirt
execute in minecraft:overworld run fill 230 74 25 230 144 25 air
execute in minecraft:overworld run fill 230 58 26 230 70 26 stone
execute in minecraft:overworld run fill 230 71 26 230 72 26 dirt
execute in minecraft:overworld run setblock 230 73 26 coarse_dirt
execute in minecraft:overworld run fill 230 74 26 230 144 26 air
execute in minecraft:overworld run fill 230 58 27 230 70 27 stone
execute in minecraft:overworld run fill 230 71 27 230 72 27 dirt
execute in minecraft:overworld run setblock 230 73 27 grass_block
execute in minecraft:overworld run fill 230 74 27 230 144 27 air
execute in minecraft:overworld run fill 230 58 28 230 70 28 stone
execute in minecraft:overworld run fill 230 71 28 230 72 28 dirt
execute in minecraft:overworld run setblock 230 73 28 coarse_dirt
execute in minecraft:overworld run fill 230 74 28 230 144 28 air
execute in minecraft:overworld run setblock 230 74 28 mossy_cobblestone
execute in minecraft:overworld run fill 230 58 29 230 70 29 stone
execute in minecraft:overworld run fill 230 71 29 230 72 29 dirt
execute in minecraft:overworld run setblock 230 73 29 grass_block
execute in minecraft:overworld run fill 230 74 29 230 144 29 air
execute in minecraft:overworld run fill 230 58 30 230 70 30 stone
execute in minecraft:overworld run fill 230 71 30 230 72 30 dirt
execute in minecraft:overworld run setblock 230 73 30 coarse_dirt
execute in minecraft:overworld run fill 230 74 30 230 144 30 air
execute in minecraft:overworld run fill 230 58 31 230 70 31 stone
execute in minecraft:overworld run fill 230 71 31 230 72 31 dirt
execute in minecraft:overworld run setblock 230 73 31 coarse_dirt
execute in minecraft:overworld run fill 230 74 31 230 144 31 air
execute in minecraft:overworld run fill 230 58 32 230 70 32 stone
execute in minecraft:overworld run fill 230 71 32 230 72 32 dirt
execute in minecraft:overworld run setblock 230 73 32 coarse_dirt
execute in minecraft:overworld run fill 230 74 32 230 144 32 air
execute in minecraft:overworld run fill 230 58 33 230 70 33 stone
execute in minecraft:overworld run fill 230 71 33 230 72 33 dirt
execute in minecraft:overworld run setblock 230 73 33 coarse_dirt
execute in minecraft:overworld run fill 230 74 33 230 144 33 air
execute in minecraft:overworld run fill 230 58 34 230 69 34 stone
execute in minecraft:overworld run fill 230 70 34 230 71 34 dirt
execute in minecraft:overworld run setblock 230 72 34 grass_block
execute in minecraft:overworld run fill 230 73 34 230 144 34 air
execute in minecraft:overworld run fill 230 58 35 230 69 35 stone
execute in minecraft:overworld run fill 230 70 35 230 71 35 dirt
schedule function blade_gallery:random/burned/part_35 1t replace
