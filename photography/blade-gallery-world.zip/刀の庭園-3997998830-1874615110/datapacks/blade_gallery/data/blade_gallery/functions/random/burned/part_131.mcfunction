execute in minecraft:overworld run fill 290 58 42 290 62 42 stone
execute in minecraft:overworld run fill 290 63 42 290 64 42 dirt
execute in minecraft:overworld run setblock 290 65 42 coarse_dirt
execute in minecraft:overworld run fill 290 66 42 290 144 42 air
execute in minecraft:overworld run fill 290 58 43 290 62 43 stone
execute in minecraft:overworld run fill 290 63 43 290 64 43 dirt
execute in minecraft:overworld run setblock 290 65 43 coarse_dirt
execute in minecraft:overworld run fill 290 66 43 290 144 43 air
execute in minecraft:overworld run fill 290 58 44 290 62 44 stone
execute in minecraft:overworld run fill 290 63 44 290 64 44 dirt
execute in minecraft:overworld run setblock 290 65 44 coarse_dirt
execute in minecraft:overworld run fill 290 66 44 290 144 44 air
execute in minecraft:overworld run fill 290 58 45 290 62 45 stone
execute in minecraft:overworld run fill 290 63 45 290 64 45 dirt
execute in minecraft:overworld run setblock 290 65 45 grass_block
execute in minecraft:overworld run fill 290 66 45 290 144 45 air
execute in minecraft:overworld run fill 290 58 46 290 61 46 stone
execute in minecraft:overworld run fill 290 62 46 290 63 46 dirt
execute in minecraft:overworld run setblock 290 64 46 grass_block
execute in minecraft:overworld run fill 290 65 46 290 144 46 air
execute in minecraft:overworld run fill 290 58 47 290 61 47 stone
execute in minecraft:overworld run fill 290 62 47 290 63 47 dirt
execute in minecraft:overworld run setblock 290 64 47 coarse_dirt
execute in minecraft:overworld run fill 290 65 47 290 144 47 air
execute in minecraft:overworld run fill 291 58 -48 291 61 -48 stone
execute in minecraft:overworld run fill 291 62 -48 291 63 -48 dirt
execute in minecraft:overworld run setblock 291 64 -48 coarse_dirt
execute in minecraft:overworld run fill 291 65 -48 291 144 -48 air
execute in minecraft:overworld run fill 291 58 -47 291 63 -47 stone
execute in minecraft:overworld run fill 291 64 -47 291 65 -47 dirt
execute in minecraft:overworld run setblock 291 66 -47 grass_block
execute in minecraft:overworld run fill 291 67 -47 291 144 -47 air
execute in minecraft:overworld run fill 291 58 -46 291 65 -46 stone
execute in minecraft:overworld run fill 291 66 -46 291 67 -46 dirt
execute in minecraft:overworld run setblock 291 68 -46 grass_block
execute in minecraft:overworld run fill 291 69 -46 291 144 -46 air
execute in minecraft:overworld run fill 291 58 -45 291 67 -45 stone
execute in minecraft:overworld run fill 291 68 -45 291 69 -45 dirt
execute in minecraft:overworld run setblock 291 70 -45 coarse_dirt
execute in minecraft:overworld run fill 291 71 -45 291 144 -45 air
execute in minecraft:overworld run fill 291 58 -44 291 69 -44 stone
execute in minecraft:overworld run fill 291 70 -44 291 71 -44 dirt
execute in minecraft:overworld run setblock 291 72 -44 grass_block
execute in minecraft:overworld run fill 291 73 -44 291 144 -44 air
execute in minecraft:overworld run fill 291 58 -43 291 70 -43 stone
execute in minecraft:overworld run fill 291 71 -43 291 72 -43 dirt
execute in minecraft:overworld run setblock 291 73 -43 grass_block
execute in minecraft:overworld run fill 291 74 -43 291 144 -43 air
execute in minecraft:overworld run fill 291 58 -42 291 72 -42 stone
execute in minecraft:overworld run fill 291 73 -42 291 74 -42 dirt
execute in minecraft:overworld run setblock 291 75 -42 coarse_dirt
execute in minecraft:overworld run fill 291 76 -42 291 144 -42 air
execute in minecraft:overworld run fill 291 58 -41 291 74 -41 stone
execute in minecraft:overworld run fill 291 75 -41 291 76 -41 dirt
execute in minecraft:overworld run setblock 291 77 -41 coarse_dirt
execute in minecraft:overworld run fill 291 78 -41 291 144 -41 air
execute in minecraft:overworld run fill 291 58 -40 291 76 -40 stone
execute in minecraft:overworld run fill 291 77 -40 291 78 -40 dirt
execute in minecraft:overworld run setblock 291 79 -40 grass_block
execute in minecraft:overworld run fill 291 80 -40 291 144 -40 air
execute in minecraft:overworld run fill 291 58 -39 291 77 -39 stone
execute in minecraft:overworld run fill 291 78 -39 291 79 -39 dirt
execute in minecraft:overworld run setblock 291 80 -39 grass_block
execute in minecraft:overworld run fill 291 81 -39 291 144 -39 air
execute in minecraft:overworld run fill 291 58 -38 291 79 -38 stone
execute in minecraft:overworld run fill 291 80 -38 291 81 -38 dirt
execute in minecraft:overworld run setblock 291 82 -38 coarse_dirt
execute in minecraft:overworld run fill 291 83 -38 291 144 -38 air
execute in minecraft:overworld run fill 291 58 -37 291 79 -37 stone
execute in minecraft:overworld run fill 291 80 -37 291 81 -37 dirt
execute in minecraft:overworld run setblock 291 82 -37 coarse_dirt
execute in minecraft:overworld run fill 291 83 -37 291 144 -37 air
execute in minecraft:overworld run fill 291 58 -36 291 78 -36 stone
execute in minecraft:overworld run fill 291 79 -36 291 80 -36 dirt
execute in minecraft:overworld run setblock 291 81 -36 coarse_dirt
execute in minecraft:overworld run fill 291 82 -36 291 144 -36 air
execute in minecraft:overworld run fill 291 58 -35 291 78 -35 stone
execute in minecraft:overworld run fill 291 79 -35 291 80 -35 dirt
execute in minecraft:overworld run setblock 291 81 -35 coarse_dirt
execute in minecraft:overworld run fill 291 82 -35 291 144 -35 air
execute in minecraft:overworld run fill 291 58 -34 291 78 -34 stone
execute in minecraft:overworld run fill 291 79 -34 291 80 -34 dirt
execute in minecraft:overworld run setblock 291 81 -34 grass_block
execute in minecraft:overworld run fill 291 82 -34 291 144 -34 air
execute in minecraft:overworld run fill 291 58 -33 291 77 -33 stone
execute in minecraft:overworld run fill 291 78 -33 291 79 -33 dirt
execute in minecraft:overworld run setblock 291 80 -33 grass_block
execute in minecraft:overworld run fill 291 81 -33 291 144 -33 air
execute in minecraft:overworld run setblock 291 81 -33 grass
execute in minecraft:overworld run fill 291 58 -32 291 76 -32 stone
execute in minecraft:overworld run fill 291 77 -32 291 78 -32 dirt
execute in minecraft:overworld run setblock 291 79 -32 coarse_dirt
execute in minecraft:overworld run fill 291 80 -32 291 144 -32 air
execute in minecraft:overworld run fill 291 58 -31 291 76 -31 stone
execute in minecraft:overworld run fill 291 77 -31 291 78 -31 dirt
execute in minecraft:overworld run setblock 291 79 -31 coarse_dirt
execute in minecraft:overworld run fill 291 80 -31 291 144 -31 air
execute in minecraft:overworld run fill 291 58 -30 291 75 -30 stone
execute in minecraft:overworld run fill 291 76 -30 291 77 -30 dirt
execute in minecraft:overworld run setblock 291 78 -30 coarse_dirt
execute in minecraft:overworld run fill 291 79 -30 291 144 -30 air
execute in minecraft:overworld run fill 291 58 -29 291 75 -29 stone
execute in minecraft:overworld run fill 291 76 -29 291 77 -29 dirt
execute in minecraft:overworld run setblock 291 78 -29 coarse_dirt
execute in minecraft:overworld run fill 291 79 -29 291 144 -29 air
execute in minecraft:overworld run setblock 291 79 -29 grass
execute in minecraft:overworld run fill 291 58 -28 291 74 -28 stone
execute in minecraft:overworld run fill 291 75 -28 291 76 -28 dirt
execute in minecraft:overworld run setblock 291 77 -28 grass_block
execute in minecraft:overworld run fill 291 78 -28 291 144 -28 air
execute in minecraft:overworld run fill 291 58 -27 291 74 -27 stone
execute in minecraft:overworld run fill 291 75 -27 291 76 -27 dirt
execute in minecraft:overworld run setblock 291 77 -27 coarse_dirt
execute in minecraft:overworld run fill 291 78 -27 291 144 -27 air
execute in minecraft:overworld run fill 291 58 -26 291 74 -26 stone
execute in minecraft:overworld run fill 291 75 -26 291 76 -26 dirt
execute in minecraft:overworld run setblock 291 77 -26 grass_block
execute in minecraft:overworld run fill 291 78 -26 291 144 -26 air
execute in minecraft:overworld run fill 291 58 -25 291 73 -25 stone
execute in minecraft:overworld run fill 291 74 -25 291 75 -25 dirt
execute in minecraft:overworld run setblock 291 76 -25 coarse_dirt
execute in minecraft:overworld run fill 291 77 -25 291 144 -25 air
execute in minecraft:overworld run fill 291 58 -24 291 73 -24 stone
execute in minecraft:overworld run fill 291 74 -24 291 75 -24 dirt
execute in minecraft:overworld run setblock 291 76 -24 coarse_dirt
execute in minecraft:overworld run fill 291 77 -24 291 144 -24 air
execute in minecraft:overworld run fill 291 58 -23 291 72 -23 stone
execute in minecraft:overworld run fill 291 73 -23 291 74 -23 dirt
execute in minecraft:overworld run setblock 291 75 -23 coarse_dirt
execute in minecraft:overworld run fill 291 76 -23 291 144 -23 air
execute in minecraft:overworld run setblock 291 76 -23 grass
execute in minecraft:overworld run fill 291 58 -22 291 72 -22 stone
execute in minecraft:overworld run fill 291 73 -22 291 74 -22 dirt
execute in minecraft:overworld run setblock 291 75 -22 grass_block
execute in minecraft:overworld run fill 291 76 -22 291 144 -22 air
execute in minecraft:overworld run fill 291 58 -21 291 72 -21 stone
execute in minecraft:overworld run fill 291 73 -21 291 74 -21 dirt
execute in minecraft:overworld run setblock 291 75 -21 coarse_dirt
execute in minecraft:overworld run fill 291 76 -21 291 144 -21 air
execute in minecraft:overworld run fill 291 58 -20 291 71 -20 stone
execute in minecraft:overworld run fill 291 72 -20 291 73 -20 dirt
execute in minecraft:overworld run setblock 291 74 -20 grass_block
execute in minecraft:overworld run fill 291 75 -20 291 144 -20 air
execute in minecraft:overworld run fill 291 58 -19 291 71 -19 stone
execute in minecraft:overworld run fill 291 72 -19 291 73 -19 dirt
execute in minecraft:overworld run setblock 291 74 -19 coarse_dirt
execute in minecraft:overworld run fill 291 75 -19 291 144 -19 air
execute in minecraft:overworld run fill 291 58 -18 291 71 -18 stone
execute in minecraft:overworld run fill 291 72 -18 291 73 -18 dirt
execute in minecraft:overworld run setblock 291 74 -18 coarse_dirt
execute in minecraft:overworld run fill 291 75 -18 291 144 -18 air
execute in minecraft:overworld run fill 291 58 -17 291 70 -17 stone
execute in minecraft:overworld run fill 291 71 -17 291 72 -17 dirt
execute in minecraft:overworld run setblock 291 73 -17 coarse_dirt
execute in minecraft:overworld run fill 291 74 -17 291 144 -17 air
execute in minecraft:overworld run fill 291 58 -16 291 70 -16 stone
execute in minecraft:overworld run fill 291 71 -16 291 72 -16 dirt
execute in minecraft:overworld run setblock 291 73 -16 grass_block
execute in minecraft:overworld run fill 291 74 -16 291 144 -16 air
execute in minecraft:overworld run fill 291 58 -15 291 70 -15 stone
execute in minecraft:overworld run fill 291 71 -15 291 72 -15 dirt
execute in minecraft:overworld run setblock 291 73 -15 coarse_dirt
execute in minecraft:overworld run fill 291 74 -15 291 144 -15 air
execute in minecraft:overworld run setblock 291 74 -15 grass
execute in minecraft:overworld run fill 291 58 -14 291 69 -14 stone
execute in minecraft:overworld run fill 291 70 -14 291 71 -14 dirt
execute in minecraft:overworld run setblock 291 72 -14 coarse_dirt
execute in minecraft:overworld run fill 291 73 -14 291 144 -14 air
execute in minecraft:overworld run fill 291 58 -13 291 69 -13 stone
execute in minecraft:overworld run fill 291 70 -13 291 71 -13 dirt
execute in minecraft:overworld run setblock 291 72 -13 coarse_dirt
execute in minecraft:overworld run fill 291 73 -13 291 144 -13 air
execute in minecraft:overworld run fill 291 58 -12 291 69 -12 stone
execute in minecraft:overworld run fill 291 70 -12 291 71 -12 dirt
execute in minecraft:overworld run setblock 291 72 -12 coarse_dirt
execute in minecraft:overworld run fill 291 73 -12 291 144 -12 air
execute in minecraft:overworld run fill 291 58 -11 291 69 -11 stone
execute in minecraft:overworld run fill 291 70 -11 291 71 -11 dirt
execute in minecraft:overworld run setblock 291 72 -11 grass_block
execute in minecraft:overworld run fill 291 73 -11 291 144 -11 air
execute in minecraft:overworld run fill 291 58 -10 291 69 -10 stone
execute in minecraft:overworld run fill 291 70 -10 291 71 -10 dirt
execute in minecraft:overworld run setblock 291 72 -10 coarse_dirt
execute in minecraft:overworld run fill 291 73 -10 291 144 -10 air
execute in minecraft:overworld run fill 291 58 -9 291 69 -9 stone
execute in minecraft:overworld run fill 291 70 -9 291 71 -9 dirt
execute in minecraft:overworld run setblock 291 72 -9 coarse_dirt
execute in minecraft:overworld run fill 291 73 -9 291 144 -9 air
execute in minecraft:overworld run setblock 291 73 -9 grass
execute in minecraft:overworld run fill 291 58 -8 291 69 -8 stone
execute in minecraft:overworld run fill 291 70 -8 291 71 -8 dirt
execute in minecraft:overworld run setblock 291 72 -8 grass_block
execute in minecraft:overworld run fill 291 73 -8 291 144 -8 air
execute in minecraft:overworld run fill 291 58 -7 291 69 -7 stone
execute in minecraft:overworld run fill 291 70 -7 291 71 -7 dirt
execute in minecraft:overworld run setblock 291 72 -7 grass_block
execute in minecraft:overworld run fill 291 73 -7 291 144 -7 air
execute in minecraft:overworld run fill 291 58 -6 291 69 -6 stone
execute in minecraft:overworld run fill 291 70 -6 291 71 -6 dirt
execute in minecraft:overworld run setblock 291 72 -6 coarse_dirt
execute in minecraft:overworld run fill 291 73 -6 291 144 -6 air
execute in minecraft:overworld run fill 291 58 -5 291 69 -5 stone
execute in minecraft:overworld run fill 291 70 -5 291 71 -5 dirt
execute in minecraft:overworld run setblock 291 72 -5 coarse_dirt
execute in minecraft:overworld run fill 291 73 -5 291 144 -5 air
execute in minecraft:overworld run setblock 291 73 -5 mossy_cobblestone
execute in minecraft:overworld run fill 291 58 -4 291 69 -4 stone
execute in minecraft:overworld run fill 291 70 -4 291 71 -4 dirt
execute in minecraft:overworld run setblock 291 72 -4 coarse_dirt
execute in minecraft:overworld run fill 291 73 -4 291 144 -4 air
execute in minecraft:overworld run fill 291 58 -3 291 70 -3 stone
execute in minecraft:overworld run fill 291 71 -3 291 72 -3 dirt
execute in minecraft:overworld run setblock 291 73 -3 coarse_dirt
execute in minecraft:overworld run fill 291 74 -3 291 144 -3 air
execute in minecraft:overworld run setblock 291 74 -3 mossy_cobblestone
execute in minecraft:overworld run fill 291 58 -2 291 70 -2 stone
execute in minecraft:overworld run fill 291 71 -2 291 72 -2 dirt
execute in minecraft:overworld run setblock 291 73 -2 coarse_dirt
execute in minecraft:overworld run fill 291 74 -2 291 144 -2 air
execute in minecraft:overworld run fill 291 58 -1 291 70 -1 stone
execute in minecraft:overworld run fill 291 71 -1 291 72 -1 dirt
execute in minecraft:overworld run setblock 291 73 -1 coarse_dirt
execute in minecraft:overworld run fill 291 74 -1 291 144 -1 air
execute in minecraft:overworld run fill 291 58 0 291 70 0 stone
execute in minecraft:overworld run fill 291 71 0 291 72 0 dirt
execute in minecraft:overworld run setblock 291 73 0 coarse_dirt
execute in minecraft:overworld run fill 291 74 0 291 144 0 air
execute in minecraft:overworld run fill 291 58 1 291 70 1 stone
execute in minecraft:overworld run fill 291 71 1 291 72 1 dirt
execute in minecraft:overworld run setblock 291 73 1 grass_block
execute in minecraft:overworld run fill 291 74 1 291 144 1 air
execute in minecraft:overworld run fill 291 58 2 291 69 2 stone
execute in minecraft:overworld run fill 291 70 2 291 71 2 dirt
execute in minecraft:overworld run setblock 291 72 2 grass_block
execute in minecraft:overworld run fill 291 73 2 291 144 2 air
execute in minecraft:overworld run fill 291 58 3 291 69 3 stone
execute in minecraft:overworld run fill 291 70 3 291 71 3 dirt
execute in minecraft:overworld run setblock 291 72 3 grass_block
execute in minecraft:overworld run fill 291 73 3 291 144 3 air
execute in minecraft:overworld run setblock 291 73 3 grass
execute in minecraft:overworld run fill 291 58 4 291 69 4 stone
execute in minecraft:overworld run fill 291 70 4 291 71 4 dirt
execute in minecraft:overworld run setblock 291 72 4 coarse_dirt
execute in minecraft:overworld run fill 291 73 4 291 144 4 air
execute in minecraft:overworld run fill 291 58 5 291 68 5 stone
execute in minecraft:overworld run fill 291 69 5 291 70 5 dirt
execute in minecraft:overworld run setblock 291 71 5 grass_block
execute in minecraft:overworld run fill 291 72 5 291 144 5 air
execute in minecraft:overworld run fill 291 58 6 291 68 6 stone
execute in minecraft:overworld run fill 291 69 6 291 70 6 dirt
execute in minecraft:overworld run setblock 291 71 6 coarse_dirt
execute in minecraft:overworld run fill 291 72 6 291 144 6 air
execute in minecraft:overworld run fill 291 58 7 291 67 7 stone
execute in minecraft:overworld run fill 291 68 7 291 69 7 dirt
execute in minecraft:overworld run setblock 291 70 7 coarse_dirt
execute in minecraft:overworld run fill 291 71 7 291 144 7 air
schedule function blade_gallery:random/burned/part_132 1t replace
