execute in minecraft:overworld run fill 392 58 -4 392 144 -4 air
execute in minecraft:overworld run fill 392 58 -4 392 64 -4 water
execute in minecraft:overworld run fill 392 58 -3 392 54 -3 stone
execute in minecraft:overworld run fill 392 55 -3 392 56 -3 dirt
execute in minecraft:overworld run setblock 392 57 -3 gravel
execute in minecraft:overworld run fill 392 58 -3 392 144 -3 air
execute in minecraft:overworld run fill 392 58 -3 392 64 -3 water
execute in minecraft:overworld run fill 392 58 -2 392 54 -2 stone
execute in minecraft:overworld run fill 392 55 -2 392 56 -2 dirt
execute in minecraft:overworld run setblock 392 57 -2 gravel
execute in minecraft:overworld run fill 392 58 -2 392 144 -2 air
execute in minecraft:overworld run fill 392 58 -2 392 64 -2 water
execute in minecraft:overworld run fill 392 58 -1 392 54 -1 stone
execute in minecraft:overworld run fill 392 55 -1 392 56 -1 dirt
execute in minecraft:overworld run setblock 392 57 -1 gravel
execute in minecraft:overworld run fill 392 58 -1 392 144 -1 air
execute in minecraft:overworld run fill 392 58 -1 392 64 -1 water
execute in minecraft:overworld run fill 392 58 0 392 54 0 stone
execute in minecraft:overworld run fill 392 55 0 392 56 0 dirt
execute in minecraft:overworld run setblock 392 57 0 gravel
execute in minecraft:overworld run fill 392 58 0 392 144 0 air
execute in minecraft:overworld run fill 392 58 0 392 64 0 water
execute in minecraft:overworld run fill 392 58 1 392 54 1 stone
execute in minecraft:overworld run fill 392 55 1 392 56 1 dirt
execute in minecraft:overworld run setblock 392 57 1 gravel
execute in minecraft:overworld run fill 392 58 1 392 144 1 air
execute in minecraft:overworld run fill 392 58 1 392 64 1 water
execute in minecraft:overworld run fill 392 58 2 392 55 2 stone
execute in minecraft:overworld run fill 392 56 2 392 57 2 dirt
execute in minecraft:overworld run setblock 392 58 2 gravel
execute in minecraft:overworld run fill 392 59 2 392 144 2 air
execute in minecraft:overworld run fill 392 59 2 392 64 2 water
execute in minecraft:overworld run fill 392 58 3 392 55 3 stone
execute in minecraft:overworld run fill 392 56 3 392 57 3 dirt
execute in minecraft:overworld run setblock 392 58 3 gravel
execute in minecraft:overworld run fill 392 59 3 392 144 3 air
execute in minecraft:overworld run fill 392 59 3 392 64 3 water
execute in minecraft:overworld run fill 392 58 4 392 55 4 stone
execute in minecraft:overworld run fill 392 56 4 392 57 4 dirt
execute in minecraft:overworld run setblock 392 58 4 gravel
execute in minecraft:overworld run fill 392 59 4 392 144 4 air
execute in minecraft:overworld run fill 392 59 4 392 64 4 water
execute in minecraft:overworld run fill 392 58 5 392 55 5 stone
execute in minecraft:overworld run fill 392 56 5 392 57 5 dirt
execute in minecraft:overworld run setblock 392 58 5 gravel
execute in minecraft:overworld run fill 392 59 5 392 144 5 air
execute in minecraft:overworld run fill 392 59 5 392 64 5 water
execute in minecraft:overworld run fill 392 58 6 392 55 6 stone
execute in minecraft:overworld run fill 392 56 6 392 57 6 dirt
execute in minecraft:overworld run setblock 392 58 6 gravel
execute in minecraft:overworld run fill 392 59 6 392 144 6 air
execute in minecraft:overworld run fill 392 59 6 392 64 6 water
execute in minecraft:overworld run fill 392 58 7 392 55 7 stone
execute in minecraft:overworld run fill 392 56 7 392 57 7 dirt
execute in minecraft:overworld run setblock 392 58 7 gravel
execute in minecraft:overworld run fill 392 59 7 392 144 7 air
execute in minecraft:overworld run fill 392 59 7 392 64 7 water
execute in minecraft:overworld run fill 392 58 8 392 56 8 stone
execute in minecraft:overworld run fill 392 57 8 392 58 8 dirt
execute in minecraft:overworld run setblock 392 59 8 gravel
execute in minecraft:overworld run fill 392 60 8 392 144 8 air
execute in minecraft:overworld run fill 392 60 8 392 64 8 water
execute in minecraft:overworld run fill 392 58 9 392 56 9 stone
execute in minecraft:overworld run fill 392 57 9 392 58 9 dirt
execute in minecraft:overworld run setblock 392 59 9 gravel
execute in minecraft:overworld run fill 392 60 9 392 144 9 air
execute in minecraft:overworld run fill 392 60 9 392 64 9 water
execute in minecraft:overworld run fill 392 58 10 392 56 10 stone
execute in minecraft:overworld run fill 392 57 10 392 58 10 dirt
execute in minecraft:overworld run setblock 392 59 10 gravel
execute in minecraft:overworld run fill 392 60 10 392 144 10 air
execute in minecraft:overworld run fill 392 60 10 392 64 10 water
execute in minecraft:overworld run fill 392 58 11 392 56 11 stone
execute in minecraft:overworld run fill 392 57 11 392 58 11 dirt
execute in minecraft:overworld run setblock 392 59 11 gravel
execute in minecraft:overworld run fill 392 60 11 392 144 11 air
execute in minecraft:overworld run fill 392 60 11 392 64 11 water
execute in minecraft:overworld run fill 392 58 12 392 57 12 stone
execute in minecraft:overworld run fill 392 58 12 392 59 12 dirt
execute in minecraft:overworld run setblock 392 60 12 gravel
execute in minecraft:overworld run fill 392 61 12 392 144 12 air
execute in minecraft:overworld run fill 392 61 12 392 64 12 water
execute in minecraft:overworld run fill 392 58 13 392 57 13 stone
execute in minecraft:overworld run fill 392 58 13 392 59 13 dirt
execute in minecraft:overworld run setblock 392 60 13 gravel
execute in minecraft:overworld run fill 392 61 13 392 144 13 air
execute in minecraft:overworld run fill 392 61 13 392 64 13 water
execute in minecraft:overworld run fill 392 58 14 392 57 14 stone
execute in minecraft:overworld run fill 392 58 14 392 59 14 dirt
execute in minecraft:overworld run setblock 392 60 14 gravel
execute in minecraft:overworld run fill 392 61 14 392 144 14 air
execute in minecraft:overworld run fill 392 61 14 392 64 14 water
execute in minecraft:overworld run fill 392 58 15 392 58 15 stone
execute in minecraft:overworld run fill 392 59 15 392 60 15 dirt
execute in minecraft:overworld run setblock 392 61 15 gravel
execute in minecraft:overworld run fill 392 62 15 392 144 15 air
execute in minecraft:overworld run fill 392 62 15 392 64 15 water
execute in minecraft:overworld run fill 392 58 16 392 58 16 stone
execute in minecraft:overworld run fill 392 59 16 392 60 16 dirt
execute in minecraft:overworld run setblock 392 61 16 gravel
execute in minecraft:overworld run fill 392 62 16 392 144 16 air
execute in minecraft:overworld run fill 392 62 16 392 64 16 water
execute in minecraft:overworld run fill 392 58 17 392 58 17 stone
execute in minecraft:overworld run fill 392 59 17 392 60 17 dirt
execute in minecraft:overworld run setblock 392 61 17 gravel
execute in minecraft:overworld run fill 392 62 17 392 144 17 air
execute in minecraft:overworld run fill 392 62 17 392 64 17 water
execute in minecraft:overworld run fill 392 58 18 392 58 18 stone
execute in minecraft:overworld run fill 392 59 18 392 60 18 dirt
execute in minecraft:overworld run setblock 392 61 18 gravel
execute in minecraft:overworld run fill 392 62 18 392 144 18 air
execute in minecraft:overworld run fill 392 62 18 392 64 18 water
execute in minecraft:overworld run fill 392 58 19 392 58 19 stone
execute in minecraft:overworld run fill 392 59 19 392 60 19 dirt
execute in minecraft:overworld run setblock 392 61 19 gravel
execute in minecraft:overworld run fill 392 62 19 392 144 19 air
execute in minecraft:overworld run fill 392 62 19 392 64 19 water
execute in minecraft:overworld run fill 392 58 20 392 58 20 stone
execute in minecraft:overworld run fill 392 59 20 392 60 20 dirt
execute in minecraft:overworld run setblock 392 61 20 gravel
execute in minecraft:overworld run fill 392 62 20 392 144 20 air
execute in minecraft:overworld run fill 392 62 20 392 64 20 water
execute in minecraft:overworld run fill 392 58 21 392 58 21 stone
execute in minecraft:overworld run fill 392 59 21 392 60 21 dirt
execute in minecraft:overworld run setblock 392 61 21 gravel
execute in minecraft:overworld run fill 392 62 21 392 144 21 air
execute in minecraft:overworld run fill 392 62 21 392 64 21 water
execute in minecraft:overworld run fill 392 58 22 392 58 22 stone
execute in minecraft:overworld run fill 392 59 22 392 60 22 dirt
execute in minecraft:overworld run setblock 392 61 22 gravel
execute in minecraft:overworld run fill 392 62 22 392 144 22 air
execute in minecraft:overworld run fill 392 62 22 392 64 22 water
execute in minecraft:overworld run fill 392 58 23 392 58 23 stone
execute in minecraft:overworld run fill 392 59 23 392 60 23 dirt
execute in minecraft:overworld run setblock 392 61 23 gravel
execute in minecraft:overworld run fill 392 62 23 392 144 23 air
execute in minecraft:overworld run fill 392 62 23 392 64 23 water
execute in minecraft:overworld run fill 392 58 24 392 58 24 stone
execute in minecraft:overworld run fill 392 59 24 392 60 24 dirt
execute in minecraft:overworld run setblock 392 61 24 gravel
execute in minecraft:overworld run fill 392 62 24 392 144 24 air
execute in minecraft:overworld run fill 392 62 24 392 64 24 water
execute in minecraft:overworld run fill 392 58 25 392 58 25 stone
execute in minecraft:overworld run fill 392 59 25 392 60 25 dirt
execute in minecraft:overworld run setblock 392 61 25 gravel
execute in minecraft:overworld run fill 392 62 25 392 144 25 air
execute in minecraft:overworld run fill 392 62 25 392 64 25 water
execute in minecraft:overworld run fill 392 58 26 392 58 26 stone
execute in minecraft:overworld run fill 392 59 26 392 60 26 dirt
execute in minecraft:overworld run setblock 392 61 26 gravel
execute in minecraft:overworld run fill 392 62 26 392 144 26 air
execute in minecraft:overworld run fill 392 62 26 392 64 26 water
execute in minecraft:overworld run fill 392 58 27 392 57 27 stone
execute in minecraft:overworld run fill 392 58 27 392 59 27 dirt
execute in minecraft:overworld run setblock 392 60 27 gravel
execute in minecraft:overworld run fill 392 61 27 392 144 27 air
execute in minecraft:overworld run fill 392 61 27 392 64 27 water
execute in minecraft:overworld run fill 392 58 28 392 57 28 stone
execute in minecraft:overworld run fill 392 58 28 392 59 28 dirt
execute in minecraft:overworld run setblock 392 60 28 gravel
execute in minecraft:overworld run fill 392 61 28 392 144 28 air
execute in minecraft:overworld run fill 392 61 28 392 64 28 water
execute in minecraft:overworld run fill 392 58 29 392 57 29 stone
execute in minecraft:overworld run fill 392 58 29 392 59 29 dirt
execute in minecraft:overworld run setblock 392 60 29 gravel
execute in minecraft:overworld run fill 392 61 29 392 144 29 air
execute in minecraft:overworld run fill 392 61 29 392 64 29 water
execute in minecraft:overworld run fill 392 58 30 392 57 30 stone
execute in minecraft:overworld run fill 392 58 30 392 59 30 dirt
execute in minecraft:overworld run setblock 392 60 30 gravel
execute in minecraft:overworld run fill 392 61 30 392 144 30 air
execute in minecraft:overworld run fill 392 61 30 392 64 30 water
execute in minecraft:overworld run fill 392 58 31 392 57 31 stone
execute in minecraft:overworld run fill 392 58 31 392 59 31 dirt
execute in minecraft:overworld run setblock 392 60 31 gravel
execute in minecraft:overworld run fill 392 61 31 392 144 31 air
execute in minecraft:overworld run fill 392 61 31 392 64 31 water
execute in minecraft:overworld run fill 392 58 32 392 57 32 stone
execute in minecraft:overworld run fill 392 58 32 392 59 32 dirt
execute in minecraft:overworld run setblock 392 60 32 gravel
execute in minecraft:overworld run fill 392 61 32 392 144 32 air
execute in minecraft:overworld run fill 392 61 32 392 64 32 water
execute in minecraft:overworld run fill 392 58 33 392 58 33 stone
execute in minecraft:overworld run fill 392 59 33 392 60 33 dirt
execute in minecraft:overworld run setblock 392 61 33 gravel
execute in minecraft:overworld run fill 392 62 33 392 144 33 air
execute in minecraft:overworld run fill 392 62 33 392 64 33 water
execute in minecraft:overworld run fill 392 58 34 392 58 34 stone
execute in minecraft:overworld run fill 392 59 34 392 60 34 dirt
execute in minecraft:overworld run setblock 392 61 34 gravel
execute in minecraft:overworld run fill 392 62 34 392 144 34 air
execute in minecraft:overworld run fill 392 62 34 392 64 34 water
execute in minecraft:overworld run fill 392 58 35 392 58 35 stone
execute in minecraft:overworld run fill 392 59 35 392 60 35 dirt
execute in minecraft:overworld run setblock 392 61 35 gravel
execute in minecraft:overworld run fill 392 62 35 392 144 35 air
execute in minecraft:overworld run fill 392 62 35 392 64 35 water
execute in minecraft:overworld run fill 392 58 36 392 59 36 stone
execute in minecraft:overworld run fill 392 60 36 392 61 36 dirt
execute in minecraft:overworld run setblock 392 62 36 gravel
execute in minecraft:overworld run fill 392 63 36 392 144 36 air
execute in minecraft:overworld run fill 392 63 36 392 64 36 water
execute in minecraft:overworld run fill 392 58 37 392 59 37 stone
execute in minecraft:overworld run fill 392 60 37 392 61 37 dirt
execute in minecraft:overworld run setblock 392 62 37 gravel
execute in minecraft:overworld run fill 392 63 37 392 144 37 air
execute in minecraft:overworld run fill 392 63 37 392 64 37 water
execute in minecraft:overworld run fill 392 58 38 392 60 38 stone
execute in minecraft:overworld run fill 392 61 38 392 62 38 dirt
execute in minecraft:overworld run setblock 392 63 38 gravel
execute in minecraft:overworld run fill 392 64 38 392 144 38 air
execute in minecraft:overworld run fill 392 64 38 392 64 38 water
execute in minecraft:overworld run fill 392 58 39 392 61 39 stone
execute in minecraft:overworld run fill 392 62 39 392 63 39 dirt
execute in minecraft:overworld run setblock 392 64 39 coarse_dirt
execute in minecraft:overworld run fill 392 65 39 392 144 39 air
execute in minecraft:overworld run fill 392 58 40 392 61 40 stone
execute in minecraft:overworld run fill 392 62 40 392 63 40 dirt
execute in minecraft:overworld run setblock 392 64 40 grass_block
execute in minecraft:overworld run fill 392 65 40 392 144 40 air
execute in minecraft:overworld run fill 392 58 41 392 62 41 stone
execute in minecraft:overworld run fill 392 63 41 392 64 41 dirt
execute in minecraft:overworld run setblock 392 65 41 coarse_dirt
execute in minecraft:overworld run fill 392 66 41 392 144 41 air
execute in minecraft:overworld run fill 392 58 42 392 62 42 stone
execute in minecraft:overworld run fill 392 63 42 392 64 42 dirt
execute in minecraft:overworld run setblock 392 65 42 coarse_dirt
execute in minecraft:overworld run fill 392 66 42 392 144 42 air
execute in minecraft:overworld run fill 392 58 43 392 62 43 stone
execute in minecraft:overworld run fill 392 63 43 392 64 43 dirt
execute in minecraft:overworld run setblock 392 65 43 coarse_dirt
execute in minecraft:overworld run fill 392 66 43 392 144 43 air
execute in minecraft:overworld run fill 392 58 44 392 62 44 stone
execute in minecraft:overworld run fill 392 63 44 392 64 44 dirt
execute in minecraft:overworld run setblock 392 65 44 coarse_dirt
execute in minecraft:overworld run fill 392 66 44 392 144 44 air
execute in minecraft:overworld run fill 392 58 45 392 62 45 stone
execute in minecraft:overworld run fill 392 63 45 392 64 45 dirt
execute in minecraft:overworld run setblock 392 65 45 coarse_dirt
execute in minecraft:overworld run fill 392 66 45 392 144 45 air
execute in minecraft:overworld run fill 392 58 46 392 62 46 stone
execute in minecraft:overworld run fill 392 63 46 392 64 46 dirt
execute in minecraft:overworld run setblock 392 65 46 coarse_dirt
execute in minecraft:overworld run fill 392 66 46 392 144 46 air
execute in minecraft:overworld run fill 392 58 47 392 62 47 stone
execute in minecraft:overworld run fill 392 63 47 392 64 47 dirt
execute in minecraft:overworld run setblock 392 65 47 grass_block
execute in minecraft:overworld run fill 392 66 47 392 144 47 air
execute in minecraft:overworld run fill 393 58 -48 393 61 -48 stone
execute in minecraft:overworld run fill 393 62 -48 393 63 -48 dirt
execute in minecraft:overworld run setblock 393 64 -48 grass_block
execute in minecraft:overworld run fill 393 65 -48 393 144 -48 air
execute in minecraft:overworld run fill 393 58 -47 393 62 -47 stone
execute in minecraft:overworld run fill 393 63 -47 393 64 -47 dirt
execute in minecraft:overworld run setblock 393 65 -47 coarse_dirt
execute in minecraft:overworld run fill 393 66 -47 393 144 -47 air
schedule function blade_gallery:random/battlefield/part_89 1t replace
