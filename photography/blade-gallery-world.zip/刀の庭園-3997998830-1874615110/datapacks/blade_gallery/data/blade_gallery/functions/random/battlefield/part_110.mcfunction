execute in minecraft:overworld run fill 405 68 25 405 69 25 dirt
execute in minecraft:overworld run setblock 405 70 25 grass_block
execute in minecraft:overworld run fill 405 71 25 405 144 25 air
execute in minecraft:overworld run fill 405 58 26 405 67 26 stone
execute in minecraft:overworld run fill 405 68 26 405 69 26 dirt
execute in minecraft:overworld run setblock 405 70 26 coarse_dirt
execute in minecraft:overworld run fill 405 71 26 405 144 26 air
execute in minecraft:overworld run fill 405 58 27 405 67 27 stone
execute in minecraft:overworld run fill 405 68 27 405 69 27 dirt
execute in minecraft:overworld run setblock 405 70 27 grass_block
execute in minecraft:overworld run fill 405 71 27 405 144 27 air
execute in minecraft:overworld run fill 405 58 28 405 67 28 stone
execute in minecraft:overworld run fill 405 68 28 405 69 28 dirt
execute in minecraft:overworld run setblock 405 70 28 grass_block
execute in minecraft:overworld run fill 405 71 28 405 144 28 air
execute in minecraft:overworld run setblock 405 71 28 grass
execute in minecraft:overworld run fill 405 58 29 405 67 29 stone
execute in minecraft:overworld run fill 405 68 29 405 69 29 dirt
execute in minecraft:overworld run setblock 405 70 29 coarse_dirt
execute in minecraft:overworld run fill 405 71 29 405 144 29 air
execute in minecraft:overworld run fill 405 58 30 405 67 30 stone
execute in minecraft:overworld run fill 405 68 30 405 69 30 dirt
execute in minecraft:overworld run setblock 405 70 30 coarse_dirt
execute in minecraft:overworld run fill 405 71 30 405 144 30 air
execute in minecraft:overworld run fill 405 58 31 405 67 31 stone
execute in minecraft:overworld run fill 405 68 31 405 69 31 dirt
execute in minecraft:overworld run setblock 405 70 31 grass_block
execute in minecraft:overworld run fill 405 71 31 405 144 31 air
execute in minecraft:overworld run fill 405 58 32 405 67 32 stone
execute in minecraft:overworld run fill 405 68 32 405 69 32 dirt
execute in minecraft:overworld run setblock 405 70 32 grass_block
execute in minecraft:overworld run fill 405 71 32 405 144 32 air
execute in minecraft:overworld run fill 405 58 33 405 66 33 stone
execute in minecraft:overworld run fill 405 67 33 405 68 33 dirt
execute in minecraft:overworld run setblock 405 69 33 coarse_dirt
execute in minecraft:overworld run fill 405 70 33 405 144 33 air
execute in minecraft:overworld run fill 405 58 34 405 66 34 stone
execute in minecraft:overworld run fill 405 67 34 405 68 34 dirt
execute in minecraft:overworld run setblock 405 69 34 coarse_dirt
execute in minecraft:overworld run fill 405 70 34 405 144 34 air
execute in minecraft:overworld run fill 405 58 35 405 66 35 stone
execute in minecraft:overworld run fill 405 67 35 405 68 35 dirt
execute in minecraft:overworld run setblock 405 69 35 grass_block
execute in minecraft:overworld run fill 405 70 35 405 144 35 air
execute in minecraft:overworld run fill 405 58 36 405 66 36 stone
execute in minecraft:overworld run fill 405 67 36 405 68 36 dirt
execute in minecraft:overworld run setblock 405 69 36 grass_block
execute in minecraft:overworld run fill 405 70 36 405 144 36 air
execute in minecraft:overworld run fill 405 58 37 405 66 37 stone
execute in minecraft:overworld run fill 405 67 37 405 68 37 dirt
execute in minecraft:overworld run setblock 405 69 37 grass_block
execute in minecraft:overworld run fill 405 70 37 405 144 37 air
execute in minecraft:overworld run setblock 405 70 37 grass
execute in minecraft:overworld run fill 405 58 38 405 66 38 stone
execute in minecraft:overworld run fill 405 67 38 405 68 38 dirt
execute in minecraft:overworld run setblock 405 69 38 grass_block
execute in minecraft:overworld run fill 405 70 38 405 144 38 air
execute in minecraft:overworld run fill 405 58 39 405 66 39 stone
execute in minecraft:overworld run fill 405 67 39 405 68 39 dirt
execute in minecraft:overworld run setblock 405 69 39 grass_block
execute in minecraft:overworld run fill 405 70 39 405 144 39 air
execute in minecraft:overworld run fill 405 58 40 405 65 40 stone
execute in minecraft:overworld run fill 405 66 40 405 67 40 dirt
execute in minecraft:overworld run setblock 405 68 40 coarse_dirt
execute in minecraft:overworld run fill 405 69 40 405 144 40 air
execute in minecraft:overworld run fill 405 58 41 405 65 41 stone
execute in minecraft:overworld run fill 405 66 41 405 67 41 dirt
execute in minecraft:overworld run setblock 405 68 41 grass_block
execute in minecraft:overworld run fill 405 69 41 405 144 41 air
execute in minecraft:overworld run fill 405 58 42 405 65 42 stone
execute in minecraft:overworld run fill 405 66 42 405 67 42 dirt
execute in minecraft:overworld run setblock 405 68 42 coarse_dirt
execute in minecraft:overworld run fill 405 69 42 405 144 42 air
execute in minecraft:overworld run fill 405 58 43 405 64 43 stone
execute in minecraft:overworld run fill 405 65 43 405 66 43 dirt
execute in minecraft:overworld run setblock 405 67 43 coarse_dirt
execute in minecraft:overworld run fill 405 68 43 405 144 43 air
execute in minecraft:overworld run fill 405 58 44 405 64 44 stone
execute in minecraft:overworld run fill 405 65 44 405 66 44 dirt
execute in minecraft:overworld run setblock 405 67 44 coarse_dirt
execute in minecraft:overworld run fill 405 68 44 405 144 44 air
execute in minecraft:overworld run fill 405 58 45 405 63 45 stone
execute in minecraft:overworld run fill 405 64 45 405 65 45 dirt
execute in minecraft:overworld run setblock 405 66 45 coarse_dirt
execute in minecraft:overworld run fill 405 67 45 405 144 45 air
execute in minecraft:overworld run fill 405 58 46 405 62 46 stone
execute in minecraft:overworld run fill 405 63 46 405 64 46 dirt
execute in minecraft:overworld run setblock 405 65 46 coarse_dirt
execute in minecraft:overworld run fill 405 66 46 405 144 46 air
execute in minecraft:overworld run fill 405 58 47 405 62 47 stone
execute in minecraft:overworld run fill 405 63 47 405 64 47 dirt
execute in minecraft:overworld run setblock 405 65 47 grass_block
execute in minecraft:overworld run fill 405 66 47 405 144 47 air
execute in minecraft:overworld run fill 406 58 -48 406 61 -48 stone
execute in minecraft:overworld run fill 406 62 -48 406 63 -48 dirt
execute in minecraft:overworld run setblock 406 64 -48 coarse_dirt
execute in minecraft:overworld run fill 406 65 -48 406 144 -48 air
execute in minecraft:overworld run fill 406 58 -47 406 63 -47 stone
execute in minecraft:overworld run fill 406 64 -47 406 65 -47 dirt
execute in minecraft:overworld run setblock 406 66 -47 coarse_dirt
execute in minecraft:overworld run fill 406 67 -47 406 144 -47 air
execute in minecraft:overworld run fill 406 58 -46 406 64 -46 stone
execute in minecraft:overworld run fill 406 65 -46 406 66 -46 dirt
execute in minecraft:overworld run setblock 406 67 -46 coarse_dirt
execute in minecraft:overworld run fill 406 68 -46 406 144 -46 air
execute in minecraft:overworld run fill 406 58 -45 406 66 -45 stone
execute in minecraft:overworld run fill 406 67 -45 406 68 -45 dirt
execute in minecraft:overworld run setblock 406 69 -45 grass_block
execute in minecraft:overworld run fill 406 70 -45 406 144 -45 air
execute in minecraft:overworld run fill 406 58 -44 406 67 -44 stone
execute in minecraft:overworld run fill 406 68 -44 406 69 -44 dirt
execute in minecraft:overworld run setblock 406 70 -44 coarse_dirt
execute in minecraft:overworld run fill 406 71 -44 406 144 -44 air
execute in minecraft:overworld run fill 406 58 -43 406 69 -43 stone
execute in minecraft:overworld run fill 406 70 -43 406 71 -43 dirt
execute in minecraft:overworld run setblock 406 72 -43 coarse_dirt
execute in minecraft:overworld run fill 406 73 -43 406 144 -43 air
execute in minecraft:overworld run fill 406 58 -42 406 70 -42 stone
execute in minecraft:overworld run fill 406 71 -42 406 72 -42 dirt
execute in minecraft:overworld run setblock 406 73 -42 coarse_dirt
execute in minecraft:overworld run fill 406 74 -42 406 144 -42 air
execute in minecraft:overworld run fill 406 58 -41 406 72 -41 stone
execute in minecraft:overworld run fill 406 73 -41 406 74 -41 dirt
execute in minecraft:overworld run setblock 406 75 -41 grass_block
execute in minecraft:overworld run fill 406 76 -41 406 144 -41 air
execute in minecraft:overworld run fill 406 58 -40 406 73 -40 stone
execute in minecraft:overworld run fill 406 74 -40 406 75 -40 dirt
execute in minecraft:overworld run setblock 406 76 -40 grass_block
execute in minecraft:overworld run fill 406 77 -40 406 144 -40 air
execute in minecraft:overworld run fill 406 58 -39 406 74 -39 stone
execute in minecraft:overworld run fill 406 75 -39 406 76 -39 dirt
execute in minecraft:overworld run setblock 406 77 -39 grass_block
execute in minecraft:overworld run fill 406 78 -39 406 144 -39 air
execute in minecraft:overworld run fill 406 58 -38 406 76 -38 stone
execute in minecraft:overworld run fill 406 77 -38 406 78 -38 dirt
execute in minecraft:overworld run setblock 406 79 -38 coarse_dirt
execute in minecraft:overworld run fill 406 80 -38 406 144 -38 air
execute in minecraft:overworld run fill 406 58 -37 406 75 -37 stone
execute in minecraft:overworld run fill 406 76 -37 406 77 -37 dirt
execute in minecraft:overworld run setblock 406 78 -37 coarse_dirt
execute in minecraft:overworld run fill 406 79 -37 406 144 -37 air
execute in minecraft:overworld run fill 406 58 -36 406 75 -36 stone
execute in minecraft:overworld run fill 406 76 -36 406 77 -36 dirt
execute in minecraft:overworld run setblock 406 78 -36 grass_block
execute in minecraft:overworld run fill 406 79 -36 406 144 -36 air
execute in minecraft:overworld run fill 406 58 -35 406 75 -35 stone
execute in minecraft:overworld run fill 406 76 -35 406 77 -35 dirt
execute in minecraft:overworld run setblock 406 78 -35 coarse_dirt
execute in minecraft:overworld run fill 406 79 -35 406 144 -35 air
execute in minecraft:overworld run fill 406 58 -34 406 74 -34 stone
execute in minecraft:overworld run fill 406 75 -34 406 76 -34 dirt
execute in minecraft:overworld run setblock 406 77 -34 coarse_dirt
execute in minecraft:overworld run fill 406 78 -34 406 144 -34 air
execute in minecraft:overworld run fill 406 58 -33 406 74 -33 stone
execute in minecraft:overworld run fill 406 75 -33 406 76 -33 dirt
execute in minecraft:overworld run setblock 406 77 -33 grass_block
execute in minecraft:overworld run fill 406 78 -33 406 144 -33 air
execute in minecraft:overworld run fill 406 58 -32 406 74 -32 stone
execute in minecraft:overworld run fill 406 75 -32 406 76 -32 dirt
execute in minecraft:overworld run setblock 406 77 -32 grass_block
execute in minecraft:overworld run fill 406 78 -32 406 144 -32 air
execute in minecraft:overworld run fill 406 58 -31 406 73 -31 stone
execute in minecraft:overworld run fill 406 74 -31 406 75 -31 dirt
execute in minecraft:overworld run setblock 406 76 -31 coarse_dirt
execute in minecraft:overworld run fill 406 77 -31 406 144 -31 air
execute in minecraft:overworld run fill 406 58 -30 406 73 -30 stone
execute in minecraft:overworld run fill 406 74 -30 406 75 -30 dirt
execute in minecraft:overworld run setblock 406 76 -30 coarse_dirt
execute in minecraft:overworld run fill 406 77 -30 406 144 -30 air
execute in minecraft:overworld run fill 406 58 -29 406 73 -29 stone
execute in minecraft:overworld run fill 406 74 -29 406 75 -29 dirt
execute in minecraft:overworld run setblock 406 76 -29 grass_block
execute in minecraft:overworld run fill 406 77 -29 406 144 -29 air
execute in minecraft:overworld run fill 406 58 -28 406 72 -28 stone
execute in minecraft:overworld run fill 406 73 -28 406 74 -28 dirt
execute in minecraft:overworld run setblock 406 75 -28 coarse_dirt
execute in minecraft:overworld run fill 406 76 -28 406 144 -28 air
execute in minecraft:overworld run fill 406 58 -27 406 72 -27 stone
execute in minecraft:overworld run fill 406 73 -27 406 74 -27 dirt
execute in minecraft:overworld run setblock 406 75 -27 grass_block
execute in minecraft:overworld run fill 406 76 -27 406 144 -27 air
execute in minecraft:overworld run fill 406 58 -26 406 72 -26 stone
execute in minecraft:overworld run fill 406 73 -26 406 74 -26 dirt
execute in minecraft:overworld run setblock 406 75 -26 coarse_dirt
execute in minecraft:overworld run fill 406 76 -26 406 144 -26 air
execute in minecraft:overworld run setblock 406 76 -26 grass
execute in minecraft:overworld run fill 406 58 -25 406 71 -25 stone
execute in minecraft:overworld run fill 406 72 -25 406 73 -25 dirt
execute in minecraft:overworld run setblock 406 74 -25 coarse_dirt
execute in minecraft:overworld run fill 406 75 -25 406 144 -25 air
execute in minecraft:overworld run setblock 406 75 -25 grass
execute in minecraft:overworld run fill 406 58 -24 406 71 -24 stone
execute in minecraft:overworld run fill 406 72 -24 406 73 -24 dirt
execute in minecraft:overworld run setblock 406 74 -24 coarse_dirt
execute in minecraft:overworld run fill 406 75 -24 406 144 -24 air
execute in minecraft:overworld run fill 406 58 -23 406 71 -23 stone
execute in minecraft:overworld run fill 406 72 -23 406 73 -23 dirt
execute in minecraft:overworld run setblock 406 74 -23 coarse_dirt
execute in minecraft:overworld run fill 406 75 -23 406 144 -23 air
execute in minecraft:overworld run setblock 406 75 -23 grass
execute in minecraft:overworld run fill 406 58 -22 406 70 -22 stone
execute in minecraft:overworld run fill 406 71 -22 406 72 -22 dirt
execute in minecraft:overworld run setblock 406 73 -22 coarse_dirt
execute in minecraft:overworld run fill 406 74 -22 406 144 -22 air
execute in minecraft:overworld run fill 406 58 -21 406 70 -21 stone
execute in minecraft:overworld run fill 406 71 -21 406 72 -21 dirt
execute in minecraft:overworld run setblock 406 73 -21 coarse_dirt
execute in minecraft:overworld run fill 406 74 -21 406 144 -21 air
execute in minecraft:overworld run setblock 406 74 -21 grass
execute in minecraft:overworld run fill 406 58 -20 406 70 -20 stone
execute in minecraft:overworld run fill 406 71 -20 406 72 -20 dirt
execute in minecraft:overworld run setblock 406 73 -20 coarse_dirt
execute in minecraft:overworld run fill 406 74 -20 406 144 -20 air
execute in minecraft:overworld run fill 406 58 -19 406 69 -19 stone
execute in minecraft:overworld run fill 406 70 -19 406 71 -19 dirt
execute in minecraft:overworld run setblock 406 72 -19 coarse_dirt
execute in minecraft:overworld run fill 406 73 -19 406 144 -19 air
execute in minecraft:overworld run fill 406 58 -18 406 69 -18 stone
execute in minecraft:overworld run fill 406 70 -18 406 71 -18 dirt
execute in minecraft:overworld run setblock 406 72 -18 coarse_dirt
execute in minecraft:overworld run fill 406 73 -18 406 144 -18 air
execute in minecraft:overworld run fill 406 58 -17 406 68 -17 stone
execute in minecraft:overworld run fill 406 69 -17 406 70 -17 dirt
execute in minecraft:overworld run setblock 406 71 -17 grass_block
execute in minecraft:overworld run fill 406 72 -17 406 144 -17 air
execute in minecraft:overworld run fill 406 58 -16 406 67 -16 stone
execute in minecraft:overworld run fill 406 68 -16 406 69 -16 dirt
execute in minecraft:overworld run setblock 406 70 -16 coarse_dirt
execute in minecraft:overworld run fill 406 71 -16 406 144 -16 air
execute in minecraft:overworld run setblock 406 71 -16 grass
execute in minecraft:overworld run fill 406 58 -15 406 67 -15 stone
execute in minecraft:overworld run fill 406 68 -15 406 69 -15 dirt
execute in minecraft:overworld run setblock 406 70 -15 grass_block
execute in minecraft:overworld run fill 406 71 -15 406 144 -15 air
execute in minecraft:overworld run fill 406 58 -14 406 66 -14 stone
execute in minecraft:overworld run fill 406 67 -14 406 68 -14 dirt
execute in minecraft:overworld run setblock 406 69 -14 coarse_dirt
execute in minecraft:overworld run fill 406 70 -14 406 144 -14 air
execute in minecraft:overworld run fill 406 58 -13 406 65 -13 stone
execute in minecraft:overworld run fill 406 66 -13 406 67 -13 dirt
execute in minecraft:overworld run setblock 406 68 -13 grass_block
execute in minecraft:overworld run fill 406 69 -13 406 144 -13 air
execute in minecraft:overworld run fill 406 58 -12 406 64 -12 stone
execute in minecraft:overworld run fill 406 65 -12 406 66 -12 dirt
execute in minecraft:overworld run setblock 406 67 -12 coarse_dirt
execute in minecraft:overworld run fill 406 68 -12 406 144 -12 air
execute in minecraft:overworld run fill 406 58 -11 406 63 -11 stone
execute in minecraft:overworld run fill 406 64 -11 406 65 -11 dirt
execute in minecraft:overworld run setblock 406 66 -11 coarse_dirt
execute in minecraft:overworld run fill 406 67 -11 406 144 -11 air
execute in minecraft:overworld run fill 406 58 -10 406 63 -10 stone
execute in minecraft:overworld run fill 406 64 -10 406 65 -10 dirt
execute in minecraft:overworld run setblock 406 66 -10 coarse_dirt
execute in minecraft:overworld run fill 406 67 -10 406 144 -10 air
execute in minecraft:overworld run fill 406 58 -9 406 63 -9 stone
execute in minecraft:overworld run fill 406 64 -9 406 65 -9 dirt
schedule function blade_gallery:random/battlefield/part_111 1t replace
