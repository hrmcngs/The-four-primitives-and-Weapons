execute in minecraft:overworld run fill 273 64 -3 273 65 -3 dirt
execute in minecraft:overworld run setblock 273 66 -3 coarse_dirt
execute in minecraft:overworld run fill 273 67 -3 273 144 -3 air
execute in minecraft:overworld run fill 273 58 -2 273 63 -2 stone
execute in minecraft:overworld run fill 273 64 -2 273 65 -2 dirt
execute in minecraft:overworld run setblock 273 66 -2 coarse_dirt
execute in minecraft:overworld run fill 273 67 -2 273 144 -2 air
execute in minecraft:overworld run fill 273 58 -1 273 62 -1 stone
execute in minecraft:overworld run fill 273 63 -1 273 64 -1 dirt
execute in minecraft:overworld run setblock 273 65 -1 coarse_dirt
execute in minecraft:overworld run fill 273 66 -1 273 144 -1 air
execute in minecraft:overworld run setblock 273 66 -1 grass
execute in minecraft:overworld run fill 273 58 0 273 62 0 stone
execute in minecraft:overworld run fill 273 63 0 273 64 0 dirt
execute in minecraft:overworld run setblock 273 65 0 grass_block
execute in minecraft:overworld run fill 273 66 0 273 144 0 air
execute in minecraft:overworld run fill 273 58 1 273 62 1 stone
execute in minecraft:overworld run fill 273 63 1 273 64 1 dirt
execute in minecraft:overworld run setblock 273 65 1 grass_block
execute in minecraft:overworld run fill 273 66 1 273 144 1 air
execute in minecraft:overworld run setblock 273 66 1 mossy_cobblestone
execute in minecraft:overworld run fill 273 58 2 273 62 2 stone
execute in minecraft:overworld run fill 273 63 2 273 64 2 dirt
execute in minecraft:overworld run setblock 273 65 2 coarse_dirt
execute in minecraft:overworld run fill 273 66 2 273 144 2 air
execute in minecraft:overworld run fill 273 58 3 273 61 3 stone
execute in minecraft:overworld run fill 273 62 3 273 63 3 dirt
execute in minecraft:overworld run setblock 273 64 3 coarse_dirt
execute in minecraft:overworld run fill 273 65 3 273 144 3 air
execute in minecraft:overworld run fill 273 58 4 273 61 4 stone
execute in minecraft:overworld run fill 273 62 4 273 63 4 dirt
execute in minecraft:overworld run setblock 273 64 4 coarse_dirt
execute in minecraft:overworld run fill 273 65 4 273 144 4 air
execute in minecraft:overworld run fill 273 58 5 273 61 5 stone
execute in minecraft:overworld run fill 273 62 5 273 63 5 dirt
execute in minecraft:overworld run setblock 273 64 5 coarse_dirt
execute in minecraft:overworld run fill 273 65 5 273 144 5 air
execute in minecraft:overworld run fill 273 58 6 273 61 6 stone
execute in minecraft:overworld run fill 273 62 6 273 63 6 dirt
execute in minecraft:overworld run setblock 273 64 6 coarse_dirt
execute in minecraft:overworld run fill 273 65 6 273 144 6 air
execute in minecraft:overworld run fill 273 58 7 273 61 7 stone
execute in minecraft:overworld run fill 273 62 7 273 63 7 dirt
execute in minecraft:overworld run setblock 273 64 7 coarse_dirt
execute in minecraft:overworld run fill 273 65 7 273 144 7 air
execute in minecraft:overworld run fill 273 58 8 273 61 8 stone
execute in minecraft:overworld run fill 273 62 8 273 63 8 dirt
execute in minecraft:overworld run setblock 273 64 8 coarse_dirt
execute in minecraft:overworld run fill 273 65 8 273 144 8 air
execute in minecraft:overworld run fill 273 58 9 273 60 9 stone
execute in minecraft:overworld run fill 273 61 9 273 62 9 dirt
execute in minecraft:overworld run setblock 273 63 9 gravel
execute in minecraft:overworld run fill 273 64 9 273 144 9 air
execute in minecraft:overworld run fill 273 64 9 273 64 9 water
execute in minecraft:overworld run fill 273 58 10 273 60 10 stone
execute in minecraft:overworld run fill 273 61 10 273 62 10 dirt
execute in minecraft:overworld run setblock 273 63 10 gravel
execute in minecraft:overworld run fill 273 64 10 273 144 10 air
execute in minecraft:overworld run fill 273 64 10 273 64 10 water
execute in minecraft:overworld run fill 273 58 11 273 60 11 stone
execute in minecraft:overworld run fill 273 61 11 273 62 11 dirt
execute in minecraft:overworld run setblock 273 63 11 gravel
execute in minecraft:overworld run fill 273 64 11 273 144 11 air
execute in minecraft:overworld run fill 273 64 11 273 64 11 water
execute in minecraft:overworld run fill 273 58 12 273 60 12 stone
execute in minecraft:overworld run fill 273 61 12 273 62 12 dirt
execute in minecraft:overworld run setblock 273 63 12 gravel
execute in minecraft:overworld run fill 273 64 12 273 144 12 air
execute in minecraft:overworld run fill 273 64 12 273 64 12 water
execute in minecraft:overworld run fill 273 58 13 273 60 13 stone
execute in minecraft:overworld run fill 273 61 13 273 62 13 dirt
execute in minecraft:overworld run setblock 273 63 13 gravel
execute in minecraft:overworld run fill 273 64 13 273 144 13 air
execute in minecraft:overworld run fill 273 64 13 273 64 13 water
execute in minecraft:overworld run fill 273 58 14 273 59 14 stone
execute in minecraft:overworld run fill 273 60 14 273 61 14 dirt
execute in minecraft:overworld run setblock 273 62 14 gravel
execute in minecraft:overworld run fill 273 63 14 273 144 14 air
execute in minecraft:overworld run fill 273 63 14 273 64 14 water
execute in minecraft:overworld run fill 273 58 15 273 59 15 stone
execute in minecraft:overworld run fill 273 60 15 273 61 15 dirt
execute in minecraft:overworld run setblock 273 62 15 gravel
execute in minecraft:overworld run fill 273 63 15 273 144 15 air
execute in minecraft:overworld run fill 273 63 15 273 64 15 water
execute in minecraft:overworld run fill 273 58 16 273 59 16 stone
execute in minecraft:overworld run fill 273 60 16 273 61 16 dirt
execute in minecraft:overworld run setblock 273 62 16 gravel
execute in minecraft:overworld run fill 273 63 16 273 144 16 air
execute in minecraft:overworld run fill 273 63 16 273 64 16 water
execute in minecraft:overworld run fill 273 58 17 273 59 17 stone
execute in minecraft:overworld run fill 273 60 17 273 61 17 dirt
execute in minecraft:overworld run setblock 273 62 17 gravel
execute in minecraft:overworld run fill 273 63 17 273 144 17 air
execute in minecraft:overworld run fill 273 63 17 273 64 17 water
execute in minecraft:overworld run fill 273 58 18 273 59 18 stone
execute in minecraft:overworld run fill 273 60 18 273 61 18 dirt
execute in minecraft:overworld run setblock 273 62 18 gravel
execute in minecraft:overworld run fill 273 63 18 273 144 18 air
execute in minecraft:overworld run fill 273 63 18 273 64 18 water
execute in minecraft:overworld run fill 273 58 19 273 59 19 stone
execute in minecraft:overworld run fill 273 60 19 273 61 19 dirt
execute in minecraft:overworld run setblock 273 62 19 gravel
execute in minecraft:overworld run fill 273 63 19 273 144 19 air
execute in minecraft:overworld run fill 273 63 19 273 64 19 water
execute in minecraft:overworld run fill 273 58 20 273 59 20 stone
execute in minecraft:overworld run fill 273 60 20 273 61 20 dirt
execute in minecraft:overworld run setblock 273 62 20 gravel
execute in minecraft:overworld run fill 273 63 20 273 144 20 air
execute in minecraft:overworld run fill 273 63 20 273 64 20 water
execute in minecraft:overworld run fill 273 58 21 273 59 21 stone
execute in minecraft:overworld run fill 273 60 21 273 61 21 dirt
execute in minecraft:overworld run setblock 273 62 21 gravel
execute in minecraft:overworld run fill 273 63 21 273 144 21 air
execute in minecraft:overworld run fill 273 63 21 273 64 21 water
execute in minecraft:overworld run fill 273 58 22 273 59 22 stone
execute in minecraft:overworld run fill 273 60 22 273 61 22 dirt
execute in minecraft:overworld run setblock 273 62 22 gravel
execute in minecraft:overworld run fill 273 63 22 273 144 22 air
execute in minecraft:overworld run fill 273 63 22 273 64 22 water
execute in minecraft:overworld run fill 273 58 23 273 59 23 stone
execute in minecraft:overworld run fill 273 60 23 273 61 23 dirt
execute in minecraft:overworld run setblock 273 62 23 gravel
execute in minecraft:overworld run fill 273 63 23 273 144 23 air
execute in minecraft:overworld run fill 273 63 23 273 64 23 water
execute in minecraft:overworld run fill 273 58 24 273 59 24 stone
execute in minecraft:overworld run fill 273 60 24 273 61 24 dirt
execute in minecraft:overworld run setblock 273 62 24 gravel
execute in minecraft:overworld run fill 273 63 24 273 144 24 air
execute in minecraft:overworld run fill 273 63 24 273 64 24 water
execute in minecraft:overworld run fill 273 58 25 273 59 25 stone
execute in minecraft:overworld run fill 273 60 25 273 61 25 dirt
execute in minecraft:overworld run setblock 273 62 25 gravel
execute in minecraft:overworld run fill 273 63 25 273 144 25 air
execute in minecraft:overworld run fill 273 63 25 273 64 25 water
execute in minecraft:overworld run fill 273 58 26 273 60 26 stone
execute in minecraft:overworld run fill 273 61 26 273 62 26 dirt
execute in minecraft:overworld run setblock 273 63 26 gravel
execute in minecraft:overworld run fill 273 64 26 273 144 26 air
execute in minecraft:overworld run fill 273 64 26 273 64 26 water
execute in minecraft:overworld run fill 273 58 27 273 60 27 stone
execute in minecraft:overworld run fill 273 61 27 273 62 27 dirt
execute in minecraft:overworld run setblock 273 63 27 gravel
execute in minecraft:overworld run fill 273 64 27 273 144 27 air
execute in minecraft:overworld run fill 273 64 27 273 64 27 water
execute in minecraft:overworld run fill 273 58 28 273 60 28 stone
execute in minecraft:overworld run fill 273 61 28 273 62 28 dirt
execute in minecraft:overworld run setblock 273 63 28 gravel
execute in minecraft:overworld run fill 273 64 28 273 144 28 air
execute in minecraft:overworld run fill 273 64 28 273 64 28 water
execute in minecraft:overworld run fill 273 58 29 273 60 29 stone
execute in minecraft:overworld run fill 273 61 29 273 62 29 dirt
execute in minecraft:overworld run setblock 273 63 29 gravel
execute in minecraft:overworld run fill 273 64 29 273 144 29 air
execute in minecraft:overworld run fill 273 64 29 273 64 29 water
execute in minecraft:overworld run fill 273 58 30 273 61 30 stone
execute in minecraft:overworld run fill 273 62 30 273 63 30 dirt
execute in minecraft:overworld run setblock 273 64 30 grass_block
execute in minecraft:overworld run fill 273 65 30 273 144 30 air
execute in minecraft:overworld run fill 273 58 31 273 61 31 stone
execute in minecraft:overworld run fill 273 62 31 273 63 31 dirt
execute in minecraft:overworld run setblock 273 64 31 grass_block
execute in minecraft:overworld run fill 273 65 31 273 144 31 air
execute in minecraft:overworld run fill 273 58 32 273 61 32 stone
execute in minecraft:overworld run fill 273 62 32 273 63 32 dirt
execute in minecraft:overworld run setblock 273 64 32 coarse_dirt
execute in minecraft:overworld run fill 273 65 32 273 144 32 air
execute in minecraft:overworld run fill 273 58 33 273 61 33 stone
execute in minecraft:overworld run fill 273 62 33 273 63 33 dirt
execute in minecraft:overworld run setblock 273 64 33 grass_block
execute in minecraft:overworld run fill 273 65 33 273 144 33 air
execute in minecraft:overworld run fill 273 58 34 273 61 34 stone
execute in minecraft:overworld run fill 273 62 34 273 63 34 dirt
execute in minecraft:overworld run setblock 273 64 34 grass_block
execute in minecraft:overworld run fill 273 65 34 273 144 34 air
execute in minecraft:overworld run fill 273 58 35 273 61 35 stone
execute in minecraft:overworld run fill 273 62 35 273 63 35 dirt
execute in minecraft:overworld run setblock 273 64 35 coarse_dirt
execute in minecraft:overworld run fill 273 65 35 273 144 35 air
execute in minecraft:overworld run fill 273 58 36 273 62 36 stone
execute in minecraft:overworld run fill 273 63 36 273 64 36 dirt
execute in minecraft:overworld run setblock 273 65 36 grass_block
execute in minecraft:overworld run fill 273 66 36 273 144 36 air
execute in minecraft:overworld run fill 273 58 37 273 62 37 stone
execute in minecraft:overworld run fill 273 63 37 273 64 37 dirt
execute in minecraft:overworld run setblock 273 65 37 grass_block
execute in minecraft:overworld run fill 273 66 37 273 144 37 air
execute in minecraft:overworld run fill 273 58 38 273 62 38 stone
execute in minecraft:overworld run fill 273 63 38 273 64 38 dirt
execute in minecraft:overworld run setblock 273 65 38 coarse_dirt
execute in minecraft:overworld run fill 273 66 38 273 144 38 air
execute in minecraft:overworld run fill 273 58 39 273 62 39 stone
execute in minecraft:overworld run fill 273 63 39 273 64 39 dirt
execute in minecraft:overworld run setblock 273 65 39 coarse_dirt
execute in minecraft:overworld run fill 273 66 39 273 144 39 air
execute in minecraft:overworld run fill 273 58 40 273 62 40 stone
execute in minecraft:overworld run fill 273 63 40 273 64 40 dirt
execute in minecraft:overworld run setblock 273 65 40 coarse_dirt
execute in minecraft:overworld run fill 273 66 40 273 144 40 air
execute in minecraft:overworld run fill 273 58 41 273 62 41 stone
execute in minecraft:overworld run fill 273 63 41 273 64 41 dirt
execute in minecraft:overworld run setblock 273 65 41 coarse_dirt
execute in minecraft:overworld run fill 273 66 41 273 144 41 air
execute in minecraft:overworld run fill 273 58 42 273 61 42 stone
execute in minecraft:overworld run fill 273 62 42 273 63 42 dirt
execute in minecraft:overworld run setblock 273 64 42 coarse_dirt
execute in minecraft:overworld run fill 273 65 42 273 144 42 air
execute in minecraft:overworld run fill 273 58 43 273 61 43 stone
execute in minecraft:overworld run fill 273 62 43 273 63 43 dirt
execute in minecraft:overworld run setblock 273 64 43 coarse_dirt
execute in minecraft:overworld run fill 273 65 43 273 144 43 air
execute in minecraft:overworld run fill 273 58 44 273 61 44 stone
execute in minecraft:overworld run fill 273 62 44 273 63 44 dirt
execute in minecraft:overworld run setblock 273 64 44 coarse_dirt
execute in minecraft:overworld run fill 273 65 44 273 144 44 air
execute in minecraft:overworld run fill 273 58 45 273 61 45 stone
execute in minecraft:overworld run fill 273 62 45 273 63 45 dirt
execute in minecraft:overworld run setblock 273 64 45 coarse_dirt
execute in minecraft:overworld run fill 273 65 45 273 144 45 air
execute in minecraft:overworld run fill 273 58 46 273 61 46 stone
execute in minecraft:overworld run fill 273 62 46 273 63 46 dirt
execute in minecraft:overworld run setblock 273 64 46 grass_block
execute in minecraft:overworld run fill 273 65 46 273 144 46 air
execute in minecraft:overworld run fill 273 58 47 273 61 47 stone
execute in minecraft:overworld run fill 273 62 47 273 63 47 dirt
execute in minecraft:overworld run setblock 273 64 47 coarse_dirt
execute in minecraft:overworld run fill 273 65 47 273 144 47 air
execute in minecraft:overworld run fill 274 58 -48 274 61 -48 stone
execute in minecraft:overworld run fill 274 62 -48 274 63 -48 dirt
execute in minecraft:overworld run setblock 274 64 -48 coarse_dirt
execute in minecraft:overworld run fill 274 65 -48 274 144 -48 air
execute in minecraft:overworld run fill 274 58 -47 274 63 -47 stone
execute in minecraft:overworld run fill 274 64 -47 274 65 -47 dirt
execute in minecraft:overworld run setblock 274 66 -47 coarse_dirt
execute in minecraft:overworld run fill 274 67 -47 274 144 -47 air
execute in minecraft:overworld run fill 274 58 -46 274 65 -46 stone
execute in minecraft:overworld run fill 274 66 -46 274 67 -46 dirt
execute in minecraft:overworld run setblock 274 68 -46 coarse_dirt
execute in minecraft:overworld run fill 274 69 -46 274 144 -46 air
execute in minecraft:overworld run fill 274 58 -45 274 67 -45 stone
execute in minecraft:overworld run fill 274 68 -45 274 69 -45 dirt
execute in minecraft:overworld run setblock 274 70 -45 coarse_dirt
execute in minecraft:overworld run fill 274 71 -45 274 144 -45 air
execute in minecraft:overworld run fill 274 58 -44 274 69 -44 stone
execute in minecraft:overworld run fill 274 70 -44 274 71 -44 dirt
execute in minecraft:overworld run setblock 274 72 -44 grass_block
execute in minecraft:overworld run fill 274 73 -44 274 144 -44 air
execute in minecraft:overworld run fill 274 58 -43 274 71 -43 stone
execute in minecraft:overworld run fill 274 72 -43 274 73 -43 dirt
execute in minecraft:overworld run setblock 274 74 -43 grass_block
execute in minecraft:overworld run fill 274 75 -43 274 144 -43 air
execute in minecraft:overworld run fill 274 58 -42 274 73 -42 stone
execute in minecraft:overworld run fill 274 74 -42 274 75 -42 dirt
execute in minecraft:overworld run setblock 274 76 -42 coarse_dirt
execute in minecraft:overworld run fill 274 77 -42 274 144 -42 air
execute in minecraft:overworld run fill 274 58 -41 274 75 -41 stone
execute in minecraft:overworld run fill 274 76 -41 274 77 -41 dirt
schedule function blade_gallery:random/burned/part_105 1t replace
