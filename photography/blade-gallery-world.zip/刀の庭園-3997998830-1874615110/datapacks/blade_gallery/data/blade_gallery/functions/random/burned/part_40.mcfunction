execute in minecraft:overworld run fill 234 58 -39 234 73 -39 stone
execute in minecraft:overworld run fill 234 74 -39 234 75 -39 dirt
execute in minecraft:overworld run setblock 234 76 -39 grass_block
execute in minecraft:overworld run fill 234 77 -39 234 144 -39 air
execute in minecraft:overworld run fill 234 58 -38 234 74 -38 stone
execute in minecraft:overworld run fill 234 75 -38 234 76 -38 dirt
execute in minecraft:overworld run setblock 234 77 -38 coarse_dirt
execute in minecraft:overworld run fill 234 78 -38 234 144 -38 air
execute in minecraft:overworld run fill 234 58 -37 234 74 -37 stone
execute in minecraft:overworld run fill 234 75 -37 234 76 -37 dirt
execute in minecraft:overworld run setblock 234 77 -37 coarse_dirt
execute in minecraft:overworld run fill 234 78 -37 234 144 -37 air
execute in minecraft:overworld run setblock 234 78 -37 grass
execute in minecraft:overworld run fill 234 58 -36 234 74 -36 stone
execute in minecraft:overworld run fill 234 75 -36 234 76 -36 dirt
execute in minecraft:overworld run setblock 234 77 -36 coarse_dirt
execute in minecraft:overworld run fill 234 78 -36 234 144 -36 air
execute in minecraft:overworld run fill 234 58 -35 234 73 -35 stone
execute in minecraft:overworld run fill 234 74 -35 234 75 -35 dirt
execute in minecraft:overworld run setblock 234 76 -35 coarse_dirt
execute in minecraft:overworld run fill 234 77 -35 234 144 -35 air
execute in minecraft:overworld run fill 234 58 -34 234 73 -34 stone
execute in minecraft:overworld run fill 234 74 -34 234 75 -34 dirt
execute in minecraft:overworld run setblock 234 76 -34 coarse_dirt
execute in minecraft:overworld run fill 234 77 -34 234 144 -34 air
execute in minecraft:overworld run fill 234 58 -33 234 72 -33 stone
execute in minecraft:overworld run fill 234 73 -33 234 74 -33 dirt
execute in minecraft:overworld run setblock 234 75 -33 coarse_dirt
execute in minecraft:overworld run fill 234 76 -33 234 144 -33 air
execute in minecraft:overworld run fill 234 58 -32 234 72 -32 stone
execute in minecraft:overworld run fill 234 73 -32 234 74 -32 dirt
execute in minecraft:overworld run setblock 234 75 -32 coarse_dirt
execute in minecraft:overworld run fill 234 76 -32 234 144 -32 air
execute in minecraft:overworld run fill 234 58 -31 234 71 -31 stone
execute in minecraft:overworld run fill 234 72 -31 234 73 -31 dirt
execute in minecraft:overworld run setblock 234 74 -31 grass_block
execute in minecraft:overworld run fill 234 75 -31 234 144 -31 air
execute in minecraft:overworld run fill 234 58 -30 234 71 -30 stone
execute in minecraft:overworld run fill 234 72 -30 234 73 -30 dirt
execute in minecraft:overworld run setblock 234 74 -30 coarse_dirt
execute in minecraft:overworld run fill 234 75 -30 234 144 -30 air
execute in minecraft:overworld run fill 234 58 -29 234 70 -29 stone
execute in minecraft:overworld run fill 234 71 -29 234 72 -29 dirt
execute in minecraft:overworld run setblock 234 73 -29 coarse_dirt
execute in minecraft:overworld run fill 234 74 -29 234 144 -29 air
execute in minecraft:overworld run fill 234 58 -28 234 70 -28 stone
execute in minecraft:overworld run fill 234 71 -28 234 72 -28 dirt
execute in minecraft:overworld run setblock 234 73 -28 coarse_dirt
execute in minecraft:overworld run fill 234 74 -28 234 144 -28 air
execute in minecraft:overworld run fill 234 58 -27 234 70 -27 stone
execute in minecraft:overworld run fill 234 71 -27 234 72 -27 dirt
execute in minecraft:overworld run setblock 234 73 -27 coarse_dirt
execute in minecraft:overworld run fill 234 74 -27 234 144 -27 air
execute in minecraft:overworld run fill 234 58 -26 234 69 -26 stone
execute in minecraft:overworld run fill 234 70 -26 234 71 -26 dirt
execute in minecraft:overworld run setblock 234 72 -26 grass_block
execute in minecraft:overworld run fill 234 73 -26 234 144 -26 air
execute in minecraft:overworld run fill 234 58 -25 234 69 -25 stone
execute in minecraft:overworld run fill 234 70 -25 234 71 -25 dirt
execute in minecraft:overworld run setblock 234 72 -25 grass_block
execute in minecraft:overworld run fill 234 73 -25 234 144 -25 air
execute in minecraft:overworld run fill 234 58 -24 234 68 -24 stone
execute in minecraft:overworld run fill 234 69 -24 234 70 -24 dirt
execute in minecraft:overworld run setblock 234 71 -24 grass_block
execute in minecraft:overworld run fill 234 72 -24 234 144 -24 air
execute in minecraft:overworld run fill 234 58 -23 234 68 -23 stone
execute in minecraft:overworld run fill 234 69 -23 234 70 -23 dirt
execute in minecraft:overworld run setblock 234 71 -23 grass_block
execute in minecraft:overworld run fill 234 72 -23 234 144 -23 air
execute in minecraft:overworld run fill 234 58 -22 234 68 -22 stone
execute in minecraft:overworld run fill 234 69 -22 234 70 -22 dirt
execute in minecraft:overworld run setblock 234 71 -22 coarse_dirt
execute in minecraft:overworld run fill 234 72 -22 234 144 -22 air
execute in minecraft:overworld run fill 234 58 -21 234 67 -21 stone
execute in minecraft:overworld run fill 234 68 -21 234 69 -21 dirt
execute in minecraft:overworld run setblock 234 70 -21 grass_block
execute in minecraft:overworld run fill 234 71 -21 234 144 -21 air
execute in minecraft:overworld run fill 234 58 -20 234 67 -20 stone
execute in minecraft:overworld run fill 234 68 -20 234 69 -20 dirt
execute in minecraft:overworld run setblock 234 70 -20 coarse_dirt
execute in minecraft:overworld run fill 234 71 -20 234 144 -20 air
execute in minecraft:overworld run fill 234 58 -19 234 67 -19 stone
execute in minecraft:overworld run fill 234 68 -19 234 69 -19 dirt
execute in minecraft:overworld run setblock 234 70 -19 coarse_dirt
execute in minecraft:overworld run fill 234 71 -19 234 144 -19 air
execute in minecraft:overworld run fill 234 58 -18 234 66 -18 stone
execute in minecraft:overworld run fill 234 67 -18 234 68 -18 dirt
execute in minecraft:overworld run setblock 234 69 -18 coarse_dirt
execute in minecraft:overworld run fill 234 70 -18 234 144 -18 air
execute in minecraft:overworld run fill 234 58 -17 234 66 -17 stone
execute in minecraft:overworld run fill 234 67 -17 234 68 -17 dirt
execute in minecraft:overworld run setblock 234 69 -17 coarse_dirt
execute in minecraft:overworld run fill 234 70 -17 234 144 -17 air
execute in minecraft:overworld run fill 234 58 -16 234 66 -16 stone
execute in minecraft:overworld run fill 234 67 -16 234 68 -16 dirt
execute in minecraft:overworld run setblock 234 69 -16 coarse_dirt
execute in minecraft:overworld run fill 234 70 -16 234 144 -16 air
execute in minecraft:overworld run fill 234 58 -15 234 65 -15 stone
execute in minecraft:overworld run fill 234 66 -15 234 67 -15 dirt
execute in minecraft:overworld run setblock 234 68 -15 coarse_dirt
execute in minecraft:overworld run fill 234 69 -15 234 144 -15 air
execute in minecraft:overworld run fill 234 58 -14 234 65 -14 stone
execute in minecraft:overworld run fill 234 66 -14 234 67 -14 dirt
execute in minecraft:overworld run setblock 234 68 -14 grass_block
execute in minecraft:overworld run fill 234 69 -14 234 144 -14 air
execute in minecraft:overworld run fill 234 58 -13 234 65 -13 stone
execute in minecraft:overworld run fill 234 66 -13 234 67 -13 dirt
execute in minecraft:overworld run setblock 234 68 -13 coarse_dirt
execute in minecraft:overworld run fill 234 69 -13 234 144 -13 air
execute in minecraft:overworld run fill 234 58 -12 234 65 -12 stone
execute in minecraft:overworld run fill 234 66 -12 234 67 -12 dirt
execute in minecraft:overworld run setblock 234 68 -12 coarse_dirt
execute in minecraft:overworld run fill 234 69 -12 234 144 -12 air
execute in minecraft:overworld run setblock 234 69 -12 grass
execute in minecraft:overworld run fill 234 58 -11 234 65 -11 stone
execute in minecraft:overworld run fill 234 66 -11 234 67 -11 dirt
execute in minecraft:overworld run setblock 234 68 -11 grass_block
execute in minecraft:overworld run fill 234 69 -11 234 144 -11 air
execute in minecraft:overworld run setblock 234 69 -11 grass
execute in minecraft:overworld run fill 234 58 -10 234 65 -10 stone
execute in minecraft:overworld run fill 234 66 -10 234 67 -10 dirt
execute in minecraft:overworld run setblock 234 68 -10 coarse_dirt
execute in minecraft:overworld run fill 234 69 -10 234 144 -10 air
execute in minecraft:overworld run fill 234 58 -9 234 65 -9 stone
execute in minecraft:overworld run fill 234 66 -9 234 67 -9 dirt
execute in minecraft:overworld run setblock 234 68 -9 coarse_dirt
execute in minecraft:overworld run fill 234 69 -9 234 144 -9 air
execute in minecraft:overworld run fill 234 58 -8 234 65 -8 stone
execute in minecraft:overworld run fill 234 66 -8 234 67 -8 dirt
execute in minecraft:overworld run setblock 234 68 -8 grass_block
execute in minecraft:overworld run fill 234 69 -8 234 144 -8 air
execute in minecraft:overworld run fill 234 58 -7 234 65 -7 stone
execute in minecraft:overworld run fill 234 66 -7 234 67 -7 dirt
execute in minecraft:overworld run setblock 234 68 -7 grass_block
execute in minecraft:overworld run fill 234 69 -7 234 144 -7 air
execute in minecraft:overworld run fill 234 58 -6 234 65 -6 stone
execute in minecraft:overworld run fill 234 66 -6 234 67 -6 dirt
execute in minecraft:overworld run setblock 234 68 -6 coarse_dirt
execute in minecraft:overworld run fill 234 69 -6 234 144 -6 air
execute in minecraft:overworld run fill 234 58 -5 234 65 -5 stone
execute in minecraft:overworld run fill 234 66 -5 234 67 -5 dirt
execute in minecraft:overworld run setblock 234 68 -5 coarse_dirt
execute in minecraft:overworld run fill 234 69 -5 234 144 -5 air
execute in minecraft:overworld run fill 234 58 -4 234 64 -4 stone
execute in minecraft:overworld run fill 234 65 -4 234 66 -4 dirt
execute in minecraft:overworld run setblock 234 67 -4 coarse_dirt
execute in minecraft:overworld run fill 234 68 -4 234 144 -4 air
execute in minecraft:overworld run fill 234 58 -3 234 64 -3 stone
execute in minecraft:overworld run fill 234 65 -3 234 66 -3 dirt
execute in minecraft:overworld run setblock 234 67 -3 grass_block
execute in minecraft:overworld run fill 234 68 -3 234 144 -3 air
execute in minecraft:overworld run fill 234 58 -2 234 64 -2 stone
execute in minecraft:overworld run fill 234 65 -2 234 66 -2 dirt
execute in minecraft:overworld run setblock 234 67 -2 coarse_dirt
execute in minecraft:overworld run fill 234 68 -2 234 144 -2 air
execute in minecraft:overworld run fill 234 58 -1 234 64 -1 stone
execute in minecraft:overworld run fill 234 65 -1 234 66 -1 dirt
execute in minecraft:overworld run setblock 234 67 -1 coarse_dirt
execute in minecraft:overworld run fill 234 68 -1 234 144 -1 air
execute in minecraft:overworld run fill 234 58 0 234 64 0 stone
execute in minecraft:overworld run fill 234 65 0 234 66 0 dirt
execute in minecraft:overworld run setblock 234 67 0 grass_block
execute in minecraft:overworld run fill 234 68 0 234 144 0 air
execute in minecraft:overworld run fill 234 58 1 234 64 1 stone
execute in minecraft:overworld run fill 234 65 1 234 66 1 dirt
execute in minecraft:overworld run setblock 234 67 1 grass_block
execute in minecraft:overworld run fill 234 68 1 234 144 1 air
execute in minecraft:overworld run fill 234 58 2 234 64 2 stone
execute in minecraft:overworld run fill 234 65 2 234 66 2 dirt
execute in minecraft:overworld run setblock 234 67 2 coarse_dirt
execute in minecraft:overworld run fill 234 68 2 234 144 2 air
execute in minecraft:overworld run fill 234 58 3 234 64 3 stone
execute in minecraft:overworld run fill 234 65 3 234 66 3 dirt
execute in minecraft:overworld run setblock 234 67 3 coarse_dirt
execute in minecraft:overworld run fill 234 68 3 234 144 3 air
execute in minecraft:overworld run fill 234 58 4 234 65 4 stone
execute in minecraft:overworld run fill 234 66 4 234 67 4 dirt
execute in minecraft:overworld run setblock 234 68 4 grass_block
execute in minecraft:overworld run fill 234 69 4 234 144 4 air
execute in minecraft:overworld run fill 234 58 5 234 65 5 stone
execute in minecraft:overworld run fill 234 66 5 234 67 5 dirt
execute in minecraft:overworld run setblock 234 68 5 coarse_dirt
execute in minecraft:overworld run fill 234 69 5 234 144 5 air
execute in minecraft:overworld run fill 234 58 6 234 65 6 stone
execute in minecraft:overworld run fill 234 66 6 234 67 6 dirt
execute in minecraft:overworld run setblock 234 68 6 coarse_dirt
execute in minecraft:overworld run fill 234 69 6 234 144 6 air
execute in minecraft:overworld run fill 234 58 7 234 65 7 stone
execute in minecraft:overworld run fill 234 66 7 234 67 7 dirt
execute in minecraft:overworld run setblock 234 68 7 grass_block
execute in minecraft:overworld run fill 234 69 7 234 144 7 air
execute in minecraft:overworld run fill 234 58 8 234 66 8 stone
execute in minecraft:overworld run fill 234 67 8 234 68 8 dirt
execute in minecraft:overworld run setblock 234 69 8 grass_block
execute in minecraft:overworld run fill 234 70 8 234 144 8 air
execute in minecraft:overworld run fill 234 58 9 234 66 9 stone
execute in minecraft:overworld run fill 234 67 9 234 68 9 dirt
execute in minecraft:overworld run setblock 234 69 9 coarse_dirt
execute in minecraft:overworld run fill 234 70 9 234 144 9 air
execute in minecraft:overworld run fill 234 58 10 234 66 10 stone
execute in minecraft:overworld run fill 234 67 10 234 68 10 dirt
execute in minecraft:overworld run setblock 234 69 10 coarse_dirt
execute in minecraft:overworld run fill 234 70 10 234 144 10 air
execute in minecraft:overworld run fill 234 58 11 234 66 11 stone
execute in minecraft:overworld run fill 234 67 11 234 68 11 dirt
execute in minecraft:overworld run setblock 234 69 11 grass_block
execute in minecraft:overworld run fill 234 70 11 234 144 11 air
execute in minecraft:overworld run fill 234 58 12 234 67 12 stone
execute in minecraft:overworld run fill 234 68 12 234 69 12 dirt
execute in minecraft:overworld run setblock 234 70 12 coarse_dirt
execute in minecraft:overworld run fill 234 71 12 234 144 12 air
execute in minecraft:overworld run fill 234 58 13 234 67 13 stone
execute in minecraft:overworld run fill 234 68 13 234 69 13 dirt
execute in minecraft:overworld run setblock 234 70 13 coarse_dirt
execute in minecraft:overworld run fill 234 71 13 234 144 13 air
execute in minecraft:overworld run setblock 234 71 13 grass
execute in minecraft:overworld run fill 234 58 14 234 67 14 stone
execute in minecraft:overworld run fill 234 68 14 234 69 14 dirt
execute in minecraft:overworld run setblock 234 70 14 coarse_dirt
execute in minecraft:overworld run fill 234 71 14 234 144 14 air
execute in minecraft:overworld run fill 234 58 15 234 67 15 stone
execute in minecraft:overworld run fill 234 68 15 234 69 15 dirt
execute in minecraft:overworld run setblock 234 70 15 coarse_dirt
execute in minecraft:overworld run fill 234 71 15 234 144 15 air
execute in minecraft:overworld run fill 234 58 16 234 68 16 stone
execute in minecraft:overworld run fill 234 69 16 234 70 16 dirt
execute in minecraft:overworld run setblock 234 71 16 coarse_dirt
execute in minecraft:overworld run fill 234 72 16 234 144 16 air
execute in minecraft:overworld run fill 234 58 17 234 68 17 stone
execute in minecraft:overworld run fill 234 69 17 234 70 17 dirt
execute in minecraft:overworld run setblock 234 71 17 grass_block
execute in minecraft:overworld run fill 234 72 17 234 144 17 air
execute in minecraft:overworld run fill 234 58 18 234 68 18 stone
execute in minecraft:overworld run fill 234 69 18 234 70 18 dirt
execute in minecraft:overworld run setblock 234 71 18 grass_block
execute in minecraft:overworld run fill 234 72 18 234 144 18 air
execute in minecraft:overworld run fill 234 58 19 234 68 19 stone
execute in minecraft:overworld run fill 234 69 19 234 70 19 dirt
execute in minecraft:overworld run setblock 234 71 19 coarse_dirt
execute in minecraft:overworld run fill 234 72 19 234 144 19 air
execute in minecraft:overworld run fill 234 58 20 234 68 20 stone
execute in minecraft:overworld run fill 234 69 20 234 70 20 dirt
execute in minecraft:overworld run setblock 234 71 20 coarse_dirt
execute in minecraft:overworld run fill 234 72 20 234 144 20 air
execute in minecraft:overworld run fill 234 58 21 234 69 21 stone
execute in minecraft:overworld run fill 234 70 21 234 71 21 dirt
execute in minecraft:overworld run setblock 234 72 21 grass_block
execute in minecraft:overworld run fill 234 73 21 234 144 21 air
execute in minecraft:overworld run fill 234 58 22 234 69 22 stone
execute in minecraft:overworld run fill 234 70 22 234 71 22 dirt
execute in minecraft:overworld run setblock 234 72 22 grass_block
execute in minecraft:overworld run fill 234 73 22 234 144 22 air
execute in minecraft:overworld run fill 234 58 23 234 69 23 stone
execute in minecraft:overworld run fill 234 70 23 234 71 23 dirt
execute in minecraft:overworld run setblock 234 72 23 coarse_dirt
execute in minecraft:overworld run fill 234 73 23 234 144 23 air
schedule function blade_gallery:random/burned/part_41 1t replace
