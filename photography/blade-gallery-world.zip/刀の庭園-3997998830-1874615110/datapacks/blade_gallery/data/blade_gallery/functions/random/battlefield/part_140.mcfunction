execute in minecraft:overworld run fill 425 71 -24 425 144 -24 air
execute in minecraft:overworld run fill 425 58 -23 425 67 -23 stone
execute in minecraft:overworld run fill 425 68 -23 425 69 -23 dirt
execute in minecraft:overworld run setblock 425 70 -23 coarse_dirt
execute in minecraft:overworld run fill 425 71 -23 425 144 -23 air
execute in minecraft:overworld run fill 425 58 -22 425 67 -22 stone
execute in minecraft:overworld run fill 425 68 -22 425 69 -22 dirt
execute in minecraft:overworld run setblock 425 70 -22 coarse_dirt
execute in minecraft:overworld run fill 425 71 -22 425 144 -22 air
execute in minecraft:overworld run fill 425 58 -21 425 67 -21 stone
execute in minecraft:overworld run fill 425 68 -21 425 69 -21 dirt
execute in minecraft:overworld run setblock 425 70 -21 coarse_dirt
execute in minecraft:overworld run fill 425 71 -21 425 144 -21 air
execute in minecraft:overworld run fill 425 58 -20 425 67 -20 stone
execute in minecraft:overworld run fill 425 68 -20 425 69 -20 dirt
execute in minecraft:overworld run setblock 425 70 -20 coarse_dirt
execute in minecraft:overworld run fill 425 71 -20 425 144 -20 air
execute in minecraft:overworld run setblock 425 71 -20 grass
execute in minecraft:overworld run fill 425 58 -19 425 66 -19 stone
execute in minecraft:overworld run fill 425 67 -19 425 68 -19 dirt
execute in minecraft:overworld run setblock 425 69 -19 grass_block
execute in minecraft:overworld run fill 425 70 -19 425 144 -19 air
execute in minecraft:overworld run fill 425 58 -18 425 66 -18 stone
execute in minecraft:overworld run fill 425 67 -18 425 68 -18 dirt
execute in minecraft:overworld run setblock 425 69 -18 coarse_dirt
execute in minecraft:overworld run fill 425 70 -18 425 144 -18 air
execute in minecraft:overworld run setblock 425 70 -18 grass
execute in minecraft:overworld run fill 425 58 -17 425 66 -17 stone
execute in minecraft:overworld run fill 425 67 -17 425 68 -17 dirt
execute in minecraft:overworld run setblock 425 69 -17 grass_block
execute in minecraft:overworld run fill 425 70 -17 425 144 -17 air
execute in minecraft:overworld run fill 425 58 -16 425 65 -16 stone
execute in minecraft:overworld run fill 425 66 -16 425 67 -16 dirt
execute in minecraft:overworld run setblock 425 68 -16 coarse_dirt
execute in minecraft:overworld run fill 425 69 -16 425 144 -16 air
execute in minecraft:overworld run fill 425 58 -15 425 65 -15 stone
execute in minecraft:overworld run fill 425 66 -15 425 67 -15 dirt
execute in minecraft:overworld run setblock 425 68 -15 coarse_dirt
execute in minecraft:overworld run fill 425 69 -15 425 144 -15 air
execute in minecraft:overworld run fill 425 58 -14 425 65 -14 stone
execute in minecraft:overworld run fill 425 66 -14 425 67 -14 dirt
execute in minecraft:overworld run setblock 425 68 -14 grass_block
execute in minecraft:overworld run fill 425 69 -14 425 144 -14 air
execute in minecraft:overworld run fill 425 58 -13 425 65 -13 stone
execute in minecraft:overworld run fill 425 66 -13 425 67 -13 dirt
execute in minecraft:overworld run setblock 425 68 -13 coarse_dirt
execute in minecraft:overworld run fill 425 69 -13 425 144 -13 air
execute in minecraft:overworld run fill 425 58 -12 425 64 -12 stone
execute in minecraft:overworld run fill 425 65 -12 425 66 -12 dirt
execute in minecraft:overworld run setblock 425 67 -12 coarse_dirt
execute in minecraft:overworld run fill 425 68 -12 425 144 -12 air
execute in minecraft:overworld run fill 425 58 -11 425 64 -11 stone
execute in minecraft:overworld run fill 425 65 -11 425 66 -11 dirt
execute in minecraft:overworld run setblock 425 67 -11 coarse_dirt
execute in minecraft:overworld run fill 425 68 -11 425 144 -11 air
execute in minecraft:overworld run fill 425 58 -10 425 64 -10 stone
execute in minecraft:overworld run fill 425 65 -10 425 66 -10 dirt
execute in minecraft:overworld run setblock 425 67 -10 coarse_dirt
execute in minecraft:overworld run fill 425 68 -10 425 144 -10 air
execute in minecraft:overworld run fill 425 58 -9 425 64 -9 stone
execute in minecraft:overworld run fill 425 65 -9 425 66 -9 dirt
execute in minecraft:overworld run setblock 425 67 -9 coarse_dirt
execute in minecraft:overworld run fill 425 68 -9 425 144 -9 air
execute in minecraft:overworld run fill 425 58 -8 425 64 -8 stone
execute in minecraft:overworld run fill 425 65 -8 425 66 -8 dirt
execute in minecraft:overworld run setblock 425 67 -8 coarse_dirt
execute in minecraft:overworld run fill 425 68 -8 425 144 -8 air
execute in minecraft:overworld run fill 425 58 -7 425 64 -7 stone
execute in minecraft:overworld run fill 425 65 -7 425 66 -7 dirt
execute in minecraft:overworld run setblock 425 67 -7 coarse_dirt
execute in minecraft:overworld run fill 425 68 -7 425 144 -7 air
execute in minecraft:overworld run fill 425 58 -6 425 64 -6 stone
execute in minecraft:overworld run fill 425 65 -6 425 66 -6 dirt
execute in minecraft:overworld run setblock 425 67 -6 coarse_dirt
execute in minecraft:overworld run fill 425 68 -6 425 144 -6 air
execute in minecraft:overworld run fill 425 58 -5 425 64 -5 stone
execute in minecraft:overworld run fill 425 65 -5 425 66 -5 dirt
execute in minecraft:overworld run setblock 425 67 -5 coarse_dirt
execute in minecraft:overworld run fill 425 68 -5 425 144 -5 air
execute in minecraft:overworld run setblock 425 68 -5 grass
execute in minecraft:overworld run fill 425 58 -4 425 64 -4 stone
execute in minecraft:overworld run fill 425 65 -4 425 66 -4 dirt
execute in minecraft:overworld run setblock 425 67 -4 coarse_dirt
execute in minecraft:overworld run fill 425 68 -4 425 144 -4 air
execute in minecraft:overworld run fill 425 58 -3 425 63 -3 stone
execute in minecraft:overworld run fill 425 64 -3 425 65 -3 dirt
execute in minecraft:overworld run setblock 425 66 -3 coarse_dirt
execute in minecraft:overworld run fill 425 67 -3 425 144 -3 air
execute in minecraft:overworld run fill 425 58 -2 425 63 -2 stone
execute in minecraft:overworld run fill 425 64 -2 425 65 -2 dirt
execute in minecraft:overworld run setblock 425 66 -2 grass_block
execute in minecraft:overworld run fill 425 67 -2 425 144 -2 air
execute in minecraft:overworld run setblock 425 67 -2 grass
execute in minecraft:overworld run fill 425 58 -1 425 63 -1 stone
execute in minecraft:overworld run fill 425 64 -1 425 65 -1 dirt
execute in minecraft:overworld run setblock 425 66 -1 grass_block
execute in minecraft:overworld run fill 425 67 -1 425 144 -1 air
execute in minecraft:overworld run fill 425 58 0 425 63 0 stone
execute in minecraft:overworld run fill 425 64 0 425 65 0 dirt
execute in minecraft:overworld run setblock 425 66 0 grass_block
execute in minecraft:overworld run fill 425 67 0 425 144 0 air
execute in minecraft:overworld run fill 425 58 1 425 63 1 stone
execute in minecraft:overworld run fill 425 64 1 425 65 1 dirt
execute in minecraft:overworld run setblock 425 66 1 coarse_dirt
execute in minecraft:overworld run fill 425 67 1 425 144 1 air
execute in minecraft:overworld run fill 425 58 2 425 63 2 stone
execute in minecraft:overworld run fill 425 64 2 425 65 2 dirt
execute in minecraft:overworld run setblock 425 66 2 grass_block
execute in minecraft:overworld run fill 425 67 2 425 144 2 air
execute in minecraft:overworld run fill 425 58 3 425 63 3 stone
execute in minecraft:overworld run fill 425 64 3 425 65 3 dirt
execute in minecraft:overworld run setblock 425 66 3 grass_block
execute in minecraft:overworld run fill 425 67 3 425 144 3 air
execute in minecraft:overworld run fill 425 58 4 425 64 4 stone
execute in minecraft:overworld run fill 425 65 4 425 66 4 dirt
execute in minecraft:overworld run setblock 425 67 4 coarse_dirt
execute in minecraft:overworld run fill 425 68 4 425 144 4 air
execute in minecraft:overworld run fill 425 58 5 425 64 5 stone
execute in minecraft:overworld run fill 425 65 5 425 66 5 dirt
execute in minecraft:overworld run setblock 425 67 5 grass_block
execute in minecraft:overworld run fill 425 68 5 425 144 5 air
execute in minecraft:overworld run fill 425 58 6 425 64 6 stone
execute in minecraft:overworld run fill 425 65 6 425 66 6 dirt
execute in minecraft:overworld run setblock 425 67 6 coarse_dirt
execute in minecraft:overworld run fill 425 68 6 425 144 6 air
execute in minecraft:overworld run fill 425 58 7 425 64 7 stone
execute in minecraft:overworld run fill 425 65 7 425 66 7 dirt
execute in minecraft:overworld run setblock 425 67 7 coarse_dirt
execute in minecraft:overworld run fill 425 68 7 425 144 7 air
execute in minecraft:overworld run fill 425 58 8 425 64 8 stone
execute in minecraft:overworld run fill 425 65 8 425 66 8 dirt
execute in minecraft:overworld run setblock 425 67 8 coarse_dirt
execute in minecraft:overworld run fill 425 68 8 425 144 8 air
execute in minecraft:overworld run fill 425 58 9 425 65 9 stone
execute in minecraft:overworld run fill 425 66 9 425 67 9 dirt
execute in minecraft:overworld run setblock 425 68 9 coarse_dirt
execute in minecraft:overworld run fill 425 69 9 425 144 9 air
execute in minecraft:overworld run fill 425 58 10 425 65 10 stone
execute in minecraft:overworld run fill 425 66 10 425 67 10 dirt
execute in minecraft:overworld run setblock 425 68 10 coarse_dirt
execute in minecraft:overworld run fill 425 69 10 425 144 10 air
execute in minecraft:overworld run fill 425 58 11 425 65 11 stone
execute in minecraft:overworld run fill 425 66 11 425 67 11 dirt
execute in minecraft:overworld run setblock 425 68 11 coarse_dirt
execute in minecraft:overworld run fill 425 69 11 425 144 11 air
execute in minecraft:overworld run fill 425 58 12 425 65 12 stone
execute in minecraft:overworld run fill 425 66 12 425 67 12 dirt
execute in minecraft:overworld run setblock 425 68 12 grass_block
execute in minecraft:overworld run fill 425 69 12 425 144 12 air
execute in minecraft:overworld run fill 425 58 13 425 66 13 stone
execute in minecraft:overworld run fill 425 67 13 425 68 13 dirt
execute in minecraft:overworld run setblock 425 69 13 coarse_dirt
execute in minecraft:overworld run fill 425 70 13 425 144 13 air
execute in minecraft:overworld run fill 425 58 14 425 66 14 stone
execute in minecraft:overworld run fill 425 67 14 425 68 14 dirt
execute in minecraft:overworld run setblock 425 69 14 coarse_dirt
execute in minecraft:overworld run fill 425 70 14 425 144 14 air
execute in minecraft:overworld run fill 425 58 15 425 66 15 stone
execute in minecraft:overworld run fill 425 67 15 425 68 15 dirt
execute in minecraft:overworld run setblock 425 69 15 coarse_dirt
execute in minecraft:overworld run fill 425 70 15 425 144 15 air
execute in minecraft:overworld run setblock 425 70 15 grass
execute in minecraft:overworld run fill 425 58 16 425 66 16 stone
execute in minecraft:overworld run fill 425 67 16 425 68 16 dirt
execute in minecraft:overworld run setblock 425 69 16 grass_block
execute in minecraft:overworld run fill 425 70 16 425 144 16 air
execute in minecraft:overworld run fill 425 58 17 425 67 17 stone
execute in minecraft:overworld run fill 425 68 17 425 69 17 dirt
execute in minecraft:overworld run setblock 425 70 17 grass_block
execute in minecraft:overworld run fill 425 71 17 425 144 17 air
execute in minecraft:overworld run fill 425 58 18 425 67 18 stone
execute in minecraft:overworld run fill 425 68 18 425 69 18 dirt
execute in minecraft:overworld run setblock 425 70 18 grass_block
execute in minecraft:overworld run fill 425 71 18 425 144 18 air
execute in minecraft:overworld run fill 425 58 19 425 67 19 stone
execute in minecraft:overworld run fill 425 68 19 425 69 19 dirt
execute in minecraft:overworld run setblock 425 70 19 coarse_dirt
execute in minecraft:overworld run fill 425 71 19 425 144 19 air
execute in minecraft:overworld run fill 425 58 20 425 67 20 stone
execute in minecraft:overworld run fill 425 68 20 425 69 20 dirt
execute in minecraft:overworld run setblock 425 70 20 coarse_dirt
execute in minecraft:overworld run fill 425 71 20 425 144 20 air
execute in minecraft:overworld run setblock 425 71 20 grass
execute in minecraft:overworld run fill 425 58 21 425 67 21 stone
execute in minecraft:overworld run fill 425 68 21 425 69 21 dirt
execute in minecraft:overworld run setblock 425 70 21 grass_block
execute in minecraft:overworld run fill 425 71 21 425 144 21 air
execute in minecraft:overworld run setblock 425 71 21 grass
execute in minecraft:overworld run fill 425 58 22 425 68 22 stone
execute in minecraft:overworld run fill 425 69 22 425 70 22 dirt
execute in minecraft:overworld run setblock 425 71 22 coarse_dirt
execute in minecraft:overworld run fill 425 72 22 425 144 22 air
execute in minecraft:overworld run fill 425 58 23 425 68 23 stone
execute in minecraft:overworld run fill 425 69 23 425 70 23 dirt
execute in minecraft:overworld run setblock 425 71 23 coarse_dirt
execute in minecraft:overworld run fill 425 72 23 425 144 23 air
execute in minecraft:overworld run setblock 425 72 23 grass
execute in minecraft:overworld run fill 425 58 24 425 68 24 stone
execute in minecraft:overworld run fill 425 69 24 425 70 24 dirt
execute in minecraft:overworld run setblock 425 71 24 coarse_dirt
execute in minecraft:overworld run fill 425 72 24 425 144 24 air
execute in minecraft:overworld run fill 425 58 25 425 68 25 stone
execute in minecraft:overworld run fill 425 69 25 425 70 25 dirt
execute in minecraft:overworld run setblock 425 71 25 coarse_dirt
execute in minecraft:overworld run fill 425 72 25 425 144 25 air
execute in minecraft:overworld run fill 425 58 26 425 68 26 stone
execute in minecraft:overworld run fill 425 69 26 425 70 26 dirt
execute in minecraft:overworld run setblock 425 71 26 coarse_dirt
execute in minecraft:overworld run fill 425 72 26 425 144 26 air
execute in minecraft:overworld run fill 425 58 27 425 68 27 stone
execute in minecraft:overworld run fill 425 69 27 425 70 27 dirt
execute in minecraft:overworld run setblock 425 71 27 coarse_dirt
execute in minecraft:overworld run fill 425 72 27 425 144 27 air
execute in minecraft:overworld run fill 425 58 28 425 68 28 stone
execute in minecraft:overworld run fill 425 69 28 425 70 28 dirt
execute in minecraft:overworld run setblock 425 71 28 coarse_dirt
execute in minecraft:overworld run fill 425 72 28 425 144 28 air
execute in minecraft:overworld run fill 425 58 29 425 68 29 stone
execute in minecraft:overworld run fill 425 69 29 425 70 29 dirt
execute in minecraft:overworld run setblock 425 71 29 coarse_dirt
execute in minecraft:overworld run fill 425 72 29 425 144 29 air
execute in minecraft:overworld run fill 425 58 30 425 68 30 stone
execute in minecraft:overworld run fill 425 69 30 425 70 30 dirt
execute in minecraft:overworld run setblock 425 71 30 coarse_dirt
execute in minecraft:overworld run fill 425 72 30 425 144 30 air
execute in minecraft:overworld run fill 425 58 31 425 68 31 stone
execute in minecraft:overworld run fill 425 69 31 425 70 31 dirt
execute in minecraft:overworld run setblock 425 71 31 grass_block
execute in minecraft:overworld run fill 425 72 31 425 144 31 air
execute in minecraft:overworld run fill 425 58 32 425 68 32 stone
execute in minecraft:overworld run fill 425 69 32 425 70 32 dirt
execute in minecraft:overworld run setblock 425 71 32 coarse_dirt
execute in minecraft:overworld run fill 425 72 32 425 144 32 air
execute in minecraft:overworld run fill 425 58 33 425 68 33 stone
execute in minecraft:overworld run fill 425 69 33 425 70 33 dirt
execute in minecraft:overworld run setblock 425 71 33 grass_block
execute in minecraft:overworld run fill 425 72 33 425 144 33 air
execute in minecraft:overworld run fill 425 58 34 425 68 34 stone
execute in minecraft:overworld run fill 425 69 34 425 70 34 dirt
execute in minecraft:overworld run setblock 425 71 34 coarse_dirt
execute in minecraft:overworld run fill 425 72 34 425 144 34 air
execute in minecraft:overworld run fill 425 58 35 425 67 35 stone
execute in minecraft:overworld run fill 425 68 35 425 69 35 dirt
execute in minecraft:overworld run setblock 425 70 35 coarse_dirt
execute in minecraft:overworld run fill 425 71 35 425 144 35 air
execute in minecraft:overworld run fill 425 58 36 425 67 36 stone
execute in minecraft:overworld run fill 425 68 36 425 69 36 dirt
execute in minecraft:overworld run setblock 425 70 36 grass_block
execute in minecraft:overworld run fill 425 71 36 425 144 36 air
execute in minecraft:overworld run fill 425 58 37 425 67 37 stone
execute in minecraft:overworld run fill 425 68 37 425 69 37 dirt
execute in minecraft:overworld run setblock 425 70 37 coarse_dirt
execute in minecraft:overworld run fill 425 71 37 425 144 37 air
execute in minecraft:overworld run fill 425 58 38 425 66 38 stone
execute in minecraft:overworld run fill 425 67 38 425 68 38 dirt
execute in minecraft:overworld run setblock 425 69 38 grass_block
schedule function blade_gallery:random/battlefield/part_141 1t replace
