execute in minecraft:overworld run kill @e[type=the_four_primitives_and_weapons:stabbed_weapon,tag=blade_gallery.flowers]
execute in minecraft:overworld run gamerule doFireTick false
execute in minecraft:overworld run fill 464 58 -48 464 61 -48 stone
execute in minecraft:overworld run fill 464 62 -48 464 63 -48 dirt
execute in minecraft:overworld run setblock 464 64 -48 grass_block
execute in minecraft:overworld run fill 464 65 -48 464 144 -48 air
execute in minecraft:overworld run fill 464 58 -47 464 61 -47 stone
execute in minecraft:overworld run fill 464 62 -47 464 63 -47 dirt
execute in minecraft:overworld run setblock 464 64 -47 grass_block
execute in minecraft:overworld run fill 464 65 -47 464 144 -47 air
execute in minecraft:overworld run fill 464 58 -46 464 61 -46 stone
execute in minecraft:overworld run fill 464 62 -46 464 63 -46 dirt
execute in minecraft:overworld run setblock 464 64 -46 grass_block
execute in minecraft:overworld run fill 464 65 -46 464 144 -46 air
execute in minecraft:overworld run fill 464 58 -45 464 61 -45 stone
execute in minecraft:overworld run fill 464 62 -45 464 63 -45 dirt
execute in minecraft:overworld run setblock 464 64 -45 grass_block
execute in minecraft:overworld run fill 464 65 -45 464 144 -45 air
execute in minecraft:overworld run fill 464 58 -44 464 61 -44 stone
execute in minecraft:overworld run fill 464 62 -44 464 63 -44 dirt
execute in minecraft:overworld run setblock 464 64 -44 grass_block
execute in minecraft:overworld run fill 464 65 -44 464 144 -44 air
execute in minecraft:overworld run fill 464 58 -43 464 61 -43 stone
execute in minecraft:overworld run fill 464 62 -43 464 63 -43 dirt
execute in minecraft:overworld run setblock 464 64 -43 grass_block
execute in minecraft:overworld run fill 464 65 -43 464 144 -43 air
execute in minecraft:overworld run fill 464 58 -42 464 61 -42 stone
execute in minecraft:overworld run fill 464 62 -42 464 63 -42 dirt
execute in minecraft:overworld run setblock 464 64 -42 grass_block
execute in minecraft:overworld run fill 464 65 -42 464 144 -42 air
execute in minecraft:overworld run fill 464 58 -41 464 61 -41 stone
execute in minecraft:overworld run fill 464 62 -41 464 63 -41 dirt
execute in minecraft:overworld run setblock 464 64 -41 grass_block
execute in minecraft:overworld run fill 464 65 -41 464 144 -41 air
execute in minecraft:overworld run fill 464 58 -40 464 61 -40 stone
execute in minecraft:overworld run fill 464 62 -40 464 63 -40 dirt
execute in minecraft:overworld run setblock 464 64 -40 grass_block
execute in minecraft:overworld run fill 464 65 -40 464 144 -40 air
execute in minecraft:overworld run fill 464 58 -39 464 61 -39 stone
execute in minecraft:overworld run fill 464 62 -39 464 63 -39 dirt
execute in minecraft:overworld run setblock 464 64 -39 grass_block
execute in minecraft:overworld run fill 464 65 -39 464 144 -39 air
execute in minecraft:overworld run fill 464 58 -38 464 61 -38 stone
execute in minecraft:overworld run fill 464 62 -38 464 63 -38 dirt
execute in minecraft:overworld run setblock 464 64 -38 grass_block
execute in minecraft:overworld run fill 464 65 -38 464 144 -38 air
execute in minecraft:overworld run fill 464 58 -37 464 61 -37 stone
execute in minecraft:overworld run fill 464 62 -37 464 63 -37 dirt
execute in minecraft:overworld run setblock 464 64 -37 grass_block
execute in minecraft:overworld run fill 464 65 -37 464 144 -37 air
execute in minecraft:overworld run fill 464 58 -36 464 61 -36 stone
execute in minecraft:overworld run fill 464 62 -36 464 63 -36 dirt
execute in minecraft:overworld run setblock 464 64 -36 grass_block
execute in minecraft:overworld run fill 464 65 -36 464 144 -36 air
execute in minecraft:overworld run fill 464 58 -35 464 61 -35 stone
execute in minecraft:overworld run fill 464 62 -35 464 63 -35 dirt
execute in minecraft:overworld run setblock 464 64 -35 grass_block
execute in minecraft:overworld run fill 464 65 -35 464 144 -35 air
execute in minecraft:overworld run fill 464 58 -34 464 61 -34 stone
execute in minecraft:overworld run fill 464 62 -34 464 63 -34 dirt
execute in minecraft:overworld run setblock 464 64 -34 grass_block
execute in minecraft:overworld run fill 464 65 -34 464 144 -34 air
execute in minecraft:overworld run fill 464 58 -33 464 61 -33 stone
execute in minecraft:overworld run fill 464 62 -33 464 63 -33 dirt
execute in minecraft:overworld run setblock 464 64 -33 grass_block
execute in minecraft:overworld run fill 464 65 -33 464 144 -33 air
execute in minecraft:overworld run fill 464 58 -32 464 61 -32 stone
execute in minecraft:overworld run fill 464 62 -32 464 63 -32 dirt
execute in minecraft:overworld run setblock 464 64 -32 grass_block
execute in minecraft:overworld run fill 464 65 -32 464 144 -32 air
execute in minecraft:overworld run fill 464 58 -31 464 61 -31 stone
execute in minecraft:overworld run fill 464 62 -31 464 63 -31 dirt
execute in minecraft:overworld run setblock 464 64 -31 grass_block
execute in minecraft:overworld run fill 464 65 -31 464 144 -31 air
execute in minecraft:overworld run fill 464 58 -30 464 61 -30 stone
execute in minecraft:overworld run fill 464 62 -30 464 63 -30 dirt
execute in minecraft:overworld run setblock 464 64 -30 grass_block
execute in minecraft:overworld run fill 464 65 -30 464 144 -30 air
execute in minecraft:overworld run fill 464 58 -29 464 61 -29 stone
execute in minecraft:overworld run fill 464 62 -29 464 63 -29 dirt
execute in minecraft:overworld run setblock 464 64 -29 grass_block
execute in minecraft:overworld run fill 464 65 -29 464 144 -29 air
execute in minecraft:overworld run fill 464 58 -28 464 61 -28 stone
execute in minecraft:overworld run fill 464 62 -28 464 63 -28 dirt
execute in minecraft:overworld run setblock 464 64 -28 grass_block
execute in minecraft:overworld run fill 464 65 -28 464 144 -28 air
execute in minecraft:overworld run fill 464 58 -27 464 61 -27 stone
execute in minecraft:overworld run fill 464 62 -27 464 63 -27 dirt
execute in minecraft:overworld run setblock 464 64 -27 grass_block
execute in minecraft:overworld run fill 464 65 -27 464 144 -27 air
execute in minecraft:overworld run fill 464 58 -26 464 61 -26 stone
execute in minecraft:overworld run fill 464 62 -26 464 63 -26 dirt
execute in minecraft:overworld run setblock 464 64 -26 grass_block
execute in minecraft:overworld run fill 464 65 -26 464 144 -26 air
execute in minecraft:overworld run fill 464 58 -25 464 61 -25 stone
execute in minecraft:overworld run fill 464 62 -25 464 63 -25 dirt
execute in minecraft:overworld run setblock 464 64 -25 grass_block
execute in minecraft:overworld run fill 464 65 -25 464 144 -25 air
execute in minecraft:overworld run fill 464 58 -24 464 61 -24 stone
execute in minecraft:overworld run fill 464 62 -24 464 63 -24 dirt
execute in minecraft:overworld run setblock 464 64 -24 grass_block
execute in minecraft:overworld run fill 464 65 -24 464 144 -24 air
execute in minecraft:overworld run fill 464 58 -23 464 61 -23 stone
execute in minecraft:overworld run fill 464 62 -23 464 63 -23 dirt
execute in minecraft:overworld run setblock 464 64 -23 grass_block
execute in minecraft:overworld run fill 464 65 -23 464 144 -23 air
execute in minecraft:overworld run fill 464 58 -22 464 61 -22 stone
execute in minecraft:overworld run fill 464 62 -22 464 63 -22 dirt
execute in minecraft:overworld run setblock 464 64 -22 grass_block
execute in minecraft:overworld run fill 464 65 -22 464 144 -22 air
execute in minecraft:overworld run fill 464 58 -21 464 61 -21 stone
execute in minecraft:overworld run fill 464 62 -21 464 63 -21 dirt
execute in minecraft:overworld run setblock 464 64 -21 grass_block
execute in minecraft:overworld run fill 464 65 -21 464 144 -21 air
execute in minecraft:overworld run fill 464 58 -20 464 61 -20 stone
execute in minecraft:overworld run fill 464 62 -20 464 63 -20 dirt
execute in minecraft:overworld run setblock 464 64 -20 grass_block
execute in minecraft:overworld run fill 464 65 -20 464 144 -20 air
execute in minecraft:overworld run fill 464 58 -19 464 61 -19 stone
execute in minecraft:overworld run fill 464 62 -19 464 63 -19 dirt
execute in minecraft:overworld run setblock 464 64 -19 grass_block
execute in minecraft:overworld run fill 464 65 -19 464 144 -19 air
execute in minecraft:overworld run fill 464 58 -18 464 61 -18 stone
execute in minecraft:overworld run fill 464 62 -18 464 63 -18 dirt
execute in minecraft:overworld run setblock 464 64 -18 grass_block
execute in minecraft:overworld run fill 464 65 -18 464 144 -18 air
execute in minecraft:overworld run fill 464 58 -17 464 61 -17 stone
execute in minecraft:overworld run fill 464 62 -17 464 63 -17 dirt
execute in minecraft:overworld run setblock 464 64 -17 grass_block
execute in minecraft:overworld run fill 464 65 -17 464 144 -17 air
execute in minecraft:overworld run fill 464 58 -16 464 61 -16 stone
execute in minecraft:overworld run fill 464 62 -16 464 63 -16 dirt
execute in minecraft:overworld run setblock 464 64 -16 grass_block
execute in minecraft:overworld run fill 464 65 -16 464 144 -16 air
execute in minecraft:overworld run fill 464 58 -15 464 61 -15 stone
execute in minecraft:overworld run fill 464 62 -15 464 63 -15 dirt
execute in minecraft:overworld run setblock 464 64 -15 grass_block
execute in minecraft:overworld run fill 464 65 -15 464 144 -15 air
execute in minecraft:overworld run fill 464 58 -14 464 61 -14 stone
execute in minecraft:overworld run fill 464 62 -14 464 63 -14 dirt
execute in minecraft:overworld run setblock 464 64 -14 grass_block
execute in minecraft:overworld run fill 464 65 -14 464 144 -14 air
execute in minecraft:overworld run fill 464 58 -13 464 61 -13 stone
execute in minecraft:overworld run fill 464 62 -13 464 63 -13 dirt
execute in minecraft:overworld run setblock 464 64 -13 grass_block
execute in minecraft:overworld run fill 464 65 -13 464 144 -13 air
execute in minecraft:overworld run fill 464 58 -12 464 61 -12 stone
execute in minecraft:overworld run fill 464 62 -12 464 63 -12 dirt
execute in minecraft:overworld run setblock 464 64 -12 grass_block
execute in minecraft:overworld run fill 464 65 -12 464 144 -12 air
execute in minecraft:overworld run fill 464 58 -11 464 61 -11 stone
execute in minecraft:overworld run fill 464 62 -11 464 63 -11 dirt
execute in minecraft:overworld run setblock 464 64 -11 grass_block
execute in minecraft:overworld run fill 464 65 -11 464 144 -11 air
execute in minecraft:overworld run fill 464 58 -10 464 61 -10 stone
execute in minecraft:overworld run fill 464 62 -10 464 63 -10 dirt
execute in minecraft:overworld run setblock 464 64 -10 grass_block
execute in minecraft:overworld run fill 464 65 -10 464 144 -10 air
execute in minecraft:overworld run fill 464 58 -9 464 61 -9 stone
execute in minecraft:overworld run fill 464 62 -9 464 63 -9 dirt
execute in minecraft:overworld run setblock 464 64 -9 grass_block
execute in minecraft:overworld run fill 464 65 -9 464 144 -9 air
execute in minecraft:overworld run fill 464 58 -8 464 61 -8 stone
execute in minecraft:overworld run fill 464 62 -8 464 63 -8 dirt
execute in minecraft:overworld run setblock 464 64 -8 grass_block
execute in minecraft:overworld run fill 464 65 -8 464 144 -8 air
execute in minecraft:overworld run fill 464 58 -7 464 61 -7 stone
execute in minecraft:overworld run fill 464 62 -7 464 63 -7 dirt
execute in minecraft:overworld run setblock 464 64 -7 grass_block
execute in minecraft:overworld run fill 464 65 -7 464 144 -7 air
execute in minecraft:overworld run fill 464 58 -6 464 61 -6 stone
execute in minecraft:overworld run fill 464 62 -6 464 63 -6 dirt
execute in minecraft:overworld run setblock 464 64 -6 grass_block
execute in minecraft:overworld run fill 464 65 -6 464 144 -6 air
execute in minecraft:overworld run fill 464 58 -5 464 61 -5 stone
execute in minecraft:overworld run fill 464 62 -5 464 63 -5 dirt
execute in minecraft:overworld run setblock 464 64 -5 grass_block
execute in minecraft:overworld run fill 464 65 -5 464 144 -5 air
execute in minecraft:overworld run fill 464 58 -4 464 61 -4 stone
execute in minecraft:overworld run fill 464 62 -4 464 63 -4 dirt
execute in minecraft:overworld run setblock 464 64 -4 grass_block
execute in minecraft:overworld run fill 464 65 -4 464 144 -4 air
execute in minecraft:overworld run fill 464 58 -3 464 61 -3 stone
execute in minecraft:overworld run fill 464 62 -3 464 63 -3 dirt
execute in minecraft:overworld run setblock 464 64 -3 grass_block
execute in minecraft:overworld run fill 464 65 -3 464 144 -3 air
execute in minecraft:overworld run fill 464 58 -2 464 61 -2 stone
execute in minecraft:overworld run fill 464 62 -2 464 63 -2 dirt
execute in minecraft:overworld run setblock 464 64 -2 grass_block
execute in minecraft:overworld run fill 464 65 -2 464 144 -2 air
execute in minecraft:overworld run fill 464 58 -1 464 61 -1 stone
execute in minecraft:overworld run fill 464 62 -1 464 63 -1 dirt
execute in minecraft:overworld run setblock 464 64 -1 grass_block
execute in minecraft:overworld run fill 464 65 -1 464 144 -1 air
execute in minecraft:overworld run fill 464 58 0 464 61 0 stone
execute in minecraft:overworld run fill 464 62 0 464 63 0 dirt
execute in minecraft:overworld run setblock 464 64 0 grass_block
execute in minecraft:overworld run fill 464 65 0 464 144 0 air
execute in minecraft:overworld run fill 464 58 1 464 61 1 stone
execute in minecraft:overworld run fill 464 62 1 464 63 1 dirt
execute in minecraft:overworld run setblock 464 64 1 grass_block
execute in minecraft:overworld run fill 464 65 1 464 144 1 air
execute in minecraft:overworld run fill 464 58 2 464 61 2 stone
execute in minecraft:overworld run fill 464 62 2 464 63 2 dirt
execute in minecraft:overworld run setblock 464 64 2 grass_block
execute in minecraft:overworld run fill 464 65 2 464 144 2 air
execute in minecraft:overworld run fill 464 58 3 464 61 3 stone
execute in minecraft:overworld run fill 464 62 3 464 63 3 dirt
execute in minecraft:overworld run setblock 464 64 3 grass_block
execute in minecraft:overworld run fill 464 65 3 464 144 3 air
execute in minecraft:overworld run fill 464 58 4 464 61 4 stone
execute in minecraft:overworld run fill 464 62 4 464 63 4 dirt
execute in minecraft:overworld run setblock 464 64 4 grass_block
execute in minecraft:overworld run fill 464 65 4 464 144 4 air
execute in minecraft:overworld run fill 464 58 5 464 61 5 stone
execute in minecraft:overworld run fill 464 62 5 464 63 5 dirt
execute in minecraft:overworld run setblock 464 64 5 grass_block
execute in minecraft:overworld run fill 464 65 5 464 144 5 air
execute in minecraft:overworld run fill 464 58 6 464 61 6 stone
execute in minecraft:overworld run fill 464 62 6 464 63 6 dirt
execute in minecraft:overworld run setblock 464 64 6 grass_block
execute in minecraft:overworld run fill 464 65 6 464 144 6 air
execute in minecraft:overworld run fill 464 58 7 464 61 7 stone
execute in minecraft:overworld run fill 464 62 7 464 63 7 dirt
execute in minecraft:overworld run setblock 464 64 7 grass_block
execute in minecraft:overworld run fill 464 65 7 464 144 7 air
execute in minecraft:overworld run fill 464 58 8 464 61 8 stone
execute in minecraft:overworld run fill 464 62 8 464 63 8 dirt
execute in minecraft:overworld run setblock 464 64 8 grass_block
execute in minecraft:overworld run fill 464 65 8 464 144 8 air
execute in minecraft:overworld run fill 464 58 9 464 61 9 stone
execute in minecraft:overworld run fill 464 62 9 464 63 9 dirt
execute in minecraft:overworld run setblock 464 64 9 grass_block
execute in minecraft:overworld run fill 464 65 9 464 144 9 air
execute in minecraft:overworld run fill 464 58 10 464 61 10 stone
execute in minecraft:overworld run fill 464 62 10 464 63 10 dirt
execute in minecraft:overworld run setblock 464 64 10 grass_block
execute in minecraft:overworld run fill 464 65 10 464 144 10 air
execute in minecraft:overworld run fill 464 58 11 464 61 11 stone
execute in minecraft:overworld run fill 464 62 11 464 63 11 dirt
execute in minecraft:overworld run setblock 464 64 11 grass_block
execute in minecraft:overworld run fill 464 65 11 464 144 11 air
execute in minecraft:overworld run fill 464 58 12 464 61 12 stone
execute in minecraft:overworld run fill 464 62 12 464 63 12 dirt
execute in minecraft:overworld run setblock 464 64 12 grass_block
execute in minecraft:overworld run fill 464 65 12 464 144 12 air
execute in minecraft:overworld run fill 464 58 13 464 61 13 stone
execute in minecraft:overworld run fill 464 62 13 464 63 13 dirt
execute in minecraft:overworld run setblock 464 64 13 grass_block
execute in minecraft:overworld run fill 464 65 13 464 144 13 air
execute in minecraft:overworld run fill 464 58 14 464 61 14 stone
execute in minecraft:overworld run fill 464 62 14 464 63 14 dirt
execute in minecraft:overworld run setblock 464 64 14 grass_block
execute in minecraft:overworld run fill 464 65 14 464 144 14 air
execute in minecraft:overworld run fill 464 58 15 464 61 15 stone
execute in minecraft:overworld run fill 464 62 15 464 63 15 dirt
schedule function blade_gallery:random/flowers/part_1 1t replace
