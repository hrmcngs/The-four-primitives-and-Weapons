execute in minecraft:overworld run setblock 366 71 20 coarse_dirt
execute in minecraft:overworld run fill 366 72 20 366 144 20 air
execute in minecraft:overworld run setblock 366 72 20 grass
execute in minecraft:overworld run fill 366 58 21 366 68 21 stone
execute in minecraft:overworld run fill 366 69 21 366 70 21 dirt
execute in minecraft:overworld run setblock 366 71 21 coarse_dirt
execute in minecraft:overworld run fill 366 72 21 366 144 21 air
execute in minecraft:overworld run fill 366 58 22 366 68 22 stone
execute in minecraft:overworld run fill 366 69 22 366 70 22 dirt
execute in minecraft:overworld run setblock 366 71 22 coarse_dirt
execute in minecraft:overworld run fill 366 72 22 366 144 22 air
execute in minecraft:overworld run fill 366 58 23 366 68 23 stone
execute in minecraft:overworld run fill 366 69 23 366 70 23 dirt
execute in minecraft:overworld run setblock 366 71 23 coarse_dirt
execute in minecraft:overworld run fill 366 72 23 366 144 23 air
execute in minecraft:overworld run fill 366 58 24 366 68 24 stone
execute in minecraft:overworld run fill 366 69 24 366 70 24 dirt
execute in minecraft:overworld run setblock 366 71 24 grass_block
execute in minecraft:overworld run fill 366 72 24 366 144 24 air
execute in minecraft:overworld run fill 366 58 25 366 68 25 stone
execute in minecraft:overworld run fill 366 69 25 366 70 25 dirt
execute in minecraft:overworld run setblock 366 71 25 grass_block
execute in minecraft:overworld run fill 366 72 25 366 144 25 air
execute in minecraft:overworld run fill 366 58 26 366 68 26 stone
execute in minecraft:overworld run fill 366 69 26 366 70 26 dirt
execute in minecraft:overworld run setblock 366 71 26 coarse_dirt
execute in minecraft:overworld run fill 366 72 26 366 144 26 air
execute in minecraft:overworld run fill 366 58 27 366 68 27 stone
execute in minecraft:overworld run fill 366 69 27 366 70 27 dirt
execute in minecraft:overworld run setblock 366 71 27 coarse_dirt
execute in minecraft:overworld run fill 366 72 27 366 144 27 air
execute in minecraft:overworld run fill 366 58 28 366 68 28 stone
execute in minecraft:overworld run fill 366 69 28 366 70 28 dirt
execute in minecraft:overworld run setblock 366 71 28 coarse_dirt
execute in minecraft:overworld run fill 366 72 28 366 144 28 air
execute in minecraft:overworld run fill 366 58 29 366 69 29 stone
execute in minecraft:overworld run fill 366 70 29 366 71 29 dirt
execute in minecraft:overworld run setblock 366 72 29 coarse_dirt
execute in minecraft:overworld run fill 366 73 29 366 144 29 air
execute in minecraft:overworld run fill 366 58 30 366 69 30 stone
execute in minecraft:overworld run fill 366 70 30 366 71 30 dirt
execute in minecraft:overworld run setblock 366 72 30 coarse_dirt
execute in minecraft:overworld run fill 366 73 30 366 144 30 air
execute in minecraft:overworld run fill 366 58 31 366 69 31 stone
execute in minecraft:overworld run fill 366 70 31 366 71 31 dirt
execute in minecraft:overworld run setblock 366 72 31 grass_block
execute in minecraft:overworld run fill 366 73 31 366 144 31 air
execute in minecraft:overworld run fill 366 58 32 366 70 32 stone
execute in minecraft:overworld run fill 366 71 32 366 72 32 dirt
execute in minecraft:overworld run setblock 366 73 32 grass_block
execute in minecraft:overworld run fill 366 74 32 366 144 32 air
execute in minecraft:overworld run setblock 366 74 32 grass
execute in minecraft:overworld run fill 366 58 33 366 70 33 stone
execute in minecraft:overworld run fill 366 71 33 366 72 33 dirt
execute in minecraft:overworld run setblock 366 73 33 grass_block
execute in minecraft:overworld run fill 366 74 33 366 144 33 air
execute in minecraft:overworld run fill 366 58 34 366 70 34 stone
execute in minecraft:overworld run fill 366 71 34 366 72 34 dirt
execute in minecraft:overworld run setblock 366 73 34 coarse_dirt
execute in minecraft:overworld run fill 366 74 34 366 144 34 air
execute in minecraft:overworld run fill 366 58 35 366 70 35 stone
execute in minecraft:overworld run fill 366 71 35 366 72 35 dirt
execute in minecraft:overworld run setblock 366 73 35 coarse_dirt
execute in minecraft:overworld run fill 366 74 35 366 144 35 air
execute in minecraft:overworld run fill 366 58 36 366 70 36 stone
execute in minecraft:overworld run fill 366 71 36 366 72 36 dirt
execute in minecraft:overworld run setblock 366 73 36 coarse_dirt
execute in minecraft:overworld run fill 366 74 36 366 144 36 air
execute in minecraft:overworld run fill 366 58 37 366 70 37 stone
execute in minecraft:overworld run fill 366 71 37 366 72 37 dirt
execute in minecraft:overworld run setblock 366 73 37 coarse_dirt
execute in minecraft:overworld run fill 366 74 37 366 144 37 air
execute in minecraft:overworld run fill 366 58 38 366 70 38 stone
execute in minecraft:overworld run fill 366 71 38 366 72 38 dirt
execute in minecraft:overworld run setblock 366 73 38 coarse_dirt
execute in minecraft:overworld run fill 366 74 38 366 144 38 air
execute in minecraft:overworld run setblock 366 74 38 grass
execute in minecraft:overworld run fill 366 58 39 366 69 39 stone
execute in minecraft:overworld run fill 366 70 39 366 71 39 dirt
execute in minecraft:overworld run setblock 366 72 39 coarse_dirt
execute in minecraft:overworld run fill 366 73 39 366 144 39 air
execute in minecraft:overworld run fill 366 58 40 366 68 40 stone
execute in minecraft:overworld run fill 366 69 40 366 70 40 dirt
execute in minecraft:overworld run setblock 366 71 40 coarse_dirt
execute in minecraft:overworld run fill 366 72 40 366 144 40 air
execute in minecraft:overworld run fill 366 58 41 366 67 41 stone
execute in minecraft:overworld run fill 366 68 41 366 69 41 dirt
execute in minecraft:overworld run setblock 366 70 41 coarse_dirt
execute in minecraft:overworld run fill 366 71 41 366 144 41 air
execute in minecraft:overworld run setblock 366 71 41 grass
execute in minecraft:overworld run fill 366 58 42 366 66 42 stone
execute in minecraft:overworld run fill 366 67 42 366 68 42 dirt
execute in minecraft:overworld run setblock 366 69 42 grass_block
execute in minecraft:overworld run fill 366 70 42 366 144 42 air
execute in minecraft:overworld run fill 366 58 43 366 66 43 stone
execute in minecraft:overworld run fill 366 67 43 366 68 43 dirt
execute in minecraft:overworld run setblock 366 69 43 coarse_dirt
execute in minecraft:overworld run fill 366 70 43 366 144 43 air
execute in minecraft:overworld run fill 366 58 44 366 65 44 stone
execute in minecraft:overworld run fill 366 66 44 366 67 44 dirt
execute in minecraft:overworld run setblock 366 68 44 grass_block
execute in minecraft:overworld run fill 366 69 44 366 144 44 air
execute in minecraft:overworld run fill 366 58 45 366 64 45 stone
execute in minecraft:overworld run fill 366 65 45 366 66 45 dirt
execute in minecraft:overworld run setblock 366 67 45 coarse_dirt
execute in minecraft:overworld run fill 366 68 45 366 144 45 air
execute in minecraft:overworld run fill 366 58 46 366 63 46 stone
execute in minecraft:overworld run fill 366 64 46 366 65 46 dirt
execute in minecraft:overworld run setblock 366 66 46 coarse_dirt
execute in minecraft:overworld run fill 366 67 46 366 144 46 air
execute in minecraft:overworld run fill 366 58 47 366 62 47 stone
execute in minecraft:overworld run fill 366 63 47 366 64 47 dirt
execute in minecraft:overworld run setblock 366 65 47 coarse_dirt
execute in minecraft:overworld run fill 366 66 47 366 144 47 air
execute in minecraft:overworld run fill 367 58 -48 367 61 -48 stone
execute in minecraft:overworld run fill 367 62 -48 367 63 -48 dirt
execute in minecraft:overworld run setblock 367 64 -48 coarse_dirt
execute in minecraft:overworld run fill 367 65 -48 367 144 -48 air
execute in minecraft:overworld run fill 367 58 -47 367 62 -47 stone
execute in minecraft:overworld run fill 367 63 -47 367 64 -47 dirt
execute in minecraft:overworld run setblock 367 65 -47 coarse_dirt
execute in minecraft:overworld run fill 367 66 -47 367 144 -47 air
execute in minecraft:overworld run fill 367 58 -46 367 64 -46 stone
execute in minecraft:overworld run fill 367 65 -46 367 66 -46 dirt
execute in minecraft:overworld run setblock 367 67 -46 coarse_dirt
execute in minecraft:overworld run fill 367 68 -46 367 144 -46 air
execute in minecraft:overworld run fill 367 58 -45 367 65 -45 stone
execute in minecraft:overworld run fill 367 66 -45 367 67 -45 dirt
execute in minecraft:overworld run setblock 367 68 -45 grass_block
execute in minecraft:overworld run fill 367 69 -45 367 144 -45 air
execute in minecraft:overworld run fill 367 58 -44 367 66 -44 stone
execute in minecraft:overworld run fill 367 67 -44 367 68 -44 dirt
execute in minecraft:overworld run setblock 367 69 -44 coarse_dirt
execute in minecraft:overworld run fill 367 70 -44 367 144 -44 air
execute in minecraft:overworld run fill 367 58 -43 367 67 -43 stone
execute in minecraft:overworld run fill 367 68 -43 367 69 -43 dirt
execute in minecraft:overworld run setblock 367 70 -43 coarse_dirt
execute in minecraft:overworld run fill 367 71 -43 367 144 -43 air
execute in minecraft:overworld run fill 367 58 -42 367 69 -42 stone
execute in minecraft:overworld run fill 367 70 -42 367 71 -42 dirt
execute in minecraft:overworld run setblock 367 72 -42 grass_block
execute in minecraft:overworld run fill 367 73 -42 367 144 -42 air
execute in minecraft:overworld run fill 367 58 -41 367 70 -41 stone
execute in minecraft:overworld run fill 367 71 -41 367 72 -41 dirt
execute in minecraft:overworld run setblock 367 73 -41 coarse_dirt
execute in minecraft:overworld run fill 367 74 -41 367 144 -41 air
execute in minecraft:overworld run setblock 367 74 -41 grass
execute in minecraft:overworld run fill 367 58 -40 367 71 -40 stone
execute in minecraft:overworld run fill 367 72 -40 367 73 -40 dirt
execute in minecraft:overworld run setblock 367 74 -40 grass_block
execute in minecraft:overworld run fill 367 75 -40 367 144 -40 air
execute in minecraft:overworld run fill 367 58 -39 367 72 -39 stone
execute in minecraft:overworld run fill 367 73 -39 367 74 -39 dirt
execute in minecraft:overworld run setblock 367 75 -39 grass_block
execute in minecraft:overworld run fill 367 76 -39 367 144 -39 air
execute in minecraft:overworld run fill 367 58 -38 367 73 -38 stone
execute in minecraft:overworld run fill 367 74 -38 367 75 -38 dirt
execute in minecraft:overworld run setblock 367 76 -38 coarse_dirt
execute in minecraft:overworld run fill 367 77 -38 367 144 -38 air
execute in minecraft:overworld run setblock 367 77 -38 grass
execute in minecraft:overworld run fill 367 58 -37 367 73 -37 stone
execute in minecraft:overworld run fill 367 74 -37 367 75 -37 dirt
execute in minecraft:overworld run setblock 367 76 -37 grass_block
execute in minecraft:overworld run fill 367 77 -37 367 144 -37 air
execute in minecraft:overworld run fill 367 58 -36 367 73 -36 stone
execute in minecraft:overworld run fill 367 74 -36 367 75 -36 dirt
execute in minecraft:overworld run setblock 367 76 -36 coarse_dirt
execute in minecraft:overworld run fill 367 77 -36 367 144 -36 air
execute in minecraft:overworld run fill 367 58 -35 367 73 -35 stone
execute in minecraft:overworld run fill 367 74 -35 367 75 -35 dirt
execute in minecraft:overworld run setblock 367 76 -35 coarse_dirt
execute in minecraft:overworld run fill 367 77 -35 367 144 -35 air
execute in minecraft:overworld run fill 367 58 -34 367 73 -34 stone
execute in minecraft:overworld run fill 367 74 -34 367 75 -34 dirt
execute in minecraft:overworld run setblock 367 76 -34 grass_block
execute in minecraft:overworld run fill 367 77 -34 367 144 -34 air
execute in minecraft:overworld run fill 367 58 -33 367 73 -33 stone
execute in minecraft:overworld run fill 367 74 -33 367 75 -33 dirt
execute in minecraft:overworld run setblock 367 76 -33 grass_block
execute in minecraft:overworld run fill 367 77 -33 367 144 -33 air
execute in minecraft:overworld run fill 367 58 -32 367 72 -32 stone
execute in minecraft:overworld run fill 367 73 -32 367 74 -32 dirt
execute in minecraft:overworld run setblock 367 75 -32 coarse_dirt
execute in minecraft:overworld run fill 367 76 -32 367 144 -32 air
execute in minecraft:overworld run fill 367 58 -31 367 72 -31 stone
execute in minecraft:overworld run fill 367 73 -31 367 74 -31 dirt
execute in minecraft:overworld run setblock 367 75 -31 coarse_dirt
execute in minecraft:overworld run fill 367 76 -31 367 144 -31 air
execute in minecraft:overworld run fill 367 58 -30 367 72 -30 stone
execute in minecraft:overworld run fill 367 73 -30 367 74 -30 dirt
execute in minecraft:overworld run setblock 367 75 -30 coarse_dirt
execute in minecraft:overworld run fill 367 76 -30 367 144 -30 air
execute in minecraft:overworld run fill 367 58 -29 367 72 -29 stone
execute in minecraft:overworld run fill 367 73 -29 367 74 -29 dirt
execute in minecraft:overworld run setblock 367 75 -29 coarse_dirt
execute in minecraft:overworld run fill 367 76 -29 367 144 -29 air
execute in minecraft:overworld run fill 367 58 -28 367 71 -28 stone
execute in minecraft:overworld run fill 367 72 -28 367 73 -28 dirt
execute in minecraft:overworld run setblock 367 74 -28 grass_block
execute in minecraft:overworld run fill 367 75 -28 367 144 -28 air
execute in minecraft:overworld run fill 367 58 -27 367 71 -27 stone
execute in minecraft:overworld run fill 367 72 -27 367 73 -27 dirt
execute in minecraft:overworld run setblock 367 74 -27 coarse_dirt
execute in minecraft:overworld run fill 367 75 -27 367 144 -27 air
execute in minecraft:overworld run fill 367 58 -26 367 71 -26 stone
execute in minecraft:overworld run fill 367 72 -26 367 73 -26 dirt
execute in minecraft:overworld run setblock 367 74 -26 grass_block
execute in minecraft:overworld run fill 367 75 -26 367 144 -26 air
execute in minecraft:overworld run fill 367 58 -25 367 71 -25 stone
execute in minecraft:overworld run fill 367 72 -25 367 73 -25 dirt
execute in minecraft:overworld run setblock 367 74 -25 coarse_dirt
execute in minecraft:overworld run fill 367 75 -25 367 144 -25 air
execute in minecraft:overworld run fill 367 58 -24 367 70 -24 stone
execute in minecraft:overworld run fill 367 71 -24 367 72 -24 dirt
execute in minecraft:overworld run setblock 367 73 -24 coarse_dirt
execute in minecraft:overworld run fill 367 74 -24 367 144 -24 air
execute in minecraft:overworld run fill 367 58 -23 367 70 -23 stone
execute in minecraft:overworld run fill 367 71 -23 367 72 -23 dirt
execute in minecraft:overworld run setblock 367 73 -23 coarse_dirt
execute in minecraft:overworld run fill 367 74 -23 367 144 -23 air
execute in minecraft:overworld run fill 367 58 -22 367 69 -22 stone
execute in minecraft:overworld run fill 367 70 -22 367 71 -22 dirt
execute in minecraft:overworld run setblock 367 72 -22 coarse_dirt
execute in minecraft:overworld run fill 367 73 -22 367 144 -22 air
execute in minecraft:overworld run fill 367 58 -21 367 69 -21 stone
execute in minecraft:overworld run fill 367 70 -21 367 71 -21 dirt
execute in minecraft:overworld run setblock 367 72 -21 grass_block
execute in minecraft:overworld run fill 367 73 -21 367 144 -21 air
execute in minecraft:overworld run fill 367 58 -20 367 69 -20 stone
execute in minecraft:overworld run fill 367 70 -20 367 71 -20 dirt
execute in minecraft:overworld run setblock 367 72 -20 coarse_dirt
execute in minecraft:overworld run fill 367 73 -20 367 144 -20 air
execute in minecraft:overworld run fill 367 58 -19 367 68 -19 stone
execute in minecraft:overworld run fill 367 69 -19 367 70 -19 dirt
execute in minecraft:overworld run setblock 367 71 -19 grass_block
execute in minecraft:overworld run fill 367 72 -19 367 144 -19 air
execute in minecraft:overworld run setblock 367 72 -19 grass
execute in minecraft:overworld run fill 367 58 -18 367 68 -18 stone
execute in minecraft:overworld run fill 367 69 -18 367 70 -18 dirt
execute in minecraft:overworld run setblock 367 71 -18 grass_block
execute in minecraft:overworld run fill 367 72 -18 367 144 -18 air
execute in minecraft:overworld run fill 367 58 -17 367 68 -17 stone
execute in minecraft:overworld run fill 367 69 -17 367 70 -17 dirt
execute in minecraft:overworld run setblock 367 71 -17 coarse_dirt
execute in minecraft:overworld run fill 367 72 -17 367 144 -17 air
execute in minecraft:overworld run fill 367 58 -16 367 67 -16 stone
execute in minecraft:overworld run fill 367 68 -16 367 69 -16 dirt
execute in minecraft:overworld run setblock 367 70 -16 coarse_dirt
execute in minecraft:overworld run fill 367 71 -16 367 144 -16 air
execute in minecraft:overworld run fill 367 58 -15 367 67 -15 stone
execute in minecraft:overworld run fill 367 68 -15 367 69 -15 dirt
execute in minecraft:overworld run setblock 367 70 -15 coarse_dirt
execute in minecraft:overworld run fill 367 71 -15 367 144 -15 air
execute in minecraft:overworld run fill 367 58 -14 367 66 -14 stone
execute in minecraft:overworld run fill 367 67 -14 367 68 -14 dirt
execute in minecraft:overworld run setblock 367 69 -14 coarse_dirt
schedule function blade_gallery:random/battlefield/part_48 1t replace
