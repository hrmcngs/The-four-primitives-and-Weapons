execute in minecraft:overworld run setblock 340 65 15 coarse_dirt
execute in minecraft:overworld run fill 340 66 15 340 144 15 air
execute in minecraft:overworld run fill 340 58 16 340 62 16 stone
execute in minecraft:overworld run fill 340 63 16 340 64 16 dirt
execute in minecraft:overworld run setblock 340 65 16 coarse_dirt
execute in minecraft:overworld run fill 340 66 16 340 144 16 air
execute in minecraft:overworld run fill 340 58 17 340 62 17 stone
execute in minecraft:overworld run fill 340 63 17 340 64 17 dirt
execute in minecraft:overworld run setblock 340 65 17 grass_block
execute in minecraft:overworld run fill 340 66 17 340 144 17 air
execute in minecraft:overworld run fill 340 58 18 340 62 18 stone
execute in minecraft:overworld run fill 340 63 18 340 64 18 dirt
execute in minecraft:overworld run setblock 340 65 18 coarse_dirt
execute in minecraft:overworld run fill 340 66 18 340 144 18 air
execute in minecraft:overworld run fill 340 58 19 340 62 19 stone
execute in minecraft:overworld run fill 340 63 19 340 64 19 dirt
execute in minecraft:overworld run setblock 340 65 19 coarse_dirt
execute in minecraft:overworld run fill 340 66 19 340 144 19 air
execute in minecraft:overworld run fill 340 58 20 340 62 20 stone
execute in minecraft:overworld run fill 340 63 20 340 64 20 dirt
execute in minecraft:overworld run setblock 340 65 20 coarse_dirt
execute in minecraft:overworld run fill 340 66 20 340 144 20 air
execute in minecraft:overworld run fill 340 58 21 340 62 21 stone
execute in minecraft:overworld run fill 340 63 21 340 64 21 dirt
execute in minecraft:overworld run setblock 340 65 21 coarse_dirt
execute in minecraft:overworld run fill 340 66 21 340 144 21 air
execute in minecraft:overworld run fill 340 58 22 340 62 22 stone
execute in minecraft:overworld run fill 340 63 22 340 64 22 dirt
execute in minecraft:overworld run setblock 340 65 22 coarse_dirt
execute in minecraft:overworld run fill 340 66 22 340 144 22 air
execute in minecraft:overworld run fill 340 58 23 340 62 23 stone
execute in minecraft:overworld run fill 340 63 23 340 64 23 dirt
execute in minecraft:overworld run setblock 340 65 23 coarse_dirt
execute in minecraft:overworld run fill 340 66 23 340 144 23 air
execute in minecraft:overworld run fill 340 58 24 340 62 24 stone
execute in minecraft:overworld run fill 340 63 24 340 64 24 dirt
execute in minecraft:overworld run setblock 340 65 24 coarse_dirt
execute in minecraft:overworld run fill 340 66 24 340 144 24 air
execute in minecraft:overworld run fill 340 58 25 340 62 25 stone
execute in minecraft:overworld run fill 340 63 25 340 64 25 dirt
execute in minecraft:overworld run setblock 340 65 25 coarse_dirt
execute in minecraft:overworld run fill 340 66 25 340 144 25 air
execute in minecraft:overworld run fill 340 58 26 340 62 26 stone
execute in minecraft:overworld run fill 340 63 26 340 64 26 dirt
execute in minecraft:overworld run setblock 340 65 26 coarse_dirt
execute in minecraft:overworld run fill 340 66 26 340 144 26 air
execute in minecraft:overworld run fill 340 58 27 340 62 27 stone
execute in minecraft:overworld run fill 340 63 27 340 64 27 dirt
execute in minecraft:overworld run setblock 340 65 27 grass_block
execute in minecraft:overworld run fill 340 66 27 340 144 27 air
execute in minecraft:overworld run fill 340 58 28 340 62 28 stone
execute in minecraft:overworld run fill 340 63 28 340 64 28 dirt
execute in minecraft:overworld run setblock 340 65 28 coarse_dirt
execute in minecraft:overworld run fill 340 66 28 340 144 28 air
execute in minecraft:overworld run fill 340 58 29 340 62 29 stone
execute in minecraft:overworld run fill 340 63 29 340 64 29 dirt
execute in minecraft:overworld run setblock 340 65 29 coarse_dirt
execute in minecraft:overworld run fill 340 66 29 340 144 29 air
execute in minecraft:overworld run fill 340 58 30 340 62 30 stone
execute in minecraft:overworld run fill 340 63 30 340 64 30 dirt
execute in minecraft:overworld run setblock 340 65 30 coarse_dirt
execute in minecraft:overworld run fill 340 66 30 340 144 30 air
execute in minecraft:overworld run fill 340 58 31 340 62 31 stone
execute in minecraft:overworld run fill 340 63 31 340 64 31 dirt
execute in minecraft:overworld run setblock 340 65 31 grass_block
execute in minecraft:overworld run fill 340 66 31 340 144 31 air
execute in minecraft:overworld run fill 340 58 32 340 62 32 stone
execute in minecraft:overworld run fill 340 63 32 340 64 32 dirt
execute in minecraft:overworld run setblock 340 65 32 coarse_dirt
execute in minecraft:overworld run fill 340 66 32 340 144 32 air
execute in minecraft:overworld run fill 340 58 33 340 62 33 stone
execute in minecraft:overworld run fill 340 63 33 340 64 33 dirt
execute in minecraft:overworld run setblock 340 65 33 coarse_dirt
execute in minecraft:overworld run fill 340 66 33 340 144 33 air
execute in minecraft:overworld run fill 340 58 34 340 62 34 stone
execute in minecraft:overworld run fill 340 63 34 340 64 34 dirt
execute in minecraft:overworld run setblock 340 65 34 coarse_dirt
execute in minecraft:overworld run fill 340 66 34 340 144 34 air
execute in minecraft:overworld run fill 340 58 35 340 62 35 stone
execute in minecraft:overworld run fill 340 63 35 340 64 35 dirt
execute in minecraft:overworld run setblock 340 65 35 coarse_dirt
execute in minecraft:overworld run fill 340 66 35 340 144 35 air
execute in minecraft:overworld run fill 340 58 36 340 62 36 stone
execute in minecraft:overworld run fill 340 63 36 340 64 36 dirt
execute in minecraft:overworld run setblock 340 65 36 grass_block
execute in minecraft:overworld run fill 340 66 36 340 144 36 air
execute in minecraft:overworld run fill 340 58 37 340 62 37 stone
execute in minecraft:overworld run fill 340 63 37 340 64 37 dirt
execute in minecraft:overworld run setblock 340 65 37 coarse_dirt
execute in minecraft:overworld run fill 340 66 37 340 144 37 air
execute in minecraft:overworld run fill 340 58 38 340 62 38 stone
execute in minecraft:overworld run fill 340 63 38 340 64 38 dirt
execute in minecraft:overworld run setblock 340 65 38 coarse_dirt
execute in minecraft:overworld run fill 340 66 38 340 144 38 air
execute in minecraft:overworld run fill 340 58 39 340 62 39 stone
execute in minecraft:overworld run fill 340 63 39 340 64 39 dirt
execute in minecraft:overworld run setblock 340 65 39 coarse_dirt
execute in minecraft:overworld run fill 340 66 39 340 144 39 air
execute in minecraft:overworld run fill 340 58 40 340 62 40 stone
execute in minecraft:overworld run fill 340 63 40 340 64 40 dirt
execute in minecraft:overworld run setblock 340 65 40 coarse_dirt
execute in minecraft:overworld run fill 340 66 40 340 144 40 air
execute in minecraft:overworld run fill 340 58 41 340 62 41 stone
execute in minecraft:overworld run fill 340 63 41 340 64 41 dirt
execute in minecraft:overworld run setblock 340 65 41 grass_block
execute in minecraft:overworld run fill 340 66 41 340 144 41 air
execute in minecraft:overworld run fill 340 58 42 340 62 42 stone
execute in minecraft:overworld run fill 340 63 42 340 64 42 dirt
execute in minecraft:overworld run setblock 340 65 42 coarse_dirt
execute in minecraft:overworld run fill 340 66 42 340 144 42 air
execute in minecraft:overworld run fill 340 58 43 340 62 43 stone
execute in minecraft:overworld run fill 340 63 43 340 64 43 dirt
execute in minecraft:overworld run setblock 340 65 43 grass_block
execute in minecraft:overworld run fill 340 66 43 340 144 43 air
execute in minecraft:overworld run fill 340 58 44 340 62 44 stone
execute in minecraft:overworld run fill 340 63 44 340 64 44 dirt
execute in minecraft:overworld run setblock 340 65 44 grass_block
execute in minecraft:overworld run fill 340 66 44 340 144 44 air
execute in minecraft:overworld run fill 340 58 45 340 62 45 stone
execute in minecraft:overworld run fill 340 63 45 340 64 45 dirt
execute in minecraft:overworld run setblock 340 65 45 coarse_dirt
execute in minecraft:overworld run fill 340 66 45 340 144 45 air
execute in minecraft:overworld run fill 340 58 46 340 62 46 stone
execute in minecraft:overworld run fill 340 63 46 340 64 46 dirt
execute in minecraft:overworld run setblock 340 65 46 grass_block
execute in minecraft:overworld run fill 340 66 46 340 144 46 air
execute in minecraft:overworld run fill 340 58 47 340 61 47 stone
execute in minecraft:overworld run fill 340 62 47 340 63 47 dirt
execute in minecraft:overworld run setblock 340 64 47 coarse_dirt
execute in minecraft:overworld run fill 340 65 47 340 144 47 air
execute in minecraft:overworld run fill 341 58 -48 341 61 -48 stone
execute in minecraft:overworld run fill 341 62 -48 341 63 -48 dirt
execute in minecraft:overworld run setblock 341 64 -48 coarse_dirt
execute in minecraft:overworld run fill 341 65 -48 341 144 -48 air
execute in minecraft:overworld run fill 341 58 -47 341 63 -47 stone
execute in minecraft:overworld run fill 341 64 -47 341 65 -47 dirt
execute in minecraft:overworld run setblock 341 66 -47 grass_block
execute in minecraft:overworld run fill 341 67 -47 341 144 -47 air
execute in minecraft:overworld run fill 341 58 -46 341 65 -46 stone
execute in minecraft:overworld run fill 341 66 -46 341 67 -46 dirt
execute in minecraft:overworld run setblock 341 68 -46 coarse_dirt
execute in minecraft:overworld run fill 341 69 -46 341 144 -46 air
execute in minecraft:overworld run fill 341 58 -45 341 66 -45 stone
execute in minecraft:overworld run fill 341 67 -45 341 68 -45 dirt
execute in minecraft:overworld run setblock 341 69 -45 grass_block
execute in minecraft:overworld run fill 341 70 -45 341 144 -45 air
execute in minecraft:overworld run fill 341 58 -44 341 68 -44 stone
execute in minecraft:overworld run fill 341 69 -44 341 70 -44 dirt
execute in minecraft:overworld run setblock 341 71 -44 coarse_dirt
execute in minecraft:overworld run fill 341 72 -44 341 144 -44 air
execute in minecraft:overworld run fill 341 58 -43 341 70 -43 stone
execute in minecraft:overworld run fill 341 71 -43 341 72 -43 dirt
execute in minecraft:overworld run setblock 341 73 -43 grass_block
execute in minecraft:overworld run fill 341 74 -43 341 144 -43 air
execute in minecraft:overworld run fill 341 58 -42 341 70 -42 stone
execute in minecraft:overworld run fill 341 71 -42 341 72 -42 dirt
execute in minecraft:overworld run setblock 341 73 -42 coarse_dirt
execute in minecraft:overworld run fill 341 74 -42 341 144 -42 air
execute in minecraft:overworld run fill 341 58 -41 341 70 -41 stone
execute in minecraft:overworld run fill 341 71 -41 341 72 -41 dirt
execute in minecraft:overworld run setblock 341 73 -41 grass_block
execute in minecraft:overworld run fill 341 74 -41 341 144 -41 air
execute in minecraft:overworld run fill 341 58 -40 341 69 -40 stone
execute in minecraft:overworld run fill 341 70 -40 341 71 -40 dirt
execute in minecraft:overworld run setblock 341 72 -40 coarse_dirt
execute in minecraft:overworld run fill 341 73 -40 341 144 -40 air
execute in minecraft:overworld run fill 341 58 -39 341 69 -39 stone
execute in minecraft:overworld run fill 341 70 -39 341 71 -39 dirt
execute in minecraft:overworld run setblock 341 72 -39 coarse_dirt
execute in minecraft:overworld run fill 341 73 -39 341 144 -39 air
execute in minecraft:overworld run fill 341 58 -38 341 69 -38 stone
execute in minecraft:overworld run fill 341 70 -38 341 71 -38 dirt
execute in minecraft:overworld run setblock 341 72 -38 coarse_dirt
execute in minecraft:overworld run fill 341 73 -38 341 144 -38 air
execute in minecraft:overworld run fill 341 58 -37 341 69 -37 stone
execute in minecraft:overworld run fill 341 70 -37 341 71 -37 dirt
execute in minecraft:overworld run setblock 341 72 -37 coarse_dirt
execute in minecraft:overworld run fill 341 73 -37 341 144 -37 air
execute in minecraft:overworld run fill 341 58 -36 341 69 -36 stone
execute in minecraft:overworld run fill 341 70 -36 341 71 -36 dirt
execute in minecraft:overworld run setblock 341 72 -36 coarse_dirt
execute in minecraft:overworld run fill 341 73 -36 341 144 -36 air
execute in minecraft:overworld run fill 341 58 -35 341 69 -35 stone
execute in minecraft:overworld run fill 341 70 -35 341 71 -35 dirt
execute in minecraft:overworld run setblock 341 72 -35 coarse_dirt
execute in minecraft:overworld run fill 341 73 -35 341 144 -35 air
execute in minecraft:overworld run fill 341 58 -34 341 69 -34 stone
execute in minecraft:overworld run fill 341 70 -34 341 71 -34 dirt
execute in minecraft:overworld run setblock 341 72 -34 coarse_dirt
execute in minecraft:overworld run fill 341 73 -34 341 144 -34 air
execute in minecraft:overworld run fill 341 58 -33 341 69 -33 stone
execute in minecraft:overworld run fill 341 70 -33 341 71 -33 dirt
execute in minecraft:overworld run setblock 341 72 -33 grass_block
execute in minecraft:overworld run fill 341 73 -33 341 144 -33 air
execute in minecraft:overworld run fill 341 58 -32 341 68 -32 stone
execute in minecraft:overworld run fill 341 69 -32 341 70 -32 dirt
execute in minecraft:overworld run setblock 341 71 -32 grass_block
execute in minecraft:overworld run fill 341 72 -32 341 144 -32 air
execute in minecraft:overworld run fill 341 58 -31 341 68 -31 stone
execute in minecraft:overworld run fill 341 69 -31 341 70 -31 dirt
execute in minecraft:overworld run setblock 341 71 -31 coarse_dirt
execute in minecraft:overworld run fill 341 72 -31 341 144 -31 air
execute in minecraft:overworld run fill 341 58 -30 341 68 -30 stone
execute in minecraft:overworld run fill 341 69 -30 341 70 -30 dirt
execute in minecraft:overworld run setblock 341 71 -30 grass_block
execute in minecraft:overworld run fill 341 72 -30 341 144 -30 air
execute in minecraft:overworld run fill 341 58 -29 341 68 -29 stone
execute in minecraft:overworld run fill 341 69 -29 341 70 -29 dirt
execute in minecraft:overworld run setblock 341 71 -29 coarse_dirt
execute in minecraft:overworld run fill 341 72 -29 341 144 -29 air
execute in minecraft:overworld run fill 341 58 -28 341 68 -28 stone
execute in minecraft:overworld run fill 341 69 -28 341 70 -28 dirt
execute in minecraft:overworld run setblock 341 71 -28 coarse_dirt
execute in minecraft:overworld run fill 341 72 -28 341 144 -28 air
execute in minecraft:overworld run fill 341 58 -27 341 67 -27 stone
execute in minecraft:overworld run fill 341 68 -27 341 69 -27 dirt
execute in minecraft:overworld run setblock 341 70 -27 coarse_dirt
execute in minecraft:overworld run fill 341 71 -27 341 144 -27 air
execute in minecraft:overworld run fill 341 58 -26 341 67 -26 stone
execute in minecraft:overworld run fill 341 68 -26 341 69 -26 dirt
execute in minecraft:overworld run setblock 341 70 -26 grass_block
execute in minecraft:overworld run fill 341 71 -26 341 144 -26 air
execute in minecraft:overworld run fill 341 58 -25 341 67 -25 stone
execute in minecraft:overworld run fill 341 68 -25 341 69 -25 dirt
execute in minecraft:overworld run setblock 341 70 -25 coarse_dirt
execute in minecraft:overworld run fill 341 71 -25 341 144 -25 air
execute in minecraft:overworld run fill 341 58 -24 341 67 -24 stone
execute in minecraft:overworld run fill 341 68 -24 341 69 -24 dirt
execute in minecraft:overworld run setblock 341 70 -24 grass_block
execute in minecraft:overworld run fill 341 71 -24 341 144 -24 air
execute in minecraft:overworld run fill 341 58 -23 341 67 -23 stone
execute in minecraft:overworld run fill 341 68 -23 341 69 -23 dirt
execute in minecraft:overworld run setblock 341 70 -23 coarse_dirt
execute in minecraft:overworld run fill 341 71 -23 341 144 -23 air
execute in minecraft:overworld run fill 341 58 -22 341 67 -22 stone
execute in minecraft:overworld run fill 341 68 -22 341 69 -22 dirt
execute in minecraft:overworld run setblock 341 70 -22 coarse_dirt
execute in minecraft:overworld run fill 341 71 -22 341 144 -22 air
execute in minecraft:overworld run fill 341 58 -21 341 67 -21 stone
execute in minecraft:overworld run fill 341 68 -21 341 69 -21 dirt
execute in minecraft:overworld run setblock 341 70 -21 grass_block
execute in minecraft:overworld run fill 341 71 -21 341 144 -21 air
execute in minecraft:overworld run fill 341 58 -20 341 66 -20 stone
execute in minecraft:overworld run fill 341 67 -20 341 68 -20 dirt
execute in minecraft:overworld run setblock 341 69 -20 coarse_dirt
execute in minecraft:overworld run fill 341 70 -20 341 144 -20 air
execute in minecraft:overworld run fill 341 58 -19 341 66 -19 stone
execute in minecraft:overworld run fill 341 67 -19 341 68 -19 dirt
execute in minecraft:overworld run setblock 341 69 -19 grass_block
execute in minecraft:overworld run fill 341 70 -19 341 144 -19 air
execute in minecraft:overworld run fill 341 58 -18 341 66 -18 stone
execute in minecraft:overworld run fill 341 67 -18 341 68 -18 dirt
execute in minecraft:overworld run setblock 341 69 -18 coarse_dirt
execute in minecraft:overworld run fill 341 70 -18 341 144 -18 air
execute in minecraft:overworld run fill 341 58 -17 341 66 -17 stone
execute in minecraft:overworld run fill 341 67 -17 341 68 -17 dirt
schedule function blade_gallery:random/battlefield/part_8 1t replace
