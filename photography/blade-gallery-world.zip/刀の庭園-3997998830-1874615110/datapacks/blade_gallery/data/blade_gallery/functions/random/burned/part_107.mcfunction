execute in minecraft:overworld run fill 275 58 -14 275 69 -14 stone
execute in minecraft:overworld run fill 275 70 -14 275 71 -14 dirt
execute in minecraft:overworld run setblock 275 72 -14 coarse_dirt
execute in minecraft:overworld run fill 275 73 -14 275 144 -14 air
execute in minecraft:overworld run setblock 275 73 -14 grass
execute in minecraft:overworld run fill 275 58 -13 275 68 -13 stone
execute in minecraft:overworld run fill 275 69 -13 275 70 -13 dirt
execute in minecraft:overworld run setblock 275 71 -13 coarse_dirt
execute in minecraft:overworld run fill 275 72 -13 275 144 -13 air
execute in minecraft:overworld run fill 275 58 -12 275 67 -12 stone
execute in minecraft:overworld run fill 275 68 -12 275 69 -12 dirt
execute in minecraft:overworld run setblock 275 70 -12 coarse_dirt
execute in minecraft:overworld run fill 275 71 -12 275 144 -12 air
execute in minecraft:overworld run fill 275 58 -11 275 67 -11 stone
execute in minecraft:overworld run fill 275 68 -11 275 69 -11 dirt
execute in minecraft:overworld run setblock 275 70 -11 coarse_dirt
execute in minecraft:overworld run fill 275 71 -11 275 144 -11 air
execute in minecraft:overworld run setblock 275 71 -11 mossy_cobblestone
execute in minecraft:overworld run fill 275 58 -10 275 67 -10 stone
execute in minecraft:overworld run fill 275 68 -10 275 69 -10 dirt
execute in minecraft:overworld run setblock 275 70 -10 grass_block
execute in minecraft:overworld run fill 275 71 -10 275 144 -10 air
execute in minecraft:overworld run setblock 275 71 -10 mossy_cobblestone
execute in minecraft:overworld run fill 275 58 -9 275 66 -9 stone
execute in minecraft:overworld run fill 275 67 -9 275 68 -9 dirt
execute in minecraft:overworld run setblock 275 69 -9 grass_block
execute in minecraft:overworld run fill 275 70 -9 275 144 -9 air
execute in minecraft:overworld run fill 275 58 -8 275 66 -8 stone
execute in minecraft:overworld run fill 275 67 -8 275 68 -8 dirt
execute in minecraft:overworld run setblock 275 69 -8 grass_block
execute in minecraft:overworld run fill 275 70 -8 275 144 -8 air
execute in minecraft:overworld run fill 275 58 -7 275 66 -7 stone
execute in minecraft:overworld run fill 275 67 -7 275 68 -7 dirt
execute in minecraft:overworld run setblock 275 69 -7 coarse_dirt
execute in minecraft:overworld run fill 275 70 -7 275 144 -7 air
execute in minecraft:overworld run fill 275 58 -6 275 66 -6 stone
execute in minecraft:overworld run fill 275 67 -6 275 68 -6 dirt
execute in minecraft:overworld run setblock 275 69 -6 coarse_dirt
execute in minecraft:overworld run fill 275 70 -6 275 144 -6 air
execute in minecraft:overworld run fill 275 58 -5 275 65 -5 stone
execute in minecraft:overworld run fill 275 66 -5 275 67 -5 dirt
execute in minecraft:overworld run setblock 275 68 -5 grass_block
execute in minecraft:overworld run fill 275 69 -5 275 144 -5 air
execute in minecraft:overworld run fill 275 58 -4 275 65 -4 stone
execute in minecraft:overworld run fill 275 66 -4 275 67 -4 dirt
execute in minecraft:overworld run setblock 275 68 -4 coarse_dirt
execute in minecraft:overworld run fill 275 69 -4 275 144 -4 air
execute in minecraft:overworld run fill 275 58 -3 275 65 -3 stone
execute in minecraft:overworld run fill 275 66 -3 275 67 -3 dirt
execute in minecraft:overworld run setblock 275 68 -3 coarse_dirt
execute in minecraft:overworld run fill 275 69 -3 275 144 -3 air
execute in minecraft:overworld run setblock 275 69 -3 mossy_cobblestone
execute in minecraft:overworld run fill 275 58 -2 275 65 -2 stone
execute in minecraft:overworld run fill 275 66 -2 275 67 -2 dirt
execute in minecraft:overworld run setblock 275 68 -2 coarse_dirt
execute in minecraft:overworld run fill 275 69 -2 275 144 -2 air
execute in minecraft:overworld run fill 275 58 -1 275 64 -1 stone
execute in minecraft:overworld run fill 275 65 -1 275 66 -1 dirt
execute in minecraft:overworld run setblock 275 67 -1 coarse_dirt
execute in minecraft:overworld run fill 275 68 -1 275 144 -1 air
execute in minecraft:overworld run fill 275 58 0 275 64 0 stone
execute in minecraft:overworld run fill 275 65 0 275 66 0 dirt
execute in minecraft:overworld run setblock 275 67 0 grass_block
execute in minecraft:overworld run fill 275 68 0 275 144 0 air
execute in minecraft:overworld run fill 275 58 1 275 64 1 stone
execute in minecraft:overworld run fill 275 65 1 275 66 1 dirt
execute in minecraft:overworld run setblock 275 67 1 coarse_dirt
execute in minecraft:overworld run fill 275 68 1 275 144 1 air
execute in minecraft:overworld run fill 275 58 2 275 64 2 stone
execute in minecraft:overworld run fill 275 65 2 275 66 2 dirt
execute in minecraft:overworld run setblock 275 67 2 grass_block
execute in minecraft:overworld run fill 275 68 2 275 144 2 air
execute in minecraft:overworld run fill 275 58 3 275 64 3 stone
execute in minecraft:overworld run fill 275 65 3 275 66 3 dirt
execute in minecraft:overworld run setblock 275 67 3 coarse_dirt
execute in minecraft:overworld run fill 275 68 3 275 144 3 air
execute in minecraft:overworld run fill 275 58 4 275 63 4 stone
execute in minecraft:overworld run fill 275 64 4 275 65 4 dirt
execute in minecraft:overworld run setblock 275 66 4 coarse_dirt
execute in minecraft:overworld run fill 275 67 4 275 144 4 air
execute in minecraft:overworld run fill 275 58 5 275 63 5 stone
execute in minecraft:overworld run fill 275 64 5 275 65 5 dirt
execute in minecraft:overworld run setblock 275 66 5 coarse_dirt
execute in minecraft:overworld run fill 275 67 5 275 144 5 air
execute in minecraft:overworld run fill 275 58 6 275 63 6 stone
execute in minecraft:overworld run fill 275 64 6 275 65 6 dirt
execute in minecraft:overworld run setblock 275 66 6 coarse_dirt
execute in minecraft:overworld run fill 275 67 6 275 144 6 air
execute in minecraft:overworld run fill 275 58 7 275 63 7 stone
execute in minecraft:overworld run fill 275 64 7 275 65 7 dirt
execute in minecraft:overworld run setblock 275 66 7 coarse_dirt
execute in minecraft:overworld run fill 275 67 7 275 144 7 air
execute in minecraft:overworld run fill 275 58 8 275 62 8 stone
execute in minecraft:overworld run fill 275 63 8 275 64 8 dirt
execute in minecraft:overworld run setblock 275 65 8 coarse_dirt
execute in minecraft:overworld run fill 275 66 8 275 144 8 air
execute in minecraft:overworld run fill 275 58 9 275 62 9 stone
execute in minecraft:overworld run fill 275 63 9 275 64 9 dirt
execute in minecraft:overworld run setblock 275 65 9 coarse_dirt
execute in minecraft:overworld run fill 275 66 9 275 144 9 air
execute in minecraft:overworld run fill 275 58 10 275 62 10 stone
execute in minecraft:overworld run fill 275 63 10 275 64 10 dirt
execute in minecraft:overworld run setblock 275 65 10 coarse_dirt
execute in minecraft:overworld run fill 275 66 10 275 144 10 air
execute in minecraft:overworld run fill 275 58 11 275 62 11 stone
execute in minecraft:overworld run fill 275 63 11 275 64 11 dirt
execute in minecraft:overworld run setblock 275 65 11 coarse_dirt
execute in minecraft:overworld run fill 275 66 11 275 144 11 air
execute in minecraft:overworld run setblock 275 66 11 grass
execute in minecraft:overworld run fill 275 58 12 275 61 12 stone
execute in minecraft:overworld run fill 275 62 12 275 63 12 dirt
execute in minecraft:overworld run setblock 275 64 12 coarse_dirt
execute in minecraft:overworld run fill 275 65 12 275 144 12 air
execute in minecraft:overworld run fill 275 58 13 275 61 13 stone
execute in minecraft:overworld run fill 275 62 13 275 63 13 dirt
execute in minecraft:overworld run setblock 275 64 13 coarse_dirt
execute in minecraft:overworld run fill 275 65 13 275 144 13 air
execute in minecraft:overworld run fill 275 58 14 275 61 14 stone
execute in minecraft:overworld run fill 275 62 14 275 63 14 dirt
execute in minecraft:overworld run setblock 275 64 14 coarse_dirt
execute in minecraft:overworld run fill 275 65 14 275 144 14 air
execute in minecraft:overworld run fill 275 58 15 275 61 15 stone
execute in minecraft:overworld run fill 275 62 15 275 63 15 dirt
execute in minecraft:overworld run setblock 275 64 15 grass_block
execute in minecraft:overworld run fill 275 65 15 275 144 15 air
execute in minecraft:overworld run fill 275 58 16 275 61 16 stone
execute in minecraft:overworld run fill 275 62 16 275 63 16 dirt
execute in minecraft:overworld run setblock 275 64 16 grass_block
execute in minecraft:overworld run fill 275 65 16 275 144 16 air
execute in minecraft:overworld run fill 275 58 17 275 61 17 stone
execute in minecraft:overworld run fill 275 62 17 275 63 17 dirt
execute in minecraft:overworld run setblock 275 64 17 coarse_dirt
execute in minecraft:overworld run fill 275 65 17 275 144 17 air
execute in minecraft:overworld run fill 275 58 18 275 61 18 stone
execute in minecraft:overworld run fill 275 62 18 275 63 18 dirt
execute in minecraft:overworld run setblock 275 64 18 coarse_dirt
execute in minecraft:overworld run fill 275 65 18 275 144 18 air
execute in minecraft:overworld run fill 275 58 19 275 61 19 stone
execute in minecraft:overworld run fill 275 62 19 275 63 19 dirt
execute in minecraft:overworld run setblock 275 64 19 coarse_dirt
execute in minecraft:overworld run fill 275 65 19 275 144 19 air
execute in minecraft:overworld run fill 275 58 20 275 61 20 stone
execute in minecraft:overworld run fill 275 62 20 275 63 20 dirt
execute in minecraft:overworld run setblock 275 64 20 coarse_dirt
execute in minecraft:overworld run fill 275 65 20 275 144 20 air
execute in minecraft:overworld run fill 275 58 21 275 61 21 stone
execute in minecraft:overworld run fill 275 62 21 275 63 21 dirt
execute in minecraft:overworld run setblock 275 64 21 grass_block
execute in minecraft:overworld run fill 275 65 21 275 144 21 air
execute in minecraft:overworld run fill 275 58 22 275 61 22 stone
execute in minecraft:overworld run fill 275 62 22 275 63 22 dirt
execute in minecraft:overworld run setblock 275 64 22 grass_block
execute in minecraft:overworld run fill 275 65 22 275 144 22 air
execute in minecraft:overworld run fill 275 58 23 275 61 23 stone
execute in minecraft:overworld run fill 275 62 23 275 63 23 dirt
execute in minecraft:overworld run setblock 275 64 23 coarse_dirt
execute in minecraft:overworld run fill 275 65 23 275 144 23 air
execute in minecraft:overworld run fill 275 58 24 275 61 24 stone
execute in minecraft:overworld run fill 275 62 24 275 63 24 dirt
execute in minecraft:overworld run setblock 275 64 24 coarse_dirt
execute in minecraft:overworld run fill 275 65 24 275 144 24 air
execute in minecraft:overworld run fill 275 58 25 275 61 25 stone
execute in minecraft:overworld run fill 275 62 25 275 63 25 dirt
execute in minecraft:overworld run setblock 275 64 25 coarse_dirt
execute in minecraft:overworld run fill 275 65 25 275 144 25 air
execute in minecraft:overworld run fill 275 58 26 275 61 26 stone
execute in minecraft:overworld run fill 275 62 26 275 63 26 dirt
execute in minecraft:overworld run setblock 275 64 26 coarse_dirt
execute in minecraft:overworld run fill 275 65 26 275 144 26 air
execute in minecraft:overworld run fill 275 58 27 275 61 27 stone
execute in minecraft:overworld run fill 275 62 27 275 63 27 dirt
execute in minecraft:overworld run setblock 275 64 27 coarse_dirt
execute in minecraft:overworld run fill 275 65 27 275 144 27 air
execute in minecraft:overworld run fill 275 58 28 275 61 28 stone
execute in minecraft:overworld run fill 275 62 28 275 63 28 dirt
execute in minecraft:overworld run setblock 275 64 28 coarse_dirt
execute in minecraft:overworld run fill 275 65 28 275 144 28 air
execute in minecraft:overworld run fill 275 58 29 275 61 29 stone
execute in minecraft:overworld run fill 275 62 29 275 63 29 dirt
execute in minecraft:overworld run setblock 275 64 29 coarse_dirt
execute in minecraft:overworld run fill 275 65 29 275 144 29 air
execute in minecraft:overworld run fill 275 58 30 275 62 30 stone
execute in minecraft:overworld run fill 275 63 30 275 64 30 dirt
execute in minecraft:overworld run setblock 275 65 30 coarse_dirt
execute in minecraft:overworld run fill 275 66 30 275 144 30 air
execute in minecraft:overworld run fill 275 58 31 275 62 31 stone
execute in minecraft:overworld run fill 275 63 31 275 64 31 dirt
execute in minecraft:overworld run setblock 275 65 31 grass_block
execute in minecraft:overworld run fill 275 66 31 275 144 31 air
execute in minecraft:overworld run fill 275 58 32 275 62 32 stone
execute in minecraft:overworld run fill 275 63 32 275 64 32 dirt
execute in minecraft:overworld run setblock 275 65 32 coarse_dirt
execute in minecraft:overworld run fill 275 66 32 275 144 32 air
execute in minecraft:overworld run fill 275 58 33 275 61 33 stone
execute in minecraft:overworld run fill 275 62 33 275 63 33 dirt
execute in minecraft:overworld run setblock 275 64 33 coarse_dirt
execute in minecraft:overworld run fill 275 65 33 275 144 33 air
execute in minecraft:overworld run fill 275 58 34 275 61 34 stone
execute in minecraft:overworld run fill 275 62 34 275 63 34 dirt
execute in minecraft:overworld run setblock 275 64 34 coarse_dirt
execute in minecraft:overworld run fill 275 65 34 275 144 34 air
execute in minecraft:overworld run fill 275 58 35 275 61 35 stone
execute in minecraft:overworld run fill 275 62 35 275 63 35 dirt
execute in minecraft:overworld run setblock 275 64 35 grass_block
execute in minecraft:overworld run fill 275 65 35 275 144 35 air
execute in minecraft:overworld run fill 275 58 36 275 61 36 stone
execute in minecraft:overworld run fill 275 62 36 275 63 36 dirt
execute in minecraft:overworld run setblock 275 64 36 coarse_dirt
execute in minecraft:overworld run fill 275 65 36 275 144 36 air
execute in minecraft:overworld run fill 275 58 37 275 62 37 stone
execute in minecraft:overworld run fill 275 63 37 275 64 37 dirt
execute in minecraft:overworld run setblock 275 65 37 coarse_dirt
execute in minecraft:overworld run fill 275 66 37 275 144 37 air
execute in minecraft:overworld run fill 275 58 38 275 62 38 stone
execute in minecraft:overworld run fill 275 63 38 275 64 38 dirt
execute in minecraft:overworld run setblock 275 65 38 grass_block
execute in minecraft:overworld run fill 275 66 38 275 144 38 air
execute in minecraft:overworld run fill 275 58 39 275 62 39 stone
execute in minecraft:overworld run fill 275 63 39 275 64 39 dirt
execute in minecraft:overworld run setblock 275 65 39 coarse_dirt
execute in minecraft:overworld run fill 275 66 39 275 144 39 air
execute in minecraft:overworld run fill 275 58 40 275 62 40 stone
execute in minecraft:overworld run fill 275 63 40 275 64 40 dirt
execute in minecraft:overworld run setblock 275 65 40 grass_block
execute in minecraft:overworld run fill 275 66 40 275 144 40 air
execute in minecraft:overworld run fill 275 58 41 275 62 41 stone
execute in minecraft:overworld run fill 275 63 41 275 64 41 dirt
execute in minecraft:overworld run setblock 275 65 41 coarse_dirt
execute in minecraft:overworld run fill 275 66 41 275 144 41 air
execute in minecraft:overworld run fill 275 58 42 275 61 42 stone
execute in minecraft:overworld run fill 275 62 42 275 63 42 dirt
execute in minecraft:overworld run setblock 275 64 42 coarse_dirt
execute in minecraft:overworld run fill 275 65 42 275 144 42 air
execute in minecraft:overworld run fill 275 58 43 275 61 43 stone
execute in minecraft:overworld run fill 275 62 43 275 63 43 dirt
execute in minecraft:overworld run setblock 275 64 43 grass_block
execute in minecraft:overworld run fill 275 65 43 275 144 43 air
execute in minecraft:overworld run fill 275 58 44 275 61 44 stone
execute in minecraft:overworld run fill 275 62 44 275 63 44 dirt
execute in minecraft:overworld run setblock 275 64 44 coarse_dirt
execute in minecraft:overworld run fill 275 65 44 275 144 44 air
execute in minecraft:overworld run fill 275 58 45 275 61 45 stone
execute in minecraft:overworld run fill 275 62 45 275 63 45 dirt
execute in minecraft:overworld run setblock 275 64 45 coarse_dirt
execute in minecraft:overworld run fill 275 65 45 275 144 45 air
execute in minecraft:overworld run fill 275 58 46 275 61 46 stone
execute in minecraft:overworld run fill 275 62 46 275 63 46 dirt
execute in minecraft:overworld run setblock 275 64 46 grass_block
execute in minecraft:overworld run fill 275 65 46 275 144 46 air
execute in minecraft:overworld run fill 275 58 47 275 61 47 stone
execute in minecraft:overworld run fill 275 62 47 275 63 47 dirt
execute in minecraft:overworld run setblock 275 64 47 coarse_dirt
execute in minecraft:overworld run fill 275 65 47 275 144 47 air
execute in minecraft:overworld run fill 276 58 -48 276 61 -48 stone
execute in minecraft:overworld run fill 276 62 -48 276 63 -48 dirt
execute in minecraft:overworld run setblock 276 64 -48 coarse_dirt
schedule function blade_gallery:random/burned/part_108 1t replace
