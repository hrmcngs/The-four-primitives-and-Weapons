execute in minecraft:overworld run fill 396 55 5 396 56 5 dirt
execute in minecraft:overworld run setblock 396 57 5 gravel
execute in minecraft:overworld run fill 396 58 5 396 144 5 air
execute in minecraft:overworld run fill 396 58 5 396 64 5 water
execute in minecraft:overworld run fill 396 58 6 396 54 6 stone
execute in minecraft:overworld run fill 396 55 6 396 56 6 dirt
execute in minecraft:overworld run setblock 396 57 6 gravel
execute in minecraft:overworld run fill 396 58 6 396 144 6 air
execute in minecraft:overworld run fill 396 58 6 396 64 6 water
execute in minecraft:overworld run fill 396 58 7 396 54 7 stone
execute in minecraft:overworld run fill 396 55 7 396 56 7 dirt
execute in minecraft:overworld run setblock 396 57 7 gravel
execute in minecraft:overworld run fill 396 58 7 396 144 7 air
execute in minecraft:overworld run fill 396 58 7 396 64 7 water
execute in minecraft:overworld run fill 396 58 8 396 54 8 stone
execute in minecraft:overworld run fill 396 55 8 396 56 8 dirt
execute in minecraft:overworld run setblock 396 57 8 gravel
execute in minecraft:overworld run fill 396 58 8 396 144 8 air
execute in minecraft:overworld run fill 396 58 8 396 64 8 water
execute in minecraft:overworld run fill 396 58 9 396 54 9 stone
execute in minecraft:overworld run fill 396 55 9 396 56 9 dirt
execute in minecraft:overworld run setblock 396 57 9 gravel
execute in minecraft:overworld run fill 396 58 9 396 144 9 air
execute in minecraft:overworld run fill 396 58 9 396 64 9 water
execute in minecraft:overworld run fill 396 58 10 396 54 10 stone
execute in minecraft:overworld run fill 396 55 10 396 56 10 dirt
execute in minecraft:overworld run setblock 396 57 10 gravel
execute in minecraft:overworld run fill 396 58 10 396 144 10 air
execute in minecraft:overworld run fill 396 58 10 396 64 10 water
execute in minecraft:overworld run fill 396 58 11 396 55 11 stone
execute in minecraft:overworld run fill 396 56 11 396 57 11 dirt
execute in minecraft:overworld run setblock 396 58 11 gravel
execute in minecraft:overworld run fill 396 59 11 396 144 11 air
execute in minecraft:overworld run fill 396 59 11 396 64 11 water
execute in minecraft:overworld run fill 396 58 12 396 55 12 stone
execute in minecraft:overworld run fill 396 56 12 396 57 12 dirt
execute in minecraft:overworld run setblock 396 58 12 gravel
execute in minecraft:overworld run fill 396 59 12 396 144 12 air
execute in minecraft:overworld run fill 396 59 12 396 64 12 water
execute in minecraft:overworld run fill 396 58 13 396 56 13 stone
execute in minecraft:overworld run fill 396 57 13 396 58 13 dirt
execute in minecraft:overworld run setblock 396 59 13 gravel
execute in minecraft:overworld run fill 396 60 13 396 144 13 air
execute in minecraft:overworld run fill 396 60 13 396 64 13 water
execute in minecraft:overworld run fill 396 58 14 396 56 14 stone
execute in minecraft:overworld run fill 396 57 14 396 58 14 dirt
execute in minecraft:overworld run setblock 396 59 14 gravel
execute in minecraft:overworld run fill 396 60 14 396 144 14 air
execute in minecraft:overworld run fill 396 60 14 396 64 14 water
execute in minecraft:overworld run fill 396 58 15 396 57 15 stone
execute in minecraft:overworld run fill 396 58 15 396 59 15 dirt
execute in minecraft:overworld run setblock 396 60 15 gravel
execute in minecraft:overworld run fill 396 61 15 396 144 15 air
execute in minecraft:overworld run fill 396 61 15 396 64 15 water
execute in minecraft:overworld run fill 396 58 16 396 57 16 stone
execute in minecraft:overworld run fill 396 58 16 396 59 16 dirt
execute in minecraft:overworld run setblock 396 60 16 gravel
execute in minecraft:overworld run fill 396 61 16 396 144 16 air
execute in minecraft:overworld run fill 396 61 16 396 64 16 water
execute in minecraft:overworld run fill 396 58 17 396 57 17 stone
execute in minecraft:overworld run fill 396 58 17 396 59 17 dirt
execute in minecraft:overworld run setblock 396 60 17 gravel
execute in minecraft:overworld run fill 396 61 17 396 144 17 air
execute in minecraft:overworld run fill 396 61 17 396 64 17 water
execute in minecraft:overworld run fill 396 58 18 396 58 18 stone
execute in minecraft:overworld run fill 396 59 18 396 60 18 dirt
execute in minecraft:overworld run setblock 396 61 18 gravel
execute in minecraft:overworld run fill 396 62 18 396 144 18 air
execute in minecraft:overworld run fill 396 62 18 396 64 18 water
execute in minecraft:overworld run fill 396 58 19 396 58 19 stone
execute in minecraft:overworld run fill 396 59 19 396 60 19 dirt
execute in minecraft:overworld run setblock 396 61 19 gravel
execute in minecraft:overworld run fill 396 62 19 396 144 19 air
execute in minecraft:overworld run fill 396 62 19 396 64 19 water
execute in minecraft:overworld run fill 396 58 20 396 58 20 stone
execute in minecraft:overworld run fill 396 59 20 396 60 20 dirt
execute in minecraft:overworld run setblock 396 61 20 gravel
execute in minecraft:overworld run fill 396 62 20 396 144 20 air
execute in minecraft:overworld run fill 396 62 20 396 64 20 water
execute in minecraft:overworld run fill 396 58 21 396 58 21 stone
execute in minecraft:overworld run fill 396 59 21 396 60 21 dirt
execute in minecraft:overworld run setblock 396 61 21 gravel
execute in minecraft:overworld run fill 396 62 21 396 144 21 air
execute in minecraft:overworld run fill 396 62 21 396 64 21 water
execute in minecraft:overworld run fill 396 58 22 396 58 22 stone
execute in minecraft:overworld run fill 396 59 22 396 60 22 dirt
execute in minecraft:overworld run setblock 396 61 22 gravel
execute in minecraft:overworld run fill 396 62 22 396 144 22 air
execute in minecraft:overworld run fill 396 62 22 396 64 22 water
execute in minecraft:overworld run fill 396 58 23 396 58 23 stone
execute in minecraft:overworld run fill 396 59 23 396 60 23 dirt
execute in minecraft:overworld run setblock 396 61 23 gravel
execute in minecraft:overworld run fill 396 62 23 396 144 23 air
execute in minecraft:overworld run fill 396 62 23 396 64 23 water
execute in minecraft:overworld run fill 396 58 24 396 58 24 stone
execute in minecraft:overworld run fill 396 59 24 396 60 24 dirt
execute in minecraft:overworld run setblock 396 61 24 gravel
execute in minecraft:overworld run fill 396 62 24 396 144 24 air
execute in minecraft:overworld run fill 396 62 24 396 64 24 water
execute in minecraft:overworld run fill 396 58 25 396 58 25 stone
execute in minecraft:overworld run fill 396 59 25 396 60 25 dirt
execute in minecraft:overworld run setblock 396 61 25 gravel
execute in minecraft:overworld run fill 396 62 25 396 144 25 air
execute in minecraft:overworld run fill 396 62 25 396 64 25 water
execute in minecraft:overworld run fill 396 58 26 396 58 26 stone
execute in minecraft:overworld run fill 396 59 26 396 60 26 dirt
execute in minecraft:overworld run setblock 396 61 26 gravel
execute in minecraft:overworld run fill 396 62 26 396 144 26 air
execute in minecraft:overworld run fill 396 62 26 396 64 26 water
execute in minecraft:overworld run fill 396 58 27 396 59 27 stone
execute in minecraft:overworld run fill 396 60 27 396 61 27 dirt
execute in minecraft:overworld run setblock 396 62 27 gravel
execute in minecraft:overworld run fill 396 63 27 396 144 27 air
execute in minecraft:overworld run fill 396 63 27 396 64 27 water
execute in minecraft:overworld run fill 396 58 28 396 59 28 stone
execute in minecraft:overworld run fill 396 60 28 396 61 28 dirt
execute in minecraft:overworld run setblock 396 62 28 gravel
execute in minecraft:overworld run fill 396 63 28 396 144 28 air
execute in minecraft:overworld run fill 396 63 28 396 64 28 water
execute in minecraft:overworld run fill 396 58 29 396 59 29 stone
execute in minecraft:overworld run fill 396 60 29 396 61 29 dirt
execute in minecraft:overworld run setblock 396 62 29 gravel
execute in minecraft:overworld run fill 396 63 29 396 144 29 air
execute in minecraft:overworld run fill 396 63 29 396 64 29 water
execute in minecraft:overworld run fill 396 58 30 396 59 30 stone
execute in minecraft:overworld run fill 396 60 30 396 61 30 dirt
execute in minecraft:overworld run setblock 396 62 30 gravel
execute in minecraft:overworld run fill 396 63 30 396 144 30 air
execute in minecraft:overworld run fill 396 63 30 396 64 30 water
execute in minecraft:overworld run fill 396 58 31 396 60 31 stone
execute in minecraft:overworld run fill 396 61 31 396 62 31 dirt
execute in minecraft:overworld run setblock 396 63 31 gravel
execute in minecraft:overworld run fill 396 64 31 396 144 31 air
execute in minecraft:overworld run fill 396 64 31 396 64 31 water
execute in minecraft:overworld run fill 396 58 32 396 60 32 stone
execute in minecraft:overworld run fill 396 61 32 396 62 32 dirt
execute in minecraft:overworld run setblock 396 63 32 gravel
execute in minecraft:overworld run fill 396 64 32 396 144 32 air
execute in minecraft:overworld run fill 396 64 32 396 64 32 water
execute in minecraft:overworld run fill 396 58 33 396 60 33 stone
execute in minecraft:overworld run fill 396 61 33 396 62 33 dirt
execute in minecraft:overworld run setblock 396 63 33 gravel
execute in minecraft:overworld run fill 396 64 33 396 144 33 air
execute in minecraft:overworld run fill 396 64 33 396 64 33 water
execute in minecraft:overworld run fill 396 58 34 396 61 34 stone
execute in minecraft:overworld run fill 396 62 34 396 63 34 dirt
execute in minecraft:overworld run setblock 396 64 34 coarse_dirt
execute in minecraft:overworld run fill 396 65 34 396 144 34 air
execute in minecraft:overworld run fill 396 58 35 396 62 35 stone
execute in minecraft:overworld run fill 396 63 35 396 64 35 dirt
execute in minecraft:overworld run setblock 396 65 35 coarse_dirt
execute in minecraft:overworld run fill 396 66 35 396 144 35 air
execute in minecraft:overworld run fill 396 58 36 396 62 36 stone
execute in minecraft:overworld run fill 396 63 36 396 64 36 dirt
execute in minecraft:overworld run setblock 396 65 36 coarse_dirt
execute in minecraft:overworld run fill 396 66 36 396 144 36 air
execute in minecraft:overworld run fill 396 58 37 396 63 37 stone
execute in minecraft:overworld run fill 396 64 37 396 65 37 dirt
execute in minecraft:overworld run setblock 396 66 37 coarse_dirt
execute in minecraft:overworld run fill 396 67 37 396 144 37 air
execute in minecraft:overworld run setblock 396 67 37 grass
execute in minecraft:overworld run fill 396 58 38 396 64 38 stone
execute in minecraft:overworld run fill 396 65 38 396 66 38 dirt
execute in minecraft:overworld run setblock 396 67 38 grass_block
execute in minecraft:overworld run fill 396 68 38 396 144 38 air
execute in minecraft:overworld run fill 396 58 39 396 64 39 stone
execute in minecraft:overworld run fill 396 65 39 396 66 39 dirt
execute in minecraft:overworld run setblock 396 67 39 grass_block
execute in minecraft:overworld run fill 396 68 39 396 144 39 air
execute in minecraft:overworld run fill 396 58 40 396 64 40 stone
execute in minecraft:overworld run fill 396 65 40 396 66 40 dirt
execute in minecraft:overworld run setblock 396 67 40 coarse_dirt
execute in minecraft:overworld run fill 396 68 40 396 144 40 air
execute in minecraft:overworld run fill 396 58 41 396 64 41 stone
execute in minecraft:overworld run fill 396 65 41 396 66 41 dirt
execute in minecraft:overworld run setblock 396 67 41 coarse_dirt
execute in minecraft:overworld run fill 396 68 41 396 144 41 air
execute in minecraft:overworld run fill 396 58 42 396 64 42 stone
execute in minecraft:overworld run fill 396 65 42 396 66 42 dirt
execute in minecraft:overworld run setblock 396 67 42 coarse_dirt
execute in minecraft:overworld run fill 396 68 42 396 144 42 air
execute in minecraft:overworld run fill 396 58 43 396 64 43 stone
execute in minecraft:overworld run fill 396 65 43 396 66 43 dirt
execute in minecraft:overworld run setblock 396 67 43 coarse_dirt
execute in minecraft:overworld run fill 396 68 43 396 144 43 air
execute in minecraft:overworld run fill 396 58 44 396 64 44 stone
execute in minecraft:overworld run fill 396 65 44 396 66 44 dirt
execute in minecraft:overworld run setblock 396 67 44 coarse_dirt
execute in minecraft:overworld run fill 396 68 44 396 144 44 air
execute in minecraft:overworld run fill 396 58 45 396 63 45 stone
execute in minecraft:overworld run fill 396 64 45 396 65 45 dirt
execute in minecraft:overworld run setblock 396 66 45 grass_block
execute in minecraft:overworld run fill 396 67 45 396 144 45 air
execute in minecraft:overworld run fill 396 58 46 396 63 46 stone
execute in minecraft:overworld run fill 396 64 46 396 65 46 dirt
execute in minecraft:overworld run setblock 396 66 46 coarse_dirt
execute in minecraft:overworld run fill 396 67 46 396 144 46 air
execute in minecraft:overworld run fill 396 58 47 396 62 47 stone
execute in minecraft:overworld run fill 396 63 47 396 64 47 dirt
execute in minecraft:overworld run setblock 396 65 47 coarse_dirt
execute in minecraft:overworld run fill 396 66 47 396 144 47 air
execute in minecraft:overworld run fill 397 58 -48 397 61 -48 stone
execute in minecraft:overworld run fill 397 62 -48 397 63 -48 dirt
execute in minecraft:overworld run setblock 397 64 -48 coarse_dirt
execute in minecraft:overworld run fill 397 65 -48 397 144 -48 air
execute in minecraft:overworld run fill 397 58 -47 397 62 -47 stone
execute in minecraft:overworld run fill 397 63 -47 397 64 -47 dirt
execute in minecraft:overworld run setblock 397 65 -47 coarse_dirt
execute in minecraft:overworld run fill 397 66 -47 397 144 -47 air
execute in minecraft:overworld run fill 397 58 -46 397 64 -46 stone
execute in minecraft:overworld run fill 397 65 -46 397 66 -46 dirt
execute in minecraft:overworld run setblock 397 67 -46 coarse_dirt
execute in minecraft:overworld run fill 397 68 -46 397 144 -46 air
execute in minecraft:overworld run fill 397 58 -45 397 65 -45 stone
execute in minecraft:overworld run fill 397 66 -45 397 67 -45 dirt
execute in minecraft:overworld run setblock 397 68 -45 grass_block
execute in minecraft:overworld run fill 397 69 -45 397 144 -45 air
execute in minecraft:overworld run fill 397 58 -44 397 66 -44 stone
execute in minecraft:overworld run fill 397 67 -44 397 68 -44 dirt
execute in minecraft:overworld run setblock 397 69 -44 coarse_dirt
execute in minecraft:overworld run fill 397 70 -44 397 144 -44 air
execute in minecraft:overworld run fill 397 58 -43 397 67 -43 stone
execute in minecraft:overworld run fill 397 68 -43 397 69 -43 dirt
execute in minecraft:overworld run setblock 397 70 -43 coarse_dirt
execute in minecraft:overworld run fill 397 71 -43 397 144 -43 air
execute in minecraft:overworld run fill 397 58 -42 397 69 -42 stone
execute in minecraft:overworld run fill 397 70 -42 397 71 -42 dirt
execute in minecraft:overworld run setblock 397 72 -42 grass_block
execute in minecraft:overworld run fill 397 73 -42 397 144 -42 air
execute in minecraft:overworld run fill 397 58 -41 397 70 -41 stone
execute in minecraft:overworld run fill 397 71 -41 397 72 -41 dirt
execute in minecraft:overworld run setblock 397 73 -41 grass_block
execute in minecraft:overworld run fill 397 74 -41 397 144 -41 air
execute in minecraft:overworld run fill 397 58 -40 397 72 -40 stone
execute in minecraft:overworld run fill 397 73 -40 397 74 -40 dirt
execute in minecraft:overworld run setblock 397 75 -40 grass_block
execute in minecraft:overworld run fill 397 76 -40 397 144 -40 air
execute in minecraft:overworld run fill 397 58 -39 397 73 -39 stone
execute in minecraft:overworld run fill 397 74 -39 397 75 -39 dirt
execute in minecraft:overworld run setblock 397 76 -39 grass_block
execute in minecraft:overworld run fill 397 77 -39 397 144 -39 air
execute in minecraft:overworld run fill 397 58 -38 397 74 -38 stone
execute in minecraft:overworld run fill 397 75 -38 397 76 -38 dirt
execute in minecraft:overworld run setblock 397 77 -38 coarse_dirt
execute in minecraft:overworld run fill 397 78 -38 397 144 -38 air
execute in minecraft:overworld run fill 397 58 -37 397 74 -37 stone
execute in minecraft:overworld run fill 397 75 -37 397 76 -37 dirt
execute in minecraft:overworld run setblock 397 77 -37 coarse_dirt
execute in minecraft:overworld run fill 397 78 -37 397 144 -37 air
execute in minecraft:overworld run fill 397 58 -36 397 74 -36 stone
execute in minecraft:overworld run fill 397 75 -36 397 76 -36 dirt
execute in minecraft:overworld run setblock 397 77 -36 coarse_dirt
execute in minecraft:overworld run fill 397 78 -36 397 144 -36 air
execute in minecraft:overworld run fill 397 58 -35 397 74 -35 stone
execute in minecraft:overworld run fill 397 75 -35 397 76 -35 dirt
execute in minecraft:overworld run setblock 397 77 -35 coarse_dirt
schedule function blade_gallery:random/battlefield/part_96 1t replace
