execute in minecraft:overworld run setblock 341 64 47 coarse_dirt
execute in minecraft:overworld run fill 341 65 47 341 144 47 air
execute in minecraft:overworld run fill 342 58 -48 342 61 -48 stone
execute in minecraft:overworld run fill 342 62 -48 342 63 -48 dirt
execute in minecraft:overworld run setblock 342 64 -48 coarse_dirt
execute in minecraft:overworld run fill 342 65 -48 342 144 -48 air
execute in minecraft:overworld run fill 342 58 -47 342 63 -47 stone
execute in minecraft:overworld run fill 342 64 -47 342 65 -47 dirt
execute in minecraft:overworld run setblock 342 66 -47 coarse_dirt
execute in minecraft:overworld run fill 342 67 -47 342 144 -47 air
execute in minecraft:overworld run fill 342 58 -46 342 65 -46 stone
execute in minecraft:overworld run fill 342 66 -46 342 67 -46 dirt
execute in minecraft:overworld run setblock 342 68 -46 coarse_dirt
execute in minecraft:overworld run fill 342 69 -46 342 144 -46 air
execute in minecraft:overworld run fill 342 58 -45 342 66 -45 stone
execute in minecraft:overworld run fill 342 67 -45 342 68 -45 dirt
execute in minecraft:overworld run setblock 342 69 -45 coarse_dirt
execute in minecraft:overworld run fill 342 70 -45 342 144 -45 air
execute in minecraft:overworld run fill 342 58 -44 342 68 -44 stone
execute in minecraft:overworld run fill 342 69 -44 342 70 -44 dirt
execute in minecraft:overworld run setblock 342 71 -44 coarse_dirt
execute in minecraft:overworld run fill 342 72 -44 342 144 -44 air
execute in minecraft:overworld run fill 342 58 -43 342 70 -43 stone
execute in minecraft:overworld run fill 342 71 -43 342 72 -43 dirt
execute in minecraft:overworld run setblock 342 73 -43 grass_block
execute in minecraft:overworld run fill 342 74 -43 342 144 -43 air
execute in minecraft:overworld run fill 342 58 -42 342 71 -42 stone
execute in minecraft:overworld run fill 342 72 -42 342 73 -42 dirt
execute in minecraft:overworld run setblock 342 74 -42 coarse_dirt
execute in minecraft:overworld run fill 342 75 -42 342 144 -42 air
execute in minecraft:overworld run fill 342 58 -41 342 71 -41 stone
execute in minecraft:overworld run fill 342 72 -41 342 73 -41 dirt
execute in minecraft:overworld run setblock 342 74 -41 grass_block
execute in minecraft:overworld run fill 342 75 -41 342 144 -41 air
execute in minecraft:overworld run fill 342 58 -40 342 71 -40 stone
execute in minecraft:overworld run fill 342 72 -40 342 73 -40 dirt
execute in minecraft:overworld run setblock 342 74 -40 coarse_dirt
execute in minecraft:overworld run fill 342 75 -40 342 144 -40 air
execute in minecraft:overworld run fill 342 58 -39 342 71 -39 stone
execute in minecraft:overworld run fill 342 72 -39 342 73 -39 dirt
execute in minecraft:overworld run setblock 342 74 -39 grass_block
execute in minecraft:overworld run fill 342 75 -39 342 144 -39 air
execute in minecraft:overworld run fill 342 58 -38 342 71 -38 stone
execute in minecraft:overworld run fill 342 72 -38 342 73 -38 dirt
execute in minecraft:overworld run setblock 342 74 -38 grass_block
execute in minecraft:overworld run fill 342 75 -38 342 144 -38 air
execute in minecraft:overworld run fill 342 58 -37 342 71 -37 stone
execute in minecraft:overworld run fill 342 72 -37 342 73 -37 dirt
execute in minecraft:overworld run setblock 342 74 -37 grass_block
execute in minecraft:overworld run fill 342 75 -37 342 144 -37 air
execute in minecraft:overworld run fill 342 58 -36 342 71 -36 stone
execute in minecraft:overworld run fill 342 72 -36 342 73 -36 dirt
execute in minecraft:overworld run setblock 342 74 -36 coarse_dirt
execute in minecraft:overworld run fill 342 75 -36 342 144 -36 air
execute in minecraft:overworld run fill 342 58 -35 342 71 -35 stone
execute in minecraft:overworld run fill 342 72 -35 342 73 -35 dirt
execute in minecraft:overworld run setblock 342 74 -35 grass_block
execute in minecraft:overworld run fill 342 75 -35 342 144 -35 air
execute in minecraft:overworld run fill 342 58 -34 342 70 -34 stone
execute in minecraft:overworld run fill 342 71 -34 342 72 -34 dirt
execute in minecraft:overworld run setblock 342 73 -34 grass_block
execute in minecraft:overworld run fill 342 74 -34 342 144 -34 air
execute in minecraft:overworld run fill 342 58 -33 342 70 -33 stone
execute in minecraft:overworld run fill 342 71 -33 342 72 -33 dirt
execute in minecraft:overworld run setblock 342 73 -33 grass_block
execute in minecraft:overworld run fill 342 74 -33 342 144 -33 air
execute in minecraft:overworld run fill 342 58 -32 342 70 -32 stone
execute in minecraft:overworld run fill 342 71 -32 342 72 -32 dirt
execute in minecraft:overworld run setblock 342 73 -32 coarse_dirt
execute in minecraft:overworld run fill 342 74 -32 342 144 -32 air
execute in minecraft:overworld run fill 342 58 -31 342 70 -31 stone
execute in minecraft:overworld run fill 342 71 -31 342 72 -31 dirt
execute in minecraft:overworld run setblock 342 73 -31 coarse_dirt
execute in minecraft:overworld run fill 342 74 -31 342 144 -31 air
execute in minecraft:overworld run fill 342 58 -30 342 69 -30 stone
execute in minecraft:overworld run fill 342 70 -30 342 71 -30 dirt
execute in minecraft:overworld run setblock 342 72 -30 coarse_dirt
execute in minecraft:overworld run fill 342 73 -30 342 144 -30 air
execute in minecraft:overworld run fill 342 58 -29 342 69 -29 stone
execute in minecraft:overworld run fill 342 70 -29 342 71 -29 dirt
execute in minecraft:overworld run setblock 342 72 -29 coarse_dirt
execute in minecraft:overworld run fill 342 73 -29 342 144 -29 air
execute in minecraft:overworld run fill 342 58 -28 342 69 -28 stone
execute in minecraft:overworld run fill 342 70 -28 342 71 -28 dirt
execute in minecraft:overworld run setblock 342 72 -28 grass_block
execute in minecraft:overworld run fill 342 73 -28 342 144 -28 air
execute in minecraft:overworld run fill 342 58 -27 342 69 -27 stone
execute in minecraft:overworld run fill 342 70 -27 342 71 -27 dirt
execute in minecraft:overworld run setblock 342 72 -27 coarse_dirt
execute in minecraft:overworld run fill 342 73 -27 342 144 -27 air
execute in minecraft:overworld run fill 342 58 -26 342 68 -26 stone
execute in minecraft:overworld run fill 342 69 -26 342 70 -26 dirt
execute in minecraft:overworld run setblock 342 71 -26 coarse_dirt
execute in minecraft:overworld run fill 342 72 -26 342 144 -26 air
execute in minecraft:overworld run fill 342 58 -25 342 68 -25 stone
execute in minecraft:overworld run fill 342 69 -25 342 70 -25 dirt
execute in minecraft:overworld run setblock 342 71 -25 coarse_dirt
execute in minecraft:overworld run fill 342 72 -25 342 144 -25 air
execute in minecraft:overworld run fill 342 58 -24 342 68 -24 stone
execute in minecraft:overworld run fill 342 69 -24 342 70 -24 dirt
execute in minecraft:overworld run setblock 342 71 -24 coarse_dirt
execute in minecraft:overworld run fill 342 72 -24 342 144 -24 air
execute in minecraft:overworld run fill 342 58 -23 342 68 -23 stone
execute in minecraft:overworld run fill 342 69 -23 342 70 -23 dirt
execute in minecraft:overworld run setblock 342 71 -23 coarse_dirt
execute in minecraft:overworld run fill 342 72 -23 342 144 -23 air
execute in minecraft:overworld run fill 342 58 -22 342 68 -22 stone
execute in minecraft:overworld run fill 342 69 -22 342 70 -22 dirt
execute in minecraft:overworld run setblock 342 71 -22 coarse_dirt
execute in minecraft:overworld run fill 342 72 -22 342 144 -22 air
execute in minecraft:overworld run fill 342 58 -21 342 68 -21 stone
execute in minecraft:overworld run fill 342 69 -21 342 70 -21 dirt
execute in minecraft:overworld run setblock 342 71 -21 coarse_dirt
execute in minecraft:overworld run fill 342 72 -21 342 144 -21 air
execute in minecraft:overworld run fill 342 58 -20 342 67 -20 stone
execute in minecraft:overworld run fill 342 68 -20 342 69 -20 dirt
execute in minecraft:overworld run setblock 342 70 -20 coarse_dirt
execute in minecraft:overworld run fill 342 71 -20 342 144 -20 air
execute in minecraft:overworld run fill 342 58 -19 342 67 -19 stone
execute in minecraft:overworld run fill 342 68 -19 342 69 -19 dirt
execute in minecraft:overworld run setblock 342 70 -19 coarse_dirt
execute in minecraft:overworld run fill 342 71 -19 342 144 -19 air
execute in minecraft:overworld run fill 342 58 -18 342 67 -18 stone
execute in minecraft:overworld run fill 342 68 -18 342 69 -18 dirt
execute in minecraft:overworld run setblock 342 70 -18 coarse_dirt
execute in minecraft:overworld run fill 342 71 -18 342 144 -18 air
execute in minecraft:overworld run fill 342 58 -17 342 67 -17 stone
execute in minecraft:overworld run fill 342 68 -17 342 69 -17 dirt
execute in minecraft:overworld run setblock 342 70 -17 coarse_dirt
execute in minecraft:overworld run fill 342 71 -17 342 144 -17 air
execute in minecraft:overworld run fill 342 58 -16 342 66 -16 stone
execute in minecraft:overworld run fill 342 67 -16 342 68 -16 dirt
execute in minecraft:overworld run setblock 342 69 -16 grass_block
execute in minecraft:overworld run fill 342 70 -16 342 144 -16 air
execute in minecraft:overworld run fill 342 58 -15 342 66 -15 stone
execute in minecraft:overworld run fill 342 67 -15 342 68 -15 dirt
execute in minecraft:overworld run setblock 342 69 -15 coarse_dirt
execute in minecraft:overworld run fill 342 70 -15 342 144 -15 air
execute in minecraft:overworld run fill 342 58 -14 342 66 -14 stone
execute in minecraft:overworld run fill 342 67 -14 342 68 -14 dirt
execute in minecraft:overworld run setblock 342 69 -14 grass_block
execute in minecraft:overworld run fill 342 70 -14 342 144 -14 air
execute in minecraft:overworld run fill 342 58 -13 342 65 -13 stone
execute in minecraft:overworld run fill 342 66 -13 342 67 -13 dirt
execute in minecraft:overworld run setblock 342 68 -13 coarse_dirt
execute in minecraft:overworld run fill 342 69 -13 342 144 -13 air
execute in minecraft:overworld run fill 342 58 -12 342 65 -12 stone
execute in minecraft:overworld run fill 342 66 -12 342 67 -12 dirt
execute in minecraft:overworld run setblock 342 68 -12 coarse_dirt
execute in minecraft:overworld run fill 342 69 -12 342 144 -12 air
execute in minecraft:overworld run fill 342 58 -11 342 64 -11 stone
execute in minecraft:overworld run fill 342 65 -11 342 66 -11 dirt
execute in minecraft:overworld run setblock 342 67 -11 coarse_dirt
execute in minecraft:overworld run fill 342 68 -11 342 144 -11 air
execute in minecraft:overworld run fill 342 58 -10 342 64 -10 stone
execute in minecraft:overworld run fill 342 65 -10 342 66 -10 dirt
execute in minecraft:overworld run setblock 342 67 -10 coarse_dirt
execute in minecraft:overworld run fill 342 68 -10 342 144 -10 air
execute in minecraft:overworld run fill 342 58 -9 342 64 -9 stone
execute in minecraft:overworld run fill 342 65 -9 342 66 -9 dirt
execute in minecraft:overworld run setblock 342 67 -9 coarse_dirt
execute in minecraft:overworld run fill 342 68 -9 342 144 -9 air
execute in minecraft:overworld run fill 342 58 -8 342 64 -8 stone
execute in minecraft:overworld run fill 342 65 -8 342 66 -8 dirt
execute in minecraft:overworld run setblock 342 67 -8 coarse_dirt
execute in minecraft:overworld run fill 342 68 -8 342 144 -8 air
execute in minecraft:overworld run fill 342 58 -7 342 64 -7 stone
execute in minecraft:overworld run fill 342 65 -7 342 66 -7 dirt
execute in minecraft:overworld run setblock 342 67 -7 grass_block
execute in minecraft:overworld run fill 342 68 -7 342 144 -7 air
execute in minecraft:overworld run fill 342 58 -6 342 64 -6 stone
execute in minecraft:overworld run fill 342 65 -6 342 66 -6 dirt
execute in minecraft:overworld run setblock 342 67 -6 coarse_dirt
execute in minecraft:overworld run fill 342 68 -6 342 144 -6 air
execute in minecraft:overworld run fill 342 58 -5 342 64 -5 stone
execute in minecraft:overworld run fill 342 65 -5 342 66 -5 dirt
execute in minecraft:overworld run setblock 342 67 -5 coarse_dirt
execute in minecraft:overworld run fill 342 68 -5 342 144 -5 air
execute in minecraft:overworld run fill 342 58 -4 342 65 -4 stone
execute in minecraft:overworld run fill 342 66 -4 342 67 -4 dirt
execute in minecraft:overworld run setblock 342 68 -4 coarse_dirt
execute in minecraft:overworld run fill 342 69 -4 342 144 -4 air
execute in minecraft:overworld run fill 342 58 -3 342 65 -3 stone
execute in minecraft:overworld run fill 342 66 -3 342 67 -3 dirt
execute in minecraft:overworld run setblock 342 68 -3 grass_block
execute in minecraft:overworld run fill 342 69 -3 342 144 -3 air
execute in minecraft:overworld run fill 342 58 -2 342 65 -2 stone
execute in minecraft:overworld run fill 342 66 -2 342 67 -2 dirt
execute in minecraft:overworld run setblock 342 68 -2 coarse_dirt
execute in minecraft:overworld run fill 342 69 -2 342 144 -2 air
execute in minecraft:overworld run fill 342 58 -1 342 65 -1 stone
execute in minecraft:overworld run fill 342 66 -1 342 67 -1 dirt
execute in minecraft:overworld run setblock 342 68 -1 grass_block
execute in minecraft:overworld run fill 342 69 -1 342 144 -1 air
execute in minecraft:overworld run fill 342 58 0 342 65 0 stone
execute in minecraft:overworld run fill 342 66 0 342 67 0 dirt
execute in minecraft:overworld run setblock 342 68 0 coarse_dirt
execute in minecraft:overworld run fill 342 69 0 342 144 0 air
execute in minecraft:overworld run fill 342 58 1 342 65 1 stone
execute in minecraft:overworld run fill 342 66 1 342 67 1 dirt
execute in minecraft:overworld run setblock 342 68 1 grass_block
execute in minecraft:overworld run fill 342 69 1 342 144 1 air
execute in minecraft:overworld run fill 342 58 2 342 65 2 stone
execute in minecraft:overworld run fill 342 66 2 342 67 2 dirt
execute in minecraft:overworld run setblock 342 68 2 grass_block
execute in minecraft:overworld run fill 342 69 2 342 144 2 air
execute in minecraft:overworld run fill 342 58 3 342 65 3 stone
execute in minecraft:overworld run fill 342 66 3 342 67 3 dirt
execute in minecraft:overworld run setblock 342 68 3 grass_block
execute in minecraft:overworld run fill 342 69 3 342 144 3 air
execute in minecraft:overworld run fill 342 58 4 342 65 4 stone
execute in minecraft:overworld run fill 342 66 4 342 67 4 dirt
execute in minecraft:overworld run setblock 342 68 4 coarse_dirt
execute in minecraft:overworld run fill 342 69 4 342 144 4 air
execute in minecraft:overworld run fill 342 58 5 342 65 5 stone
execute in minecraft:overworld run fill 342 66 5 342 67 5 dirt
execute in minecraft:overworld run setblock 342 68 5 grass_block
execute in minecraft:overworld run fill 342 69 5 342 144 5 air
execute in minecraft:overworld run fill 342 58 6 342 65 6 stone
execute in minecraft:overworld run fill 342 66 6 342 67 6 dirt
execute in minecraft:overworld run setblock 342 68 6 coarse_dirt
execute in minecraft:overworld run fill 342 69 6 342 144 6 air
execute in minecraft:overworld run fill 342 58 7 342 64 7 stone
execute in minecraft:overworld run fill 342 65 7 342 66 7 dirt
execute in minecraft:overworld run setblock 342 67 7 grass_block
execute in minecraft:overworld run fill 342 68 7 342 144 7 air
execute in minecraft:overworld run fill 342 58 8 342 64 8 stone
execute in minecraft:overworld run fill 342 65 8 342 66 8 dirt
execute in minecraft:overworld run setblock 342 67 8 coarse_dirt
execute in minecraft:overworld run fill 342 68 8 342 144 8 air
execute in minecraft:overworld run fill 342 58 9 342 64 9 stone
execute in minecraft:overworld run fill 342 65 9 342 66 9 dirt
execute in minecraft:overworld run setblock 342 67 9 coarse_dirt
execute in minecraft:overworld run fill 342 68 9 342 144 9 air
execute in minecraft:overworld run fill 342 58 10 342 64 10 stone
execute in minecraft:overworld run fill 342 65 10 342 66 10 dirt
execute in minecraft:overworld run setblock 342 67 10 coarse_dirt
execute in minecraft:overworld run fill 342 68 10 342 144 10 air
execute in minecraft:overworld run fill 342 58 11 342 64 11 stone
execute in minecraft:overworld run fill 342 65 11 342 66 11 dirt
execute in minecraft:overworld run setblock 342 67 11 grass_block
execute in minecraft:overworld run fill 342 68 11 342 144 11 air
execute in minecraft:overworld run fill 342 58 12 342 64 12 stone
execute in minecraft:overworld run fill 342 65 12 342 66 12 dirt
execute in minecraft:overworld run setblock 342 67 12 coarse_dirt
execute in minecraft:overworld run fill 342 68 12 342 144 12 air
execute in minecraft:overworld run fill 342 58 13 342 64 13 stone
execute in minecraft:overworld run fill 342 65 13 342 66 13 dirt
execute in minecraft:overworld run setblock 342 67 13 grass_block
execute in minecraft:overworld run fill 342 68 13 342 144 13 air
execute in minecraft:overworld run fill 342 58 14 342 63 14 stone
execute in minecraft:overworld run fill 342 64 14 342 65 14 dirt
execute in minecraft:overworld run setblock 342 66 14 coarse_dirt
execute in minecraft:overworld run fill 342 67 14 342 144 14 air
execute in minecraft:overworld run fill 342 58 15 342 63 15 stone
execute in minecraft:overworld run fill 342 64 15 342 65 15 dirt
schedule function blade_gallery:random/battlefield/part_10 1t replace
