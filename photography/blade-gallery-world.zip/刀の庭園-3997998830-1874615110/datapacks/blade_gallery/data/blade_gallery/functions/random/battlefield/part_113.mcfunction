execute in minecraft:overworld run fill 407 67 20 407 68 20 dirt
execute in minecraft:overworld run setblock 407 69 20 coarse_dirt
execute in minecraft:overworld run fill 407 70 20 407 144 20 air
execute in minecraft:overworld run setblock 407 70 20 grass
execute in minecraft:overworld run fill 407 58 21 407 67 21 stone
execute in minecraft:overworld run fill 407 68 21 407 69 21 dirt
execute in minecraft:overworld run setblock 407 70 21 grass_block
execute in minecraft:overworld run fill 407 71 21 407 144 21 air
execute in minecraft:overworld run fill 407 58 22 407 67 22 stone
execute in minecraft:overworld run fill 407 68 22 407 69 22 dirt
execute in minecraft:overworld run setblock 407 70 22 coarse_dirt
execute in minecraft:overworld run fill 407 71 22 407 144 22 air
execute in minecraft:overworld run fill 407 58 23 407 67 23 stone
execute in minecraft:overworld run fill 407 68 23 407 69 23 dirt
execute in minecraft:overworld run setblock 407 70 23 grass_block
execute in minecraft:overworld run fill 407 71 23 407 144 23 air
execute in minecraft:overworld run fill 407 58 24 407 68 24 stone
execute in minecraft:overworld run fill 407 69 24 407 70 24 dirt
execute in minecraft:overworld run setblock 407 71 24 grass_block
execute in minecraft:overworld run fill 407 72 24 407 144 24 air
execute in minecraft:overworld run fill 407 58 25 407 68 25 stone
execute in minecraft:overworld run fill 407 69 25 407 70 25 dirt
execute in minecraft:overworld run setblock 407 71 25 grass_block
execute in minecraft:overworld run fill 407 72 25 407 144 25 air
execute in minecraft:overworld run fill 407 58 26 407 68 26 stone
execute in minecraft:overworld run fill 407 69 26 407 70 26 dirt
execute in minecraft:overworld run setblock 407 71 26 grass_block
execute in minecraft:overworld run fill 407 72 26 407 144 26 air
execute in minecraft:overworld run fill 407 58 27 407 68 27 stone
execute in minecraft:overworld run fill 407 69 27 407 70 27 dirt
execute in minecraft:overworld run setblock 407 71 27 coarse_dirt
execute in minecraft:overworld run fill 407 72 27 407 144 27 air
execute in minecraft:overworld run fill 407 58 28 407 68 28 stone
execute in minecraft:overworld run fill 407 69 28 407 70 28 dirt
execute in minecraft:overworld run setblock 407 71 28 coarse_dirt
execute in minecraft:overworld run fill 407 72 28 407 144 28 air
execute in minecraft:overworld run fill 407 58 29 407 68 29 stone
execute in minecraft:overworld run fill 407 69 29 407 70 29 dirt
execute in minecraft:overworld run setblock 407 71 29 coarse_dirt
execute in minecraft:overworld run fill 407 72 29 407 144 29 air
execute in minecraft:overworld run fill 407 58 30 407 68 30 stone
execute in minecraft:overworld run fill 407 69 30 407 70 30 dirt
execute in minecraft:overworld run setblock 407 71 30 coarse_dirt
execute in minecraft:overworld run fill 407 72 30 407 144 30 air
execute in minecraft:overworld run fill 407 58 31 407 68 31 stone
execute in minecraft:overworld run fill 407 69 31 407 70 31 dirt
execute in minecraft:overworld run setblock 407 71 31 coarse_dirt
execute in minecraft:overworld run fill 407 72 31 407 144 31 air
execute in minecraft:overworld run setblock 407 72 31 grass
execute in minecraft:overworld run fill 407 58 32 407 68 32 stone
execute in minecraft:overworld run fill 407 69 32 407 70 32 dirt
execute in minecraft:overworld run setblock 407 71 32 coarse_dirt
execute in minecraft:overworld run fill 407 72 32 407 144 32 air
execute in minecraft:overworld run fill 407 58 33 407 67 33 stone
execute in minecraft:overworld run fill 407 68 33 407 69 33 dirt
execute in minecraft:overworld run setblock 407 70 33 grass_block
execute in minecraft:overworld run fill 407 71 33 407 144 33 air
execute in minecraft:overworld run fill 407 58 34 407 67 34 stone
execute in minecraft:overworld run fill 407 68 34 407 69 34 dirt
execute in minecraft:overworld run setblock 407 70 34 coarse_dirt
execute in minecraft:overworld run fill 407 71 34 407 144 34 air
execute in minecraft:overworld run fill 407 58 35 407 67 35 stone
execute in minecraft:overworld run fill 407 68 35 407 69 35 dirt
execute in minecraft:overworld run setblock 407 70 35 coarse_dirt
execute in minecraft:overworld run fill 407 71 35 407 144 35 air
execute in minecraft:overworld run fill 407 58 36 407 67 36 stone
execute in minecraft:overworld run fill 407 68 36 407 69 36 dirt
execute in minecraft:overworld run setblock 407 70 36 coarse_dirt
execute in minecraft:overworld run fill 407 71 36 407 144 36 air
execute in minecraft:overworld run fill 407 58 37 407 67 37 stone
execute in minecraft:overworld run fill 407 68 37 407 69 37 dirt
execute in minecraft:overworld run setblock 407 70 37 coarse_dirt
execute in minecraft:overworld run fill 407 71 37 407 144 37 air
execute in minecraft:overworld run fill 407 58 38 407 67 38 stone
execute in minecraft:overworld run fill 407 68 38 407 69 38 dirt
execute in minecraft:overworld run setblock 407 70 38 coarse_dirt
execute in minecraft:overworld run fill 407 71 38 407 144 38 air
execute in minecraft:overworld run fill 407 58 39 407 66 39 stone
execute in minecraft:overworld run fill 407 67 39 407 68 39 dirt
execute in minecraft:overworld run setblock 407 69 39 coarse_dirt
execute in minecraft:overworld run fill 407 70 39 407 144 39 air
execute in minecraft:overworld run fill 407 58 40 407 66 40 stone
execute in minecraft:overworld run fill 407 67 40 407 68 40 dirt
execute in minecraft:overworld run setblock 407 69 40 coarse_dirt
execute in minecraft:overworld run fill 407 70 40 407 144 40 air
execute in minecraft:overworld run fill 407 58 41 407 65 41 stone
execute in minecraft:overworld run fill 407 66 41 407 67 41 dirt
execute in minecraft:overworld run setblock 407 68 41 coarse_dirt
execute in minecraft:overworld run fill 407 69 41 407 144 41 air
execute in minecraft:overworld run setblock 407 69 41 grass
execute in minecraft:overworld run fill 407 58 42 407 65 42 stone
execute in minecraft:overworld run fill 407 66 42 407 67 42 dirt
execute in minecraft:overworld run setblock 407 68 42 grass_block
execute in minecraft:overworld run fill 407 69 42 407 144 42 air
execute in minecraft:overworld run fill 407 58 43 407 64 43 stone
execute in minecraft:overworld run fill 407 65 43 407 66 43 dirt
execute in minecraft:overworld run setblock 407 67 43 coarse_dirt
execute in minecraft:overworld run fill 407 68 43 407 144 43 air
execute in minecraft:overworld run fill 407 58 44 407 63 44 stone
execute in minecraft:overworld run fill 407 64 44 407 65 44 dirt
execute in minecraft:overworld run setblock 407 66 44 coarse_dirt
execute in minecraft:overworld run fill 407 67 44 407 144 44 air
execute in minecraft:overworld run fill 407 58 45 407 63 45 stone
execute in minecraft:overworld run fill 407 64 45 407 65 45 dirt
execute in minecraft:overworld run setblock 407 66 45 coarse_dirt
execute in minecraft:overworld run fill 407 67 45 407 144 45 air
execute in minecraft:overworld run fill 407 58 46 407 62 46 stone
execute in minecraft:overworld run fill 407 63 46 407 64 46 dirt
execute in minecraft:overworld run setblock 407 65 46 coarse_dirt
execute in minecraft:overworld run fill 407 66 46 407 144 46 air
execute in minecraft:overworld run fill 407 58 47 407 62 47 stone
execute in minecraft:overworld run fill 407 63 47 407 64 47 dirt
execute in minecraft:overworld run setblock 407 65 47 coarse_dirt
execute in minecraft:overworld run fill 407 66 47 407 144 47 air
execute in minecraft:overworld run fill 408 58 -48 408 61 -48 stone
execute in minecraft:overworld run fill 408 62 -48 408 63 -48 dirt
execute in minecraft:overworld run setblock 408 64 -48 grass_block
execute in minecraft:overworld run fill 408 65 -48 408 144 -48 air
execute in minecraft:overworld run fill 408 58 -47 408 63 -47 stone
execute in minecraft:overworld run fill 408 64 -47 408 65 -47 dirt
execute in minecraft:overworld run setblock 408 66 -47 coarse_dirt
execute in minecraft:overworld run fill 408 67 -47 408 144 -47 air
execute in minecraft:overworld run fill 408 58 -46 408 64 -46 stone
execute in minecraft:overworld run fill 408 65 -46 408 66 -46 dirt
execute in minecraft:overworld run setblock 408 67 -46 coarse_dirt
execute in minecraft:overworld run fill 408 68 -46 408 144 -46 air
execute in minecraft:overworld run fill 408 58 -45 408 66 -45 stone
execute in minecraft:overworld run fill 408 67 -45 408 68 -45 dirt
execute in minecraft:overworld run setblock 408 69 -45 grass_block
execute in minecraft:overworld run fill 408 70 -45 408 144 -45 air
execute in minecraft:overworld run fill 408 58 -44 408 67 -44 stone
execute in minecraft:overworld run fill 408 68 -44 408 69 -44 dirt
execute in minecraft:overworld run setblock 408 70 -44 coarse_dirt
execute in minecraft:overworld run fill 408 71 -44 408 144 -44 air
execute in minecraft:overworld run fill 408 58 -43 408 69 -43 stone
execute in minecraft:overworld run fill 408 70 -43 408 71 -43 dirt
execute in minecraft:overworld run setblock 408 72 -43 coarse_dirt
execute in minecraft:overworld run fill 408 73 -43 408 144 -43 air
execute in minecraft:overworld run fill 408 58 -42 408 70 -42 stone
execute in minecraft:overworld run fill 408 71 -42 408 72 -42 dirt
execute in minecraft:overworld run setblock 408 73 -42 coarse_dirt
execute in minecraft:overworld run fill 408 74 -42 408 144 -42 air
execute in minecraft:overworld run fill 408 58 -41 408 72 -41 stone
execute in minecraft:overworld run fill 408 73 -41 408 74 -41 dirt
execute in minecraft:overworld run setblock 408 75 -41 grass_block
execute in minecraft:overworld run fill 408 76 -41 408 144 -41 air
execute in minecraft:overworld run fill 408 58 -40 408 73 -40 stone
execute in minecraft:overworld run fill 408 74 -40 408 75 -40 dirt
execute in minecraft:overworld run setblock 408 76 -40 grass_block
execute in minecraft:overworld run fill 408 77 -40 408 144 -40 air
execute in minecraft:overworld run fill 408 58 -39 408 74 -39 stone
execute in minecraft:overworld run fill 408 75 -39 408 76 -39 dirt
execute in minecraft:overworld run setblock 408 77 -39 grass_block
execute in minecraft:overworld run fill 408 78 -39 408 144 -39 air
execute in minecraft:overworld run setblock 408 78 -39 grass
execute in minecraft:overworld run fill 408 58 -38 408 75 -38 stone
execute in minecraft:overworld run fill 408 76 -38 408 77 -38 dirt
execute in minecraft:overworld run setblock 408 78 -38 coarse_dirt
execute in minecraft:overworld run fill 408 79 -38 408 144 -38 air
execute in minecraft:overworld run fill 408 58 -37 408 75 -37 stone
execute in minecraft:overworld run fill 408 76 -37 408 77 -37 dirt
execute in minecraft:overworld run setblock 408 78 -37 grass_block
execute in minecraft:overworld run fill 408 79 -37 408 144 -37 air
execute in minecraft:overworld run fill 408 58 -36 408 75 -36 stone
execute in minecraft:overworld run fill 408 76 -36 408 77 -36 dirt
execute in minecraft:overworld run setblock 408 78 -36 grass_block
execute in minecraft:overworld run fill 408 79 -36 408 144 -36 air
execute in minecraft:overworld run fill 408 58 -35 408 75 -35 stone
execute in minecraft:overworld run fill 408 76 -35 408 77 -35 dirt
execute in minecraft:overworld run setblock 408 78 -35 grass_block
execute in minecraft:overworld run fill 408 79 -35 408 144 -35 air
execute in minecraft:overworld run fill 408 58 -34 408 74 -34 stone
execute in minecraft:overworld run fill 408 75 -34 408 76 -34 dirt
execute in minecraft:overworld run setblock 408 77 -34 coarse_dirt
execute in minecraft:overworld run fill 408 78 -34 408 144 -34 air
execute in minecraft:overworld run fill 408 58 -33 408 74 -33 stone
execute in minecraft:overworld run fill 408 75 -33 408 76 -33 dirt
execute in minecraft:overworld run setblock 408 77 -33 coarse_dirt
execute in minecraft:overworld run fill 408 78 -33 408 144 -33 air
execute in minecraft:overworld run fill 408 58 -32 408 73 -32 stone
execute in minecraft:overworld run fill 408 74 -32 408 75 -32 dirt
execute in minecraft:overworld run setblock 408 76 -32 grass_block
execute in minecraft:overworld run fill 408 77 -32 408 144 -32 air
execute in minecraft:overworld run fill 408 58 -31 408 73 -31 stone
execute in minecraft:overworld run fill 408 74 -31 408 75 -31 dirt
execute in minecraft:overworld run setblock 408 76 -31 coarse_dirt
execute in minecraft:overworld run fill 408 77 -31 408 144 -31 air
execute in minecraft:overworld run setblock 408 77 -31 mossy_cobblestone
execute in minecraft:overworld run fill 408 58 -30 408 73 -30 stone
execute in minecraft:overworld run fill 408 74 -30 408 75 -30 dirt
execute in minecraft:overworld run setblock 408 76 -30 coarse_dirt
execute in minecraft:overworld run fill 408 77 -30 408 144 -30 air
execute in minecraft:overworld run fill 408 58 -29 408 72 -29 stone
execute in minecraft:overworld run fill 408 73 -29 408 74 -29 dirt
execute in minecraft:overworld run setblock 408 75 -29 coarse_dirt
execute in minecraft:overworld run fill 408 76 -29 408 144 -29 air
execute in minecraft:overworld run fill 408 58 -28 408 72 -28 stone
execute in minecraft:overworld run fill 408 73 -28 408 74 -28 dirt
execute in minecraft:overworld run setblock 408 75 -28 coarse_dirt
execute in minecraft:overworld run fill 408 76 -28 408 144 -28 air
execute in minecraft:overworld run fill 408 58 -27 408 72 -27 stone
execute in minecraft:overworld run fill 408 73 -27 408 74 -27 dirt
execute in minecraft:overworld run setblock 408 75 -27 coarse_dirt
execute in minecraft:overworld run fill 408 76 -27 408 144 -27 air
execute in minecraft:overworld run fill 408 58 -26 408 71 -26 stone
execute in minecraft:overworld run fill 408 72 -26 408 73 -26 dirt
execute in minecraft:overworld run setblock 408 74 -26 grass_block
execute in minecraft:overworld run fill 408 75 -26 408 144 -26 air
execute in minecraft:overworld run fill 408 58 -25 408 71 -25 stone
execute in minecraft:overworld run fill 408 72 -25 408 73 -25 dirt
execute in minecraft:overworld run setblock 408 74 -25 coarse_dirt
execute in minecraft:overworld run fill 408 75 -25 408 144 -25 air
execute in minecraft:overworld run fill 408 58 -24 408 71 -24 stone
execute in minecraft:overworld run fill 408 72 -24 408 73 -24 dirt
execute in minecraft:overworld run setblock 408 74 -24 coarse_dirt
execute in minecraft:overworld run fill 408 75 -24 408 144 -24 air
execute in minecraft:overworld run fill 408 58 -23 408 70 -23 stone
execute in minecraft:overworld run fill 408 71 -23 408 72 -23 dirt
execute in minecraft:overworld run setblock 408 73 -23 coarse_dirt
execute in minecraft:overworld run fill 408 74 -23 408 144 -23 air
execute in minecraft:overworld run setblock 408 74 -23 grass
execute in minecraft:overworld run fill 408 58 -22 408 70 -22 stone
execute in minecraft:overworld run fill 408 71 -22 408 72 -22 dirt
execute in minecraft:overworld run setblock 408 73 -22 grass_block
execute in minecraft:overworld run fill 408 74 -22 408 144 -22 air
execute in minecraft:overworld run fill 408 58 -21 408 70 -21 stone
execute in minecraft:overworld run fill 408 71 -21 408 72 -21 dirt
execute in minecraft:overworld run setblock 408 73 -21 coarse_dirt
execute in minecraft:overworld run fill 408 74 -21 408 144 -21 air
execute in minecraft:overworld run fill 408 58 -20 408 69 -20 stone
execute in minecraft:overworld run fill 408 70 -20 408 71 -20 dirt
execute in minecraft:overworld run setblock 408 72 -20 coarse_dirt
execute in minecraft:overworld run fill 408 73 -20 408 144 -20 air
execute in minecraft:overworld run fill 408 58 -19 408 69 -19 stone
execute in minecraft:overworld run fill 408 70 -19 408 71 -19 dirt
execute in minecraft:overworld run setblock 408 72 -19 coarse_dirt
execute in minecraft:overworld run fill 408 73 -19 408 144 -19 air
execute in minecraft:overworld run setblock 408 73 -19 grass
execute in minecraft:overworld run fill 408 58 -18 408 68 -18 stone
execute in minecraft:overworld run fill 408 69 -18 408 70 -18 dirt
execute in minecraft:overworld run setblock 408 71 -18 coarse_dirt
execute in minecraft:overworld run fill 408 72 -18 408 144 -18 air
execute in minecraft:overworld run fill 408 58 -17 408 68 -17 stone
execute in minecraft:overworld run fill 408 69 -17 408 70 -17 dirt
execute in minecraft:overworld run setblock 408 71 -17 coarse_dirt
execute in minecraft:overworld run fill 408 72 -17 408 144 -17 air
execute in minecraft:overworld run fill 408 58 -16 408 67 -16 stone
execute in minecraft:overworld run fill 408 68 -16 408 69 -16 dirt
execute in minecraft:overworld run setblock 408 70 -16 coarse_dirt
execute in minecraft:overworld run fill 408 71 -16 408 144 -16 air
execute in minecraft:overworld run fill 408 58 -15 408 67 -15 stone
execute in minecraft:overworld run fill 408 68 -15 408 69 -15 dirt
execute in minecraft:overworld run setblock 408 70 -15 grass_block
execute in minecraft:overworld run fill 408 71 -15 408 144 -15 air
execute in minecraft:overworld run fill 408 58 -14 408 66 -14 stone
execute in minecraft:overworld run fill 408 67 -14 408 68 -14 dirt
schedule function blade_gallery:random/battlefield/part_114 1t replace
