execute in minecraft:overworld run fill 258 62 -17 258 63 -17 dirt
execute in minecraft:overworld run setblock 258 64 -17 coarse_dirt
execute in minecraft:overworld run fill 258 65 -17 258 144 -17 air
execute in minecraft:overworld run fill 258 58 -16 258 60 -16 stone
execute in minecraft:overworld run fill 258 61 -16 258 62 -16 dirt
execute in minecraft:overworld run setblock 258 63 -16 gravel
execute in minecraft:overworld run fill 258 64 -16 258 144 -16 air
execute in minecraft:overworld run fill 258 64 -16 258 64 -16 water
execute in minecraft:overworld run fill 258 58 -15 258 59 -15 stone
execute in minecraft:overworld run fill 258 60 -15 258 61 -15 dirt
execute in minecraft:overworld run setblock 258 62 -15 gravel
execute in minecraft:overworld run fill 258 63 -15 258 144 -15 air
execute in minecraft:overworld run fill 258 63 -15 258 64 -15 water
execute in minecraft:overworld run fill 258 58 -14 258 59 -14 stone
execute in minecraft:overworld run fill 258 60 -14 258 61 -14 dirt
execute in minecraft:overworld run setblock 258 62 -14 gravel
execute in minecraft:overworld run fill 258 63 -14 258 144 -14 air
execute in minecraft:overworld run fill 258 63 -14 258 64 -14 water
execute in minecraft:overworld run fill 258 58 -13 258 58 -13 stone
execute in minecraft:overworld run fill 258 59 -13 258 60 -13 dirt
execute in minecraft:overworld run setblock 258 61 -13 gravel
execute in minecraft:overworld run fill 258 62 -13 258 144 -13 air
execute in minecraft:overworld run fill 258 62 -13 258 64 -13 water
execute in minecraft:overworld run fill 258 58 -12 258 57 -12 stone
execute in minecraft:overworld run fill 258 58 -12 258 59 -12 dirt
execute in minecraft:overworld run setblock 258 60 -12 gravel
execute in minecraft:overworld run fill 258 61 -12 258 144 -12 air
execute in minecraft:overworld run fill 258 61 -12 258 64 -12 water
execute in minecraft:overworld run fill 258 58 -11 258 57 -11 stone
execute in minecraft:overworld run fill 258 58 -11 258 59 -11 dirt
execute in minecraft:overworld run setblock 258 60 -11 gravel
execute in minecraft:overworld run fill 258 61 -11 258 144 -11 air
execute in minecraft:overworld run fill 258 61 -11 258 64 -11 water
execute in minecraft:overworld run fill 258 58 -10 258 57 -10 stone
execute in minecraft:overworld run fill 258 58 -10 258 59 -10 dirt
execute in minecraft:overworld run setblock 258 60 -10 gravel
execute in minecraft:overworld run fill 258 61 -10 258 144 -10 air
execute in minecraft:overworld run fill 258 61 -10 258 64 -10 water
execute in minecraft:overworld run fill 258 58 -9 258 57 -9 stone
execute in minecraft:overworld run fill 258 58 -9 258 59 -9 dirt
execute in minecraft:overworld run setblock 258 60 -9 gravel
execute in minecraft:overworld run fill 258 61 -9 258 144 -9 air
execute in minecraft:overworld run fill 258 61 -9 258 64 -9 water
execute in minecraft:overworld run fill 258 58 -8 258 57 -8 stone
execute in minecraft:overworld run fill 258 58 -8 258 59 -8 dirt
execute in minecraft:overworld run setblock 258 60 -8 gravel
execute in minecraft:overworld run fill 258 61 -8 258 144 -8 air
execute in minecraft:overworld run fill 258 61 -8 258 64 -8 water
execute in minecraft:overworld run fill 258 58 -7 258 57 -7 stone
execute in minecraft:overworld run fill 258 58 -7 258 59 -7 dirt
execute in minecraft:overworld run setblock 258 60 -7 gravel
execute in minecraft:overworld run fill 258 61 -7 258 144 -7 air
execute in minecraft:overworld run fill 258 61 -7 258 64 -7 water
execute in minecraft:overworld run fill 258 58 -6 258 57 -6 stone
execute in minecraft:overworld run fill 258 58 -6 258 59 -6 dirt
execute in minecraft:overworld run setblock 258 60 -6 gravel
execute in minecraft:overworld run fill 258 61 -6 258 144 -6 air
execute in minecraft:overworld run fill 258 61 -6 258 64 -6 water
execute in minecraft:overworld run fill 258 58 -5 258 57 -5 stone
execute in minecraft:overworld run fill 258 58 -5 258 59 -5 dirt
execute in minecraft:overworld run setblock 258 60 -5 gravel
execute in minecraft:overworld run fill 258 61 -5 258 144 -5 air
execute in minecraft:overworld run fill 258 61 -5 258 64 -5 water
execute in minecraft:overworld run fill 258 58 -4 258 57 -4 stone
execute in minecraft:overworld run fill 258 58 -4 258 59 -4 dirt
execute in minecraft:overworld run setblock 258 60 -4 gravel
execute in minecraft:overworld run fill 258 61 -4 258 144 -4 air
execute in minecraft:overworld run fill 258 61 -4 258 64 -4 water
execute in minecraft:overworld run fill 258 58 -3 258 57 -3 stone
execute in minecraft:overworld run fill 258 58 -3 258 59 -3 dirt
execute in minecraft:overworld run setblock 258 60 -3 gravel
execute in minecraft:overworld run fill 258 61 -3 258 144 -3 air
execute in minecraft:overworld run fill 258 61 -3 258 64 -3 water
execute in minecraft:overworld run fill 258 58 -2 258 57 -2 stone
execute in minecraft:overworld run fill 258 58 -2 258 59 -2 dirt
execute in minecraft:overworld run setblock 258 60 -2 gravel
execute in minecraft:overworld run fill 258 61 -2 258 144 -2 air
execute in minecraft:overworld run fill 258 61 -2 258 64 -2 water
execute in minecraft:overworld run fill 258 58 -1 258 57 -1 stone
execute in minecraft:overworld run fill 258 58 -1 258 59 -1 dirt
execute in minecraft:overworld run setblock 258 60 -1 gravel
execute in minecraft:overworld run fill 258 61 -1 258 144 -1 air
execute in minecraft:overworld run fill 258 61 -1 258 64 -1 water
execute in minecraft:overworld run fill 258 58 0 258 57 0 stone
execute in minecraft:overworld run fill 258 58 0 258 59 0 dirt
execute in minecraft:overworld run setblock 258 60 0 gravel
execute in minecraft:overworld run fill 258 61 0 258 144 0 air
execute in minecraft:overworld run fill 258 61 0 258 64 0 water
execute in minecraft:overworld run fill 258 58 1 258 57 1 stone
execute in minecraft:overworld run fill 258 58 1 258 59 1 dirt
execute in minecraft:overworld run setblock 258 60 1 gravel
execute in minecraft:overworld run fill 258 61 1 258 144 1 air
execute in minecraft:overworld run fill 258 61 1 258 64 1 water
execute in minecraft:overworld run fill 258 58 2 258 58 2 stone
execute in minecraft:overworld run fill 258 59 2 258 60 2 dirt
execute in minecraft:overworld run setblock 258 61 2 gravel
execute in minecraft:overworld run fill 258 62 2 258 144 2 air
execute in minecraft:overworld run fill 258 62 2 258 64 2 water
execute in minecraft:overworld run fill 258 58 3 258 58 3 stone
execute in minecraft:overworld run fill 258 59 3 258 60 3 dirt
execute in minecraft:overworld run setblock 258 61 3 gravel
execute in minecraft:overworld run fill 258 62 3 258 144 3 air
execute in minecraft:overworld run fill 258 62 3 258 64 3 water
execute in minecraft:overworld run fill 258 58 4 258 58 4 stone
execute in minecraft:overworld run fill 258 59 4 258 60 4 dirt
execute in minecraft:overworld run setblock 258 61 4 gravel
execute in minecraft:overworld run fill 258 62 4 258 144 4 air
execute in minecraft:overworld run fill 258 62 4 258 64 4 water
execute in minecraft:overworld run fill 258 58 5 258 59 5 stone
execute in minecraft:overworld run fill 258 60 5 258 61 5 dirt
execute in minecraft:overworld run setblock 258 62 5 gravel
execute in minecraft:overworld run fill 258 63 5 258 144 5 air
execute in minecraft:overworld run fill 258 63 5 258 64 5 water
execute in minecraft:overworld run fill 258 58 6 258 59 6 stone
execute in minecraft:overworld run fill 258 60 6 258 61 6 dirt
execute in minecraft:overworld run setblock 258 62 6 gravel
execute in minecraft:overworld run fill 258 63 6 258 144 6 air
execute in minecraft:overworld run fill 258 63 6 258 64 6 water
execute in minecraft:overworld run fill 258 58 7 258 59 7 stone
execute in minecraft:overworld run fill 258 60 7 258 61 7 dirt
execute in minecraft:overworld run setblock 258 62 7 gravel
execute in minecraft:overworld run fill 258 63 7 258 144 7 air
execute in minecraft:overworld run fill 258 63 7 258 64 7 water
execute in minecraft:overworld run fill 258 58 8 258 59 8 stone
execute in minecraft:overworld run fill 258 60 8 258 61 8 dirt
execute in minecraft:overworld run setblock 258 62 8 gravel
execute in minecraft:overworld run fill 258 63 8 258 144 8 air
execute in minecraft:overworld run fill 258 63 8 258 64 8 water
execute in minecraft:overworld run fill 258 58 9 258 59 9 stone
execute in minecraft:overworld run fill 258 60 9 258 61 9 dirt
execute in minecraft:overworld run setblock 258 62 9 gravel
execute in minecraft:overworld run fill 258 63 9 258 144 9 air
execute in minecraft:overworld run fill 258 63 9 258 64 9 water
execute in minecraft:overworld run fill 258 58 10 258 60 10 stone
execute in minecraft:overworld run fill 258 61 10 258 62 10 dirt
execute in minecraft:overworld run setblock 258 63 10 gravel
execute in minecraft:overworld run fill 258 64 10 258 144 10 air
execute in minecraft:overworld run fill 258 64 10 258 64 10 water
execute in minecraft:overworld run fill 258 58 11 258 60 11 stone
execute in minecraft:overworld run fill 258 61 11 258 62 11 dirt
execute in minecraft:overworld run setblock 258 63 11 gravel
execute in minecraft:overworld run fill 258 64 11 258 144 11 air
execute in minecraft:overworld run fill 258 64 11 258 64 11 water
execute in minecraft:overworld run fill 258 58 12 258 60 12 stone
execute in minecraft:overworld run fill 258 61 12 258 62 12 dirt
execute in minecraft:overworld run setblock 258 63 12 gravel
execute in minecraft:overworld run fill 258 64 12 258 144 12 air
execute in minecraft:overworld run fill 258 64 12 258 64 12 water
execute in minecraft:overworld run fill 258 58 13 258 61 13 stone
execute in minecraft:overworld run fill 258 62 13 258 63 13 dirt
execute in minecraft:overworld run setblock 258 64 13 grass_block
execute in minecraft:overworld run fill 258 65 13 258 144 13 air
execute in minecraft:overworld run fill 258 58 14 258 61 14 stone
execute in minecraft:overworld run fill 258 62 14 258 63 14 dirt
execute in minecraft:overworld run setblock 258 64 14 coarse_dirt
execute in minecraft:overworld run fill 258 65 14 258 144 14 air
execute in minecraft:overworld run fill 258 58 15 258 62 15 stone
execute in minecraft:overworld run fill 258 63 15 258 64 15 dirt
execute in minecraft:overworld run setblock 258 65 15 grass_block
execute in minecraft:overworld run fill 258 66 15 258 144 15 air
execute in minecraft:overworld run fill 258 58 16 258 62 16 stone
execute in minecraft:overworld run fill 258 63 16 258 64 16 dirt
execute in minecraft:overworld run setblock 258 65 16 coarse_dirt
execute in minecraft:overworld run fill 258 66 16 258 144 16 air
execute in minecraft:overworld run fill 258 58 17 258 62 17 stone
execute in minecraft:overworld run fill 258 63 17 258 64 17 dirt
execute in minecraft:overworld run setblock 258 65 17 coarse_dirt
execute in minecraft:overworld run fill 258 66 17 258 144 17 air
execute in minecraft:overworld run fill 258 58 18 258 62 18 stone
execute in minecraft:overworld run fill 258 63 18 258 64 18 dirt
execute in minecraft:overworld run setblock 258 65 18 coarse_dirt
execute in minecraft:overworld run fill 258 66 18 258 144 18 air
execute in minecraft:overworld run fill 258 58 19 258 62 19 stone
execute in minecraft:overworld run fill 258 63 19 258 64 19 dirt
execute in minecraft:overworld run setblock 258 65 19 coarse_dirt
execute in minecraft:overworld run fill 258 66 19 258 144 19 air
execute in minecraft:overworld run fill 258 58 20 258 62 20 stone
execute in minecraft:overworld run fill 258 63 20 258 64 20 dirt
execute in minecraft:overworld run setblock 258 65 20 coarse_dirt
execute in minecraft:overworld run fill 258 66 20 258 144 20 air
execute in minecraft:overworld run fill 258 58 21 258 62 21 stone
execute in minecraft:overworld run fill 258 63 21 258 64 21 dirt
execute in minecraft:overworld run setblock 258 65 21 coarse_dirt
execute in minecraft:overworld run fill 258 66 21 258 144 21 air
execute in minecraft:overworld run fill 258 58 22 258 62 22 stone
execute in minecraft:overworld run fill 258 63 22 258 64 22 dirt
execute in minecraft:overworld run setblock 258 65 22 grass_block
execute in minecraft:overworld run fill 258 66 22 258 144 22 air
execute in minecraft:overworld run fill 258 58 23 258 62 23 stone
execute in minecraft:overworld run fill 258 63 23 258 64 23 dirt
execute in minecraft:overworld run setblock 258 65 23 grass_block
execute in minecraft:overworld run fill 258 66 23 258 144 23 air
execute in minecraft:overworld run fill 258 58 24 258 62 24 stone
execute in minecraft:overworld run fill 258 63 24 258 64 24 dirt
execute in minecraft:overworld run setblock 258 65 24 coarse_dirt
execute in minecraft:overworld run fill 258 66 24 258 144 24 air
execute in minecraft:overworld run fill 258 58 25 258 61 25 stone
execute in minecraft:overworld run fill 258 62 25 258 63 25 dirt
execute in minecraft:overworld run setblock 258 64 25 coarse_dirt
execute in minecraft:overworld run fill 258 65 25 258 144 25 air
execute in minecraft:overworld run fill 258 58 26 258 61 26 stone
execute in minecraft:overworld run fill 258 62 26 258 63 26 dirt
execute in minecraft:overworld run setblock 258 64 26 coarse_dirt
execute in minecraft:overworld run fill 258 65 26 258 144 26 air
execute in minecraft:overworld run fill 258 58 27 258 61 27 stone
execute in minecraft:overworld run fill 258 62 27 258 63 27 dirt
execute in minecraft:overworld run setblock 258 64 27 coarse_dirt
execute in minecraft:overworld run fill 258 65 27 258 144 27 air
execute in minecraft:overworld run fill 258 58 28 258 61 28 stone
execute in minecraft:overworld run fill 258 62 28 258 63 28 dirt
execute in minecraft:overworld run setblock 258 64 28 coarse_dirt
execute in minecraft:overworld run fill 258 65 28 258 144 28 air
execute in minecraft:overworld run fill 258 58 29 258 60 29 stone
execute in minecraft:overworld run fill 258 61 29 258 62 29 dirt
execute in minecraft:overworld run setblock 258 63 29 gravel
execute in minecraft:overworld run fill 258 64 29 258 144 29 air
execute in minecraft:overworld run fill 258 64 29 258 64 29 water
execute in minecraft:overworld run fill 258 58 30 258 60 30 stone
execute in minecraft:overworld run fill 258 61 30 258 62 30 dirt
execute in minecraft:overworld run setblock 258 63 30 gravel
execute in minecraft:overworld run fill 258 64 30 258 144 30 air
execute in minecraft:overworld run fill 258 64 30 258 64 30 water
execute in minecraft:overworld run fill 258 58 31 258 60 31 stone
execute in minecraft:overworld run fill 258 61 31 258 62 31 dirt
execute in minecraft:overworld run setblock 258 63 31 gravel
execute in minecraft:overworld run fill 258 64 31 258 144 31 air
execute in minecraft:overworld run fill 258 64 31 258 64 31 water
execute in minecraft:overworld run fill 258 58 32 258 59 32 stone
execute in minecraft:overworld run fill 258 60 32 258 61 32 dirt
execute in minecraft:overworld run setblock 258 62 32 gravel
execute in minecraft:overworld run fill 258 63 32 258 144 32 air
execute in minecraft:overworld run fill 258 63 32 258 64 32 water
execute in minecraft:overworld run fill 258 58 33 258 59 33 stone
execute in minecraft:overworld run fill 258 60 33 258 61 33 dirt
execute in minecraft:overworld run setblock 258 62 33 gravel
execute in minecraft:overworld run fill 258 63 33 258 144 33 air
execute in minecraft:overworld run fill 258 63 33 258 64 33 water
execute in minecraft:overworld run fill 258 58 34 258 58 34 stone
execute in minecraft:overworld run fill 258 59 34 258 60 34 dirt
execute in minecraft:overworld run setblock 258 61 34 gravel
execute in minecraft:overworld run fill 258 62 34 258 144 34 air
execute in minecraft:overworld run fill 258 62 34 258 64 34 water
execute in minecraft:overworld run fill 258 58 35 258 58 35 stone
execute in minecraft:overworld run fill 258 59 35 258 60 35 dirt
execute in minecraft:overworld run setblock 258 61 35 gravel
execute in minecraft:overworld run fill 258 62 35 258 144 35 air
execute in minecraft:overworld run fill 258 62 35 258 64 35 water
execute in minecraft:overworld run fill 258 58 36 258 57 36 stone
execute in minecraft:overworld run fill 258 58 36 258 59 36 dirt
execute in minecraft:overworld run setblock 258 60 36 gravel
execute in minecraft:overworld run fill 258 61 36 258 144 36 air
execute in minecraft:overworld run fill 258 61 36 258 64 36 water
execute in minecraft:overworld run fill 258 58 37 258 57 37 stone
execute in minecraft:overworld run fill 258 58 37 258 59 37 dirt
execute in minecraft:overworld run setblock 258 60 37 gravel
execute in minecraft:overworld run fill 258 61 37 258 144 37 air
schedule function blade_gallery:random/burned/part_79 1t replace
