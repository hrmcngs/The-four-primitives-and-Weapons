execute in minecraft:overworld run fill 261 74 -26 261 75 -26 dirt
execute in minecraft:overworld run setblock 261 76 -26 coarse_dirt
execute in minecraft:overworld run fill 261 77 -26 261 144 -26 air
execute in minecraft:overworld run setblock 261 77 -26 mossy_cobblestone
execute in minecraft:overworld run fill 261 58 -25 261 71 -25 stone
execute in minecraft:overworld run fill 261 72 -25 261 73 -25 dirt
execute in minecraft:overworld run setblock 261 74 -25 coarse_dirt
execute in minecraft:overworld run fill 261 75 -25 261 144 -25 air
execute in minecraft:overworld run fill 261 58 -24 261 70 -24 stone
execute in minecraft:overworld run fill 261 71 -24 261 72 -24 dirt
execute in minecraft:overworld run setblock 261 73 -24 coarse_dirt
execute in minecraft:overworld run fill 261 74 -24 261 144 -24 air
execute in minecraft:overworld run fill 261 58 -23 261 69 -23 stone
execute in minecraft:overworld run fill 261 70 -23 261 71 -23 dirt
execute in minecraft:overworld run setblock 261 72 -23 grass_block
execute in minecraft:overworld run fill 261 73 -23 261 144 -23 air
execute in minecraft:overworld run fill 261 58 -22 261 68 -22 stone
execute in minecraft:overworld run fill 261 69 -22 261 70 -22 dirt
execute in minecraft:overworld run setblock 261 71 -22 coarse_dirt
execute in minecraft:overworld run fill 261 72 -22 261 144 -22 air
execute in minecraft:overworld run fill 261 58 -21 261 67 -21 stone
execute in minecraft:overworld run fill 261 68 -21 261 69 -21 dirt
execute in minecraft:overworld run setblock 261 70 -21 grass_block
execute in minecraft:overworld run fill 261 71 -21 261 144 -21 air
execute in minecraft:overworld run fill 261 58 -20 261 65 -20 stone
execute in minecraft:overworld run fill 261 66 -20 261 67 -20 dirt
execute in minecraft:overworld run setblock 261 68 -20 grass_block
execute in minecraft:overworld run fill 261 69 -20 261 144 -20 air
execute in minecraft:overworld run fill 261 58 -19 261 64 -19 stone
execute in minecraft:overworld run fill 261 65 -19 261 66 -19 dirt
execute in minecraft:overworld run setblock 261 67 -19 grass_block
execute in minecraft:overworld run fill 261 68 -19 261 144 -19 air
execute in minecraft:overworld run fill 261 58 -18 261 63 -18 stone
execute in minecraft:overworld run fill 261 64 -18 261 65 -18 dirt
execute in minecraft:overworld run setblock 261 66 -18 grass_block
execute in minecraft:overworld run fill 261 67 -18 261 144 -18 air
execute in minecraft:overworld run fill 261 58 -17 261 62 -17 stone
execute in minecraft:overworld run fill 261 63 -17 261 64 -17 dirt
execute in minecraft:overworld run setblock 261 65 -17 grass_block
execute in minecraft:overworld run fill 261 66 -17 261 144 -17 air
execute in minecraft:overworld run fill 261 58 -16 261 61 -16 stone
execute in minecraft:overworld run fill 261 62 -16 261 63 -16 dirt
execute in minecraft:overworld run setblock 261 64 -16 grass_block
execute in minecraft:overworld run fill 261 65 -16 261 144 -16 air
execute in minecraft:overworld run fill 261 58 -15 261 60 -15 stone
execute in minecraft:overworld run fill 261 61 -15 261 62 -15 dirt
execute in minecraft:overworld run setblock 261 63 -15 gravel
execute in minecraft:overworld run fill 261 64 -15 261 144 -15 air
execute in minecraft:overworld run fill 261 64 -15 261 64 -15 water
execute in minecraft:overworld run fill 261 58 -14 261 59 -14 stone
execute in minecraft:overworld run fill 261 60 -14 261 61 -14 dirt
execute in minecraft:overworld run setblock 261 62 -14 gravel
execute in minecraft:overworld run fill 261 63 -14 261 144 -14 air
execute in minecraft:overworld run fill 261 63 -14 261 64 -14 water
execute in minecraft:overworld run fill 261 58 -13 261 58 -13 stone
execute in minecraft:overworld run fill 261 59 -13 261 60 -13 dirt
execute in minecraft:overworld run setblock 261 61 -13 gravel
execute in minecraft:overworld run fill 261 62 -13 261 144 -13 air
execute in minecraft:overworld run fill 261 62 -13 261 64 -13 water
execute in minecraft:overworld run fill 261 58 -12 261 57 -12 stone
execute in minecraft:overworld run fill 261 58 -12 261 59 -12 dirt
execute in minecraft:overworld run setblock 261 60 -12 gravel
execute in minecraft:overworld run fill 261 61 -12 261 144 -12 air
execute in minecraft:overworld run fill 261 61 -12 261 64 -12 water
execute in minecraft:overworld run fill 261 58 -11 261 56 -11 stone
execute in minecraft:overworld run fill 261 57 -11 261 58 -11 dirt
execute in minecraft:overworld run setblock 261 59 -11 gravel
execute in minecraft:overworld run fill 261 60 -11 261 144 -11 air
execute in minecraft:overworld run fill 261 60 -11 261 64 -11 water
execute in minecraft:overworld run fill 261 58 -10 261 56 -10 stone
execute in minecraft:overworld run fill 261 57 -10 261 58 -10 dirt
execute in minecraft:overworld run setblock 261 59 -10 gravel
execute in minecraft:overworld run fill 261 60 -10 261 144 -10 air
execute in minecraft:overworld run fill 261 60 -10 261 64 -10 water
execute in minecraft:overworld run fill 261 58 -9 261 56 -9 stone
execute in minecraft:overworld run fill 261 57 -9 261 58 -9 dirt
execute in minecraft:overworld run setblock 261 59 -9 gravel
execute in minecraft:overworld run fill 261 60 -9 261 144 -9 air
execute in minecraft:overworld run fill 261 60 -9 261 64 -9 water
execute in minecraft:overworld run fill 261 58 -8 261 56 -8 stone
execute in minecraft:overworld run fill 261 57 -8 261 58 -8 dirt
execute in minecraft:overworld run setblock 261 59 -8 gravel
execute in minecraft:overworld run fill 261 60 -8 261 144 -8 air
execute in minecraft:overworld run fill 261 60 -8 261 64 -8 water
execute in minecraft:overworld run fill 261 58 -7 261 55 -7 stone
execute in minecraft:overworld run fill 261 56 -7 261 57 -7 dirt
execute in minecraft:overworld run setblock 261 58 -7 gravel
execute in minecraft:overworld run fill 261 59 -7 261 144 -7 air
execute in minecraft:overworld run fill 261 59 -7 261 64 -7 water
execute in minecraft:overworld run fill 261 58 -6 261 55 -6 stone
execute in minecraft:overworld run fill 261 56 -6 261 57 -6 dirt
execute in minecraft:overworld run setblock 261 58 -6 gravel
execute in minecraft:overworld run fill 261 59 -6 261 144 -6 air
execute in minecraft:overworld run fill 261 59 -6 261 64 -6 water
execute in minecraft:overworld run fill 261 58 -5 261 55 -5 stone
execute in minecraft:overworld run fill 261 56 -5 261 57 -5 dirt
execute in minecraft:overworld run setblock 261 58 -5 gravel
execute in minecraft:overworld run fill 261 59 -5 261 144 -5 air
execute in minecraft:overworld run fill 261 59 -5 261 64 -5 water
execute in minecraft:overworld run fill 261 58 -4 261 55 -4 stone
execute in minecraft:overworld run fill 261 56 -4 261 57 -4 dirt
execute in minecraft:overworld run setblock 261 58 -4 gravel
execute in minecraft:overworld run fill 261 59 -4 261 144 -4 air
execute in minecraft:overworld run fill 261 59 -4 261 64 -4 water
execute in minecraft:overworld run fill 261 58 -3 261 55 -3 stone
execute in minecraft:overworld run fill 261 56 -3 261 57 -3 dirt
execute in minecraft:overworld run setblock 261 58 -3 gravel
execute in minecraft:overworld run fill 261 59 -3 261 144 -3 air
execute in minecraft:overworld run fill 261 59 -3 261 64 -3 water
execute in minecraft:overworld run fill 261 58 -2 261 55 -2 stone
execute in minecraft:overworld run fill 261 56 -2 261 57 -2 dirt
execute in minecraft:overworld run setblock 261 58 -2 gravel
execute in minecraft:overworld run fill 261 59 -2 261 144 -2 air
execute in minecraft:overworld run fill 261 59 -2 261 64 -2 water
execute in minecraft:overworld run fill 261 58 -1 261 55 -1 stone
execute in minecraft:overworld run fill 261 56 -1 261 57 -1 dirt
execute in minecraft:overworld run setblock 261 58 -1 gravel
execute in minecraft:overworld run fill 261 59 -1 261 144 -1 air
execute in minecraft:overworld run fill 261 59 -1 261 64 -1 water
execute in minecraft:overworld run fill 261 58 0 261 55 0 stone
execute in minecraft:overworld run fill 261 56 0 261 57 0 dirt
execute in minecraft:overworld run setblock 261 58 0 gravel
execute in minecraft:overworld run fill 261 59 0 261 144 0 air
execute in minecraft:overworld run fill 261 59 0 261 64 0 water
execute in minecraft:overworld run fill 261 58 1 261 56 1 stone
execute in minecraft:overworld run fill 261 57 1 261 58 1 dirt
execute in minecraft:overworld run setblock 261 59 1 gravel
execute in minecraft:overworld run fill 261 60 1 261 144 1 air
execute in minecraft:overworld run fill 261 60 1 261 64 1 water
execute in minecraft:overworld run fill 261 58 2 261 56 2 stone
execute in minecraft:overworld run fill 261 57 2 261 58 2 dirt
execute in minecraft:overworld run setblock 261 59 2 gravel
execute in minecraft:overworld run fill 261 60 2 261 144 2 air
execute in minecraft:overworld run fill 261 60 2 261 64 2 water
execute in minecraft:overworld run fill 261 58 3 261 56 3 stone
execute in minecraft:overworld run fill 261 57 3 261 58 3 dirt
execute in minecraft:overworld run setblock 261 59 3 gravel
execute in minecraft:overworld run fill 261 60 3 261 144 3 air
execute in minecraft:overworld run fill 261 60 3 261 64 3 water
execute in minecraft:overworld run fill 261 58 4 261 56 4 stone
execute in minecraft:overworld run fill 261 57 4 261 58 4 dirt
execute in minecraft:overworld run setblock 261 59 4 gravel
execute in minecraft:overworld run fill 261 60 4 261 144 4 air
execute in minecraft:overworld run fill 261 60 4 261 64 4 water
execute in minecraft:overworld run fill 261 58 5 261 57 5 stone
execute in minecraft:overworld run fill 261 58 5 261 59 5 dirt
execute in minecraft:overworld run setblock 261 60 5 gravel
execute in minecraft:overworld run fill 261 61 5 261 144 5 air
execute in minecraft:overworld run fill 261 61 5 261 64 5 water
execute in minecraft:overworld run fill 261 58 6 261 57 6 stone
execute in minecraft:overworld run fill 261 58 6 261 59 6 dirt
execute in minecraft:overworld run setblock 261 60 6 gravel
execute in minecraft:overworld run fill 261 61 6 261 144 6 air
execute in minecraft:overworld run fill 261 61 6 261 64 6 water
execute in minecraft:overworld run fill 261 58 7 261 57 7 stone
execute in minecraft:overworld run fill 261 58 7 261 59 7 dirt
execute in minecraft:overworld run setblock 261 60 7 gravel
execute in minecraft:overworld run fill 261 61 7 261 144 7 air
execute in minecraft:overworld run fill 261 61 7 261 64 7 water
execute in minecraft:overworld run fill 261 58 8 261 57 8 stone
execute in minecraft:overworld run fill 261 58 8 261 59 8 dirt
execute in minecraft:overworld run setblock 261 60 8 gravel
execute in minecraft:overworld run fill 261 61 8 261 144 8 air
execute in minecraft:overworld run fill 261 61 8 261 64 8 water
execute in minecraft:overworld run fill 261 58 9 261 57 9 stone
execute in minecraft:overworld run fill 261 58 9 261 59 9 dirt
execute in minecraft:overworld run setblock 261 60 9 gravel
execute in minecraft:overworld run fill 261 61 9 261 144 9 air
execute in minecraft:overworld run fill 261 61 9 261 64 9 water
execute in minecraft:overworld run fill 261 58 10 261 58 10 stone
execute in minecraft:overworld run fill 261 59 10 261 60 10 dirt
execute in minecraft:overworld run setblock 261 61 10 gravel
execute in minecraft:overworld run fill 261 62 10 261 144 10 air
execute in minecraft:overworld run fill 261 62 10 261 64 10 water
execute in minecraft:overworld run fill 261 58 11 261 58 11 stone
execute in minecraft:overworld run fill 261 59 11 261 60 11 dirt
execute in minecraft:overworld run setblock 261 61 11 gravel
execute in minecraft:overworld run fill 261 62 11 261 144 11 air
execute in minecraft:overworld run fill 261 62 11 261 64 11 water
execute in minecraft:overworld run fill 261 58 12 261 58 12 stone
execute in minecraft:overworld run fill 261 59 12 261 60 12 dirt
execute in minecraft:overworld run setblock 261 61 12 gravel
execute in minecraft:overworld run fill 261 62 12 261 144 12 air
execute in minecraft:overworld run fill 261 62 12 261 64 12 water
execute in minecraft:overworld run fill 261 58 13 261 59 13 stone
execute in minecraft:overworld run fill 261 60 13 261 61 13 dirt
execute in minecraft:overworld run setblock 261 62 13 gravel
execute in minecraft:overworld run fill 261 63 13 261 144 13 air
execute in minecraft:overworld run fill 261 63 13 261 64 13 water
execute in minecraft:overworld run fill 261 58 14 261 59 14 stone
execute in minecraft:overworld run fill 261 60 14 261 61 14 dirt
execute in minecraft:overworld run setblock 261 62 14 gravel
execute in minecraft:overworld run fill 261 63 14 261 144 14 air
execute in minecraft:overworld run fill 261 63 14 261 64 14 water
execute in minecraft:overworld run fill 261 58 15 261 60 15 stone
execute in minecraft:overworld run fill 261 61 15 261 62 15 dirt
execute in minecraft:overworld run setblock 261 63 15 gravel
execute in minecraft:overworld run fill 261 64 15 261 144 15 air
execute in minecraft:overworld run fill 261 64 15 261 64 15 water
execute in minecraft:overworld run fill 261 58 16 261 60 16 stone
execute in minecraft:overworld run fill 261 61 16 261 62 16 dirt
execute in minecraft:overworld run setblock 261 63 16 gravel
execute in minecraft:overworld run fill 261 64 16 261 144 16 air
execute in minecraft:overworld run fill 261 64 16 261 64 16 water
execute in minecraft:overworld run fill 261 58 17 261 60 17 stone
execute in minecraft:overworld run fill 261 61 17 261 62 17 dirt
execute in minecraft:overworld run setblock 261 63 17 gravel
execute in minecraft:overworld run fill 261 64 17 261 144 17 air
execute in minecraft:overworld run fill 261 64 17 261 64 17 water
execute in minecraft:overworld run fill 261 58 18 261 60 18 stone
execute in minecraft:overworld run fill 261 61 18 261 62 18 dirt
execute in minecraft:overworld run setblock 261 63 18 gravel
execute in minecraft:overworld run fill 261 64 18 261 144 18 air
execute in minecraft:overworld run fill 261 64 18 261 64 18 water
execute in minecraft:overworld run fill 261 58 19 261 60 19 stone
execute in minecraft:overworld run fill 261 61 19 261 62 19 dirt
execute in minecraft:overworld run setblock 261 63 19 gravel
execute in minecraft:overworld run fill 261 64 19 261 144 19 air
execute in minecraft:overworld run fill 261 64 19 261 64 19 water
execute in minecraft:overworld run fill 261 58 20 261 60 20 stone
execute in minecraft:overworld run fill 261 61 20 261 62 20 dirt
execute in minecraft:overworld run setblock 261 63 20 gravel
execute in minecraft:overworld run fill 261 64 20 261 144 20 air
execute in minecraft:overworld run fill 261 64 20 261 64 20 water
execute in minecraft:overworld run fill 261 58 21 261 60 21 stone
execute in minecraft:overworld run fill 261 61 21 261 62 21 dirt
execute in minecraft:overworld run setblock 261 63 21 gravel
execute in minecraft:overworld run fill 261 64 21 261 144 21 air
execute in minecraft:overworld run fill 261 64 21 261 64 21 water
execute in minecraft:overworld run fill 261 58 22 261 59 22 stone
execute in minecraft:overworld run fill 261 60 22 261 61 22 dirt
execute in minecraft:overworld run setblock 261 62 22 gravel
execute in minecraft:overworld run fill 261 63 22 261 144 22 air
execute in minecraft:overworld run fill 261 63 22 261 64 22 water
execute in minecraft:overworld run fill 261 58 23 261 59 23 stone
execute in minecraft:overworld run fill 261 60 23 261 61 23 dirt
execute in minecraft:overworld run setblock 261 62 23 gravel
execute in minecraft:overworld run fill 261 63 23 261 144 23 air
execute in minecraft:overworld run fill 261 63 23 261 64 23 water
execute in minecraft:overworld run fill 261 58 24 261 59 24 stone
execute in minecraft:overworld run fill 261 60 24 261 61 24 dirt
execute in minecraft:overworld run setblock 261 62 24 gravel
execute in minecraft:overworld run fill 261 63 24 261 144 24 air
execute in minecraft:overworld run fill 261 63 24 261 64 24 water
execute in minecraft:overworld run fill 261 58 25 261 58 25 stone
execute in minecraft:overworld run fill 261 59 25 261 60 25 dirt
execute in minecraft:overworld run setblock 261 61 25 gravel
execute in minecraft:overworld run fill 261 62 25 261 144 25 air
execute in minecraft:overworld run fill 261 62 25 261 64 25 water
execute in minecraft:overworld run fill 261 58 26 261 58 26 stone
execute in minecraft:overworld run fill 261 59 26 261 60 26 dirt
execute in minecraft:overworld run setblock 261 61 26 gravel
execute in minecraft:overworld run fill 261 62 26 261 144 26 air
execute in minecraft:overworld run fill 261 62 26 261 64 26 water
execute in minecraft:overworld run fill 261 58 27 261 58 27 stone
execute in minecraft:overworld run fill 261 59 27 261 60 27 dirt
schedule function blade_gallery:random/burned/part_84 1t replace
