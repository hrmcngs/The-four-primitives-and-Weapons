execute in minecraft:overworld run fill 405 76 -37 405 77 -37 dirt
execute in minecraft:overworld run setblock 405 78 -37 grass_block
execute in minecraft:overworld run fill 405 79 -37 405 144 -37 air
execute in minecraft:overworld run fill 405 58 -36 405 75 -36 stone
execute in minecraft:overworld run fill 405 76 -36 405 77 -36 dirt
execute in minecraft:overworld run setblock 405 78 -36 coarse_dirt
execute in minecraft:overworld run fill 405 79 -36 405 144 -36 air
execute in minecraft:overworld run fill 405 58 -35 405 75 -35 stone
execute in minecraft:overworld run fill 405 76 -35 405 77 -35 dirt
execute in minecraft:overworld run setblock 405 78 -35 coarse_dirt
execute in minecraft:overworld run fill 405 79 -35 405 144 -35 air
execute in minecraft:overworld run fill 405 58 -34 405 74 -34 stone
execute in minecraft:overworld run fill 405 75 -34 405 76 -34 dirt
execute in minecraft:overworld run setblock 405 77 -34 coarse_dirt
execute in minecraft:overworld run fill 405 78 -34 405 144 -34 air
execute in minecraft:overworld run fill 405 58 -33 405 74 -33 stone
execute in minecraft:overworld run fill 405 75 -33 405 76 -33 dirt
execute in minecraft:overworld run setblock 405 77 -33 coarse_dirt
execute in minecraft:overworld run fill 405 78 -33 405 144 -33 air
execute in minecraft:overworld run fill 405 58 -32 405 74 -32 stone
execute in minecraft:overworld run fill 405 75 -32 405 76 -32 dirt
execute in minecraft:overworld run setblock 405 77 -32 coarse_dirt
execute in minecraft:overworld run fill 405 78 -32 405 144 -32 air
execute in minecraft:overworld run fill 405 58 -31 405 73 -31 stone
execute in minecraft:overworld run fill 405 74 -31 405 75 -31 dirt
execute in minecraft:overworld run setblock 405 76 -31 coarse_dirt
execute in minecraft:overworld run fill 405 77 -31 405 144 -31 air
execute in minecraft:overworld run fill 405 58 -30 405 73 -30 stone
execute in minecraft:overworld run fill 405 74 -30 405 75 -30 dirt
execute in minecraft:overworld run setblock 405 76 -30 coarse_dirt
execute in minecraft:overworld run fill 405 77 -30 405 144 -30 air
execute in minecraft:overworld run fill 405 58 -29 405 73 -29 stone
execute in minecraft:overworld run fill 405 74 -29 405 75 -29 dirt
execute in minecraft:overworld run setblock 405 76 -29 coarse_dirt
execute in minecraft:overworld run fill 405 77 -29 405 144 -29 air
execute in minecraft:overworld run fill 405 58 -28 405 72 -28 stone
execute in minecraft:overworld run fill 405 73 -28 405 74 -28 dirt
execute in minecraft:overworld run setblock 405 75 -28 coarse_dirt
execute in minecraft:overworld run fill 405 76 -28 405 144 -28 air
execute in minecraft:overworld run fill 405 58 -27 405 72 -27 stone
execute in minecraft:overworld run fill 405 73 -27 405 74 -27 dirt
execute in minecraft:overworld run setblock 405 75 -27 coarse_dirt
execute in minecraft:overworld run fill 405 76 -27 405 144 -27 air
execute in minecraft:overworld run fill 405 58 -26 405 72 -26 stone
execute in minecraft:overworld run fill 405 73 -26 405 74 -26 dirt
execute in minecraft:overworld run setblock 405 75 -26 coarse_dirt
execute in minecraft:overworld run fill 405 76 -26 405 144 -26 air
execute in minecraft:overworld run fill 405 58 -25 405 71 -25 stone
execute in minecraft:overworld run fill 405 72 -25 405 73 -25 dirt
execute in minecraft:overworld run setblock 405 74 -25 coarse_dirt
execute in minecraft:overworld run fill 405 75 -25 405 144 -25 air
execute in minecraft:overworld run fill 405 58 -24 405 71 -24 stone
execute in minecraft:overworld run fill 405 72 -24 405 73 -24 dirt
execute in minecraft:overworld run setblock 405 74 -24 coarse_dirt
execute in minecraft:overworld run fill 405 75 -24 405 144 -24 air
execute in minecraft:overworld run setblock 405 75 -24 grass
execute in minecraft:overworld run fill 405 58 -23 405 71 -23 stone
execute in minecraft:overworld run fill 405 72 -23 405 73 -23 dirt
execute in minecraft:overworld run setblock 405 74 -23 coarse_dirt
execute in minecraft:overworld run fill 405 75 -23 405 144 -23 air
execute in minecraft:overworld run fill 405 58 -22 405 70 -22 stone
execute in minecraft:overworld run fill 405 71 -22 405 72 -22 dirt
execute in minecraft:overworld run setblock 405 73 -22 coarse_dirt
execute in minecraft:overworld run fill 405 74 -22 405 144 -22 air
execute in minecraft:overworld run fill 405 58 -21 405 70 -21 stone
execute in minecraft:overworld run fill 405 71 -21 405 72 -21 dirt
execute in minecraft:overworld run setblock 405 73 -21 coarse_dirt
execute in minecraft:overworld run fill 405 74 -21 405 144 -21 air
execute in minecraft:overworld run setblock 405 74 -21 grass
execute in minecraft:overworld run fill 405 58 -20 405 70 -20 stone
execute in minecraft:overworld run fill 405 71 -20 405 72 -20 dirt
execute in minecraft:overworld run setblock 405 73 -20 coarse_dirt
execute in minecraft:overworld run fill 405 74 -20 405 144 -20 air
execute in minecraft:overworld run setblock 405 74 -20 mossy_cobblestone
execute in minecraft:overworld run fill 405 58 -19 405 69 -19 stone
execute in minecraft:overworld run fill 405 70 -19 405 71 -19 dirt
execute in minecraft:overworld run setblock 405 72 -19 grass_block
execute in minecraft:overworld run fill 405 73 -19 405 144 -19 air
execute in minecraft:overworld run fill 405 58 -18 405 69 -18 stone
execute in minecraft:overworld run fill 405 70 -18 405 71 -18 dirt
execute in minecraft:overworld run setblock 405 72 -18 coarse_dirt
execute in minecraft:overworld run fill 405 73 -18 405 144 -18 air
execute in minecraft:overworld run fill 405 58 -17 405 68 -17 stone
execute in minecraft:overworld run fill 405 69 -17 405 70 -17 dirt
execute in minecraft:overworld run setblock 405 71 -17 coarse_dirt
execute in minecraft:overworld run fill 405 72 -17 405 144 -17 air
execute in minecraft:overworld run setblock 405 72 -17 grass
execute in minecraft:overworld run fill 405 58 -16 405 67 -16 stone
execute in minecraft:overworld run fill 405 68 -16 405 69 -16 dirt
execute in minecraft:overworld run setblock 405 70 -16 coarse_dirt
execute in minecraft:overworld run fill 405 71 -16 405 144 -16 air
execute in minecraft:overworld run setblock 405 71 -16 grass
execute in minecraft:overworld run fill 405 58 -15 405 67 -15 stone
execute in minecraft:overworld run fill 405 68 -15 405 69 -15 dirt
execute in minecraft:overworld run setblock 405 70 -15 coarse_dirt
execute in minecraft:overworld run fill 405 71 -15 405 144 -15 air
execute in minecraft:overworld run fill 405 58 -14 405 66 -14 stone
execute in minecraft:overworld run fill 405 67 -14 405 68 -14 dirt
execute in minecraft:overworld run setblock 405 69 -14 coarse_dirt
execute in minecraft:overworld run fill 405 70 -14 405 144 -14 air
execute in minecraft:overworld run fill 405 58 -13 405 65 -13 stone
execute in minecraft:overworld run fill 405 66 -13 405 67 -13 dirt
execute in minecraft:overworld run setblock 405 68 -13 grass_block
execute in minecraft:overworld run fill 405 69 -13 405 144 -13 air
execute in minecraft:overworld run fill 405 58 -12 405 64 -12 stone
execute in minecraft:overworld run fill 405 65 -12 405 66 -12 dirt
execute in minecraft:overworld run setblock 405 67 -12 coarse_dirt
execute in minecraft:overworld run fill 405 68 -12 405 144 -12 air
execute in minecraft:overworld run fill 405 58 -11 405 63 -11 stone
execute in minecraft:overworld run fill 405 64 -11 405 65 -11 dirt
execute in minecraft:overworld run setblock 405 66 -11 coarse_dirt
execute in minecraft:overworld run fill 405 67 -11 405 144 -11 air
execute in minecraft:overworld run fill 405 58 -10 405 63 -10 stone
execute in minecraft:overworld run fill 405 64 -10 405 65 -10 dirt
execute in minecraft:overworld run setblock 405 66 -10 coarse_dirt
execute in minecraft:overworld run fill 405 67 -10 405 144 -10 air
execute in minecraft:overworld run fill 405 58 -9 405 62 -9 stone
execute in minecraft:overworld run fill 405 63 -9 405 64 -9 dirt
execute in minecraft:overworld run setblock 405 65 -9 coarse_dirt
execute in minecraft:overworld run fill 405 66 -9 405 144 -9 air
execute in minecraft:overworld run fill 405 58 -8 405 62 -8 stone
execute in minecraft:overworld run fill 405 63 -8 405 64 -8 dirt
execute in minecraft:overworld run setblock 405 65 -8 grass_block
execute in minecraft:overworld run fill 405 66 -8 405 144 -8 air
execute in minecraft:overworld run fill 405 58 -7 405 62 -7 stone
execute in minecraft:overworld run fill 405 63 -7 405 64 -7 dirt
execute in minecraft:overworld run setblock 405 65 -7 grass_block
execute in minecraft:overworld run fill 405 66 -7 405 144 -7 air
execute in minecraft:overworld run fill 405 58 -6 405 62 -6 stone
execute in minecraft:overworld run fill 405 63 -6 405 64 -6 dirt
execute in minecraft:overworld run setblock 405 65 -6 grass_block
execute in minecraft:overworld run fill 405 66 -6 405 144 -6 air
execute in minecraft:overworld run setblock 405 66 -6 mossy_cobblestone
execute in minecraft:overworld run fill 405 58 -5 405 62 -5 stone
execute in minecraft:overworld run fill 405 63 -5 405 64 -5 dirt
execute in minecraft:overworld run setblock 405 65 -5 coarse_dirt
execute in minecraft:overworld run fill 405 66 -5 405 144 -5 air
execute in minecraft:overworld run fill 405 58 -4 405 62 -4 stone
execute in minecraft:overworld run fill 405 63 -4 405 64 -4 dirt
execute in minecraft:overworld run setblock 405 65 -4 grass_block
execute in minecraft:overworld run fill 405 66 -4 405 144 -4 air
execute in minecraft:overworld run fill 405 58 -3 405 61 -3 stone
execute in minecraft:overworld run fill 405 62 -3 405 63 -3 dirt
execute in minecraft:overworld run setblock 405 64 -3 grass_block
execute in minecraft:overworld run fill 405 65 -3 405 144 -3 air
execute in minecraft:overworld run fill 405 58 -2 405 61 -2 stone
execute in minecraft:overworld run fill 405 62 -2 405 63 -2 dirt
execute in minecraft:overworld run setblock 405 64 -2 coarse_dirt
execute in minecraft:overworld run fill 405 65 -2 405 144 -2 air
execute in minecraft:overworld run fill 405 58 -1 405 61 -1 stone
execute in minecraft:overworld run fill 405 62 -1 405 63 -1 dirt
execute in minecraft:overworld run setblock 405 64 -1 coarse_dirt
execute in minecraft:overworld run fill 405 65 -1 405 144 -1 air
execute in minecraft:overworld run fill 405 58 0 405 61 0 stone
execute in minecraft:overworld run fill 405 62 0 405 63 0 dirt
execute in minecraft:overworld run setblock 405 64 0 grass_block
execute in minecraft:overworld run fill 405 65 0 405 144 0 air
execute in minecraft:overworld run fill 405 58 1 405 61 1 stone
execute in minecraft:overworld run fill 405 62 1 405 63 1 dirt
execute in minecraft:overworld run setblock 405 64 1 coarse_dirt
execute in minecraft:overworld run fill 405 65 1 405 144 1 air
execute in minecraft:overworld run fill 405 58 2 405 61 2 stone
execute in minecraft:overworld run fill 405 62 2 405 63 2 dirt
execute in minecraft:overworld run setblock 405 64 2 coarse_dirt
execute in minecraft:overworld run fill 405 65 2 405 144 2 air
execute in minecraft:overworld run fill 405 58 3 405 61 3 stone
execute in minecraft:overworld run fill 405 62 3 405 63 3 dirt
execute in minecraft:overworld run setblock 405 64 3 coarse_dirt
execute in minecraft:overworld run fill 405 65 3 405 144 3 air
execute in minecraft:overworld run fill 405 58 4 405 61 4 stone
execute in minecraft:overworld run fill 405 62 4 405 63 4 dirt
execute in minecraft:overworld run setblock 405 64 4 coarse_dirt
execute in minecraft:overworld run fill 405 65 4 405 144 4 air
execute in minecraft:overworld run fill 405 58 5 405 61 5 stone
execute in minecraft:overworld run fill 405 62 5 405 63 5 dirt
execute in minecraft:overworld run setblock 405 64 5 coarse_dirt
execute in minecraft:overworld run fill 405 65 5 405 144 5 air
execute in minecraft:overworld run fill 405 58 6 405 61 6 stone
execute in minecraft:overworld run fill 405 62 6 405 63 6 dirt
execute in minecraft:overworld run setblock 405 64 6 coarse_dirt
execute in minecraft:overworld run fill 405 65 6 405 144 6 air
execute in minecraft:overworld run fill 405 58 7 405 61 7 stone
execute in minecraft:overworld run fill 405 62 7 405 63 7 dirt
execute in minecraft:overworld run setblock 405 64 7 coarse_dirt
execute in minecraft:overworld run fill 405 65 7 405 144 7 air
execute in minecraft:overworld run fill 405 58 8 405 61 8 stone
execute in minecraft:overworld run fill 405 62 8 405 63 8 dirt
execute in minecraft:overworld run setblock 405 64 8 grass_block
execute in minecraft:overworld run fill 405 65 8 405 144 8 air
execute in minecraft:overworld run fill 405 58 9 405 61 9 stone
execute in minecraft:overworld run fill 405 62 9 405 63 9 dirt
execute in minecraft:overworld run setblock 405 64 9 coarse_dirt
execute in minecraft:overworld run fill 405 65 9 405 144 9 air
execute in minecraft:overworld run fill 405 58 10 405 62 10 stone
execute in minecraft:overworld run fill 405 63 10 405 64 10 dirt
execute in minecraft:overworld run setblock 405 65 10 coarse_dirt
execute in minecraft:overworld run fill 405 66 10 405 144 10 air
execute in minecraft:overworld run setblock 405 66 10 grass
execute in minecraft:overworld run fill 405 58 11 405 62 11 stone
execute in minecraft:overworld run fill 405 63 11 405 64 11 dirt
execute in minecraft:overworld run setblock 405 65 11 grass_block
execute in minecraft:overworld run fill 405 66 11 405 144 11 air
execute in minecraft:overworld run fill 405 58 12 405 62 12 stone
execute in minecraft:overworld run fill 405 63 12 405 64 12 dirt
execute in minecraft:overworld run setblock 405 65 12 coarse_dirt
execute in minecraft:overworld run fill 405 66 12 405 144 12 air
execute in minecraft:overworld run fill 405 58 13 405 62 13 stone
execute in minecraft:overworld run fill 405 63 13 405 64 13 dirt
execute in minecraft:overworld run setblock 405 65 13 grass_block
execute in minecraft:overworld run fill 405 66 13 405 144 13 air
execute in minecraft:overworld run fill 405 58 14 405 63 14 stone
execute in minecraft:overworld run fill 405 64 14 405 65 14 dirt
execute in minecraft:overworld run setblock 405 66 14 coarse_dirt
execute in minecraft:overworld run fill 405 67 14 405 144 14 air
execute in minecraft:overworld run fill 405 58 15 405 63 15 stone
execute in minecraft:overworld run fill 405 64 15 405 65 15 dirt
execute in minecraft:overworld run setblock 405 66 15 coarse_dirt
execute in minecraft:overworld run fill 405 67 15 405 144 15 air
execute in minecraft:overworld run fill 405 58 16 405 63 16 stone
execute in minecraft:overworld run fill 405 64 16 405 65 16 dirt
execute in minecraft:overworld run setblock 405 66 16 coarse_dirt
execute in minecraft:overworld run fill 405 67 16 405 144 16 air
execute in minecraft:overworld run fill 405 58 17 405 64 17 stone
execute in minecraft:overworld run fill 405 65 17 405 66 17 dirt
execute in minecraft:overworld run setblock 405 67 17 coarse_dirt
execute in minecraft:overworld run fill 405 68 17 405 144 17 air
execute in minecraft:overworld run fill 405 58 18 405 64 18 stone
execute in minecraft:overworld run fill 405 65 18 405 66 18 dirt
execute in minecraft:overworld run setblock 405 67 18 grass_block
execute in minecraft:overworld run fill 405 68 18 405 144 18 air
execute in minecraft:overworld run fill 405 58 19 405 64 19 stone
execute in minecraft:overworld run fill 405 65 19 405 66 19 dirt
execute in minecraft:overworld run setblock 405 67 19 coarse_dirt
execute in minecraft:overworld run fill 405 68 19 405 144 19 air
execute in minecraft:overworld run fill 405 58 20 405 65 20 stone
execute in minecraft:overworld run fill 405 66 20 405 67 20 dirt
execute in minecraft:overworld run setblock 405 68 20 grass_block
execute in minecraft:overworld run fill 405 69 20 405 144 20 air
execute in minecraft:overworld run fill 405 58 21 405 65 21 stone
execute in minecraft:overworld run fill 405 66 21 405 67 21 dirt
execute in minecraft:overworld run setblock 405 68 21 coarse_dirt
execute in minecraft:overworld run fill 405 69 21 405 144 21 air
execute in minecraft:overworld run setblock 405 69 21 grass
execute in minecraft:overworld run fill 405 58 22 405 65 22 stone
execute in minecraft:overworld run fill 405 66 22 405 67 22 dirt
execute in minecraft:overworld run setblock 405 68 22 grass_block
execute in minecraft:overworld run fill 405 69 22 405 144 22 air
execute in minecraft:overworld run fill 405 58 23 405 66 23 stone
execute in minecraft:overworld run fill 405 67 23 405 68 23 dirt
execute in minecraft:overworld run setblock 405 69 23 grass_block
execute in minecraft:overworld run fill 405 70 23 405 144 23 air
execute in minecraft:overworld run fill 405 58 24 405 66 24 stone
execute in minecraft:overworld run fill 405 67 24 405 68 24 dirt
execute in minecraft:overworld run setblock 405 69 24 coarse_dirt
execute in minecraft:overworld run fill 405 70 24 405 144 24 air
execute in minecraft:overworld run fill 405 58 25 405 67 25 stone
schedule function blade_gallery:random/battlefield/part_110 1t replace
