execute in minecraft:overworld run fill 291 58 8 291 67 8 stone
execute in minecraft:overworld run fill 291 68 8 291 69 8 dirt
execute in minecraft:overworld run setblock 291 70 8 grass_block
execute in minecraft:overworld run fill 291 71 8 291 144 8 air
execute in minecraft:overworld run fill 291 58 9 291 67 9 stone
execute in minecraft:overworld run fill 291 68 9 291 69 9 dirt
execute in minecraft:overworld run setblock 291 70 9 grass_block
execute in minecraft:overworld run fill 291 71 9 291 144 9 air
execute in minecraft:overworld run fill 291 58 10 291 66 10 stone
execute in minecraft:overworld run fill 291 67 10 291 68 10 dirt
execute in minecraft:overworld run setblock 291 69 10 coarse_dirt
execute in minecraft:overworld run fill 291 70 10 291 144 10 air
execute in minecraft:overworld run fill 291 58 11 291 66 11 stone
execute in minecraft:overworld run fill 291 67 11 291 68 11 dirt
execute in minecraft:overworld run setblock 291 69 11 coarse_dirt
execute in minecraft:overworld run fill 291 70 11 291 144 11 air
execute in minecraft:overworld run fill 291 58 12 291 66 12 stone
execute in minecraft:overworld run fill 291 67 12 291 68 12 dirt
execute in minecraft:overworld run setblock 291 69 12 coarse_dirt
execute in minecraft:overworld run fill 291 70 12 291 144 12 air
execute in minecraft:overworld run fill 291 58 13 291 66 13 stone
execute in minecraft:overworld run fill 291 67 13 291 68 13 dirt
execute in minecraft:overworld run setblock 291 69 13 grass_block
execute in minecraft:overworld run fill 291 70 13 291 144 13 air
execute in minecraft:overworld run fill 291 58 14 291 66 14 stone
execute in minecraft:overworld run fill 291 67 14 291 68 14 dirt
execute in minecraft:overworld run setblock 291 69 14 coarse_dirt
execute in minecraft:overworld run fill 291 70 14 291 144 14 air
execute in minecraft:overworld run fill 291 58 15 291 66 15 stone
execute in minecraft:overworld run fill 291 67 15 291 68 15 dirt
execute in minecraft:overworld run setblock 291 69 15 grass_block
execute in minecraft:overworld run fill 291 70 15 291 144 15 air
execute in minecraft:overworld run fill 291 58 16 291 65 16 stone
execute in minecraft:overworld run fill 291 66 16 291 67 16 dirt
execute in minecraft:overworld run setblock 291 68 16 coarse_dirt
execute in minecraft:overworld run fill 291 69 16 291 144 16 air
execute in minecraft:overworld run fill 291 58 17 291 65 17 stone
execute in minecraft:overworld run fill 291 66 17 291 67 17 dirt
execute in minecraft:overworld run setblock 291 68 17 coarse_dirt
execute in minecraft:overworld run fill 291 69 17 291 144 17 air
execute in minecraft:overworld run fill 291 58 18 291 65 18 stone
execute in minecraft:overworld run fill 291 66 18 291 67 18 dirt
execute in minecraft:overworld run setblock 291 68 18 coarse_dirt
execute in minecraft:overworld run fill 291 69 18 291 144 18 air
execute in minecraft:overworld run fill 291 58 19 291 65 19 stone
execute in minecraft:overworld run fill 291 66 19 291 67 19 dirt
execute in minecraft:overworld run setblock 291 68 19 grass_block
execute in minecraft:overworld run fill 291 69 19 291 144 19 air
execute in minecraft:overworld run fill 291 58 20 291 65 20 stone
execute in minecraft:overworld run fill 291 66 20 291 67 20 dirt
execute in minecraft:overworld run setblock 291 68 20 grass_block
execute in minecraft:overworld run fill 291 69 20 291 144 20 air
execute in minecraft:overworld run fill 291 58 21 291 65 21 stone
execute in minecraft:overworld run fill 291 66 21 291 67 21 dirt
execute in minecraft:overworld run setblock 291 68 21 coarse_dirt
execute in minecraft:overworld run fill 291 69 21 291 144 21 air
execute in minecraft:overworld run fill 291 58 22 291 65 22 stone
execute in minecraft:overworld run fill 291 66 22 291 67 22 dirt
execute in minecraft:overworld run setblock 291 68 22 grass_block
execute in minecraft:overworld run fill 291 69 22 291 144 22 air
execute in minecraft:overworld run fill 291 58 23 291 65 23 stone
execute in minecraft:overworld run fill 291 66 23 291 67 23 dirt
execute in minecraft:overworld run setblock 291 68 23 grass_block
execute in minecraft:overworld run fill 291 69 23 291 144 23 air
execute in minecraft:overworld run fill 291 58 24 291 65 24 stone
execute in minecraft:overworld run fill 291 66 24 291 67 24 dirt
execute in minecraft:overworld run setblock 291 68 24 coarse_dirt
execute in minecraft:overworld run fill 291 69 24 291 144 24 air
execute in minecraft:overworld run setblock 291 69 24 grass
execute in minecraft:overworld run fill 291 58 25 291 65 25 stone
execute in minecraft:overworld run fill 291 66 25 291 67 25 dirt
execute in minecraft:overworld run setblock 291 68 25 coarse_dirt
execute in minecraft:overworld run fill 291 69 25 291 144 25 air
execute in minecraft:overworld run fill 291 58 26 291 65 26 stone
execute in minecraft:overworld run fill 291 66 26 291 67 26 dirt
execute in minecraft:overworld run setblock 291 68 26 coarse_dirt
execute in minecraft:overworld run fill 291 69 26 291 144 26 air
execute in minecraft:overworld run fill 291 58 27 291 65 27 stone
execute in minecraft:overworld run fill 291 66 27 291 67 27 dirt
execute in minecraft:overworld run setblock 291 68 27 coarse_dirt
execute in minecraft:overworld run fill 291 69 27 291 144 27 air
execute in minecraft:overworld run fill 291 58 28 291 65 28 stone
execute in minecraft:overworld run fill 291 66 28 291 67 28 dirt
execute in minecraft:overworld run setblock 291 68 28 coarse_dirt
execute in minecraft:overworld run fill 291 69 28 291 144 28 air
execute in minecraft:overworld run fill 291 58 29 291 65 29 stone
execute in minecraft:overworld run fill 291 66 29 291 67 29 dirt
execute in minecraft:overworld run setblock 291 68 29 grass_block
execute in minecraft:overworld run fill 291 69 29 291 144 29 air
execute in minecraft:overworld run fill 291 58 30 291 65 30 stone
execute in minecraft:overworld run fill 291 66 30 291 67 30 dirt
execute in minecraft:overworld run setblock 291 68 30 coarse_dirt
execute in minecraft:overworld run fill 291 69 30 291 144 30 air
execute in minecraft:overworld run fill 291 58 31 291 64 31 stone
execute in minecraft:overworld run fill 291 65 31 291 66 31 dirt
execute in minecraft:overworld run setblock 291 67 31 coarse_dirt
execute in minecraft:overworld run fill 291 68 31 291 144 31 air
execute in minecraft:overworld run fill 291 58 32 291 64 32 stone
execute in minecraft:overworld run fill 291 65 32 291 66 32 dirt
execute in minecraft:overworld run setblock 291 67 32 coarse_dirt
execute in minecraft:overworld run fill 291 68 32 291 144 32 air
execute in minecraft:overworld run fill 291 58 33 291 64 33 stone
execute in minecraft:overworld run fill 291 65 33 291 66 33 dirt
execute in minecraft:overworld run setblock 291 67 33 coarse_dirt
execute in minecraft:overworld run fill 291 68 33 291 144 33 air
execute in minecraft:overworld run fill 291 58 34 291 63 34 stone
execute in minecraft:overworld run fill 291 64 34 291 65 34 dirt
execute in minecraft:overworld run setblock 291 66 34 grass_block
execute in minecraft:overworld run fill 291 67 34 291 144 34 air
execute in minecraft:overworld run fill 291 58 35 291 63 35 stone
execute in minecraft:overworld run fill 291 64 35 291 65 35 dirt
execute in minecraft:overworld run setblock 291 66 35 coarse_dirt
execute in minecraft:overworld run fill 291 67 35 291 144 35 air
execute in minecraft:overworld run fill 291 58 36 291 63 36 stone
execute in minecraft:overworld run fill 291 64 36 291 65 36 dirt
execute in minecraft:overworld run setblock 291 66 36 coarse_dirt
execute in minecraft:overworld run fill 291 67 36 291 144 36 air
execute in minecraft:overworld run fill 291 58 37 291 63 37 stone
execute in minecraft:overworld run fill 291 64 37 291 65 37 dirt
execute in minecraft:overworld run setblock 291 66 37 coarse_dirt
execute in minecraft:overworld run fill 291 67 37 291 144 37 air
execute in minecraft:overworld run setblock 291 67 37 grass
execute in minecraft:overworld run fill 291 58 38 291 63 38 stone
execute in minecraft:overworld run fill 291 64 38 291 65 38 dirt
execute in minecraft:overworld run setblock 291 66 38 coarse_dirt
execute in minecraft:overworld run fill 291 67 38 291 144 38 air
execute in minecraft:overworld run fill 291 58 39 291 63 39 stone
execute in minecraft:overworld run fill 291 64 39 291 65 39 dirt
execute in minecraft:overworld run setblock 291 66 39 coarse_dirt
execute in minecraft:overworld run fill 291 67 39 291 144 39 air
execute in minecraft:overworld run fill 291 58 40 291 63 40 stone
execute in minecraft:overworld run fill 291 64 40 291 65 40 dirt
execute in minecraft:overworld run setblock 291 66 40 coarse_dirt
execute in minecraft:overworld run fill 291 67 40 291 144 40 air
execute in minecraft:overworld run setblock 291 67 40 grass
execute in minecraft:overworld run fill 291 58 41 291 63 41 stone
execute in minecraft:overworld run fill 291 64 41 291 65 41 dirt
execute in minecraft:overworld run setblock 291 66 41 coarse_dirt
execute in minecraft:overworld run fill 291 67 41 291 144 41 air
execute in minecraft:overworld run fill 291 58 42 291 62 42 stone
execute in minecraft:overworld run fill 291 63 42 291 64 42 dirt
execute in minecraft:overworld run setblock 291 65 42 grass_block
execute in minecraft:overworld run fill 291 66 42 291 144 42 air
execute in minecraft:overworld run fill 291 58 43 291 62 43 stone
execute in minecraft:overworld run fill 291 63 43 291 64 43 dirt
execute in minecraft:overworld run setblock 291 65 43 coarse_dirt
execute in minecraft:overworld run fill 291 66 43 291 144 43 air
execute in minecraft:overworld run fill 291 58 44 291 62 44 stone
execute in minecraft:overworld run fill 291 63 44 291 64 44 dirt
execute in minecraft:overworld run setblock 291 65 44 coarse_dirt
execute in minecraft:overworld run fill 291 66 44 291 144 44 air
execute in minecraft:overworld run fill 291 58 45 291 62 45 stone
execute in minecraft:overworld run fill 291 63 45 291 64 45 dirt
execute in minecraft:overworld run setblock 291 65 45 grass_block
execute in minecraft:overworld run fill 291 66 45 291 144 45 air
execute in minecraft:overworld run fill 291 58 46 291 61 46 stone
execute in minecraft:overworld run fill 291 62 46 291 63 46 dirt
execute in minecraft:overworld run setblock 291 64 46 coarse_dirt
execute in minecraft:overworld run fill 291 65 46 291 144 46 air
execute in minecraft:overworld run fill 291 58 47 291 61 47 stone
execute in minecraft:overworld run fill 291 62 47 291 63 47 dirt
execute in minecraft:overworld run setblock 291 64 47 coarse_dirt
execute in minecraft:overworld run fill 291 65 47 291 144 47 air
execute in minecraft:overworld run fill 292 58 -48 292 61 -48 stone
execute in minecraft:overworld run fill 292 62 -48 292 63 -48 dirt
execute in minecraft:overworld run setblock 292 64 -48 coarse_dirt
execute in minecraft:overworld run fill 292 65 -48 292 144 -48 air
execute in minecraft:overworld run fill 292 58 -47 292 63 -47 stone
execute in minecraft:overworld run fill 292 64 -47 292 65 -47 dirt
execute in minecraft:overworld run setblock 292 66 -47 coarse_dirt
execute in minecraft:overworld run fill 292 67 -47 292 144 -47 air
execute in minecraft:overworld run fill 292 58 -46 292 65 -46 stone
execute in minecraft:overworld run fill 292 66 -46 292 67 -46 dirt
execute in minecraft:overworld run setblock 292 68 -46 grass_block
execute in minecraft:overworld run fill 292 69 -46 292 144 -46 air
execute in minecraft:overworld run fill 292 58 -45 292 67 -45 stone
execute in minecraft:overworld run fill 292 68 -45 292 69 -45 dirt
execute in minecraft:overworld run setblock 292 70 -45 coarse_dirt
execute in minecraft:overworld run fill 292 71 -45 292 144 -45 air
execute in minecraft:overworld run fill 292 58 -44 292 69 -44 stone
execute in minecraft:overworld run fill 292 70 -44 292 71 -44 dirt
execute in minecraft:overworld run setblock 292 72 -44 coarse_dirt
execute in minecraft:overworld run fill 292 73 -44 292 144 -44 air
execute in minecraft:overworld run fill 292 58 -43 292 70 -43 stone
execute in minecraft:overworld run fill 292 71 -43 292 72 -43 dirt
execute in minecraft:overworld run setblock 292 73 -43 grass_block
execute in minecraft:overworld run fill 292 74 -43 292 144 -43 air
execute in minecraft:overworld run fill 292 58 -42 292 72 -42 stone
execute in minecraft:overworld run fill 292 73 -42 292 74 -42 dirt
execute in minecraft:overworld run setblock 292 75 -42 grass_block
execute in minecraft:overworld run fill 292 76 -42 292 144 -42 air
execute in minecraft:overworld run fill 292 58 -41 292 74 -41 stone
execute in minecraft:overworld run fill 292 75 -41 292 76 -41 dirt
execute in minecraft:overworld run setblock 292 77 -41 coarse_dirt
execute in minecraft:overworld run fill 292 78 -41 292 144 -41 air
execute in minecraft:overworld run setblock 292 78 -41 grass
execute in minecraft:overworld run fill 292 58 -40 292 76 -40 stone
execute in minecraft:overworld run fill 292 77 -40 292 78 -40 dirt
execute in minecraft:overworld run setblock 292 79 -40 grass_block
execute in minecraft:overworld run fill 292 80 -40 292 144 -40 air
execute in minecraft:overworld run fill 292 58 -39 292 77 -39 stone
execute in minecraft:overworld run fill 292 78 -39 292 79 -39 dirt
execute in minecraft:overworld run setblock 292 80 -39 coarse_dirt
execute in minecraft:overworld run fill 292 81 -39 292 144 -39 air
execute in minecraft:overworld run fill 292 58 -38 292 79 -38 stone
execute in minecraft:overworld run fill 292 80 -38 292 81 -38 dirt
execute in minecraft:overworld run setblock 292 82 -38 coarse_dirt
execute in minecraft:overworld run fill 292 83 -38 292 144 -38 air
execute in minecraft:overworld run fill 292 58 -37 292 79 -37 stone
execute in minecraft:overworld run fill 292 80 -37 292 81 -37 dirt
execute in minecraft:overworld run setblock 292 82 -37 grass_block
execute in minecraft:overworld run fill 292 83 -37 292 144 -37 air
execute in minecraft:overworld run fill 292 58 -36 292 78 -36 stone
execute in minecraft:overworld run fill 292 79 -36 292 80 -36 dirt
execute in minecraft:overworld run setblock 292 81 -36 coarse_dirt
execute in minecraft:overworld run fill 292 82 -36 292 144 -36 air
execute in minecraft:overworld run fill 292 58 -35 292 78 -35 stone
execute in minecraft:overworld run fill 292 79 -35 292 80 -35 dirt
execute in minecraft:overworld run setblock 292 81 -35 grass_block
execute in minecraft:overworld run fill 292 82 -35 292 144 -35 air
execute in minecraft:overworld run fill 292 58 -34 292 78 -34 stone
execute in minecraft:overworld run fill 292 79 -34 292 80 -34 dirt
execute in minecraft:overworld run setblock 292 81 -34 coarse_dirt
execute in minecraft:overworld run fill 292 82 -34 292 144 -34 air
execute in minecraft:overworld run fill 292 58 -33 292 77 -33 stone
execute in minecraft:overworld run fill 292 78 -33 292 79 -33 dirt
execute in minecraft:overworld run setblock 292 80 -33 grass_block
execute in minecraft:overworld run fill 292 81 -33 292 144 -33 air
execute in minecraft:overworld run fill 292 58 -32 292 77 -32 stone
execute in minecraft:overworld run fill 292 78 -32 292 79 -32 dirt
execute in minecraft:overworld run setblock 292 80 -32 coarse_dirt
execute in minecraft:overworld run fill 292 81 -32 292 144 -32 air
execute in minecraft:overworld run setblock 292 81 -32 grass
execute in minecraft:overworld run fill 292 58 -31 292 76 -31 stone
execute in minecraft:overworld run fill 292 77 -31 292 78 -31 dirt
execute in minecraft:overworld run setblock 292 79 -31 grass_block
execute in minecraft:overworld run fill 292 80 -31 292 144 -31 air
execute in minecraft:overworld run fill 292 58 -30 292 76 -30 stone
execute in minecraft:overworld run fill 292 77 -30 292 78 -30 dirt
execute in minecraft:overworld run setblock 292 79 -30 grass_block
execute in minecraft:overworld run fill 292 80 -30 292 144 -30 air
execute in minecraft:overworld run fill 292 58 -29 292 75 -29 stone
execute in minecraft:overworld run fill 292 76 -29 292 77 -29 dirt
execute in minecraft:overworld run setblock 292 78 -29 coarse_dirt
execute in minecraft:overworld run fill 292 79 -29 292 144 -29 air
execute in minecraft:overworld run setblock 292 79 -29 grass
execute in minecraft:overworld run fill 292 58 -28 292 75 -28 stone
execute in minecraft:overworld run fill 292 76 -28 292 77 -28 dirt
execute in minecraft:overworld run setblock 292 78 -28 grass_block
execute in minecraft:overworld run fill 292 79 -28 292 144 -28 air
execute in minecraft:overworld run fill 292 58 -27 292 74 -27 stone
execute in minecraft:overworld run fill 292 75 -27 292 76 -27 dirt
execute in minecraft:overworld run setblock 292 77 -27 coarse_dirt
execute in minecraft:overworld run fill 292 78 -27 292 144 -27 air
execute in minecraft:overworld run fill 292 58 -26 292 74 -26 stone
execute in minecraft:overworld run fill 292 75 -26 292 76 -26 dirt
schedule function blade_gallery:random/burned/part_133 1t replace
