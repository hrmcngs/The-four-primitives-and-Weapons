execute in minecraft:overworld run setblock 212 67 15 grass_block
execute in minecraft:overworld run fill 212 68 15 212 144 15 air
execute in minecraft:overworld run fill 212 58 16 212 64 16 stone
execute in minecraft:overworld run fill 212 65 16 212 66 16 dirt
execute in minecraft:overworld run setblock 212 67 16 grass_block
execute in minecraft:overworld run fill 212 68 16 212 144 16 air
execute in minecraft:overworld run fill 212 58 17 212 64 17 stone
execute in minecraft:overworld run fill 212 65 17 212 66 17 dirt
execute in minecraft:overworld run setblock 212 67 17 coarse_dirt
execute in minecraft:overworld run fill 212 68 17 212 144 17 air
execute in minecraft:overworld run fill 212 58 18 212 64 18 stone
execute in minecraft:overworld run fill 212 65 18 212 66 18 dirt
execute in minecraft:overworld run setblock 212 67 18 grass_block
execute in minecraft:overworld run fill 212 68 18 212 144 18 air
execute in minecraft:overworld run fill 212 58 19 212 64 19 stone
execute in minecraft:overworld run fill 212 65 19 212 66 19 dirt
execute in minecraft:overworld run setblock 212 67 19 grass_block
execute in minecraft:overworld run fill 212 68 19 212 144 19 air
execute in minecraft:overworld run fill 212 58 20 212 64 20 stone
execute in minecraft:overworld run fill 212 65 20 212 66 20 dirt
execute in minecraft:overworld run setblock 212 67 20 coarse_dirt
execute in minecraft:overworld run fill 212 68 20 212 144 20 air
execute in minecraft:overworld run fill 212 58 21 212 64 21 stone
execute in minecraft:overworld run fill 212 65 21 212 66 21 dirt
execute in minecraft:overworld run setblock 212 67 21 coarse_dirt
execute in minecraft:overworld run fill 212 68 21 212 144 21 air
execute in minecraft:overworld run fill 212 58 22 212 64 22 stone
execute in minecraft:overworld run fill 212 65 22 212 66 22 dirt
execute in minecraft:overworld run setblock 212 67 22 grass_block
execute in minecraft:overworld run fill 212 68 22 212 144 22 air
execute in minecraft:overworld run fill 212 58 23 212 64 23 stone
execute in minecraft:overworld run fill 212 65 23 212 66 23 dirt
execute in minecraft:overworld run setblock 212 67 23 coarse_dirt
execute in minecraft:overworld run fill 212 68 23 212 144 23 air
execute in minecraft:overworld run fill 212 58 24 212 64 24 stone
execute in minecraft:overworld run fill 212 65 24 212 66 24 dirt
execute in minecraft:overworld run setblock 212 67 24 coarse_dirt
execute in minecraft:overworld run fill 212 68 24 212 144 24 air
execute in minecraft:overworld run fill 212 58 25 212 64 25 stone
execute in minecraft:overworld run fill 212 65 25 212 66 25 dirt
execute in minecraft:overworld run setblock 212 67 25 coarse_dirt
execute in minecraft:overworld run fill 212 68 25 212 144 25 air
execute in minecraft:overworld run fill 212 58 26 212 64 26 stone
execute in minecraft:overworld run fill 212 65 26 212 66 26 dirt
execute in minecraft:overworld run setblock 212 67 26 coarse_dirt
execute in minecraft:overworld run fill 212 68 26 212 144 26 air
execute in minecraft:overworld run fill 212 58 27 212 64 27 stone
execute in minecraft:overworld run fill 212 65 27 212 66 27 dirt
execute in minecraft:overworld run setblock 212 67 27 grass_block
execute in minecraft:overworld run fill 212 68 27 212 144 27 air
execute in minecraft:overworld run fill 212 58 28 212 64 28 stone
execute in minecraft:overworld run fill 212 65 28 212 66 28 dirt
execute in minecraft:overworld run setblock 212 67 28 coarse_dirt
execute in minecraft:overworld run fill 212 68 28 212 144 28 air
execute in minecraft:overworld run fill 212 58 29 212 64 29 stone
execute in minecraft:overworld run fill 212 65 29 212 66 29 dirt
execute in minecraft:overworld run setblock 212 67 29 coarse_dirt
execute in minecraft:overworld run fill 212 68 29 212 144 29 air
execute in minecraft:overworld run fill 212 58 30 212 64 30 stone
execute in minecraft:overworld run fill 212 65 30 212 66 30 dirt
execute in minecraft:overworld run setblock 212 67 30 coarse_dirt
execute in minecraft:overworld run fill 212 68 30 212 144 30 air
execute in minecraft:overworld run fill 212 58 31 212 64 31 stone
execute in minecraft:overworld run fill 212 65 31 212 66 31 dirt
execute in minecraft:overworld run setblock 212 67 31 coarse_dirt
execute in minecraft:overworld run fill 212 68 31 212 144 31 air
execute in minecraft:overworld run fill 212 58 32 212 64 32 stone
execute in minecraft:overworld run fill 212 65 32 212 66 32 dirt
execute in minecraft:overworld run setblock 212 67 32 coarse_dirt
execute in minecraft:overworld run fill 212 68 32 212 144 32 air
execute in minecraft:overworld run fill 212 58 33 212 64 33 stone
execute in minecraft:overworld run fill 212 65 33 212 66 33 dirt
execute in minecraft:overworld run setblock 212 67 33 grass_block
execute in minecraft:overworld run fill 212 68 33 212 144 33 air
execute in minecraft:overworld run fill 212 58 34 212 64 34 stone
execute in minecraft:overworld run fill 212 65 34 212 66 34 dirt
execute in minecraft:overworld run setblock 212 67 34 grass_block
execute in minecraft:overworld run fill 212 68 34 212 144 34 air
execute in minecraft:overworld run fill 212 58 35 212 64 35 stone
execute in minecraft:overworld run fill 212 65 35 212 66 35 dirt
execute in minecraft:overworld run setblock 212 67 35 coarse_dirt
execute in minecraft:overworld run fill 212 68 35 212 144 35 air
execute in minecraft:overworld run fill 212 58 36 212 64 36 stone
execute in minecraft:overworld run fill 212 65 36 212 66 36 dirt
execute in minecraft:overworld run setblock 212 67 36 grass_block
execute in minecraft:overworld run fill 212 68 36 212 144 36 air
execute in minecraft:overworld run fill 212 58 37 212 64 37 stone
execute in minecraft:overworld run fill 212 65 37 212 66 37 dirt
execute in minecraft:overworld run setblock 212 67 37 coarse_dirt
execute in minecraft:overworld run fill 212 68 37 212 144 37 air
execute in minecraft:overworld run fill 212 58 38 212 64 38 stone
execute in minecraft:overworld run fill 212 65 38 212 66 38 dirt
execute in minecraft:overworld run setblock 212 67 38 coarse_dirt
execute in minecraft:overworld run fill 212 68 38 212 144 38 air
execute in minecraft:overworld run fill 212 58 39 212 64 39 stone
execute in minecraft:overworld run fill 212 65 39 212 66 39 dirt
execute in minecraft:overworld run setblock 212 67 39 coarse_dirt
execute in minecraft:overworld run fill 212 68 39 212 144 39 air
execute in minecraft:overworld run fill 212 58 40 212 63 40 stone
execute in minecraft:overworld run fill 212 64 40 212 65 40 dirt
execute in minecraft:overworld run setblock 212 66 40 coarse_dirt
execute in minecraft:overworld run fill 212 67 40 212 144 40 air
execute in minecraft:overworld run fill 212 58 41 212 63 41 stone
execute in minecraft:overworld run fill 212 64 41 212 65 41 dirt
execute in minecraft:overworld run setblock 212 66 41 coarse_dirt
execute in minecraft:overworld run fill 212 67 41 212 144 41 air
execute in minecraft:overworld run fill 212 58 42 212 63 42 stone
execute in minecraft:overworld run fill 212 64 42 212 65 42 dirt
execute in minecraft:overworld run setblock 212 66 42 coarse_dirt
execute in minecraft:overworld run fill 212 67 42 212 144 42 air
execute in minecraft:overworld run fill 212 58 43 212 63 43 stone
execute in minecraft:overworld run fill 212 64 43 212 65 43 dirt
execute in minecraft:overworld run setblock 212 66 43 grass_block
execute in minecraft:overworld run fill 212 67 43 212 144 43 air
execute in minecraft:overworld run fill 212 58 44 212 63 44 stone
execute in minecraft:overworld run fill 212 64 44 212 65 44 dirt
execute in minecraft:overworld run setblock 212 66 44 grass_block
execute in minecraft:overworld run fill 212 67 44 212 144 44 air
execute in minecraft:overworld run fill 212 58 45 212 62 45 stone
execute in minecraft:overworld run fill 212 63 45 212 64 45 dirt
execute in minecraft:overworld run setblock 212 65 45 coarse_dirt
execute in minecraft:overworld run fill 212 66 45 212 144 45 air
execute in minecraft:overworld run fill 212 58 46 212 62 46 stone
execute in minecraft:overworld run fill 212 63 46 212 64 46 dirt
execute in minecraft:overworld run setblock 212 65 46 coarse_dirt
execute in minecraft:overworld run fill 212 66 46 212 144 46 air
execute in minecraft:overworld run fill 212 58 47 212 61 47 stone
execute in minecraft:overworld run fill 212 62 47 212 63 47 dirt
execute in minecraft:overworld run setblock 212 64 47 coarse_dirt
execute in minecraft:overworld run fill 212 65 47 212 144 47 air
execute in minecraft:overworld run fill 213 58 -48 213 61 -48 stone
execute in minecraft:overworld run fill 213 62 -48 213 63 -48 dirt
execute in minecraft:overworld run setblock 213 64 -48 coarse_dirt
execute in minecraft:overworld run fill 213 65 -48 213 144 -48 air
execute in minecraft:overworld run fill 213 58 -47 213 63 -47 stone
execute in minecraft:overworld run fill 213 64 -47 213 65 -47 dirt
execute in minecraft:overworld run setblock 213 66 -47 coarse_dirt
execute in minecraft:overworld run fill 213 67 -47 213 144 -47 air
execute in minecraft:overworld run fill 213 58 -46 213 64 -46 stone
execute in minecraft:overworld run fill 213 65 -46 213 66 -46 dirt
execute in minecraft:overworld run setblock 213 67 -46 coarse_dirt
execute in minecraft:overworld run fill 213 68 -46 213 144 -46 air
execute in minecraft:overworld run fill 213 58 -45 213 66 -45 stone
execute in minecraft:overworld run fill 213 67 -45 213 68 -45 dirt
execute in minecraft:overworld run setblock 213 69 -45 grass_block
execute in minecraft:overworld run fill 213 70 -45 213 144 -45 air
execute in minecraft:overworld run fill 213 58 -44 213 67 -44 stone
execute in minecraft:overworld run fill 213 68 -44 213 69 -44 dirt
execute in minecraft:overworld run setblock 213 70 -44 coarse_dirt
execute in minecraft:overworld run fill 213 71 -44 213 144 -44 air
execute in minecraft:overworld run fill 213 58 -43 213 69 -43 stone
execute in minecraft:overworld run fill 213 70 -43 213 71 -43 dirt
execute in minecraft:overworld run setblock 213 72 -43 coarse_dirt
execute in minecraft:overworld run fill 213 73 -43 213 144 -43 air
execute in minecraft:overworld run fill 213 58 -42 213 68 -42 stone
execute in minecraft:overworld run fill 213 69 -42 213 70 -42 dirt
execute in minecraft:overworld run setblock 213 71 -42 coarse_dirt
execute in minecraft:overworld run fill 213 72 -42 213 144 -42 air
execute in minecraft:overworld run fill 213 58 -41 213 68 -41 stone
execute in minecraft:overworld run fill 213 69 -41 213 70 -41 dirt
execute in minecraft:overworld run setblock 213 71 -41 coarse_dirt
execute in minecraft:overworld run fill 213 72 -41 213 144 -41 air
execute in minecraft:overworld run fill 213 58 -40 213 67 -40 stone
execute in minecraft:overworld run fill 213 68 -40 213 69 -40 dirt
execute in minecraft:overworld run setblock 213 70 -40 grass_block
execute in minecraft:overworld run fill 213 71 -40 213 144 -40 air
execute in minecraft:overworld run fill 213 58 -39 213 67 -39 stone
execute in minecraft:overworld run fill 213 68 -39 213 69 -39 dirt
execute in minecraft:overworld run setblock 213 70 -39 coarse_dirt
execute in minecraft:overworld run fill 213 71 -39 213 144 -39 air
execute in minecraft:overworld run fill 213 58 -38 213 67 -38 stone
execute in minecraft:overworld run fill 213 68 -38 213 69 -38 dirt
execute in minecraft:overworld run setblock 213 70 -38 grass_block
execute in minecraft:overworld run fill 213 71 -38 213 144 -38 air
execute in minecraft:overworld run fill 213 58 -37 213 66 -37 stone
execute in minecraft:overworld run fill 213 67 -37 213 68 -37 dirt
execute in minecraft:overworld run setblock 213 69 -37 grass_block
execute in minecraft:overworld run fill 213 70 -37 213 144 -37 air
execute in minecraft:overworld run fill 213 58 -36 213 66 -36 stone
execute in minecraft:overworld run fill 213 67 -36 213 68 -36 dirt
execute in minecraft:overworld run setblock 213 69 -36 coarse_dirt
execute in minecraft:overworld run fill 213 70 -36 213 144 -36 air
execute in minecraft:overworld run fill 213 58 -35 213 66 -35 stone
execute in minecraft:overworld run fill 213 67 -35 213 68 -35 dirt
execute in minecraft:overworld run setblock 213 69 -35 coarse_dirt
execute in minecraft:overworld run fill 213 70 -35 213 144 -35 air
execute in minecraft:overworld run fill 213 58 -34 213 65 -34 stone
execute in minecraft:overworld run fill 213 66 -34 213 67 -34 dirt
execute in minecraft:overworld run setblock 213 68 -34 grass_block
execute in minecraft:overworld run fill 213 69 -34 213 144 -34 air
execute in minecraft:overworld run fill 213 58 -33 213 65 -33 stone
execute in minecraft:overworld run fill 213 66 -33 213 67 -33 dirt
execute in minecraft:overworld run setblock 213 68 -33 coarse_dirt
execute in minecraft:overworld run fill 213 69 -33 213 144 -33 air
execute in minecraft:overworld run fill 213 58 -32 213 65 -32 stone
execute in minecraft:overworld run fill 213 66 -32 213 67 -32 dirt
execute in minecraft:overworld run setblock 213 68 -32 coarse_dirt
execute in minecraft:overworld run fill 213 69 -32 213 144 -32 air
execute in minecraft:overworld run fill 213 58 -31 213 64 -31 stone
execute in minecraft:overworld run fill 213 65 -31 213 66 -31 dirt
execute in minecraft:overworld run setblock 213 67 -31 grass_block
execute in minecraft:overworld run fill 213 68 -31 213 144 -31 air
execute in minecraft:overworld run fill 213 58 -30 213 64 -30 stone
execute in minecraft:overworld run fill 213 65 -30 213 66 -30 dirt
execute in minecraft:overworld run setblock 213 67 -30 coarse_dirt
execute in minecraft:overworld run fill 213 68 -30 213 144 -30 air
execute in minecraft:overworld run fill 213 58 -29 213 64 -29 stone
execute in minecraft:overworld run fill 213 65 -29 213 66 -29 dirt
execute in minecraft:overworld run setblock 213 67 -29 coarse_dirt
execute in minecraft:overworld run fill 213 68 -29 213 144 -29 air
execute in minecraft:overworld run fill 213 58 -28 213 64 -28 stone
execute in minecraft:overworld run fill 213 65 -28 213 66 -28 dirt
execute in minecraft:overworld run setblock 213 67 -28 coarse_dirt
execute in minecraft:overworld run fill 213 68 -28 213 144 -28 air
execute in minecraft:overworld run fill 213 58 -27 213 64 -27 stone
execute in minecraft:overworld run fill 213 65 -27 213 66 -27 dirt
execute in minecraft:overworld run setblock 213 67 -27 coarse_dirt
execute in minecraft:overworld run fill 213 68 -27 213 144 -27 air
execute in minecraft:overworld run fill 213 58 -26 213 64 -26 stone
execute in minecraft:overworld run fill 213 65 -26 213 66 -26 dirt
execute in minecraft:overworld run setblock 213 67 -26 coarse_dirt
execute in minecraft:overworld run fill 213 68 -26 213 144 -26 air
execute in minecraft:overworld run fill 213 58 -25 213 63 -25 stone
execute in minecraft:overworld run fill 213 64 -25 213 65 -25 dirt
execute in minecraft:overworld run setblock 213 66 -25 grass_block
execute in minecraft:overworld run fill 213 67 -25 213 144 -25 air
execute in minecraft:overworld run fill 213 58 -24 213 63 -24 stone
execute in minecraft:overworld run fill 213 64 -24 213 65 -24 dirt
execute in minecraft:overworld run setblock 213 66 -24 coarse_dirt
execute in minecraft:overworld run fill 213 67 -24 213 144 -24 air
execute in minecraft:overworld run fill 213 58 -23 213 64 -23 stone
execute in minecraft:overworld run fill 213 65 -23 213 66 -23 dirt
execute in minecraft:overworld run setblock 213 67 -23 coarse_dirt
execute in minecraft:overworld run fill 213 68 -23 213 144 -23 air
execute in minecraft:overworld run fill 213 58 -22 213 64 -22 stone
execute in minecraft:overworld run fill 213 65 -22 213 66 -22 dirt
execute in minecraft:overworld run setblock 213 67 -22 coarse_dirt
execute in minecraft:overworld run fill 213 68 -22 213 144 -22 air
execute in minecraft:overworld run fill 213 58 -21 213 64 -21 stone
execute in minecraft:overworld run fill 213 65 -21 213 66 -21 dirt
execute in minecraft:overworld run setblock 213 67 -21 coarse_dirt
execute in minecraft:overworld run fill 213 68 -21 213 144 -21 air
execute in minecraft:overworld run fill 213 58 -20 213 64 -20 stone
execute in minecraft:overworld run fill 213 65 -20 213 66 -20 dirt
execute in minecraft:overworld run setblock 213 67 -20 grass_block
execute in minecraft:overworld run fill 213 68 -20 213 144 -20 air
execute in minecraft:overworld run fill 213 58 -19 213 64 -19 stone
execute in minecraft:overworld run fill 213 65 -19 213 66 -19 dirt
execute in minecraft:overworld run setblock 213 67 -19 coarse_dirt
execute in minecraft:overworld run fill 213 68 -19 213 144 -19 air
execute in minecraft:overworld run fill 213 58 -18 213 64 -18 stone
execute in minecraft:overworld run fill 213 65 -18 213 66 -18 dirt
execute in minecraft:overworld run setblock 213 67 -18 coarse_dirt
execute in minecraft:overworld run fill 213 68 -18 213 144 -18 air
execute in minecraft:overworld run fill 213 58 -17 213 64 -17 stone
execute in minecraft:overworld run fill 213 65 -17 213 66 -17 dirt
schedule function blade_gallery:random/burned/part_8 1t replace
