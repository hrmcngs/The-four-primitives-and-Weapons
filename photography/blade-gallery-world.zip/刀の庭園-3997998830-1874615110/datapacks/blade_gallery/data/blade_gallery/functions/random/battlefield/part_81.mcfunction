execute in minecraft:overworld run setblock 388 59 -7 gravel
execute in minecraft:overworld run fill 388 60 -7 388 144 -7 air
execute in minecraft:overworld run fill 388 60 -7 388 64 -7 water
execute in minecraft:overworld run fill 388 58 -6 388 56 -6 stone
execute in minecraft:overworld run fill 388 57 -6 388 58 -6 dirt
execute in minecraft:overworld run setblock 388 59 -6 gravel
execute in minecraft:overworld run fill 388 60 -6 388 144 -6 air
execute in minecraft:overworld run fill 388 60 -6 388 64 -6 water
execute in minecraft:overworld run fill 388 58 -5 388 56 -5 stone
execute in minecraft:overworld run fill 388 57 -5 388 58 -5 dirt
execute in minecraft:overworld run setblock 388 59 -5 gravel
execute in minecraft:overworld run fill 388 60 -5 388 144 -5 air
execute in minecraft:overworld run fill 388 60 -5 388 64 -5 water
execute in minecraft:overworld run fill 388 58 -4 388 57 -4 stone
execute in minecraft:overworld run fill 388 58 -4 388 59 -4 dirt
execute in minecraft:overworld run setblock 388 60 -4 gravel
execute in minecraft:overworld run fill 388 61 -4 388 144 -4 air
execute in minecraft:overworld run fill 388 61 -4 388 64 -4 water
execute in minecraft:overworld run fill 388 58 -3 388 57 -3 stone
execute in minecraft:overworld run fill 388 58 -3 388 59 -3 dirt
execute in minecraft:overworld run setblock 388 60 -3 gravel
execute in minecraft:overworld run fill 388 61 -3 388 144 -3 air
execute in minecraft:overworld run fill 388 61 -3 388 64 -3 water
execute in minecraft:overworld run fill 388 58 -2 388 57 -2 stone
execute in minecraft:overworld run fill 388 58 -2 388 59 -2 dirt
execute in minecraft:overworld run setblock 388 60 -2 gravel
execute in minecraft:overworld run fill 388 61 -2 388 144 -2 air
execute in minecraft:overworld run fill 388 61 -2 388 64 -2 water
execute in minecraft:overworld run fill 388 58 -1 388 58 -1 stone
execute in minecraft:overworld run fill 388 59 -1 388 60 -1 dirt
execute in minecraft:overworld run setblock 388 61 -1 gravel
execute in minecraft:overworld run fill 388 62 -1 388 144 -1 air
execute in minecraft:overworld run fill 388 62 -1 388 64 -1 water
execute in minecraft:overworld run fill 388 58 0 388 58 0 stone
execute in minecraft:overworld run fill 388 59 0 388 60 0 dirt
execute in minecraft:overworld run setblock 388 61 0 gravel
execute in minecraft:overworld run fill 388 62 0 388 144 0 air
execute in minecraft:overworld run fill 388 62 0 388 64 0 water
execute in minecraft:overworld run fill 388 58 1 388 58 1 stone
execute in minecraft:overworld run fill 388 59 1 388 60 1 dirt
execute in minecraft:overworld run setblock 388 61 1 gravel
execute in minecraft:overworld run fill 388 62 1 388 144 1 air
execute in minecraft:overworld run fill 388 62 1 388 64 1 water
execute in minecraft:overworld run fill 388 58 2 388 58 2 stone
execute in minecraft:overworld run fill 388 59 2 388 60 2 dirt
execute in minecraft:overworld run setblock 388 61 2 gravel
execute in minecraft:overworld run fill 388 62 2 388 144 2 air
execute in minecraft:overworld run fill 388 62 2 388 64 2 water
execute in minecraft:overworld run fill 388 58 3 388 58 3 stone
execute in minecraft:overworld run fill 388 59 3 388 60 3 dirt
execute in minecraft:overworld run setblock 388 61 3 gravel
execute in minecraft:overworld run fill 388 62 3 388 144 3 air
execute in minecraft:overworld run fill 388 62 3 388 64 3 water
execute in minecraft:overworld run fill 388 58 4 388 59 4 stone
execute in minecraft:overworld run fill 388 60 4 388 61 4 dirt
execute in minecraft:overworld run setblock 388 62 4 gravel
execute in minecraft:overworld run fill 388 63 4 388 144 4 air
execute in minecraft:overworld run fill 388 63 4 388 64 4 water
execute in minecraft:overworld run fill 388 58 5 388 59 5 stone
execute in minecraft:overworld run fill 388 60 5 388 61 5 dirt
execute in minecraft:overworld run setblock 388 62 5 gravel
execute in minecraft:overworld run fill 388 63 5 388 144 5 air
execute in minecraft:overworld run fill 388 63 5 388 64 5 water
execute in minecraft:overworld run fill 388 58 6 388 59 6 stone
execute in minecraft:overworld run fill 388 60 6 388 61 6 dirt
execute in minecraft:overworld run setblock 388 62 6 gravel
execute in minecraft:overworld run fill 388 63 6 388 144 6 air
execute in minecraft:overworld run fill 388 63 6 388 64 6 water
execute in minecraft:overworld run fill 388 58 7 388 59 7 stone
execute in minecraft:overworld run fill 388 60 7 388 61 7 dirt
execute in minecraft:overworld run setblock 388 62 7 gravel
execute in minecraft:overworld run fill 388 63 7 388 144 7 air
execute in minecraft:overworld run fill 388 63 7 388 64 7 water
execute in minecraft:overworld run fill 388 58 8 388 59 8 stone
execute in minecraft:overworld run fill 388 60 8 388 61 8 dirt
execute in minecraft:overworld run setblock 388 62 8 gravel
execute in minecraft:overworld run fill 388 63 8 388 144 8 air
execute in minecraft:overworld run fill 388 63 8 388 64 8 water
execute in minecraft:overworld run fill 388 58 9 388 59 9 stone
execute in minecraft:overworld run fill 388 60 9 388 61 9 dirt
execute in minecraft:overworld run setblock 388 62 9 gravel
execute in minecraft:overworld run fill 388 63 9 388 144 9 air
execute in minecraft:overworld run fill 388 63 9 388 64 9 water
execute in minecraft:overworld run fill 388 58 10 388 59 10 stone
execute in minecraft:overworld run fill 388 60 10 388 61 10 dirt
execute in minecraft:overworld run setblock 388 62 10 gravel
execute in minecraft:overworld run fill 388 63 10 388 144 10 air
execute in minecraft:overworld run fill 388 63 10 388 64 10 water
execute in minecraft:overworld run fill 388 58 11 388 60 11 stone
execute in minecraft:overworld run fill 388 61 11 388 62 11 dirt
execute in minecraft:overworld run setblock 388 63 11 gravel
execute in minecraft:overworld run fill 388 64 11 388 144 11 air
execute in minecraft:overworld run fill 388 64 11 388 64 11 water
execute in minecraft:overworld run fill 388 58 12 388 60 12 stone
execute in minecraft:overworld run fill 388 61 12 388 62 12 dirt
execute in minecraft:overworld run setblock 388 63 12 gravel
execute in minecraft:overworld run fill 388 64 12 388 144 12 air
execute in minecraft:overworld run fill 388 64 12 388 64 12 water
execute in minecraft:overworld run fill 388 58 13 388 60 13 stone
execute in minecraft:overworld run fill 388 61 13 388 62 13 dirt
execute in minecraft:overworld run setblock 388 63 13 gravel
execute in minecraft:overworld run fill 388 64 13 388 144 13 air
execute in minecraft:overworld run fill 388 64 13 388 64 13 water
execute in minecraft:overworld run fill 388 58 14 388 60 14 stone
execute in minecraft:overworld run fill 388 61 14 388 62 14 dirt
execute in minecraft:overworld run setblock 388 63 14 gravel
execute in minecraft:overworld run fill 388 64 14 388 144 14 air
execute in minecraft:overworld run fill 388 64 14 388 64 14 water
execute in minecraft:overworld run fill 388 58 15 388 60 15 stone
execute in minecraft:overworld run fill 388 61 15 388 62 15 dirt
execute in minecraft:overworld run setblock 388 63 15 gravel
execute in minecraft:overworld run fill 388 64 15 388 144 15 air
execute in minecraft:overworld run fill 388 64 15 388 64 15 water
execute in minecraft:overworld run fill 388 58 16 388 61 16 stone
execute in minecraft:overworld run fill 388 62 16 388 63 16 dirt
execute in minecraft:overworld run setblock 388 64 16 grass_block
execute in minecraft:overworld run fill 388 65 16 388 144 16 air
execute in minecraft:overworld run fill 388 58 17 388 61 17 stone
execute in minecraft:overworld run fill 388 62 17 388 63 17 dirt
execute in minecraft:overworld run setblock 388 64 17 coarse_dirt
execute in minecraft:overworld run fill 388 65 17 388 144 17 air
execute in minecraft:overworld run fill 388 58 18 388 61 18 stone
execute in minecraft:overworld run fill 388 62 18 388 63 18 dirt
execute in minecraft:overworld run setblock 388 64 18 coarse_dirt
execute in minecraft:overworld run fill 388 65 18 388 144 18 air
execute in minecraft:overworld run fill 388 58 19 388 61 19 stone
execute in minecraft:overworld run fill 388 62 19 388 63 19 dirt
execute in minecraft:overworld run setblock 388 64 19 grass_block
execute in minecraft:overworld run fill 388 65 19 388 144 19 air
execute in minecraft:overworld run fill 388 58 20 388 61 20 stone
execute in minecraft:overworld run fill 388 62 20 388 63 20 dirt
execute in minecraft:overworld run setblock 388 64 20 coarse_dirt
execute in minecraft:overworld run fill 388 65 20 388 144 20 air
execute in minecraft:overworld run fill 388 58 21 388 61 21 stone
execute in minecraft:overworld run fill 388 62 21 388 63 21 dirt
execute in minecraft:overworld run setblock 388 64 21 grass_block
execute in minecraft:overworld run fill 388 65 21 388 144 21 air
execute in minecraft:overworld run fill 388 58 22 388 61 22 stone
execute in minecraft:overworld run fill 388 62 22 388 63 22 dirt
execute in minecraft:overworld run setblock 388 64 22 coarse_dirt
execute in minecraft:overworld run fill 388 65 22 388 144 22 air
execute in minecraft:overworld run fill 388 58 23 388 61 23 stone
execute in minecraft:overworld run fill 388 62 23 388 63 23 dirt
execute in minecraft:overworld run setblock 388 64 23 coarse_dirt
execute in minecraft:overworld run fill 388 65 23 388 144 23 air
execute in minecraft:overworld run fill 388 58 24 388 61 24 stone
execute in minecraft:overworld run fill 388 62 24 388 63 24 dirt
execute in minecraft:overworld run setblock 388 64 24 grass_block
execute in minecraft:overworld run fill 388 65 24 388 144 24 air
execute in minecraft:overworld run fill 388 58 25 388 60 25 stone
execute in minecraft:overworld run fill 388 61 25 388 62 25 dirt
execute in minecraft:overworld run setblock 388 63 25 gravel
execute in minecraft:overworld run fill 388 64 25 388 144 25 air
execute in minecraft:overworld run fill 388 64 25 388 64 25 water
execute in minecraft:overworld run fill 388 58 26 388 60 26 stone
execute in minecraft:overworld run fill 388 61 26 388 62 26 dirt
execute in minecraft:overworld run setblock 388 63 26 gravel
execute in minecraft:overworld run fill 388 64 26 388 144 26 air
execute in minecraft:overworld run fill 388 64 26 388 64 26 water
execute in minecraft:overworld run fill 388 58 27 388 60 27 stone
execute in minecraft:overworld run fill 388 61 27 388 62 27 dirt
execute in minecraft:overworld run setblock 388 63 27 gravel
execute in minecraft:overworld run fill 388 64 27 388 144 27 air
execute in minecraft:overworld run fill 388 64 27 388 64 27 water
execute in minecraft:overworld run fill 388 58 28 388 60 28 stone
execute in minecraft:overworld run fill 388 61 28 388 62 28 dirt
execute in minecraft:overworld run setblock 388 63 28 gravel
execute in minecraft:overworld run fill 388 64 28 388 144 28 air
execute in minecraft:overworld run fill 388 64 28 388 64 28 water
execute in minecraft:overworld run fill 388 58 29 388 59 29 stone
execute in minecraft:overworld run fill 388 60 29 388 61 29 dirt
execute in minecraft:overworld run setblock 388 62 29 gravel
execute in minecraft:overworld run fill 388 63 29 388 144 29 air
execute in minecraft:overworld run fill 388 63 29 388 64 29 water
execute in minecraft:overworld run fill 388 58 30 388 59 30 stone
execute in minecraft:overworld run fill 388 60 30 388 61 30 dirt
execute in minecraft:overworld run setblock 388 62 30 gravel
execute in minecraft:overworld run fill 388 63 30 388 144 30 air
execute in minecraft:overworld run fill 388 63 30 388 64 30 water
execute in minecraft:overworld run fill 388 58 31 388 59 31 stone
execute in minecraft:overworld run fill 388 60 31 388 61 31 dirt
execute in minecraft:overworld run setblock 388 62 31 gravel
execute in minecraft:overworld run fill 388 63 31 388 144 31 air
execute in minecraft:overworld run fill 388 63 31 388 64 31 water
execute in minecraft:overworld run fill 388 58 32 388 59 32 stone
execute in minecraft:overworld run fill 388 60 32 388 61 32 dirt
execute in minecraft:overworld run setblock 388 62 32 gravel
execute in minecraft:overworld run fill 388 63 32 388 144 32 air
execute in minecraft:overworld run fill 388 63 32 388 64 32 water
execute in minecraft:overworld run fill 388 58 33 388 59 33 stone
execute in minecraft:overworld run fill 388 60 33 388 61 33 dirt
execute in minecraft:overworld run setblock 388 62 33 gravel
execute in minecraft:overworld run fill 388 63 33 388 144 33 air
execute in minecraft:overworld run fill 388 63 33 388 64 33 water
execute in minecraft:overworld run fill 388 58 34 388 59 34 stone
execute in minecraft:overworld run fill 388 60 34 388 61 34 dirt
execute in minecraft:overworld run setblock 388 62 34 gravel
execute in minecraft:overworld run fill 388 63 34 388 144 34 air
execute in minecraft:overworld run fill 388 63 34 388 64 34 water
execute in minecraft:overworld run fill 388 58 35 388 59 35 stone
execute in minecraft:overworld run fill 388 60 35 388 61 35 dirt
execute in minecraft:overworld run setblock 388 62 35 gravel
execute in minecraft:overworld run fill 388 63 35 388 144 35 air
execute in minecraft:overworld run fill 388 63 35 388 64 35 water
execute in minecraft:overworld run fill 388 58 36 388 59 36 stone
execute in minecraft:overworld run fill 388 60 36 388 61 36 dirt
execute in minecraft:overworld run setblock 388 62 36 gravel
execute in minecraft:overworld run fill 388 63 36 388 144 36 air
execute in minecraft:overworld run fill 388 63 36 388 64 36 water
execute in minecraft:overworld run fill 388 58 37 388 59 37 stone
execute in minecraft:overworld run fill 388 60 37 388 61 37 dirt
execute in minecraft:overworld run setblock 388 62 37 gravel
execute in minecraft:overworld run fill 388 63 37 388 144 37 air
execute in minecraft:overworld run fill 388 63 37 388 64 37 water
execute in minecraft:overworld run fill 388 58 38 388 59 38 stone
execute in minecraft:overworld run fill 388 60 38 388 61 38 dirt
execute in minecraft:overworld run setblock 388 62 38 gravel
execute in minecraft:overworld run fill 388 63 38 388 144 38 air
execute in minecraft:overworld run fill 388 63 38 388 64 38 water
execute in minecraft:overworld run fill 388 58 39 388 59 39 stone
execute in minecraft:overworld run fill 388 60 39 388 61 39 dirt
execute in minecraft:overworld run setblock 388 62 39 gravel
execute in minecraft:overworld run fill 388 63 39 388 144 39 air
execute in minecraft:overworld run fill 388 63 39 388 64 39 water
execute in minecraft:overworld run fill 388 58 40 388 59 40 stone
execute in minecraft:overworld run fill 388 60 40 388 61 40 dirt
execute in minecraft:overworld run setblock 388 62 40 gravel
execute in minecraft:overworld run fill 388 63 40 388 144 40 air
execute in minecraft:overworld run fill 388 63 40 388 64 40 water
execute in minecraft:overworld run fill 388 58 41 388 60 41 stone
execute in minecraft:overworld run fill 388 61 41 388 62 41 dirt
execute in minecraft:overworld run setblock 388 63 41 gravel
execute in minecraft:overworld run fill 388 64 41 388 144 41 air
execute in minecraft:overworld run fill 388 64 41 388 64 41 water
execute in minecraft:overworld run fill 388 58 42 388 60 42 stone
execute in minecraft:overworld run fill 388 61 42 388 62 42 dirt
execute in minecraft:overworld run setblock 388 63 42 gravel
execute in minecraft:overworld run fill 388 64 42 388 144 42 air
execute in minecraft:overworld run fill 388 64 42 388 64 42 water
execute in minecraft:overworld run fill 388 58 43 388 60 43 stone
execute in minecraft:overworld run fill 388 61 43 388 62 43 dirt
execute in minecraft:overworld run setblock 388 63 43 gravel
execute in minecraft:overworld run fill 388 64 43 388 144 43 air
execute in minecraft:overworld run fill 388 64 43 388 64 43 water
execute in minecraft:overworld run fill 388 58 44 388 61 44 stone
execute in minecraft:overworld run fill 388 62 44 388 63 44 dirt
execute in minecraft:overworld run setblock 388 64 44 coarse_dirt
execute in minecraft:overworld run fill 388 65 44 388 144 44 air
execute in minecraft:overworld run fill 388 58 45 388 61 45 stone
execute in minecraft:overworld run fill 388 62 45 388 63 45 dirt
execute in minecraft:overworld run setblock 388 64 45 grass_block
execute in minecraft:overworld run fill 388 65 45 388 144 45 air
execute in minecraft:overworld run fill 388 58 46 388 61 46 stone
execute in minecraft:overworld run fill 388 62 46 388 63 46 dirt
execute in minecraft:overworld run setblock 388 64 46 coarse_dirt
execute in minecraft:overworld run fill 388 65 46 388 144 46 air
schedule function blade_gallery:random/battlefield/part_82 1t replace
