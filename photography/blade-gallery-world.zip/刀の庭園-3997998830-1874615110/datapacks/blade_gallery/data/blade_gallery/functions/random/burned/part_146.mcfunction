execute in minecraft:overworld run fill 300 64 25 300 65 25 dirt
execute in minecraft:overworld run setblock 300 66 25 grass_block
execute in minecraft:overworld run fill 300 67 25 300 144 25 air
execute in minecraft:overworld run fill 300 58 26 300 63 26 stone
execute in minecraft:overworld run fill 300 64 26 300 65 26 dirt
execute in minecraft:overworld run setblock 300 66 26 grass_block
execute in minecraft:overworld run fill 300 67 26 300 144 26 air
execute in minecraft:overworld run fill 300 58 27 300 63 27 stone
execute in minecraft:overworld run fill 300 64 27 300 65 27 dirt
execute in minecraft:overworld run setblock 300 66 27 grass_block
execute in minecraft:overworld run fill 300 67 27 300 144 27 air
execute in minecraft:overworld run fill 300 58 28 300 63 28 stone
execute in minecraft:overworld run fill 300 64 28 300 65 28 dirt
execute in minecraft:overworld run setblock 300 66 28 grass_block
execute in minecraft:overworld run fill 300 67 28 300 144 28 air
execute in minecraft:overworld run fill 300 58 29 300 63 29 stone
execute in minecraft:overworld run fill 300 64 29 300 65 29 dirt
execute in minecraft:overworld run setblock 300 66 29 coarse_dirt
execute in minecraft:overworld run fill 300 67 29 300 144 29 air
execute in minecraft:overworld run fill 300 58 30 300 63 30 stone
execute in minecraft:overworld run fill 300 64 30 300 65 30 dirt
execute in minecraft:overworld run setblock 300 66 30 coarse_dirt
execute in minecraft:overworld run fill 300 67 30 300 144 30 air
execute in minecraft:overworld run fill 300 58 31 300 63 31 stone
execute in minecraft:overworld run fill 300 64 31 300 65 31 dirt
execute in minecraft:overworld run setblock 300 66 31 grass_block
execute in minecraft:overworld run fill 300 67 31 300 144 31 air
execute in minecraft:overworld run fill 300 58 32 300 63 32 stone
execute in minecraft:overworld run fill 300 64 32 300 65 32 dirt
execute in minecraft:overworld run setblock 300 66 32 coarse_dirt
execute in minecraft:overworld run fill 300 67 32 300 144 32 air
execute in minecraft:overworld run fill 300 58 33 300 63 33 stone
execute in minecraft:overworld run fill 300 64 33 300 65 33 dirt
execute in minecraft:overworld run setblock 300 66 33 coarse_dirt
execute in minecraft:overworld run fill 300 67 33 300 144 33 air
execute in minecraft:overworld run fill 300 58 34 300 63 34 stone
execute in minecraft:overworld run fill 300 64 34 300 65 34 dirt
execute in minecraft:overworld run setblock 300 66 34 coarse_dirt
execute in minecraft:overworld run fill 300 67 34 300 144 34 air
execute in minecraft:overworld run fill 300 58 35 300 63 35 stone
execute in minecraft:overworld run fill 300 64 35 300 65 35 dirt
execute in minecraft:overworld run setblock 300 66 35 grass_block
execute in minecraft:overworld run fill 300 67 35 300 144 35 air
execute in minecraft:overworld run fill 300 58 36 300 63 36 stone
execute in minecraft:overworld run fill 300 64 36 300 65 36 dirt
execute in minecraft:overworld run setblock 300 66 36 coarse_dirt
execute in minecraft:overworld run fill 300 67 36 300 144 36 air
execute in minecraft:overworld run fill 300 58 37 300 63 37 stone
execute in minecraft:overworld run fill 300 64 37 300 65 37 dirt
execute in minecraft:overworld run setblock 300 66 37 grass_block
execute in minecraft:overworld run fill 300 67 37 300 144 37 air
execute in minecraft:overworld run fill 300 58 38 300 62 38 stone
execute in minecraft:overworld run fill 300 63 38 300 64 38 dirt
execute in minecraft:overworld run setblock 300 65 38 coarse_dirt
execute in minecraft:overworld run fill 300 66 38 300 144 38 air
execute in minecraft:overworld run fill 300 58 39 300 62 39 stone
execute in minecraft:overworld run fill 300 63 39 300 64 39 dirt
execute in minecraft:overworld run setblock 300 65 39 coarse_dirt
execute in minecraft:overworld run fill 300 66 39 300 144 39 air
execute in minecraft:overworld run fill 300 58 40 300 62 40 stone
execute in minecraft:overworld run fill 300 63 40 300 64 40 dirt
execute in minecraft:overworld run setblock 300 65 40 coarse_dirt
execute in minecraft:overworld run fill 300 66 40 300 144 40 air
execute in minecraft:overworld run fill 300 58 41 300 62 41 stone
execute in minecraft:overworld run fill 300 63 41 300 64 41 dirt
execute in minecraft:overworld run setblock 300 65 41 grass_block
execute in minecraft:overworld run fill 300 66 41 300 144 41 air
execute in minecraft:overworld run fill 300 58 42 300 62 42 stone
execute in minecraft:overworld run fill 300 63 42 300 64 42 dirt
execute in minecraft:overworld run setblock 300 65 42 coarse_dirt
execute in minecraft:overworld run fill 300 66 42 300 144 42 air
execute in minecraft:overworld run fill 300 58 43 300 62 43 stone
execute in minecraft:overworld run fill 300 63 43 300 64 43 dirt
execute in minecraft:overworld run setblock 300 65 43 coarse_dirt
execute in minecraft:overworld run fill 300 66 43 300 144 43 air
execute in minecraft:overworld run fill 300 58 44 300 62 44 stone
execute in minecraft:overworld run fill 300 63 44 300 64 44 dirt
execute in minecraft:overworld run setblock 300 65 44 coarse_dirt
execute in minecraft:overworld run fill 300 66 44 300 144 44 air
execute in minecraft:overworld run fill 300 58 45 300 62 45 stone
execute in minecraft:overworld run fill 300 63 45 300 64 45 dirt
execute in minecraft:overworld run setblock 300 65 45 grass_block
execute in minecraft:overworld run fill 300 66 45 300 144 45 air
execute in minecraft:overworld run fill 300 58 46 300 61 46 stone
execute in minecraft:overworld run fill 300 62 46 300 63 46 dirt
execute in minecraft:overworld run setblock 300 64 46 grass_block
execute in minecraft:overworld run fill 300 65 46 300 144 46 air
execute in minecraft:overworld run fill 300 58 47 300 61 47 stone
execute in minecraft:overworld run fill 300 62 47 300 63 47 dirt
execute in minecraft:overworld run setblock 300 64 47 coarse_dirt
execute in minecraft:overworld run fill 300 65 47 300 144 47 air
execute in minecraft:overworld run fill 301 58 -48 301 61 -48 stone
execute in minecraft:overworld run fill 301 62 -48 301 63 -48 dirt
execute in minecraft:overworld run setblock 301 64 -48 grass_block
execute in minecraft:overworld run fill 301 65 -48 301 144 -48 air
execute in minecraft:overworld run fill 301 58 -47 301 63 -47 stone
execute in minecraft:overworld run fill 301 64 -47 301 65 -47 dirt
execute in minecraft:overworld run setblock 301 66 -47 coarse_dirt
execute in minecraft:overworld run fill 301 67 -47 301 144 -47 air
execute in minecraft:overworld run fill 301 58 -46 301 65 -46 stone
execute in minecraft:overworld run fill 301 66 -46 301 67 -46 dirt
execute in minecraft:overworld run setblock 301 68 -46 coarse_dirt
execute in minecraft:overworld run fill 301 69 -46 301 144 -46 air
execute in minecraft:overworld run fill 301 58 -45 301 67 -45 stone
execute in minecraft:overworld run fill 301 68 -45 301 69 -45 dirt
execute in minecraft:overworld run setblock 301 70 -45 coarse_dirt
execute in minecraft:overworld run fill 301 71 -45 301 144 -45 air
execute in minecraft:overworld run fill 301 58 -44 301 67 -44 stone
execute in minecraft:overworld run fill 301 68 -44 301 69 -44 dirt
execute in minecraft:overworld run setblock 301 70 -44 coarse_dirt
execute in minecraft:overworld run fill 301 71 -44 301 144 -44 air
execute in minecraft:overworld run fill 301 58 -43 301 67 -43 stone
execute in minecraft:overworld run fill 301 68 -43 301 69 -43 dirt
execute in minecraft:overworld run setblock 301 70 -43 coarse_dirt
execute in minecraft:overworld run fill 301 71 -43 301 144 -43 air
execute in minecraft:overworld run fill 301 58 -42 301 66 -42 stone
execute in minecraft:overworld run fill 301 67 -42 301 68 -42 dirt
execute in minecraft:overworld run setblock 301 69 -42 coarse_dirt
execute in minecraft:overworld run fill 301 70 -42 301 144 -42 air
execute in minecraft:overworld run fill 301 58 -41 301 66 -41 stone
execute in minecraft:overworld run fill 301 67 -41 301 68 -41 dirt
execute in minecraft:overworld run setblock 301 69 -41 grass_block
execute in minecraft:overworld run fill 301 70 -41 301 144 -41 air
execute in minecraft:overworld run fill 301 58 -40 301 66 -40 stone
execute in minecraft:overworld run fill 301 67 -40 301 68 -40 dirt
execute in minecraft:overworld run setblock 301 69 -40 grass_block
execute in minecraft:overworld run fill 301 70 -40 301 144 -40 air
execute in minecraft:overworld run fill 301 58 -39 301 66 -39 stone
execute in minecraft:overworld run fill 301 67 -39 301 68 -39 dirt
execute in minecraft:overworld run setblock 301 69 -39 coarse_dirt
execute in minecraft:overworld run fill 301 70 -39 301 144 -39 air
execute in minecraft:overworld run fill 301 58 -38 301 66 -38 stone
execute in minecraft:overworld run fill 301 67 -38 301 68 -38 dirt
execute in minecraft:overworld run setblock 301 69 -38 coarse_dirt
execute in minecraft:overworld run fill 301 70 -38 301 144 -38 air
execute in minecraft:overworld run fill 301 58 -37 301 66 -37 stone
execute in minecraft:overworld run fill 301 67 -37 301 68 -37 dirt
execute in minecraft:overworld run setblock 301 69 -37 grass_block
execute in minecraft:overworld run fill 301 70 -37 301 144 -37 air
execute in minecraft:overworld run fill 301 58 -36 301 66 -36 stone
execute in minecraft:overworld run fill 301 67 -36 301 68 -36 dirt
execute in minecraft:overworld run setblock 301 69 -36 coarse_dirt
execute in minecraft:overworld run fill 301 70 -36 301 144 -36 air
execute in minecraft:overworld run fill 301 58 -35 301 66 -35 stone
execute in minecraft:overworld run fill 301 67 -35 301 68 -35 dirt
execute in minecraft:overworld run setblock 301 69 -35 grass_block
execute in minecraft:overworld run fill 301 70 -35 301 144 -35 air
execute in minecraft:overworld run fill 301 58 -34 301 66 -34 stone
execute in minecraft:overworld run fill 301 67 -34 301 68 -34 dirt
execute in minecraft:overworld run setblock 301 69 -34 coarse_dirt
execute in minecraft:overworld run fill 301 70 -34 301 144 -34 air
execute in minecraft:overworld run fill 301 58 -33 301 66 -33 stone
execute in minecraft:overworld run fill 301 67 -33 301 68 -33 dirt
execute in minecraft:overworld run setblock 301 69 -33 coarse_dirt
execute in minecraft:overworld run fill 301 70 -33 301 144 -33 air
execute in minecraft:overworld run fill 301 58 -32 301 66 -32 stone
execute in minecraft:overworld run fill 301 67 -32 301 68 -32 dirt
execute in minecraft:overworld run setblock 301 69 -32 coarse_dirt
execute in minecraft:overworld run fill 301 70 -32 301 144 -32 air
execute in minecraft:overworld run fill 301 58 -31 301 66 -31 stone
execute in minecraft:overworld run fill 301 67 -31 301 68 -31 dirt
execute in minecraft:overworld run setblock 301 69 -31 coarse_dirt
execute in minecraft:overworld run fill 301 70 -31 301 144 -31 air
execute in minecraft:overworld run fill 301 58 -30 301 65 -30 stone
execute in minecraft:overworld run fill 301 66 -30 301 67 -30 dirt
execute in minecraft:overworld run setblock 301 68 -30 coarse_dirt
execute in minecraft:overworld run fill 301 69 -30 301 144 -30 air
execute in minecraft:overworld run fill 301 58 -29 301 65 -29 stone
execute in minecraft:overworld run fill 301 66 -29 301 67 -29 dirt
execute in minecraft:overworld run setblock 301 68 -29 coarse_dirt
execute in minecraft:overworld run fill 301 69 -29 301 144 -29 air
execute in minecraft:overworld run fill 301 58 -28 301 65 -28 stone
execute in minecraft:overworld run fill 301 66 -28 301 67 -28 dirt
execute in minecraft:overworld run setblock 301 68 -28 grass_block
execute in minecraft:overworld run fill 301 69 -28 301 144 -28 air
execute in minecraft:overworld run fill 301 58 -27 301 65 -27 stone
execute in minecraft:overworld run fill 301 66 -27 301 67 -27 dirt
execute in minecraft:overworld run setblock 301 68 -27 coarse_dirt
execute in minecraft:overworld run fill 301 69 -27 301 144 -27 air
execute in minecraft:overworld run fill 301 58 -26 301 65 -26 stone
execute in minecraft:overworld run fill 301 66 -26 301 67 -26 dirt
execute in minecraft:overworld run setblock 301 68 -26 coarse_dirt
execute in minecraft:overworld run fill 301 69 -26 301 144 -26 air
execute in minecraft:overworld run fill 301 58 -25 301 65 -25 stone
execute in minecraft:overworld run fill 301 66 -25 301 67 -25 dirt
execute in minecraft:overworld run setblock 301 68 -25 coarse_dirt
execute in minecraft:overworld run fill 301 69 -25 301 144 -25 air
execute in minecraft:overworld run fill 301 58 -24 301 65 -24 stone
execute in minecraft:overworld run fill 301 66 -24 301 67 -24 dirt
execute in minecraft:overworld run setblock 301 68 -24 coarse_dirt
execute in minecraft:overworld run fill 301 69 -24 301 144 -24 air
execute in minecraft:overworld run fill 301 58 -23 301 65 -23 stone
execute in minecraft:overworld run fill 301 66 -23 301 67 -23 dirt
execute in minecraft:overworld run setblock 301 68 -23 coarse_dirt
execute in minecraft:overworld run fill 301 69 -23 301 144 -23 air
execute in minecraft:overworld run fill 301 58 -22 301 64 -22 stone
execute in minecraft:overworld run fill 301 65 -22 301 66 -22 dirt
execute in minecraft:overworld run setblock 301 67 -22 coarse_dirt
execute in minecraft:overworld run fill 301 68 -22 301 144 -22 air
execute in minecraft:overworld run fill 301 58 -21 301 64 -21 stone
execute in minecraft:overworld run fill 301 65 -21 301 66 -21 dirt
execute in minecraft:overworld run setblock 301 67 -21 coarse_dirt
execute in minecraft:overworld run fill 301 68 -21 301 144 -21 air
execute in minecraft:overworld run fill 301 58 -20 301 64 -20 stone
execute in minecraft:overworld run fill 301 65 -20 301 66 -20 dirt
execute in minecraft:overworld run setblock 301 67 -20 grass_block
execute in minecraft:overworld run fill 301 68 -20 301 144 -20 air
execute in minecraft:overworld run fill 301 58 -19 301 64 -19 stone
execute in minecraft:overworld run fill 301 65 -19 301 66 -19 dirt
execute in minecraft:overworld run setblock 301 67 -19 grass_block
execute in minecraft:overworld run fill 301 68 -19 301 144 -19 air
execute in minecraft:overworld run fill 301 58 -18 301 64 -18 stone
execute in minecraft:overworld run fill 301 65 -18 301 66 -18 dirt
execute in minecraft:overworld run setblock 301 67 -18 coarse_dirt
execute in minecraft:overworld run fill 301 68 -18 301 144 -18 air
execute in minecraft:overworld run fill 301 58 -17 301 64 -17 stone
execute in minecraft:overworld run fill 301 65 -17 301 66 -17 dirt
execute in minecraft:overworld run setblock 301 67 -17 grass_block
execute in minecraft:overworld run fill 301 68 -17 301 144 -17 air
execute in minecraft:overworld run fill 301 58 -16 301 64 -16 stone
execute in minecraft:overworld run fill 301 65 -16 301 66 -16 dirt
execute in minecraft:overworld run setblock 301 67 -16 grass_block
execute in minecraft:overworld run fill 301 68 -16 301 144 -16 air
execute in minecraft:overworld run fill 301 58 -15 301 63 -15 stone
execute in minecraft:overworld run fill 301 64 -15 301 65 -15 dirt
execute in minecraft:overworld run setblock 301 66 -15 grass_block
execute in minecraft:overworld run fill 301 67 -15 301 144 -15 air
execute in minecraft:overworld run fill 301 58 -14 301 63 -14 stone
execute in minecraft:overworld run fill 301 64 -14 301 65 -14 dirt
execute in minecraft:overworld run setblock 301 66 -14 coarse_dirt
execute in minecraft:overworld run fill 301 67 -14 301 144 -14 air
execute in minecraft:overworld run fill 301 58 -13 301 63 -13 stone
execute in minecraft:overworld run fill 301 64 -13 301 65 -13 dirt
execute in minecraft:overworld run setblock 301 66 -13 grass_block
execute in minecraft:overworld run fill 301 67 -13 301 144 -13 air
execute in minecraft:overworld run fill 301 58 -12 301 63 -12 stone
execute in minecraft:overworld run fill 301 64 -12 301 65 -12 dirt
execute in minecraft:overworld run setblock 301 66 -12 grass_block
execute in minecraft:overworld run fill 301 67 -12 301 144 -12 air
execute in minecraft:overworld run fill 301 58 -11 301 63 -11 stone
execute in minecraft:overworld run fill 301 64 -11 301 65 -11 dirt
execute in minecraft:overworld run setblock 301 66 -11 grass_block
execute in minecraft:overworld run fill 301 67 -11 301 144 -11 air
execute in minecraft:overworld run fill 301 58 -10 301 63 -10 stone
execute in minecraft:overworld run fill 301 64 -10 301 65 -10 dirt
execute in minecraft:overworld run setblock 301 66 -10 coarse_dirt
execute in minecraft:overworld run fill 301 67 -10 301 144 -10 air
execute in minecraft:overworld run fill 301 58 -9 301 63 -9 stone
execute in minecraft:overworld run fill 301 64 -9 301 65 -9 dirt
execute in minecraft:overworld run setblock 301 66 -9 coarse_dirt
execute in minecraft:overworld run fill 301 67 -9 301 144 -9 air
execute in minecraft:overworld run fill 301 58 -8 301 63 -8 stone
execute in minecraft:overworld run fill 301 64 -8 301 65 -8 dirt
execute in minecraft:overworld run setblock 301 66 -8 coarse_dirt
execute in minecraft:overworld run fill 301 67 -8 301 144 -8 air
execute in minecraft:overworld run fill 301 58 -7 301 63 -7 stone
schedule function blade_gallery:random/burned/part_147 1t replace
