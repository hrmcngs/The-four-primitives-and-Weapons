execute in minecraft:overworld run fill 362 73 29 362 144 29 air
execute in minecraft:overworld run fill 362 58 30 362 69 30 stone
execute in minecraft:overworld run fill 362 70 30 362 71 30 dirt
execute in minecraft:overworld run setblock 362 72 30 grass_block
execute in minecraft:overworld run fill 362 73 30 362 144 30 air
execute in minecraft:overworld run fill 362 58 31 362 69 31 stone
execute in minecraft:overworld run fill 362 70 31 362 71 31 dirt
execute in minecraft:overworld run setblock 362 72 31 coarse_dirt
execute in minecraft:overworld run fill 362 73 31 362 144 31 air
execute in minecraft:overworld run fill 362 58 32 362 69 32 stone
execute in minecraft:overworld run fill 362 70 32 362 71 32 dirt
execute in minecraft:overworld run setblock 362 72 32 coarse_dirt
execute in minecraft:overworld run fill 362 73 32 362 144 32 air
execute in minecraft:overworld run fill 362 58 33 362 69 33 stone
execute in minecraft:overworld run fill 362 70 33 362 71 33 dirt
execute in minecraft:overworld run setblock 362 72 33 grass_block
execute in minecraft:overworld run fill 362 73 33 362 144 33 air
execute in minecraft:overworld run fill 362 58 34 362 70 34 stone
execute in minecraft:overworld run fill 362 71 34 362 72 34 dirt
execute in minecraft:overworld run setblock 362 73 34 coarse_dirt
execute in minecraft:overworld run fill 362 74 34 362 144 34 air
execute in minecraft:overworld run fill 362 58 35 362 70 35 stone
execute in minecraft:overworld run fill 362 71 35 362 72 35 dirt
execute in minecraft:overworld run setblock 362 73 35 grass_block
execute in minecraft:overworld run fill 362 74 35 362 144 35 air
execute in minecraft:overworld run fill 362 58 36 362 70 36 stone
execute in minecraft:overworld run fill 362 71 36 362 72 36 dirt
execute in minecraft:overworld run setblock 362 73 36 grass_block
execute in minecraft:overworld run fill 362 74 36 362 144 36 air
execute in minecraft:overworld run fill 362 58 37 362 70 37 stone
execute in minecraft:overworld run fill 362 71 37 362 72 37 dirt
execute in minecraft:overworld run setblock 362 73 37 coarse_dirt
execute in minecraft:overworld run fill 362 74 37 362 144 37 air
execute in minecraft:overworld run fill 362 58 38 362 70 38 stone
execute in minecraft:overworld run fill 362 71 38 362 72 38 dirt
execute in minecraft:overworld run setblock 362 73 38 coarse_dirt
execute in minecraft:overworld run fill 362 74 38 362 144 38 air
execute in minecraft:overworld run fill 362 58 39 362 69 39 stone
execute in minecraft:overworld run fill 362 70 39 362 71 39 dirt
execute in minecraft:overworld run setblock 362 72 39 grass_block
execute in minecraft:overworld run fill 362 73 39 362 144 39 air
execute in minecraft:overworld run fill 362 58 40 362 68 40 stone
execute in minecraft:overworld run fill 362 69 40 362 70 40 dirt
execute in minecraft:overworld run setblock 362 71 40 coarse_dirt
execute in minecraft:overworld run fill 362 72 40 362 144 40 air
execute in minecraft:overworld run setblock 362 72 40 grass
execute in minecraft:overworld run fill 362 58 41 362 67 41 stone
execute in minecraft:overworld run fill 362 68 41 362 69 41 dirt
execute in minecraft:overworld run setblock 362 70 41 coarse_dirt
execute in minecraft:overworld run fill 362 71 41 362 144 41 air
execute in minecraft:overworld run setblock 362 71 41 grass
execute in minecraft:overworld run fill 362 58 42 362 66 42 stone
execute in minecraft:overworld run fill 362 67 42 362 68 42 dirt
execute in minecraft:overworld run setblock 362 69 42 coarse_dirt
execute in minecraft:overworld run fill 362 70 42 362 144 42 air
execute in minecraft:overworld run fill 362 58 43 362 65 43 stone
execute in minecraft:overworld run fill 362 66 43 362 67 43 dirt
execute in minecraft:overworld run setblock 362 68 43 grass_block
execute in minecraft:overworld run fill 362 69 43 362 144 43 air
execute in minecraft:overworld run fill 362 58 44 362 64 44 stone
execute in minecraft:overworld run fill 362 65 44 362 66 44 dirt
execute in minecraft:overworld run setblock 362 67 44 coarse_dirt
execute in minecraft:overworld run fill 362 68 44 362 144 44 air
execute in minecraft:overworld run fill 362 58 45 362 63 45 stone
execute in minecraft:overworld run fill 362 64 45 362 65 45 dirt
execute in minecraft:overworld run setblock 362 66 45 coarse_dirt
execute in minecraft:overworld run fill 362 67 45 362 144 45 air
execute in minecraft:overworld run fill 362 58 46 362 63 46 stone
execute in minecraft:overworld run fill 362 64 46 362 65 46 dirt
execute in minecraft:overworld run setblock 362 66 46 coarse_dirt
execute in minecraft:overworld run fill 362 67 46 362 144 46 air
execute in minecraft:overworld run fill 362 58 47 362 62 47 stone
execute in minecraft:overworld run fill 362 63 47 362 64 47 dirt
execute in minecraft:overworld run setblock 362 65 47 coarse_dirt
execute in minecraft:overworld run fill 362 66 47 362 144 47 air
execute in minecraft:overworld run fill 363 58 -48 363 61 -48 stone
execute in minecraft:overworld run fill 363 62 -48 363 63 -48 dirt
execute in minecraft:overworld run setblock 363 64 -48 coarse_dirt
execute in minecraft:overworld run fill 363 65 -48 363 144 -48 air
execute in minecraft:overworld run fill 363 58 -47 363 63 -47 stone
execute in minecraft:overworld run fill 363 64 -47 363 65 -47 dirt
execute in minecraft:overworld run setblock 363 66 -47 coarse_dirt
execute in minecraft:overworld run fill 363 67 -47 363 144 -47 air
execute in minecraft:overworld run fill 363 58 -46 363 64 -46 stone
execute in minecraft:overworld run fill 363 65 -46 363 66 -46 dirt
execute in minecraft:overworld run setblock 363 67 -46 coarse_dirt
execute in minecraft:overworld run fill 363 68 -46 363 144 -46 air
execute in minecraft:overworld run fill 363 58 -45 363 66 -45 stone
execute in minecraft:overworld run fill 363 67 -45 363 68 -45 dirt
execute in minecraft:overworld run setblock 363 69 -45 coarse_dirt
execute in minecraft:overworld run fill 363 70 -45 363 144 -45 air
execute in minecraft:overworld run fill 363 58 -44 363 68 -44 stone
execute in minecraft:overworld run fill 363 69 -44 363 70 -44 dirt
execute in minecraft:overworld run setblock 363 71 -44 coarse_dirt
execute in minecraft:overworld run fill 363 72 -44 363 144 -44 air
execute in minecraft:overworld run fill 363 58 -43 363 69 -43 stone
execute in minecraft:overworld run fill 363 70 -43 363 71 -43 dirt
execute in minecraft:overworld run setblock 363 72 -43 grass_block
execute in minecraft:overworld run fill 363 73 -43 363 144 -43 air
execute in minecraft:overworld run fill 363 58 -42 363 70 -42 stone
execute in minecraft:overworld run fill 363 71 -42 363 72 -42 dirt
execute in minecraft:overworld run setblock 363 73 -42 grass_block
execute in minecraft:overworld run fill 363 74 -42 363 144 -42 air
execute in minecraft:overworld run fill 363 58 -41 363 72 -41 stone
execute in minecraft:overworld run fill 363 73 -41 363 74 -41 dirt
execute in minecraft:overworld run setblock 363 75 -41 grass_block
execute in minecraft:overworld run fill 363 76 -41 363 144 -41 air
execute in minecraft:overworld run setblock 363 76 -41 grass
execute in minecraft:overworld run fill 363 58 -40 363 73 -40 stone
execute in minecraft:overworld run fill 363 74 -40 363 75 -40 dirt
execute in minecraft:overworld run setblock 363 76 -40 coarse_dirt
execute in minecraft:overworld run fill 363 77 -40 363 144 -40 air
execute in minecraft:overworld run fill 363 58 -39 363 74 -39 stone
execute in minecraft:overworld run fill 363 75 -39 363 76 -39 dirt
execute in minecraft:overworld run setblock 363 77 -39 grass_block
execute in minecraft:overworld run fill 363 78 -39 363 144 -39 air
execute in minecraft:overworld run setblock 363 78 -39 mossy_cobblestone
execute in minecraft:overworld run fill 363 58 -38 363 75 -38 stone
execute in minecraft:overworld run fill 363 76 -38 363 77 -38 dirt
execute in minecraft:overworld run setblock 363 78 -38 coarse_dirt
execute in minecraft:overworld run fill 363 79 -38 363 144 -38 air
execute in minecraft:overworld run setblock 363 79 -38 grass
execute in minecraft:overworld run fill 363 58 -37 363 74 -37 stone
execute in minecraft:overworld run fill 363 75 -37 363 76 -37 dirt
execute in minecraft:overworld run setblock 363 77 -37 coarse_dirt
execute in minecraft:overworld run fill 363 78 -37 363 144 -37 air
execute in minecraft:overworld run fill 363 58 -36 363 74 -36 stone
execute in minecraft:overworld run fill 363 75 -36 363 76 -36 dirt
execute in minecraft:overworld run setblock 363 77 -36 grass_block
execute in minecraft:overworld run fill 363 78 -36 363 144 -36 air
execute in minecraft:overworld run fill 363 58 -35 363 74 -35 stone
execute in minecraft:overworld run fill 363 75 -35 363 76 -35 dirt
execute in minecraft:overworld run setblock 363 77 -35 coarse_dirt
execute in minecraft:overworld run fill 363 78 -35 363 144 -35 air
execute in minecraft:overworld run fill 363 58 -34 363 74 -34 stone
execute in minecraft:overworld run fill 363 75 -34 363 76 -34 dirt
execute in minecraft:overworld run setblock 363 77 -34 coarse_dirt
execute in minecraft:overworld run fill 363 78 -34 363 144 -34 air
execute in minecraft:overworld run fill 363 58 -33 363 74 -33 stone
execute in minecraft:overworld run fill 363 75 -33 363 76 -33 dirt
execute in minecraft:overworld run setblock 363 77 -33 coarse_dirt
execute in minecraft:overworld run fill 363 78 -33 363 144 -33 air
execute in minecraft:overworld run fill 363 58 -32 363 74 -32 stone
execute in minecraft:overworld run fill 363 75 -32 363 76 -32 dirt
execute in minecraft:overworld run setblock 363 77 -32 coarse_dirt
execute in minecraft:overworld run fill 363 78 -32 363 144 -32 air
execute in minecraft:overworld run fill 363 58 -31 363 73 -31 stone
execute in minecraft:overworld run fill 363 74 -31 363 75 -31 dirt
execute in minecraft:overworld run setblock 363 76 -31 coarse_dirt
execute in minecraft:overworld run fill 363 77 -31 363 144 -31 air
execute in minecraft:overworld run fill 363 58 -30 363 73 -30 stone
execute in minecraft:overworld run fill 363 74 -30 363 75 -30 dirt
execute in minecraft:overworld run setblock 363 76 -30 coarse_dirt
execute in minecraft:overworld run fill 363 77 -30 363 144 -30 air
execute in minecraft:overworld run fill 363 58 -29 363 73 -29 stone
execute in minecraft:overworld run fill 363 74 -29 363 75 -29 dirt
execute in minecraft:overworld run setblock 363 76 -29 grass_block
execute in minecraft:overworld run fill 363 77 -29 363 144 -29 air
execute in minecraft:overworld run fill 363 58 -28 363 73 -28 stone
execute in minecraft:overworld run fill 363 74 -28 363 75 -28 dirt
execute in minecraft:overworld run setblock 363 76 -28 grass_block
execute in minecraft:overworld run fill 363 77 -28 363 144 -28 air
execute in minecraft:overworld run fill 363 58 -27 363 73 -27 stone
execute in minecraft:overworld run fill 363 74 -27 363 75 -27 dirt
execute in minecraft:overworld run setblock 363 76 -27 coarse_dirt
execute in minecraft:overworld run fill 363 77 -27 363 144 -27 air
execute in minecraft:overworld run fill 363 58 -26 363 72 -26 stone
execute in minecraft:overworld run fill 363 73 -26 363 74 -26 dirt
execute in minecraft:overworld run setblock 363 75 -26 coarse_dirt
execute in minecraft:overworld run fill 363 76 -26 363 144 -26 air
execute in minecraft:overworld run fill 363 58 -25 363 72 -25 stone
execute in minecraft:overworld run fill 363 73 -25 363 74 -25 dirt
execute in minecraft:overworld run setblock 363 75 -25 coarse_dirt
execute in minecraft:overworld run fill 363 76 -25 363 144 -25 air
execute in minecraft:overworld run fill 363 58 -24 363 72 -24 stone
execute in minecraft:overworld run fill 363 73 -24 363 74 -24 dirt
execute in minecraft:overworld run setblock 363 75 -24 coarse_dirt
execute in minecraft:overworld run fill 363 76 -24 363 144 -24 air
execute in minecraft:overworld run fill 363 58 -23 363 71 -23 stone
execute in minecraft:overworld run fill 363 72 -23 363 73 -23 dirt
execute in minecraft:overworld run setblock 363 74 -23 grass_block
execute in minecraft:overworld run fill 363 75 -23 363 144 -23 air
execute in minecraft:overworld run setblock 363 75 -23 mossy_cobblestone
execute in minecraft:overworld run fill 363 58 -22 363 71 -22 stone
execute in minecraft:overworld run fill 363 72 -22 363 73 -22 dirt
execute in minecraft:overworld run setblock 363 74 -22 coarse_dirt
execute in minecraft:overworld run fill 363 75 -22 363 144 -22 air
execute in minecraft:overworld run fill 363 58 -21 363 71 -21 stone
execute in minecraft:overworld run fill 363 72 -21 363 73 -21 dirt
execute in minecraft:overworld run setblock 363 74 -21 coarse_dirt
execute in minecraft:overworld run fill 363 75 -21 363 144 -21 air
execute in minecraft:overworld run fill 363 58 -20 363 70 -20 stone
execute in minecraft:overworld run fill 363 71 -20 363 72 -20 dirt
execute in minecraft:overworld run setblock 363 73 -20 coarse_dirt
execute in minecraft:overworld run fill 363 74 -20 363 144 -20 air
execute in minecraft:overworld run fill 363 58 -19 363 70 -19 stone
execute in minecraft:overworld run fill 363 71 -19 363 72 -19 dirt
execute in minecraft:overworld run setblock 363 73 -19 grass_block
execute in minecraft:overworld run fill 363 74 -19 363 144 -19 air
execute in minecraft:overworld run fill 363 58 -18 363 70 -18 stone
execute in minecraft:overworld run fill 363 71 -18 363 72 -18 dirt
execute in minecraft:overworld run setblock 363 73 -18 coarse_dirt
execute in minecraft:overworld run fill 363 74 -18 363 144 -18 air
execute in minecraft:overworld run fill 363 58 -17 363 69 -17 stone
execute in minecraft:overworld run fill 363 70 -17 363 71 -17 dirt
execute in minecraft:overworld run setblock 363 72 -17 coarse_dirt
execute in minecraft:overworld run fill 363 73 -17 363 144 -17 air
execute in minecraft:overworld run fill 363 58 -16 363 69 -16 stone
execute in minecraft:overworld run fill 363 70 -16 363 71 -16 dirt
execute in minecraft:overworld run setblock 363 72 -16 coarse_dirt
execute in minecraft:overworld run fill 363 73 -16 363 144 -16 air
execute in minecraft:overworld run fill 363 58 -15 363 68 -15 stone
execute in minecraft:overworld run fill 363 69 -15 363 70 -15 dirt
execute in minecraft:overworld run setblock 363 71 -15 coarse_dirt
execute in minecraft:overworld run fill 363 72 -15 363 144 -15 air
execute in minecraft:overworld run fill 363 58 -14 363 67 -14 stone
execute in minecraft:overworld run fill 363 68 -14 363 69 -14 dirt
execute in minecraft:overworld run setblock 363 70 -14 coarse_dirt
execute in minecraft:overworld run fill 363 71 -14 363 144 -14 air
execute in minecraft:overworld run fill 363 58 -13 363 67 -13 stone
execute in minecraft:overworld run fill 363 68 -13 363 69 -13 dirt
execute in minecraft:overworld run setblock 363 70 -13 grass_block
execute in minecraft:overworld run fill 363 71 -13 363 144 -13 air
execute in minecraft:overworld run setblock 363 71 -13 grass
execute in minecraft:overworld run fill 363 58 -12 363 66 -12 stone
execute in minecraft:overworld run fill 363 67 -12 363 68 -12 dirt
execute in minecraft:overworld run setblock 363 69 -12 coarse_dirt
execute in minecraft:overworld run fill 363 70 -12 363 144 -12 air
execute in minecraft:overworld run fill 363 58 -11 363 66 -11 stone
execute in minecraft:overworld run fill 363 67 -11 363 68 -11 dirt
execute in minecraft:overworld run setblock 363 69 -11 coarse_dirt
execute in minecraft:overworld run fill 363 70 -11 363 144 -11 air
execute in minecraft:overworld run fill 363 58 -10 363 65 -10 stone
execute in minecraft:overworld run fill 363 66 -10 363 67 -10 dirt
execute in minecraft:overworld run setblock 363 68 -10 grass_block
execute in minecraft:overworld run fill 363 69 -10 363 144 -10 air
execute in minecraft:overworld run fill 363 58 -9 363 65 -9 stone
execute in minecraft:overworld run fill 363 66 -9 363 67 -9 dirt
execute in minecraft:overworld run setblock 363 68 -9 coarse_dirt
execute in minecraft:overworld run fill 363 69 -9 363 144 -9 air
execute in minecraft:overworld run setblock 363 69 -9 grass
execute in minecraft:overworld run fill 363 58 -8 363 65 -8 stone
execute in minecraft:overworld run fill 363 66 -8 363 67 -8 dirt
execute in minecraft:overworld run setblock 363 68 -8 coarse_dirt
execute in minecraft:overworld run fill 363 69 -8 363 144 -8 air
execute in minecraft:overworld run fill 363 58 -7 363 65 -7 stone
execute in minecraft:overworld run fill 363 66 -7 363 67 -7 dirt
execute in minecraft:overworld run setblock 363 68 -7 grass_block
execute in minecraft:overworld run fill 363 69 -7 363 144 -7 air
execute in minecraft:overworld run fill 363 58 -6 363 65 -6 stone
execute in minecraft:overworld run fill 363 66 -6 363 67 -6 dirt
execute in minecraft:overworld run setblock 363 68 -6 coarse_dirt
execute in minecraft:overworld run fill 363 69 -6 363 144 -6 air
execute in minecraft:overworld run setblock 363 69 -6 grass
execute in minecraft:overworld run fill 363 58 -5 363 65 -5 stone
execute in minecraft:overworld run fill 363 66 -5 363 67 -5 dirt
schedule function blade_gallery:random/battlefield/part_42 1t replace
