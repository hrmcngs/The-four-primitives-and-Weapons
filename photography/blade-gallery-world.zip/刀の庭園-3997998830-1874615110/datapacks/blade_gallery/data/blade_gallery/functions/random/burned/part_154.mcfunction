execute in minecraft:overworld run fill 238 74 -29 238 78 -29 stone_bricks
execute in minecraft:overworld run fill 238 74 -28 238 78 -28 stone_bricks
execute in minecraft:overworld run fill 239 75 -36 239 78 -36 stone_bricks
execute in minecraft:overworld run fill 239 75 -35 239 78 -35 stone_bricks
execute in minecraft:overworld run fill 239 75 -34 239 78 -34 stone_bricks
execute in minecraft:overworld run fill 239 75 -33 239 78 -33 stone_bricks
execute in minecraft:overworld run fill 239 75 -32 239 78 -32 stone_bricks
execute in minecraft:overworld run fill 239 75 -31 239 78 -31 stone_bricks
execute in minecraft:overworld run fill 239 75 -30 239 78 -30 stone_bricks
execute in minecraft:overworld run fill 239 74 -29 239 78 -29 stone_bricks
execute in minecraft:overworld run fill 239 74 -28 239 78 -28 stone_bricks
execute in minecraft:overworld run fill 240 75 -36 240 78 -36 stone_bricks
execute in minecraft:overworld run fill 240 75 -35 240 78 -35 stone_bricks
execute in minecraft:overworld run fill 240 75 -34 240 78 -34 stone_bricks
execute in minecraft:overworld run fill 240 75 -33 240 78 -33 stone_bricks
execute in minecraft:overworld run fill 240 75 -32 240 78 -32 stone_bricks
execute in minecraft:overworld run fill 240 75 -31 240 78 -31 stone_bricks
execute in minecraft:overworld run fill 240 75 -30 240 78 -30 stone_bricks
execute in minecraft:overworld run fill 240 74 -29 240 78 -29 stone_bricks
execute in minecraft:overworld run fill 240 74 -28 240 78 -28 stone_bricks
execute in minecraft:overworld run fill 241 74 -36 241 78 -36 stone_bricks
execute in minecraft:overworld run fill 241 74 -35 241 78 -35 stone_bricks
execute in minecraft:overworld run fill 241 74 -34 241 78 -34 stone_bricks
execute in minecraft:overworld run fill 241 74 -33 241 78 -33 stone_bricks
execute in minecraft:overworld run fill 241 74 -32 241 78 -32 stone_bricks
execute in minecraft:overworld run fill 241 74 -31 241 78 -31 stone_bricks
execute in minecraft:overworld run fill 241 74 -30 241 78 -30 stone_bricks
execute in minecraft:overworld run fill 241 74 -29 241 78 -29 stone_bricks
execute in minecraft:overworld run fill 241 74 -28 241 78 -28 stone_bricks
execute in minecraft:overworld run fill 242 73 -36 242 78 -36 stone_bricks
execute in minecraft:overworld run fill 242 74 -35 242 78 -35 stone_bricks
execute in minecraft:overworld run fill 242 74 -34 242 78 -34 stone_bricks
execute in minecraft:overworld run fill 242 74 -33 242 78 -33 stone_bricks
execute in minecraft:overworld run fill 242 74 -32 242 78 -32 stone_bricks
execute in minecraft:overworld run fill 242 74 -31 242 78 -31 stone_bricks
execute in minecraft:overworld run fill 242 74 -30 242 78 -30 stone_bricks
execute in minecraft:overworld run fill 242 74 -29 242 78 -29 stone_bricks
execute in minecraft:overworld run fill 242 74 -28 242 78 -28 stone_bricks
execute in minecraft:overworld run fill 243 73 -36 243 78 -36 stone_bricks
execute in minecraft:overworld run fill 243 73 -35 243 78 -35 stone_bricks
execute in minecraft:overworld run fill 243 73 -34 243 78 -34 stone_bricks
execute in minecraft:overworld run fill 243 73 -33 243 78 -33 stone_bricks
execute in minecraft:overworld run fill 243 74 -32 243 78 -32 stone_bricks
execute in minecraft:overworld run fill 243 74 -31 243 78 -31 stone_bricks
execute in minecraft:overworld run fill 243 74 -30 243 78 -30 stone_bricks
execute in minecraft:overworld run fill 243 74 -29 243 78 -29 stone_bricks
execute in minecraft:overworld run fill 243 74 -28 243 78 -28 stone_bricks
execute in minecraft:overworld run fill 244 72 -36 244 78 -36 stone_bricks
execute in minecraft:overworld run fill 244 72 -35 244 78 -35 stone_bricks
execute in minecraft:overworld run fill 244 73 -34 244 78 -34 stone_bricks
execute in minecraft:overworld run fill 244 73 -33 244 78 -33 stone_bricks
execute in minecraft:overworld run fill 244 73 -32 244 78 -32 stone_bricks
execute in minecraft:overworld run fill 244 73 -31 244 78 -31 stone_bricks
execute in minecraft:overworld run fill 244 73 -30 244 78 -30 stone_bricks
execute in minecraft:overworld run fill 244 74 -29 244 78 -29 stone_bricks
execute in minecraft:overworld run fill 244 74 -28 244 78 -28 stone_bricks
execute in minecraft:overworld run setblock 236 78 -36 gray_concrete
execute in minecraft:overworld run setblock 236 78 -35 gray_concrete
execute in minecraft:overworld run setblock 236 78 -34 gray_concrete
execute in minecraft:overworld run setblock 236 78 -33 gray_concrete
execute in minecraft:overworld run setblock 236 78 -32 gray_concrete
execute in minecraft:overworld run setblock 236 78 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 78 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 78 -29 gray_concrete
execute in minecraft:overworld run setblock 236 78 -28 gray_concrete
execute in minecraft:overworld run setblock 237 78 -36 gray_concrete
execute in minecraft:overworld run setblock 237 78 -35 gray_concrete
execute in minecraft:overworld run setblock 237 78 -34 gray_concrete
execute in minecraft:overworld run setblock 237 78 -33 gray_concrete
execute in minecraft:overworld run setblock 237 78 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 237 78 -30 gray_concrete
execute in minecraft:overworld run setblock 237 78 -29 gray_concrete
execute in minecraft:overworld run setblock 237 78 -28 gray_concrete
execute in minecraft:overworld run setblock 238 78 -36 gray_concrete
execute in minecraft:overworld run setblock 238 78 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 78 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 78 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 78 -31 gray_concrete
execute in minecraft:overworld run setblock 238 78 -30 gray_concrete
execute in minecraft:overworld run setblock 238 78 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 78 -28 gray_concrete
execute in minecraft:overworld run setblock 239 78 -36 gray_concrete
execute in minecraft:overworld run setblock 239 78 -35 gray_concrete
execute in minecraft:overworld run setblock 239 78 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 239 78 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 239 78 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 239 78 -31 gray_concrete
execute in minecraft:overworld run setblock 239 78 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 239 78 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 239 78 -28 gray_concrete
execute in minecraft:overworld run setblock 240 78 -36 gray_concrete
execute in minecraft:overworld run setblock 240 78 -34 gray_concrete
execute in minecraft:overworld run setblock 240 78 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 240 78 -32 gray_concrete
execute in minecraft:overworld run setblock 240 78 -31 gray_concrete
execute in minecraft:overworld run setblock 240 78 -30 gray_concrete
execute in minecraft:overworld run setblock 240 78 -29 gray_concrete
execute in minecraft:overworld run setblock 240 78 -28 gray_concrete
execute in minecraft:overworld run setblock 241 78 -36 gray_concrete
execute in minecraft:overworld run setblock 241 78 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 241 78 -34 gray_concrete
execute in minecraft:overworld run setblock 241 78 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 241 78 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 241 78 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 241 78 -30 gray_concrete
execute in minecraft:overworld run setblock 241 78 -29 gray_concrete
execute in minecraft:overworld run setblock 242 78 -36 gray_concrete
execute in minecraft:overworld run setblock 242 78 -35 gray_concrete
execute in minecraft:overworld run setblock 242 78 -34 gray_concrete
execute in minecraft:overworld run setblock 242 78 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 242 78 -32 gray_concrete
execute in minecraft:overworld run setblock 242 78 -31 gray_concrete
execute in minecraft:overworld run setblock 242 78 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 242 78 -29 gray_concrete
execute in minecraft:overworld run setblock 242 78 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 243 78 -36 gray_concrete
execute in minecraft:overworld run setblock 243 78 -35 gray_concrete
execute in minecraft:overworld run setblock 243 78 -33 gray_concrete
execute in minecraft:overworld run setblock 243 78 -32 gray_concrete
execute in minecraft:overworld run setblock 243 78 -31 gray_concrete
execute in minecraft:overworld run setblock 243 78 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 243 78 -29 gray_concrete
execute in minecraft:overworld run setblock 243 78 -28 gray_concrete
execute in minecraft:overworld run setblock 244 78 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 78 -35 gray_concrete
execute in minecraft:overworld run setblock 244 78 -34 gray_concrete
execute in minecraft:overworld run setblock 244 78 -33 gray_concrete
execute in minecraft:overworld run setblock 244 78 -32 gray_concrete
execute in minecraft:overworld run setblock 244 78 -31 gray_concrete
execute in minecraft:overworld run setblock 244 78 -30 gray_concrete
execute in minecraft:overworld run setblock 244 78 -29 gray_concrete
execute in minecraft:overworld run setblock 244 78 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 79 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 79 -35 gray_concrete
execute in minecraft:overworld run setblock 236 79 -34 gray_concrete
execute in minecraft:overworld run setblock 236 79 -33 gray_concrete
execute in minecraft:overworld run setblock 236 79 -32 gray_concrete
execute in minecraft:overworld run setblock 236 79 -31 gray_concrete
execute in minecraft:overworld run setblock 236 79 -29 gray_concrete
execute in minecraft:overworld run setblock 236 79 -28 gray_concrete
execute in minecraft:overworld run setblock 237 79 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 237 79 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 79 -36 gray_concrete
execute in minecraft:overworld run setblock 238 79 -28 gray_concrete
execute in minecraft:overworld run setblock 239 79 -36 gray_concrete
execute in minecraft:overworld run setblock 239 79 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 240 79 -36 gray_concrete
execute in minecraft:overworld run setblock 240 79 -28 gray_concrete
execute in minecraft:overworld run setblock 241 79 -36 gray_concrete
execute in minecraft:overworld run setblock 241 79 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 242 79 -36 gray_concrete
execute in minecraft:overworld run setblock 242 79 -28 gray_concrete
execute in minecraft:overworld run setblock 243 79 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 243 79 -28 gray_concrete
execute in minecraft:overworld run setblock 244 79 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 79 -35 gray_concrete
execute in minecraft:overworld run setblock 244 79 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 79 -33 gray_concrete
execute in minecraft:overworld run setblock 244 79 -32 gray_concrete
execute in minecraft:overworld run setblock 244 79 -31 gray_concrete
execute in minecraft:overworld run setblock 244 79 -30 gray_concrete
execute in minecraft:overworld run setblock 244 79 -28 gray_concrete
execute in minecraft:overworld run setblock 236 80 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 80 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 80 -33 gray_concrete
execute in minecraft:overworld run setblock 236 80 -32 gray_concrete
execute in minecraft:overworld run setblock 236 80 -31 gray_concrete
execute in minecraft:overworld run setblock 236 80 -30 gray_concrete
execute in minecraft:overworld run setblock 236 80 -29 gray_concrete
execute in minecraft:overworld run setblock 236 80 -28 gray_concrete
execute in minecraft:overworld run setblock 237 80 -28 gray_concrete
execute in minecraft:overworld run setblock 238 80 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 80 -28 gray_concrete
execute in minecraft:overworld run setblock 239 80 -36 gray_concrete
execute in minecraft:overworld run setblock 239 80 -28 gray_concrete
execute in minecraft:overworld run setblock 240 80 -36 gray_concrete
execute in minecraft:overworld run setblock 240 80 -28 gray_concrete
execute in minecraft:overworld run setblock 241 80 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 241 80 -28 gray_concrete
execute in minecraft:overworld run setblock 242 80 -36 gray_concrete
execute in minecraft:overworld run setblock 242 80 -28 gray_concrete
execute in minecraft:overworld run setblock 243 80 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 80 -36 gray_concrete
execute in minecraft:overworld run setblock 244 80 -35 gray_concrete
execute in minecraft:overworld run setblock 244 80 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 80 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 80 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 80 -31 gray_concrete
execute in minecraft:overworld run setblock 244 80 -30 gray_concrete
execute in minecraft:overworld run setblock 244 80 -29 gray_concrete
execute in minecraft:overworld run setblock 244 80 -28 gray_concrete
execute in minecraft:overworld run setblock 236 81 -36 gray_concrete
execute in minecraft:overworld run setblock 236 81 -35 gray_concrete
execute in minecraft:overworld run setblock 236 81 -34 gray_concrete
execute in minecraft:overworld run setblock 236 81 -33 gray_concrete
execute in minecraft:overworld run setblock 236 81 -32 gray_concrete
execute in minecraft:overworld run setblock 236 81 -31 gray_concrete
execute in minecraft:overworld run setblock 236 81 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 81 -29 gray_concrete
execute in minecraft:overworld run setblock 236 81 -28 gray_concrete
execute in minecraft:overworld run setblock 237 81 -36 gray_concrete
execute in minecraft:overworld run setblock 237 81 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 238 81 -36 gray_concrete
execute in minecraft:overworld run setblock 238 81 -28 gray_concrete
execute in minecraft:overworld run setblock 239 81 -36 gray_concrete
execute in minecraft:overworld run setblock 239 81 -28 gray_concrete
execute in minecraft:overworld run setblock 240 81 -28 gray_concrete
execute in minecraft:overworld run setblock 241 81 -36 gray_concrete
execute in minecraft:overworld run setblock 241 81 -28 gray_concrete
execute in minecraft:overworld run setblock 242 81 -36 gray_concrete
execute in minecraft:overworld run setblock 242 81 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 243 81 -36 gray_concrete
execute in minecraft:overworld run setblock 243 81 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 81 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 81 -35 gray_concrete
execute in minecraft:overworld run setblock 244 81 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 81 -32 gray_concrete
execute in minecraft:overworld run setblock 244 81 -31 gray_concrete
execute in minecraft:overworld run setblock 244 81 -30 gray_concrete
execute in minecraft:overworld run setblock 244 81 -29 gray_concrete
execute in minecraft:overworld run setblock 244 81 -28 gray_concrete
execute in minecraft:overworld run setblock 236 82 -36 gray_concrete
execute in minecraft:overworld run setblock 236 82 -35 gray_concrete
execute in minecraft:overworld run setblock 236 82 -34 gray_concrete
execute in minecraft:overworld run setblock 236 82 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 82 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 82 -31 gray_concrete
execute in minecraft:overworld run setblock 236 82 -30 gray_concrete
execute in minecraft:overworld run setblock 236 82 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 237 82 -36 gray_concrete
execute in minecraft:overworld run setblock 237 82 -28 gray_concrete
execute in minecraft:overworld run setblock 238 82 -36 gray_concrete
execute in minecraft:overworld run setblock 238 82 -28 gray_concrete
execute in minecraft:overworld run setblock 239 82 -36 gray_concrete
execute in minecraft:overworld run setblock 239 82 -28 gray_concrete
execute in minecraft:overworld run setblock 240 82 -36 cracked_stone_bricks
execute in minecraft:overworld run setblock 240 82 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 241 82 -36 gray_concrete
execute in minecraft:overworld run setblock 241 82 -28 gray_concrete
execute in minecraft:overworld run setblock 242 82 -36 gray_concrete
execute in minecraft:overworld run setblock 242 82 -28 gray_concrete
execute in minecraft:overworld run setblock 243 82 -36 gray_concrete
execute in minecraft:overworld run setblock 243 82 -28 gray_concrete
execute in minecraft:overworld run setblock 244 82 -36 gray_concrete
execute in minecraft:overworld run setblock 244 82 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 244 82 -34 gray_concrete
execute in minecraft:overworld run setblock 244 82 -33 gray_concrete
execute in minecraft:overworld run setblock 244 82 -32 gray_concrete
execute in minecraft:overworld run setblock 244 82 -30 gray_concrete
execute in minecraft:overworld run setblock 244 82 -29 gray_concrete
execute in minecraft:overworld run setblock 244 82 -28 gray_concrete
execute in minecraft:overworld run setblock 236 83 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 83 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 83 -33 gray_concrete
execute in minecraft:overworld run setblock 236 83 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 236 83 -30 cracked_stone_bricks
schedule function blade_gallery:random/burned/part_155 1t replace
