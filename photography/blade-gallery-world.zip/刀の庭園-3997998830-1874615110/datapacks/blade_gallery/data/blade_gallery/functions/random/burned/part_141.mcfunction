execute in minecraft:overworld run fill 297 67 -6 297 68 -6 dirt
execute in minecraft:overworld run setblock 297 69 -6 grass_block
execute in minecraft:overworld run fill 297 70 -6 297 144 -6 air
execute in minecraft:overworld run fill 297 58 -5 297 66 -5 stone
execute in minecraft:overworld run fill 297 67 -5 297 68 -5 dirt
execute in minecraft:overworld run setblock 297 69 -5 grass_block
execute in minecraft:overworld run fill 297 70 -5 297 144 -5 air
execute in minecraft:overworld run fill 297 58 -4 297 66 -4 stone
execute in minecraft:overworld run fill 297 67 -4 297 68 -4 dirt
execute in minecraft:overworld run setblock 297 69 -4 grass_block
execute in minecraft:overworld run fill 297 70 -4 297 144 -4 air
execute in minecraft:overworld run fill 297 58 -3 297 67 -3 stone
execute in minecraft:overworld run fill 297 68 -3 297 69 -3 dirt
execute in minecraft:overworld run setblock 297 70 -3 coarse_dirt
execute in minecraft:overworld run fill 297 71 -3 297 144 -3 air
execute in minecraft:overworld run fill 297 58 -2 297 67 -2 stone
execute in minecraft:overworld run fill 297 68 -2 297 69 -2 dirt
execute in minecraft:overworld run setblock 297 70 -2 grass_block
execute in minecraft:overworld run fill 297 71 -2 297 144 -2 air
execute in minecraft:overworld run fill 297 58 -1 297 67 -1 stone
execute in minecraft:overworld run fill 297 68 -1 297 69 -1 dirt
execute in minecraft:overworld run setblock 297 70 -1 coarse_dirt
execute in minecraft:overworld run fill 297 71 -1 297 144 -1 air
execute in minecraft:overworld run fill 297 58 0 297 67 0 stone
execute in minecraft:overworld run fill 297 68 0 297 69 0 dirt
execute in minecraft:overworld run setblock 297 70 0 coarse_dirt
execute in minecraft:overworld run fill 297 71 0 297 144 0 air
execute in minecraft:overworld run fill 297 58 1 297 67 1 stone
execute in minecraft:overworld run fill 297 68 1 297 69 1 dirt
execute in minecraft:overworld run setblock 297 70 1 grass_block
execute in minecraft:overworld run fill 297 71 1 297 144 1 air
execute in minecraft:overworld run fill 297 58 2 297 67 2 stone
execute in minecraft:overworld run fill 297 68 2 297 69 2 dirt
execute in minecraft:overworld run setblock 297 70 2 coarse_dirt
execute in minecraft:overworld run fill 297 71 2 297 144 2 air
execute in minecraft:overworld run setblock 297 71 2 grass
execute in minecraft:overworld run fill 297 58 3 297 67 3 stone
execute in minecraft:overworld run fill 297 68 3 297 69 3 dirt
execute in minecraft:overworld run setblock 297 70 3 grass_block
execute in minecraft:overworld run fill 297 71 3 297 144 3 air
execute in minecraft:overworld run fill 297 58 4 297 66 4 stone
execute in minecraft:overworld run fill 297 67 4 297 68 4 dirt
execute in minecraft:overworld run setblock 297 69 4 grass_block
execute in minecraft:overworld run fill 297 70 4 297 144 4 air
execute in minecraft:overworld run fill 297 58 5 297 66 5 stone
execute in minecraft:overworld run fill 297 67 5 297 68 5 dirt
execute in minecraft:overworld run setblock 297 69 5 coarse_dirt
execute in minecraft:overworld run fill 297 70 5 297 144 5 air
execute in minecraft:overworld run fill 297 58 6 297 66 6 stone
execute in minecraft:overworld run fill 297 67 6 297 68 6 dirt
execute in minecraft:overworld run setblock 297 69 6 grass_block
execute in minecraft:overworld run fill 297 70 6 297 144 6 air
execute in minecraft:overworld run fill 297 58 7 297 66 7 stone
execute in minecraft:overworld run fill 297 67 7 297 68 7 dirt
execute in minecraft:overworld run setblock 297 69 7 coarse_dirt
execute in minecraft:overworld run fill 297 70 7 297 144 7 air
execute in minecraft:overworld run fill 297 58 8 297 65 8 stone
execute in minecraft:overworld run fill 297 66 8 297 67 8 dirt
execute in minecraft:overworld run setblock 297 68 8 coarse_dirt
execute in minecraft:overworld run fill 297 69 8 297 144 8 air
execute in minecraft:overworld run fill 297 58 9 297 65 9 stone
execute in minecraft:overworld run fill 297 66 9 297 67 9 dirt
execute in minecraft:overworld run setblock 297 68 9 grass_block
execute in minecraft:overworld run fill 297 69 9 297 144 9 air
execute in minecraft:overworld run fill 297 58 10 297 65 10 stone
execute in minecraft:overworld run fill 297 66 10 297 67 10 dirt
execute in minecraft:overworld run setblock 297 68 10 grass_block
execute in minecraft:overworld run fill 297 69 10 297 144 10 air
execute in minecraft:overworld run fill 297 58 11 297 65 11 stone
execute in minecraft:overworld run fill 297 66 11 297 67 11 dirt
execute in minecraft:overworld run setblock 297 68 11 coarse_dirt
execute in minecraft:overworld run fill 297 69 11 297 144 11 air
execute in minecraft:overworld run fill 297 58 12 297 65 12 stone
execute in minecraft:overworld run fill 297 66 12 297 67 12 dirt
execute in minecraft:overworld run setblock 297 68 12 grass_block
execute in minecraft:overworld run fill 297 69 12 297 144 12 air
execute in minecraft:overworld run setblock 297 69 12 grass
execute in minecraft:overworld run fill 297 58 13 297 65 13 stone
execute in minecraft:overworld run fill 297 66 13 297 67 13 dirt
execute in minecraft:overworld run setblock 297 68 13 grass_block
execute in minecraft:overworld run fill 297 69 13 297 144 13 air
execute in minecraft:overworld run fill 297 58 14 297 65 14 stone
execute in minecraft:overworld run fill 297 66 14 297 67 14 dirt
execute in minecraft:overworld run setblock 297 68 14 coarse_dirt
execute in minecraft:overworld run fill 297 69 14 297 144 14 air
execute in minecraft:overworld run fill 297 58 15 297 64 15 stone
execute in minecraft:overworld run fill 297 65 15 297 66 15 dirt
execute in minecraft:overworld run setblock 297 67 15 grass_block
execute in minecraft:overworld run fill 297 68 15 297 144 15 air
execute in minecraft:overworld run fill 297 58 16 297 64 16 stone
execute in minecraft:overworld run fill 297 65 16 297 66 16 dirt
execute in minecraft:overworld run setblock 297 67 16 grass_block
execute in minecraft:overworld run fill 297 68 16 297 144 16 air
execute in minecraft:overworld run fill 297 58 17 297 64 17 stone
execute in minecraft:overworld run fill 297 65 17 297 66 17 dirt
execute in minecraft:overworld run setblock 297 67 17 grass_block
execute in minecraft:overworld run fill 297 68 17 297 144 17 air
execute in minecraft:overworld run fill 297 58 18 297 64 18 stone
execute in minecraft:overworld run fill 297 65 18 297 66 18 dirt
execute in minecraft:overworld run setblock 297 67 18 grass_block
execute in minecraft:overworld run fill 297 68 18 297 144 18 air
execute in minecraft:overworld run fill 297 58 19 297 64 19 stone
execute in minecraft:overworld run fill 297 65 19 297 66 19 dirt
execute in minecraft:overworld run setblock 297 67 19 coarse_dirt
execute in minecraft:overworld run fill 297 68 19 297 144 19 air
execute in minecraft:overworld run fill 297 58 20 297 64 20 stone
execute in minecraft:overworld run fill 297 65 20 297 66 20 dirt
execute in minecraft:overworld run setblock 297 67 20 coarse_dirt
execute in minecraft:overworld run fill 297 68 20 297 144 20 air
execute in minecraft:overworld run fill 297 58 21 297 64 21 stone
execute in minecraft:overworld run fill 297 65 21 297 66 21 dirt
execute in minecraft:overworld run setblock 297 67 21 grass_block
execute in minecraft:overworld run fill 297 68 21 297 144 21 air
execute in minecraft:overworld run fill 297 58 22 297 64 22 stone
execute in minecraft:overworld run fill 297 65 22 297 66 22 dirt
execute in minecraft:overworld run setblock 297 67 22 grass_block
execute in minecraft:overworld run fill 297 68 22 297 144 22 air
execute in minecraft:overworld run fill 297 58 23 297 64 23 stone
execute in minecraft:overworld run fill 297 65 23 297 66 23 dirt
execute in minecraft:overworld run setblock 297 67 23 coarse_dirt
execute in minecraft:overworld run fill 297 68 23 297 144 23 air
execute in minecraft:overworld run fill 297 58 24 297 64 24 stone
execute in minecraft:overworld run fill 297 65 24 297 66 24 dirt
execute in minecraft:overworld run setblock 297 67 24 coarse_dirt
execute in minecraft:overworld run fill 297 68 24 297 144 24 air
execute in minecraft:overworld run fill 297 58 25 297 64 25 stone
execute in minecraft:overworld run fill 297 65 25 297 66 25 dirt
execute in minecraft:overworld run setblock 297 67 25 coarse_dirt
execute in minecraft:overworld run fill 297 68 25 297 144 25 air
execute in minecraft:overworld run fill 297 58 26 297 65 26 stone
execute in minecraft:overworld run fill 297 66 26 297 67 26 dirt
execute in minecraft:overworld run setblock 297 68 26 coarse_dirt
execute in minecraft:overworld run fill 297 69 26 297 144 26 air
execute in minecraft:overworld run fill 297 58 27 297 65 27 stone
execute in minecraft:overworld run fill 297 66 27 297 67 27 dirt
execute in minecraft:overworld run setblock 297 68 27 coarse_dirt
execute in minecraft:overworld run fill 297 69 27 297 144 27 air
execute in minecraft:overworld run fill 297 58 28 297 65 28 stone
execute in minecraft:overworld run fill 297 66 28 297 67 28 dirt
execute in minecraft:overworld run setblock 297 68 28 grass_block
execute in minecraft:overworld run fill 297 69 28 297 144 28 air
execute in minecraft:overworld run fill 297 58 29 297 64 29 stone
execute in minecraft:overworld run fill 297 65 29 297 66 29 dirt
execute in minecraft:overworld run setblock 297 67 29 coarse_dirt
execute in minecraft:overworld run fill 297 68 29 297 144 29 air
execute in minecraft:overworld run fill 297 58 30 297 64 30 stone
execute in minecraft:overworld run fill 297 65 30 297 66 30 dirt
execute in minecraft:overworld run setblock 297 67 30 coarse_dirt
execute in minecraft:overworld run fill 297 68 30 297 144 30 air
execute in minecraft:overworld run fill 297 58 31 297 64 31 stone
execute in minecraft:overworld run fill 297 65 31 297 66 31 dirt
execute in minecraft:overworld run setblock 297 67 31 grass_block
execute in minecraft:overworld run fill 297 68 31 297 144 31 air
execute in minecraft:overworld run fill 297 58 32 297 64 32 stone
execute in minecraft:overworld run fill 297 65 32 297 66 32 dirt
execute in minecraft:overworld run setblock 297 67 32 grass_block
execute in minecraft:overworld run fill 297 68 32 297 144 32 air
execute in minecraft:overworld run fill 297 58 33 297 64 33 stone
execute in minecraft:overworld run fill 297 65 33 297 66 33 dirt
execute in minecraft:overworld run setblock 297 67 33 coarse_dirt
execute in minecraft:overworld run fill 297 68 33 297 144 33 air
execute in minecraft:overworld run fill 297 58 34 297 64 34 stone
execute in minecraft:overworld run fill 297 65 34 297 66 34 dirt
execute in minecraft:overworld run setblock 297 67 34 coarse_dirt
execute in minecraft:overworld run fill 297 68 34 297 144 34 air
execute in minecraft:overworld run fill 297 58 35 297 64 35 stone
execute in minecraft:overworld run fill 297 65 35 297 66 35 dirt
execute in minecraft:overworld run setblock 297 67 35 coarse_dirt
execute in minecraft:overworld run fill 297 68 35 297 144 35 air
execute in minecraft:overworld run fill 297 58 36 297 64 36 stone
execute in minecraft:overworld run fill 297 65 36 297 66 36 dirt
execute in minecraft:overworld run setblock 297 67 36 coarse_dirt
execute in minecraft:overworld run fill 297 68 36 297 144 36 air
execute in minecraft:overworld run fill 297 58 37 297 64 37 stone
execute in minecraft:overworld run fill 297 65 37 297 66 37 dirt
execute in minecraft:overworld run setblock 297 67 37 coarse_dirt
execute in minecraft:overworld run fill 297 68 37 297 144 37 air
execute in minecraft:overworld run fill 297 58 38 297 64 38 stone
execute in minecraft:overworld run fill 297 65 38 297 66 38 dirt
execute in minecraft:overworld run setblock 297 67 38 coarse_dirt
execute in minecraft:overworld run fill 297 68 38 297 144 38 air
execute in minecraft:overworld run fill 297 58 39 297 63 39 stone
execute in minecraft:overworld run fill 297 64 39 297 65 39 dirt
execute in minecraft:overworld run setblock 297 66 39 coarse_dirt
execute in minecraft:overworld run fill 297 67 39 297 144 39 air
execute in minecraft:overworld run fill 297 58 40 297 63 40 stone
execute in minecraft:overworld run fill 297 64 40 297 65 40 dirt
execute in minecraft:overworld run setblock 297 66 40 coarse_dirt
execute in minecraft:overworld run fill 297 67 40 297 144 40 air
execute in minecraft:overworld run setblock 297 67 40 grass
execute in minecraft:overworld run fill 297 58 41 297 63 41 stone
execute in minecraft:overworld run fill 297 64 41 297 65 41 dirt
execute in minecraft:overworld run setblock 297 66 41 grass_block
execute in minecraft:overworld run fill 297 67 41 297 144 41 air
execute in minecraft:overworld run setblock 297 67 41 mossy_cobblestone
execute in minecraft:overworld run fill 297 58 42 297 63 42 stone
execute in minecraft:overworld run fill 297 64 42 297 65 42 dirt
execute in minecraft:overworld run setblock 297 66 42 coarse_dirt
execute in minecraft:overworld run fill 297 67 42 297 144 42 air
execute in minecraft:overworld run fill 297 58 43 297 63 43 stone
execute in minecraft:overworld run fill 297 64 43 297 65 43 dirt
execute in minecraft:overworld run setblock 297 66 43 coarse_dirt
execute in minecraft:overworld run fill 297 67 43 297 144 43 air
execute in minecraft:overworld run fill 297 58 44 297 62 44 stone
execute in minecraft:overworld run fill 297 63 44 297 64 44 dirt
execute in minecraft:overworld run setblock 297 65 44 grass_block
execute in minecraft:overworld run fill 297 66 44 297 144 44 air
execute in minecraft:overworld run fill 297 58 45 297 62 45 stone
execute in minecraft:overworld run fill 297 63 45 297 64 45 dirt
execute in minecraft:overworld run setblock 297 65 45 coarse_dirt
execute in minecraft:overworld run fill 297 66 45 297 144 45 air
execute in minecraft:overworld run fill 297 58 46 297 62 46 stone
execute in minecraft:overworld run fill 297 63 46 297 64 46 dirt
execute in minecraft:overworld run setblock 297 65 46 coarse_dirt
execute in minecraft:overworld run fill 297 66 46 297 144 46 air
execute in minecraft:overworld run fill 297 58 47 297 61 47 stone
execute in minecraft:overworld run fill 297 62 47 297 63 47 dirt
execute in minecraft:overworld run setblock 297 64 47 coarse_dirt
execute in minecraft:overworld run fill 297 65 47 297 144 47 air
execute in minecraft:overworld run fill 298 58 -48 298 61 -48 stone
execute in minecraft:overworld run fill 298 62 -48 298 63 -48 dirt
execute in minecraft:overworld run setblock 298 64 -48 coarse_dirt
execute in minecraft:overworld run fill 298 65 -48 298 144 -48 air
execute in minecraft:overworld run fill 298 58 -47 298 63 -47 stone
execute in minecraft:overworld run fill 298 64 -47 298 65 -47 dirt
execute in minecraft:overworld run setblock 298 66 -47 grass_block
execute in minecraft:overworld run fill 298 67 -47 298 144 -47 air
execute in minecraft:overworld run fill 298 58 -46 298 65 -46 stone
execute in minecraft:overworld run fill 298 66 -46 298 67 -46 dirt
execute in minecraft:overworld run setblock 298 68 -46 coarse_dirt
execute in minecraft:overworld run fill 298 69 -46 298 144 -46 air
execute in minecraft:overworld run fill 298 58 -45 298 67 -45 stone
execute in minecraft:overworld run fill 298 68 -45 298 69 -45 dirt
execute in minecraft:overworld run setblock 298 70 -45 coarse_dirt
execute in minecraft:overworld run fill 298 71 -45 298 144 -45 air
execute in minecraft:overworld run fill 298 58 -44 298 69 -44 stone
execute in minecraft:overworld run fill 298 70 -44 298 71 -44 dirt
execute in minecraft:overworld run setblock 298 72 -44 grass_block
execute in minecraft:overworld run fill 298 73 -44 298 144 -44 air
execute in minecraft:overworld run fill 298 58 -43 298 70 -43 stone
execute in minecraft:overworld run fill 298 71 -43 298 72 -43 dirt
execute in minecraft:overworld run setblock 298 73 -43 coarse_dirt
execute in minecraft:overworld run fill 298 74 -43 298 144 -43 air
execute in minecraft:overworld run fill 298 58 -42 298 72 -42 stone
execute in minecraft:overworld run fill 298 73 -42 298 74 -42 dirt
execute in minecraft:overworld run setblock 298 75 -42 grass_block
execute in minecraft:overworld run fill 298 76 -42 298 144 -42 air
execute in minecraft:overworld run fill 298 58 -41 298 72 -41 stone
execute in minecraft:overworld run fill 298 73 -41 298 74 -41 dirt
execute in minecraft:overworld run setblock 298 75 -41 coarse_dirt
execute in minecraft:overworld run fill 298 76 -41 298 144 -41 air
execute in minecraft:overworld run fill 298 58 -40 298 72 -40 stone
execute in minecraft:overworld run fill 298 73 -40 298 74 -40 dirt
execute in minecraft:overworld run setblock 298 75 -40 coarse_dirt
execute in minecraft:overworld run fill 298 76 -40 298 144 -40 air
execute in minecraft:overworld run fill 298 58 -39 298 72 -39 stone
schedule function blade_gallery:random/burned/part_142 1t replace
