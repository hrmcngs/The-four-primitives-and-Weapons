execute in minecraft:overworld run setblock 258 84 -27 gray_concrete
execute in minecraft:overworld run setblock 258 84 -26 gray_concrete
execute in minecraft:overworld run setblock 258 84 -25 cracked_stone_bricks
execute in minecraft:overworld run setblock 258 84 -24 gray_concrete
execute in minecraft:overworld run setblock 258 84 -23 gray_concrete
execute in minecraft:overworld run setblock 258 84 -22 gray_concrete
execute in minecraft:overworld run setblock 259 84 -29 gray_concrete
execute in minecraft:overworld run setblock 259 84 -27 gray_concrete
execute in minecraft:overworld run setblock 259 84 -26 gray_concrete
execute in minecraft:overworld run setblock 259 84 -25 gray_concrete
execute in minecraft:overworld run setblock 259 84 -23 gray_concrete
execute in minecraft:overworld run setblock 260 84 -29 gray_concrete
execute in minecraft:overworld run setblock 260 84 -28 gray_concrete
execute in minecraft:overworld run setblock 260 84 -27 gray_concrete
execute in minecraft:overworld run setblock 260 84 -25 gray_concrete
execute in minecraft:overworld run setblock 260 84 -24 gray_concrete
execute in minecraft:overworld run setblock 260 84 -23 gray_concrete
execute in minecraft:overworld run setblock 260 84 -22 gray_concrete
execute in minecraft:overworld run setblock 252 85 -29 gray_concrete
execute in minecraft:overworld run setblock 252 85 -28 gray_concrete
execute in minecraft:overworld run setblock 252 85 -27 gray_concrete
execute in minecraft:overworld run setblock 252 85 -26 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 85 -25 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 85 -24 gray_concrete
execute in minecraft:overworld run setblock 252 85 -23 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 85 -22 gray_concrete
execute in minecraft:overworld run setblock 253 85 -30 gray_concrete
execute in minecraft:overworld run setblock 254 85 -30 gray_concrete
execute in minecraft:overworld run setblock 254 85 -22 gray_concrete
execute in minecraft:overworld run setblock 255 85 -30 gray_concrete
execute in minecraft:overworld run setblock 255 85 -22 gray_concrete
execute in minecraft:overworld run setblock 256 85 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 256 85 -22 gray_concrete
execute in minecraft:overworld run setblock 257 85 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 257 85 -22 gray_concrete
execute in minecraft:overworld run setblock 258 85 -30 gray_concrete
execute in minecraft:overworld run setblock 258 85 -22 gray_concrete
execute in minecraft:overworld run setblock 259 85 -30 gray_concrete
execute in minecraft:overworld run setblock 259 85 -22 gray_concrete
execute in minecraft:overworld run setblock 260 85 -29 gray_concrete
execute in minecraft:overworld run setblock 260 85 -28 gray_concrete
execute in minecraft:overworld run setblock 260 85 -27 gray_concrete
execute in minecraft:overworld run setblock 260 85 -26 gray_concrete
execute in minecraft:overworld run setblock 260 85 -25 gray_concrete
execute in minecraft:overworld run setblock 260 85 -24 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 85 -23 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 86 -30 gray_concrete
execute in minecraft:overworld run setblock 252 86 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 86 -28 gray_concrete
execute in minecraft:overworld run setblock 252 86 -25 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 86 -24 gray_concrete
execute in minecraft:overworld run setblock 252 86 -23 gray_concrete
execute in minecraft:overworld run setblock 252 86 -22 gray_concrete
execute in minecraft:overworld run setblock 253 86 -30 gray_concrete
execute in minecraft:overworld run setblock 254 86 -22 gray_concrete
execute in minecraft:overworld run setblock 255 86 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 255 86 -22 gray_concrete
execute in minecraft:overworld run setblock 256 86 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 256 86 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 257 86 -30 gray_concrete
execute in minecraft:overworld run setblock 257 86 -22 gray_concrete
execute in minecraft:overworld run setblock 258 86 -30 gray_concrete
execute in minecraft:overworld run setblock 258 86 -22 gray_concrete
execute in minecraft:overworld run setblock 259 86 -30 gray_concrete
execute in minecraft:overworld run setblock 259 86 -22 gray_concrete
execute in minecraft:overworld run setblock 260 86 -30 gray_concrete
execute in minecraft:overworld run setblock 260 86 -28 gray_concrete
execute in minecraft:overworld run setblock 260 86 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 86 -25 gray_concrete
execute in minecraft:overworld run setblock 260 86 -24 gray_concrete
execute in minecraft:overworld run setblock 260 86 -23 gray_concrete
execute in minecraft:overworld run setblock 260 86 -22 gray_concrete
execute in minecraft:overworld run setblock 252 87 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 87 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 87 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 87 -27 gray_concrete
execute in minecraft:overworld run setblock 252 87 -26 gray_concrete
execute in minecraft:overworld run setblock 252 87 -25 gray_concrete
execute in minecraft:overworld run setblock 252 87 -24 gray_concrete
execute in minecraft:overworld run setblock 252 87 -22 gray_concrete
execute in minecraft:overworld run setblock 253 87 -22 gray_concrete
execute in minecraft:overworld run setblock 254 87 -22 gray_concrete
execute in minecraft:overworld run setblock 255 87 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 255 87 -22 gray_concrete
execute in minecraft:overworld run setblock 256 87 -22 gray_concrete
execute in minecraft:overworld run setblock 257 87 -30 gray_concrete
execute in minecraft:overworld run setblock 257 87 -22 gray_concrete
execute in minecraft:overworld run setblock 258 87 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 259 87 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 259 87 -22 gray_concrete
execute in minecraft:overworld run setblock 260 87 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 87 -28 gray_concrete
execute in minecraft:overworld run setblock 260 87 -26 gray_concrete
execute in minecraft:overworld run setblock 260 87 -25 gray_concrete
execute in minecraft:overworld run setblock 260 87 -24 gray_concrete
execute in minecraft:overworld run setblock 260 87 -23 gray_concrete
execute in minecraft:overworld run setblock 260 87 -22 gray_concrete
execute in minecraft:overworld run setblock 252 88 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 88 -29 gray_concrete
execute in minecraft:overworld run setblock 252 88 -28 gray_concrete
execute in minecraft:overworld run setblock 252 88 -27 gray_concrete
execute in minecraft:overworld run setblock 252 88 -26 gray_concrete
execute in minecraft:overworld run setblock 252 88 -25 gray_concrete
execute in minecraft:overworld run setblock 252 88 -24 gray_concrete
execute in minecraft:overworld run setblock 252 88 -23 gray_concrete
execute in minecraft:overworld run setblock 252 88 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 253 88 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 254 88 -30 gray_concrete
execute in minecraft:overworld run setblock 254 88 -22 gray_concrete
execute in minecraft:overworld run setblock 255 88 -30 gray_concrete
execute in minecraft:overworld run setblock 256 88 -30 gray_concrete
execute in minecraft:overworld run setblock 256 88 -22 gray_concrete
execute in minecraft:overworld run setblock 257 88 -30 gray_concrete
execute in minecraft:overworld run setblock 257 88 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 258 88 -30 gray_concrete
execute in minecraft:overworld run setblock 258 88 -22 gray_concrete
execute in minecraft:overworld run setblock 259 88 -30 gray_concrete
execute in minecraft:overworld run setblock 259 88 -22 gray_concrete
execute in minecraft:overworld run setblock 260 88 -30 gray_concrete
execute in minecraft:overworld run setblock 260 88 -29 gray_concrete
execute in minecraft:overworld run setblock 260 88 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 88 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 88 -25 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 88 -24 gray_concrete
execute in minecraft:overworld run setblock 260 88 -23 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 88 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 89 -30 gray_concrete
execute in minecraft:overworld run setblock 252 89 -29 gray_concrete
execute in minecraft:overworld run setblock 252 89 -28 gray_concrete
execute in minecraft:overworld run setblock 252 89 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 252 89 -26 gray_concrete
execute in minecraft:overworld run setblock 252 89 -25 gray_concrete
execute in minecraft:overworld run setblock 252 89 -23 gray_concrete
execute in minecraft:overworld run setblock 252 89 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 253 89 -30 gray_concrete
execute in minecraft:overworld run setblock 253 89 -29 gray_concrete
execute in minecraft:overworld run setblock 253 89 -27 gray_concrete
execute in minecraft:overworld run setblock 253 89 -26 gray_concrete
execute in minecraft:overworld run setblock 253 89 -25 cracked_stone_bricks
execute in minecraft:overworld run setblock 253 89 -24 gray_concrete
execute in minecraft:overworld run setblock 253 89 -22 gray_concrete
execute in minecraft:overworld run setblock 254 89 -29 gray_concrete
execute in minecraft:overworld run setblock 254 89 -28 gray_concrete
execute in minecraft:overworld run setblock 254 89 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 254 89 -25 gray_concrete
execute in minecraft:overworld run setblock 254 89 -24 gray_concrete
execute in minecraft:overworld run setblock 254 89 -23 gray_concrete
execute in minecraft:overworld run setblock 254 89 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 255 89 -30 gray_concrete
execute in minecraft:overworld run setblock 255 89 -29 gray_concrete
execute in minecraft:overworld run setblock 255 89 -28 gray_concrete
execute in minecraft:overworld run setblock 255 89 -27 gray_concrete
execute in minecraft:overworld run setblock 255 89 -26 gray_concrete
execute in minecraft:overworld run setblock 255 89 -24 gray_concrete
execute in minecraft:overworld run setblock 256 89 -30 gray_concrete
execute in minecraft:overworld run setblock 256 89 -29 gray_concrete
execute in minecraft:overworld run setblock 256 89 -28 gray_concrete
execute in minecraft:overworld run setblock 256 89 -26 gray_concrete
execute in minecraft:overworld run setblock 256 89 -25 gray_concrete
execute in minecraft:overworld run setblock 256 89 -24 gray_concrete
execute in minecraft:overworld run setblock 256 89 -23 gray_concrete
execute in minecraft:overworld run setblock 257 89 -28 gray_concrete
execute in minecraft:overworld run setblock 257 89 -27 gray_concrete
execute in minecraft:overworld run setblock 257 89 -25 gray_concrete
execute in minecraft:overworld run setblock 257 89 -24 gray_concrete
execute in minecraft:overworld run setblock 257 89 -23 gray_concrete
execute in minecraft:overworld run setblock 257 89 -22 gray_concrete
execute in minecraft:overworld run setblock 258 89 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 258 89 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 258 89 -27 gray_concrete
execute in minecraft:overworld run setblock 258 89 -26 gray_concrete
execute in minecraft:overworld run setblock 258 89 -24 gray_concrete
execute in minecraft:overworld run setblock 258 89 -23 gray_concrete
execute in minecraft:overworld run setblock 258 89 -22 cracked_stone_bricks
execute in minecraft:overworld run setblock 259 89 -30 gray_concrete
execute in minecraft:overworld run setblock 259 89 -29 gray_concrete
execute in minecraft:overworld run setblock 259 89 -28 gray_concrete
execute in minecraft:overworld run setblock 259 89 -25 cracked_stone_bricks
execute in minecraft:overworld run setblock 259 89 -24 cracked_stone_bricks
execute in minecraft:overworld run setblock 259 89 -23 gray_concrete
execute in minecraft:overworld run setblock 259 89 -22 gray_concrete
execute in minecraft:overworld run setblock 260 89 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 89 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 89 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 260 89 -26 gray_concrete
execute in minecraft:overworld run setblock 260 89 -25 gray_concrete
execute in minecraft:overworld run setblock 260 89 -24 gray_concrete
execute in minecraft:overworld run setblock 260 89 -23 gray_concrete
execute in minecraft:overworld run setblock 260 89 -22 gray_concrete
execute in minecraft:overworld run fill 268 79 -32 268 81 -32 stone_bricks
execute in minecraft:overworld run fill 268 79 -31 268 81 -31 stone_bricks
execute in minecraft:overworld run fill 268 78 -30 268 81 -30 stone_bricks
execute in minecraft:overworld run fill 268 78 -29 268 81 -29 stone_bricks
execute in minecraft:overworld run fill 268 78 -28 268 81 -28 stone_bricks
execute in minecraft:overworld run fill 268 77 -27 268 81 -27 stone_bricks
execute in minecraft:overworld run fill 268 77 -26 268 81 -26 stone_bricks
execute in minecraft:overworld run fill 268 76 -25 268 81 -25 stone_bricks
execute in minecraft:overworld run fill 268 76 -24 268 81 -24 stone_bricks
execute in minecraft:overworld run fill 269 79 -32 269 81 -32 stone_bricks
execute in minecraft:overworld run fill 269 79 -31 269 81 -31 stone_bricks
execute in minecraft:overworld run fill 269 78 -30 269 81 -30 stone_bricks
execute in minecraft:overworld run fill 269 78 -29 269 81 -29 stone_bricks
execute in minecraft:overworld run fill 269 77 -28 269 81 -28 stone_bricks
execute in minecraft:overworld run fill 269 77 -27 269 81 -27 stone_bricks
execute in minecraft:overworld run fill 269 77 -26 269 81 -26 stone_bricks
execute in minecraft:overworld run fill 269 76 -25 269 81 -25 stone_bricks
execute in minecraft:overworld run fill 269 76 -24 269 81 -24 stone_bricks
execute in minecraft:overworld run fill 270 79 -32 270 81 -32 stone_bricks
execute in minecraft:overworld run fill 270 79 -31 270 81 -31 stone_bricks
execute in minecraft:overworld run fill 270 78 -30 270 81 -30 stone_bricks
execute in minecraft:overworld run fill 270 78 -29 270 81 -29 stone_bricks
execute in minecraft:overworld run fill 270 77 -28 270 81 -28 stone_bricks
execute in minecraft:overworld run fill 270 77 -27 270 81 -27 stone_bricks
execute in minecraft:overworld run fill 270 77 -26 270 81 -26 stone_bricks
execute in minecraft:overworld run fill 270 76 -25 270 81 -25 stone_bricks
execute in minecraft:overworld run fill 270 76 -24 270 81 -24 stone_bricks
execute in minecraft:overworld run fill 271 79 -32 271 81 -32 stone_bricks
execute in minecraft:overworld run fill 271 79 -31 271 81 -31 stone_bricks
execute in minecraft:overworld run fill 271 78 -30 271 81 -30 stone_bricks
execute in minecraft:overworld run fill 271 78 -29 271 81 -29 stone_bricks
execute in minecraft:overworld run fill 271 77 -28 271 81 -28 stone_bricks
execute in minecraft:overworld run fill 271 77 -27 271 81 -27 stone_bricks
execute in minecraft:overworld run fill 271 77 -26 271 81 -26 stone_bricks
execute in minecraft:overworld run fill 271 76 -25 271 81 -25 stone_bricks
execute in minecraft:overworld run fill 271 76 -24 271 81 -24 stone_bricks
execute in minecraft:overworld run fill 272 79 -32 272 81 -32 stone_bricks
execute in minecraft:overworld run fill 272 79 -31 272 81 -31 stone_bricks
execute in minecraft:overworld run fill 272 78 -30 272 81 -30 stone_bricks
execute in minecraft:overworld run fill 272 78 -29 272 81 -29 stone_bricks
execute in minecraft:overworld run fill 272 78 -28 272 81 -28 stone_bricks
execute in minecraft:overworld run fill 272 77 -27 272 81 -27 stone_bricks
execute in minecraft:overworld run fill 272 77 -26 272 81 -26 stone_bricks
execute in minecraft:overworld run fill 272 76 -25 272 81 -25 stone_bricks
execute in minecraft:overworld run fill 272 76 -24 272 81 -24 stone_bricks
execute in minecraft:overworld run fill 273 79 -32 273 81 -32 stone_bricks
execute in minecraft:overworld run fill 273 79 -31 273 81 -31 stone_bricks
execute in minecraft:overworld run fill 273 78 -30 273 81 -30 stone_bricks
execute in minecraft:overworld run fill 273 78 -29 273 81 -29 stone_bricks
execute in minecraft:overworld run fill 273 78 -28 273 81 -28 stone_bricks
execute in minecraft:overworld run fill 273 77 -27 273 81 -27 stone_bricks
execute in minecraft:overworld run fill 273 77 -26 273 81 -26 stone_bricks
execute in minecraft:overworld run fill 273 77 -25 273 81 -25 stone_bricks
execute in minecraft:overworld run fill 273 76 -24 273 81 -24 stone_bricks
execute in minecraft:overworld run fill 274 79 -32 274 81 -32 stone_bricks
execute in minecraft:overworld run fill 274 79 -31 274 81 -31 stone_bricks
execute in minecraft:overworld run fill 274 79 -30 274 81 -30 stone_bricks
execute in minecraft:overworld run fill 274 78 -29 274 81 -29 stone_bricks
execute in minecraft:overworld run fill 274 78 -28 274 81 -28 stone_bricks
execute in minecraft:overworld run fill 274 78 -27 274 81 -27 stone_bricks
execute in minecraft:overworld run fill 274 77 -26 274 81 -26 stone_bricks
execute in minecraft:overworld run fill 274 77 -25 274 81 -25 stone_bricks
execute in minecraft:overworld run fill 274 77 -24 274 81 -24 stone_bricks
execute in minecraft:overworld run fill 275 79 -32 275 81 -32 stone_bricks
execute in minecraft:overworld run fill 275 79 -31 275 81 -31 stone_bricks
execute in minecraft:overworld run fill 275 79 -30 275 81 -30 stone_bricks
execute in minecraft:overworld run fill 275 78 -29 275 81 -29 stone_bricks
schedule function blade_gallery:random/burned/part_159 1t replace
