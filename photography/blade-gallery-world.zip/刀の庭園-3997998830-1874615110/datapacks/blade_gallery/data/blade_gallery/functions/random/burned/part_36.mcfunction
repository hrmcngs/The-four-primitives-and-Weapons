execute in minecraft:overworld run fill 231 66 1 231 67 1 dirt
execute in minecraft:overworld run setblock 231 68 1 coarse_dirt
execute in minecraft:overworld run fill 231 69 1 231 144 1 air
execute in minecraft:overworld run fill 231 58 2 231 65 2 stone
execute in minecraft:overworld run fill 231 66 2 231 67 2 dirt
execute in minecraft:overworld run setblock 231 68 2 coarse_dirt
execute in minecraft:overworld run fill 231 69 2 231 144 2 air
execute in minecraft:overworld run fill 231 58 3 231 66 3 stone
execute in minecraft:overworld run fill 231 67 3 231 68 3 dirt
execute in minecraft:overworld run setblock 231 69 3 coarse_dirt
execute in minecraft:overworld run fill 231 70 3 231 144 3 air
execute in minecraft:overworld run setblock 231 70 3 grass
execute in minecraft:overworld run fill 231 58 4 231 66 4 stone
execute in minecraft:overworld run fill 231 67 4 231 68 4 dirt
execute in minecraft:overworld run setblock 231 69 4 coarse_dirt
execute in minecraft:overworld run fill 231 70 4 231 144 4 air
execute in minecraft:overworld run fill 231 58 5 231 66 5 stone
execute in minecraft:overworld run fill 231 67 5 231 68 5 dirt
execute in minecraft:overworld run setblock 231 69 5 grass_block
execute in minecraft:overworld run fill 231 70 5 231 144 5 air
execute in minecraft:overworld run setblock 231 70 5 grass
execute in minecraft:overworld run fill 231 58 6 231 66 6 stone
execute in minecraft:overworld run fill 231 67 6 231 68 6 dirt
execute in minecraft:overworld run setblock 231 69 6 coarse_dirt
execute in minecraft:overworld run fill 231 70 6 231 144 6 air
execute in minecraft:overworld run fill 231 58 7 231 66 7 stone
execute in minecraft:overworld run fill 231 67 7 231 68 7 dirt
execute in minecraft:overworld run setblock 231 69 7 coarse_dirt
execute in minecraft:overworld run fill 231 70 7 231 144 7 air
execute in minecraft:overworld run fill 231 58 8 231 66 8 stone
execute in minecraft:overworld run fill 231 67 8 231 68 8 dirt
execute in minecraft:overworld run setblock 231 69 8 coarse_dirt
execute in minecraft:overworld run fill 231 70 8 231 144 8 air
execute in minecraft:overworld run fill 231 58 9 231 66 9 stone
execute in minecraft:overworld run fill 231 67 9 231 68 9 dirt
execute in minecraft:overworld run setblock 231 69 9 coarse_dirt
execute in minecraft:overworld run fill 231 70 9 231 144 9 air
execute in minecraft:overworld run fill 231 58 10 231 67 10 stone
execute in minecraft:overworld run fill 231 68 10 231 69 10 dirt
execute in minecraft:overworld run setblock 231 70 10 coarse_dirt
execute in minecraft:overworld run fill 231 71 10 231 144 10 air
execute in minecraft:overworld run fill 231 58 11 231 67 11 stone
execute in minecraft:overworld run fill 231 68 11 231 69 11 dirt
execute in minecraft:overworld run setblock 231 70 11 grass_block
execute in minecraft:overworld run fill 231 71 11 231 144 11 air
execute in minecraft:overworld run fill 231 58 12 231 67 12 stone
execute in minecraft:overworld run fill 231 68 12 231 69 12 dirt
execute in minecraft:overworld run setblock 231 70 12 coarse_dirt
execute in minecraft:overworld run fill 231 71 12 231 144 12 air
execute in minecraft:overworld run fill 231 58 13 231 67 13 stone
execute in minecraft:overworld run fill 231 68 13 231 69 13 dirt
execute in minecraft:overworld run setblock 231 70 13 coarse_dirt
execute in minecraft:overworld run fill 231 71 13 231 144 13 air
execute in minecraft:overworld run fill 231 58 14 231 68 14 stone
execute in minecraft:overworld run fill 231 69 14 231 70 14 dirt
execute in minecraft:overworld run setblock 231 71 14 coarse_dirt
execute in minecraft:overworld run fill 231 72 14 231 144 14 air
execute in minecraft:overworld run fill 231 58 15 231 68 15 stone
execute in minecraft:overworld run fill 231 69 15 231 70 15 dirt
execute in minecraft:overworld run setblock 231 71 15 coarse_dirt
execute in minecraft:overworld run fill 231 72 15 231 144 15 air
execute in minecraft:overworld run fill 231 58 16 231 68 16 stone
execute in minecraft:overworld run fill 231 69 16 231 70 16 dirt
execute in minecraft:overworld run setblock 231 71 16 coarse_dirt
execute in minecraft:overworld run fill 231 72 16 231 144 16 air
execute in minecraft:overworld run fill 231 58 17 231 69 17 stone
execute in minecraft:overworld run fill 231 70 17 231 71 17 dirt
execute in minecraft:overworld run setblock 231 72 17 coarse_dirt
execute in minecraft:overworld run fill 231 73 17 231 144 17 air
execute in minecraft:overworld run setblock 231 73 17 grass
execute in minecraft:overworld run fill 231 58 18 231 69 18 stone
execute in minecraft:overworld run fill 231 70 18 231 71 18 dirt
execute in minecraft:overworld run setblock 231 72 18 coarse_dirt
execute in minecraft:overworld run fill 231 73 18 231 144 18 air
execute in minecraft:overworld run fill 231 58 19 231 69 19 stone
execute in minecraft:overworld run fill 231 70 19 231 71 19 dirt
execute in minecraft:overworld run setblock 231 72 19 grass_block
execute in minecraft:overworld run fill 231 73 19 231 144 19 air
execute in minecraft:overworld run fill 231 58 20 231 69 20 stone
execute in minecraft:overworld run fill 231 70 20 231 71 20 dirt
execute in minecraft:overworld run setblock 231 72 20 grass_block
execute in minecraft:overworld run fill 231 73 20 231 144 20 air
execute in minecraft:overworld run fill 231 58 21 231 69 21 stone
execute in minecraft:overworld run fill 231 70 21 231 71 21 dirt
execute in minecraft:overworld run setblock 231 72 21 coarse_dirt
execute in minecraft:overworld run fill 231 73 21 231 144 21 air
execute in minecraft:overworld run fill 231 58 22 231 69 22 stone
execute in minecraft:overworld run fill 231 70 22 231 71 22 dirt
execute in minecraft:overworld run setblock 231 72 22 coarse_dirt
execute in minecraft:overworld run fill 231 73 22 231 144 22 air
execute in minecraft:overworld run setblock 231 73 22 grass
execute in minecraft:overworld run fill 231 58 23 231 69 23 stone
execute in minecraft:overworld run fill 231 70 23 231 71 23 dirt
execute in minecraft:overworld run setblock 231 72 23 coarse_dirt
execute in minecraft:overworld run fill 231 73 23 231 144 23 air
execute in minecraft:overworld run fill 231 58 24 231 69 24 stone
execute in minecraft:overworld run fill 231 70 24 231 71 24 dirt
execute in minecraft:overworld run setblock 231 72 24 coarse_dirt
execute in minecraft:overworld run fill 231 73 24 231 144 24 air
execute in minecraft:overworld run setblock 231 73 24 grass
execute in minecraft:overworld run fill 231 58 25 231 69 25 stone
execute in minecraft:overworld run fill 231 70 25 231 71 25 dirt
execute in minecraft:overworld run setblock 231 72 25 coarse_dirt
execute in minecraft:overworld run fill 231 73 25 231 144 25 air
execute in minecraft:overworld run setblock 231 73 25 grass
execute in minecraft:overworld run fill 231 58 26 231 69 26 stone
execute in minecraft:overworld run fill 231 70 26 231 71 26 dirt
execute in minecraft:overworld run setblock 231 72 26 grass_block
execute in minecraft:overworld run fill 231 73 26 231 144 26 air
execute in minecraft:overworld run fill 231 58 27 231 70 27 stone
execute in minecraft:overworld run fill 231 71 27 231 72 27 dirt
execute in minecraft:overworld run setblock 231 73 27 coarse_dirt
execute in minecraft:overworld run fill 231 74 27 231 144 27 air
execute in minecraft:overworld run fill 231 58 28 231 70 28 stone
execute in minecraft:overworld run fill 231 71 28 231 72 28 dirt
execute in minecraft:overworld run setblock 231 73 28 coarse_dirt
execute in minecraft:overworld run fill 231 74 28 231 144 28 air
execute in minecraft:overworld run fill 231 58 29 231 70 29 stone
execute in minecraft:overworld run fill 231 71 29 231 72 29 dirt
execute in minecraft:overworld run setblock 231 73 29 grass_block
execute in minecraft:overworld run fill 231 74 29 231 144 29 air
execute in minecraft:overworld run fill 231 58 30 231 70 30 stone
execute in minecraft:overworld run fill 231 71 30 231 72 30 dirt
execute in minecraft:overworld run setblock 231 73 30 coarse_dirt
execute in minecraft:overworld run fill 231 74 30 231 144 30 air
execute in minecraft:overworld run fill 231 58 31 231 70 31 stone
execute in minecraft:overworld run fill 231 71 31 231 72 31 dirt
execute in minecraft:overworld run setblock 231 73 31 grass_block
execute in minecraft:overworld run fill 231 74 31 231 144 31 air
execute in minecraft:overworld run fill 231 58 32 231 70 32 stone
execute in minecraft:overworld run fill 231 71 32 231 72 32 dirt
execute in minecraft:overworld run setblock 231 73 32 coarse_dirt
execute in minecraft:overworld run fill 231 74 32 231 144 32 air
execute in minecraft:overworld run setblock 231 74 32 grass
execute in minecraft:overworld run fill 231 58 33 231 70 33 stone
execute in minecraft:overworld run fill 231 71 33 231 72 33 dirt
execute in minecraft:overworld run setblock 231 73 33 grass_block
execute in minecraft:overworld run fill 231 74 33 231 144 33 air
execute in minecraft:overworld run fill 231 58 34 231 69 34 stone
execute in minecraft:overworld run fill 231 70 34 231 71 34 dirt
execute in minecraft:overworld run setblock 231 72 34 grass_block
execute in minecraft:overworld run fill 231 73 34 231 144 34 air
execute in minecraft:overworld run fill 231 58 35 231 69 35 stone
execute in minecraft:overworld run fill 231 70 35 231 71 35 dirt
execute in minecraft:overworld run setblock 231 72 35 coarse_dirt
execute in minecraft:overworld run fill 231 73 35 231 144 35 air
execute in minecraft:overworld run fill 231 58 36 231 69 36 stone
execute in minecraft:overworld run fill 231 70 36 231 71 36 dirt
execute in minecraft:overworld run setblock 231 72 36 coarse_dirt
execute in minecraft:overworld run fill 231 73 36 231 144 36 air
execute in minecraft:overworld run fill 231 58 37 231 68 37 stone
execute in minecraft:overworld run fill 231 69 37 231 70 37 dirt
execute in minecraft:overworld run setblock 231 71 37 grass_block
execute in minecraft:overworld run fill 231 72 37 231 144 37 air
execute in minecraft:overworld run fill 231 58 38 231 68 38 stone
execute in minecraft:overworld run fill 231 69 38 231 70 38 dirt
execute in minecraft:overworld run setblock 231 71 38 coarse_dirt
execute in minecraft:overworld run fill 231 72 38 231 144 38 air
execute in minecraft:overworld run fill 231 58 39 231 67 39 stone
execute in minecraft:overworld run fill 231 68 39 231 69 39 dirt
execute in minecraft:overworld run setblock 231 70 39 grass_block
execute in minecraft:overworld run fill 231 71 39 231 144 39 air
execute in minecraft:overworld run fill 231 58 40 231 66 40 stone
execute in minecraft:overworld run fill 231 67 40 231 68 40 dirt
execute in minecraft:overworld run setblock 231 69 40 coarse_dirt
execute in minecraft:overworld run fill 231 70 40 231 144 40 air
execute in minecraft:overworld run fill 231 58 41 231 65 41 stone
execute in minecraft:overworld run fill 231 66 41 231 67 41 dirt
execute in minecraft:overworld run setblock 231 68 41 coarse_dirt
execute in minecraft:overworld run fill 231 69 41 231 144 41 air
execute in minecraft:overworld run fill 231 58 42 231 64 42 stone
execute in minecraft:overworld run fill 231 65 42 231 66 42 dirt
execute in minecraft:overworld run setblock 231 67 42 coarse_dirt
execute in minecraft:overworld run fill 231 68 42 231 144 42 air
execute in minecraft:overworld run fill 231 58 43 231 63 43 stone
execute in minecraft:overworld run fill 231 64 43 231 65 43 dirt
execute in minecraft:overworld run setblock 231 66 43 coarse_dirt
execute in minecraft:overworld run fill 231 67 43 231 144 43 air
execute in minecraft:overworld run fill 231 58 44 231 63 44 stone
execute in minecraft:overworld run fill 231 64 44 231 65 44 dirt
execute in minecraft:overworld run setblock 231 66 44 coarse_dirt
execute in minecraft:overworld run fill 231 67 44 231 144 44 air
execute in minecraft:overworld run fill 231 58 45 231 62 45 stone
execute in minecraft:overworld run fill 231 63 45 231 64 45 dirt
execute in minecraft:overworld run setblock 231 65 45 coarse_dirt
execute in minecraft:overworld run fill 231 66 45 231 144 45 air
execute in minecraft:overworld run fill 231 58 46 231 62 46 stone
execute in minecraft:overworld run fill 231 63 46 231 64 46 dirt
execute in minecraft:overworld run setblock 231 65 46 coarse_dirt
execute in minecraft:overworld run fill 231 66 46 231 144 46 air
execute in minecraft:overworld run fill 231 58 47 231 61 47 stone
execute in minecraft:overworld run fill 231 62 47 231 63 47 dirt
execute in minecraft:overworld run setblock 231 64 47 grass_block
execute in minecraft:overworld run fill 231 65 47 231 144 47 air
execute in minecraft:overworld run fill 232 58 -48 232 61 -48 stone
execute in minecraft:overworld run fill 232 62 -48 232 63 -48 dirt
execute in minecraft:overworld run setblock 232 64 -48 coarse_dirt
execute in minecraft:overworld run fill 232 65 -48 232 144 -48 air
execute in minecraft:overworld run fill 232 58 -47 232 63 -47 stone
execute in minecraft:overworld run fill 232 64 -47 232 65 -47 dirt
execute in minecraft:overworld run setblock 232 66 -47 grass_block
execute in minecraft:overworld run fill 232 67 -47 232 144 -47 air
execute in minecraft:overworld run fill 232 58 -46 232 64 -46 stone
execute in minecraft:overworld run fill 232 65 -46 232 66 -46 dirt
execute in minecraft:overworld run setblock 232 67 -46 coarse_dirt
execute in minecraft:overworld run fill 232 68 -46 232 144 -46 air
execute in minecraft:overworld run fill 232 58 -45 232 66 -45 stone
execute in minecraft:overworld run fill 232 67 -45 232 68 -45 dirt
execute in minecraft:overworld run setblock 232 69 -45 grass_block
execute in minecraft:overworld run fill 232 70 -45 232 144 -45 air
execute in minecraft:overworld run fill 232 58 -44 232 67 -44 stone
execute in minecraft:overworld run fill 232 68 -44 232 69 -44 dirt
execute in minecraft:overworld run setblock 232 70 -44 grass_block
execute in minecraft:overworld run fill 232 71 -44 232 144 -44 air
execute in minecraft:overworld run fill 232 58 -43 232 68 -43 stone
execute in minecraft:overworld run fill 232 69 -43 232 70 -43 dirt
execute in minecraft:overworld run setblock 232 71 -43 grass_block
execute in minecraft:overworld run fill 232 72 -43 232 144 -43 air
execute in minecraft:overworld run fill 232 58 -42 232 70 -42 stone
execute in minecraft:overworld run fill 232 71 -42 232 72 -42 dirt
execute in minecraft:overworld run setblock 232 73 -42 grass_block
execute in minecraft:overworld run fill 232 74 -42 232 144 -42 air
execute in minecraft:overworld run fill 232 58 -41 232 71 -41 stone
execute in minecraft:overworld run fill 232 72 -41 232 73 -41 dirt
execute in minecraft:overworld run setblock 232 74 -41 grass_block
execute in minecraft:overworld run fill 232 75 -41 232 144 -41 air
execute in minecraft:overworld run fill 232 58 -40 232 72 -40 stone
execute in minecraft:overworld run fill 232 73 -40 232 74 -40 dirt
execute in minecraft:overworld run setblock 232 75 -40 coarse_dirt
execute in minecraft:overworld run fill 232 76 -40 232 144 -40 air
execute in minecraft:overworld run fill 232 58 -39 232 73 -39 stone
execute in minecraft:overworld run fill 232 74 -39 232 75 -39 dirt
execute in minecraft:overworld run setblock 232 76 -39 grass_block
execute in minecraft:overworld run fill 232 77 -39 232 144 -39 air
execute in minecraft:overworld run fill 232 58 -38 232 74 -38 stone
execute in minecraft:overworld run fill 232 75 -38 232 76 -38 dirt
execute in minecraft:overworld run setblock 232 77 -38 grass_block
execute in minecraft:overworld run fill 232 78 -38 232 144 -38 air
execute in minecraft:overworld run fill 232 58 -37 232 74 -37 stone
execute in minecraft:overworld run fill 232 75 -37 232 76 -37 dirt
execute in minecraft:overworld run setblock 232 77 -37 grass_block
execute in minecraft:overworld run fill 232 78 -37 232 144 -37 air
execute in minecraft:overworld run fill 232 58 -36 232 73 -36 stone
execute in minecraft:overworld run fill 232 74 -36 232 75 -36 dirt
execute in minecraft:overworld run setblock 232 76 -36 grass_block
execute in minecraft:overworld run fill 232 77 -36 232 144 -36 air
execute in minecraft:overworld run fill 232 58 -35 232 73 -35 stone
execute in minecraft:overworld run fill 232 74 -35 232 75 -35 dirt
execute in minecraft:overworld run setblock 232 76 -35 coarse_dirt
execute in minecraft:overworld run fill 232 77 -35 232 144 -35 air
execute in minecraft:overworld run fill 232 58 -34 232 72 -34 stone
execute in minecraft:overworld run fill 232 73 -34 232 74 -34 dirt
execute in minecraft:overworld run setblock 232 75 -34 coarse_dirt
execute in minecraft:overworld run fill 232 76 -34 232 144 -34 air
execute in minecraft:overworld run fill 232 58 -33 232 71 -33 stone
execute in minecraft:overworld run fill 232 72 -33 232 73 -33 dirt
schedule function blade_gallery:random/burned/part_37 1t replace
