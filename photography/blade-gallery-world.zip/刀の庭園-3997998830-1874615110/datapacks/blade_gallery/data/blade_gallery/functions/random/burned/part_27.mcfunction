execute in minecraft:overworld run fill 225 70 17 225 71 17 dirt
execute in minecraft:overworld run setblock 225 72 17 coarse_dirt
execute in minecraft:overworld run fill 225 73 17 225 144 17 air
execute in minecraft:overworld run fill 225 58 18 225 70 18 stone
execute in minecraft:overworld run fill 225 71 18 225 72 18 dirt
execute in minecraft:overworld run setblock 225 73 18 coarse_dirt
execute in minecraft:overworld run fill 225 74 18 225 144 18 air
execute in minecraft:overworld run fill 225 58 19 225 70 19 stone
execute in minecraft:overworld run fill 225 71 19 225 72 19 dirt
execute in minecraft:overworld run setblock 225 73 19 coarse_dirt
execute in minecraft:overworld run fill 225 74 19 225 144 19 air
execute in minecraft:overworld run setblock 225 74 19 grass
execute in minecraft:overworld run fill 225 58 20 225 70 20 stone
execute in minecraft:overworld run fill 225 71 20 225 72 20 dirt
execute in minecraft:overworld run setblock 225 73 20 coarse_dirt
execute in minecraft:overworld run fill 225 74 20 225 144 20 air
execute in minecraft:overworld run fill 225 58 21 225 70 21 stone
execute in minecraft:overworld run fill 225 71 21 225 72 21 dirt
execute in minecraft:overworld run setblock 225 73 21 coarse_dirt
execute in minecraft:overworld run fill 225 74 21 225 144 21 air
execute in minecraft:overworld run fill 225 58 22 225 70 22 stone
execute in minecraft:overworld run fill 225 71 22 225 72 22 dirt
execute in minecraft:overworld run setblock 225 73 22 coarse_dirt
execute in minecraft:overworld run fill 225 74 22 225 144 22 air
execute in minecraft:overworld run fill 225 58 23 225 70 23 stone
execute in minecraft:overworld run fill 225 71 23 225 72 23 dirt
execute in minecraft:overworld run setblock 225 73 23 coarse_dirt
execute in minecraft:overworld run fill 225 74 23 225 144 23 air
execute in minecraft:overworld run fill 225 58 24 225 70 24 stone
execute in minecraft:overworld run fill 225 71 24 225 72 24 dirt
execute in minecraft:overworld run setblock 225 73 24 coarse_dirt
execute in minecraft:overworld run fill 225 74 24 225 144 24 air
execute in minecraft:overworld run fill 225 58 25 225 70 25 stone
execute in minecraft:overworld run fill 225 71 25 225 72 25 dirt
execute in minecraft:overworld run setblock 225 73 25 coarse_dirt
execute in minecraft:overworld run fill 225 74 25 225 144 25 air
execute in minecraft:overworld run fill 225 58 26 225 70 26 stone
execute in minecraft:overworld run fill 225 71 26 225 72 26 dirt
execute in minecraft:overworld run setblock 225 73 26 grass_block
execute in minecraft:overworld run fill 225 74 26 225 144 26 air
execute in minecraft:overworld run fill 225 58 27 225 70 27 stone
execute in minecraft:overworld run fill 225 71 27 225 72 27 dirt
execute in minecraft:overworld run setblock 225 73 27 coarse_dirt
execute in minecraft:overworld run fill 225 74 27 225 144 27 air
execute in minecraft:overworld run setblock 225 74 27 mossy_cobblestone
execute in minecraft:overworld run fill 225 58 28 225 70 28 stone
execute in minecraft:overworld run fill 225 71 28 225 72 28 dirt
execute in minecraft:overworld run setblock 225 73 28 coarse_dirt
execute in minecraft:overworld run fill 225 74 28 225 144 28 air
execute in minecraft:overworld run fill 225 58 29 225 70 29 stone
execute in minecraft:overworld run fill 225 71 29 225 72 29 dirt
execute in minecraft:overworld run setblock 225 73 29 grass_block
execute in minecraft:overworld run fill 225 74 29 225 144 29 air
execute in minecraft:overworld run fill 225 58 30 225 70 30 stone
execute in minecraft:overworld run fill 225 71 30 225 72 30 dirt
execute in minecraft:overworld run setblock 225 73 30 grass_block
execute in minecraft:overworld run fill 225 74 30 225 144 30 air
execute in minecraft:overworld run fill 225 58 31 225 70 31 stone
execute in minecraft:overworld run fill 225 71 31 225 72 31 dirt
execute in minecraft:overworld run setblock 225 73 31 coarse_dirt
execute in minecraft:overworld run fill 225 74 31 225 144 31 air
execute in minecraft:overworld run fill 225 58 32 225 70 32 stone
execute in minecraft:overworld run fill 225 71 32 225 72 32 dirt
execute in minecraft:overworld run setblock 225 73 32 coarse_dirt
execute in minecraft:overworld run fill 225 74 32 225 144 32 air
execute in minecraft:overworld run fill 225 58 33 225 70 33 stone
execute in minecraft:overworld run fill 225 71 33 225 72 33 dirt
execute in minecraft:overworld run setblock 225 73 33 grass_block
execute in minecraft:overworld run fill 225 74 33 225 144 33 air
execute in minecraft:overworld run fill 225 58 34 225 69 34 stone
execute in minecraft:overworld run fill 225 70 34 225 71 34 dirt
execute in minecraft:overworld run setblock 225 72 34 grass_block
execute in minecraft:overworld run fill 225 73 34 225 144 34 air
execute in minecraft:overworld run fill 225 58 35 225 69 35 stone
execute in minecraft:overworld run fill 225 70 35 225 71 35 dirt
execute in minecraft:overworld run setblock 225 72 35 coarse_dirt
execute in minecraft:overworld run fill 225 73 35 225 144 35 air
execute in minecraft:overworld run fill 225 58 36 225 69 36 stone
execute in minecraft:overworld run fill 225 70 36 225 71 36 dirt
execute in minecraft:overworld run setblock 225 72 36 coarse_dirt
execute in minecraft:overworld run fill 225 73 36 225 144 36 air
execute in minecraft:overworld run fill 225 58 37 225 68 37 stone
execute in minecraft:overworld run fill 225 69 37 225 70 37 dirt
execute in minecraft:overworld run setblock 225 71 37 grass_block
execute in minecraft:overworld run fill 225 72 37 225 144 37 air
execute in minecraft:overworld run setblock 225 72 37 mossy_cobblestone
execute in minecraft:overworld run fill 225 58 38 225 68 38 stone
execute in minecraft:overworld run fill 225 69 38 225 70 38 dirt
execute in minecraft:overworld run setblock 225 71 38 grass_block
execute in minecraft:overworld run fill 225 72 38 225 144 38 air
execute in minecraft:overworld run fill 225 58 39 225 67 39 stone
execute in minecraft:overworld run fill 225 68 39 225 69 39 dirt
execute in minecraft:overworld run setblock 225 70 39 grass_block
execute in minecraft:overworld run fill 225 71 39 225 144 39 air
execute in minecraft:overworld run fill 225 58 40 225 66 40 stone
execute in minecraft:overworld run fill 225 67 40 225 68 40 dirt
execute in minecraft:overworld run setblock 225 69 40 grass_block
execute in minecraft:overworld run fill 225 70 40 225 144 40 air
execute in minecraft:overworld run fill 225 58 41 225 65 41 stone
execute in minecraft:overworld run fill 225 66 41 225 67 41 dirt
execute in minecraft:overworld run setblock 225 68 41 grass_block
execute in minecraft:overworld run fill 225 69 41 225 144 41 air
execute in minecraft:overworld run setblock 225 69 41 mossy_cobblestone
execute in minecraft:overworld run fill 225 58 42 225 64 42 stone
execute in minecraft:overworld run fill 225 65 42 225 66 42 dirt
execute in minecraft:overworld run setblock 225 67 42 grass_block
execute in minecraft:overworld run fill 225 68 42 225 144 42 air
execute in minecraft:overworld run fill 225 58 43 225 63 43 stone
execute in minecraft:overworld run fill 225 64 43 225 65 43 dirt
execute in minecraft:overworld run setblock 225 66 43 coarse_dirt
execute in minecraft:overworld run fill 225 67 43 225 144 43 air
execute in minecraft:overworld run fill 225 58 44 225 62 44 stone
execute in minecraft:overworld run fill 225 63 44 225 64 44 dirt
execute in minecraft:overworld run setblock 225 65 44 coarse_dirt
execute in minecraft:overworld run fill 225 66 44 225 144 44 air
execute in minecraft:overworld run fill 225 58 45 225 62 45 stone
execute in minecraft:overworld run fill 225 63 45 225 64 45 dirt
execute in minecraft:overworld run setblock 225 65 45 grass_block
execute in minecraft:overworld run fill 225 66 45 225 144 45 air
execute in minecraft:overworld run fill 225 58 46 225 61 46 stone
execute in minecraft:overworld run fill 225 62 46 225 63 46 dirt
execute in minecraft:overworld run setblock 225 64 46 coarse_dirt
execute in minecraft:overworld run fill 225 65 46 225 144 46 air
execute in minecraft:overworld run fill 225 58 47 225 61 47 stone
execute in minecraft:overworld run fill 225 62 47 225 63 47 dirt
execute in minecraft:overworld run setblock 225 64 47 coarse_dirt
execute in minecraft:overworld run fill 225 65 47 225 144 47 air
execute in minecraft:overworld run fill 226 58 -48 226 61 -48 stone
execute in minecraft:overworld run fill 226 62 -48 226 63 -48 dirt
execute in minecraft:overworld run setblock 226 64 -48 grass_block
execute in minecraft:overworld run fill 226 65 -48 226 144 -48 air
execute in minecraft:overworld run fill 226 58 -47 226 63 -47 stone
execute in minecraft:overworld run fill 226 64 -47 226 65 -47 dirt
execute in minecraft:overworld run setblock 226 66 -47 grass_block
execute in minecraft:overworld run fill 226 67 -47 226 144 -47 air
execute in minecraft:overworld run fill 226 58 -46 226 64 -46 stone
execute in minecraft:overworld run fill 226 65 -46 226 66 -46 dirt
execute in minecraft:overworld run setblock 226 67 -46 coarse_dirt
execute in minecraft:overworld run fill 226 68 -46 226 144 -46 air
execute in minecraft:overworld run fill 226 58 -45 226 66 -45 stone
execute in minecraft:overworld run fill 226 67 -45 226 68 -45 dirt
execute in minecraft:overworld run setblock 226 69 -45 grass_block
execute in minecraft:overworld run fill 226 70 -45 226 144 -45 air
execute in minecraft:overworld run fill 226 58 -44 226 67 -44 stone
execute in minecraft:overworld run fill 226 68 -44 226 69 -44 dirt
execute in minecraft:overworld run setblock 226 70 -44 grass_block
execute in minecraft:overworld run fill 226 71 -44 226 144 -44 air
execute in minecraft:overworld run fill 226 58 -43 226 68 -43 stone
execute in minecraft:overworld run fill 226 69 -43 226 70 -43 dirt
execute in minecraft:overworld run setblock 226 71 -43 coarse_dirt
execute in minecraft:overworld run fill 226 72 -43 226 144 -43 air
execute in minecraft:overworld run fill 226 58 -42 226 69 -42 stone
execute in minecraft:overworld run fill 226 70 -42 226 71 -42 dirt
execute in minecraft:overworld run setblock 226 72 -42 coarse_dirt
execute in minecraft:overworld run fill 226 73 -42 226 144 -42 air
execute in minecraft:overworld run fill 226 58 -41 226 70 -41 stone
execute in minecraft:overworld run fill 226 71 -41 226 72 -41 dirt
execute in minecraft:overworld run setblock 226 73 -41 coarse_dirt
execute in minecraft:overworld run fill 226 74 -41 226 144 -41 air
execute in minecraft:overworld run fill 226 58 -40 226 70 -40 stone
execute in minecraft:overworld run fill 226 71 -40 226 72 -40 dirt
execute in minecraft:overworld run setblock 226 73 -40 coarse_dirt
execute in minecraft:overworld run fill 226 74 -40 226 144 -40 air
execute in minecraft:overworld run fill 226 58 -39 226 71 -39 stone
execute in minecraft:overworld run fill 226 72 -39 226 73 -39 dirt
execute in minecraft:overworld run setblock 226 74 -39 coarse_dirt
execute in minecraft:overworld run fill 226 75 -39 226 144 -39 air
execute in minecraft:overworld run fill 226 58 -38 226 71 -38 stone
execute in minecraft:overworld run fill 226 72 -38 226 73 -38 dirt
execute in minecraft:overworld run setblock 226 74 -38 coarse_dirt
execute in minecraft:overworld run fill 226 75 -38 226 144 -38 air
execute in minecraft:overworld run fill 226 58 -37 226 70 -37 stone
execute in minecraft:overworld run fill 226 71 -37 226 72 -37 dirt
execute in minecraft:overworld run setblock 226 73 -37 coarse_dirt
execute in minecraft:overworld run fill 226 74 -37 226 144 -37 air
execute in minecraft:overworld run fill 226 58 -36 226 70 -36 stone
execute in minecraft:overworld run fill 226 71 -36 226 72 -36 dirt
execute in minecraft:overworld run setblock 226 73 -36 grass_block
execute in minecraft:overworld run fill 226 74 -36 226 144 -36 air
execute in minecraft:overworld run fill 226 58 -35 226 69 -35 stone
execute in minecraft:overworld run fill 226 70 -35 226 71 -35 dirt
execute in minecraft:overworld run setblock 226 72 -35 coarse_dirt
execute in minecraft:overworld run fill 226 73 -35 226 144 -35 air
execute in minecraft:overworld run fill 226 58 -34 226 69 -34 stone
execute in minecraft:overworld run fill 226 70 -34 226 71 -34 dirt
execute in minecraft:overworld run setblock 226 72 -34 grass_block
execute in minecraft:overworld run fill 226 73 -34 226 144 -34 air
execute in minecraft:overworld run fill 226 58 -33 226 68 -33 stone
execute in minecraft:overworld run fill 226 69 -33 226 70 -33 dirt
execute in minecraft:overworld run setblock 226 71 -33 coarse_dirt
execute in minecraft:overworld run fill 226 72 -33 226 144 -33 air
execute in minecraft:overworld run fill 226 58 -32 226 68 -32 stone
execute in minecraft:overworld run fill 226 69 -32 226 70 -32 dirt
execute in minecraft:overworld run setblock 226 71 -32 grass_block
execute in minecraft:overworld run fill 226 72 -32 226 144 -32 air
execute in minecraft:overworld run fill 226 58 -31 226 67 -31 stone
execute in minecraft:overworld run fill 226 68 -31 226 69 -31 dirt
execute in minecraft:overworld run setblock 226 70 -31 grass_block
execute in minecraft:overworld run fill 226 71 -31 226 144 -31 air
execute in minecraft:overworld run fill 226 58 -30 226 67 -30 stone
execute in minecraft:overworld run fill 226 68 -30 226 69 -30 dirt
execute in minecraft:overworld run setblock 226 70 -30 coarse_dirt
execute in minecraft:overworld run fill 226 71 -30 226 144 -30 air
execute in minecraft:overworld run fill 226 58 -29 226 67 -29 stone
execute in minecraft:overworld run fill 226 68 -29 226 69 -29 dirt
execute in minecraft:overworld run setblock 226 70 -29 coarse_dirt
execute in minecraft:overworld run fill 226 71 -29 226 144 -29 air
execute in minecraft:overworld run fill 226 58 -28 226 66 -28 stone
execute in minecraft:overworld run fill 226 67 -28 226 68 -28 dirt
execute in minecraft:overworld run setblock 226 69 -28 grass_block
execute in minecraft:overworld run fill 226 70 -28 226 144 -28 air
execute in minecraft:overworld run fill 226 58 -27 226 66 -27 stone
execute in minecraft:overworld run fill 226 67 -27 226 68 -27 dirt
execute in minecraft:overworld run setblock 226 69 -27 coarse_dirt
execute in minecraft:overworld run fill 226 70 -27 226 144 -27 air
execute in minecraft:overworld run fill 226 58 -26 226 66 -26 stone
execute in minecraft:overworld run fill 226 67 -26 226 68 -26 dirt
execute in minecraft:overworld run setblock 226 69 -26 coarse_dirt
execute in minecraft:overworld run fill 226 70 -26 226 144 -26 air
execute in minecraft:overworld run fill 226 58 -25 226 66 -25 stone
execute in minecraft:overworld run fill 226 67 -25 226 68 -25 dirt
execute in minecraft:overworld run setblock 226 69 -25 coarse_dirt
execute in minecraft:overworld run fill 226 70 -25 226 144 -25 air
execute in minecraft:overworld run fill 226 58 -24 226 66 -24 stone
execute in minecraft:overworld run fill 226 67 -24 226 68 -24 dirt
execute in minecraft:overworld run setblock 226 69 -24 coarse_dirt
execute in minecraft:overworld run fill 226 70 -24 226 144 -24 air
execute in minecraft:overworld run fill 226 58 -23 226 66 -23 stone
execute in minecraft:overworld run fill 226 67 -23 226 68 -23 dirt
execute in minecraft:overworld run setblock 226 69 -23 grass_block
execute in minecraft:overworld run fill 226 70 -23 226 144 -23 air
execute in minecraft:overworld run setblock 226 70 -23 grass
execute in minecraft:overworld run fill 226 58 -22 226 66 -22 stone
execute in minecraft:overworld run fill 226 67 -22 226 68 -22 dirt
execute in minecraft:overworld run setblock 226 69 -22 grass_block
execute in minecraft:overworld run fill 226 70 -22 226 144 -22 air
execute in minecraft:overworld run setblock 226 70 -22 grass
execute in minecraft:overworld run fill 226 58 -21 226 66 -21 stone
execute in minecraft:overworld run fill 226 67 -21 226 68 -21 dirt
execute in minecraft:overworld run setblock 226 69 -21 coarse_dirt
execute in minecraft:overworld run fill 226 70 -21 226 144 -21 air
execute in minecraft:overworld run fill 226 58 -20 226 66 -20 stone
execute in minecraft:overworld run fill 226 67 -20 226 68 -20 dirt
execute in minecraft:overworld run setblock 226 69 -20 coarse_dirt
execute in minecraft:overworld run fill 226 70 -20 226 144 -20 air
execute in minecraft:overworld run fill 226 58 -19 226 66 -19 stone
execute in minecraft:overworld run fill 226 67 -19 226 68 -19 dirt
execute in minecraft:overworld run setblock 226 69 -19 grass_block
execute in minecraft:overworld run fill 226 70 -19 226 144 -19 air
execute in minecraft:overworld run fill 226 58 -18 226 66 -18 stone
execute in minecraft:overworld run fill 226 67 -18 226 68 -18 dirt
execute in minecraft:overworld run setblock 226 69 -18 grass_block
execute in minecraft:overworld run fill 226 70 -18 226 144 -18 air
execute in minecraft:overworld run fill 226 58 -17 226 66 -17 stone
execute in minecraft:overworld run fill 226 67 -17 226 68 -17 dirt
execute in minecraft:overworld run setblock 226 69 -17 coarse_dirt
schedule function blade_gallery:random/burned/part_28 1t replace
