execute in minecraft:overworld run tp @s 374 74 22 facing 384 76 -12
