execute in minecraft:overworld run fill 269 62 31 269 64 31 water
execute in minecraft:overworld run fill 269 58 32 269 58 32 stone
execute in minecraft:overworld run fill 269 59 32 269 60 32 dirt
execute in minecraft:overworld run setblock 269 61 32 gravel
execute in minecraft:overworld run fill 269 62 32 269 144 32 air
execute in minecraft:overworld run fill 269 62 32 269 64 32 water
execute in minecraft:overworld run fill 269 58 33 269 59 33 stone
execute in minecraft:overworld run fill 269 60 33 269 61 33 dirt
execute in minecraft:overworld run setblock 269 62 33 gravel
execute in minecraft:overworld run fill 269 63 33 269 144 33 air
execute in minecraft:overworld run fill 269 63 33 269 64 33 water
execute in minecraft:overworld run fill 269 58 34 269 59 34 stone
execute in minecraft:overworld run fill 269 60 34 269 61 34 dirt
execute in minecraft:overworld run setblock 269 62 34 gravel
execute in minecraft:overworld run fill 269 63 34 269 144 34 air
execute in minecraft:overworld run fill 269 63 34 269 64 34 water
execute in minecraft:overworld run fill 269 58 35 269 59 35 stone
execute in minecraft:overworld run fill 269 60 35 269 61 35 dirt
execute in minecraft:overworld run setblock 269 62 35 gravel
execute in minecraft:overworld run fill 269 63 35 269 144 35 air
execute in minecraft:overworld run fill 269 63 35 269 64 35 water
execute in minecraft:overworld run fill 269 58 36 269 60 36 stone
execute in minecraft:overworld run fill 269 61 36 269 62 36 dirt
execute in minecraft:overworld run setblock 269 63 36 gravel
execute in minecraft:overworld run fill 269 64 36 269 144 36 air
execute in minecraft:overworld run fill 269 64 36 269 64 36 water
execute in minecraft:overworld run fill 269 58 37 269 60 37 stone
execute in minecraft:overworld run fill 269 61 37 269 62 37 dirt
execute in minecraft:overworld run setblock 269 63 37 gravel
execute in minecraft:overworld run fill 269 64 37 269 144 37 air
execute in minecraft:overworld run fill 269 64 37 269 64 37 water
execute in minecraft:overworld run fill 269 58 38 269 60 38 stone
execute in minecraft:overworld run fill 269 61 38 269 62 38 dirt
execute in minecraft:overworld run setblock 269 63 38 gravel
execute in minecraft:overworld run fill 269 64 38 269 144 38 air
execute in minecraft:overworld run fill 269 64 38 269 64 38 water
execute in minecraft:overworld run fill 269 58 39 269 60 39 stone
execute in minecraft:overworld run fill 269 61 39 269 62 39 dirt
execute in minecraft:overworld run setblock 269 63 39 gravel
execute in minecraft:overworld run fill 269 64 39 269 144 39 air
execute in minecraft:overworld run fill 269 64 39 269 64 39 water
execute in minecraft:overworld run fill 269 58 40 269 61 40 stone
execute in minecraft:overworld run fill 269 62 40 269 63 40 dirt
execute in minecraft:overworld run setblock 269 64 40 grass_block
execute in minecraft:overworld run fill 269 65 40 269 144 40 air
execute in minecraft:overworld run fill 269 58 41 269 61 41 stone
execute in minecraft:overworld run fill 269 62 41 269 63 41 dirt
execute in minecraft:overworld run setblock 269 64 41 grass_block
execute in minecraft:overworld run fill 269 65 41 269 144 41 air
execute in minecraft:overworld run fill 269 58 42 269 61 42 stone
execute in minecraft:overworld run fill 269 62 42 269 63 42 dirt
execute in minecraft:overworld run setblock 269 64 42 coarse_dirt
execute in minecraft:overworld run fill 269 65 42 269 144 42 air
execute in minecraft:overworld run fill 269 58 43 269 61 43 stone
execute in minecraft:overworld run fill 269 62 43 269 63 43 dirt
execute in minecraft:overworld run setblock 269 64 43 coarse_dirt
execute in minecraft:overworld run fill 269 65 43 269 144 43 air
execute in minecraft:overworld run fill 269 58 44 269 61 44 stone
execute in minecraft:overworld run fill 269 62 44 269 63 44 dirt
execute in minecraft:overworld run setblock 269 64 44 coarse_dirt
execute in minecraft:overworld run fill 269 65 44 269 144 44 air
execute in minecraft:overworld run fill 269 58 45 269 61 45 stone
execute in minecraft:overworld run fill 269 62 45 269 63 45 dirt
execute in minecraft:overworld run setblock 269 64 45 coarse_dirt
execute in minecraft:overworld run fill 269 65 45 269 144 45 air
execute in minecraft:overworld run fill 269 58 46 269 61 46 stone
execute in minecraft:overworld run fill 269 62 46 269 63 46 dirt
execute in minecraft:overworld run setblock 269 64 46 grass_block
execute in minecraft:overworld run fill 269 65 46 269 144 46 air
execute in minecraft:overworld run fill 269 58 47 269 61 47 stone
execute in minecraft:overworld run fill 269 62 47 269 63 47 dirt
execute in minecraft:overworld run setblock 269 64 47 coarse_dirt
execute in minecraft:overworld run fill 269 65 47 269 144 47 air
execute in minecraft:overworld run fill 270 58 -48 270 61 -48 stone
execute in minecraft:overworld run fill 270 62 -48 270 63 -48 dirt
execute in minecraft:overworld run setblock 270 64 -48 grass_block
execute in minecraft:overworld run fill 270 65 -48 270 144 -48 air
execute in minecraft:overworld run fill 270 58 -47 270 63 -47 stone
execute in minecraft:overworld run fill 270 64 -47 270 65 -47 dirt
execute in minecraft:overworld run setblock 270 66 -47 coarse_dirt
execute in minecraft:overworld run fill 270 67 -47 270 144 -47 air
execute in minecraft:overworld run fill 270 58 -46 270 65 -46 stone
execute in minecraft:overworld run fill 270 66 -46 270 67 -46 dirt
execute in minecraft:overworld run setblock 270 68 -46 coarse_dirt
execute in minecraft:overworld run fill 270 69 -46 270 144 -46 air
execute in minecraft:overworld run fill 270 58 -45 270 67 -45 stone
execute in minecraft:overworld run fill 270 68 -45 270 69 -45 dirt
execute in minecraft:overworld run setblock 270 70 -45 grass_block
execute in minecraft:overworld run fill 270 71 -45 270 144 -45 air
execute in minecraft:overworld run fill 270 58 -44 270 69 -44 stone
execute in minecraft:overworld run fill 270 70 -44 270 71 -44 dirt
execute in minecraft:overworld run setblock 270 72 -44 coarse_dirt
execute in minecraft:overworld run fill 270 73 -44 270 144 -44 air
execute in minecraft:overworld run fill 270 58 -43 270 71 -43 stone
execute in minecraft:overworld run fill 270 72 -43 270 73 -43 dirt
execute in minecraft:overworld run setblock 270 74 -43 coarse_dirt
execute in minecraft:overworld run fill 270 75 -43 270 144 -43 air
execute in minecraft:overworld run fill 270 58 -42 270 72 -42 stone
execute in minecraft:overworld run fill 270 73 -42 270 74 -42 dirt
execute in minecraft:overworld run setblock 270 75 -42 grass_block
execute in minecraft:overworld run fill 270 76 -42 270 144 -42 air
execute in minecraft:overworld run fill 270 58 -41 270 74 -41 stone
execute in minecraft:overworld run fill 270 75 -41 270 76 -41 dirt
execute in minecraft:overworld run setblock 270 77 -41 grass_block
execute in minecraft:overworld run fill 270 78 -41 270 144 -41 air
execute in minecraft:overworld run fill 270 58 -40 270 75 -40 stone
execute in minecraft:overworld run fill 270 76 -40 270 77 -40 dirt
execute in minecraft:overworld run setblock 270 78 -40 grass_block
execute in minecraft:overworld run fill 270 79 -40 270 144 -40 air
execute in minecraft:overworld run fill 270 58 -39 270 77 -39 stone
execute in minecraft:overworld run fill 270 78 -39 270 79 -39 dirt
execute in minecraft:overworld run setblock 270 80 -39 coarse_dirt
execute in minecraft:overworld run fill 270 81 -39 270 144 -39 air
execute in minecraft:overworld run fill 270 58 -38 270 78 -38 stone
execute in minecraft:overworld run fill 270 79 -38 270 80 -38 dirt
execute in minecraft:overworld run setblock 270 81 -38 coarse_dirt
execute in minecraft:overworld run fill 270 82 -38 270 144 -38 air
execute in minecraft:overworld run setblock 270 82 -38 grass
execute in minecraft:overworld run fill 270 58 -37 270 78 -37 stone
execute in minecraft:overworld run fill 270 79 -37 270 80 -37 dirt
execute in minecraft:overworld run setblock 270 81 -37 coarse_dirt
execute in minecraft:overworld run fill 270 82 -37 270 144 -37 air
execute in minecraft:overworld run fill 270 58 -36 270 77 -36 stone
execute in minecraft:overworld run fill 270 78 -36 270 79 -36 dirt
execute in minecraft:overworld run setblock 270 80 -36 coarse_dirt
execute in minecraft:overworld run fill 270 81 -36 270 144 -36 air
execute in minecraft:overworld run fill 270 58 -35 270 77 -35 stone
execute in minecraft:overworld run fill 270 78 -35 270 79 -35 dirt
execute in minecraft:overworld run setblock 270 80 -35 grass_block
execute in minecraft:overworld run fill 270 81 -35 270 144 -35 air
execute in minecraft:overworld run setblock 270 81 -35 mossy_cobblestone
execute in minecraft:overworld run fill 270 58 -34 270 77 -34 stone
execute in minecraft:overworld run fill 270 78 -34 270 79 -34 dirt
execute in minecraft:overworld run setblock 270 80 -34 coarse_dirt
execute in minecraft:overworld run fill 270 81 -34 270 144 -34 air
execute in minecraft:overworld run fill 270 58 -33 270 76 -33 stone
execute in minecraft:overworld run fill 270 77 -33 270 78 -33 dirt
execute in minecraft:overworld run setblock 270 79 -33 coarse_dirt
execute in minecraft:overworld run fill 270 80 -33 270 144 -33 air
execute in minecraft:overworld run fill 270 58 -32 270 76 -32 stone
execute in minecraft:overworld run fill 270 77 -32 270 78 -32 dirt
execute in minecraft:overworld run setblock 270 79 -32 coarse_dirt
execute in minecraft:overworld run fill 270 80 -32 270 144 -32 air
execute in minecraft:overworld run fill 270 58 -31 270 76 -31 stone
execute in minecraft:overworld run fill 270 77 -31 270 78 -31 dirt
execute in minecraft:overworld run setblock 270 79 -31 grass_block
execute in minecraft:overworld run fill 270 80 -31 270 144 -31 air
execute in minecraft:overworld run fill 270 58 -30 270 75 -30 stone
execute in minecraft:overworld run fill 270 76 -30 270 77 -30 dirt
execute in minecraft:overworld run setblock 270 78 -30 grass_block
execute in minecraft:overworld run fill 270 79 -30 270 144 -30 air
execute in minecraft:overworld run fill 270 58 -29 270 75 -29 stone
execute in minecraft:overworld run fill 270 76 -29 270 77 -29 dirt
execute in minecraft:overworld run setblock 270 78 -29 coarse_dirt
execute in minecraft:overworld run fill 270 79 -29 270 144 -29 air
execute in minecraft:overworld run setblock 270 79 -29 grass
execute in minecraft:overworld run fill 270 58 -28 270 74 -28 stone
execute in minecraft:overworld run fill 270 75 -28 270 76 -28 dirt
execute in minecraft:overworld run setblock 270 77 -28 grass_block
execute in minecraft:overworld run fill 270 78 -28 270 144 -28 air
execute in minecraft:overworld run setblock 270 78 -28 grass
execute in minecraft:overworld run fill 270 58 -27 270 74 -27 stone
execute in minecraft:overworld run fill 270 75 -27 270 76 -27 dirt
execute in minecraft:overworld run setblock 270 77 -27 grass_block
execute in minecraft:overworld run fill 270 78 -27 270 144 -27 air
execute in minecraft:overworld run fill 270 58 -26 270 74 -26 stone
execute in minecraft:overworld run fill 270 75 -26 270 76 -26 dirt
execute in minecraft:overworld run setblock 270 77 -26 coarse_dirt
execute in minecraft:overworld run fill 270 78 -26 270 144 -26 air
execute in minecraft:overworld run fill 270 58 -25 270 73 -25 stone
execute in minecraft:overworld run fill 270 74 -25 270 75 -25 dirt
execute in minecraft:overworld run setblock 270 76 -25 coarse_dirt
execute in minecraft:overworld run fill 270 77 -25 270 144 -25 air
execute in minecraft:overworld run fill 270 58 -24 270 73 -24 stone
execute in minecraft:overworld run fill 270 74 -24 270 75 -24 dirt
execute in minecraft:overworld run setblock 270 76 -24 coarse_dirt
execute in minecraft:overworld run fill 270 77 -24 270 144 -24 air
execute in minecraft:overworld run setblock 270 77 -24 grass
execute in minecraft:overworld run fill 270 58 -23 270 72 -23 stone
execute in minecraft:overworld run fill 270 73 -23 270 74 -23 dirt
execute in minecraft:overworld run setblock 270 75 -23 coarse_dirt
execute in minecraft:overworld run fill 270 76 -23 270 144 -23 air
execute in minecraft:overworld run fill 270 58 -22 270 72 -22 stone
execute in minecraft:overworld run fill 270 73 -22 270 74 -22 dirt
execute in minecraft:overworld run setblock 270 75 -22 coarse_dirt
execute in minecraft:overworld run fill 270 76 -22 270 144 -22 air
execute in minecraft:overworld run fill 270 58 -21 270 71 -21 stone
execute in minecraft:overworld run fill 270 72 -21 270 73 -21 dirt
execute in minecraft:overworld run setblock 270 74 -21 grass_block
execute in minecraft:overworld run fill 270 75 -21 270 144 -21 air
execute in minecraft:overworld run setblock 270 75 -21 grass
execute in minecraft:overworld run fill 270 58 -20 270 71 -20 stone
execute in minecraft:overworld run fill 270 72 -20 270 73 -20 dirt
execute in minecraft:overworld run setblock 270 74 -20 grass_block
execute in minecraft:overworld run fill 270 75 -20 270 144 -20 air
execute in minecraft:overworld run fill 270 58 -19 270 70 -19 stone
execute in minecraft:overworld run fill 270 71 -19 270 72 -19 dirt
execute in minecraft:overworld run setblock 270 73 -19 coarse_dirt
execute in minecraft:overworld run fill 270 74 -19 270 144 -19 air
execute in minecraft:overworld run fill 270 58 -18 270 69 -18 stone
execute in minecraft:overworld run fill 270 70 -18 270 71 -18 dirt
execute in minecraft:overworld run setblock 270 72 -18 coarse_dirt
execute in minecraft:overworld run fill 270 73 -18 270 144 -18 air
execute in minecraft:overworld run fill 270 58 -17 270 69 -17 stone
execute in minecraft:overworld run fill 270 70 -17 270 71 -17 dirt
execute in minecraft:overworld run setblock 270 72 -17 coarse_dirt
execute in minecraft:overworld run fill 270 73 -17 270 144 -17 air
execute in minecraft:overworld run fill 270 58 -16 270 68 -16 stone
execute in minecraft:overworld run fill 270 69 -16 270 70 -16 dirt
execute in minecraft:overworld run setblock 270 71 -16 grass_block
execute in minecraft:overworld run fill 270 72 -16 270 144 -16 air
execute in minecraft:overworld run fill 270 58 -15 270 67 -15 stone
execute in minecraft:overworld run fill 270 68 -15 270 69 -15 dirt
execute in minecraft:overworld run setblock 270 70 -15 coarse_dirt
execute in minecraft:overworld run fill 270 71 -15 270 144 -15 air
execute in minecraft:overworld run fill 270 58 -14 270 66 -14 stone
execute in minecraft:overworld run fill 270 67 -14 270 68 -14 dirt
execute in minecraft:overworld run setblock 270 69 -14 coarse_dirt
execute in minecraft:overworld run fill 270 70 -14 270 144 -14 air
execute in minecraft:overworld run fill 270 58 -13 270 65 -13 stone
execute in minecraft:overworld run fill 270 66 -13 270 67 -13 dirt
execute in minecraft:overworld run setblock 270 68 -13 coarse_dirt
execute in minecraft:overworld run fill 270 69 -13 270 144 -13 air
execute in minecraft:overworld run fill 270 58 -12 270 64 -12 stone
execute in minecraft:overworld run fill 270 65 -12 270 66 -12 dirt
execute in minecraft:overworld run setblock 270 67 -12 coarse_dirt
execute in minecraft:overworld run fill 270 68 -12 270 144 -12 air
execute in minecraft:overworld run fill 270 58 -11 270 64 -11 stone
execute in minecraft:overworld run fill 270 65 -11 270 66 -11 dirt
execute in minecraft:overworld run setblock 270 67 -11 coarse_dirt
execute in minecraft:overworld run fill 270 68 -11 270 144 -11 air
execute in minecraft:overworld run fill 270 58 -10 270 63 -10 stone
execute in minecraft:overworld run fill 270 64 -10 270 65 -10 dirt
execute in minecraft:overworld run setblock 270 66 -10 coarse_dirt
execute in minecraft:overworld run fill 270 67 -10 270 144 -10 air
execute in minecraft:overworld run fill 270 58 -9 270 62 -9 stone
execute in minecraft:overworld run fill 270 63 -9 270 64 -9 dirt
execute in minecraft:overworld run setblock 270 65 -9 grass_block
execute in minecraft:overworld run fill 270 66 -9 270 144 -9 air
execute in minecraft:overworld run fill 270 58 -8 270 62 -8 stone
execute in minecraft:overworld run fill 270 63 -8 270 64 -8 dirt
execute in minecraft:overworld run setblock 270 65 -8 grass_block
execute in minecraft:overworld run fill 270 66 -8 270 144 -8 air
execute in minecraft:overworld run fill 270 58 -7 270 61 -7 stone
execute in minecraft:overworld run fill 270 62 -7 270 63 -7 dirt
execute in minecraft:overworld run setblock 270 64 -7 coarse_dirt
execute in minecraft:overworld run fill 270 65 -7 270 144 -7 air
execute in minecraft:overworld run fill 270 58 -6 270 61 -6 stone
execute in minecraft:overworld run fill 270 62 -6 270 63 -6 dirt
execute in minecraft:overworld run setblock 270 64 -6 coarse_dirt
execute in minecraft:overworld run fill 270 65 -6 270 144 -6 air
execute in minecraft:overworld run fill 270 58 -5 270 60 -5 stone
execute in minecraft:overworld run fill 270 61 -5 270 62 -5 dirt
execute in minecraft:overworld run setblock 270 63 -5 gravel
execute in minecraft:overworld run fill 270 64 -5 270 144 -5 air
execute in minecraft:overworld run fill 270 64 -5 270 64 -5 water
schedule function blade_gallery:random/burned/part_99 1t replace
