schedule clear blade_gallery:random/flowers/wait
execute in minecraft:overworld run function blade_gallery:random/flowers/part_0
