execute in minecraft:overworld run setblock 222 68 -7 coarse_dirt
execute in minecraft:overworld run fill 222 69 -7 222 144 -7 air
execute in minecraft:overworld run fill 222 58 -6 222 66 -6 stone
execute in minecraft:overworld run fill 222 67 -6 222 68 -6 dirt
execute in minecraft:overworld run setblock 222 69 -6 grass_block
execute in minecraft:overworld run fill 222 70 -6 222 144 -6 air
execute in minecraft:overworld run fill 222 58 -5 222 66 -5 stone
execute in minecraft:overworld run fill 222 67 -5 222 68 -5 dirt
execute in minecraft:overworld run setblock 222 69 -5 coarse_dirt
execute in minecraft:overworld run fill 222 70 -5 222 144 -5 air
execute in minecraft:overworld run fill 222 58 -4 222 67 -4 stone
execute in minecraft:overworld run fill 222 68 -4 222 69 -4 dirt
execute in minecraft:overworld run setblock 222 70 -4 grass_block
execute in minecraft:overworld run fill 222 71 -4 222 144 -4 air
execute in minecraft:overworld run fill 222 58 -3 222 67 -3 stone
execute in minecraft:overworld run fill 222 68 -3 222 69 -3 dirt
execute in minecraft:overworld run setblock 222 70 -3 grass_block
execute in minecraft:overworld run fill 222 71 -3 222 144 -3 air
execute in minecraft:overworld run fill 222 58 -2 222 67 -2 stone
execute in minecraft:overworld run fill 222 68 -2 222 69 -2 dirt
execute in minecraft:overworld run setblock 222 70 -2 coarse_dirt
execute in minecraft:overworld run fill 222 71 -2 222 144 -2 air
execute in minecraft:overworld run fill 222 58 -1 222 68 -1 stone
execute in minecraft:overworld run fill 222 69 -1 222 70 -1 dirt
execute in minecraft:overworld run setblock 222 71 -1 coarse_dirt
execute in minecraft:overworld run fill 222 72 -1 222 144 -1 air
execute in minecraft:overworld run fill 222 58 0 222 68 0 stone
execute in minecraft:overworld run fill 222 69 0 222 70 0 dirt
execute in minecraft:overworld run setblock 222 71 0 grass_block
execute in minecraft:overworld run fill 222 72 0 222 144 0 air
execute in minecraft:overworld run setblock 222 72 0 grass
execute in minecraft:overworld run fill 222 58 1 222 68 1 stone
execute in minecraft:overworld run fill 222 69 1 222 70 1 dirt
execute in minecraft:overworld run setblock 222 71 1 coarse_dirt
execute in minecraft:overworld run fill 222 72 1 222 144 1 air
execute in minecraft:overworld run fill 222 58 2 222 67 2 stone
execute in minecraft:overworld run fill 222 68 2 222 69 2 dirt
execute in minecraft:overworld run setblock 222 70 2 coarse_dirt
execute in minecraft:overworld run fill 222 71 2 222 144 2 air
execute in minecraft:overworld run setblock 222 71 2 grass
execute in minecraft:overworld run fill 222 58 3 222 67 3 stone
execute in minecraft:overworld run fill 222 68 3 222 69 3 dirt
execute in minecraft:overworld run setblock 222 70 3 coarse_dirt
execute in minecraft:overworld run fill 222 71 3 222 144 3 air
execute in minecraft:overworld run fill 222 58 4 222 67 4 stone
execute in minecraft:overworld run fill 222 68 4 222 69 4 dirt
execute in minecraft:overworld run setblock 222 70 4 grass_block
execute in minecraft:overworld run fill 222 71 4 222 144 4 air
execute in minecraft:overworld run setblock 222 71 4 grass
execute in minecraft:overworld run fill 222 58 5 222 67 5 stone
execute in minecraft:overworld run fill 222 68 5 222 69 5 dirt
execute in minecraft:overworld run setblock 222 70 5 coarse_dirt
execute in minecraft:overworld run fill 222 71 5 222 144 5 air
execute in minecraft:overworld run setblock 222 71 5 grass
execute in minecraft:overworld run fill 222 58 6 222 67 6 stone
execute in minecraft:overworld run fill 222 68 6 222 69 6 dirt
execute in minecraft:overworld run setblock 222 70 6 grass_block
execute in minecraft:overworld run fill 222 71 6 222 144 6 air
execute in minecraft:overworld run fill 222 58 7 222 66 7 stone
execute in minecraft:overworld run fill 222 67 7 222 68 7 dirt
execute in minecraft:overworld run setblock 222 69 7 coarse_dirt
execute in minecraft:overworld run fill 222 70 7 222 144 7 air
execute in minecraft:overworld run fill 222 58 8 222 66 8 stone
execute in minecraft:overworld run fill 222 67 8 222 68 8 dirt
execute in minecraft:overworld run setblock 222 69 8 grass_block
execute in minecraft:overworld run fill 222 70 8 222 144 8 air
execute in minecraft:overworld run fill 222 58 9 222 67 9 stone
execute in minecraft:overworld run fill 222 68 9 222 69 9 dirt
execute in minecraft:overworld run setblock 222 70 9 coarse_dirt
execute in minecraft:overworld run fill 222 71 9 222 144 9 air
execute in minecraft:overworld run fill 222 58 10 222 67 10 stone
execute in minecraft:overworld run fill 222 68 10 222 69 10 dirt
execute in minecraft:overworld run setblock 222 70 10 coarse_dirt
execute in minecraft:overworld run fill 222 71 10 222 144 10 air
execute in minecraft:overworld run fill 222 58 11 222 67 11 stone
execute in minecraft:overworld run fill 222 68 11 222 69 11 dirt
execute in minecraft:overworld run setblock 222 70 11 coarse_dirt
execute in minecraft:overworld run fill 222 71 11 222 144 11 air
execute in minecraft:overworld run fill 222 58 12 222 68 12 stone
execute in minecraft:overworld run fill 222 69 12 222 70 12 dirt
execute in minecraft:overworld run setblock 222 71 12 coarse_dirt
execute in minecraft:overworld run fill 222 72 12 222 144 12 air
execute in minecraft:overworld run fill 222 58 13 222 68 13 stone
execute in minecraft:overworld run fill 222 69 13 222 70 13 dirt
execute in minecraft:overworld run setblock 222 71 13 coarse_dirt
execute in minecraft:overworld run fill 222 72 13 222 144 13 air
execute in minecraft:overworld run fill 222 58 14 222 68 14 stone
execute in minecraft:overworld run fill 222 69 14 222 70 14 dirt
execute in minecraft:overworld run setblock 222 71 14 grass_block
execute in minecraft:overworld run fill 222 72 14 222 144 14 air
execute in minecraft:overworld run fill 222 58 15 222 69 15 stone
execute in minecraft:overworld run fill 222 70 15 222 71 15 dirt
execute in minecraft:overworld run setblock 222 72 15 grass_block
execute in minecraft:overworld run fill 222 73 15 222 144 15 air
execute in minecraft:overworld run fill 222 58 16 222 69 16 stone
execute in minecraft:overworld run fill 222 70 16 222 71 16 dirt
execute in minecraft:overworld run setblock 222 72 16 coarse_dirt
execute in minecraft:overworld run fill 222 73 16 222 144 16 air
execute in minecraft:overworld run fill 222 58 17 222 70 17 stone
execute in minecraft:overworld run fill 222 71 17 222 72 17 dirt
execute in minecraft:overworld run setblock 222 73 17 grass_block
execute in minecraft:overworld run fill 222 74 17 222 144 17 air
execute in minecraft:overworld run fill 222 58 18 222 70 18 stone
execute in minecraft:overworld run fill 222 71 18 222 72 18 dirt
execute in minecraft:overworld run setblock 222 73 18 coarse_dirt
execute in minecraft:overworld run fill 222 74 18 222 144 18 air
execute in minecraft:overworld run fill 222 58 19 222 70 19 stone
execute in minecraft:overworld run fill 222 71 19 222 72 19 dirt
execute in minecraft:overworld run setblock 222 73 19 grass_block
execute in minecraft:overworld run fill 222 74 19 222 144 19 air
execute in minecraft:overworld run fill 222 58 20 222 70 20 stone
execute in minecraft:overworld run fill 222 71 20 222 72 20 dirt
execute in minecraft:overworld run setblock 222 73 20 grass_block
execute in minecraft:overworld run fill 222 74 20 222 144 20 air
execute in minecraft:overworld run fill 222 58 21 222 70 21 stone
execute in minecraft:overworld run fill 222 71 21 222 72 21 dirt
execute in minecraft:overworld run setblock 222 73 21 coarse_dirt
execute in minecraft:overworld run fill 222 74 21 222 144 21 air
execute in minecraft:overworld run fill 222 58 22 222 70 22 stone
execute in minecraft:overworld run fill 222 71 22 222 72 22 dirt
execute in minecraft:overworld run setblock 222 73 22 coarse_dirt
execute in minecraft:overworld run fill 222 74 22 222 144 22 air
execute in minecraft:overworld run fill 222 58 23 222 70 23 stone
execute in minecraft:overworld run fill 222 71 23 222 72 23 dirt
execute in minecraft:overworld run setblock 222 73 23 coarse_dirt
execute in minecraft:overworld run fill 222 74 23 222 144 23 air
execute in minecraft:overworld run fill 222 58 24 222 70 24 stone
execute in minecraft:overworld run fill 222 71 24 222 72 24 dirt
execute in minecraft:overworld run setblock 222 73 24 grass_block
execute in minecraft:overworld run fill 222 74 24 222 144 24 air
execute in minecraft:overworld run fill 222 58 25 222 70 25 stone
execute in minecraft:overworld run fill 222 71 25 222 72 25 dirt
execute in minecraft:overworld run setblock 222 73 25 coarse_dirt
execute in minecraft:overworld run fill 222 74 25 222 144 25 air
execute in minecraft:overworld run setblock 222 74 25 grass
execute in minecraft:overworld run fill 222 58 26 222 70 26 stone
execute in minecraft:overworld run fill 222 71 26 222 72 26 dirt
execute in minecraft:overworld run setblock 222 73 26 grass_block
execute in minecraft:overworld run fill 222 74 26 222 144 26 air
execute in minecraft:overworld run fill 222 58 27 222 70 27 stone
execute in minecraft:overworld run fill 222 71 27 222 72 27 dirt
execute in minecraft:overworld run setblock 222 73 27 coarse_dirt
execute in minecraft:overworld run fill 222 74 27 222 144 27 air
execute in minecraft:overworld run fill 222 58 28 222 70 28 stone
execute in minecraft:overworld run fill 222 71 28 222 72 28 dirt
execute in minecraft:overworld run setblock 222 73 28 grass_block
execute in minecraft:overworld run fill 222 74 28 222 144 28 air
execute in minecraft:overworld run fill 222 58 29 222 70 29 stone
execute in minecraft:overworld run fill 222 71 29 222 72 29 dirt
execute in minecraft:overworld run setblock 222 73 29 coarse_dirt
execute in minecraft:overworld run fill 222 74 29 222 144 29 air
execute in minecraft:overworld run setblock 222 74 29 grass
execute in minecraft:overworld run fill 222 58 30 222 70 30 stone
execute in minecraft:overworld run fill 222 71 30 222 72 30 dirt
execute in minecraft:overworld run setblock 222 73 30 coarse_dirt
execute in minecraft:overworld run fill 222 74 30 222 144 30 air
execute in minecraft:overworld run fill 222 58 31 222 70 31 stone
execute in minecraft:overworld run fill 222 71 31 222 72 31 dirt
execute in minecraft:overworld run setblock 222 73 31 coarse_dirt
execute in minecraft:overworld run fill 222 74 31 222 144 31 air
execute in minecraft:overworld run fill 222 58 32 222 70 32 stone
execute in minecraft:overworld run fill 222 71 32 222 72 32 dirt
execute in minecraft:overworld run setblock 222 73 32 grass_block
execute in minecraft:overworld run fill 222 74 32 222 144 32 air
execute in minecraft:overworld run fill 222 58 33 222 70 33 stone
execute in minecraft:overworld run fill 222 71 33 222 72 33 dirt
execute in minecraft:overworld run setblock 222 73 33 coarse_dirt
execute in minecraft:overworld run fill 222 74 33 222 144 33 air
execute in minecraft:overworld run fill 222 58 34 222 70 34 stone
execute in minecraft:overworld run fill 222 71 34 222 72 34 dirt
execute in minecraft:overworld run setblock 222 73 34 grass_block
execute in minecraft:overworld run fill 222 74 34 222 144 34 air
execute in minecraft:overworld run fill 222 58 35 222 69 35 stone
execute in minecraft:overworld run fill 222 70 35 222 71 35 dirt
execute in minecraft:overworld run setblock 222 72 35 coarse_dirt
execute in minecraft:overworld run fill 222 73 35 222 144 35 air
execute in minecraft:overworld run fill 222 58 36 222 69 36 stone
execute in minecraft:overworld run fill 222 70 36 222 71 36 dirt
execute in minecraft:overworld run setblock 222 72 36 coarse_dirt
execute in minecraft:overworld run fill 222 73 36 222 144 36 air
execute in minecraft:overworld run fill 222 58 37 222 68 37 stone
execute in minecraft:overworld run fill 222 69 37 222 70 37 dirt
execute in minecraft:overworld run setblock 222 71 37 grass_block
execute in minecraft:overworld run fill 222 72 37 222 144 37 air
execute in minecraft:overworld run fill 222 58 38 222 68 38 stone
execute in minecraft:overworld run fill 222 69 38 222 70 38 dirt
execute in minecraft:overworld run setblock 222 71 38 coarse_dirt
execute in minecraft:overworld run fill 222 72 38 222 144 38 air
execute in minecraft:overworld run setblock 222 72 38 grass
execute in minecraft:overworld run fill 222 58 39 222 67 39 stone
execute in minecraft:overworld run fill 222 68 39 222 69 39 dirt
execute in minecraft:overworld run setblock 222 70 39 grass_block
execute in minecraft:overworld run fill 222 71 39 222 144 39 air
execute in minecraft:overworld run fill 222 58 40 222 66 40 stone
execute in minecraft:overworld run fill 222 67 40 222 68 40 dirt
execute in minecraft:overworld run setblock 222 69 40 coarse_dirt
execute in minecraft:overworld run fill 222 70 40 222 144 40 air
execute in minecraft:overworld run fill 222 58 41 222 65 41 stone
execute in minecraft:overworld run fill 222 66 41 222 67 41 dirt
execute in minecraft:overworld run setblock 222 68 41 coarse_dirt
execute in minecraft:overworld run fill 222 69 41 222 144 41 air
execute in minecraft:overworld run fill 222 58 42 222 64 42 stone
execute in minecraft:overworld run fill 222 65 42 222 66 42 dirt
execute in minecraft:overworld run setblock 222 67 42 coarse_dirt
execute in minecraft:overworld run fill 222 68 42 222 144 42 air
execute in minecraft:overworld run fill 222 58 43 222 63 43 stone
execute in minecraft:overworld run fill 222 64 43 222 65 43 dirt
execute in minecraft:overworld run setblock 222 66 43 coarse_dirt
execute in minecraft:overworld run fill 222 67 43 222 144 43 air
execute in minecraft:overworld run fill 222 58 44 222 63 44 stone
execute in minecraft:overworld run fill 222 64 44 222 65 44 dirt
execute in minecraft:overworld run setblock 222 66 44 coarse_dirt
execute in minecraft:overworld run fill 222 67 44 222 144 44 air
execute in minecraft:overworld run fill 222 58 45 222 62 45 stone
execute in minecraft:overworld run fill 222 63 45 222 64 45 dirt
execute in minecraft:overworld run setblock 222 65 45 grass_block
execute in minecraft:overworld run fill 222 66 45 222 144 45 air
execute in minecraft:overworld run fill 222 58 46 222 62 46 stone
execute in minecraft:overworld run fill 222 63 46 222 64 46 dirt
execute in minecraft:overworld run setblock 222 65 46 grass_block
execute in minecraft:overworld run fill 222 66 46 222 144 46 air
execute in minecraft:overworld run fill 222 58 47 222 61 47 stone
execute in minecraft:overworld run fill 222 62 47 222 63 47 dirt
execute in minecraft:overworld run setblock 222 64 47 coarse_dirt
execute in minecraft:overworld run fill 222 65 47 222 144 47 air
execute in minecraft:overworld run fill 223 58 -48 223 61 -48 stone
execute in minecraft:overworld run fill 223 62 -48 223 63 -48 dirt
execute in minecraft:overworld run setblock 223 64 -48 coarse_dirt
execute in minecraft:overworld run fill 223 65 -48 223 144 -48 air
execute in minecraft:overworld run fill 223 58 -47 223 63 -47 stone
execute in minecraft:overworld run fill 223 64 -47 223 65 -47 dirt
execute in minecraft:overworld run setblock 223 66 -47 coarse_dirt
execute in minecraft:overworld run fill 223 67 -47 223 144 -47 air
execute in minecraft:overworld run fill 223 58 -46 223 64 -46 stone
execute in minecraft:overworld run fill 223 65 -46 223 66 -46 dirt
execute in minecraft:overworld run setblock 223 67 -46 coarse_dirt
execute in minecraft:overworld run fill 223 68 -46 223 144 -46 air
execute in minecraft:overworld run fill 223 58 -45 223 66 -45 stone
execute in minecraft:overworld run fill 223 67 -45 223 68 -45 dirt
execute in minecraft:overworld run setblock 223 69 -45 coarse_dirt
execute in minecraft:overworld run fill 223 70 -45 223 144 -45 air
execute in minecraft:overworld run fill 223 58 -44 223 67 -44 stone
execute in minecraft:overworld run fill 223 68 -44 223 69 -44 dirt
execute in minecraft:overworld run setblock 223 70 -44 grass_block
execute in minecraft:overworld run fill 223 71 -44 223 144 -44 air
execute in minecraft:overworld run fill 223 58 -43 223 68 -43 stone
execute in minecraft:overworld run fill 223 69 -43 223 70 -43 dirt
execute in minecraft:overworld run setblock 223 71 -43 grass_block
execute in minecraft:overworld run fill 223 72 -43 223 144 -43 air
execute in minecraft:overworld run fill 223 58 -42 223 69 -42 stone
execute in minecraft:overworld run fill 223 70 -42 223 71 -42 dirt
execute in minecraft:overworld run setblock 223 72 -42 coarse_dirt
execute in minecraft:overworld run fill 223 73 -42 223 144 -42 air
execute in minecraft:overworld run fill 223 58 -41 223 70 -41 stone
execute in minecraft:overworld run fill 223 71 -41 223 72 -41 dirt
execute in minecraft:overworld run setblock 223 73 -41 grass_block
schedule function blade_gallery:random/burned/part_23 1t replace
