execute in minecraft:overworld run fill 371 58 37 371 70 37 stone
execute in minecraft:overworld run fill 371 71 37 371 72 37 dirt
execute in minecraft:overworld run setblock 371 73 37 coarse_dirt
execute in minecraft:overworld run fill 371 74 37 371 144 37 air
execute in minecraft:overworld run fill 371 58 38 371 70 38 stone
execute in minecraft:overworld run fill 371 71 38 371 72 38 dirt
execute in minecraft:overworld run setblock 371 73 38 coarse_dirt
execute in minecraft:overworld run fill 371 74 38 371 144 38 air
execute in minecraft:overworld run fill 371 58 39 371 69 39 stone
execute in minecraft:overworld run fill 371 70 39 371 71 39 dirt
execute in minecraft:overworld run setblock 371 72 39 coarse_dirt
execute in minecraft:overworld run fill 371 73 39 371 144 39 air
execute in minecraft:overworld run fill 371 58 40 371 68 40 stone
execute in minecraft:overworld run fill 371 69 40 371 70 40 dirt
execute in minecraft:overworld run setblock 371 71 40 coarse_dirt
execute in minecraft:overworld run fill 371 72 40 371 144 40 air
execute in minecraft:overworld run fill 371 58 41 371 67 41 stone
execute in minecraft:overworld run fill 371 68 41 371 69 41 dirt
execute in minecraft:overworld run setblock 371 70 41 grass_block
execute in minecraft:overworld run fill 371 71 41 371 144 41 air
execute in minecraft:overworld run fill 371 58 42 371 66 42 stone
execute in minecraft:overworld run fill 371 67 42 371 68 42 dirt
execute in minecraft:overworld run setblock 371 69 42 grass_block
execute in minecraft:overworld run fill 371 70 42 371 144 42 air
execute in minecraft:overworld run fill 371 58 43 371 65 43 stone
execute in minecraft:overworld run fill 371 66 43 371 67 43 dirt
execute in minecraft:overworld run setblock 371 68 43 grass_block
execute in minecraft:overworld run fill 371 69 43 371 144 43 air
execute in minecraft:overworld run fill 371 58 44 371 65 44 stone
execute in minecraft:overworld run fill 371 66 44 371 67 44 dirt
execute in minecraft:overworld run setblock 371 68 44 coarse_dirt
execute in minecraft:overworld run fill 371 69 44 371 144 44 air
execute in minecraft:overworld run fill 371 58 45 371 64 45 stone
execute in minecraft:overworld run fill 371 65 45 371 66 45 dirt
execute in minecraft:overworld run setblock 371 67 45 coarse_dirt
execute in minecraft:overworld run fill 371 68 45 371 144 45 air
execute in minecraft:overworld run fill 371 58 46 371 63 46 stone
execute in minecraft:overworld run fill 371 64 46 371 65 46 dirt
execute in minecraft:overworld run setblock 371 66 46 coarse_dirt
execute in minecraft:overworld run fill 371 67 46 371 144 46 air
execute in minecraft:overworld run fill 371 58 47 371 62 47 stone
execute in minecraft:overworld run fill 371 63 47 371 64 47 dirt
execute in minecraft:overworld run setblock 371 65 47 grass_block
execute in minecraft:overworld run fill 371 66 47 371 144 47 air
execute in minecraft:overworld run fill 372 58 -48 372 61 -48 stone
execute in minecraft:overworld run fill 372 62 -48 372 63 -48 dirt
execute in minecraft:overworld run setblock 372 64 -48 coarse_dirt
execute in minecraft:overworld run fill 372 65 -48 372 144 -48 air
execute in minecraft:overworld run fill 372 58 -47 372 62 -47 stone
execute in minecraft:overworld run fill 372 63 -47 372 64 -47 dirt
execute in minecraft:overworld run setblock 372 65 -47 grass_block
execute in minecraft:overworld run fill 372 66 -47 372 144 -47 air
execute in minecraft:overworld run fill 372 58 -46 372 63 -46 stone
execute in minecraft:overworld run fill 372 64 -46 372 65 -46 dirt
execute in minecraft:overworld run setblock 372 66 -46 coarse_dirt
execute in minecraft:overworld run fill 372 67 -46 372 144 -46 air
execute in minecraft:overworld run fill 372 58 -45 372 64 -45 stone
execute in minecraft:overworld run fill 372 65 -45 372 66 -45 dirt
execute in minecraft:overworld run setblock 372 67 -45 grass_block
execute in minecraft:overworld run fill 372 68 -45 372 144 -45 air
execute in minecraft:overworld run fill 372 58 -44 372 64 -44 stone
execute in minecraft:overworld run fill 372 65 -44 372 66 -44 dirt
execute in minecraft:overworld run setblock 372 67 -44 grass_block
execute in minecraft:overworld run fill 372 68 -44 372 144 -44 air
execute in minecraft:overworld run fill 372 58 -43 372 65 -43 stone
execute in minecraft:overworld run fill 372 66 -43 372 67 -43 dirt
execute in minecraft:overworld run setblock 372 68 -43 grass_block
execute in minecraft:overworld run fill 372 69 -43 372 144 -43 air
execute in minecraft:overworld run fill 372 58 -42 372 66 -42 stone
execute in minecraft:overworld run fill 372 67 -42 372 68 -42 dirt
execute in minecraft:overworld run setblock 372 69 -42 coarse_dirt
execute in minecraft:overworld run fill 372 70 -42 372 144 -42 air
execute in minecraft:overworld run fill 372 58 -41 372 66 -41 stone
execute in minecraft:overworld run fill 372 67 -41 372 68 -41 dirt
execute in minecraft:overworld run setblock 372 69 -41 coarse_dirt
execute in minecraft:overworld run fill 372 70 -41 372 144 -41 air
execute in minecraft:overworld run fill 372 58 -40 372 67 -40 stone
execute in minecraft:overworld run fill 372 68 -40 372 69 -40 dirt
execute in minecraft:overworld run setblock 372 70 -40 coarse_dirt
execute in minecraft:overworld run fill 372 71 -40 372 144 -40 air
execute in minecraft:overworld run fill 372 58 -39 372 68 -39 stone
execute in minecraft:overworld run fill 372 69 -39 372 70 -39 dirt
execute in minecraft:overworld run setblock 372 71 -39 coarse_dirt
execute in minecraft:overworld run fill 372 72 -39 372 144 -39 air
execute in minecraft:overworld run fill 372 58 -38 372 68 -38 stone
execute in minecraft:overworld run fill 372 69 -38 372 70 -38 dirt
execute in minecraft:overworld run setblock 372 71 -38 grass_block
execute in minecraft:overworld run fill 372 72 -38 372 144 -38 air
execute in minecraft:overworld run fill 372 58 -37 372 68 -37 stone
execute in minecraft:overworld run fill 372 69 -37 372 70 -37 dirt
execute in minecraft:overworld run setblock 372 71 -37 coarse_dirt
execute in minecraft:overworld run fill 372 72 -37 372 144 -37 air
execute in minecraft:overworld run fill 372 58 -36 372 68 -36 stone
execute in minecraft:overworld run fill 372 69 -36 372 70 -36 dirt
execute in minecraft:overworld run setblock 372 71 -36 coarse_dirt
execute in minecraft:overworld run fill 372 72 -36 372 144 -36 air
execute in minecraft:overworld run fill 372 58 -35 372 69 -35 stone
execute in minecraft:overworld run fill 372 70 -35 372 71 -35 dirt
execute in minecraft:overworld run setblock 372 72 -35 coarse_dirt
execute in minecraft:overworld run fill 372 73 -35 372 144 -35 air
execute in minecraft:overworld run fill 372 58 -34 372 69 -34 stone
execute in minecraft:overworld run fill 372 70 -34 372 71 -34 dirt
execute in minecraft:overworld run setblock 372 72 -34 coarse_dirt
execute in minecraft:overworld run fill 372 73 -34 372 144 -34 air
execute in minecraft:overworld run fill 372 58 -33 372 69 -33 stone
execute in minecraft:overworld run fill 372 70 -33 372 71 -33 dirt
execute in minecraft:overworld run setblock 372 72 -33 grass_block
execute in minecraft:overworld run fill 372 73 -33 372 144 -33 air
execute in minecraft:overworld run fill 372 58 -32 372 69 -32 stone
execute in minecraft:overworld run fill 372 70 -32 372 71 -32 dirt
execute in minecraft:overworld run setblock 372 72 -32 coarse_dirt
execute in minecraft:overworld run fill 372 73 -32 372 144 -32 air
execute in minecraft:overworld run setblock 372 73 -32 grass
execute in minecraft:overworld run fill 372 58 -31 372 69 -31 stone
execute in minecraft:overworld run fill 372 70 -31 372 71 -31 dirt
execute in minecraft:overworld run setblock 372 72 -31 coarse_dirt
execute in minecraft:overworld run fill 372 73 -31 372 144 -31 air
execute in minecraft:overworld run setblock 372 73 -31 grass
execute in minecraft:overworld run fill 372 58 -30 372 69 -30 stone
execute in minecraft:overworld run fill 372 70 -30 372 71 -30 dirt
execute in minecraft:overworld run setblock 372 72 -30 coarse_dirt
execute in minecraft:overworld run fill 372 73 -30 372 144 -30 air
execute in minecraft:overworld run fill 372 58 -29 372 69 -29 stone
execute in minecraft:overworld run fill 372 70 -29 372 71 -29 dirt
execute in minecraft:overworld run setblock 372 72 -29 grass_block
execute in minecraft:overworld run fill 372 73 -29 372 144 -29 air
execute in minecraft:overworld run fill 372 58 -28 372 69 -28 stone
execute in minecraft:overworld run fill 372 70 -28 372 71 -28 dirt
execute in minecraft:overworld run setblock 372 72 -28 coarse_dirt
execute in minecraft:overworld run fill 372 73 -28 372 144 -28 air
execute in minecraft:overworld run fill 372 58 -27 372 69 -27 stone
execute in minecraft:overworld run fill 372 70 -27 372 71 -27 dirt
execute in minecraft:overworld run setblock 372 72 -27 coarse_dirt
execute in minecraft:overworld run fill 372 73 -27 372 144 -27 air
execute in minecraft:overworld run fill 372 58 -26 372 69 -26 stone
execute in minecraft:overworld run fill 372 70 -26 372 71 -26 dirt
execute in minecraft:overworld run setblock 372 72 -26 grass_block
execute in minecraft:overworld run fill 372 73 -26 372 144 -26 air
execute in minecraft:overworld run fill 372 58 -25 372 69 -25 stone
execute in minecraft:overworld run fill 372 70 -25 372 71 -25 dirt
execute in minecraft:overworld run setblock 372 72 -25 coarse_dirt
execute in minecraft:overworld run fill 372 73 -25 372 144 -25 air
execute in minecraft:overworld run fill 372 58 -24 372 69 -24 stone
execute in minecraft:overworld run fill 372 70 -24 372 71 -24 dirt
execute in minecraft:overworld run setblock 372 72 -24 grass_block
execute in minecraft:overworld run fill 372 73 -24 372 144 -24 air
execute in minecraft:overworld run fill 372 58 -23 372 69 -23 stone
execute in minecraft:overworld run fill 372 70 -23 372 71 -23 dirt
execute in minecraft:overworld run setblock 372 72 -23 coarse_dirt
execute in minecraft:overworld run fill 372 73 -23 372 144 -23 air
execute in minecraft:overworld run fill 372 58 -22 372 68 -22 stone
execute in minecraft:overworld run fill 372 69 -22 372 70 -22 dirt
execute in minecraft:overworld run setblock 372 71 -22 grass_block
execute in minecraft:overworld run fill 372 72 -22 372 144 -22 air
execute in minecraft:overworld run fill 372 58 -21 372 68 -21 stone
execute in minecraft:overworld run fill 372 69 -21 372 70 -21 dirt
execute in minecraft:overworld run setblock 372 71 -21 grass_block
execute in minecraft:overworld run fill 372 72 -21 372 144 -21 air
execute in minecraft:overworld run fill 372 58 -20 372 68 -20 stone
execute in minecraft:overworld run fill 372 69 -20 372 70 -20 dirt
execute in minecraft:overworld run setblock 372 71 -20 coarse_dirt
execute in minecraft:overworld run fill 372 72 -20 372 144 -20 air
execute in minecraft:overworld run fill 372 58 -19 372 67 -19 stone
execute in minecraft:overworld run fill 372 68 -19 372 69 -19 dirt
execute in minecraft:overworld run setblock 372 70 -19 coarse_dirt
execute in minecraft:overworld run fill 372 71 -19 372 144 -19 air
execute in minecraft:overworld run setblock 372 71 -19 grass
execute in minecraft:overworld run fill 372 58 -18 372 67 -18 stone
execute in minecraft:overworld run fill 372 68 -18 372 69 -18 dirt
execute in minecraft:overworld run setblock 372 70 -18 coarse_dirt
execute in minecraft:overworld run fill 372 71 -18 372 144 -18 air
execute in minecraft:overworld run fill 372 58 -17 372 67 -17 stone
execute in minecraft:overworld run fill 372 68 -17 372 69 -17 dirt
execute in minecraft:overworld run setblock 372 70 -17 coarse_dirt
execute in minecraft:overworld run fill 372 71 -17 372 144 -17 air
execute in minecraft:overworld run fill 372 58 -16 372 66 -16 stone
execute in minecraft:overworld run fill 372 67 -16 372 68 -16 dirt
execute in minecraft:overworld run setblock 372 69 -16 coarse_dirt
execute in minecraft:overworld run fill 372 70 -16 372 144 -16 air
execute in minecraft:overworld run fill 372 58 -15 372 66 -15 stone
execute in minecraft:overworld run fill 372 67 -15 372 68 -15 dirt
execute in minecraft:overworld run setblock 372 69 -15 coarse_dirt
execute in minecraft:overworld run fill 372 70 -15 372 144 -15 air
execute in minecraft:overworld run setblock 372 70 -15 grass
execute in minecraft:overworld run fill 372 58 -14 372 66 -14 stone
execute in minecraft:overworld run fill 372 67 -14 372 68 -14 dirt
execute in minecraft:overworld run setblock 372 69 -14 grass_block
execute in minecraft:overworld run fill 372 70 -14 372 144 -14 air
execute in minecraft:overworld run fill 372 58 -13 372 66 -13 stone
execute in minecraft:overworld run fill 372 67 -13 372 68 -13 dirt
execute in minecraft:overworld run setblock 372 69 -13 coarse_dirt
execute in minecraft:overworld run fill 372 70 -13 372 144 -13 air
execute in minecraft:overworld run fill 372 58 -12 372 65 -12 stone
execute in minecraft:overworld run fill 372 66 -12 372 67 -12 dirt
execute in minecraft:overworld run setblock 372 68 -12 grass_block
execute in minecraft:overworld run fill 372 69 -12 372 144 -12 air
execute in minecraft:overworld run fill 372 58 -11 372 65 -11 stone
execute in minecraft:overworld run fill 372 66 -11 372 67 -11 dirt
execute in minecraft:overworld run setblock 372 68 -11 coarse_dirt
execute in minecraft:overworld run fill 372 69 -11 372 144 -11 air
execute in minecraft:overworld run fill 372 58 -10 372 65 -10 stone
execute in minecraft:overworld run fill 372 66 -10 372 67 -10 dirt
execute in minecraft:overworld run setblock 372 68 -10 coarse_dirt
execute in minecraft:overworld run fill 372 69 -10 372 144 -10 air
execute in minecraft:overworld run fill 372 58 -9 372 65 -9 stone
execute in minecraft:overworld run fill 372 66 -9 372 67 -9 dirt
execute in minecraft:overworld run setblock 372 68 -9 coarse_dirt
execute in minecraft:overworld run fill 372 69 -9 372 144 -9 air
execute in minecraft:overworld run setblock 372 69 -9 grass
execute in minecraft:overworld run fill 372 58 -8 372 65 -8 stone
execute in minecraft:overworld run fill 372 66 -8 372 67 -8 dirt
execute in minecraft:overworld run setblock 372 68 -8 coarse_dirt
execute in minecraft:overworld run fill 372 69 -8 372 144 -8 air
execute in minecraft:overworld run fill 372 58 -7 372 65 -7 stone
execute in minecraft:overworld run fill 372 66 -7 372 67 -7 dirt
execute in minecraft:overworld run setblock 372 68 -7 grass_block
execute in minecraft:overworld run fill 372 69 -7 372 144 -7 air
execute in minecraft:overworld run fill 372 58 -6 372 65 -6 stone
execute in minecraft:overworld run fill 372 66 -6 372 67 -6 dirt
execute in minecraft:overworld run setblock 372 68 -6 coarse_dirt
execute in minecraft:overworld run fill 372 69 -6 372 144 -6 air
execute in minecraft:overworld run fill 372 58 -5 372 65 -5 stone
execute in minecraft:overworld run fill 372 66 -5 372 67 -5 dirt
execute in minecraft:overworld run setblock 372 68 -5 coarse_dirt
execute in minecraft:overworld run fill 372 69 -5 372 144 -5 air
execute in minecraft:overworld run fill 372 58 -4 372 65 -4 stone
execute in minecraft:overworld run fill 372 66 -4 372 67 -4 dirt
execute in minecraft:overworld run setblock 372 68 -4 coarse_dirt
execute in minecraft:overworld run fill 372 69 -4 372 144 -4 air
execute in minecraft:overworld run fill 372 58 -3 372 65 -3 stone
execute in minecraft:overworld run fill 372 66 -3 372 67 -3 dirt
execute in minecraft:overworld run setblock 372 68 -3 coarse_dirt
execute in minecraft:overworld run fill 372 69 -3 372 144 -3 air
execute in minecraft:overworld run fill 372 58 -2 372 65 -2 stone
execute in minecraft:overworld run fill 372 66 -2 372 67 -2 dirt
execute in minecraft:overworld run setblock 372 68 -2 coarse_dirt
execute in minecraft:overworld run fill 372 69 -2 372 144 -2 air
execute in minecraft:overworld run fill 372 58 -1 372 65 -1 stone
execute in minecraft:overworld run fill 372 66 -1 372 67 -1 dirt
execute in minecraft:overworld run setblock 372 68 -1 grass_block
execute in minecraft:overworld run fill 372 69 -1 372 144 -1 air
execute in minecraft:overworld run fill 372 58 0 372 65 0 stone
execute in minecraft:overworld run fill 372 66 0 372 67 0 dirt
execute in minecraft:overworld run setblock 372 68 0 coarse_dirt
execute in minecraft:overworld run fill 372 69 0 372 144 0 air
execute in minecraft:overworld run fill 372 58 1 372 65 1 stone
execute in minecraft:overworld run fill 372 66 1 372 67 1 dirt
execute in minecraft:overworld run setblock 372 68 1 grass_block
execute in minecraft:overworld run fill 372 69 1 372 144 1 air
execute in minecraft:overworld run fill 372 58 2 372 65 2 stone
execute in minecraft:overworld run fill 372 66 2 372 67 2 dirt
execute in minecraft:overworld run setblock 372 68 2 grass_block
execute in minecraft:overworld run fill 372 69 2 372 144 2 air
execute in minecraft:overworld run fill 372 58 3 372 65 3 stone
execute in minecraft:overworld run fill 372 66 3 372 67 3 dirt
execute in minecraft:overworld run setblock 372 68 3 coarse_dirt
schedule function blade_gallery:random/battlefield/part_56 1t replace
