execute in minecraft:overworld run fill 407 74 -42 407 144 -42 air
execute in minecraft:overworld run fill 407 58 -41 407 72 -41 stone
execute in minecraft:overworld run fill 407 73 -41 407 74 -41 dirt
execute in minecraft:overworld run setblock 407 75 -41 grass_block
execute in minecraft:overworld run fill 407 76 -41 407 144 -41 air
execute in minecraft:overworld run fill 407 58 -40 407 73 -40 stone
execute in minecraft:overworld run fill 407 74 -40 407 75 -40 dirt
execute in minecraft:overworld run setblock 407 76 -40 coarse_dirt
execute in minecraft:overworld run fill 407 77 -40 407 144 -40 air
execute in minecraft:overworld run fill 407 58 -39 407 74 -39 stone
execute in minecraft:overworld run fill 407 75 -39 407 76 -39 dirt
execute in minecraft:overworld run setblock 407 77 -39 coarse_dirt
execute in minecraft:overworld run fill 407 78 -39 407 144 -39 air
execute in minecraft:overworld run fill 407 58 -38 407 76 -38 stone
execute in minecraft:overworld run fill 407 77 -38 407 78 -38 dirt
execute in minecraft:overworld run setblock 407 79 -38 grass_block
execute in minecraft:overworld run fill 407 80 -38 407 144 -38 air
execute in minecraft:overworld run fill 407 58 -37 407 75 -37 stone
execute in minecraft:overworld run fill 407 76 -37 407 77 -37 dirt
execute in minecraft:overworld run setblock 407 78 -37 coarse_dirt
execute in minecraft:overworld run fill 407 79 -37 407 144 -37 air
execute in minecraft:overworld run setblock 407 79 -37 grass
execute in minecraft:overworld run fill 407 58 -36 407 75 -36 stone
execute in minecraft:overworld run fill 407 76 -36 407 77 -36 dirt
execute in minecraft:overworld run setblock 407 78 -36 coarse_dirt
execute in minecraft:overworld run fill 407 79 -36 407 144 -36 air
execute in minecraft:overworld run setblock 407 79 -36 grass
execute in minecraft:overworld run fill 407 58 -35 407 75 -35 stone
execute in minecraft:overworld run fill 407 76 -35 407 77 -35 dirt
execute in minecraft:overworld run setblock 407 78 -35 grass_block
execute in minecraft:overworld run fill 407 79 -35 407 144 -35 air
execute in minecraft:overworld run fill 407 58 -34 407 74 -34 stone
execute in minecraft:overworld run fill 407 75 -34 407 76 -34 dirt
execute in minecraft:overworld run setblock 407 77 -34 coarse_dirt
execute in minecraft:overworld run fill 407 78 -34 407 144 -34 air
execute in minecraft:overworld run fill 407 58 -33 407 74 -33 stone
execute in minecraft:overworld run fill 407 75 -33 407 76 -33 dirt
execute in minecraft:overworld run setblock 407 77 -33 grass_block
execute in minecraft:overworld run fill 407 78 -33 407 144 -33 air
execute in minecraft:overworld run fill 407 58 -32 407 74 -32 stone
execute in minecraft:overworld run fill 407 75 -32 407 76 -32 dirt
execute in minecraft:overworld run setblock 407 77 -32 coarse_dirt
execute in minecraft:overworld run fill 407 78 -32 407 144 -32 air
execute in minecraft:overworld run fill 407 58 -31 407 73 -31 stone
execute in minecraft:overworld run fill 407 74 -31 407 75 -31 dirt
execute in minecraft:overworld run setblock 407 76 -31 coarse_dirt
execute in minecraft:overworld run fill 407 77 -31 407 144 -31 air
execute in minecraft:overworld run fill 407 58 -30 407 73 -30 stone
execute in minecraft:overworld run fill 407 74 -30 407 75 -30 dirt
execute in minecraft:overworld run setblock 407 76 -30 coarse_dirt
execute in minecraft:overworld run fill 407 77 -30 407 144 -30 air
execute in minecraft:overworld run fill 407 58 -29 407 72 -29 stone
execute in minecraft:overworld run fill 407 73 -29 407 74 -29 dirt
execute in minecraft:overworld run setblock 407 75 -29 grass_block
execute in minecraft:overworld run fill 407 76 -29 407 144 -29 air
execute in minecraft:overworld run fill 407 58 -28 407 72 -28 stone
execute in minecraft:overworld run fill 407 73 -28 407 74 -28 dirt
execute in minecraft:overworld run setblock 407 75 -28 grass_block
execute in minecraft:overworld run fill 407 76 -28 407 144 -28 air
execute in minecraft:overworld run fill 407 58 -27 407 72 -27 stone
execute in minecraft:overworld run fill 407 73 -27 407 74 -27 dirt
execute in minecraft:overworld run setblock 407 75 -27 coarse_dirt
execute in minecraft:overworld run fill 407 76 -27 407 144 -27 air
execute in minecraft:overworld run fill 407 58 -26 407 71 -26 stone
execute in minecraft:overworld run fill 407 72 -26 407 73 -26 dirt
execute in minecraft:overworld run setblock 407 74 -26 coarse_dirt
execute in minecraft:overworld run fill 407 75 -26 407 144 -26 air
execute in minecraft:overworld run fill 407 58 -25 407 71 -25 stone
execute in minecraft:overworld run fill 407 72 -25 407 73 -25 dirt
execute in minecraft:overworld run setblock 407 74 -25 grass_block
execute in minecraft:overworld run fill 407 75 -25 407 144 -25 air
execute in minecraft:overworld run fill 407 58 -24 407 71 -24 stone
execute in minecraft:overworld run fill 407 72 -24 407 73 -24 dirt
execute in minecraft:overworld run setblock 407 74 -24 coarse_dirt
execute in minecraft:overworld run fill 407 75 -24 407 144 -24 air
execute in minecraft:overworld run fill 407 58 -23 407 70 -23 stone
execute in minecraft:overworld run fill 407 71 -23 407 72 -23 dirt
execute in minecraft:overworld run setblock 407 73 -23 grass_block
execute in minecraft:overworld run fill 407 74 -23 407 144 -23 air
execute in minecraft:overworld run fill 407 58 -22 407 70 -22 stone
execute in minecraft:overworld run fill 407 71 -22 407 72 -22 dirt
execute in minecraft:overworld run setblock 407 73 -22 grass_block
execute in minecraft:overworld run fill 407 74 -22 407 144 -22 air
execute in minecraft:overworld run fill 407 58 -21 407 70 -21 stone
execute in minecraft:overworld run fill 407 71 -21 407 72 -21 dirt
execute in minecraft:overworld run setblock 407 73 -21 grass_block
execute in minecraft:overworld run fill 407 74 -21 407 144 -21 air
execute in minecraft:overworld run fill 407 58 -20 407 69 -20 stone
execute in minecraft:overworld run fill 407 70 -20 407 71 -20 dirt
execute in minecraft:overworld run setblock 407 72 -20 coarse_dirt
execute in minecraft:overworld run fill 407 73 -20 407 144 -20 air
execute in minecraft:overworld run fill 407 58 -19 407 69 -19 stone
execute in minecraft:overworld run fill 407 70 -19 407 71 -19 dirt
execute in minecraft:overworld run setblock 407 72 -19 coarse_dirt
execute in minecraft:overworld run fill 407 73 -19 407 144 -19 air
execute in minecraft:overworld run fill 407 58 -18 407 69 -18 stone
execute in minecraft:overworld run fill 407 70 -18 407 71 -18 dirt
execute in minecraft:overworld run setblock 407 72 -18 grass_block
execute in minecraft:overworld run fill 407 73 -18 407 144 -18 air
execute in minecraft:overworld run fill 407 58 -17 407 68 -17 stone
execute in minecraft:overworld run fill 407 69 -17 407 70 -17 dirt
execute in minecraft:overworld run setblock 407 71 -17 coarse_dirt
execute in minecraft:overworld run fill 407 72 -17 407 144 -17 air
execute in minecraft:overworld run fill 407 58 -16 407 67 -16 stone
execute in minecraft:overworld run fill 407 68 -16 407 69 -16 dirt
execute in minecraft:overworld run setblock 407 70 -16 coarse_dirt
execute in minecraft:overworld run fill 407 71 -16 407 144 -16 air
execute in minecraft:overworld run fill 407 58 -15 407 67 -15 stone
execute in minecraft:overworld run fill 407 68 -15 407 69 -15 dirt
execute in minecraft:overworld run setblock 407 70 -15 coarse_dirt
execute in minecraft:overworld run fill 407 71 -15 407 144 -15 air
execute in minecraft:overworld run fill 407 58 -14 407 66 -14 stone
execute in minecraft:overworld run fill 407 67 -14 407 68 -14 dirt
execute in minecraft:overworld run setblock 407 69 -14 grass_block
execute in minecraft:overworld run fill 407 70 -14 407 144 -14 air
execute in minecraft:overworld run fill 407 58 -13 407 65 -13 stone
execute in minecraft:overworld run fill 407 66 -13 407 67 -13 dirt
execute in minecraft:overworld run setblock 407 68 -13 grass_block
execute in minecraft:overworld run fill 407 69 -13 407 144 -13 air
execute in minecraft:overworld run fill 407 58 -12 407 64 -12 stone
execute in minecraft:overworld run fill 407 65 -12 407 66 -12 dirt
execute in minecraft:overworld run setblock 407 67 -12 coarse_dirt
execute in minecraft:overworld run fill 407 68 -12 407 144 -12 air
execute in minecraft:overworld run fill 407 58 -11 407 64 -11 stone
execute in minecraft:overworld run fill 407 65 -11 407 66 -11 dirt
execute in minecraft:overworld run setblock 407 67 -11 coarse_dirt
execute in minecraft:overworld run fill 407 68 -11 407 144 -11 air
execute in minecraft:overworld run fill 407 58 -10 407 63 -10 stone
execute in minecraft:overworld run fill 407 64 -10 407 65 -10 dirt
execute in minecraft:overworld run setblock 407 66 -10 coarse_dirt
execute in minecraft:overworld run fill 407 67 -10 407 144 -10 air
execute in minecraft:overworld run fill 407 58 -9 407 63 -9 stone
execute in minecraft:overworld run fill 407 64 -9 407 65 -9 dirt
execute in minecraft:overworld run setblock 407 66 -9 coarse_dirt
execute in minecraft:overworld run fill 407 67 -9 407 144 -9 air
execute in minecraft:overworld run fill 407 58 -8 407 63 -8 stone
execute in minecraft:overworld run fill 407 64 -8 407 65 -8 dirt
execute in minecraft:overworld run setblock 407 66 -8 grass_block
execute in minecraft:overworld run fill 407 67 -8 407 144 -8 air
execute in minecraft:overworld run fill 407 58 -7 407 63 -7 stone
execute in minecraft:overworld run fill 407 64 -7 407 65 -7 dirt
execute in minecraft:overworld run setblock 407 66 -7 grass_block
execute in minecraft:overworld run fill 407 67 -7 407 144 -7 air
execute in minecraft:overworld run fill 407 58 -6 407 63 -6 stone
execute in minecraft:overworld run fill 407 64 -6 407 65 -6 dirt
execute in minecraft:overworld run setblock 407 66 -6 coarse_dirt
execute in minecraft:overworld run fill 407 67 -6 407 144 -6 air
execute in minecraft:overworld run fill 407 58 -5 407 62 -5 stone
execute in minecraft:overworld run fill 407 63 -5 407 64 -5 dirt
execute in minecraft:overworld run setblock 407 65 -5 coarse_dirt
execute in minecraft:overworld run fill 407 66 -5 407 144 -5 air
execute in minecraft:overworld run setblock 407 66 -5 mossy_cobblestone
execute in minecraft:overworld run fill 407 58 -4 407 62 -4 stone
execute in minecraft:overworld run fill 407 63 -4 407 64 -4 dirt
execute in minecraft:overworld run setblock 407 65 -4 coarse_dirt
execute in minecraft:overworld run fill 407 66 -4 407 144 -4 air
execute in minecraft:overworld run fill 407 58 -3 407 62 -3 stone
execute in minecraft:overworld run fill 407 63 -3 407 64 -3 dirt
execute in minecraft:overworld run setblock 407 65 -3 grass_block
execute in minecraft:overworld run fill 407 66 -3 407 144 -3 air
execute in minecraft:overworld run setblock 407 66 -3 grass
execute in minecraft:overworld run fill 407 58 -2 407 62 -2 stone
execute in minecraft:overworld run fill 407 63 -2 407 64 -2 dirt
execute in minecraft:overworld run setblock 407 65 -2 coarse_dirt
execute in minecraft:overworld run fill 407 66 -2 407 144 -2 air
execute in minecraft:overworld run fill 407 58 -1 407 62 -1 stone
execute in minecraft:overworld run fill 407 63 -1 407 64 -1 dirt
execute in minecraft:overworld run setblock 407 65 -1 coarse_dirt
execute in minecraft:overworld run fill 407 66 -1 407 144 -1 air
execute in minecraft:overworld run fill 407 58 0 407 62 0 stone
execute in minecraft:overworld run fill 407 63 0 407 64 0 dirt
execute in minecraft:overworld run setblock 407 65 0 coarse_dirt
execute in minecraft:overworld run fill 407 66 0 407 144 0 air
execute in minecraft:overworld run fill 407 58 1 407 62 1 stone
execute in minecraft:overworld run fill 407 63 1 407 64 1 dirt
execute in minecraft:overworld run setblock 407 65 1 coarse_dirt
execute in minecraft:overworld run fill 407 66 1 407 144 1 air
execute in minecraft:overworld run fill 407 58 2 407 62 2 stone
execute in minecraft:overworld run fill 407 63 2 407 64 2 dirt
execute in minecraft:overworld run setblock 407 65 2 coarse_dirt
execute in minecraft:overworld run fill 407 66 2 407 144 2 air
execute in minecraft:overworld run fill 407 58 3 407 62 3 stone
execute in minecraft:overworld run fill 407 63 3 407 64 3 dirt
execute in minecraft:overworld run setblock 407 65 3 coarse_dirt
execute in minecraft:overworld run fill 407 66 3 407 144 3 air
execute in minecraft:overworld run setblock 407 66 3 grass
execute in minecraft:overworld run fill 407 58 4 407 62 4 stone
execute in minecraft:overworld run fill 407 63 4 407 64 4 dirt
execute in minecraft:overworld run setblock 407 65 4 coarse_dirt
execute in minecraft:overworld run fill 407 66 4 407 144 4 air
execute in minecraft:overworld run fill 407 58 5 407 62 5 stone
execute in minecraft:overworld run fill 407 63 5 407 64 5 dirt
execute in minecraft:overworld run setblock 407 65 5 coarse_dirt
execute in minecraft:overworld run fill 407 66 5 407 144 5 air
execute in minecraft:overworld run fill 407 58 6 407 62 6 stone
execute in minecraft:overworld run fill 407 63 6 407 64 6 dirt
execute in minecraft:overworld run setblock 407 65 6 grass_block
execute in minecraft:overworld run fill 407 66 6 407 144 6 air
execute in minecraft:overworld run fill 407 58 7 407 62 7 stone
execute in minecraft:overworld run fill 407 63 7 407 64 7 dirt
execute in minecraft:overworld run setblock 407 65 7 coarse_dirt
execute in minecraft:overworld run fill 407 66 7 407 144 7 air
execute in minecraft:overworld run setblock 407 66 7 mossy_cobblestone
execute in minecraft:overworld run fill 407 58 8 407 63 8 stone
execute in minecraft:overworld run fill 407 64 8 407 65 8 dirt
execute in minecraft:overworld run setblock 407 66 8 coarse_dirt
execute in minecraft:overworld run fill 407 67 8 407 144 8 air
execute in minecraft:overworld run fill 407 58 9 407 63 9 stone
execute in minecraft:overworld run fill 407 64 9 407 65 9 dirt
execute in minecraft:overworld run setblock 407 66 9 grass_block
execute in minecraft:overworld run fill 407 67 9 407 144 9 air
execute in minecraft:overworld run setblock 407 67 9 mossy_cobblestone
execute in minecraft:overworld run fill 407 58 10 407 63 10 stone
execute in minecraft:overworld run fill 407 64 10 407 65 10 dirt
execute in minecraft:overworld run setblock 407 66 10 coarse_dirt
execute in minecraft:overworld run fill 407 67 10 407 144 10 air
execute in minecraft:overworld run setblock 407 67 10 grass
execute in minecraft:overworld run fill 407 58 11 407 63 11 stone
execute in minecraft:overworld run fill 407 64 11 407 65 11 dirt
execute in minecraft:overworld run setblock 407 66 11 coarse_dirt
execute in minecraft:overworld run fill 407 67 11 407 144 11 air
execute in minecraft:overworld run setblock 407 67 11 grass
execute in minecraft:overworld run fill 407 58 12 407 64 12 stone
execute in minecraft:overworld run fill 407 65 12 407 66 12 dirt
execute in minecraft:overworld run setblock 407 67 12 grass_block
execute in minecraft:overworld run fill 407 68 12 407 144 12 air
execute in minecraft:overworld run fill 407 58 13 407 64 13 stone
execute in minecraft:overworld run fill 407 65 13 407 66 13 dirt
execute in minecraft:overworld run setblock 407 67 13 grass_block
execute in minecraft:overworld run fill 407 68 13 407 144 13 air
execute in minecraft:overworld run fill 407 58 14 407 64 14 stone
execute in minecraft:overworld run fill 407 65 14 407 66 14 dirt
execute in minecraft:overworld run setblock 407 67 14 coarse_dirt
execute in minecraft:overworld run fill 407 68 14 407 144 14 air
execute in minecraft:overworld run fill 407 58 15 407 64 15 stone
execute in minecraft:overworld run fill 407 65 15 407 66 15 dirt
execute in minecraft:overworld run setblock 407 67 15 grass_block
execute in minecraft:overworld run fill 407 68 15 407 144 15 air
execute in minecraft:overworld run fill 407 58 16 407 65 16 stone
execute in minecraft:overworld run fill 407 66 16 407 67 16 dirt
execute in minecraft:overworld run setblock 407 68 16 coarse_dirt
execute in minecraft:overworld run fill 407 69 16 407 144 16 air
execute in minecraft:overworld run fill 407 58 17 407 65 17 stone
execute in minecraft:overworld run fill 407 66 17 407 67 17 dirt
execute in minecraft:overworld run setblock 407 68 17 coarse_dirt
execute in minecraft:overworld run fill 407 69 17 407 144 17 air
execute in minecraft:overworld run fill 407 58 18 407 65 18 stone
execute in minecraft:overworld run fill 407 66 18 407 67 18 dirt
execute in minecraft:overworld run setblock 407 68 18 coarse_dirt
execute in minecraft:overworld run fill 407 69 18 407 144 18 air
execute in minecraft:overworld run setblock 407 69 18 grass
execute in minecraft:overworld run fill 407 58 19 407 66 19 stone
execute in minecraft:overworld run fill 407 67 19 407 68 19 dirt
execute in minecraft:overworld run setblock 407 69 19 grass_block
execute in minecraft:overworld run fill 407 70 19 407 144 19 air
execute in minecraft:overworld run fill 407 58 20 407 66 20 stone
schedule function blade_gallery:random/battlefield/part_113 1t replace
