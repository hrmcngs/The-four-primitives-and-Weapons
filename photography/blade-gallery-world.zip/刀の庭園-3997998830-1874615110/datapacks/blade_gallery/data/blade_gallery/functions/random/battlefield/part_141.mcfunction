execute in minecraft:overworld run fill 425 70 38 425 144 38 air
execute in minecraft:overworld run fill 425 58 39 425 66 39 stone
execute in minecraft:overworld run fill 425 67 39 425 68 39 dirt
execute in minecraft:overworld run setblock 425 69 39 coarse_dirt
execute in minecraft:overworld run fill 425 70 39 425 144 39 air
execute in minecraft:overworld run fill 425 58 40 425 65 40 stone
execute in minecraft:overworld run fill 425 66 40 425 67 40 dirt
execute in minecraft:overworld run setblock 425 68 40 coarse_dirt
execute in minecraft:overworld run fill 425 69 40 425 144 40 air
execute in minecraft:overworld run fill 425 58 41 425 65 41 stone
execute in minecraft:overworld run fill 425 66 41 425 67 41 dirt
execute in minecraft:overworld run setblock 425 68 41 coarse_dirt
execute in minecraft:overworld run fill 425 69 41 425 144 41 air
execute in minecraft:overworld run fill 425 58 42 425 64 42 stone
execute in minecraft:overworld run fill 425 65 42 425 66 42 dirt
execute in minecraft:overworld run setblock 425 67 42 grass_block
execute in minecraft:overworld run fill 425 68 42 425 144 42 air
execute in minecraft:overworld run fill 425 58 43 425 63 43 stone
execute in minecraft:overworld run fill 425 64 43 425 65 43 dirt
execute in minecraft:overworld run setblock 425 66 43 grass_block
execute in minecraft:overworld run fill 425 67 43 425 144 43 air
execute in minecraft:overworld run fill 425 58 44 425 62 44 stone
execute in minecraft:overworld run fill 425 63 44 425 64 44 dirt
execute in minecraft:overworld run setblock 425 65 44 grass_block
execute in minecraft:overworld run fill 425 66 44 425 144 44 air
execute in minecraft:overworld run fill 425 58 45 425 62 45 stone
execute in minecraft:overworld run fill 425 63 45 425 64 45 dirt
execute in minecraft:overworld run setblock 425 65 45 coarse_dirt
execute in minecraft:overworld run fill 425 66 45 425 144 45 air
execute in minecraft:overworld run fill 425 58 46 425 61 46 stone
execute in minecraft:overworld run fill 425 62 46 425 63 46 dirt
execute in minecraft:overworld run setblock 425 64 46 grass_block
execute in minecraft:overworld run fill 425 65 46 425 144 46 air
execute in minecraft:overworld run fill 425 58 47 425 61 47 stone
execute in minecraft:overworld run fill 425 62 47 425 63 47 dirt
execute in minecraft:overworld run setblock 425 64 47 coarse_dirt
execute in minecraft:overworld run fill 425 65 47 425 144 47 air
execute in minecraft:overworld run fill 426 58 -48 426 61 -48 stone
execute in minecraft:overworld run fill 426 62 -48 426 63 -48 dirt
execute in minecraft:overworld run setblock 426 64 -48 coarse_dirt
execute in minecraft:overworld run fill 426 65 -48 426 144 -48 air
execute in minecraft:overworld run fill 426 58 -47 426 63 -47 stone
execute in minecraft:overworld run fill 426 64 -47 426 65 -47 dirt
execute in minecraft:overworld run setblock 426 66 -47 coarse_dirt
execute in minecraft:overworld run fill 426 67 -47 426 144 -47 air
execute in minecraft:overworld run fill 426 58 -46 426 64 -46 stone
execute in minecraft:overworld run fill 426 65 -46 426 66 -46 dirt
execute in minecraft:overworld run setblock 426 67 -46 grass_block
execute in minecraft:overworld run fill 426 68 -46 426 144 -46 air
execute in minecraft:overworld run fill 426 58 -45 426 66 -45 stone
execute in minecraft:overworld run fill 426 67 -45 426 68 -45 dirt
execute in minecraft:overworld run setblock 426 69 -45 coarse_dirt
execute in minecraft:overworld run fill 426 70 -45 426 144 -45 air
execute in minecraft:overworld run fill 426 58 -44 426 67 -44 stone
execute in minecraft:overworld run fill 426 68 -44 426 69 -44 dirt
execute in minecraft:overworld run setblock 426 70 -44 grass_block
execute in minecraft:overworld run fill 426 71 -44 426 144 -44 air
execute in minecraft:overworld run fill 426 58 -43 426 69 -43 stone
execute in minecraft:overworld run fill 426 70 -43 426 71 -43 dirt
execute in minecraft:overworld run setblock 426 72 -43 coarse_dirt
execute in minecraft:overworld run fill 426 73 -43 426 144 -43 air
execute in minecraft:overworld run fill 426 58 -42 426 70 -42 stone
execute in minecraft:overworld run fill 426 71 -42 426 72 -42 dirt
execute in minecraft:overworld run setblock 426 73 -42 grass_block
execute in minecraft:overworld run fill 426 74 -42 426 144 -42 air
execute in minecraft:overworld run fill 426 58 -41 426 70 -41 stone
execute in minecraft:overworld run fill 426 71 -41 426 72 -41 dirt
execute in minecraft:overworld run setblock 426 73 -41 grass_block
execute in minecraft:overworld run fill 426 74 -41 426 144 -41 air
execute in minecraft:overworld run fill 426 58 -40 426 70 -40 stone
execute in minecraft:overworld run fill 426 71 -40 426 72 -40 dirt
execute in minecraft:overworld run setblock 426 73 -40 grass_block
execute in minecraft:overworld run fill 426 74 -40 426 144 -40 air
execute in minecraft:overworld run fill 426 58 -39 426 70 -39 stone
execute in minecraft:overworld run fill 426 71 -39 426 72 -39 dirt
execute in minecraft:overworld run setblock 426 73 -39 coarse_dirt
execute in minecraft:overworld run fill 426 74 -39 426 144 -39 air
execute in minecraft:overworld run fill 426 58 -38 426 70 -38 stone
execute in minecraft:overworld run fill 426 71 -38 426 72 -38 dirt
execute in minecraft:overworld run setblock 426 73 -38 coarse_dirt
execute in minecraft:overworld run fill 426 74 -38 426 144 -38 air
execute in minecraft:overworld run fill 426 58 -37 426 70 -37 stone
execute in minecraft:overworld run fill 426 71 -37 426 72 -37 dirt
execute in minecraft:overworld run setblock 426 73 -37 coarse_dirt
execute in minecraft:overworld run fill 426 74 -37 426 144 -37 air
execute in minecraft:overworld run fill 426 58 -36 426 69 -36 stone
execute in minecraft:overworld run fill 426 70 -36 426 71 -36 dirt
execute in minecraft:overworld run setblock 426 72 -36 coarse_dirt
execute in minecraft:overworld run fill 426 73 -36 426 144 -36 air
execute in minecraft:overworld run fill 426 58 -35 426 69 -35 stone
execute in minecraft:overworld run fill 426 70 -35 426 71 -35 dirt
execute in minecraft:overworld run setblock 426 72 -35 coarse_dirt
execute in minecraft:overworld run fill 426 73 -35 426 144 -35 air
execute in minecraft:overworld run fill 426 58 -34 426 69 -34 stone
execute in minecraft:overworld run fill 426 70 -34 426 71 -34 dirt
execute in minecraft:overworld run setblock 426 72 -34 coarse_dirt
execute in minecraft:overworld run fill 426 73 -34 426 144 -34 air
execute in minecraft:overworld run fill 426 58 -33 426 69 -33 stone
execute in minecraft:overworld run fill 426 70 -33 426 71 -33 dirt
execute in minecraft:overworld run setblock 426 72 -33 grass_block
execute in minecraft:overworld run fill 426 73 -33 426 144 -33 air
execute in minecraft:overworld run fill 426 58 -32 426 68 -32 stone
execute in minecraft:overworld run fill 426 69 -32 426 70 -32 dirt
execute in minecraft:overworld run setblock 426 71 -32 coarse_dirt
execute in minecraft:overworld run fill 426 72 -32 426 144 -32 air
execute in minecraft:overworld run fill 426 58 -31 426 68 -31 stone
execute in minecraft:overworld run fill 426 69 -31 426 70 -31 dirt
execute in minecraft:overworld run setblock 426 71 -31 coarse_dirt
execute in minecraft:overworld run fill 426 72 -31 426 144 -31 air
execute in minecraft:overworld run fill 426 58 -30 426 68 -30 stone
execute in minecraft:overworld run fill 426 69 -30 426 70 -30 dirt
execute in minecraft:overworld run setblock 426 71 -30 coarse_dirt
execute in minecraft:overworld run fill 426 72 -30 426 144 -30 air
execute in minecraft:overworld run fill 426 58 -29 426 67 -29 stone
execute in minecraft:overworld run fill 426 68 -29 426 69 -29 dirt
execute in minecraft:overworld run setblock 426 70 -29 coarse_dirt
execute in minecraft:overworld run fill 426 71 -29 426 144 -29 air
execute in minecraft:overworld run fill 426 58 -28 426 67 -28 stone
execute in minecraft:overworld run fill 426 68 -28 426 69 -28 dirt
execute in minecraft:overworld run setblock 426 70 -28 coarse_dirt
execute in minecraft:overworld run fill 426 71 -28 426 144 -28 air
execute in minecraft:overworld run fill 426 58 -27 426 67 -27 stone
execute in minecraft:overworld run fill 426 68 -27 426 69 -27 dirt
execute in minecraft:overworld run setblock 426 70 -27 coarse_dirt
execute in minecraft:overworld run fill 426 71 -27 426 144 -27 air
execute in minecraft:overworld run fill 426 58 -26 426 67 -26 stone
execute in minecraft:overworld run fill 426 68 -26 426 69 -26 dirt
execute in minecraft:overworld run setblock 426 70 -26 coarse_dirt
execute in minecraft:overworld run fill 426 71 -26 426 144 -26 air
execute in minecraft:overworld run fill 426 58 -25 426 67 -25 stone
execute in minecraft:overworld run fill 426 68 -25 426 69 -25 dirt
execute in minecraft:overworld run setblock 426 70 -25 grass_block
execute in minecraft:overworld run fill 426 71 -25 426 144 -25 air
execute in minecraft:overworld run fill 426 58 -24 426 66 -24 stone
execute in minecraft:overworld run fill 426 67 -24 426 68 -24 dirt
execute in minecraft:overworld run setblock 426 69 -24 grass_block
execute in minecraft:overworld run fill 426 70 -24 426 144 -24 air
execute in minecraft:overworld run fill 426 58 -23 426 66 -23 stone
execute in minecraft:overworld run fill 426 67 -23 426 68 -23 dirt
execute in minecraft:overworld run setblock 426 69 -23 coarse_dirt
execute in minecraft:overworld run fill 426 70 -23 426 144 -23 air
execute in minecraft:overworld run fill 426 58 -22 426 66 -22 stone
execute in minecraft:overworld run fill 426 67 -22 426 68 -22 dirt
execute in minecraft:overworld run setblock 426 69 -22 coarse_dirt
execute in minecraft:overworld run fill 426 70 -22 426 144 -22 air
execute in minecraft:overworld run fill 426 58 -21 426 66 -21 stone
execute in minecraft:overworld run fill 426 67 -21 426 68 -21 dirt
execute in minecraft:overworld run setblock 426 69 -21 coarse_dirt
execute in minecraft:overworld run fill 426 70 -21 426 144 -21 air
execute in minecraft:overworld run fill 426 58 -20 426 66 -20 stone
execute in minecraft:overworld run fill 426 67 -20 426 68 -20 dirt
execute in minecraft:overworld run setblock 426 69 -20 grass_block
execute in minecraft:overworld run fill 426 70 -20 426 144 -20 air
execute in minecraft:overworld run fill 426 58 -19 426 65 -19 stone
execute in minecraft:overworld run fill 426 66 -19 426 67 -19 dirt
execute in minecraft:overworld run setblock 426 68 -19 grass_block
execute in minecraft:overworld run fill 426 69 -19 426 144 -19 air
execute in minecraft:overworld run fill 426 58 -18 426 65 -18 stone
execute in minecraft:overworld run fill 426 66 -18 426 67 -18 dirt
execute in minecraft:overworld run setblock 426 68 -18 coarse_dirt
execute in minecraft:overworld run fill 426 69 -18 426 144 -18 air
execute in minecraft:overworld run fill 426 58 -17 426 65 -17 stone
execute in minecraft:overworld run fill 426 66 -17 426 67 -17 dirt
execute in minecraft:overworld run setblock 426 68 -17 coarse_dirt
execute in minecraft:overworld run fill 426 69 -17 426 144 -17 air
execute in minecraft:overworld run fill 426 58 -16 426 65 -16 stone
execute in minecraft:overworld run fill 426 66 -16 426 67 -16 dirt
execute in minecraft:overworld run setblock 426 68 -16 coarse_dirt
execute in minecraft:overworld run fill 426 69 -16 426 144 -16 air
execute in minecraft:overworld run fill 426 58 -15 426 65 -15 stone
execute in minecraft:overworld run fill 426 66 -15 426 67 -15 dirt
execute in minecraft:overworld run setblock 426 68 -15 coarse_dirt
execute in minecraft:overworld run fill 426 69 -15 426 144 -15 air
execute in minecraft:overworld run fill 426 58 -14 426 64 -14 stone
execute in minecraft:overworld run fill 426 65 -14 426 66 -14 dirt
execute in minecraft:overworld run setblock 426 67 -14 coarse_dirt
execute in minecraft:overworld run fill 426 68 -14 426 144 -14 air
execute in minecraft:overworld run fill 426 58 -13 426 64 -13 stone
execute in minecraft:overworld run fill 426 65 -13 426 66 -13 dirt
execute in minecraft:overworld run setblock 426 67 -13 coarse_dirt
execute in minecraft:overworld run fill 426 68 -13 426 144 -13 air
execute in minecraft:overworld run fill 426 58 -12 426 64 -12 stone
execute in minecraft:overworld run fill 426 65 -12 426 66 -12 dirt
execute in minecraft:overworld run setblock 426 67 -12 grass_block
execute in minecraft:overworld run fill 426 68 -12 426 144 -12 air
execute in minecraft:overworld run fill 426 58 -11 426 64 -11 stone
execute in minecraft:overworld run fill 426 65 -11 426 66 -11 dirt
execute in minecraft:overworld run setblock 426 67 -11 grass_block
execute in minecraft:overworld run fill 426 68 -11 426 144 -11 air
execute in minecraft:overworld run fill 426 58 -10 426 64 -10 stone
execute in minecraft:overworld run fill 426 65 -10 426 66 -10 dirt
execute in minecraft:overworld run setblock 426 67 -10 coarse_dirt
execute in minecraft:overworld run fill 426 68 -10 426 144 -10 air
execute in minecraft:overworld run fill 426 58 -9 426 64 -9 stone
execute in minecraft:overworld run fill 426 65 -9 426 66 -9 dirt
execute in minecraft:overworld run setblock 426 67 -9 coarse_dirt
execute in minecraft:overworld run fill 426 68 -9 426 144 -9 air
execute in minecraft:overworld run fill 426 58 -8 426 64 -8 stone
execute in minecraft:overworld run fill 426 65 -8 426 66 -8 dirt
execute in minecraft:overworld run setblock 426 67 -8 coarse_dirt
execute in minecraft:overworld run fill 426 68 -8 426 144 -8 air
execute in minecraft:overworld run fill 426 58 -7 426 64 -7 stone
execute in minecraft:overworld run fill 426 65 -7 426 66 -7 dirt
execute in minecraft:overworld run setblock 426 67 -7 coarse_dirt
execute in minecraft:overworld run fill 426 68 -7 426 144 -7 air
execute in minecraft:overworld run fill 426 58 -6 426 64 -6 stone
execute in minecraft:overworld run fill 426 65 -6 426 66 -6 dirt
execute in minecraft:overworld run setblock 426 67 -6 coarse_dirt
execute in minecraft:overworld run fill 426 68 -6 426 144 -6 air
execute in minecraft:overworld run fill 426 58 -5 426 63 -5 stone
execute in minecraft:overworld run fill 426 64 -5 426 65 -5 dirt
execute in minecraft:overworld run setblock 426 66 -5 coarse_dirt
execute in minecraft:overworld run fill 426 67 -5 426 144 -5 air
execute in minecraft:overworld run fill 426 58 -4 426 63 -4 stone
execute in minecraft:overworld run fill 426 64 -4 426 65 -4 dirt
execute in minecraft:overworld run setblock 426 66 -4 grass_block
execute in minecraft:overworld run fill 426 67 -4 426 144 -4 air
execute in minecraft:overworld run fill 426 58 -3 426 63 -3 stone
execute in minecraft:overworld run fill 426 64 -3 426 65 -3 dirt
execute in minecraft:overworld run setblock 426 66 -3 coarse_dirt
execute in minecraft:overworld run fill 426 67 -3 426 144 -3 air
execute in minecraft:overworld run fill 426 58 -2 426 63 -2 stone
execute in minecraft:overworld run fill 426 64 -2 426 65 -2 dirt
execute in minecraft:overworld run setblock 426 66 -2 coarse_dirt
execute in minecraft:overworld run fill 426 67 -2 426 144 -2 air
execute in minecraft:overworld run fill 426 58 -1 426 63 -1 stone
execute in minecraft:overworld run fill 426 64 -1 426 65 -1 dirt
execute in minecraft:overworld run setblock 426 66 -1 coarse_dirt
execute in minecraft:overworld run fill 426 67 -1 426 144 -1 air
execute in minecraft:overworld run fill 426 58 0 426 63 0 stone
execute in minecraft:overworld run fill 426 64 0 426 65 0 dirt
execute in minecraft:overworld run setblock 426 66 0 coarse_dirt
execute in minecraft:overworld run fill 426 67 0 426 144 0 air
execute in minecraft:overworld run fill 426 58 1 426 63 1 stone
execute in minecraft:overworld run fill 426 64 1 426 65 1 dirt
execute in minecraft:overworld run setblock 426 66 1 coarse_dirt
execute in minecraft:overworld run fill 426 67 1 426 144 1 air
execute in minecraft:overworld run fill 426 58 2 426 63 2 stone
execute in minecraft:overworld run fill 426 64 2 426 65 2 dirt
execute in minecraft:overworld run setblock 426 66 2 coarse_dirt
execute in minecraft:overworld run fill 426 67 2 426 144 2 air
execute in minecraft:overworld run fill 426 58 3 426 63 3 stone
execute in minecraft:overworld run fill 426 64 3 426 65 3 dirt
execute in minecraft:overworld run setblock 426 66 3 coarse_dirt
execute in minecraft:overworld run fill 426 67 3 426 144 3 air
execute in minecraft:overworld run fill 426 58 4 426 63 4 stone
execute in minecraft:overworld run fill 426 64 4 426 65 4 dirt
execute in minecraft:overworld run setblock 426 66 4 coarse_dirt
execute in minecraft:overworld run fill 426 67 4 426 144 4 air
execute in minecraft:overworld run fill 426 58 5 426 63 5 stone
execute in minecraft:overworld run fill 426 64 5 426 65 5 dirt
execute in minecraft:overworld run setblock 426 66 5 coarse_dirt
execute in minecraft:overworld run fill 426 67 5 426 144 5 air
execute in minecraft:overworld run fill 426 58 6 426 64 6 stone
execute in minecraft:overworld run fill 426 65 6 426 66 6 dirt
execute in minecraft:overworld run setblock 426 67 6 coarse_dirt
schedule function blade_gallery:random/battlefield/part_142 1t replace
