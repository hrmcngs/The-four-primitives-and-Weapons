execute in minecraft:overworld run fill 242 58 6 242 64 6 stone
execute in minecraft:overworld run fill 242 65 6 242 66 6 dirt
execute in minecraft:overworld run setblock 242 67 6 coarse_dirt
execute in minecraft:overworld run fill 242 68 6 242 144 6 air
execute in minecraft:overworld run fill 242 58 7 242 64 7 stone
execute in minecraft:overworld run fill 242 65 7 242 66 7 dirt
execute in minecraft:overworld run setblock 242 67 7 coarse_dirt
execute in minecraft:overworld run fill 242 68 7 242 144 7 air
execute in minecraft:overworld run fill 242 58 8 242 65 8 stone
execute in minecraft:overworld run fill 242 66 8 242 67 8 dirt
execute in minecraft:overworld run setblock 242 68 8 coarse_dirt
execute in minecraft:overworld run fill 242 69 8 242 144 8 air
execute in minecraft:overworld run fill 242 58 9 242 65 9 stone
execute in minecraft:overworld run fill 242 66 9 242 67 9 dirt
execute in minecraft:overworld run setblock 242 68 9 grass_block
execute in minecraft:overworld run fill 242 69 9 242 144 9 air
execute in minecraft:overworld run fill 242 58 10 242 65 10 stone
execute in minecraft:overworld run fill 242 66 10 242 67 10 dirt
execute in minecraft:overworld run setblock 242 68 10 coarse_dirt
execute in minecraft:overworld run fill 242 69 10 242 144 10 air
execute in minecraft:overworld run setblock 242 69 10 grass
execute in minecraft:overworld run fill 242 58 11 242 65 11 stone
execute in minecraft:overworld run fill 242 66 11 242 67 11 dirt
execute in minecraft:overworld run setblock 242 68 11 grass_block
execute in minecraft:overworld run fill 242 69 11 242 144 11 air
execute in minecraft:overworld run setblock 242 69 11 grass
execute in minecraft:overworld run fill 242 58 12 242 65 12 stone
execute in minecraft:overworld run fill 242 66 12 242 67 12 dirt
execute in minecraft:overworld run setblock 242 68 12 coarse_dirt
execute in minecraft:overworld run fill 242 69 12 242 144 12 air
execute in minecraft:overworld run fill 242 58 13 242 65 13 stone
execute in minecraft:overworld run fill 242 66 13 242 67 13 dirt
execute in minecraft:overworld run setblock 242 68 13 grass_block
execute in minecraft:overworld run fill 242 69 13 242 144 13 air
execute in minecraft:overworld run fill 242 58 14 242 65 14 stone
execute in minecraft:overworld run fill 242 66 14 242 67 14 dirt
execute in minecraft:overworld run setblock 242 68 14 grass_block
execute in minecraft:overworld run fill 242 69 14 242 144 14 air
execute in minecraft:overworld run fill 242 58 15 242 66 15 stone
execute in minecraft:overworld run fill 242 67 15 242 68 15 dirt
execute in minecraft:overworld run setblock 242 69 15 coarse_dirt
execute in minecraft:overworld run fill 242 70 15 242 144 15 air
execute in minecraft:overworld run fill 242 58 16 242 66 16 stone
execute in minecraft:overworld run fill 242 67 16 242 68 16 dirt
execute in minecraft:overworld run setblock 242 69 16 coarse_dirt
execute in minecraft:overworld run fill 242 70 16 242 144 16 air
execute in minecraft:overworld run fill 242 58 17 242 66 17 stone
execute in minecraft:overworld run fill 242 67 17 242 68 17 dirt
execute in minecraft:overworld run setblock 242 69 17 coarse_dirt
execute in minecraft:overworld run fill 242 70 17 242 144 17 air
execute in minecraft:overworld run fill 242 58 18 242 66 18 stone
execute in minecraft:overworld run fill 242 67 18 242 68 18 dirt
execute in minecraft:overworld run setblock 242 69 18 coarse_dirt
execute in minecraft:overworld run fill 242 70 18 242 144 18 air
execute in minecraft:overworld run setblock 242 70 18 grass
execute in minecraft:overworld run fill 242 58 19 242 66 19 stone
execute in minecraft:overworld run fill 242 67 19 242 68 19 dirt
execute in minecraft:overworld run setblock 242 69 19 grass_block
execute in minecraft:overworld run fill 242 70 19 242 144 19 air
execute in minecraft:overworld run fill 242 58 20 242 66 20 stone
execute in minecraft:overworld run fill 242 67 20 242 68 20 dirt
execute in minecraft:overworld run setblock 242 69 20 coarse_dirt
execute in minecraft:overworld run fill 242 70 20 242 144 20 air
execute in minecraft:overworld run fill 242 58 21 242 66 21 stone
execute in minecraft:overworld run fill 242 67 21 242 68 21 dirt
execute in minecraft:overworld run setblock 242 69 21 grass_block
execute in minecraft:overworld run fill 242 70 21 242 144 21 air
execute in minecraft:overworld run fill 242 58 22 242 66 22 stone
execute in minecraft:overworld run fill 242 67 22 242 68 22 dirt
execute in minecraft:overworld run setblock 242 69 22 coarse_dirt
execute in minecraft:overworld run fill 242 70 22 242 144 22 air
execute in minecraft:overworld run fill 242 58 23 242 66 23 stone
execute in minecraft:overworld run fill 242 67 23 242 68 23 dirt
execute in minecraft:overworld run setblock 242 69 23 coarse_dirt
execute in minecraft:overworld run fill 242 70 23 242 144 23 air
execute in minecraft:overworld run fill 242 58 24 242 66 24 stone
execute in minecraft:overworld run fill 242 67 24 242 68 24 dirt
execute in minecraft:overworld run setblock 242 69 24 grass_block
execute in minecraft:overworld run fill 242 70 24 242 144 24 air
execute in minecraft:overworld run fill 242 58 25 242 66 25 stone
execute in minecraft:overworld run fill 242 67 25 242 68 25 dirt
execute in minecraft:overworld run setblock 242 69 25 coarse_dirt
execute in minecraft:overworld run fill 242 70 25 242 144 25 air
execute in minecraft:overworld run fill 242 58 26 242 66 26 stone
execute in minecraft:overworld run fill 242 67 26 242 68 26 dirt
execute in minecraft:overworld run setblock 242 69 26 grass_block
execute in minecraft:overworld run fill 242 70 26 242 144 26 air
execute in minecraft:overworld run fill 242 58 27 242 66 27 stone
execute in minecraft:overworld run fill 242 67 27 242 68 27 dirt
execute in minecraft:overworld run setblock 242 69 27 coarse_dirt
execute in minecraft:overworld run fill 242 70 27 242 144 27 air
execute in minecraft:overworld run fill 242 58 28 242 66 28 stone
execute in minecraft:overworld run fill 242 67 28 242 68 28 dirt
execute in minecraft:overworld run setblock 242 69 28 coarse_dirt
execute in minecraft:overworld run fill 242 70 28 242 144 28 air
execute in minecraft:overworld run fill 242 58 29 242 66 29 stone
execute in minecraft:overworld run fill 242 67 29 242 68 29 dirt
execute in minecraft:overworld run setblock 242 69 29 coarse_dirt
execute in minecraft:overworld run fill 242 70 29 242 144 29 air
execute in minecraft:overworld run fill 242 58 30 242 66 30 stone
execute in minecraft:overworld run fill 242 67 30 242 68 30 dirt
execute in minecraft:overworld run setblock 242 69 30 coarse_dirt
execute in minecraft:overworld run fill 242 70 30 242 144 30 air
execute in minecraft:overworld run fill 242 58 31 242 66 31 stone
execute in minecraft:overworld run fill 242 67 31 242 68 31 dirt
execute in minecraft:overworld run setblock 242 69 31 coarse_dirt
execute in minecraft:overworld run fill 242 70 31 242 144 31 air
execute in minecraft:overworld run fill 242 58 32 242 66 32 stone
execute in minecraft:overworld run fill 242 67 32 242 68 32 dirt
execute in minecraft:overworld run setblock 242 69 32 coarse_dirt
execute in minecraft:overworld run fill 242 70 32 242 144 32 air
execute in minecraft:overworld run setblock 242 70 32 grass
execute in minecraft:overworld run fill 242 58 33 242 65 33 stone
execute in minecraft:overworld run fill 242 66 33 242 67 33 dirt
execute in minecraft:overworld run setblock 242 68 33 coarse_dirt
execute in minecraft:overworld run fill 242 69 33 242 144 33 air
execute in minecraft:overworld run setblock 242 69 33 grass
execute in minecraft:overworld run fill 242 58 34 242 65 34 stone
execute in minecraft:overworld run fill 242 66 34 242 67 34 dirt
execute in minecraft:overworld run setblock 242 68 34 coarse_dirt
execute in minecraft:overworld run fill 242 69 34 242 144 34 air
execute in minecraft:overworld run fill 242 58 35 242 65 35 stone
execute in minecraft:overworld run fill 242 66 35 242 67 35 dirt
execute in minecraft:overworld run setblock 242 68 35 grass_block
execute in minecraft:overworld run fill 242 69 35 242 144 35 air
execute in minecraft:overworld run fill 242 58 36 242 65 36 stone
execute in minecraft:overworld run fill 242 66 36 242 67 36 dirt
execute in minecraft:overworld run setblock 242 68 36 grass_block
execute in minecraft:overworld run fill 242 69 36 242 144 36 air
execute in minecraft:overworld run fill 242 58 37 242 64 37 stone
execute in minecraft:overworld run fill 242 65 37 242 66 37 dirt
execute in minecraft:overworld run setblock 242 67 37 coarse_dirt
execute in minecraft:overworld run fill 242 68 37 242 144 37 air
execute in minecraft:overworld run fill 242 58 38 242 64 38 stone
execute in minecraft:overworld run fill 242 65 38 242 66 38 dirt
execute in minecraft:overworld run setblock 242 67 38 grass_block
execute in minecraft:overworld run fill 242 68 38 242 144 38 air
execute in minecraft:overworld run fill 242 58 39 242 64 39 stone
execute in minecraft:overworld run fill 242 65 39 242 66 39 dirt
execute in minecraft:overworld run setblock 242 67 39 coarse_dirt
execute in minecraft:overworld run fill 242 68 39 242 144 39 air
execute in minecraft:overworld run fill 242 58 40 242 64 40 stone
execute in minecraft:overworld run fill 242 65 40 242 66 40 dirt
execute in minecraft:overworld run setblock 242 67 40 grass_block
execute in minecraft:overworld run fill 242 68 40 242 144 40 air
execute in minecraft:overworld run fill 242 58 41 242 63 41 stone
execute in minecraft:overworld run fill 242 64 41 242 65 41 dirt
execute in minecraft:overworld run setblock 242 66 41 grass_block
execute in minecraft:overworld run fill 242 67 41 242 144 41 air
execute in minecraft:overworld run fill 242 58 42 242 63 42 stone
execute in minecraft:overworld run fill 242 64 42 242 65 42 dirt
execute in minecraft:overworld run setblock 242 66 42 coarse_dirt
execute in minecraft:overworld run fill 242 67 42 242 144 42 air
execute in minecraft:overworld run fill 242 58 43 242 63 43 stone
execute in minecraft:overworld run fill 242 64 43 242 65 43 dirt
execute in minecraft:overworld run setblock 242 66 43 coarse_dirt
execute in minecraft:overworld run fill 242 67 43 242 144 43 air
execute in minecraft:overworld run fill 242 58 44 242 62 44 stone
execute in minecraft:overworld run fill 242 63 44 242 64 44 dirt
execute in minecraft:overworld run setblock 242 65 44 grass_block
execute in minecraft:overworld run fill 242 66 44 242 144 44 air
execute in minecraft:overworld run fill 242 58 45 242 62 45 stone
execute in minecraft:overworld run fill 242 63 45 242 64 45 dirt
execute in minecraft:overworld run setblock 242 65 45 coarse_dirt
execute in minecraft:overworld run fill 242 66 45 242 144 45 air
execute in minecraft:overworld run fill 242 58 46 242 62 46 stone
execute in minecraft:overworld run fill 242 63 46 242 64 46 dirt
execute in minecraft:overworld run setblock 242 65 46 grass_block
execute in minecraft:overworld run fill 242 66 46 242 144 46 air
execute in minecraft:overworld run fill 242 58 47 242 61 47 stone
execute in minecraft:overworld run fill 242 62 47 242 63 47 dirt
execute in minecraft:overworld run setblock 242 64 47 coarse_dirt
execute in minecraft:overworld run fill 242 65 47 242 144 47 air
execute in minecraft:overworld run fill 243 58 -48 243 61 -48 stone
execute in minecraft:overworld run fill 243 62 -48 243 63 -48 dirt
execute in minecraft:overworld run setblock 243 64 -48 coarse_dirt
execute in minecraft:overworld run fill 243 65 -48 243 144 -48 air
execute in minecraft:overworld run fill 243 58 -47 243 62 -47 stone
execute in minecraft:overworld run fill 243 63 -47 243 64 -47 dirt
execute in minecraft:overworld run setblock 243 65 -47 coarse_dirt
execute in minecraft:overworld run fill 243 66 -47 243 144 -47 air
execute in minecraft:overworld run fill 243 58 -46 243 63 -46 stone
execute in minecraft:overworld run fill 243 64 -46 243 65 -46 dirt
execute in minecraft:overworld run setblock 243 66 -46 coarse_dirt
execute in minecraft:overworld run fill 243 67 -46 243 144 -46 air
execute in minecraft:overworld run fill 243 58 -45 243 64 -45 stone
execute in minecraft:overworld run fill 243 65 -45 243 66 -45 dirt
execute in minecraft:overworld run setblock 243 67 -45 coarse_dirt
execute in minecraft:overworld run fill 243 68 -45 243 144 -45 air
execute in minecraft:overworld run fill 243 58 -44 243 65 -44 stone
execute in minecraft:overworld run fill 243 66 -44 243 67 -44 dirt
execute in minecraft:overworld run setblock 243 68 -44 coarse_dirt
execute in minecraft:overworld run fill 243 69 -44 243 144 -44 air
execute in minecraft:overworld run fill 243 58 -43 243 65 -43 stone
execute in minecraft:overworld run fill 243 66 -43 243 67 -43 dirt
execute in minecraft:overworld run setblock 243 68 -43 coarse_dirt
execute in minecraft:overworld run fill 243 69 -43 243 144 -43 air
execute in minecraft:overworld run fill 243 58 -42 243 66 -42 stone
execute in minecraft:overworld run fill 243 67 -42 243 68 -42 dirt
execute in minecraft:overworld run setblock 243 69 -42 coarse_dirt
execute in minecraft:overworld run fill 243 70 -42 243 144 -42 air
execute in minecraft:overworld run fill 243 58 -41 243 67 -41 stone
execute in minecraft:overworld run fill 243 68 -41 243 69 -41 dirt
execute in minecraft:overworld run setblock 243 70 -41 coarse_dirt
execute in minecraft:overworld run fill 243 71 -41 243 144 -41 air
execute in minecraft:overworld run fill 243 58 -40 243 68 -40 stone
execute in minecraft:overworld run fill 243 69 -40 243 70 -40 dirt
execute in minecraft:overworld run setblock 243 71 -40 coarse_dirt
execute in minecraft:overworld run fill 243 72 -40 243 144 -40 air
execute in minecraft:overworld run fill 243 58 -39 243 69 -39 stone
execute in minecraft:overworld run fill 243 70 -39 243 71 -39 dirt
execute in minecraft:overworld run setblock 243 72 -39 grass_block
execute in minecraft:overworld run fill 243 73 -39 243 144 -39 air
execute in minecraft:overworld run fill 243 58 -38 243 69 -38 stone
execute in minecraft:overworld run fill 243 70 -38 243 71 -38 dirt
execute in minecraft:overworld run setblock 243 72 -38 coarse_dirt
execute in minecraft:overworld run fill 243 73 -38 243 144 -38 air
execute in minecraft:overworld run fill 243 58 -37 243 70 -37 stone
execute in minecraft:overworld run fill 243 71 -37 243 72 -37 dirt
execute in minecraft:overworld run setblock 243 73 -37 coarse_dirt
execute in minecraft:overworld run fill 243 74 -37 243 144 -37 air
execute in minecraft:overworld run fill 243 58 -36 243 70 -36 stone
execute in minecraft:overworld run fill 243 71 -36 243 72 -36 dirt
execute in minecraft:overworld run setblock 243 73 -36 coarse_dirt
execute in minecraft:overworld run fill 243 74 -36 243 144 -36 air
execute in minecraft:overworld run setblock 243 74 -36 grass
execute in minecraft:overworld run fill 243 58 -35 243 70 -35 stone
execute in minecraft:overworld run fill 243 71 -35 243 72 -35 dirt
execute in minecraft:overworld run setblock 243 73 -35 coarse_dirt
execute in minecraft:overworld run fill 243 74 -35 243 144 -35 air
execute in minecraft:overworld run fill 243 58 -34 243 70 -34 stone
execute in minecraft:overworld run fill 243 71 -34 243 72 -34 dirt
execute in minecraft:overworld run setblock 243 73 -34 grass_block
execute in minecraft:overworld run fill 243 74 -34 243 144 -34 air
execute in minecraft:overworld run fill 243 58 -33 243 70 -33 stone
execute in minecraft:overworld run fill 243 71 -33 243 72 -33 dirt
execute in minecraft:overworld run setblock 243 73 -33 coarse_dirt
execute in minecraft:overworld run fill 243 74 -33 243 144 -33 air
execute in minecraft:overworld run fill 243 58 -32 243 71 -32 stone
execute in minecraft:overworld run fill 243 72 -32 243 73 -32 dirt
execute in minecraft:overworld run setblock 243 74 -32 coarse_dirt
execute in minecraft:overworld run fill 243 75 -32 243 144 -32 air
execute in minecraft:overworld run fill 243 58 -31 243 71 -31 stone
execute in minecraft:overworld run fill 243 72 -31 243 73 -31 dirt
execute in minecraft:overworld run setblock 243 74 -31 coarse_dirt
execute in minecraft:overworld run fill 243 75 -31 243 144 -31 air
execute in minecraft:overworld run fill 243 58 -30 243 71 -30 stone
execute in minecraft:overworld run fill 243 72 -30 243 73 -30 dirt
execute in minecraft:overworld run setblock 243 74 -30 coarse_dirt
execute in minecraft:overworld run fill 243 75 -30 243 144 -30 air
execute in minecraft:overworld run fill 243 58 -29 243 71 -29 stone
execute in minecraft:overworld run fill 243 72 -29 243 73 -29 dirt
execute in minecraft:overworld run setblock 243 74 -29 grass_block
execute in minecraft:overworld run fill 243 75 -29 243 144 -29 air
execute in minecraft:overworld run setblock 243 75 -29 grass
execute in minecraft:overworld run fill 243 58 -28 243 71 -28 stone
schedule function blade_gallery:random/burned/part_54 1t replace
