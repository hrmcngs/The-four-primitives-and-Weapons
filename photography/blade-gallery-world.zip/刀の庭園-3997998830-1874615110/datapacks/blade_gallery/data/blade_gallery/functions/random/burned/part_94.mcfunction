execute in minecraft:overworld run fill 267 59 2 267 64 2 water
execute in minecraft:overworld run fill 267 58 3 267 55 3 stone
execute in minecraft:overworld run fill 267 56 3 267 57 3 dirt
execute in minecraft:overworld run setblock 267 58 3 gravel
execute in minecraft:overworld run fill 267 59 3 267 144 3 air
execute in minecraft:overworld run fill 267 59 3 267 64 3 water
execute in minecraft:overworld run fill 267 58 4 267 56 4 stone
execute in minecraft:overworld run fill 267 57 4 267 58 4 dirt
execute in minecraft:overworld run setblock 267 59 4 gravel
execute in minecraft:overworld run fill 267 60 4 267 144 4 air
execute in minecraft:overworld run fill 267 60 4 267 64 4 water
execute in minecraft:overworld run fill 267 58 5 267 56 5 stone
execute in minecraft:overworld run fill 267 57 5 267 58 5 dirt
execute in minecraft:overworld run setblock 267 59 5 gravel
execute in minecraft:overworld run fill 267 60 5 267 144 5 air
execute in minecraft:overworld run fill 267 60 5 267 64 5 water
execute in minecraft:overworld run fill 267 58 6 267 56 6 stone
execute in minecraft:overworld run fill 267 57 6 267 58 6 dirt
execute in minecraft:overworld run setblock 267 59 6 gravel
execute in minecraft:overworld run fill 267 60 6 267 144 6 air
execute in minecraft:overworld run fill 267 60 6 267 64 6 water
execute in minecraft:overworld run fill 267 58 7 267 56 7 stone
execute in minecraft:overworld run fill 267 57 7 267 58 7 dirt
execute in minecraft:overworld run setblock 267 59 7 gravel
execute in minecraft:overworld run fill 267 60 7 267 144 7 air
execute in minecraft:overworld run fill 267 60 7 267 64 7 water
execute in minecraft:overworld run fill 267 58 8 267 56 8 stone
execute in minecraft:overworld run fill 267 57 8 267 58 8 dirt
execute in minecraft:overworld run setblock 267 59 8 gravel
execute in minecraft:overworld run fill 267 60 8 267 144 8 air
execute in minecraft:overworld run fill 267 60 8 267 64 8 water
execute in minecraft:overworld run fill 267 58 9 267 56 9 stone
execute in minecraft:overworld run fill 267 57 9 267 58 9 dirt
execute in minecraft:overworld run setblock 267 59 9 gravel
execute in minecraft:overworld run fill 267 60 9 267 144 9 air
execute in minecraft:overworld run fill 267 60 9 267 64 9 water
execute in minecraft:overworld run fill 267 58 10 267 56 10 stone
execute in minecraft:overworld run fill 267 57 10 267 58 10 dirt
execute in minecraft:overworld run setblock 267 59 10 gravel
execute in minecraft:overworld run fill 267 60 10 267 144 10 air
execute in minecraft:overworld run fill 267 60 10 267 64 10 water
execute in minecraft:overworld run fill 267 58 11 267 56 11 stone
execute in minecraft:overworld run fill 267 57 11 267 58 11 dirt
execute in minecraft:overworld run setblock 267 59 11 gravel
execute in minecraft:overworld run fill 267 60 11 267 144 11 air
execute in minecraft:overworld run fill 267 60 11 267 64 11 water
execute in minecraft:overworld run fill 267 58 12 267 56 12 stone
execute in minecraft:overworld run fill 267 57 12 267 58 12 dirt
execute in minecraft:overworld run setblock 267 59 12 gravel
execute in minecraft:overworld run fill 267 60 12 267 144 12 air
execute in minecraft:overworld run fill 267 60 12 267 64 12 water
execute in minecraft:overworld run fill 267 58 13 267 56 13 stone
execute in minecraft:overworld run fill 267 57 13 267 58 13 dirt
execute in minecraft:overworld run setblock 267 59 13 gravel
execute in minecraft:overworld run fill 267 60 13 267 144 13 air
execute in minecraft:overworld run fill 267 60 13 267 64 13 water
execute in minecraft:overworld run fill 267 58 14 267 56 14 stone
execute in minecraft:overworld run fill 267 57 14 267 58 14 dirt
execute in minecraft:overworld run setblock 267 59 14 gravel
execute in minecraft:overworld run fill 267 60 14 267 144 14 air
execute in minecraft:overworld run fill 267 60 14 267 64 14 water
execute in minecraft:overworld run fill 267 58 15 267 56 15 stone
execute in minecraft:overworld run fill 267 57 15 267 58 15 dirt
execute in minecraft:overworld run setblock 267 59 15 gravel
execute in minecraft:overworld run fill 267 60 15 267 144 15 air
execute in minecraft:overworld run fill 267 60 15 267 64 15 water
execute in minecraft:overworld run fill 267 58 16 267 56 16 stone
execute in minecraft:overworld run fill 267 57 16 267 58 16 dirt
execute in minecraft:overworld run setblock 267 59 16 gravel
execute in minecraft:overworld run fill 267 60 16 267 144 16 air
execute in minecraft:overworld run fill 267 60 16 267 64 16 water
execute in minecraft:overworld run fill 267 58 17 267 56 17 stone
execute in minecraft:overworld run fill 267 57 17 267 58 17 dirt
execute in minecraft:overworld run setblock 267 59 17 gravel
execute in minecraft:overworld run fill 267 60 17 267 144 17 air
execute in minecraft:overworld run fill 267 60 17 267 64 17 water
execute in minecraft:overworld run fill 267 58 18 267 56 18 stone
execute in minecraft:overworld run fill 267 57 18 267 58 18 dirt
execute in minecraft:overworld run setblock 267 59 18 gravel
execute in minecraft:overworld run fill 267 60 18 267 144 18 air
execute in minecraft:overworld run fill 267 60 18 267 64 18 water
execute in minecraft:overworld run fill 267 58 19 267 56 19 stone
execute in minecraft:overworld run fill 267 57 19 267 58 19 dirt
execute in minecraft:overworld run setblock 267 59 19 gravel
execute in minecraft:overworld run fill 267 60 19 267 144 19 air
execute in minecraft:overworld run fill 267 60 19 267 64 19 water
execute in minecraft:overworld run fill 267 58 20 267 56 20 stone
execute in minecraft:overworld run fill 267 57 20 267 58 20 dirt
execute in minecraft:overworld run setblock 267 59 20 gravel
execute in minecraft:overworld run fill 267 60 20 267 144 20 air
execute in minecraft:overworld run fill 267 60 20 267 64 20 water
execute in minecraft:overworld run fill 267 58 21 267 56 21 stone
execute in minecraft:overworld run fill 267 57 21 267 58 21 dirt
execute in minecraft:overworld run setblock 267 59 21 gravel
execute in minecraft:overworld run fill 267 60 21 267 144 21 air
execute in minecraft:overworld run fill 267 60 21 267 64 21 water
execute in minecraft:overworld run fill 267 58 22 267 56 22 stone
execute in minecraft:overworld run fill 267 57 22 267 58 22 dirt
execute in minecraft:overworld run setblock 267 59 22 gravel
execute in minecraft:overworld run fill 267 60 22 267 144 22 air
execute in minecraft:overworld run fill 267 60 22 267 64 22 water
execute in minecraft:overworld run fill 267 58 23 267 56 23 stone
execute in minecraft:overworld run fill 267 57 23 267 58 23 dirt
execute in minecraft:overworld run setblock 267 59 23 gravel
execute in minecraft:overworld run fill 267 60 23 267 144 23 air
execute in minecraft:overworld run fill 267 60 23 267 64 23 water
execute in minecraft:overworld run fill 267 58 24 267 56 24 stone
execute in minecraft:overworld run fill 267 57 24 267 58 24 dirt
execute in minecraft:overworld run setblock 267 59 24 gravel
execute in minecraft:overworld run fill 267 60 24 267 144 24 air
execute in minecraft:overworld run fill 267 60 24 267 64 24 water
execute in minecraft:overworld run fill 267 58 25 267 56 25 stone
execute in minecraft:overworld run fill 267 57 25 267 58 25 dirt
execute in minecraft:overworld run setblock 267 59 25 gravel
execute in minecraft:overworld run fill 267 60 25 267 144 25 air
execute in minecraft:overworld run fill 267 60 25 267 64 25 water
execute in minecraft:overworld run fill 267 58 26 267 56 26 stone
execute in minecraft:overworld run fill 267 57 26 267 58 26 dirt
execute in minecraft:overworld run setblock 267 59 26 gravel
execute in minecraft:overworld run fill 267 60 26 267 144 26 air
execute in minecraft:overworld run fill 267 60 26 267 64 26 water
execute in minecraft:overworld run fill 267 58 27 267 56 27 stone
execute in minecraft:overworld run fill 267 57 27 267 58 27 dirt
execute in minecraft:overworld run setblock 267 59 27 gravel
execute in minecraft:overworld run fill 267 60 27 267 144 27 air
execute in minecraft:overworld run fill 267 60 27 267 64 27 water
execute in minecraft:overworld run fill 267 58 28 267 56 28 stone
execute in minecraft:overworld run fill 267 57 28 267 58 28 dirt
execute in minecraft:overworld run setblock 267 59 28 gravel
execute in minecraft:overworld run fill 267 60 28 267 144 28 air
execute in minecraft:overworld run fill 267 60 28 267 64 28 water
execute in minecraft:overworld run fill 267 58 29 267 56 29 stone
execute in minecraft:overworld run fill 267 57 29 267 58 29 dirt
execute in minecraft:overworld run setblock 267 59 29 gravel
execute in minecraft:overworld run fill 267 60 29 267 144 29 air
execute in minecraft:overworld run fill 267 60 29 267 64 29 water
execute in minecraft:overworld run fill 267 58 30 267 56 30 stone
execute in minecraft:overworld run fill 267 57 30 267 58 30 dirt
execute in minecraft:overworld run setblock 267 59 30 gravel
execute in minecraft:overworld run fill 267 60 30 267 144 30 air
execute in minecraft:overworld run fill 267 60 30 267 64 30 water
execute in minecraft:overworld run fill 267 58 31 267 56 31 stone
execute in minecraft:overworld run fill 267 57 31 267 58 31 dirt
execute in minecraft:overworld run setblock 267 59 31 gravel
execute in minecraft:overworld run fill 267 60 31 267 144 31 air
execute in minecraft:overworld run fill 267 60 31 267 64 31 water
execute in minecraft:overworld run fill 267 58 32 267 57 32 stone
execute in minecraft:overworld run fill 267 58 32 267 59 32 dirt
execute in minecraft:overworld run setblock 267 60 32 gravel
execute in minecraft:overworld run fill 267 61 32 267 144 32 air
execute in minecraft:overworld run fill 267 61 32 267 64 32 water
execute in minecraft:overworld run fill 267 58 33 267 57 33 stone
execute in minecraft:overworld run fill 267 58 33 267 59 33 dirt
execute in minecraft:overworld run setblock 267 60 33 gravel
execute in minecraft:overworld run fill 267 61 33 267 144 33 air
execute in minecraft:overworld run fill 267 61 33 267 64 33 water
execute in minecraft:overworld run fill 267 58 34 267 57 34 stone
execute in minecraft:overworld run fill 267 58 34 267 59 34 dirt
execute in minecraft:overworld run setblock 267 60 34 gravel
execute in minecraft:overworld run fill 267 61 34 267 144 34 air
execute in minecraft:overworld run fill 267 61 34 267 64 34 water
execute in minecraft:overworld run fill 267 58 35 267 57 35 stone
execute in minecraft:overworld run fill 267 58 35 267 59 35 dirt
execute in minecraft:overworld run setblock 267 60 35 gravel
execute in minecraft:overworld run fill 267 61 35 267 144 35 air
execute in minecraft:overworld run fill 267 61 35 267 64 35 water
execute in minecraft:overworld run fill 267 58 36 267 58 36 stone
execute in minecraft:overworld run fill 267 59 36 267 60 36 dirt
execute in minecraft:overworld run setblock 267 61 36 gravel
execute in minecraft:overworld run fill 267 62 36 267 144 36 air
execute in minecraft:overworld run fill 267 62 36 267 64 36 water
execute in minecraft:overworld run fill 267 58 37 267 58 37 stone
execute in minecraft:overworld run fill 267 59 37 267 60 37 dirt
execute in minecraft:overworld run setblock 267 61 37 gravel
execute in minecraft:overworld run fill 267 62 37 267 144 37 air
execute in minecraft:overworld run fill 267 62 37 267 64 37 water
execute in minecraft:overworld run fill 267 58 38 267 58 38 stone
execute in minecraft:overworld run fill 267 59 38 267 60 38 dirt
execute in minecraft:overworld run setblock 267 61 38 gravel
execute in minecraft:overworld run fill 267 62 38 267 144 38 air
execute in minecraft:overworld run fill 267 62 38 267 64 38 water
execute in minecraft:overworld run fill 267 58 39 267 59 39 stone
execute in minecraft:overworld run fill 267 60 39 267 61 39 dirt
execute in minecraft:overworld run setblock 267 62 39 gravel
execute in minecraft:overworld run fill 267 63 39 267 144 39 air
execute in minecraft:overworld run fill 267 63 39 267 64 39 water
execute in minecraft:overworld run fill 267 58 40 267 59 40 stone
execute in minecraft:overworld run fill 267 60 40 267 61 40 dirt
execute in minecraft:overworld run setblock 267 62 40 gravel
execute in minecraft:overworld run fill 267 63 40 267 144 40 air
execute in minecraft:overworld run fill 267 63 40 267 64 40 water
execute in minecraft:overworld run fill 267 58 41 267 60 41 stone
execute in minecraft:overworld run fill 267 61 41 267 62 41 dirt
execute in minecraft:overworld run setblock 267 63 41 gravel
execute in minecraft:overworld run fill 267 64 41 267 144 41 air
execute in minecraft:overworld run fill 267 64 41 267 64 41 water
execute in minecraft:overworld run fill 267 58 42 267 60 42 stone
execute in minecraft:overworld run fill 267 61 42 267 62 42 dirt
execute in minecraft:overworld run setblock 267 63 42 gravel
execute in minecraft:overworld run fill 267 64 42 267 144 42 air
execute in minecraft:overworld run fill 267 64 42 267 64 42 water
execute in minecraft:overworld run fill 267 58 43 267 60 43 stone
execute in minecraft:overworld run fill 267 61 43 267 62 43 dirt
execute in minecraft:overworld run setblock 267 63 43 gravel
execute in minecraft:overworld run fill 267 64 43 267 144 43 air
execute in minecraft:overworld run fill 267 64 43 267 64 43 water
execute in minecraft:overworld run fill 267 58 44 267 61 44 stone
execute in minecraft:overworld run fill 267 62 44 267 63 44 dirt
execute in minecraft:overworld run setblock 267 64 44 coarse_dirt
execute in minecraft:overworld run fill 267 65 44 267 144 44 air
execute in minecraft:overworld run fill 267 58 45 267 61 45 stone
execute in minecraft:overworld run fill 267 62 45 267 63 45 dirt
execute in minecraft:overworld run setblock 267 64 45 coarse_dirt
execute in minecraft:overworld run fill 267 65 45 267 144 45 air
execute in minecraft:overworld run fill 267 58 46 267 61 46 stone
execute in minecraft:overworld run fill 267 62 46 267 63 46 dirt
execute in minecraft:overworld run setblock 267 64 46 grass_block
execute in minecraft:overworld run fill 267 65 46 267 144 46 air
execute in minecraft:overworld run fill 267 58 47 267 61 47 stone
execute in minecraft:overworld run fill 267 62 47 267 63 47 dirt
execute in minecraft:overworld run setblock 267 64 47 coarse_dirt
execute in minecraft:overworld run fill 267 65 47 267 144 47 air
execute in minecraft:overworld run fill 268 58 -48 268 61 -48 stone
execute in minecraft:overworld run fill 268 62 -48 268 63 -48 dirt
execute in minecraft:overworld run setblock 268 64 -48 coarse_dirt
execute in minecraft:overworld run fill 268 65 -48 268 144 -48 air
execute in minecraft:overworld run fill 268 58 -47 268 63 -47 stone
execute in minecraft:overworld run fill 268 64 -47 268 65 -47 dirt
execute in minecraft:overworld run setblock 268 66 -47 coarse_dirt
execute in minecraft:overworld run fill 268 67 -47 268 144 -47 air
execute in minecraft:overworld run fill 268 58 -46 268 65 -46 stone
execute in minecraft:overworld run fill 268 66 -46 268 67 -46 dirt
execute in minecraft:overworld run setblock 268 68 -46 coarse_dirt
execute in minecraft:overworld run fill 268 69 -46 268 144 -46 air
execute in minecraft:overworld run fill 268 58 -45 268 67 -45 stone
execute in minecraft:overworld run fill 268 68 -45 268 69 -45 dirt
execute in minecraft:overworld run setblock 268 70 -45 coarse_dirt
execute in minecraft:overworld run fill 268 71 -45 268 144 -45 air
execute in minecraft:overworld run fill 268 58 -44 268 69 -44 stone
execute in minecraft:overworld run fill 268 70 -44 268 71 -44 dirt
execute in minecraft:overworld run setblock 268 72 -44 grass_block
execute in minecraft:overworld run fill 268 73 -44 268 144 -44 air
execute in minecraft:overworld run fill 268 58 -43 268 70 -43 stone
execute in minecraft:overworld run fill 268 71 -43 268 72 -43 dirt
execute in minecraft:overworld run setblock 268 73 -43 coarse_dirt
execute in minecraft:overworld run fill 268 74 -43 268 144 -43 air
execute in minecraft:overworld run fill 268 58 -42 268 72 -42 stone
execute in minecraft:overworld run fill 268 73 -42 268 74 -42 dirt
execute in minecraft:overworld run setblock 268 75 -42 coarse_dirt
execute in minecraft:overworld run fill 268 76 -42 268 144 -42 air
execute in minecraft:overworld run fill 268 58 -41 268 74 -41 stone
execute in minecraft:overworld run fill 268 75 -41 268 76 -41 dirt
execute in minecraft:overworld run setblock 268 77 -41 coarse_dirt
execute in minecraft:overworld run fill 268 78 -41 268 144 -41 air
execute in minecraft:overworld run fill 268 58 -40 268 75 -40 stone
execute in minecraft:overworld run fill 268 76 -40 268 77 -40 dirt
schedule function blade_gallery:random/burned/part_95 1t replace
