execute in minecraft:overworld run setblock 346 70 5 coarse_dirt
execute in minecraft:overworld run fill 346 71 5 346 144 5 air
execute in minecraft:overworld run fill 346 58 6 346 67 6 stone
execute in minecraft:overworld run fill 346 68 6 346 69 6 dirt
execute in minecraft:overworld run setblock 346 70 6 grass_block
execute in minecraft:overworld run fill 346 71 6 346 144 6 air
execute in minecraft:overworld run fill 346 58 7 346 67 7 stone
execute in minecraft:overworld run fill 346 68 7 346 69 7 dirt
execute in minecraft:overworld run setblock 346 70 7 grass_block
execute in minecraft:overworld run fill 346 71 7 346 144 7 air
execute in minecraft:overworld run setblock 346 71 7 grass
execute in minecraft:overworld run fill 346 58 8 346 67 8 stone
execute in minecraft:overworld run fill 346 68 8 346 69 8 dirt
execute in minecraft:overworld run setblock 346 70 8 coarse_dirt
execute in minecraft:overworld run fill 346 71 8 346 144 8 air
execute in minecraft:overworld run fill 346 58 9 346 67 9 stone
execute in minecraft:overworld run fill 346 68 9 346 69 9 dirt
execute in minecraft:overworld run setblock 346 70 9 coarse_dirt
execute in minecraft:overworld run fill 346 71 9 346 144 9 air
execute in minecraft:overworld run fill 346 58 10 346 67 10 stone
execute in minecraft:overworld run fill 346 68 10 346 69 10 dirt
execute in minecraft:overworld run setblock 346 70 10 coarse_dirt
execute in minecraft:overworld run fill 346 71 10 346 144 10 air
execute in minecraft:overworld run fill 346 58 11 346 66 11 stone
execute in minecraft:overworld run fill 346 67 11 346 68 11 dirt
execute in minecraft:overworld run setblock 346 69 11 grass_block
execute in minecraft:overworld run fill 346 70 11 346 144 11 air
execute in minecraft:overworld run fill 346 58 12 346 66 12 stone
execute in minecraft:overworld run fill 346 67 12 346 68 12 dirt
execute in minecraft:overworld run setblock 346 69 12 grass_block
execute in minecraft:overworld run fill 346 70 12 346 144 12 air
execute in minecraft:overworld run fill 346 58 13 346 66 13 stone
execute in minecraft:overworld run fill 346 67 13 346 68 13 dirt
execute in minecraft:overworld run setblock 346 69 13 grass_block
execute in minecraft:overworld run fill 346 70 13 346 144 13 air
execute in minecraft:overworld run fill 346 58 14 346 65 14 stone
execute in minecraft:overworld run fill 346 66 14 346 67 14 dirt
execute in minecraft:overworld run setblock 346 68 14 coarse_dirt
execute in minecraft:overworld run fill 346 69 14 346 144 14 air
execute in minecraft:overworld run fill 346 58 15 346 65 15 stone
execute in minecraft:overworld run fill 346 66 15 346 67 15 dirt
execute in minecraft:overworld run setblock 346 68 15 grass_block
execute in minecraft:overworld run fill 346 69 15 346 144 15 air
execute in minecraft:overworld run fill 346 58 16 346 65 16 stone
execute in minecraft:overworld run fill 346 66 16 346 67 16 dirt
execute in minecraft:overworld run setblock 346 68 16 coarse_dirt
execute in minecraft:overworld run fill 346 69 16 346 144 16 air
execute in minecraft:overworld run fill 346 58 17 346 64 17 stone
execute in minecraft:overworld run fill 346 65 17 346 66 17 dirt
execute in minecraft:overworld run setblock 346 67 17 coarse_dirt
execute in minecraft:overworld run fill 346 68 17 346 144 17 air
execute in minecraft:overworld run fill 346 58 18 346 64 18 stone
execute in minecraft:overworld run fill 346 65 18 346 66 18 dirt
execute in minecraft:overworld run setblock 346 67 18 coarse_dirt
execute in minecraft:overworld run fill 346 68 18 346 144 18 air
execute in minecraft:overworld run fill 346 58 19 346 64 19 stone
execute in minecraft:overworld run fill 346 65 19 346 66 19 dirt
execute in minecraft:overworld run setblock 346 67 19 grass_block
execute in minecraft:overworld run fill 346 68 19 346 144 19 air
execute in minecraft:overworld run fill 346 58 20 346 64 20 stone
execute in minecraft:overworld run fill 346 65 20 346 66 20 dirt
execute in minecraft:overworld run setblock 346 67 20 coarse_dirt
execute in minecraft:overworld run fill 346 68 20 346 144 20 air
execute in minecraft:overworld run fill 346 58 21 346 65 21 stone
execute in minecraft:overworld run fill 346 66 21 346 67 21 dirt
execute in minecraft:overworld run setblock 346 68 21 coarse_dirt
execute in minecraft:overworld run fill 346 69 21 346 144 21 air
execute in minecraft:overworld run fill 346 58 22 346 65 22 stone
execute in minecraft:overworld run fill 346 66 22 346 67 22 dirt
execute in minecraft:overworld run setblock 346 68 22 coarse_dirt
execute in minecraft:overworld run fill 346 69 22 346 144 22 air
execute in minecraft:overworld run fill 346 58 23 346 65 23 stone
execute in minecraft:overworld run fill 346 66 23 346 67 23 dirt
execute in minecraft:overworld run setblock 346 68 23 coarse_dirt
execute in minecraft:overworld run fill 346 69 23 346 144 23 air
execute in minecraft:overworld run fill 346 58 24 346 65 24 stone
execute in minecraft:overworld run fill 346 66 24 346 67 24 dirt
execute in minecraft:overworld run setblock 346 68 24 coarse_dirt
execute in minecraft:overworld run fill 346 69 24 346 144 24 air
execute in minecraft:overworld run fill 346 58 25 346 66 25 stone
execute in minecraft:overworld run fill 346 67 25 346 68 25 dirt
execute in minecraft:overworld run setblock 346 69 25 grass_block
execute in minecraft:overworld run fill 346 70 25 346 144 25 air
execute in minecraft:overworld run fill 346 58 26 346 66 26 stone
execute in minecraft:overworld run fill 346 67 26 346 68 26 dirt
execute in minecraft:overworld run setblock 346 69 26 grass_block
execute in minecraft:overworld run fill 346 70 26 346 144 26 air
execute in minecraft:overworld run setblock 346 70 26 grass
execute in minecraft:overworld run fill 346 58 27 346 66 27 stone
execute in minecraft:overworld run fill 346 67 27 346 68 27 dirt
execute in minecraft:overworld run setblock 346 69 27 coarse_dirt
execute in minecraft:overworld run fill 346 70 27 346 144 27 air
execute in minecraft:overworld run fill 346 58 28 346 66 28 stone
execute in minecraft:overworld run fill 346 67 28 346 68 28 dirt
execute in minecraft:overworld run setblock 346 69 28 coarse_dirt
execute in minecraft:overworld run fill 346 70 28 346 144 28 air
execute in minecraft:overworld run fill 346 58 29 346 66 29 stone
execute in minecraft:overworld run fill 346 67 29 346 68 29 dirt
execute in minecraft:overworld run setblock 346 69 29 coarse_dirt
execute in minecraft:overworld run fill 346 70 29 346 144 29 air
execute in minecraft:overworld run fill 346 58 30 346 66 30 stone
execute in minecraft:overworld run fill 346 67 30 346 68 30 dirt
execute in minecraft:overworld run setblock 346 69 30 grass_block
execute in minecraft:overworld run fill 346 70 30 346 144 30 air
execute in minecraft:overworld run fill 346 58 31 346 65 31 stone
execute in minecraft:overworld run fill 346 66 31 346 67 31 dirt
execute in minecraft:overworld run setblock 346 68 31 coarse_dirt
execute in minecraft:overworld run fill 346 69 31 346 144 31 air
execute in minecraft:overworld run fill 346 58 32 346 65 32 stone
execute in minecraft:overworld run fill 346 66 32 346 67 32 dirt
execute in minecraft:overworld run setblock 346 68 32 coarse_dirt
execute in minecraft:overworld run fill 346 69 32 346 144 32 air
execute in minecraft:overworld run fill 346 58 33 346 65 33 stone
execute in minecraft:overworld run fill 346 66 33 346 67 33 dirt
execute in minecraft:overworld run setblock 346 68 33 coarse_dirt
execute in minecraft:overworld run fill 346 69 33 346 144 33 air
execute in minecraft:overworld run fill 346 58 34 346 65 34 stone
execute in minecraft:overworld run fill 346 66 34 346 67 34 dirt
execute in minecraft:overworld run setblock 346 68 34 coarse_dirt
execute in minecraft:overworld run fill 346 69 34 346 144 34 air
execute in minecraft:overworld run fill 346 58 35 346 65 35 stone
execute in minecraft:overworld run fill 346 66 35 346 67 35 dirt
execute in minecraft:overworld run setblock 346 68 35 grass_block
execute in minecraft:overworld run fill 346 69 35 346 144 35 air
execute in minecraft:overworld run fill 346 58 36 346 65 36 stone
execute in minecraft:overworld run fill 346 66 36 346 67 36 dirt
execute in minecraft:overworld run setblock 346 68 36 coarse_dirt
execute in minecraft:overworld run fill 346 69 36 346 144 36 air
execute in minecraft:overworld run fill 346 58 37 346 65 37 stone
execute in minecraft:overworld run fill 346 66 37 346 67 37 dirt
execute in minecraft:overworld run setblock 346 68 37 coarse_dirt
execute in minecraft:overworld run fill 346 69 37 346 144 37 air
execute in minecraft:overworld run setblock 346 69 37 grass
execute in minecraft:overworld run fill 346 58 38 346 65 38 stone
execute in minecraft:overworld run fill 346 66 38 346 67 38 dirt
execute in minecraft:overworld run setblock 346 68 38 coarse_dirt
execute in minecraft:overworld run fill 346 69 38 346 144 38 air
execute in minecraft:overworld run fill 346 58 39 346 65 39 stone
execute in minecraft:overworld run fill 346 66 39 346 67 39 dirt
execute in minecraft:overworld run setblock 346 68 39 coarse_dirt
execute in minecraft:overworld run fill 346 69 39 346 144 39 air
execute in minecraft:overworld run fill 346 58 40 346 64 40 stone
execute in minecraft:overworld run fill 346 65 40 346 66 40 dirt
execute in minecraft:overworld run setblock 346 67 40 grass_block
execute in minecraft:overworld run fill 346 68 40 346 144 40 air
execute in minecraft:overworld run fill 346 58 41 346 64 41 stone
execute in minecraft:overworld run fill 346 65 41 346 66 41 dirt
execute in minecraft:overworld run setblock 346 67 41 grass_block
execute in minecraft:overworld run fill 346 68 41 346 144 41 air
execute in minecraft:overworld run fill 346 58 42 346 64 42 stone
execute in minecraft:overworld run fill 346 65 42 346 66 42 dirt
execute in minecraft:overworld run setblock 346 67 42 coarse_dirt
execute in minecraft:overworld run fill 346 68 42 346 144 42 air
execute in minecraft:overworld run fill 346 58 43 346 63 43 stone
execute in minecraft:overworld run fill 346 64 43 346 65 43 dirt
execute in minecraft:overworld run setblock 346 66 43 coarse_dirt
execute in minecraft:overworld run fill 346 67 43 346 144 43 air
execute in minecraft:overworld run fill 346 58 44 346 63 44 stone
execute in minecraft:overworld run fill 346 64 44 346 65 44 dirt
execute in minecraft:overworld run setblock 346 66 44 grass_block
execute in minecraft:overworld run fill 346 67 44 346 144 44 air
execute in minecraft:overworld run fill 346 58 45 346 62 45 stone
execute in minecraft:overworld run fill 346 63 45 346 64 45 dirt
execute in minecraft:overworld run setblock 346 65 45 coarse_dirt
execute in minecraft:overworld run fill 346 66 45 346 144 45 air
execute in minecraft:overworld run fill 346 58 46 346 62 46 stone
execute in minecraft:overworld run fill 346 63 46 346 64 46 dirt
execute in minecraft:overworld run setblock 346 65 46 grass_block
execute in minecraft:overworld run fill 346 66 46 346 144 46 air
execute in minecraft:overworld run fill 346 58 47 346 61 47 stone
execute in minecraft:overworld run fill 346 62 47 346 63 47 dirt
execute in minecraft:overworld run setblock 346 64 47 coarse_dirt
execute in minecraft:overworld run fill 346 65 47 346 144 47 air
execute in minecraft:overworld run fill 347 58 -48 347 61 -48 stone
execute in minecraft:overworld run fill 347 62 -48 347 63 -48 dirt
execute in minecraft:overworld run setblock 347 64 -48 coarse_dirt
execute in minecraft:overworld run fill 347 65 -48 347 144 -48 air
execute in minecraft:overworld run fill 347 58 -47 347 63 -47 stone
execute in minecraft:overworld run fill 347 64 -47 347 65 -47 dirt
execute in minecraft:overworld run setblock 347 66 -47 coarse_dirt
execute in minecraft:overworld run fill 347 67 -47 347 144 -47 air
execute in minecraft:overworld run fill 347 58 -46 347 65 -46 stone
execute in minecraft:overworld run fill 347 66 -46 347 67 -46 dirt
execute in minecraft:overworld run setblock 347 68 -46 grass_block
execute in minecraft:overworld run fill 347 69 -46 347 144 -46 air
execute in minecraft:overworld run fill 347 58 -45 347 66 -45 stone
execute in minecraft:overworld run fill 347 67 -45 347 68 -45 dirt
execute in minecraft:overworld run setblock 347 69 -45 coarse_dirt
execute in minecraft:overworld run fill 347 70 -45 347 144 -45 air
execute in minecraft:overworld run fill 347 58 -44 347 68 -44 stone
execute in minecraft:overworld run fill 347 69 -44 347 70 -44 dirt
execute in minecraft:overworld run setblock 347 71 -44 coarse_dirt
execute in minecraft:overworld run fill 347 72 -44 347 144 -44 air
execute in minecraft:overworld run fill 347 58 -43 347 70 -43 stone
execute in minecraft:overworld run fill 347 71 -43 347 72 -43 dirt
execute in minecraft:overworld run setblock 347 73 -43 coarse_dirt
execute in minecraft:overworld run fill 347 74 -43 347 144 -43 air
execute in minecraft:overworld run fill 347 58 -42 347 71 -42 stone
execute in minecraft:overworld run fill 347 72 -42 347 73 -42 dirt
execute in minecraft:overworld run setblock 347 74 -42 coarse_dirt
execute in minecraft:overworld run fill 347 75 -42 347 144 -42 air
execute in minecraft:overworld run fill 347 58 -41 347 73 -41 stone
execute in minecraft:overworld run fill 347 74 -41 347 75 -41 dirt
execute in minecraft:overworld run setblock 347 76 -41 coarse_dirt
execute in minecraft:overworld run fill 347 77 -41 347 144 -41 air
execute in minecraft:overworld run fill 347 58 -40 347 74 -40 stone
execute in minecraft:overworld run fill 347 75 -40 347 76 -40 dirt
execute in minecraft:overworld run setblock 347 77 -40 coarse_dirt
execute in minecraft:overworld run fill 347 78 -40 347 144 -40 air
execute in minecraft:overworld run fill 347 58 -39 347 75 -39 stone
execute in minecraft:overworld run fill 347 76 -39 347 77 -39 dirt
execute in minecraft:overworld run setblock 347 78 -39 coarse_dirt
execute in minecraft:overworld run fill 347 79 -39 347 144 -39 air
execute in minecraft:overworld run fill 347 58 -38 347 76 -38 stone
execute in minecraft:overworld run fill 347 77 -38 347 78 -38 dirt
execute in minecraft:overworld run setblock 347 79 -38 coarse_dirt
execute in minecraft:overworld run fill 347 80 -38 347 144 -38 air
execute in minecraft:overworld run fill 347 58 -37 347 76 -37 stone
execute in minecraft:overworld run fill 347 77 -37 347 78 -37 dirt
execute in minecraft:overworld run setblock 347 79 -37 coarse_dirt
execute in minecraft:overworld run fill 347 80 -37 347 144 -37 air
execute in minecraft:overworld run fill 347 58 -36 347 76 -36 stone
execute in minecraft:overworld run fill 347 77 -36 347 78 -36 dirt
execute in minecraft:overworld run setblock 347 79 -36 coarse_dirt
execute in minecraft:overworld run fill 347 80 -36 347 144 -36 air
execute in minecraft:overworld run fill 347 58 -35 347 75 -35 stone
execute in minecraft:overworld run fill 347 76 -35 347 77 -35 dirt
execute in minecraft:overworld run setblock 347 78 -35 coarse_dirt
execute in minecraft:overworld run fill 347 79 -35 347 144 -35 air
execute in minecraft:overworld run fill 347 58 -34 347 75 -34 stone
execute in minecraft:overworld run fill 347 76 -34 347 77 -34 dirt
execute in minecraft:overworld run setblock 347 78 -34 coarse_dirt
execute in minecraft:overworld run fill 347 79 -34 347 144 -34 air
execute in minecraft:overworld run fill 347 58 -33 347 75 -33 stone
execute in minecraft:overworld run fill 347 76 -33 347 77 -33 dirt
execute in minecraft:overworld run setblock 347 78 -33 coarse_dirt
execute in minecraft:overworld run fill 347 79 -33 347 144 -33 air
execute in minecraft:overworld run fill 347 58 -32 347 75 -32 stone
execute in minecraft:overworld run fill 347 76 -32 347 77 -32 dirt
execute in minecraft:overworld run setblock 347 78 -32 grass_block
execute in minecraft:overworld run fill 347 79 -32 347 144 -32 air
execute in minecraft:overworld run fill 347 58 -31 347 74 -31 stone
execute in minecraft:overworld run fill 347 75 -31 347 76 -31 dirt
execute in minecraft:overworld run setblock 347 77 -31 coarse_dirt
execute in minecraft:overworld run fill 347 78 -31 347 144 -31 air
execute in minecraft:overworld run fill 347 58 -30 347 74 -30 stone
execute in minecraft:overworld run fill 347 75 -30 347 76 -30 dirt
execute in minecraft:overworld run setblock 347 77 -30 coarse_dirt
execute in minecraft:overworld run fill 347 78 -30 347 144 -30 air
execute in minecraft:overworld run fill 347 58 -29 347 74 -29 stone
execute in minecraft:overworld run fill 347 75 -29 347 76 -29 dirt
execute in minecraft:overworld run setblock 347 77 -29 coarse_dirt
execute in minecraft:overworld run fill 347 78 -29 347 144 -29 air
execute in minecraft:overworld run fill 347 58 -28 347 74 -28 stone
execute in minecraft:overworld run fill 347 75 -28 347 76 -28 dirt
execute in minecraft:overworld run setblock 347 77 -28 grass_block
schedule function blade_gallery:random/battlefield/part_17 1t replace
