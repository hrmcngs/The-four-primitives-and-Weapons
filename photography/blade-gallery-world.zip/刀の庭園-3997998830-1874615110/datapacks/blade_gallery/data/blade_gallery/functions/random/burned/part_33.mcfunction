execute in minecraft:overworld run fill 229 58 7 229 66 7 stone
execute in minecraft:overworld run fill 229 67 7 229 68 7 dirt
execute in minecraft:overworld run setblock 229 69 7 coarse_dirt
execute in minecraft:overworld run fill 229 70 7 229 144 7 air
execute in minecraft:overworld run fill 229 58 8 229 66 8 stone
execute in minecraft:overworld run fill 229 67 8 229 68 8 dirt
execute in minecraft:overworld run setblock 229 69 8 coarse_dirt
execute in minecraft:overworld run fill 229 70 8 229 144 8 air
execute in minecraft:overworld run setblock 229 70 8 grass
execute in minecraft:overworld run fill 229 58 9 229 66 9 stone
execute in minecraft:overworld run fill 229 67 9 229 68 9 dirt
execute in minecraft:overworld run setblock 229 69 9 coarse_dirt
execute in minecraft:overworld run fill 229 70 9 229 144 9 air
execute in minecraft:overworld run fill 229 58 10 229 67 10 stone
execute in minecraft:overworld run fill 229 68 10 229 69 10 dirt
execute in minecraft:overworld run setblock 229 70 10 grass_block
execute in minecraft:overworld run fill 229 71 10 229 144 10 air
execute in minecraft:overworld run fill 229 58 11 229 67 11 stone
execute in minecraft:overworld run fill 229 68 11 229 69 11 dirt
execute in minecraft:overworld run setblock 229 70 11 coarse_dirt
execute in minecraft:overworld run fill 229 71 11 229 144 11 air
execute in minecraft:overworld run fill 229 58 12 229 67 12 stone
execute in minecraft:overworld run fill 229 68 12 229 69 12 dirt
execute in minecraft:overworld run setblock 229 70 12 grass_block
execute in minecraft:overworld run fill 229 71 12 229 144 12 air
execute in minecraft:overworld run fill 229 58 13 229 68 13 stone
execute in minecraft:overworld run fill 229 69 13 229 70 13 dirt
execute in minecraft:overworld run setblock 229 71 13 coarse_dirt
execute in minecraft:overworld run fill 229 72 13 229 144 13 air
execute in minecraft:overworld run fill 229 58 14 229 68 14 stone
execute in minecraft:overworld run fill 229 69 14 229 70 14 dirt
execute in minecraft:overworld run setblock 229 71 14 coarse_dirt
execute in minecraft:overworld run fill 229 72 14 229 144 14 air
execute in minecraft:overworld run fill 229 58 15 229 68 15 stone
execute in minecraft:overworld run fill 229 69 15 229 70 15 dirt
execute in minecraft:overworld run setblock 229 71 15 grass_block
execute in minecraft:overworld run fill 229 72 15 229 144 15 air
execute in minecraft:overworld run fill 229 58 16 229 69 16 stone
execute in minecraft:overworld run fill 229 70 16 229 71 16 dirt
execute in minecraft:overworld run setblock 229 72 16 coarse_dirt
execute in minecraft:overworld run fill 229 73 16 229 144 16 air
execute in minecraft:overworld run fill 229 58 17 229 69 17 stone
execute in minecraft:overworld run fill 229 70 17 229 71 17 dirt
execute in minecraft:overworld run setblock 229 72 17 coarse_dirt
execute in minecraft:overworld run fill 229 73 17 229 144 17 air
execute in minecraft:overworld run fill 229 58 18 229 69 18 stone
execute in minecraft:overworld run fill 229 70 18 229 71 18 dirt
execute in minecraft:overworld run setblock 229 72 18 coarse_dirt
execute in minecraft:overworld run fill 229 73 18 229 144 18 air
execute in minecraft:overworld run fill 229 58 19 229 69 19 stone
execute in minecraft:overworld run fill 229 70 19 229 71 19 dirt
execute in minecraft:overworld run setblock 229 72 19 grass_block
execute in minecraft:overworld run fill 229 73 19 229 144 19 air
execute in minecraft:overworld run fill 229 58 20 229 70 20 stone
execute in minecraft:overworld run fill 229 71 20 229 72 20 dirt
execute in minecraft:overworld run setblock 229 73 20 coarse_dirt
execute in minecraft:overworld run fill 229 74 20 229 144 20 air
execute in minecraft:overworld run setblock 229 74 20 grass
execute in minecraft:overworld run fill 229 58 21 229 70 21 stone
execute in minecraft:overworld run fill 229 71 21 229 72 21 dirt
execute in minecraft:overworld run setblock 229 73 21 coarse_dirt
execute in minecraft:overworld run fill 229 74 21 229 144 21 air
execute in minecraft:overworld run fill 229 58 22 229 70 22 stone
execute in minecraft:overworld run fill 229 71 22 229 72 22 dirt
execute in minecraft:overworld run setblock 229 73 22 coarse_dirt
execute in minecraft:overworld run fill 229 74 22 229 144 22 air
execute in minecraft:overworld run fill 229 58 23 229 70 23 stone
execute in minecraft:overworld run fill 229 71 23 229 72 23 dirt
execute in minecraft:overworld run setblock 229 73 23 coarse_dirt
execute in minecraft:overworld run fill 229 74 23 229 144 23 air
execute in minecraft:overworld run fill 229 58 24 229 70 24 stone
execute in minecraft:overworld run fill 229 71 24 229 72 24 dirt
execute in minecraft:overworld run setblock 229 73 24 coarse_dirt
execute in minecraft:overworld run fill 229 74 24 229 144 24 air
execute in minecraft:overworld run fill 229 58 25 229 70 25 stone
execute in minecraft:overworld run fill 229 71 25 229 72 25 dirt
execute in minecraft:overworld run setblock 229 73 25 coarse_dirt
execute in minecraft:overworld run fill 229 74 25 229 144 25 air
execute in minecraft:overworld run fill 229 58 26 229 70 26 stone
execute in minecraft:overworld run fill 229 71 26 229 72 26 dirt
execute in minecraft:overworld run setblock 229 73 26 grass_block
execute in minecraft:overworld run fill 229 74 26 229 144 26 air
execute in minecraft:overworld run fill 229 58 27 229 70 27 stone
execute in minecraft:overworld run fill 229 71 27 229 72 27 dirt
execute in minecraft:overworld run setblock 229 73 27 grass_block
execute in minecraft:overworld run fill 229 74 27 229 144 27 air
execute in minecraft:overworld run setblock 229 74 27 grass
execute in minecraft:overworld run fill 229 58 28 229 70 28 stone
execute in minecraft:overworld run fill 229 71 28 229 72 28 dirt
execute in minecraft:overworld run setblock 229 73 28 coarse_dirt
execute in minecraft:overworld run fill 229 74 28 229 144 28 air
execute in minecraft:overworld run fill 229 58 29 229 70 29 stone
execute in minecraft:overworld run fill 229 71 29 229 72 29 dirt
execute in minecraft:overworld run setblock 229 73 29 coarse_dirt
execute in minecraft:overworld run fill 229 74 29 229 144 29 air
execute in minecraft:overworld run fill 229 58 30 229 70 30 stone
execute in minecraft:overworld run fill 229 71 30 229 72 30 dirt
execute in minecraft:overworld run setblock 229 73 30 coarse_dirt
execute in minecraft:overworld run fill 229 74 30 229 144 30 air
execute in minecraft:overworld run fill 229 58 31 229 70 31 stone
execute in minecraft:overworld run fill 229 71 31 229 72 31 dirt
execute in minecraft:overworld run setblock 229 73 31 grass_block
execute in minecraft:overworld run fill 229 74 31 229 144 31 air
execute in minecraft:overworld run fill 229 58 32 229 70 32 stone
execute in minecraft:overworld run fill 229 71 32 229 72 32 dirt
execute in minecraft:overworld run setblock 229 73 32 coarse_dirt
execute in minecraft:overworld run fill 229 74 32 229 144 32 air
execute in minecraft:overworld run fill 229 58 33 229 70 33 stone
execute in minecraft:overworld run fill 229 71 33 229 72 33 dirt
execute in minecraft:overworld run setblock 229 73 33 coarse_dirt
execute in minecraft:overworld run fill 229 74 33 229 144 33 air
execute in minecraft:overworld run fill 229 58 34 229 69 34 stone
execute in minecraft:overworld run fill 229 70 34 229 71 34 dirt
execute in minecraft:overworld run setblock 229 72 34 coarse_dirt
execute in minecraft:overworld run fill 229 73 34 229 144 34 air
execute in minecraft:overworld run fill 229 58 35 229 69 35 stone
execute in minecraft:overworld run fill 229 70 35 229 71 35 dirt
execute in minecraft:overworld run setblock 229 72 35 grass_block
execute in minecraft:overworld run fill 229 73 35 229 144 35 air
execute in minecraft:overworld run fill 229 58 36 229 69 36 stone
execute in minecraft:overworld run fill 229 70 36 229 71 36 dirt
execute in minecraft:overworld run setblock 229 72 36 coarse_dirt
execute in minecraft:overworld run fill 229 73 36 229 144 36 air
execute in minecraft:overworld run setblock 229 73 36 grass
execute in minecraft:overworld run fill 229 58 37 229 68 37 stone
execute in minecraft:overworld run fill 229 69 37 229 70 37 dirt
execute in minecraft:overworld run setblock 229 71 37 grass_block
execute in minecraft:overworld run fill 229 72 37 229 144 37 air
execute in minecraft:overworld run fill 229 58 38 229 68 38 stone
execute in minecraft:overworld run fill 229 69 38 229 70 38 dirt
execute in minecraft:overworld run setblock 229 71 38 coarse_dirt
execute in minecraft:overworld run fill 229 72 38 229 144 38 air
execute in minecraft:overworld run fill 229 58 39 229 67 39 stone
execute in minecraft:overworld run fill 229 68 39 229 69 39 dirt
execute in minecraft:overworld run setblock 229 70 39 grass_block
execute in minecraft:overworld run fill 229 71 39 229 144 39 air
execute in minecraft:overworld run fill 229 58 40 229 66 40 stone
execute in minecraft:overworld run fill 229 67 40 229 68 40 dirt
execute in minecraft:overworld run setblock 229 69 40 coarse_dirt
execute in minecraft:overworld run fill 229 70 40 229 144 40 air
execute in minecraft:overworld run fill 229 58 41 229 65 41 stone
execute in minecraft:overworld run fill 229 66 41 229 67 41 dirt
execute in minecraft:overworld run setblock 229 68 41 coarse_dirt
execute in minecraft:overworld run fill 229 69 41 229 144 41 air
execute in minecraft:overworld run fill 229 58 42 229 64 42 stone
execute in minecraft:overworld run fill 229 65 42 229 66 42 dirt
execute in minecraft:overworld run setblock 229 67 42 grass_block
execute in minecraft:overworld run fill 229 68 42 229 144 42 air
execute in minecraft:overworld run fill 229 58 43 229 63 43 stone
execute in minecraft:overworld run fill 229 64 43 229 65 43 dirt
execute in minecraft:overworld run setblock 229 66 43 coarse_dirt
execute in minecraft:overworld run fill 229 67 43 229 144 43 air
execute in minecraft:overworld run fill 229 58 44 229 62 44 stone
execute in minecraft:overworld run fill 229 63 44 229 64 44 dirt
execute in minecraft:overworld run setblock 229 65 44 coarse_dirt
execute in minecraft:overworld run fill 229 66 44 229 144 44 air
execute in minecraft:overworld run fill 229 58 45 229 62 45 stone
execute in minecraft:overworld run fill 229 63 45 229 64 45 dirt
execute in minecraft:overworld run setblock 229 65 45 coarse_dirt
execute in minecraft:overworld run fill 229 66 45 229 144 45 air
execute in minecraft:overworld run fill 229 58 46 229 62 46 stone
execute in minecraft:overworld run fill 229 63 46 229 64 46 dirt
execute in minecraft:overworld run setblock 229 65 46 coarse_dirt
execute in minecraft:overworld run fill 229 66 46 229 144 46 air
execute in minecraft:overworld run fill 229 58 47 229 61 47 stone
execute in minecraft:overworld run fill 229 62 47 229 63 47 dirt
execute in minecraft:overworld run setblock 229 64 47 coarse_dirt
execute in minecraft:overworld run fill 229 65 47 229 144 47 air
execute in minecraft:overworld run fill 230 58 -48 230 61 -48 stone
execute in minecraft:overworld run fill 230 62 -48 230 63 -48 dirt
execute in minecraft:overworld run setblock 230 64 -48 grass_block
execute in minecraft:overworld run fill 230 65 -48 230 144 -48 air
execute in minecraft:overworld run fill 230 58 -47 230 63 -47 stone
execute in minecraft:overworld run fill 230 64 -47 230 65 -47 dirt
execute in minecraft:overworld run setblock 230 66 -47 coarse_dirt
execute in minecraft:overworld run fill 230 67 -47 230 144 -47 air
execute in minecraft:overworld run fill 230 58 -46 230 64 -46 stone
execute in minecraft:overworld run fill 230 65 -46 230 66 -46 dirt
execute in minecraft:overworld run setblock 230 67 -46 grass_block
execute in minecraft:overworld run fill 230 68 -46 230 144 -46 air
execute in minecraft:overworld run fill 230 58 -45 230 66 -45 stone
execute in minecraft:overworld run fill 230 67 -45 230 68 -45 dirt
execute in minecraft:overworld run setblock 230 69 -45 coarse_dirt
execute in minecraft:overworld run fill 230 70 -45 230 144 -45 air
execute in minecraft:overworld run fill 230 58 -44 230 67 -44 stone
execute in minecraft:overworld run fill 230 68 -44 230 69 -44 dirt
execute in minecraft:overworld run setblock 230 70 -44 coarse_dirt
execute in minecraft:overworld run fill 230 71 -44 230 144 -44 air
execute in minecraft:overworld run fill 230 58 -43 230 68 -43 stone
execute in minecraft:overworld run fill 230 69 -43 230 70 -43 dirt
execute in minecraft:overworld run setblock 230 71 -43 grass_block
execute in minecraft:overworld run fill 230 72 -43 230 144 -43 air
execute in minecraft:overworld run fill 230 58 -42 230 69 -42 stone
execute in minecraft:overworld run fill 230 70 -42 230 71 -42 dirt
execute in minecraft:overworld run setblock 230 72 -42 coarse_dirt
execute in minecraft:overworld run fill 230 73 -42 230 144 -42 air
execute in minecraft:overworld run fill 230 58 -41 230 70 -41 stone
execute in minecraft:overworld run fill 230 71 -41 230 72 -41 dirt
execute in minecraft:overworld run setblock 230 73 -41 grass_block
execute in minecraft:overworld run fill 230 74 -41 230 144 -41 air
execute in minecraft:overworld run fill 230 58 -40 230 71 -40 stone
execute in minecraft:overworld run fill 230 72 -40 230 73 -40 dirt
execute in minecraft:overworld run setblock 230 74 -40 grass_block
execute in minecraft:overworld run fill 230 75 -40 230 144 -40 air
execute in minecraft:overworld run fill 230 58 -39 230 72 -39 stone
execute in minecraft:overworld run fill 230 73 -39 230 74 -39 dirt
execute in minecraft:overworld run setblock 230 75 -39 coarse_dirt
execute in minecraft:overworld run fill 230 76 -39 230 144 -39 air
execute in minecraft:overworld run fill 230 58 -38 230 73 -38 stone
execute in minecraft:overworld run fill 230 74 -38 230 75 -38 dirt
execute in minecraft:overworld run setblock 230 76 -38 coarse_dirt
execute in minecraft:overworld run fill 230 77 -38 230 144 -38 air
execute in minecraft:overworld run fill 230 58 -37 230 72 -37 stone
execute in minecraft:overworld run fill 230 73 -37 230 74 -37 dirt
execute in minecraft:overworld run setblock 230 75 -37 coarse_dirt
execute in minecraft:overworld run fill 230 76 -37 230 144 -37 air
execute in minecraft:overworld run fill 230 58 -36 230 72 -36 stone
execute in minecraft:overworld run fill 230 73 -36 230 74 -36 dirt
execute in minecraft:overworld run setblock 230 75 -36 coarse_dirt
execute in minecraft:overworld run fill 230 76 -36 230 144 -36 air
execute in minecraft:overworld run fill 230 58 -35 230 71 -35 stone
execute in minecraft:overworld run fill 230 72 -35 230 73 -35 dirt
execute in minecraft:overworld run setblock 230 74 -35 coarse_dirt
execute in minecraft:overworld run fill 230 75 -35 230 144 -35 air
execute in minecraft:overworld run fill 230 58 -34 230 71 -34 stone
execute in minecraft:overworld run fill 230 72 -34 230 73 -34 dirt
execute in minecraft:overworld run setblock 230 74 -34 coarse_dirt
execute in minecraft:overworld run fill 230 75 -34 230 144 -34 air
execute in minecraft:overworld run fill 230 58 -33 230 70 -33 stone
execute in minecraft:overworld run fill 230 71 -33 230 72 -33 dirt
execute in minecraft:overworld run setblock 230 73 -33 coarse_dirt
execute in minecraft:overworld run fill 230 74 -33 230 144 -33 air
execute in minecraft:overworld run fill 230 58 -32 230 70 -32 stone
execute in minecraft:overworld run fill 230 71 -32 230 72 -32 dirt
execute in minecraft:overworld run setblock 230 73 -32 coarse_dirt
execute in minecraft:overworld run fill 230 74 -32 230 144 -32 air
execute in minecraft:overworld run fill 230 58 -31 230 69 -31 stone
execute in minecraft:overworld run fill 230 70 -31 230 71 -31 dirt
execute in minecraft:overworld run setblock 230 72 -31 grass_block
execute in minecraft:overworld run fill 230 73 -31 230 144 -31 air
execute in minecraft:overworld run fill 230 58 -30 230 69 -30 stone
execute in minecraft:overworld run fill 230 70 -30 230 71 -30 dirt
execute in minecraft:overworld run setblock 230 72 -30 grass_block
execute in minecraft:overworld run fill 230 73 -30 230 144 -30 air
execute in minecraft:overworld run fill 230 58 -29 230 68 -29 stone
execute in minecraft:overworld run fill 230 69 -29 230 70 -29 dirt
execute in minecraft:overworld run setblock 230 71 -29 coarse_dirt
execute in minecraft:overworld run fill 230 72 -29 230 144 -29 air
execute in minecraft:overworld run fill 230 58 -28 230 68 -28 stone
execute in minecraft:overworld run fill 230 69 -28 230 70 -28 dirt
execute in minecraft:overworld run setblock 230 71 -28 coarse_dirt
execute in minecraft:overworld run fill 230 72 -28 230 144 -28 air
execute in minecraft:overworld run fill 230 58 -27 230 68 -27 stone
execute in minecraft:overworld run fill 230 69 -27 230 70 -27 dirt
execute in minecraft:overworld run setblock 230 71 -27 coarse_dirt
execute in minecraft:overworld run fill 230 72 -27 230 144 -27 air
schedule function blade_gallery:random/burned/part_34 1t replace
