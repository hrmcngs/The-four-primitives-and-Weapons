execute in minecraft:overworld run fill 359 70 4 359 144 4 air
execute in minecraft:overworld run fill 359 58 5 359 67 5 stone
execute in minecraft:overworld run fill 359 68 5 359 69 5 dirt
execute in minecraft:overworld run setblock 359 70 5 coarse_dirt
execute in minecraft:overworld run fill 359 71 5 359 144 5 air
execute in minecraft:overworld run fill 359 58 6 359 67 6 stone
execute in minecraft:overworld run fill 359 68 6 359 69 6 dirt
execute in minecraft:overworld run setblock 359 70 6 coarse_dirt
execute in minecraft:overworld run fill 359 71 6 359 144 6 air
execute in minecraft:overworld run fill 359 58 7 359 67 7 stone
execute in minecraft:overworld run fill 359 68 7 359 69 7 dirt
execute in minecraft:overworld run setblock 359 70 7 grass_block
execute in minecraft:overworld run fill 359 71 7 359 144 7 air
execute in minecraft:overworld run fill 359 58 8 359 68 8 stone
execute in minecraft:overworld run fill 359 69 8 359 70 8 dirt
execute in minecraft:overworld run setblock 359 71 8 coarse_dirt
execute in minecraft:overworld run fill 359 72 8 359 144 8 air
execute in minecraft:overworld run fill 359 58 9 359 68 9 stone
execute in minecraft:overworld run fill 359 69 9 359 70 9 dirt
execute in minecraft:overworld run setblock 359 71 9 coarse_dirt
execute in minecraft:overworld run fill 359 72 9 359 144 9 air
execute in minecraft:overworld run fill 359 58 10 359 68 10 stone
execute in minecraft:overworld run fill 359 69 10 359 70 10 dirt
execute in minecraft:overworld run setblock 359 71 10 grass_block
execute in minecraft:overworld run fill 359 72 10 359 144 10 air
execute in minecraft:overworld run fill 359 58 11 359 68 11 stone
execute in minecraft:overworld run fill 359 69 11 359 70 11 dirt
execute in minecraft:overworld run setblock 359 71 11 grass_block
execute in minecraft:overworld run fill 359 72 11 359 144 11 air
execute in minecraft:overworld run fill 359 58 12 359 68 12 stone
execute in minecraft:overworld run fill 359 69 12 359 70 12 dirt
execute in minecraft:overworld run setblock 359 71 12 coarse_dirt
execute in minecraft:overworld run fill 359 72 12 359 144 12 air
execute in minecraft:overworld run fill 359 58 13 359 68 13 stone
execute in minecraft:overworld run fill 359 69 13 359 70 13 dirt
execute in minecraft:overworld run setblock 359 71 13 coarse_dirt
execute in minecraft:overworld run fill 359 72 13 359 144 13 air
execute in minecraft:overworld run fill 359 58 14 359 69 14 stone
execute in minecraft:overworld run fill 359 70 14 359 71 14 dirt
execute in minecraft:overworld run setblock 359 72 14 coarse_dirt
execute in minecraft:overworld run fill 359 73 14 359 144 14 air
execute in minecraft:overworld run fill 359 58 15 359 69 15 stone
execute in minecraft:overworld run fill 359 70 15 359 71 15 dirt
execute in minecraft:overworld run setblock 359 72 15 grass_block
execute in minecraft:overworld run fill 359 73 15 359 144 15 air
execute in minecraft:overworld run fill 359 58 16 359 69 16 stone
execute in minecraft:overworld run fill 359 70 16 359 71 16 dirt
execute in minecraft:overworld run setblock 359 72 16 grass_block
execute in minecraft:overworld run fill 359 73 16 359 144 16 air
execute in minecraft:overworld run fill 359 58 17 359 69 17 stone
execute in minecraft:overworld run fill 359 70 17 359 71 17 dirt
execute in minecraft:overworld run setblock 359 72 17 coarse_dirt
execute in minecraft:overworld run fill 359 73 17 359 144 17 air
execute in minecraft:overworld run fill 359 58 18 359 69 18 stone
execute in minecraft:overworld run fill 359 70 18 359 71 18 dirt
execute in minecraft:overworld run setblock 359 72 18 grass_block
execute in minecraft:overworld run fill 359 73 18 359 144 18 air
execute in minecraft:overworld run fill 359 58 19 359 69 19 stone
execute in minecraft:overworld run fill 359 70 19 359 71 19 dirt
execute in minecraft:overworld run setblock 359 72 19 coarse_dirt
execute in minecraft:overworld run fill 359 73 19 359 144 19 air
execute in minecraft:overworld run fill 359 58 20 359 69 20 stone
execute in minecraft:overworld run fill 359 70 20 359 71 20 dirt
execute in minecraft:overworld run setblock 359 72 20 grass_block
execute in minecraft:overworld run fill 359 73 20 359 144 20 air
execute in minecraft:overworld run fill 359 58 21 359 69 21 stone
execute in minecraft:overworld run fill 359 70 21 359 71 21 dirt
execute in minecraft:overworld run setblock 359 72 21 coarse_dirt
execute in minecraft:overworld run fill 359 73 21 359 144 21 air
execute in minecraft:overworld run fill 359 58 22 359 69 22 stone
execute in minecraft:overworld run fill 359 70 22 359 71 22 dirt
execute in minecraft:overworld run setblock 359 72 22 coarse_dirt
execute in minecraft:overworld run fill 359 73 22 359 144 22 air
execute in minecraft:overworld run fill 359 58 23 359 69 23 stone
execute in minecraft:overworld run fill 359 70 23 359 71 23 dirt
execute in minecraft:overworld run setblock 359 72 23 coarse_dirt
execute in minecraft:overworld run fill 359 73 23 359 144 23 air
execute in minecraft:overworld run fill 359 58 24 359 69 24 stone
execute in minecraft:overworld run fill 359 70 24 359 71 24 dirt
execute in minecraft:overworld run setblock 359 72 24 coarse_dirt
execute in minecraft:overworld run fill 359 73 24 359 144 24 air
execute in minecraft:overworld run fill 359 58 25 359 68 25 stone
execute in minecraft:overworld run fill 359 69 25 359 70 25 dirt
execute in minecraft:overworld run setblock 359 71 25 grass_block
execute in minecraft:overworld run fill 359 72 25 359 144 25 air
execute in minecraft:overworld run fill 359 58 26 359 68 26 stone
execute in minecraft:overworld run fill 359 69 26 359 70 26 dirt
execute in minecraft:overworld run setblock 359 71 26 grass_block
execute in minecraft:overworld run fill 359 72 26 359 144 26 air
execute in minecraft:overworld run setblock 359 72 26 mossy_cobblestone
execute in minecraft:overworld run fill 359 58 27 359 68 27 stone
execute in minecraft:overworld run fill 359 69 27 359 70 27 dirt
execute in minecraft:overworld run setblock 359 71 27 coarse_dirt
execute in minecraft:overworld run fill 359 72 27 359 144 27 air
execute in minecraft:overworld run fill 359 58 28 359 68 28 stone
execute in minecraft:overworld run fill 359 69 28 359 70 28 dirt
execute in minecraft:overworld run setblock 359 71 28 grass_block
execute in minecraft:overworld run fill 359 72 28 359 144 28 air
execute in minecraft:overworld run fill 359 58 29 359 68 29 stone
execute in minecraft:overworld run fill 359 69 29 359 70 29 dirt
execute in minecraft:overworld run setblock 359 71 29 grass_block
execute in minecraft:overworld run fill 359 72 29 359 144 29 air
execute in minecraft:overworld run fill 359 58 30 359 69 30 stone
execute in minecraft:overworld run fill 359 70 30 359 71 30 dirt
execute in minecraft:overworld run setblock 359 72 30 grass_block
execute in minecraft:overworld run fill 359 73 30 359 144 30 air
execute in minecraft:overworld run fill 359 58 31 359 69 31 stone
execute in minecraft:overworld run fill 359 70 31 359 71 31 dirt
execute in minecraft:overworld run setblock 359 72 31 coarse_dirt
execute in minecraft:overworld run fill 359 73 31 359 144 31 air
execute in minecraft:overworld run fill 359 58 32 359 69 32 stone
execute in minecraft:overworld run fill 359 70 32 359 71 32 dirt
execute in minecraft:overworld run setblock 359 72 32 grass_block
execute in minecraft:overworld run fill 359 73 32 359 144 32 air
execute in minecraft:overworld run fill 359 58 33 359 69 33 stone
execute in minecraft:overworld run fill 359 70 33 359 71 33 dirt
execute in minecraft:overworld run setblock 359 72 33 grass_block
execute in minecraft:overworld run fill 359 73 33 359 144 33 air
execute in minecraft:overworld run fill 359 58 34 359 69 34 stone
execute in minecraft:overworld run fill 359 70 34 359 71 34 dirt
execute in minecraft:overworld run setblock 359 72 34 grass_block
execute in minecraft:overworld run fill 359 73 34 359 144 34 air
execute in minecraft:overworld run fill 359 58 35 359 69 35 stone
execute in minecraft:overworld run fill 359 70 35 359 71 35 dirt
execute in minecraft:overworld run setblock 359 72 35 grass_block
execute in minecraft:overworld run fill 359 73 35 359 144 35 air
execute in minecraft:overworld run fill 359 58 36 359 69 36 stone
execute in minecraft:overworld run fill 359 70 36 359 71 36 dirt
execute in minecraft:overworld run setblock 359 72 36 grass_block
execute in minecraft:overworld run fill 359 73 36 359 144 36 air
execute in minecraft:overworld run fill 359 58 37 359 69 37 stone
execute in minecraft:overworld run fill 359 70 37 359 71 37 dirt
execute in minecraft:overworld run setblock 359 72 37 coarse_dirt
execute in minecraft:overworld run fill 359 73 37 359 144 37 air
execute in minecraft:overworld run fill 359 58 38 359 69 38 stone
execute in minecraft:overworld run fill 359 70 38 359 71 38 dirt
execute in minecraft:overworld run setblock 359 72 38 coarse_dirt
execute in minecraft:overworld run fill 359 73 38 359 144 38 air
execute in minecraft:overworld run fill 359 58 39 359 68 39 stone
execute in minecraft:overworld run fill 359 69 39 359 70 39 dirt
execute in minecraft:overworld run setblock 359 71 39 coarse_dirt
execute in minecraft:overworld run fill 359 72 39 359 144 39 air
execute in minecraft:overworld run setblock 359 72 39 grass
execute in minecraft:overworld run fill 359 58 40 359 67 40 stone
execute in minecraft:overworld run fill 359 68 40 359 69 40 dirt
execute in minecraft:overworld run setblock 359 70 40 grass_block
execute in minecraft:overworld run fill 359 71 40 359 144 40 air
execute in minecraft:overworld run fill 359 58 41 359 66 41 stone
execute in minecraft:overworld run fill 359 67 41 359 68 41 dirt
execute in minecraft:overworld run setblock 359 69 41 coarse_dirt
execute in minecraft:overworld run fill 359 70 41 359 144 41 air
execute in minecraft:overworld run fill 359 58 42 359 65 42 stone
execute in minecraft:overworld run fill 359 66 42 359 67 42 dirt
execute in minecraft:overworld run setblock 359 68 42 coarse_dirt
execute in minecraft:overworld run fill 359 69 42 359 144 42 air
execute in minecraft:overworld run fill 359 58 43 359 65 43 stone
execute in minecraft:overworld run fill 359 66 43 359 67 43 dirt
execute in minecraft:overworld run setblock 359 68 43 coarse_dirt
execute in minecraft:overworld run fill 359 69 43 359 144 43 air
execute in minecraft:overworld run fill 359 58 44 359 64 44 stone
execute in minecraft:overworld run fill 359 65 44 359 66 44 dirt
execute in minecraft:overworld run setblock 359 67 44 grass_block
execute in minecraft:overworld run fill 359 68 44 359 144 44 air
execute in minecraft:overworld run fill 359 58 45 359 63 45 stone
execute in minecraft:overworld run fill 359 64 45 359 65 45 dirt
execute in minecraft:overworld run setblock 359 66 45 coarse_dirt
execute in minecraft:overworld run fill 359 67 45 359 144 45 air
execute in minecraft:overworld run fill 359 58 46 359 62 46 stone
execute in minecraft:overworld run fill 359 63 46 359 64 46 dirt
execute in minecraft:overworld run setblock 359 65 46 coarse_dirt
execute in minecraft:overworld run fill 359 66 46 359 144 46 air
execute in minecraft:overworld run fill 359 58 47 359 62 47 stone
execute in minecraft:overworld run fill 359 63 47 359 64 47 dirt
execute in minecraft:overworld run setblock 359 65 47 grass_block
execute in minecraft:overworld run fill 359 66 47 359 144 47 air
execute in minecraft:overworld run fill 360 58 -48 360 61 -48 stone
execute in minecraft:overworld run fill 360 62 -48 360 63 -48 dirt
execute in minecraft:overworld run setblock 360 64 -48 coarse_dirt
execute in minecraft:overworld run fill 360 65 -48 360 144 -48 air
execute in minecraft:overworld run fill 360 58 -47 360 63 -47 stone
execute in minecraft:overworld run fill 360 64 -47 360 65 -47 dirt
execute in minecraft:overworld run setblock 360 66 -47 grass_block
execute in minecraft:overworld run fill 360 67 -47 360 144 -47 air
execute in minecraft:overworld run fill 360 58 -46 360 65 -46 stone
execute in minecraft:overworld run fill 360 66 -46 360 67 -46 dirt
execute in minecraft:overworld run setblock 360 68 -46 coarse_dirt
execute in minecraft:overworld run fill 360 69 -46 360 144 -46 air
execute in minecraft:overworld run fill 360 58 -45 360 66 -45 stone
execute in minecraft:overworld run fill 360 67 -45 360 68 -45 dirt
execute in minecraft:overworld run setblock 360 69 -45 coarse_dirt
execute in minecraft:overworld run fill 360 70 -45 360 144 -45 air
execute in minecraft:overworld run fill 360 58 -44 360 68 -44 stone
execute in minecraft:overworld run fill 360 69 -44 360 70 -44 dirt
execute in minecraft:overworld run setblock 360 71 -44 grass_block
execute in minecraft:overworld run fill 360 72 -44 360 144 -44 air
execute in minecraft:overworld run fill 360 58 -43 360 70 -43 stone
execute in minecraft:overworld run fill 360 71 -43 360 72 -43 dirt
execute in minecraft:overworld run setblock 360 73 -43 coarse_dirt
execute in minecraft:overworld run fill 360 74 -43 360 144 -43 air
execute in minecraft:overworld run fill 360 58 -42 360 71 -42 stone
execute in minecraft:overworld run fill 360 72 -42 360 73 -42 dirt
execute in minecraft:overworld run setblock 360 74 -42 grass_block
execute in minecraft:overworld run fill 360 75 -42 360 144 -42 air
execute in minecraft:overworld run fill 360 58 -41 360 72 -41 stone
execute in minecraft:overworld run fill 360 73 -41 360 74 -41 dirt
execute in minecraft:overworld run setblock 360 75 -41 grass_block
execute in minecraft:overworld run fill 360 76 -41 360 144 -41 air
execute in minecraft:overworld run fill 360 58 -40 360 73 -40 stone
execute in minecraft:overworld run fill 360 74 -40 360 75 -40 dirt
execute in minecraft:overworld run setblock 360 76 -40 coarse_dirt
execute in minecraft:overworld run fill 360 77 -40 360 144 -40 air
execute in minecraft:overworld run fill 360 58 -39 360 74 -39 stone
execute in minecraft:overworld run fill 360 75 -39 360 76 -39 dirt
execute in minecraft:overworld run setblock 360 77 -39 coarse_dirt
execute in minecraft:overworld run fill 360 78 -39 360 144 -39 air
execute in minecraft:overworld run setblock 360 78 -39 mossy_cobblestone
execute in minecraft:overworld run fill 360 58 -38 360 75 -38 stone
execute in minecraft:overworld run fill 360 76 -38 360 77 -38 dirt
execute in minecraft:overworld run setblock 360 78 -38 coarse_dirt
execute in minecraft:overworld run fill 360 79 -38 360 144 -38 air
execute in minecraft:overworld run fill 360 58 -37 360 75 -37 stone
execute in minecraft:overworld run fill 360 76 -37 360 77 -37 dirt
execute in minecraft:overworld run setblock 360 78 -37 coarse_dirt
execute in minecraft:overworld run fill 360 79 -37 360 144 -37 air
execute in minecraft:overworld run fill 360 58 -36 360 74 -36 stone
execute in minecraft:overworld run fill 360 75 -36 360 76 -36 dirt
execute in minecraft:overworld run setblock 360 77 -36 coarse_dirt
execute in minecraft:overworld run fill 360 78 -36 360 144 -36 air
execute in minecraft:overworld run fill 360 58 -35 360 74 -35 stone
execute in minecraft:overworld run fill 360 75 -35 360 76 -35 dirt
execute in minecraft:overworld run setblock 360 77 -35 coarse_dirt
execute in minecraft:overworld run fill 360 78 -35 360 144 -35 air
execute in minecraft:overworld run fill 360 58 -34 360 74 -34 stone
execute in minecraft:overworld run fill 360 75 -34 360 76 -34 dirt
execute in minecraft:overworld run setblock 360 77 -34 coarse_dirt
execute in minecraft:overworld run fill 360 78 -34 360 144 -34 air
execute in minecraft:overworld run fill 360 58 -33 360 74 -33 stone
execute in minecraft:overworld run fill 360 75 -33 360 76 -33 dirt
execute in minecraft:overworld run setblock 360 77 -33 grass_block
execute in minecraft:overworld run fill 360 78 -33 360 144 -33 air
execute in minecraft:overworld run fill 360 58 -32 360 74 -32 stone
execute in minecraft:overworld run fill 360 75 -32 360 76 -32 dirt
execute in minecraft:overworld run setblock 360 77 -32 grass_block
execute in minecraft:overworld run fill 360 78 -32 360 144 -32 air
execute in minecraft:overworld run fill 360 58 -31 360 74 -31 stone
execute in minecraft:overworld run fill 360 75 -31 360 76 -31 dirt
execute in minecraft:overworld run setblock 360 77 -31 grass_block
execute in minecraft:overworld run fill 360 78 -31 360 144 -31 air
execute in minecraft:overworld run fill 360 58 -30 360 74 -30 stone
execute in minecraft:overworld run fill 360 75 -30 360 76 -30 dirt
execute in minecraft:overworld run setblock 360 77 -30 grass_block
execute in minecraft:overworld run fill 360 78 -30 360 144 -30 air
execute in minecraft:overworld run fill 360 58 -29 360 74 -29 stone
execute in minecraft:overworld run fill 360 75 -29 360 76 -29 dirt
execute in minecraft:overworld run setblock 360 77 -29 grass_block
execute in minecraft:overworld run fill 360 78 -29 360 144 -29 air
schedule function blade_gallery:random/battlefield/part_37 1t replace
