execute in minecraft:overworld run fill 232 71 29 232 72 29 dirt
execute in minecraft:overworld run setblock 232 73 29 grass_block
execute in minecraft:overworld run fill 232 74 29 232 144 29 air
execute in minecraft:overworld run fill 232 58 30 232 70 30 stone
execute in minecraft:overworld run fill 232 71 30 232 72 30 dirt
execute in minecraft:overworld run setblock 232 73 30 grass_block
execute in minecraft:overworld run fill 232 74 30 232 144 30 air
execute in minecraft:overworld run setblock 232 74 30 grass
execute in minecraft:overworld run fill 232 58 31 232 70 31 stone
execute in minecraft:overworld run fill 232 71 31 232 72 31 dirt
execute in minecraft:overworld run setblock 232 73 31 coarse_dirt
execute in minecraft:overworld run fill 232 74 31 232 144 31 air
execute in minecraft:overworld run fill 232 58 32 232 70 32 stone
execute in minecraft:overworld run fill 232 71 32 232 72 32 dirt
execute in minecraft:overworld run setblock 232 73 32 coarse_dirt
execute in minecraft:overworld run fill 232 74 32 232 144 32 air
execute in minecraft:overworld run setblock 232 74 32 grass
execute in minecraft:overworld run fill 232 58 33 232 69 33 stone
execute in minecraft:overworld run fill 232 70 33 232 71 33 dirt
execute in minecraft:overworld run setblock 232 72 33 coarse_dirt
execute in minecraft:overworld run fill 232 73 33 232 144 33 air
execute in minecraft:overworld run setblock 232 73 33 mossy_cobblestone
execute in minecraft:overworld run fill 232 58 34 232 69 34 stone
execute in minecraft:overworld run fill 232 70 34 232 71 34 dirt
execute in minecraft:overworld run setblock 232 72 34 coarse_dirt
execute in minecraft:overworld run fill 232 73 34 232 144 34 air
execute in minecraft:overworld run fill 232 58 35 232 69 35 stone
execute in minecraft:overworld run fill 232 70 35 232 71 35 dirt
execute in minecraft:overworld run setblock 232 72 35 coarse_dirt
execute in minecraft:overworld run fill 232 73 35 232 144 35 air
execute in minecraft:overworld run fill 232 58 36 232 69 36 stone
execute in minecraft:overworld run fill 232 70 36 232 71 36 dirt
execute in minecraft:overworld run setblock 232 72 36 coarse_dirt
execute in minecraft:overworld run fill 232 73 36 232 144 36 air
execute in minecraft:overworld run fill 232 58 37 232 68 37 stone
execute in minecraft:overworld run fill 232 69 37 232 70 37 dirt
execute in minecraft:overworld run setblock 232 71 37 coarse_dirt
execute in minecraft:overworld run fill 232 72 37 232 144 37 air
execute in minecraft:overworld run fill 232 58 38 232 68 38 stone
execute in minecraft:overworld run fill 232 69 38 232 70 38 dirt
execute in minecraft:overworld run setblock 232 71 38 grass_block
execute in minecraft:overworld run fill 232 72 38 232 144 38 air
execute in minecraft:overworld run fill 232 58 39 232 67 39 stone
execute in minecraft:overworld run fill 232 68 39 232 69 39 dirt
execute in minecraft:overworld run setblock 232 70 39 coarse_dirt
execute in minecraft:overworld run fill 232 71 39 232 144 39 air
execute in minecraft:overworld run fill 232 58 40 232 66 40 stone
execute in minecraft:overworld run fill 232 67 40 232 68 40 dirt
execute in minecraft:overworld run setblock 232 69 40 grass_block
execute in minecraft:overworld run fill 232 70 40 232 144 40 air
execute in minecraft:overworld run fill 232 58 41 232 65 41 stone
execute in minecraft:overworld run fill 232 66 41 232 67 41 dirt
execute in minecraft:overworld run setblock 232 68 41 grass_block
execute in minecraft:overworld run fill 232 69 41 232 144 41 air
execute in minecraft:overworld run fill 232 58 42 232 64 42 stone
execute in minecraft:overworld run fill 232 65 42 232 66 42 dirt
execute in minecraft:overworld run setblock 232 67 42 grass_block
execute in minecraft:overworld run fill 232 68 42 232 144 42 air
execute in minecraft:overworld run fill 232 58 43 232 63 43 stone
execute in minecraft:overworld run fill 232 64 43 232 65 43 dirt
execute in minecraft:overworld run setblock 232 66 43 grass_block
execute in minecraft:overworld run fill 232 67 43 232 144 43 air
execute in minecraft:overworld run fill 232 58 44 232 63 44 stone
execute in minecraft:overworld run fill 232 64 44 232 65 44 dirt
execute in minecraft:overworld run setblock 232 66 44 coarse_dirt
execute in minecraft:overworld run fill 232 67 44 232 144 44 air
execute in minecraft:overworld run fill 232 58 45 232 62 45 stone
execute in minecraft:overworld run fill 232 63 45 232 64 45 dirt
execute in minecraft:overworld run setblock 232 65 45 coarse_dirt
execute in minecraft:overworld run fill 232 66 45 232 144 45 air
execute in minecraft:overworld run fill 232 58 46 232 62 46 stone
execute in minecraft:overworld run fill 232 63 46 232 64 46 dirt
execute in minecraft:overworld run setblock 232 65 46 grass_block
execute in minecraft:overworld run fill 232 66 46 232 144 46 air
execute in minecraft:overworld run fill 232 58 47 232 61 47 stone
execute in minecraft:overworld run fill 232 62 47 232 63 47 dirt
execute in minecraft:overworld run setblock 232 64 47 coarse_dirt
execute in minecraft:overworld run fill 232 65 47 232 144 47 air
execute in minecraft:overworld run fill 233 58 -48 233 61 -48 stone
execute in minecraft:overworld run fill 233 62 -48 233 63 -48 dirt
execute in minecraft:overworld run setblock 233 64 -48 coarse_dirt
execute in minecraft:overworld run fill 233 65 -48 233 144 -48 air
execute in minecraft:overworld run fill 233 58 -47 233 63 -47 stone
execute in minecraft:overworld run fill 233 64 -47 233 65 -47 dirt
execute in minecraft:overworld run setblock 233 66 -47 grass_block
execute in minecraft:overworld run fill 233 67 -47 233 144 -47 air
execute in minecraft:overworld run fill 233 58 -46 233 64 -46 stone
execute in minecraft:overworld run fill 233 65 -46 233 66 -46 dirt
execute in minecraft:overworld run setblock 233 67 -46 grass_block
execute in minecraft:overworld run fill 233 68 -46 233 144 -46 air
execute in minecraft:overworld run fill 233 58 -45 233 66 -45 stone
execute in minecraft:overworld run fill 233 67 -45 233 68 -45 dirt
execute in minecraft:overworld run setblock 233 69 -45 coarse_dirt
execute in minecraft:overworld run fill 233 70 -45 233 144 -45 air
execute in minecraft:overworld run fill 233 58 -44 233 67 -44 stone
execute in minecraft:overworld run fill 233 68 -44 233 69 -44 dirt
execute in minecraft:overworld run setblock 233 70 -44 coarse_dirt
execute in minecraft:overworld run fill 233 71 -44 233 144 -44 air
execute in minecraft:overworld run fill 233 58 -43 233 68 -43 stone
execute in minecraft:overworld run fill 233 69 -43 233 70 -43 dirt
execute in minecraft:overworld run setblock 233 71 -43 coarse_dirt
execute in minecraft:overworld run fill 233 72 -43 233 144 -43 air
execute in minecraft:overworld run fill 233 58 -42 233 70 -42 stone
execute in minecraft:overworld run fill 233 71 -42 233 72 -42 dirt
execute in minecraft:overworld run setblock 233 73 -42 coarse_dirt
execute in minecraft:overworld run fill 233 74 -42 233 144 -42 air
execute in minecraft:overworld run fill 233 58 -41 233 71 -41 stone
execute in minecraft:overworld run fill 233 72 -41 233 73 -41 dirt
execute in minecraft:overworld run setblock 233 74 -41 coarse_dirt
execute in minecraft:overworld run fill 233 75 -41 233 144 -41 air
execute in minecraft:overworld run fill 233 58 -40 233 72 -40 stone
execute in minecraft:overworld run fill 233 73 -40 233 74 -40 dirt
execute in minecraft:overworld run setblock 233 75 -40 coarse_dirt
execute in minecraft:overworld run fill 233 76 -40 233 144 -40 air
execute in minecraft:overworld run setblock 233 76 -40 mossy_cobblestone
execute in minecraft:overworld run fill 233 58 -39 233 73 -39 stone
execute in minecraft:overworld run fill 233 74 -39 233 75 -39 dirt
execute in minecraft:overworld run setblock 233 76 -39 coarse_dirt
execute in minecraft:overworld run fill 233 77 -39 233 144 -39 air
execute in minecraft:overworld run fill 233 58 -38 233 74 -38 stone
execute in minecraft:overworld run fill 233 75 -38 233 76 -38 dirt
execute in minecraft:overworld run setblock 233 77 -38 coarse_dirt
execute in minecraft:overworld run fill 233 78 -38 233 144 -38 air
execute in minecraft:overworld run setblock 233 78 -38 grass
execute in minecraft:overworld run fill 233 58 -37 233 74 -37 stone
execute in minecraft:overworld run fill 233 75 -37 233 76 -37 dirt
execute in minecraft:overworld run setblock 233 77 -37 grass_block
execute in minecraft:overworld run fill 233 78 -37 233 144 -37 air
execute in minecraft:overworld run fill 233 58 -36 233 73 -36 stone
execute in minecraft:overworld run fill 233 74 -36 233 75 -36 dirt
execute in minecraft:overworld run setblock 233 76 -36 coarse_dirt
execute in minecraft:overworld run fill 233 77 -36 233 144 -36 air
execute in minecraft:overworld run fill 233 58 -35 233 73 -35 stone
execute in minecraft:overworld run fill 233 74 -35 233 75 -35 dirt
execute in minecraft:overworld run setblock 233 76 -35 grass_block
execute in minecraft:overworld run fill 233 77 -35 233 144 -35 air
execute in minecraft:overworld run fill 233 58 -34 233 72 -34 stone
execute in minecraft:overworld run fill 233 73 -34 233 74 -34 dirt
execute in minecraft:overworld run setblock 233 75 -34 coarse_dirt
execute in minecraft:overworld run fill 233 76 -34 233 144 -34 air
execute in minecraft:overworld run fill 233 58 -33 233 72 -33 stone
execute in minecraft:overworld run fill 233 73 -33 233 74 -33 dirt
execute in minecraft:overworld run setblock 233 75 -33 coarse_dirt
execute in minecraft:overworld run fill 233 76 -33 233 144 -33 air
execute in minecraft:overworld run fill 233 58 -32 233 71 -32 stone
execute in minecraft:overworld run fill 233 72 -32 233 73 -32 dirt
execute in minecraft:overworld run setblock 233 74 -32 coarse_dirt
execute in minecraft:overworld run fill 233 75 -32 233 144 -32 air
execute in minecraft:overworld run fill 233 58 -31 233 71 -31 stone
execute in minecraft:overworld run fill 233 72 -31 233 73 -31 dirt
execute in minecraft:overworld run setblock 233 74 -31 grass_block
execute in minecraft:overworld run fill 233 75 -31 233 144 -31 air
execute in minecraft:overworld run setblock 233 75 -31 grass
execute in minecraft:overworld run fill 233 58 -30 233 70 -30 stone
execute in minecraft:overworld run fill 233 71 -30 233 72 -30 dirt
execute in minecraft:overworld run setblock 233 73 -30 coarse_dirt
execute in minecraft:overworld run fill 233 74 -30 233 144 -30 air
execute in minecraft:overworld run fill 233 58 -29 233 70 -29 stone
execute in minecraft:overworld run fill 233 71 -29 233 72 -29 dirt
execute in minecraft:overworld run setblock 233 73 -29 grass_block
execute in minecraft:overworld run fill 233 74 -29 233 144 -29 air
execute in minecraft:overworld run fill 233 58 -28 233 69 -28 stone
execute in minecraft:overworld run fill 233 70 -28 233 71 -28 dirt
execute in minecraft:overworld run setblock 233 72 -28 coarse_dirt
execute in minecraft:overworld run fill 233 73 -28 233 144 -28 air
execute in minecraft:overworld run fill 233 58 -27 233 69 -27 stone
execute in minecraft:overworld run fill 233 70 -27 233 71 -27 dirt
execute in minecraft:overworld run setblock 233 72 -27 coarse_dirt
execute in minecraft:overworld run fill 233 73 -27 233 144 -27 air
execute in minecraft:overworld run fill 233 58 -26 233 69 -26 stone
execute in minecraft:overworld run fill 233 70 -26 233 71 -26 dirt
execute in minecraft:overworld run setblock 233 72 -26 grass_block
execute in minecraft:overworld run fill 233 73 -26 233 144 -26 air
execute in minecraft:overworld run fill 233 58 -25 233 68 -25 stone
execute in minecraft:overworld run fill 233 69 -25 233 70 -25 dirt
execute in minecraft:overworld run setblock 233 71 -25 coarse_dirt
execute in minecraft:overworld run fill 233 72 -25 233 144 -25 air
execute in minecraft:overworld run fill 233 58 -24 233 68 -24 stone
execute in minecraft:overworld run fill 233 69 -24 233 70 -24 dirt
execute in minecraft:overworld run setblock 233 71 -24 coarse_dirt
execute in minecraft:overworld run fill 233 72 -24 233 144 -24 air
execute in minecraft:overworld run fill 233 58 -23 233 68 -23 stone
execute in minecraft:overworld run fill 233 69 -23 233 70 -23 dirt
execute in minecraft:overworld run setblock 233 71 -23 coarse_dirt
execute in minecraft:overworld run fill 233 72 -23 233 144 -23 air
execute in minecraft:overworld run fill 233 58 -22 233 67 -22 stone
execute in minecraft:overworld run fill 233 68 -22 233 69 -22 dirt
execute in minecraft:overworld run setblock 233 70 -22 grass_block
execute in minecraft:overworld run fill 233 71 -22 233 144 -22 air
execute in minecraft:overworld run fill 233 58 -21 233 67 -21 stone
execute in minecraft:overworld run fill 233 68 -21 233 69 -21 dirt
execute in minecraft:overworld run setblock 233 70 -21 grass_block
execute in minecraft:overworld run fill 233 71 -21 233 144 -21 air
execute in minecraft:overworld run fill 233 58 -20 233 67 -20 stone
execute in minecraft:overworld run fill 233 68 -20 233 69 -20 dirt
execute in minecraft:overworld run setblock 233 70 -20 grass_block
execute in minecraft:overworld run fill 233 71 -20 233 144 -20 air
execute in minecraft:overworld run setblock 233 71 -20 grass
execute in minecraft:overworld run fill 233 58 -19 233 66 -19 stone
execute in minecraft:overworld run fill 233 67 -19 233 68 -19 dirt
execute in minecraft:overworld run setblock 233 69 -19 coarse_dirt
execute in minecraft:overworld run fill 233 70 -19 233 144 -19 air
execute in minecraft:overworld run fill 233 58 -18 233 66 -18 stone
execute in minecraft:overworld run fill 233 67 -18 233 68 -18 dirt
execute in minecraft:overworld run setblock 233 69 -18 coarse_dirt
execute in minecraft:overworld run fill 233 70 -18 233 144 -18 air
execute in minecraft:overworld run fill 233 58 -17 233 66 -17 stone
execute in minecraft:overworld run fill 233 67 -17 233 68 -17 dirt
execute in minecraft:overworld run setblock 233 69 -17 coarse_dirt
execute in minecraft:overworld run fill 233 70 -17 233 144 -17 air
execute in minecraft:overworld run fill 233 58 -16 233 66 -16 stone
execute in minecraft:overworld run fill 233 67 -16 233 68 -16 dirt
execute in minecraft:overworld run setblock 233 69 -16 grass_block
execute in minecraft:overworld run fill 233 70 -16 233 144 -16 air
execute in minecraft:overworld run fill 233 58 -15 233 65 -15 stone
execute in minecraft:overworld run fill 233 66 -15 233 67 -15 dirt
execute in minecraft:overworld run setblock 233 68 -15 grass_block
execute in minecraft:overworld run fill 233 69 -15 233 144 -15 air
execute in minecraft:overworld run fill 233 58 -14 233 65 -14 stone
execute in minecraft:overworld run fill 233 66 -14 233 67 -14 dirt
execute in minecraft:overworld run setblock 233 68 -14 coarse_dirt
execute in minecraft:overworld run fill 233 69 -14 233 144 -14 air
execute in minecraft:overworld run fill 233 58 -13 233 65 -13 stone
execute in minecraft:overworld run fill 233 66 -13 233 67 -13 dirt
execute in minecraft:overworld run setblock 233 68 -13 grass_block
execute in minecraft:overworld run fill 233 69 -13 233 144 -13 air
execute in minecraft:overworld run fill 233 58 -12 233 65 -12 stone
execute in minecraft:overworld run fill 233 66 -12 233 67 -12 dirt
execute in minecraft:overworld run setblock 233 68 -12 coarse_dirt
execute in minecraft:overworld run fill 233 69 -12 233 144 -12 air
execute in minecraft:overworld run setblock 233 69 -12 grass
execute in minecraft:overworld run fill 233 58 -11 233 65 -11 stone
execute in minecraft:overworld run fill 233 66 -11 233 67 -11 dirt
execute in minecraft:overworld run setblock 233 68 -11 coarse_dirt
execute in minecraft:overworld run fill 233 69 -11 233 144 -11 air
execute in minecraft:overworld run fill 233 58 -10 233 65 -10 stone
execute in minecraft:overworld run fill 233 66 -10 233 67 -10 dirt
execute in minecraft:overworld run setblock 233 68 -10 grass_block
execute in minecraft:overworld run fill 233 69 -10 233 144 -10 air
execute in minecraft:overworld run setblock 233 69 -10 mossy_cobblestone
execute in minecraft:overworld run fill 233 58 -9 233 65 -9 stone
execute in minecraft:overworld run fill 233 66 -9 233 67 -9 dirt
execute in minecraft:overworld run setblock 233 68 -9 grass_block
execute in minecraft:overworld run fill 233 69 -9 233 144 -9 air
execute in minecraft:overworld run setblock 233 69 -9 mossy_cobblestone
execute in minecraft:overworld run fill 233 58 -8 233 65 -8 stone
execute in minecraft:overworld run fill 233 66 -8 233 67 -8 dirt
execute in minecraft:overworld run setblock 233 68 -8 grass_block
execute in minecraft:overworld run fill 233 69 -8 233 144 -8 air
execute in minecraft:overworld run fill 233 58 -7 233 65 -7 stone
execute in minecraft:overworld run fill 233 66 -7 233 67 -7 dirt
execute in minecraft:overworld run setblock 233 68 -7 grass_block
execute in minecraft:overworld run fill 233 69 -7 233 144 -7 air
execute in minecraft:overworld run setblock 233 69 -7 grass
execute in minecraft:overworld run fill 233 58 -6 233 65 -6 stone
execute in minecraft:overworld run fill 233 66 -6 233 67 -6 dirt
schedule function blade_gallery:random/burned/part_39 1t replace
