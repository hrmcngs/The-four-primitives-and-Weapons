execute in minecraft:overworld run kill @e[type=the_four_primitives_and_weapons:stabbed_weapon,tag=blade_gallery.burned]
execute in minecraft:overworld run gamerule doFireTick false
execute in minecraft:overworld run fill 208 58 -48 208 61 -48 stone
execute in minecraft:overworld run fill 208 62 -48 208 63 -48 dirt
execute in minecraft:overworld run setblock 208 64 -48 grass_block
execute in minecraft:overworld run fill 208 65 -48 208 144 -48 air
execute in minecraft:overworld run fill 208 58 -47 208 61 -47 stone
execute in minecraft:overworld run fill 208 62 -47 208 63 -47 dirt
execute in minecraft:overworld run setblock 208 64 -47 coarse_dirt
execute in minecraft:overworld run fill 208 65 -47 208 144 -47 air
execute in minecraft:overworld run fill 208 58 -46 208 61 -46 stone
execute in minecraft:overworld run fill 208 62 -46 208 63 -46 dirt
execute in minecraft:overworld run setblock 208 64 -46 coarse_dirt
execute in minecraft:overworld run fill 208 65 -46 208 144 -46 air
execute in minecraft:overworld run fill 208 58 -45 208 61 -45 stone
execute in minecraft:overworld run fill 208 62 -45 208 63 -45 dirt
execute in minecraft:overworld run setblock 208 64 -45 grass_block
execute in minecraft:overworld run fill 208 65 -45 208 144 -45 air
execute in minecraft:overworld run fill 208 58 -44 208 61 -44 stone
execute in minecraft:overworld run fill 208 62 -44 208 63 -44 dirt
execute in minecraft:overworld run setblock 208 64 -44 coarse_dirt
execute in minecraft:overworld run fill 208 65 -44 208 144 -44 air
execute in minecraft:overworld run fill 208 58 -43 208 61 -43 stone
execute in minecraft:overworld run fill 208 62 -43 208 63 -43 dirt
execute in minecraft:overworld run setblock 208 64 -43 coarse_dirt
execute in minecraft:overworld run fill 208 65 -43 208 144 -43 air
execute in minecraft:overworld run fill 208 58 -42 208 61 -42 stone
execute in minecraft:overworld run fill 208 62 -42 208 63 -42 dirt
execute in minecraft:overworld run setblock 208 64 -42 coarse_dirt
execute in minecraft:overworld run fill 208 65 -42 208 144 -42 air
execute in minecraft:overworld run fill 208 58 -41 208 61 -41 stone
execute in minecraft:overworld run fill 208 62 -41 208 63 -41 dirt
execute in minecraft:overworld run setblock 208 64 -41 coarse_dirt
execute in minecraft:overworld run fill 208 65 -41 208 144 -41 air
execute in minecraft:overworld run fill 208 58 -40 208 61 -40 stone
execute in minecraft:overworld run fill 208 62 -40 208 63 -40 dirt
execute in minecraft:overworld run setblock 208 64 -40 coarse_dirt
execute in minecraft:overworld run fill 208 65 -40 208 144 -40 air
execute in minecraft:overworld run fill 208 58 -39 208 61 -39 stone
execute in minecraft:overworld run fill 208 62 -39 208 63 -39 dirt
execute in minecraft:overworld run setblock 208 64 -39 coarse_dirt
execute in minecraft:overworld run fill 208 65 -39 208 144 -39 air
execute in minecraft:overworld run fill 208 58 -38 208 61 -38 stone
execute in minecraft:overworld run fill 208 62 -38 208 63 -38 dirt
execute in minecraft:overworld run setblock 208 64 -38 coarse_dirt
execute in minecraft:overworld run fill 208 65 -38 208 144 -38 air
execute in minecraft:overworld run fill 208 58 -37 208 61 -37 stone
execute in minecraft:overworld run fill 208 62 -37 208 63 -37 dirt
execute in minecraft:overworld run setblock 208 64 -37 grass_block
execute in minecraft:overworld run fill 208 65 -37 208 144 -37 air
execute in minecraft:overworld run fill 208 58 -36 208 61 -36 stone
execute in minecraft:overworld run fill 208 62 -36 208 63 -36 dirt
execute in minecraft:overworld run setblock 208 64 -36 coarse_dirt
execute in minecraft:overworld run fill 208 65 -36 208 144 -36 air
execute in minecraft:overworld run fill 208 58 -35 208 61 -35 stone
execute in minecraft:overworld run fill 208 62 -35 208 63 -35 dirt
execute in minecraft:overworld run setblock 208 64 -35 grass_block
execute in minecraft:overworld run fill 208 65 -35 208 144 -35 air
execute in minecraft:overworld run fill 208 58 -34 208 61 -34 stone
execute in minecraft:overworld run fill 208 62 -34 208 63 -34 dirt
execute in minecraft:overworld run setblock 208 64 -34 grass_block
execute in minecraft:overworld run fill 208 65 -34 208 144 -34 air
execute in minecraft:overworld run fill 208 58 -33 208 61 -33 stone
execute in minecraft:overworld run fill 208 62 -33 208 63 -33 dirt
execute in minecraft:overworld run setblock 208 64 -33 grass_block
execute in minecraft:overworld run fill 208 65 -33 208 144 -33 air
execute in minecraft:overworld run fill 208 58 -32 208 61 -32 stone
execute in minecraft:overworld run fill 208 62 -32 208 63 -32 dirt
execute in minecraft:overworld run setblock 208 64 -32 coarse_dirt
execute in minecraft:overworld run fill 208 65 -32 208 144 -32 air
execute in minecraft:overworld run fill 208 58 -31 208 61 -31 stone
execute in minecraft:overworld run fill 208 62 -31 208 63 -31 dirt
execute in minecraft:overworld run setblock 208 64 -31 grass_block
execute in minecraft:overworld run fill 208 65 -31 208 144 -31 air
execute in minecraft:overworld run fill 208 58 -30 208 61 -30 stone
execute in minecraft:overworld run fill 208 62 -30 208 63 -30 dirt
execute in minecraft:overworld run setblock 208 64 -30 grass_block
execute in minecraft:overworld run fill 208 65 -30 208 144 -30 air
execute in minecraft:overworld run fill 208 58 -29 208 61 -29 stone
execute in minecraft:overworld run fill 208 62 -29 208 63 -29 dirt
execute in minecraft:overworld run setblock 208 64 -29 coarse_dirt
execute in minecraft:overworld run fill 208 65 -29 208 144 -29 air
execute in minecraft:overworld run fill 208 58 -28 208 61 -28 stone
execute in minecraft:overworld run fill 208 62 -28 208 63 -28 dirt
execute in minecraft:overworld run setblock 208 64 -28 grass_block
execute in minecraft:overworld run fill 208 65 -28 208 144 -28 air
execute in minecraft:overworld run fill 208 58 -27 208 61 -27 stone
execute in minecraft:overworld run fill 208 62 -27 208 63 -27 dirt
execute in minecraft:overworld run setblock 208 64 -27 coarse_dirt
execute in minecraft:overworld run fill 208 65 -27 208 144 -27 air
execute in minecraft:overworld run fill 208 58 -26 208 61 -26 stone
execute in minecraft:overworld run fill 208 62 -26 208 63 -26 dirt
execute in minecraft:overworld run setblock 208 64 -26 grass_block
execute in minecraft:overworld run fill 208 65 -26 208 144 -26 air
execute in minecraft:overworld run fill 208 58 -25 208 61 -25 stone
execute in minecraft:overworld run fill 208 62 -25 208 63 -25 dirt
execute in minecraft:overworld run setblock 208 64 -25 coarse_dirt
execute in minecraft:overworld run fill 208 65 -25 208 144 -25 air
execute in minecraft:overworld run fill 208 58 -24 208 61 -24 stone
execute in minecraft:overworld run fill 208 62 -24 208 63 -24 dirt
execute in minecraft:overworld run setblock 208 64 -24 coarse_dirt
execute in minecraft:overworld run fill 208 65 -24 208 144 -24 air
execute in minecraft:overworld run fill 208 58 -23 208 61 -23 stone
execute in minecraft:overworld run fill 208 62 -23 208 63 -23 dirt
execute in minecraft:overworld run setblock 208 64 -23 coarse_dirt
execute in minecraft:overworld run fill 208 65 -23 208 144 -23 air
execute in minecraft:overworld run fill 208 58 -22 208 61 -22 stone
execute in minecraft:overworld run fill 208 62 -22 208 63 -22 dirt
execute in minecraft:overworld run setblock 208 64 -22 grass_block
execute in minecraft:overworld run fill 208 65 -22 208 144 -22 air
execute in minecraft:overworld run fill 208 58 -21 208 61 -21 stone
execute in minecraft:overworld run fill 208 62 -21 208 63 -21 dirt
execute in minecraft:overworld run setblock 208 64 -21 coarse_dirt
execute in minecraft:overworld run fill 208 65 -21 208 144 -21 air
execute in minecraft:overworld run fill 208 58 -20 208 61 -20 stone
execute in minecraft:overworld run fill 208 62 -20 208 63 -20 dirt
execute in minecraft:overworld run setblock 208 64 -20 coarse_dirt
execute in minecraft:overworld run fill 208 65 -20 208 144 -20 air
execute in minecraft:overworld run fill 208 58 -19 208 61 -19 stone
execute in minecraft:overworld run fill 208 62 -19 208 63 -19 dirt
execute in minecraft:overworld run setblock 208 64 -19 coarse_dirt
execute in minecraft:overworld run fill 208 65 -19 208 144 -19 air
execute in minecraft:overworld run fill 208 58 -18 208 61 -18 stone
execute in minecraft:overworld run fill 208 62 -18 208 63 -18 dirt
execute in minecraft:overworld run setblock 208 64 -18 coarse_dirt
execute in minecraft:overworld run fill 208 65 -18 208 144 -18 air
execute in minecraft:overworld run fill 208 58 -17 208 61 -17 stone
execute in minecraft:overworld run fill 208 62 -17 208 63 -17 dirt
execute in minecraft:overworld run setblock 208 64 -17 coarse_dirt
execute in minecraft:overworld run fill 208 65 -17 208 144 -17 air
execute in minecraft:overworld run fill 208 58 -16 208 61 -16 stone
execute in minecraft:overworld run fill 208 62 -16 208 63 -16 dirt
execute in minecraft:overworld run setblock 208 64 -16 grass_block
execute in minecraft:overworld run fill 208 65 -16 208 144 -16 air
execute in minecraft:overworld run fill 208 58 -15 208 61 -15 stone
execute in minecraft:overworld run fill 208 62 -15 208 63 -15 dirt
execute in minecraft:overworld run setblock 208 64 -15 coarse_dirt
execute in minecraft:overworld run fill 208 65 -15 208 144 -15 air
execute in minecraft:overworld run fill 208 58 -14 208 61 -14 stone
execute in minecraft:overworld run fill 208 62 -14 208 63 -14 dirt
execute in minecraft:overworld run setblock 208 64 -14 coarse_dirt
execute in minecraft:overworld run fill 208 65 -14 208 144 -14 air
execute in minecraft:overworld run fill 208 58 -13 208 61 -13 stone
execute in minecraft:overworld run fill 208 62 -13 208 63 -13 dirt
execute in minecraft:overworld run setblock 208 64 -13 coarse_dirt
execute in minecraft:overworld run fill 208 65 -13 208 144 -13 air
execute in minecraft:overworld run fill 208 58 -12 208 61 -12 stone
execute in minecraft:overworld run fill 208 62 -12 208 63 -12 dirt
execute in minecraft:overworld run setblock 208 64 -12 grass_block
execute in minecraft:overworld run fill 208 65 -12 208 144 -12 air
execute in minecraft:overworld run fill 208 58 -11 208 61 -11 stone
execute in minecraft:overworld run fill 208 62 -11 208 63 -11 dirt
execute in minecraft:overworld run setblock 208 64 -11 grass_block
execute in minecraft:overworld run fill 208 65 -11 208 144 -11 air
execute in minecraft:overworld run fill 208 58 -10 208 61 -10 stone
execute in minecraft:overworld run fill 208 62 -10 208 63 -10 dirt
execute in minecraft:overworld run setblock 208 64 -10 grass_block
execute in minecraft:overworld run fill 208 65 -10 208 144 -10 air
execute in minecraft:overworld run fill 208 58 -9 208 61 -9 stone
execute in minecraft:overworld run fill 208 62 -9 208 63 -9 dirt
execute in minecraft:overworld run setblock 208 64 -9 coarse_dirt
execute in minecraft:overworld run fill 208 65 -9 208 144 -9 air
execute in minecraft:overworld run fill 208 58 -8 208 61 -8 stone
execute in minecraft:overworld run fill 208 62 -8 208 63 -8 dirt
execute in minecraft:overworld run setblock 208 64 -8 grass_block
execute in minecraft:overworld run fill 208 65 -8 208 144 -8 air
execute in minecraft:overworld run fill 208 58 -7 208 61 -7 stone
execute in minecraft:overworld run fill 208 62 -7 208 63 -7 dirt
execute in minecraft:overworld run setblock 208 64 -7 coarse_dirt
execute in minecraft:overworld run fill 208 65 -7 208 144 -7 air
execute in minecraft:overworld run fill 208 58 -6 208 61 -6 stone
execute in minecraft:overworld run fill 208 62 -6 208 63 -6 dirt
execute in minecraft:overworld run setblock 208 64 -6 coarse_dirt
execute in minecraft:overworld run fill 208 65 -6 208 144 -6 air
execute in minecraft:overworld run fill 208 58 -5 208 61 -5 stone
execute in minecraft:overworld run fill 208 62 -5 208 63 -5 dirt
execute in minecraft:overworld run setblock 208 64 -5 grass_block
execute in minecraft:overworld run fill 208 65 -5 208 144 -5 air
execute in minecraft:overworld run fill 208 58 -4 208 61 -4 stone
execute in minecraft:overworld run fill 208 62 -4 208 63 -4 dirt
execute in minecraft:overworld run setblock 208 64 -4 coarse_dirt
execute in minecraft:overworld run fill 208 65 -4 208 144 -4 air
execute in minecraft:overworld run fill 208 58 -3 208 61 -3 stone
execute in minecraft:overworld run fill 208 62 -3 208 63 -3 dirt
execute in minecraft:overworld run setblock 208 64 -3 coarse_dirt
execute in minecraft:overworld run fill 208 65 -3 208 144 -3 air
execute in minecraft:overworld run fill 208 58 -2 208 61 -2 stone
execute in minecraft:overworld run fill 208 62 -2 208 63 -2 dirt
execute in minecraft:overworld run setblock 208 64 -2 coarse_dirt
execute in minecraft:overworld run fill 208 65 -2 208 144 -2 air
execute in minecraft:overworld run fill 208 58 -1 208 61 -1 stone
execute in minecraft:overworld run fill 208 62 -1 208 63 -1 dirt
execute in minecraft:overworld run setblock 208 64 -1 coarse_dirt
execute in minecraft:overworld run fill 208 65 -1 208 144 -1 air
execute in minecraft:overworld run fill 208 58 0 208 61 0 stone
execute in minecraft:overworld run fill 208 62 0 208 63 0 dirt
execute in minecraft:overworld run setblock 208 64 0 coarse_dirt
execute in minecraft:overworld run fill 208 65 0 208 144 0 air
execute in minecraft:overworld run fill 208 58 1 208 61 1 stone
execute in minecraft:overworld run fill 208 62 1 208 63 1 dirt
execute in minecraft:overworld run setblock 208 64 1 grass_block
execute in minecraft:overworld run fill 208 65 1 208 144 1 air
execute in minecraft:overworld run fill 208 58 2 208 61 2 stone
execute in minecraft:overworld run fill 208 62 2 208 63 2 dirt
execute in minecraft:overworld run setblock 208 64 2 coarse_dirt
execute in minecraft:overworld run fill 208 65 2 208 144 2 air
execute in minecraft:overworld run fill 208 58 3 208 61 3 stone
execute in minecraft:overworld run fill 208 62 3 208 63 3 dirt
execute in minecraft:overworld run setblock 208 64 3 coarse_dirt
execute in minecraft:overworld run fill 208 65 3 208 144 3 air
execute in minecraft:overworld run fill 208 58 4 208 61 4 stone
execute in minecraft:overworld run fill 208 62 4 208 63 4 dirt
execute in minecraft:overworld run setblock 208 64 4 coarse_dirt
execute in minecraft:overworld run fill 208 65 4 208 144 4 air
execute in minecraft:overworld run fill 208 58 5 208 61 5 stone
execute in minecraft:overworld run fill 208 62 5 208 63 5 dirt
execute in minecraft:overworld run setblock 208 64 5 coarse_dirt
execute in minecraft:overworld run fill 208 65 5 208 144 5 air
execute in minecraft:overworld run fill 208 58 6 208 61 6 stone
execute in minecraft:overworld run fill 208 62 6 208 63 6 dirt
execute in minecraft:overworld run setblock 208 64 6 coarse_dirt
execute in minecraft:overworld run fill 208 65 6 208 144 6 air
execute in minecraft:overworld run fill 208 58 7 208 61 7 stone
execute in minecraft:overworld run fill 208 62 7 208 63 7 dirt
execute in minecraft:overworld run setblock 208 64 7 coarse_dirt
execute in minecraft:overworld run fill 208 65 7 208 144 7 air
execute in minecraft:overworld run fill 208 58 8 208 61 8 stone
execute in minecraft:overworld run fill 208 62 8 208 63 8 dirt
execute in minecraft:overworld run setblock 208 64 8 coarse_dirt
execute in minecraft:overworld run fill 208 65 8 208 144 8 air
execute in minecraft:overworld run fill 208 58 9 208 61 9 stone
execute in minecraft:overworld run fill 208 62 9 208 63 9 dirt
execute in minecraft:overworld run setblock 208 64 9 coarse_dirt
execute in minecraft:overworld run fill 208 65 9 208 144 9 air
execute in minecraft:overworld run fill 208 58 10 208 61 10 stone
execute in minecraft:overworld run fill 208 62 10 208 63 10 dirt
execute in minecraft:overworld run setblock 208 64 10 grass_block
execute in minecraft:overworld run fill 208 65 10 208 144 10 air
execute in minecraft:overworld run fill 208 58 11 208 61 11 stone
execute in minecraft:overworld run fill 208 62 11 208 63 11 dirt
execute in minecraft:overworld run setblock 208 64 11 grass_block
execute in minecraft:overworld run fill 208 65 11 208 144 11 air
execute in minecraft:overworld run fill 208 58 12 208 61 12 stone
execute in minecraft:overworld run fill 208 62 12 208 63 12 dirt
execute in minecraft:overworld run setblock 208 64 12 coarse_dirt
execute in minecraft:overworld run fill 208 65 12 208 144 12 air
execute in minecraft:overworld run fill 208 58 13 208 61 13 stone
execute in minecraft:overworld run fill 208 62 13 208 63 13 dirt
execute in minecraft:overworld run setblock 208 64 13 grass_block
execute in minecraft:overworld run fill 208 65 13 208 144 13 air
execute in minecraft:overworld run fill 208 58 14 208 61 14 stone
execute in minecraft:overworld run fill 208 62 14 208 63 14 dirt
execute in minecraft:overworld run setblock 208 64 14 coarse_dirt
execute in minecraft:overworld run fill 208 65 14 208 144 14 air
execute in minecraft:overworld run fill 208 58 15 208 61 15 stone
execute in minecraft:overworld run fill 208 62 15 208 63 15 dirt
schedule function blade_gallery:random/burned/part_1 1t replace
