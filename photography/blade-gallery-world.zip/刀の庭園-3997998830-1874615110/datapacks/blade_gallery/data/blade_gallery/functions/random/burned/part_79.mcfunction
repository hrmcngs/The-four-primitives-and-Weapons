execute in minecraft:overworld run fill 258 61 37 258 64 37 water
execute in minecraft:overworld run fill 258 58 38 258 56 38 stone
execute in minecraft:overworld run fill 258 57 38 258 58 38 dirt
execute in minecraft:overworld run setblock 258 59 38 gravel
execute in minecraft:overworld run fill 258 60 38 258 144 38 air
execute in minecraft:overworld run fill 258 60 38 258 64 38 water
execute in minecraft:overworld run fill 258 58 39 258 57 39 stone
execute in minecraft:overworld run fill 258 58 39 258 59 39 dirt
execute in minecraft:overworld run setblock 258 60 39 gravel
execute in minecraft:overworld run fill 258 61 39 258 144 39 air
execute in minecraft:overworld run fill 258 61 39 258 64 39 water
execute in minecraft:overworld run fill 258 58 40 258 57 40 stone
execute in minecraft:overworld run fill 258 58 40 258 59 40 dirt
execute in minecraft:overworld run setblock 258 60 40 gravel
execute in minecraft:overworld run fill 258 61 40 258 144 40 air
execute in minecraft:overworld run fill 258 61 40 258 64 40 water
execute in minecraft:overworld run fill 258 58 41 258 57 41 stone
execute in minecraft:overworld run fill 258 58 41 258 59 41 dirt
execute in minecraft:overworld run setblock 258 60 41 gravel
execute in minecraft:overworld run fill 258 61 41 258 144 41 air
execute in minecraft:overworld run fill 258 61 41 258 64 41 water
execute in minecraft:overworld run fill 258 58 42 258 58 42 stone
execute in minecraft:overworld run fill 258 59 42 258 60 42 dirt
execute in minecraft:overworld run setblock 258 61 42 gravel
execute in minecraft:overworld run fill 258 62 42 258 144 42 air
execute in minecraft:overworld run fill 258 62 42 258 64 42 water
execute in minecraft:overworld run fill 258 58 43 258 58 43 stone
execute in minecraft:overworld run fill 258 59 43 258 60 43 dirt
execute in minecraft:overworld run setblock 258 61 43 gravel
execute in minecraft:overworld run fill 258 62 43 258 144 43 air
execute in minecraft:overworld run fill 258 62 43 258 64 43 water
execute in minecraft:overworld run fill 258 58 44 258 59 44 stone
execute in minecraft:overworld run fill 258 60 44 258 61 44 dirt
execute in minecraft:overworld run setblock 258 62 44 gravel
execute in minecraft:overworld run fill 258 63 44 258 144 44 air
execute in minecraft:overworld run fill 258 63 44 258 64 44 water
execute in minecraft:overworld run fill 258 58 45 258 59 45 stone
execute in minecraft:overworld run fill 258 60 45 258 61 45 dirt
execute in minecraft:overworld run setblock 258 62 45 gravel
execute in minecraft:overworld run fill 258 63 45 258 144 45 air
execute in minecraft:overworld run fill 258 63 45 258 64 45 water
execute in minecraft:overworld run fill 258 58 46 258 60 46 stone
execute in minecraft:overworld run fill 258 61 46 258 62 46 dirt
execute in minecraft:overworld run setblock 258 63 46 gravel
execute in minecraft:overworld run fill 258 64 46 258 144 46 air
execute in minecraft:overworld run fill 258 64 46 258 64 46 water
execute in minecraft:overworld run fill 258 58 47 258 60 47 stone
execute in minecraft:overworld run fill 258 61 47 258 62 47 dirt
execute in minecraft:overworld run setblock 258 63 47 gravel
execute in minecraft:overworld run fill 258 64 47 258 144 47 air
execute in minecraft:overworld run fill 258 64 47 258 64 47 water
execute in minecraft:overworld run fill 259 58 -48 259 61 -48 stone
execute in minecraft:overworld run fill 259 62 -48 259 63 -48 dirt
execute in minecraft:overworld run setblock 259 64 -48 coarse_dirt
execute in minecraft:overworld run fill 259 65 -48 259 144 -48 air
execute in minecraft:overworld run fill 259 58 -47 259 63 -47 stone
execute in minecraft:overworld run fill 259 64 -47 259 65 -47 dirt
execute in minecraft:overworld run setblock 259 66 -47 grass_block
execute in minecraft:overworld run fill 259 67 -47 259 144 -47 air
execute in minecraft:overworld run fill 259 58 -46 259 64 -46 stone
execute in minecraft:overworld run fill 259 65 -46 259 66 -46 dirt
execute in minecraft:overworld run setblock 259 67 -46 coarse_dirt
execute in minecraft:overworld run fill 259 68 -46 259 144 -46 air
execute in minecraft:overworld run fill 259 58 -45 259 66 -45 stone
execute in minecraft:overworld run fill 259 67 -45 259 68 -45 dirt
execute in minecraft:overworld run setblock 259 69 -45 grass_block
execute in minecraft:overworld run fill 259 70 -45 259 144 -45 air
execute in minecraft:overworld run fill 259 58 -44 259 68 -44 stone
execute in minecraft:overworld run fill 259 69 -44 259 70 -44 dirt
execute in minecraft:overworld run setblock 259 71 -44 grass_block
execute in minecraft:overworld run fill 259 72 -44 259 144 -44 air
execute in minecraft:overworld run fill 259 58 -43 259 69 -43 stone
execute in minecraft:overworld run fill 259 70 -43 259 71 -43 dirt
execute in minecraft:overworld run setblock 259 72 -43 coarse_dirt
execute in minecraft:overworld run fill 259 73 -43 259 144 -43 air
execute in minecraft:overworld run fill 259 58 -42 259 71 -42 stone
execute in minecraft:overworld run fill 259 72 -42 259 73 -42 dirt
execute in minecraft:overworld run setblock 259 74 -42 grass_block
execute in minecraft:overworld run fill 259 75 -42 259 144 -42 air
execute in minecraft:overworld run fill 259 58 -41 259 72 -41 stone
execute in minecraft:overworld run fill 259 73 -41 259 74 -41 dirt
execute in minecraft:overworld run setblock 259 75 -41 coarse_dirt
execute in minecraft:overworld run fill 259 76 -41 259 144 -41 air
execute in minecraft:overworld run fill 259 58 -40 259 74 -40 stone
execute in minecraft:overworld run fill 259 75 -40 259 76 -40 dirt
execute in minecraft:overworld run setblock 259 77 -40 grass_block
execute in minecraft:overworld run fill 259 78 -40 259 144 -40 air
execute in minecraft:overworld run setblock 259 78 -40 grass
execute in minecraft:overworld run fill 259 58 -39 259 75 -39 stone
execute in minecraft:overworld run fill 259 76 -39 259 77 -39 dirt
execute in minecraft:overworld run setblock 259 78 -39 coarse_dirt
execute in minecraft:overworld run fill 259 79 -39 259 144 -39 air
execute in minecraft:overworld run fill 259 58 -38 259 76 -38 stone
execute in minecraft:overworld run fill 259 77 -38 259 78 -38 dirt
execute in minecraft:overworld run setblock 259 79 -38 grass_block
execute in minecraft:overworld run fill 259 80 -38 259 144 -38 air
execute in minecraft:overworld run fill 259 58 -37 259 76 -37 stone
execute in minecraft:overworld run fill 259 77 -37 259 78 -37 dirt
execute in minecraft:overworld run setblock 259 79 -37 coarse_dirt
execute in minecraft:overworld run fill 259 80 -37 259 144 -37 air
execute in minecraft:overworld run fill 259 58 -36 259 76 -36 stone
execute in minecraft:overworld run fill 259 77 -36 259 78 -36 dirt
execute in minecraft:overworld run setblock 259 79 -36 coarse_dirt
execute in minecraft:overworld run fill 259 80 -36 259 144 -36 air
execute in minecraft:overworld run fill 259 58 -35 259 76 -35 stone
execute in minecraft:overworld run fill 259 77 -35 259 78 -35 dirt
execute in minecraft:overworld run setblock 259 79 -35 coarse_dirt
execute in minecraft:overworld run fill 259 80 -35 259 144 -35 air
execute in minecraft:overworld run fill 259 58 -34 259 75 -34 stone
execute in minecraft:overworld run fill 259 76 -34 259 77 -34 dirt
execute in minecraft:overworld run setblock 259 78 -34 grass_block
execute in minecraft:overworld run fill 259 79 -34 259 144 -34 air
execute in minecraft:overworld run fill 259 58 -33 259 75 -33 stone
execute in minecraft:overworld run fill 259 76 -33 259 77 -33 dirt
execute in minecraft:overworld run setblock 259 78 -33 coarse_dirt
execute in minecraft:overworld run fill 259 79 -33 259 144 -33 air
execute in minecraft:overworld run fill 259 58 -32 259 75 -32 stone
execute in minecraft:overworld run fill 259 76 -32 259 77 -32 dirt
execute in minecraft:overworld run setblock 259 78 -32 coarse_dirt
execute in minecraft:overworld run fill 259 79 -32 259 144 -32 air
execute in minecraft:overworld run fill 259 58 -31 259 74 -31 stone
execute in minecraft:overworld run fill 259 75 -31 259 76 -31 dirt
execute in minecraft:overworld run setblock 259 77 -31 coarse_dirt
execute in minecraft:overworld run fill 259 78 -31 259 144 -31 air
execute in minecraft:overworld run fill 259 58 -30 259 74 -30 stone
execute in minecraft:overworld run fill 259 75 -30 259 76 -30 dirt
execute in minecraft:overworld run setblock 259 77 -30 coarse_dirt
execute in minecraft:overworld run fill 259 78 -30 259 144 -30 air
execute in minecraft:overworld run fill 259 58 -29 259 73 -29 stone
execute in minecraft:overworld run fill 259 74 -29 259 75 -29 dirt
execute in minecraft:overworld run setblock 259 76 -29 coarse_dirt
execute in minecraft:overworld run fill 259 77 -29 259 144 -29 air
execute in minecraft:overworld run fill 259 58 -28 259 72 -28 stone
execute in minecraft:overworld run fill 259 73 -28 259 74 -28 dirt
execute in minecraft:overworld run setblock 259 75 -28 grass_block
execute in minecraft:overworld run fill 259 76 -28 259 144 -28 air
execute in minecraft:overworld run fill 259 58 -27 259 72 -27 stone
execute in minecraft:overworld run fill 259 73 -27 259 74 -27 dirt
execute in minecraft:overworld run setblock 259 75 -27 coarse_dirt
execute in minecraft:overworld run fill 259 76 -27 259 144 -27 air
execute in minecraft:overworld run fill 259 58 -26 259 71 -26 stone
execute in minecraft:overworld run fill 259 72 -26 259 73 -26 dirt
execute in minecraft:overworld run setblock 259 74 -26 grass_block
execute in minecraft:overworld run fill 259 75 -26 259 144 -26 air
execute in minecraft:overworld run fill 259 58 -25 259 70 -25 stone
execute in minecraft:overworld run fill 259 71 -25 259 72 -25 dirt
execute in minecraft:overworld run setblock 259 73 -25 coarse_dirt
execute in minecraft:overworld run fill 259 74 -25 259 144 -25 air
execute in minecraft:overworld run fill 259 58 -24 259 68 -24 stone
execute in minecraft:overworld run fill 259 69 -24 259 70 -24 dirt
execute in minecraft:overworld run setblock 259 71 -24 grass_block
execute in minecraft:overworld run fill 259 72 -24 259 144 -24 air
execute in minecraft:overworld run fill 259 58 -23 259 67 -23 stone
execute in minecraft:overworld run fill 259 68 -23 259 69 -23 dirt
execute in minecraft:overworld run setblock 259 70 -23 coarse_dirt
execute in minecraft:overworld run fill 259 71 -23 259 144 -23 air
execute in minecraft:overworld run fill 259 58 -22 259 66 -22 stone
execute in minecraft:overworld run fill 259 67 -22 259 68 -22 dirt
execute in minecraft:overworld run setblock 259 69 -22 grass_block
execute in minecraft:overworld run fill 259 70 -22 259 144 -22 air
execute in minecraft:overworld run fill 259 58 -21 259 65 -21 stone
execute in minecraft:overworld run fill 259 66 -21 259 67 -21 dirt
execute in minecraft:overworld run setblock 259 68 -21 coarse_dirt
execute in minecraft:overworld run fill 259 69 -21 259 144 -21 air
execute in minecraft:overworld run fill 259 58 -20 259 64 -20 stone
execute in minecraft:overworld run fill 259 65 -20 259 66 -20 dirt
execute in minecraft:overworld run setblock 259 67 -20 grass_block
execute in minecraft:overworld run fill 259 68 -20 259 144 -20 air
execute in minecraft:overworld run setblock 259 68 -20 grass
execute in minecraft:overworld run fill 259 58 -19 259 63 -19 stone
execute in minecraft:overworld run fill 259 64 -19 259 65 -19 dirt
execute in minecraft:overworld run setblock 259 66 -19 grass_block
execute in minecraft:overworld run fill 259 67 -19 259 144 -19 air
execute in minecraft:overworld run fill 259 58 -18 259 62 -18 stone
execute in minecraft:overworld run fill 259 63 -18 259 64 -18 dirt
execute in minecraft:overworld run setblock 259 65 -18 grass_block
execute in minecraft:overworld run fill 259 66 -18 259 144 -18 air
execute in minecraft:overworld run fill 259 58 -17 259 61 -17 stone
execute in minecraft:overworld run fill 259 62 -17 259 63 -17 dirt
execute in minecraft:overworld run setblock 259 64 -17 grass_block
execute in minecraft:overworld run fill 259 65 -17 259 144 -17 air
execute in minecraft:overworld run fill 259 58 -16 259 60 -16 stone
execute in minecraft:overworld run fill 259 61 -16 259 62 -16 dirt
execute in minecraft:overworld run setblock 259 63 -16 gravel
execute in minecraft:overworld run fill 259 64 -16 259 144 -16 air
execute in minecraft:overworld run fill 259 64 -16 259 64 -16 water
execute in minecraft:overworld run fill 259 58 -15 259 59 -15 stone
execute in minecraft:overworld run fill 259 60 -15 259 61 -15 dirt
execute in minecraft:overworld run setblock 259 62 -15 gravel
execute in minecraft:overworld run fill 259 63 -15 259 144 -15 air
execute in minecraft:overworld run fill 259 63 -15 259 64 -15 water
execute in minecraft:overworld run fill 259 58 -14 259 58 -14 stone
execute in minecraft:overworld run fill 259 59 -14 259 60 -14 dirt
execute in minecraft:overworld run setblock 259 61 -14 gravel
execute in minecraft:overworld run fill 259 62 -14 259 144 -14 air
execute in minecraft:overworld run fill 259 62 -14 259 64 -14 water
execute in minecraft:overworld run fill 259 58 -13 259 58 -13 stone
execute in minecraft:overworld run fill 259 59 -13 259 60 -13 dirt
execute in minecraft:overworld run setblock 259 61 -13 gravel
execute in minecraft:overworld run fill 259 62 -13 259 144 -13 air
execute in minecraft:overworld run fill 259 62 -13 259 64 -13 water
execute in minecraft:overworld run fill 259 58 -12 259 57 -12 stone
execute in minecraft:overworld run fill 259 58 -12 259 59 -12 dirt
execute in minecraft:overworld run setblock 259 60 -12 gravel
execute in minecraft:overworld run fill 259 61 -12 259 144 -12 air
execute in minecraft:overworld run fill 259 61 -12 259 64 -12 water
execute in minecraft:overworld run fill 259 58 -11 259 57 -11 stone
execute in minecraft:overworld run fill 259 58 -11 259 59 -11 dirt
execute in minecraft:overworld run setblock 259 60 -11 gravel
execute in minecraft:overworld run fill 259 61 -11 259 144 -11 air
execute in minecraft:overworld run fill 259 61 -11 259 64 -11 water
execute in minecraft:overworld run fill 259 58 -10 259 57 -10 stone
execute in minecraft:overworld run fill 259 58 -10 259 59 -10 dirt
execute in minecraft:overworld run setblock 259 60 -10 gravel
execute in minecraft:overworld run fill 259 61 -10 259 144 -10 air
execute in minecraft:overworld run fill 259 61 -10 259 64 -10 water
execute in minecraft:overworld run fill 259 58 -9 259 57 -9 stone
execute in minecraft:overworld run fill 259 58 -9 259 59 -9 dirt
execute in minecraft:overworld run setblock 259 60 -9 gravel
execute in minecraft:overworld run fill 259 61 -9 259 144 -9 air
execute in minecraft:overworld run fill 259 61 -9 259 64 -9 water
execute in minecraft:overworld run fill 259 58 -8 259 56 -8 stone
execute in minecraft:overworld run fill 259 57 -8 259 58 -8 dirt
execute in minecraft:overworld run setblock 259 59 -8 gravel
execute in minecraft:overworld run fill 259 60 -8 259 144 -8 air
execute in minecraft:overworld run fill 259 60 -8 259 64 -8 water
execute in minecraft:overworld run fill 259 58 -7 259 56 -7 stone
execute in minecraft:overworld run fill 259 57 -7 259 58 -7 dirt
execute in minecraft:overworld run setblock 259 59 -7 gravel
execute in minecraft:overworld run fill 259 60 -7 259 144 -7 air
execute in minecraft:overworld run fill 259 60 -7 259 64 -7 water
execute in minecraft:overworld run fill 259 58 -6 259 56 -6 stone
execute in minecraft:overworld run fill 259 57 -6 259 58 -6 dirt
execute in minecraft:overworld run setblock 259 59 -6 gravel
execute in minecraft:overworld run fill 259 60 -6 259 144 -6 air
execute in minecraft:overworld run fill 259 60 -6 259 64 -6 water
execute in minecraft:overworld run fill 259 58 -5 259 56 -5 stone
execute in minecraft:overworld run fill 259 57 -5 259 58 -5 dirt
execute in minecraft:overworld run setblock 259 59 -5 gravel
execute in minecraft:overworld run fill 259 60 -5 259 144 -5 air
execute in minecraft:overworld run fill 259 60 -5 259 64 -5 water
execute in minecraft:overworld run fill 259 58 -4 259 56 -4 stone
execute in minecraft:overworld run fill 259 57 -4 259 58 -4 dirt
execute in minecraft:overworld run setblock 259 59 -4 gravel
execute in minecraft:overworld run fill 259 60 -4 259 144 -4 air
execute in minecraft:overworld run fill 259 60 -4 259 64 -4 water
execute in minecraft:overworld run fill 259 58 -3 259 56 -3 stone
execute in minecraft:overworld run fill 259 57 -3 259 58 -3 dirt
execute in minecraft:overworld run setblock 259 59 -3 gravel
execute in minecraft:overworld run fill 259 60 -3 259 144 -3 air
execute in minecraft:overworld run fill 259 60 -3 259 64 -3 water
execute in minecraft:overworld run fill 259 58 -2 259 56 -2 stone
execute in minecraft:overworld run fill 259 57 -2 259 58 -2 dirt
execute in minecraft:overworld run setblock 259 59 -2 gravel
execute in minecraft:overworld run fill 259 60 -2 259 144 -2 air
execute in minecraft:overworld run fill 259 60 -2 259 64 -2 water
schedule function blade_gallery:random/burned/part_80 1t replace
