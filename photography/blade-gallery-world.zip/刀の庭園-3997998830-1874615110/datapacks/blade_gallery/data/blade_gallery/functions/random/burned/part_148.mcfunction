execute in minecraft:overworld run fill 302 65 -39 302 66 -39 dirt
execute in minecraft:overworld run setblock 302 67 -39 grass_block
execute in minecraft:overworld run fill 302 68 -39 302 144 -39 air
execute in minecraft:overworld run fill 302 58 -38 302 64 -38 stone
execute in minecraft:overworld run fill 302 65 -38 302 66 -38 dirt
execute in minecraft:overworld run setblock 302 67 -38 coarse_dirt
execute in minecraft:overworld run fill 302 68 -38 302 144 -38 air
execute in minecraft:overworld run fill 302 58 -37 302 64 -37 stone
execute in minecraft:overworld run fill 302 65 -37 302 66 -37 dirt
execute in minecraft:overworld run setblock 302 67 -37 coarse_dirt
execute in minecraft:overworld run fill 302 68 -37 302 144 -37 air
execute in minecraft:overworld run fill 302 58 -36 302 64 -36 stone
execute in minecraft:overworld run fill 302 65 -36 302 66 -36 dirt
execute in minecraft:overworld run setblock 302 67 -36 coarse_dirt
execute in minecraft:overworld run fill 302 68 -36 302 144 -36 air
execute in minecraft:overworld run fill 302 58 -35 302 64 -35 stone
execute in minecraft:overworld run fill 302 65 -35 302 66 -35 dirt
execute in minecraft:overworld run setblock 302 67 -35 coarse_dirt
execute in minecraft:overworld run fill 302 68 -35 302 144 -35 air
execute in minecraft:overworld run fill 302 58 -34 302 64 -34 stone
execute in minecraft:overworld run fill 302 65 -34 302 66 -34 dirt
execute in minecraft:overworld run setblock 302 67 -34 coarse_dirt
execute in minecraft:overworld run fill 302 68 -34 302 144 -34 air
execute in minecraft:overworld run fill 302 58 -33 302 64 -33 stone
execute in minecraft:overworld run fill 302 65 -33 302 66 -33 dirt
execute in minecraft:overworld run setblock 302 67 -33 grass_block
execute in minecraft:overworld run fill 302 68 -33 302 144 -33 air
execute in minecraft:overworld run fill 302 58 -32 302 64 -32 stone
execute in minecraft:overworld run fill 302 65 -32 302 66 -32 dirt
execute in minecraft:overworld run setblock 302 67 -32 coarse_dirt
execute in minecraft:overworld run fill 302 68 -32 302 144 -32 air
execute in minecraft:overworld run fill 302 58 -31 302 64 -31 stone
execute in minecraft:overworld run fill 302 65 -31 302 66 -31 dirt
execute in minecraft:overworld run setblock 302 67 -31 coarse_dirt
execute in minecraft:overworld run fill 302 68 -31 302 144 -31 air
execute in minecraft:overworld run fill 302 58 -30 302 64 -30 stone
execute in minecraft:overworld run fill 302 65 -30 302 66 -30 dirt
execute in minecraft:overworld run setblock 302 67 -30 coarse_dirt
execute in minecraft:overworld run fill 302 68 -30 302 144 -30 air
execute in minecraft:overworld run fill 302 58 -29 302 64 -29 stone
execute in minecraft:overworld run fill 302 65 -29 302 66 -29 dirt
execute in minecraft:overworld run setblock 302 67 -29 coarse_dirt
execute in minecraft:overworld run fill 302 68 -29 302 144 -29 air
execute in minecraft:overworld run fill 302 58 -28 302 64 -28 stone
execute in minecraft:overworld run fill 302 65 -28 302 66 -28 dirt
execute in minecraft:overworld run setblock 302 67 -28 coarse_dirt
execute in minecraft:overworld run fill 302 68 -28 302 144 -28 air
execute in minecraft:overworld run fill 302 58 -27 302 64 -27 stone
execute in minecraft:overworld run fill 302 65 -27 302 66 -27 dirt
execute in minecraft:overworld run setblock 302 67 -27 coarse_dirt
execute in minecraft:overworld run fill 302 68 -27 302 144 -27 air
execute in minecraft:overworld run fill 302 58 -26 302 64 -26 stone
execute in minecraft:overworld run fill 302 65 -26 302 66 -26 dirt
execute in minecraft:overworld run setblock 302 67 -26 coarse_dirt
execute in minecraft:overworld run fill 302 68 -26 302 144 -26 air
execute in minecraft:overworld run fill 302 58 -25 302 64 -25 stone
execute in minecraft:overworld run fill 302 65 -25 302 66 -25 dirt
execute in minecraft:overworld run setblock 302 67 -25 coarse_dirt
execute in minecraft:overworld run fill 302 68 -25 302 144 -25 air
execute in minecraft:overworld run fill 302 58 -24 302 63 -24 stone
execute in minecraft:overworld run fill 302 64 -24 302 65 -24 dirt
execute in minecraft:overworld run setblock 302 66 -24 coarse_dirt
execute in minecraft:overworld run fill 302 67 -24 302 144 -24 air
execute in minecraft:overworld run fill 302 58 -23 302 63 -23 stone
execute in minecraft:overworld run fill 302 64 -23 302 65 -23 dirt
execute in minecraft:overworld run setblock 302 66 -23 coarse_dirt
execute in minecraft:overworld run fill 302 67 -23 302 144 -23 air
execute in minecraft:overworld run fill 302 58 -22 302 63 -22 stone
execute in minecraft:overworld run fill 302 64 -22 302 65 -22 dirt
execute in minecraft:overworld run setblock 302 66 -22 coarse_dirt
execute in minecraft:overworld run fill 302 67 -22 302 144 -22 air
execute in minecraft:overworld run fill 302 58 -21 302 63 -21 stone
execute in minecraft:overworld run fill 302 64 -21 302 65 -21 dirt
execute in minecraft:overworld run setblock 302 66 -21 coarse_dirt
execute in minecraft:overworld run fill 302 67 -21 302 144 -21 air
execute in minecraft:overworld run fill 302 58 -20 302 63 -20 stone
execute in minecraft:overworld run fill 302 64 -20 302 65 -20 dirt
execute in minecraft:overworld run setblock 302 66 -20 coarse_dirt
execute in minecraft:overworld run fill 302 67 -20 302 144 -20 air
execute in minecraft:overworld run fill 302 58 -19 302 63 -19 stone
execute in minecraft:overworld run fill 302 64 -19 302 65 -19 dirt
execute in minecraft:overworld run setblock 302 66 -19 grass_block
execute in minecraft:overworld run fill 302 67 -19 302 144 -19 air
execute in minecraft:overworld run fill 302 58 -18 302 63 -18 stone
execute in minecraft:overworld run fill 302 64 -18 302 65 -18 dirt
execute in minecraft:overworld run setblock 302 66 -18 coarse_dirt
execute in minecraft:overworld run fill 302 67 -18 302 144 -18 air
execute in minecraft:overworld run fill 302 58 -17 302 63 -17 stone
execute in minecraft:overworld run fill 302 64 -17 302 65 -17 dirt
execute in minecraft:overworld run setblock 302 66 -17 coarse_dirt
execute in minecraft:overworld run fill 302 67 -17 302 144 -17 air
execute in minecraft:overworld run fill 302 58 -16 302 63 -16 stone
execute in minecraft:overworld run fill 302 64 -16 302 65 -16 dirt
execute in minecraft:overworld run setblock 302 66 -16 coarse_dirt
execute in minecraft:overworld run fill 302 67 -16 302 144 -16 air
execute in minecraft:overworld run fill 302 58 -15 302 63 -15 stone
execute in minecraft:overworld run fill 302 64 -15 302 65 -15 dirt
execute in minecraft:overworld run setblock 302 66 -15 coarse_dirt
execute in minecraft:overworld run fill 302 67 -15 302 144 -15 air
execute in minecraft:overworld run fill 302 58 -14 302 63 -14 stone
execute in minecraft:overworld run fill 302 64 -14 302 65 -14 dirt
execute in minecraft:overworld run setblock 302 66 -14 coarse_dirt
execute in minecraft:overworld run fill 302 67 -14 302 144 -14 air
execute in minecraft:overworld run fill 302 58 -13 302 62 -13 stone
execute in minecraft:overworld run fill 302 63 -13 302 64 -13 dirt
execute in minecraft:overworld run setblock 302 65 -13 coarse_dirt
execute in minecraft:overworld run fill 302 66 -13 302 144 -13 air
execute in minecraft:overworld run fill 302 58 -12 302 62 -12 stone
execute in minecraft:overworld run fill 302 63 -12 302 64 -12 dirt
execute in minecraft:overworld run setblock 302 65 -12 coarse_dirt
execute in minecraft:overworld run fill 302 66 -12 302 144 -12 air
execute in minecraft:overworld run fill 302 58 -11 302 62 -11 stone
execute in minecraft:overworld run fill 302 63 -11 302 64 -11 dirt
execute in minecraft:overworld run setblock 302 65 -11 coarse_dirt
execute in minecraft:overworld run fill 302 66 -11 302 144 -11 air
execute in minecraft:overworld run fill 302 58 -10 302 62 -10 stone
execute in minecraft:overworld run fill 302 63 -10 302 64 -10 dirt
execute in minecraft:overworld run setblock 302 65 -10 grass_block
execute in minecraft:overworld run fill 302 66 -10 302 144 -10 air
execute in minecraft:overworld run fill 302 58 -9 302 62 -9 stone
execute in minecraft:overworld run fill 302 63 -9 302 64 -9 dirt
execute in minecraft:overworld run setblock 302 65 -9 grass_block
execute in minecraft:overworld run fill 302 66 -9 302 144 -9 air
execute in minecraft:overworld run fill 302 58 -8 302 62 -8 stone
execute in minecraft:overworld run fill 302 63 -8 302 64 -8 dirt
execute in minecraft:overworld run setblock 302 65 -8 coarse_dirt
execute in minecraft:overworld run fill 302 66 -8 302 144 -8 air
execute in minecraft:overworld run fill 302 58 -7 302 62 -7 stone
execute in minecraft:overworld run fill 302 63 -7 302 64 -7 dirt
execute in minecraft:overworld run setblock 302 65 -7 coarse_dirt
execute in minecraft:overworld run fill 302 66 -7 302 144 -7 air
execute in minecraft:overworld run fill 302 58 -6 302 62 -6 stone
execute in minecraft:overworld run fill 302 63 -6 302 64 -6 dirt
execute in minecraft:overworld run setblock 302 65 -6 coarse_dirt
execute in minecraft:overworld run fill 302 66 -6 302 144 -6 air
execute in minecraft:overworld run fill 302 58 -5 302 62 -5 stone
execute in minecraft:overworld run fill 302 63 -5 302 64 -5 dirt
execute in minecraft:overworld run setblock 302 65 -5 coarse_dirt
execute in minecraft:overworld run fill 302 66 -5 302 144 -5 air
execute in minecraft:overworld run fill 302 58 -4 302 62 -4 stone
execute in minecraft:overworld run fill 302 63 -4 302 64 -4 dirt
execute in minecraft:overworld run setblock 302 65 -4 coarse_dirt
execute in minecraft:overworld run fill 302 66 -4 302 144 -4 air
execute in minecraft:overworld run fill 302 58 -3 302 62 -3 stone
execute in minecraft:overworld run fill 302 63 -3 302 64 -3 dirt
execute in minecraft:overworld run setblock 302 65 -3 grass_block
execute in minecraft:overworld run fill 302 66 -3 302 144 -3 air
execute in minecraft:overworld run fill 302 58 -2 302 62 -2 stone
execute in minecraft:overworld run fill 302 63 -2 302 64 -2 dirt
execute in minecraft:overworld run setblock 302 65 -2 coarse_dirt
execute in minecraft:overworld run fill 302 66 -2 302 144 -2 air
execute in minecraft:overworld run fill 302 58 -1 302 62 -1 stone
execute in minecraft:overworld run fill 302 63 -1 302 64 -1 dirt
execute in minecraft:overworld run setblock 302 65 -1 coarse_dirt
execute in minecraft:overworld run fill 302 66 -1 302 144 -1 air
execute in minecraft:overworld run fill 302 58 0 302 62 0 stone
execute in minecraft:overworld run fill 302 63 0 302 64 0 dirt
execute in minecraft:overworld run setblock 302 65 0 coarse_dirt
execute in minecraft:overworld run fill 302 66 0 302 144 0 air
execute in minecraft:overworld run fill 302 58 1 302 62 1 stone
execute in minecraft:overworld run fill 302 63 1 302 64 1 dirt
execute in minecraft:overworld run setblock 302 65 1 grass_block
execute in minecraft:overworld run fill 302 66 1 302 144 1 air
execute in minecraft:overworld run fill 302 58 2 302 62 2 stone
execute in minecraft:overworld run fill 302 63 2 302 64 2 dirt
execute in minecraft:overworld run setblock 302 65 2 grass_block
execute in minecraft:overworld run fill 302 66 2 302 144 2 air
execute in minecraft:overworld run fill 302 58 3 302 62 3 stone
execute in minecraft:overworld run fill 302 63 3 302 64 3 dirt
execute in minecraft:overworld run setblock 302 65 3 grass_block
execute in minecraft:overworld run fill 302 66 3 302 144 3 air
execute in minecraft:overworld run fill 302 58 4 302 62 4 stone
execute in minecraft:overworld run fill 302 63 4 302 64 4 dirt
execute in minecraft:overworld run setblock 302 65 4 coarse_dirt
execute in minecraft:overworld run fill 302 66 4 302 144 4 air
execute in minecraft:overworld run fill 302 58 5 302 62 5 stone
execute in minecraft:overworld run fill 302 63 5 302 64 5 dirt
execute in minecraft:overworld run setblock 302 65 5 coarse_dirt
execute in minecraft:overworld run fill 302 66 5 302 144 5 air
execute in minecraft:overworld run fill 302 58 6 302 62 6 stone
execute in minecraft:overworld run fill 302 63 6 302 64 6 dirt
execute in minecraft:overworld run setblock 302 65 6 grass_block
execute in minecraft:overworld run fill 302 66 6 302 144 6 air
execute in minecraft:overworld run fill 302 58 7 302 62 7 stone
execute in minecraft:overworld run fill 302 63 7 302 64 7 dirt
execute in minecraft:overworld run setblock 302 65 7 coarse_dirt
execute in minecraft:overworld run fill 302 66 7 302 144 7 air
execute in minecraft:overworld run fill 302 58 8 302 62 8 stone
execute in minecraft:overworld run fill 302 63 8 302 64 8 dirt
execute in minecraft:overworld run setblock 302 65 8 coarse_dirt
execute in minecraft:overworld run fill 302 66 8 302 144 8 air
execute in minecraft:overworld run fill 302 58 9 302 62 9 stone
execute in minecraft:overworld run fill 302 63 9 302 64 9 dirt
execute in minecraft:overworld run setblock 302 65 9 coarse_dirt
execute in minecraft:overworld run fill 302 66 9 302 144 9 air
execute in minecraft:overworld run fill 302 58 10 302 62 10 stone
execute in minecraft:overworld run fill 302 63 10 302 64 10 dirt
execute in minecraft:overworld run setblock 302 65 10 coarse_dirt
execute in minecraft:overworld run fill 302 66 10 302 144 10 air
execute in minecraft:overworld run fill 302 58 11 302 62 11 stone
execute in minecraft:overworld run fill 302 63 11 302 64 11 dirt
execute in minecraft:overworld run setblock 302 65 11 coarse_dirt
execute in minecraft:overworld run fill 302 66 11 302 144 11 air
execute in minecraft:overworld run fill 302 58 12 302 62 12 stone
execute in minecraft:overworld run fill 302 63 12 302 64 12 dirt
execute in minecraft:overworld run setblock 302 65 12 coarse_dirt
execute in minecraft:overworld run fill 302 66 12 302 144 12 air
execute in minecraft:overworld run fill 302 58 13 302 62 13 stone
execute in minecraft:overworld run fill 302 63 13 302 64 13 dirt
execute in minecraft:overworld run setblock 302 65 13 grass_block
execute in minecraft:overworld run fill 302 66 13 302 144 13 air
execute in minecraft:overworld run fill 302 58 14 302 62 14 stone
execute in minecraft:overworld run fill 302 63 14 302 64 14 dirt
execute in minecraft:overworld run setblock 302 65 14 grass_block
execute in minecraft:overworld run fill 302 66 14 302 144 14 air
execute in minecraft:overworld run fill 302 58 15 302 62 15 stone
execute in minecraft:overworld run fill 302 63 15 302 64 15 dirt
execute in minecraft:overworld run setblock 302 65 15 grass_block
execute in minecraft:overworld run fill 302 66 15 302 144 15 air
execute in minecraft:overworld run fill 302 58 16 302 62 16 stone
execute in minecraft:overworld run fill 302 63 16 302 64 16 dirt
execute in minecraft:overworld run setblock 302 65 16 coarse_dirt
execute in minecraft:overworld run fill 302 66 16 302 144 16 air
execute in minecraft:overworld run fill 302 58 17 302 62 17 stone
execute in minecraft:overworld run fill 302 63 17 302 64 17 dirt
execute in minecraft:overworld run setblock 302 65 17 coarse_dirt
execute in minecraft:overworld run fill 302 66 17 302 144 17 air
execute in minecraft:overworld run fill 302 58 18 302 62 18 stone
execute in minecraft:overworld run fill 302 63 18 302 64 18 dirt
execute in minecraft:overworld run setblock 302 65 18 coarse_dirt
execute in minecraft:overworld run fill 302 66 18 302 144 18 air
execute in minecraft:overworld run fill 302 58 19 302 62 19 stone
execute in minecraft:overworld run fill 302 63 19 302 64 19 dirt
execute in minecraft:overworld run setblock 302 65 19 coarse_dirt
execute in minecraft:overworld run fill 302 66 19 302 144 19 air
execute in minecraft:overworld run fill 302 58 20 302 62 20 stone
execute in minecraft:overworld run fill 302 63 20 302 64 20 dirt
execute in minecraft:overworld run setblock 302 65 20 coarse_dirt
execute in minecraft:overworld run fill 302 66 20 302 144 20 air
execute in minecraft:overworld run fill 302 58 21 302 62 21 stone
execute in minecraft:overworld run fill 302 63 21 302 64 21 dirt
execute in minecraft:overworld run setblock 302 65 21 coarse_dirt
execute in minecraft:overworld run fill 302 66 21 302 144 21 air
execute in minecraft:overworld run fill 302 58 22 302 62 22 stone
execute in minecraft:overworld run fill 302 63 22 302 64 22 dirt
execute in minecraft:overworld run setblock 302 65 22 coarse_dirt
execute in minecraft:overworld run fill 302 66 22 302 144 22 air
execute in minecraft:overworld run fill 302 58 23 302 62 23 stone
execute in minecraft:overworld run fill 302 63 23 302 64 23 dirt
execute in minecraft:overworld run setblock 302 65 23 grass_block
execute in minecraft:overworld run fill 302 66 23 302 144 23 air
execute in minecraft:overworld run fill 302 58 24 302 62 24 stone
execute in minecraft:overworld run fill 302 63 24 302 64 24 dirt
execute in minecraft:overworld run setblock 302 65 24 grass_block
execute in minecraft:overworld run fill 302 66 24 302 144 24 air
execute in minecraft:overworld run fill 302 58 25 302 62 25 stone
schedule function blade_gallery:random/burned/part_149 1t replace
