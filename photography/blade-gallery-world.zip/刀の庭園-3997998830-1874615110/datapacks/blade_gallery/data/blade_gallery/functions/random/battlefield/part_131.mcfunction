execute in minecraft:overworld run fill 419 66 -7 419 67 -7 dirt
execute in minecraft:overworld run setblock 419 68 -7 grass_block
execute in minecraft:overworld run fill 419 69 -7 419 144 -7 air
execute in minecraft:overworld run fill 419 58 -6 419 65 -6 stone
execute in minecraft:overworld run fill 419 66 -6 419 67 -6 dirt
execute in minecraft:overworld run setblock 419 68 -6 coarse_dirt
execute in minecraft:overworld run fill 419 69 -6 419 144 -6 air
execute in minecraft:overworld run fill 419 58 -5 419 64 -5 stone
execute in minecraft:overworld run fill 419 65 -5 419 66 -5 dirt
execute in minecraft:overworld run setblock 419 67 -5 coarse_dirt
execute in minecraft:overworld run fill 419 68 -5 419 144 -5 air
execute in minecraft:overworld run setblock 419 68 -5 grass
execute in minecraft:overworld run fill 419 58 -4 419 64 -4 stone
execute in minecraft:overworld run fill 419 65 -4 419 66 -4 dirt
execute in minecraft:overworld run setblock 419 67 -4 coarse_dirt
execute in minecraft:overworld run fill 419 68 -4 419 144 -4 air
execute in minecraft:overworld run fill 419 58 -3 419 64 -3 stone
execute in minecraft:overworld run fill 419 65 -3 419 66 -3 dirt
execute in minecraft:overworld run setblock 419 67 -3 grass_block
execute in minecraft:overworld run fill 419 68 -3 419 144 -3 air
execute in minecraft:overworld run fill 419 58 -2 419 63 -2 stone
execute in minecraft:overworld run fill 419 64 -2 419 65 -2 dirt
execute in minecraft:overworld run setblock 419 66 -2 grass_block
execute in minecraft:overworld run fill 419 67 -2 419 144 -2 air
execute in minecraft:overworld run fill 419 58 -1 419 63 -1 stone
execute in minecraft:overworld run fill 419 64 -1 419 65 -1 dirt
execute in minecraft:overworld run setblock 419 66 -1 grass_block
execute in minecraft:overworld run fill 419 67 -1 419 144 -1 air
execute in minecraft:overworld run fill 419 58 0 419 63 0 stone
execute in minecraft:overworld run fill 419 64 0 419 65 0 dirt
execute in minecraft:overworld run setblock 419 66 0 coarse_dirt
execute in minecraft:overworld run fill 419 67 0 419 144 0 air
execute in minecraft:overworld run fill 419 58 1 419 63 1 stone
execute in minecraft:overworld run fill 419 64 1 419 65 1 dirt
execute in minecraft:overworld run setblock 419 66 1 grass_block
execute in minecraft:overworld run fill 419 67 1 419 144 1 air
execute in minecraft:overworld run fill 419 58 2 419 63 2 stone
execute in minecraft:overworld run fill 419 64 2 419 65 2 dirt
execute in minecraft:overworld run setblock 419 66 2 coarse_dirt
execute in minecraft:overworld run fill 419 67 2 419 144 2 air
execute in minecraft:overworld run fill 419 58 3 419 64 3 stone
execute in minecraft:overworld run fill 419 65 3 419 66 3 dirt
execute in minecraft:overworld run setblock 419 67 3 grass_block
execute in minecraft:overworld run fill 419 68 3 419 144 3 air
execute in minecraft:overworld run fill 419 58 4 419 64 4 stone
execute in minecraft:overworld run fill 419 65 4 419 66 4 dirt
execute in minecraft:overworld run setblock 419 67 4 grass_block
execute in minecraft:overworld run fill 419 68 4 419 144 4 air
execute in minecraft:overworld run fill 419 58 5 419 64 5 stone
execute in minecraft:overworld run fill 419 65 5 419 66 5 dirt
execute in minecraft:overworld run setblock 419 67 5 grass_block
execute in minecraft:overworld run fill 419 68 5 419 144 5 air
execute in minecraft:overworld run fill 419 58 6 419 65 6 stone
execute in minecraft:overworld run fill 419 66 6 419 67 6 dirt
execute in minecraft:overworld run setblock 419 68 6 grass_block
execute in minecraft:overworld run fill 419 69 6 419 144 6 air
execute in minecraft:overworld run fill 419 58 7 419 65 7 stone
execute in minecraft:overworld run fill 419 66 7 419 67 7 dirt
execute in minecraft:overworld run setblock 419 68 7 coarse_dirt
execute in minecraft:overworld run fill 419 69 7 419 144 7 air
execute in minecraft:overworld run fill 419 58 8 419 65 8 stone
execute in minecraft:overworld run fill 419 66 8 419 67 8 dirt
execute in minecraft:overworld run setblock 419 68 8 grass_block
execute in minecraft:overworld run fill 419 69 8 419 144 8 air
execute in minecraft:overworld run fill 419 58 9 419 66 9 stone
execute in minecraft:overworld run fill 419 67 9 419 68 9 dirt
execute in minecraft:overworld run setblock 419 69 9 grass_block
execute in minecraft:overworld run fill 419 70 9 419 144 9 air
execute in minecraft:overworld run fill 419 58 10 419 66 10 stone
execute in minecraft:overworld run fill 419 67 10 419 68 10 dirt
execute in minecraft:overworld run setblock 419 69 10 coarse_dirt
execute in minecraft:overworld run fill 419 70 10 419 144 10 air
execute in minecraft:overworld run fill 419 58 11 419 66 11 stone
execute in minecraft:overworld run fill 419 67 11 419 68 11 dirt
execute in minecraft:overworld run setblock 419 69 11 coarse_dirt
execute in minecraft:overworld run fill 419 70 11 419 144 11 air
execute in minecraft:overworld run fill 419 58 12 419 67 12 stone
execute in minecraft:overworld run fill 419 68 12 419 69 12 dirt
execute in minecraft:overworld run setblock 419 70 12 coarse_dirt
execute in minecraft:overworld run fill 419 71 12 419 144 12 air
execute in minecraft:overworld run fill 419 58 13 419 67 13 stone
execute in minecraft:overworld run fill 419 68 13 419 69 13 dirt
execute in minecraft:overworld run setblock 419 70 13 coarse_dirt
execute in minecraft:overworld run fill 419 71 13 419 144 13 air
execute in minecraft:overworld run fill 419 58 14 419 67 14 stone
execute in minecraft:overworld run fill 419 68 14 419 69 14 dirt
execute in minecraft:overworld run setblock 419 70 14 grass_block
execute in minecraft:overworld run fill 419 71 14 419 144 14 air
execute in minecraft:overworld run fill 419 58 15 419 68 15 stone
execute in minecraft:overworld run fill 419 69 15 419 70 15 dirt
execute in minecraft:overworld run setblock 419 71 15 grass_block
execute in minecraft:overworld run fill 419 72 15 419 144 15 air
execute in minecraft:overworld run setblock 419 72 15 grass
execute in minecraft:overworld run fill 419 58 16 419 68 16 stone
execute in minecraft:overworld run fill 419 69 16 419 70 16 dirt
execute in minecraft:overworld run setblock 419 71 16 coarse_dirt
execute in minecraft:overworld run fill 419 72 16 419 144 16 air
execute in minecraft:overworld run fill 419 58 17 419 69 17 stone
execute in minecraft:overworld run fill 419 70 17 419 71 17 dirt
execute in minecraft:overworld run setblock 419 72 17 coarse_dirt
execute in minecraft:overworld run fill 419 73 17 419 144 17 air
execute in minecraft:overworld run fill 419 58 18 419 69 18 stone
execute in minecraft:overworld run fill 419 70 18 419 71 18 dirt
execute in minecraft:overworld run setblock 419 72 18 coarse_dirt
execute in minecraft:overworld run fill 419 73 18 419 144 18 air
execute in minecraft:overworld run fill 419 58 19 419 69 19 stone
execute in minecraft:overworld run fill 419 70 19 419 71 19 dirt
execute in minecraft:overworld run setblock 419 72 19 coarse_dirt
execute in minecraft:overworld run fill 419 73 19 419 144 19 air
execute in minecraft:overworld run fill 419 58 20 419 70 20 stone
execute in minecraft:overworld run fill 419 71 20 419 72 20 dirt
execute in minecraft:overworld run setblock 419 73 20 coarse_dirt
execute in minecraft:overworld run fill 419 74 20 419 144 20 air
execute in minecraft:overworld run fill 419 58 21 419 70 21 stone
execute in minecraft:overworld run fill 419 71 21 419 72 21 dirt
execute in minecraft:overworld run setblock 419 73 21 grass_block
execute in minecraft:overworld run fill 419 74 21 419 144 21 air
execute in minecraft:overworld run setblock 419 74 21 grass
execute in minecraft:overworld run fill 419 58 22 419 70 22 stone
execute in minecraft:overworld run fill 419 71 22 419 72 22 dirt
execute in minecraft:overworld run setblock 419 73 22 coarse_dirt
execute in minecraft:overworld run fill 419 74 22 419 144 22 air
execute in minecraft:overworld run fill 419 58 23 419 71 23 stone
execute in minecraft:overworld run fill 419 72 23 419 73 23 dirt
execute in minecraft:overworld run setblock 419 74 23 grass_block
execute in minecraft:overworld run fill 419 75 23 419 144 23 air
execute in minecraft:overworld run fill 419 58 24 419 71 24 stone
execute in minecraft:overworld run fill 419 72 24 419 73 24 dirt
execute in minecraft:overworld run setblock 419 74 24 coarse_dirt
execute in minecraft:overworld run fill 419 75 24 419 144 24 air
execute in minecraft:overworld run fill 419 58 25 419 71 25 stone
execute in minecraft:overworld run fill 419 72 25 419 73 25 dirt
execute in minecraft:overworld run setblock 419 74 25 grass_block
execute in minecraft:overworld run fill 419 75 25 419 144 25 air
execute in minecraft:overworld run fill 419 58 26 419 71 26 stone
execute in minecraft:overworld run fill 419 72 26 419 73 26 dirt
execute in minecraft:overworld run setblock 419 74 26 grass_block
execute in minecraft:overworld run fill 419 75 26 419 144 26 air
execute in minecraft:overworld run setblock 419 75 26 grass
execute in minecraft:overworld run fill 419 58 27 419 71 27 stone
execute in minecraft:overworld run fill 419 72 27 419 73 27 dirt
execute in minecraft:overworld run setblock 419 74 27 coarse_dirt
execute in minecraft:overworld run fill 419 75 27 419 144 27 air
execute in minecraft:overworld run fill 419 58 28 419 71 28 stone
execute in minecraft:overworld run fill 419 72 28 419 73 28 dirt
execute in minecraft:overworld run setblock 419 74 28 coarse_dirt
execute in minecraft:overworld run fill 419 75 28 419 144 28 air
execute in minecraft:overworld run fill 419 58 29 419 71 29 stone
execute in minecraft:overworld run fill 419 72 29 419 73 29 dirt
execute in minecraft:overworld run setblock 419 74 29 coarse_dirt
execute in minecraft:overworld run fill 419 75 29 419 144 29 air
execute in minecraft:overworld run setblock 419 75 29 mossy_cobblestone
execute in minecraft:overworld run fill 419 58 30 419 71 30 stone
execute in minecraft:overworld run fill 419 72 30 419 73 30 dirt
execute in minecraft:overworld run setblock 419 74 30 grass_block
execute in minecraft:overworld run fill 419 75 30 419 144 30 air
execute in minecraft:overworld run setblock 419 75 30 mossy_cobblestone
execute in minecraft:overworld run fill 419 58 31 419 71 31 stone
execute in minecraft:overworld run fill 419 72 31 419 73 31 dirt
execute in minecraft:overworld run setblock 419 74 31 coarse_dirt
execute in minecraft:overworld run fill 419 75 31 419 144 31 air
execute in minecraft:overworld run fill 419 58 32 419 71 32 stone
execute in minecraft:overworld run fill 419 72 32 419 73 32 dirt
execute in minecraft:overworld run setblock 419 74 32 coarse_dirt
execute in minecraft:overworld run fill 419 75 32 419 144 32 air
execute in minecraft:overworld run fill 419 58 33 419 71 33 stone
execute in minecraft:overworld run fill 419 72 33 419 73 33 dirt
execute in minecraft:overworld run setblock 419 74 33 coarse_dirt
execute in minecraft:overworld run fill 419 75 33 419 144 33 air
execute in minecraft:overworld run fill 419 58 34 419 70 34 stone
execute in minecraft:overworld run fill 419 71 34 419 72 34 dirt
execute in minecraft:overworld run setblock 419 73 34 coarse_dirt
execute in minecraft:overworld run fill 419 74 34 419 144 34 air
execute in minecraft:overworld run fill 419 58 35 419 70 35 stone
execute in minecraft:overworld run fill 419 71 35 419 72 35 dirt
execute in minecraft:overworld run setblock 419 73 35 coarse_dirt
execute in minecraft:overworld run fill 419 74 35 419 144 35 air
execute in minecraft:overworld run fill 419 58 36 419 70 36 stone
execute in minecraft:overworld run fill 419 71 36 419 72 36 dirt
execute in minecraft:overworld run setblock 419 73 36 coarse_dirt
execute in minecraft:overworld run fill 419 74 36 419 144 36 air
execute in minecraft:overworld run fill 419 58 37 419 69 37 stone
execute in minecraft:overworld run fill 419 70 37 419 71 37 dirt
execute in minecraft:overworld run setblock 419 72 37 coarse_dirt
execute in minecraft:overworld run fill 419 73 37 419 144 37 air
execute in minecraft:overworld run fill 419 58 38 419 69 38 stone
execute in minecraft:overworld run fill 419 70 38 419 71 38 dirt
execute in minecraft:overworld run setblock 419 72 38 coarse_dirt
execute in minecraft:overworld run fill 419 73 38 419 144 38 air
execute in minecraft:overworld run fill 419 58 39 419 67 39 stone
execute in minecraft:overworld run fill 419 68 39 419 69 39 dirt
execute in minecraft:overworld run setblock 419 70 39 grass_block
execute in minecraft:overworld run fill 419 71 39 419 144 39 air
execute in minecraft:overworld run setblock 419 71 39 grass
execute in minecraft:overworld run fill 419 58 40 419 66 40 stone
execute in minecraft:overworld run fill 419 67 40 419 68 40 dirt
execute in minecraft:overworld run setblock 419 69 40 grass_block
execute in minecraft:overworld run fill 419 70 40 419 144 40 air
execute in minecraft:overworld run fill 419 58 41 419 65 41 stone
execute in minecraft:overworld run fill 419 66 41 419 67 41 dirt
execute in minecraft:overworld run setblock 419 68 41 coarse_dirt
execute in minecraft:overworld run fill 419 69 41 419 144 41 air
execute in minecraft:overworld run fill 419 58 42 419 64 42 stone
execute in minecraft:overworld run fill 419 65 42 419 66 42 dirt
execute in minecraft:overworld run setblock 419 67 42 coarse_dirt
execute in minecraft:overworld run fill 419 68 42 419 144 42 air
execute in minecraft:overworld run fill 419 58 43 419 63 43 stone
execute in minecraft:overworld run fill 419 64 43 419 65 43 dirt
execute in minecraft:overworld run setblock 419 66 43 coarse_dirt
execute in minecraft:overworld run fill 419 67 43 419 144 43 air
execute in minecraft:overworld run fill 419 58 44 419 62 44 stone
execute in minecraft:overworld run fill 419 63 44 419 64 44 dirt
execute in minecraft:overworld run setblock 419 65 44 grass_block
execute in minecraft:overworld run fill 419 66 44 419 144 44 air
execute in minecraft:overworld run fill 419 58 45 419 62 45 stone
execute in minecraft:overworld run fill 419 63 45 419 64 45 dirt
execute in minecraft:overworld run setblock 419 65 45 coarse_dirt
execute in minecraft:overworld run fill 419 66 45 419 144 45 air
execute in minecraft:overworld run fill 419 58 46 419 62 46 stone
execute in minecraft:overworld run fill 419 63 46 419 64 46 dirt
execute in minecraft:overworld run setblock 419 65 46 coarse_dirt
execute in minecraft:overworld run fill 419 66 46 419 144 46 air
execute in minecraft:overworld run fill 419 58 47 419 61 47 stone
execute in minecraft:overworld run fill 419 62 47 419 63 47 dirt
execute in minecraft:overworld run setblock 419 64 47 coarse_dirt
execute in minecraft:overworld run fill 419 65 47 419 144 47 air
execute in minecraft:overworld run fill 420 58 -48 420 61 -48 stone
execute in minecraft:overworld run fill 420 62 -48 420 63 -48 dirt
execute in minecraft:overworld run setblock 420 64 -48 coarse_dirt
execute in minecraft:overworld run fill 420 65 -48 420 144 -48 air
execute in minecraft:overworld run fill 420 58 -47 420 63 -47 stone
execute in minecraft:overworld run fill 420 64 -47 420 65 -47 dirt
execute in minecraft:overworld run setblock 420 66 -47 grass_block
execute in minecraft:overworld run fill 420 67 -47 420 144 -47 air
execute in minecraft:overworld run fill 420 58 -46 420 64 -46 stone
execute in minecraft:overworld run fill 420 65 -46 420 66 -46 dirt
execute in minecraft:overworld run setblock 420 67 -46 grass_block
execute in minecraft:overworld run fill 420 68 -46 420 144 -46 air
execute in minecraft:overworld run fill 420 58 -45 420 66 -45 stone
execute in minecraft:overworld run fill 420 67 -45 420 68 -45 dirt
execute in minecraft:overworld run setblock 420 69 -45 grass_block
execute in minecraft:overworld run fill 420 70 -45 420 144 -45 air
execute in minecraft:overworld run fill 420 58 -44 420 67 -44 stone
execute in minecraft:overworld run fill 420 68 -44 420 69 -44 dirt
execute in minecraft:overworld run setblock 420 70 -44 grass_block
execute in minecraft:overworld run fill 420 71 -44 420 144 -44 air
execute in minecraft:overworld run fill 420 58 -43 420 69 -43 stone
execute in minecraft:overworld run fill 420 70 -43 420 71 -43 dirt
execute in minecraft:overworld run setblock 420 72 -43 grass_block
execute in minecraft:overworld run fill 420 73 -43 420 144 -43 air
execute in minecraft:overworld run fill 420 58 -42 420 70 -42 stone
execute in minecraft:overworld run fill 420 71 -42 420 72 -42 dirt
execute in minecraft:overworld run setblock 420 73 -42 coarse_dirt
execute in minecraft:overworld run fill 420 74 -42 420 144 -42 air
execute in minecraft:overworld run fill 420 58 -41 420 72 -41 stone
execute in minecraft:overworld run fill 420 73 -41 420 74 -41 dirt
schedule function blade_gallery:random/battlefield/part_132 1t replace
