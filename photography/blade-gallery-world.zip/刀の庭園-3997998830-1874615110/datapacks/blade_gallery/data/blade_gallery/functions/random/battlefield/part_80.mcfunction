execute in minecraft:overworld run fill 387 58 32 387 60 32 stone
execute in minecraft:overworld run fill 387 61 32 387 62 32 dirt
execute in minecraft:overworld run setblock 387 63 32 gravel
execute in minecraft:overworld run fill 387 64 32 387 144 32 air
execute in minecraft:overworld run fill 387 64 32 387 64 32 water
execute in minecraft:overworld run fill 387 58 33 387 60 33 stone
execute in minecraft:overworld run fill 387 61 33 387 62 33 dirt
execute in minecraft:overworld run setblock 387 63 33 gravel
execute in minecraft:overworld run fill 387 64 33 387 144 33 air
execute in minecraft:overworld run fill 387 64 33 387 64 33 water
execute in minecraft:overworld run fill 387 58 34 387 60 34 stone
execute in minecraft:overworld run fill 387 61 34 387 62 34 dirt
execute in minecraft:overworld run setblock 387 63 34 gravel
execute in minecraft:overworld run fill 387 64 34 387 144 34 air
execute in minecraft:overworld run fill 387 64 34 387 64 34 water
execute in minecraft:overworld run fill 387 58 35 387 60 35 stone
execute in minecraft:overworld run fill 387 61 35 387 62 35 dirt
execute in minecraft:overworld run setblock 387 63 35 gravel
execute in minecraft:overworld run fill 387 64 35 387 144 35 air
execute in minecraft:overworld run fill 387 64 35 387 64 35 water
execute in minecraft:overworld run fill 387 58 36 387 60 36 stone
execute in minecraft:overworld run fill 387 61 36 387 62 36 dirt
execute in minecraft:overworld run setblock 387 63 36 gravel
execute in minecraft:overworld run fill 387 64 36 387 144 36 air
execute in minecraft:overworld run fill 387 64 36 387 64 36 water
execute in minecraft:overworld run fill 387 58 37 387 59 37 stone
execute in minecraft:overworld run fill 387 60 37 387 61 37 dirt
execute in minecraft:overworld run setblock 387 62 37 gravel
execute in minecraft:overworld run fill 387 63 37 387 144 37 air
execute in minecraft:overworld run fill 387 63 37 387 64 37 water
execute in minecraft:overworld run fill 387 58 38 387 59 38 stone
execute in minecraft:overworld run fill 387 60 38 387 61 38 dirt
execute in minecraft:overworld run setblock 387 62 38 gravel
execute in minecraft:overworld run fill 387 63 38 387 144 38 air
execute in minecraft:overworld run fill 387 63 38 387 64 38 water
execute in minecraft:overworld run fill 387 58 39 387 59 39 stone
execute in minecraft:overworld run fill 387 60 39 387 61 39 dirt
execute in minecraft:overworld run setblock 387 62 39 gravel
execute in minecraft:overworld run fill 387 63 39 387 144 39 air
execute in minecraft:overworld run fill 387 63 39 387 64 39 water
execute in minecraft:overworld run fill 387 58 40 387 60 40 stone
execute in minecraft:overworld run fill 387 61 40 387 62 40 dirt
execute in minecraft:overworld run setblock 387 63 40 gravel
execute in minecraft:overworld run fill 387 64 40 387 144 40 air
execute in minecraft:overworld run fill 387 64 40 387 64 40 water
execute in minecraft:overworld run fill 387 58 41 387 60 41 stone
execute in minecraft:overworld run fill 387 61 41 387 62 41 dirt
execute in minecraft:overworld run setblock 387 63 41 gravel
execute in minecraft:overworld run fill 387 64 41 387 144 41 air
execute in minecraft:overworld run fill 387 64 41 387 64 41 water
execute in minecraft:overworld run fill 387 58 42 387 60 42 stone
execute in minecraft:overworld run fill 387 61 42 387 62 42 dirt
execute in minecraft:overworld run setblock 387 63 42 gravel
execute in minecraft:overworld run fill 387 64 42 387 144 42 air
execute in minecraft:overworld run fill 387 64 42 387 64 42 water
execute in minecraft:overworld run fill 387 58 43 387 60 43 stone
execute in minecraft:overworld run fill 387 61 43 387 62 43 dirt
execute in minecraft:overworld run setblock 387 63 43 gravel
execute in minecraft:overworld run fill 387 64 43 387 144 43 air
execute in minecraft:overworld run fill 387 64 43 387 64 43 water
execute in minecraft:overworld run fill 387 58 44 387 61 44 stone
execute in minecraft:overworld run fill 387 62 44 387 63 44 dirt
execute in minecraft:overworld run setblock 387 64 44 coarse_dirt
execute in minecraft:overworld run fill 387 65 44 387 144 44 air
execute in minecraft:overworld run fill 387 58 45 387 61 45 stone
execute in minecraft:overworld run fill 387 62 45 387 63 45 dirt
execute in minecraft:overworld run setblock 387 64 45 coarse_dirt
execute in minecraft:overworld run fill 387 65 45 387 144 45 air
execute in minecraft:overworld run fill 387 58 46 387 61 46 stone
execute in minecraft:overworld run fill 387 62 46 387 63 46 dirt
execute in minecraft:overworld run setblock 387 64 46 coarse_dirt
execute in minecraft:overworld run fill 387 65 46 387 144 46 air
execute in minecraft:overworld run fill 387 58 47 387 61 47 stone
execute in minecraft:overworld run fill 387 62 47 387 63 47 dirt
execute in minecraft:overworld run setblock 387 64 47 coarse_dirt
execute in minecraft:overworld run fill 387 65 47 387 144 47 air
execute in minecraft:overworld run fill 388 58 -48 388 61 -48 stone
execute in minecraft:overworld run fill 388 62 -48 388 63 -48 dirt
execute in minecraft:overworld run setblock 388 64 -48 coarse_dirt
execute in minecraft:overworld run fill 388 65 -48 388 144 -48 air
execute in minecraft:overworld run fill 388 58 -47 388 62 -47 stone
execute in minecraft:overworld run fill 388 63 -47 388 64 -47 dirt
execute in minecraft:overworld run setblock 388 65 -47 grass_block
execute in minecraft:overworld run fill 388 66 -47 388 144 -47 air
execute in minecraft:overworld run fill 388 58 -46 388 64 -46 stone
execute in minecraft:overworld run fill 388 65 -46 388 66 -46 dirt
execute in minecraft:overworld run setblock 388 67 -46 coarse_dirt
execute in minecraft:overworld run fill 388 68 -46 388 144 -46 air
execute in minecraft:overworld run fill 388 58 -45 388 65 -45 stone
execute in minecraft:overworld run fill 388 66 -45 388 67 -45 dirt
execute in minecraft:overworld run setblock 388 68 -45 coarse_dirt
execute in minecraft:overworld run fill 388 69 -45 388 144 -45 air
execute in minecraft:overworld run fill 388 58 -44 388 67 -44 stone
execute in minecraft:overworld run fill 388 68 -44 388 69 -44 dirt
execute in minecraft:overworld run setblock 388 70 -44 grass_block
execute in minecraft:overworld run fill 388 71 -44 388 144 -44 air
execute in minecraft:overworld run fill 388 58 -43 388 68 -43 stone
execute in minecraft:overworld run fill 388 69 -43 388 70 -43 dirt
execute in minecraft:overworld run setblock 388 71 -43 coarse_dirt
execute in minecraft:overworld run fill 388 72 -43 388 144 -43 air
execute in minecraft:overworld run fill 388 58 -42 388 69 -42 stone
execute in minecraft:overworld run fill 388 70 -42 388 71 -42 dirt
execute in minecraft:overworld run setblock 388 72 -42 coarse_dirt
execute in minecraft:overworld run fill 388 73 -42 388 144 -42 air
execute in minecraft:overworld run fill 388 58 -41 388 71 -41 stone
execute in minecraft:overworld run fill 388 72 -41 388 73 -41 dirt
execute in minecraft:overworld run setblock 388 74 -41 coarse_dirt
execute in minecraft:overworld run fill 388 75 -41 388 144 -41 air
execute in minecraft:overworld run fill 388 58 -40 388 71 -40 stone
execute in minecraft:overworld run fill 388 72 -40 388 73 -40 dirt
execute in minecraft:overworld run setblock 388 74 -40 grass_block
execute in minecraft:overworld run fill 388 75 -40 388 144 -40 air
execute in minecraft:overworld run fill 388 58 -39 388 72 -39 stone
execute in minecraft:overworld run fill 388 73 -39 388 74 -39 dirt
execute in minecraft:overworld run setblock 388 75 -39 coarse_dirt
execute in minecraft:overworld run fill 388 76 -39 388 144 -39 air
execute in minecraft:overworld run fill 388 58 -38 388 73 -38 stone
execute in minecraft:overworld run fill 388 74 -38 388 75 -38 dirt
execute in minecraft:overworld run setblock 388 76 -38 coarse_dirt
execute in minecraft:overworld run fill 388 77 -38 388 144 -38 air
execute in minecraft:overworld run fill 388 58 -37 388 73 -37 stone
execute in minecraft:overworld run fill 388 74 -37 388 75 -37 dirt
execute in minecraft:overworld run setblock 388 76 -37 coarse_dirt
execute in minecraft:overworld run fill 388 77 -37 388 144 -37 air
execute in minecraft:overworld run fill 388 58 -36 388 72 -36 stone
execute in minecraft:overworld run fill 388 73 -36 388 74 -36 dirt
execute in minecraft:overworld run setblock 388 75 -36 grass_block
execute in minecraft:overworld run fill 388 76 -36 388 144 -36 air
execute in minecraft:overworld run fill 388 58 -35 388 72 -35 stone
execute in minecraft:overworld run fill 388 73 -35 388 74 -35 dirt
execute in minecraft:overworld run setblock 388 75 -35 coarse_dirt
execute in minecraft:overworld run fill 388 76 -35 388 144 -35 air
execute in minecraft:overworld run setblock 388 76 -35 grass
execute in minecraft:overworld run fill 388 58 -34 388 72 -34 stone
execute in minecraft:overworld run fill 388 73 -34 388 74 -34 dirt
execute in minecraft:overworld run setblock 388 75 -34 coarse_dirt
execute in minecraft:overworld run fill 388 76 -34 388 144 -34 air
execute in minecraft:overworld run fill 388 58 -33 388 71 -33 stone
execute in minecraft:overworld run fill 388 72 -33 388 73 -33 dirt
execute in minecraft:overworld run setblock 388 74 -33 coarse_dirt
execute in minecraft:overworld run fill 388 75 -33 388 144 -33 air
execute in minecraft:overworld run fill 388 58 -32 388 71 -32 stone
execute in minecraft:overworld run fill 388 72 -32 388 73 -32 dirt
execute in minecraft:overworld run setblock 388 74 -32 coarse_dirt
execute in minecraft:overworld run fill 388 75 -32 388 144 -32 air
execute in minecraft:overworld run fill 388 58 -31 388 71 -31 stone
execute in minecraft:overworld run fill 388 72 -31 388 73 -31 dirt
execute in minecraft:overworld run setblock 388 74 -31 coarse_dirt
execute in minecraft:overworld run fill 388 75 -31 388 144 -31 air
execute in minecraft:overworld run fill 388 58 -30 388 70 -30 stone
execute in minecraft:overworld run fill 388 71 -30 388 72 -30 dirt
execute in minecraft:overworld run setblock 388 73 -30 grass_block
execute in minecraft:overworld run fill 388 74 -30 388 144 -30 air
execute in minecraft:overworld run fill 388 58 -29 388 70 -29 stone
execute in minecraft:overworld run fill 388 71 -29 388 72 -29 dirt
execute in minecraft:overworld run setblock 388 73 -29 coarse_dirt
execute in minecraft:overworld run fill 388 74 -29 388 144 -29 air
execute in minecraft:overworld run setblock 388 74 -29 grass
execute in minecraft:overworld run fill 388 58 -28 388 69 -28 stone
execute in minecraft:overworld run fill 388 70 -28 388 71 -28 dirt
execute in minecraft:overworld run setblock 388 72 -28 coarse_dirt
execute in minecraft:overworld run fill 388 73 -28 388 144 -28 air
execute in minecraft:overworld run fill 388 58 -27 388 68 -27 stone
execute in minecraft:overworld run fill 388 69 -27 388 70 -27 dirt
execute in minecraft:overworld run setblock 388 71 -27 grass_block
execute in minecraft:overworld run fill 388 72 -27 388 144 -27 air
execute in minecraft:overworld run fill 388 58 -26 388 67 -26 stone
execute in minecraft:overworld run fill 388 68 -26 388 69 -26 dirt
execute in minecraft:overworld run setblock 388 70 -26 coarse_dirt
execute in minecraft:overworld run fill 388 71 -26 388 144 -26 air
execute in minecraft:overworld run fill 388 58 -25 388 66 -25 stone
execute in minecraft:overworld run fill 388 67 -25 388 68 -25 dirt
execute in minecraft:overworld run setblock 388 69 -25 coarse_dirt
execute in minecraft:overworld run fill 388 70 -25 388 144 -25 air
execute in minecraft:overworld run fill 388 58 -24 388 65 -24 stone
execute in minecraft:overworld run fill 388 66 -24 388 67 -24 dirt
execute in minecraft:overworld run setblock 388 68 -24 grass_block
execute in minecraft:overworld run fill 388 69 -24 388 144 -24 air
execute in minecraft:overworld run fill 388 58 -23 388 64 -23 stone
execute in minecraft:overworld run fill 388 65 -23 388 66 -23 dirt
execute in minecraft:overworld run setblock 388 67 -23 coarse_dirt
execute in minecraft:overworld run fill 388 68 -23 388 144 -23 air
execute in minecraft:overworld run fill 388 58 -22 388 63 -22 stone
execute in minecraft:overworld run fill 388 64 -22 388 65 -22 dirt
execute in minecraft:overworld run setblock 388 66 -22 coarse_dirt
execute in minecraft:overworld run fill 388 67 -22 388 144 -22 air
execute in minecraft:overworld run fill 388 58 -21 388 62 -21 stone
execute in minecraft:overworld run fill 388 63 -21 388 64 -21 dirt
execute in minecraft:overworld run setblock 388 65 -21 coarse_dirt
execute in minecraft:overworld run fill 388 66 -21 388 144 -21 air
execute in minecraft:overworld run fill 388 58 -20 388 61 -20 stone
execute in minecraft:overworld run fill 388 62 -20 388 63 -20 dirt
execute in minecraft:overworld run setblock 388 64 -20 coarse_dirt
execute in minecraft:overworld run fill 388 65 -20 388 144 -20 air
execute in minecraft:overworld run fill 388 58 -19 388 60 -19 stone
execute in minecraft:overworld run fill 388 61 -19 388 62 -19 dirt
execute in minecraft:overworld run setblock 388 63 -19 gravel
execute in minecraft:overworld run fill 388 64 -19 388 144 -19 air
execute in minecraft:overworld run fill 388 64 -19 388 64 -19 water
execute in minecraft:overworld run fill 388 58 -18 388 59 -18 stone
execute in minecraft:overworld run fill 388 60 -18 388 61 -18 dirt
execute in minecraft:overworld run setblock 388 62 -18 gravel
execute in minecraft:overworld run fill 388 63 -18 388 144 -18 air
execute in minecraft:overworld run fill 388 63 -18 388 64 -18 water
execute in minecraft:overworld run fill 388 58 -17 388 58 -17 stone
execute in minecraft:overworld run fill 388 59 -17 388 60 -17 dirt
execute in minecraft:overworld run setblock 388 61 -17 gravel
execute in minecraft:overworld run fill 388 62 -17 388 144 -17 air
execute in minecraft:overworld run fill 388 62 -17 388 64 -17 water
execute in minecraft:overworld run fill 388 58 -16 388 57 -16 stone
execute in minecraft:overworld run fill 388 58 -16 388 59 -16 dirt
execute in minecraft:overworld run setblock 388 60 -16 gravel
execute in minecraft:overworld run fill 388 61 -16 388 144 -16 air
execute in minecraft:overworld run fill 388 61 -16 388 64 -16 water
execute in minecraft:overworld run fill 388 58 -15 388 57 -15 stone
execute in minecraft:overworld run fill 388 58 -15 388 59 -15 dirt
execute in minecraft:overworld run setblock 388 60 -15 gravel
execute in minecraft:overworld run fill 388 61 -15 388 144 -15 air
execute in minecraft:overworld run fill 388 61 -15 388 64 -15 water
execute in minecraft:overworld run fill 388 58 -14 388 56 -14 stone
execute in minecraft:overworld run fill 388 57 -14 388 58 -14 dirt
execute in minecraft:overworld run setblock 388 59 -14 gravel
execute in minecraft:overworld run fill 388 60 -14 388 144 -14 air
execute in minecraft:overworld run fill 388 60 -14 388 64 -14 water
execute in minecraft:overworld run fill 388 58 -13 388 56 -13 stone
execute in minecraft:overworld run fill 388 57 -13 388 58 -13 dirt
execute in minecraft:overworld run setblock 388 59 -13 gravel
execute in minecraft:overworld run fill 388 60 -13 388 144 -13 air
execute in minecraft:overworld run fill 388 60 -13 388 64 -13 water
execute in minecraft:overworld run fill 388 58 -12 388 55 -12 stone
execute in minecraft:overworld run fill 388 56 -12 388 57 -12 dirt
execute in minecraft:overworld run setblock 388 58 -12 gravel
execute in minecraft:overworld run fill 388 59 -12 388 144 -12 air
execute in minecraft:overworld run fill 388 59 -12 388 64 -12 water
execute in minecraft:overworld run fill 388 58 -11 388 55 -11 stone
execute in minecraft:overworld run fill 388 56 -11 388 57 -11 dirt
execute in minecraft:overworld run setblock 388 58 -11 gravel
execute in minecraft:overworld run fill 388 59 -11 388 144 -11 air
execute in minecraft:overworld run fill 388 59 -11 388 64 -11 water
execute in minecraft:overworld run fill 388 58 -10 388 55 -10 stone
execute in minecraft:overworld run fill 388 56 -10 388 57 -10 dirt
execute in minecraft:overworld run setblock 388 58 -10 gravel
execute in minecraft:overworld run fill 388 59 -10 388 144 -10 air
execute in minecraft:overworld run fill 388 59 -10 388 64 -10 water
execute in minecraft:overworld run fill 388 58 -9 388 55 -9 stone
execute in minecraft:overworld run fill 388 56 -9 388 57 -9 dirt
execute in minecraft:overworld run setblock 388 58 -9 gravel
execute in minecraft:overworld run fill 388 59 -9 388 144 -9 air
execute in minecraft:overworld run fill 388 59 -9 388 64 -9 water
execute in minecraft:overworld run fill 388 58 -8 388 56 -8 stone
execute in minecraft:overworld run fill 388 57 -8 388 58 -8 dirt
execute in minecraft:overworld run setblock 388 59 -8 gravel
execute in minecraft:overworld run fill 388 60 -8 388 144 -8 air
execute in minecraft:overworld run fill 388 60 -8 388 64 -8 water
execute in minecraft:overworld run fill 388 58 -7 388 56 -7 stone
execute in minecraft:overworld run fill 388 57 -7 388 58 -7 dirt
schedule function blade_gallery:random/battlefield/part_81 1t replace
