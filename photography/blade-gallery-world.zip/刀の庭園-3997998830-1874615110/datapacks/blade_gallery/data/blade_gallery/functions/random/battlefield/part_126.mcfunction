execute in minecraft:overworld run fill 416 76 -31 416 144 -31 air
execute in minecraft:overworld run fill 416 58 -30 416 72 -30 stone
execute in minecraft:overworld run fill 416 73 -30 416 74 -30 dirt
execute in minecraft:overworld run setblock 416 75 -30 coarse_dirt
execute in minecraft:overworld run fill 416 76 -30 416 144 -30 air
execute in minecraft:overworld run fill 416 58 -29 416 71 -29 stone
execute in minecraft:overworld run fill 416 72 -29 416 73 -29 dirt
execute in minecraft:overworld run setblock 416 74 -29 coarse_dirt
execute in minecraft:overworld run fill 416 75 -29 416 144 -29 air
execute in minecraft:overworld run fill 416 58 -28 416 71 -28 stone
execute in minecraft:overworld run fill 416 72 -28 416 73 -28 dirt
execute in minecraft:overworld run setblock 416 74 -28 coarse_dirt
execute in minecraft:overworld run fill 416 75 -28 416 144 -28 air
execute in minecraft:overworld run fill 416 58 -27 416 70 -27 stone
execute in minecraft:overworld run fill 416 71 -27 416 72 -27 dirt
execute in minecraft:overworld run setblock 416 73 -27 coarse_dirt
execute in minecraft:overworld run fill 416 74 -27 416 144 -27 air
execute in minecraft:overworld run fill 416 58 -26 416 70 -26 stone
execute in minecraft:overworld run fill 416 71 -26 416 72 -26 dirt
execute in minecraft:overworld run setblock 416 73 -26 coarse_dirt
execute in minecraft:overworld run fill 416 74 -26 416 144 -26 air
execute in minecraft:overworld run fill 416 58 -25 416 70 -25 stone
execute in minecraft:overworld run fill 416 71 -25 416 72 -25 dirt
execute in minecraft:overworld run setblock 416 73 -25 coarse_dirt
execute in minecraft:overworld run fill 416 74 -25 416 144 -25 air
execute in minecraft:overworld run fill 416 58 -24 416 70 -24 stone
execute in minecraft:overworld run fill 416 71 -24 416 72 -24 dirt
execute in minecraft:overworld run setblock 416 73 -24 grass_block
execute in minecraft:overworld run fill 416 74 -24 416 144 -24 air
execute in minecraft:overworld run fill 416 58 -23 416 69 -23 stone
execute in minecraft:overworld run fill 416 70 -23 416 71 -23 dirt
execute in minecraft:overworld run setblock 416 72 -23 coarse_dirt
execute in minecraft:overworld run fill 416 73 -23 416 144 -23 air
execute in minecraft:overworld run fill 416 58 -22 416 69 -22 stone
execute in minecraft:overworld run fill 416 70 -22 416 71 -22 dirt
execute in minecraft:overworld run setblock 416 72 -22 coarse_dirt
execute in minecraft:overworld run fill 416 73 -22 416 144 -22 air
execute in minecraft:overworld run fill 416 58 -21 416 69 -21 stone
execute in minecraft:overworld run fill 416 70 -21 416 71 -21 dirt
execute in minecraft:overworld run setblock 416 72 -21 grass_block
execute in minecraft:overworld run fill 416 73 -21 416 144 -21 air
execute in minecraft:overworld run fill 416 58 -20 416 69 -20 stone
execute in minecraft:overworld run fill 416 70 -20 416 71 -20 dirt
execute in minecraft:overworld run setblock 416 72 -20 coarse_dirt
execute in minecraft:overworld run fill 416 73 -20 416 144 -20 air
execute in minecraft:overworld run fill 416 58 -19 416 68 -19 stone
execute in minecraft:overworld run fill 416 69 -19 416 70 -19 dirt
execute in minecraft:overworld run setblock 416 71 -19 coarse_dirt
execute in minecraft:overworld run fill 416 72 -19 416 144 -19 air
execute in minecraft:overworld run fill 416 58 -18 416 68 -18 stone
execute in minecraft:overworld run fill 416 69 -18 416 70 -18 dirt
execute in minecraft:overworld run setblock 416 71 -18 coarse_dirt
execute in minecraft:overworld run fill 416 72 -18 416 144 -18 air
execute in minecraft:overworld run setblock 416 72 -18 grass
execute in minecraft:overworld run fill 416 58 -17 416 67 -17 stone
execute in minecraft:overworld run fill 416 68 -17 416 69 -17 dirt
execute in minecraft:overworld run setblock 416 70 -17 grass_block
execute in minecraft:overworld run fill 416 71 -17 416 144 -17 air
execute in minecraft:overworld run fill 416 58 -16 416 67 -16 stone
execute in minecraft:overworld run fill 416 68 -16 416 69 -16 dirt
execute in minecraft:overworld run setblock 416 70 -16 coarse_dirt
execute in minecraft:overworld run fill 416 71 -16 416 144 -16 air
execute in minecraft:overworld run fill 416 58 -15 416 66 -15 stone
execute in minecraft:overworld run fill 416 67 -15 416 68 -15 dirt
execute in minecraft:overworld run setblock 416 69 -15 grass_block
execute in minecraft:overworld run fill 416 70 -15 416 144 -15 air
execute in minecraft:overworld run fill 416 58 -14 416 66 -14 stone
execute in minecraft:overworld run fill 416 67 -14 416 68 -14 dirt
execute in minecraft:overworld run setblock 416 69 -14 grass_block
execute in minecraft:overworld run fill 416 70 -14 416 144 -14 air
execute in minecraft:overworld run fill 416 58 -13 416 65 -13 stone
execute in minecraft:overworld run fill 416 66 -13 416 67 -13 dirt
execute in minecraft:overworld run setblock 416 68 -13 coarse_dirt
execute in minecraft:overworld run fill 416 69 -13 416 144 -13 air
execute in minecraft:overworld run fill 416 58 -12 416 65 -12 stone
execute in minecraft:overworld run fill 416 66 -12 416 67 -12 dirt
execute in minecraft:overworld run setblock 416 68 -12 grass_block
execute in minecraft:overworld run fill 416 69 -12 416 144 -12 air
execute in minecraft:overworld run fill 416 58 -11 416 65 -11 stone
execute in minecraft:overworld run fill 416 66 -11 416 67 -11 dirt
execute in minecraft:overworld run setblock 416 68 -11 coarse_dirt
execute in minecraft:overworld run fill 416 69 -11 416 144 -11 air
execute in minecraft:overworld run fill 416 58 -10 416 65 -10 stone
execute in minecraft:overworld run fill 416 66 -10 416 67 -10 dirt
execute in minecraft:overworld run setblock 416 68 -10 coarse_dirt
execute in minecraft:overworld run fill 416 69 -10 416 144 -10 air
execute in minecraft:overworld run fill 416 58 -9 416 65 -9 stone
execute in minecraft:overworld run fill 416 66 -9 416 67 -9 dirt
execute in minecraft:overworld run setblock 416 68 -9 coarse_dirt
execute in minecraft:overworld run fill 416 69 -9 416 144 -9 air
execute in minecraft:overworld run fill 416 58 -8 416 65 -8 stone
execute in minecraft:overworld run fill 416 66 -8 416 67 -8 dirt
execute in minecraft:overworld run setblock 416 68 -8 coarse_dirt
execute in minecraft:overworld run fill 416 69 -8 416 144 -8 air
execute in minecraft:overworld run fill 416 58 -7 416 64 -7 stone
execute in minecraft:overworld run fill 416 65 -7 416 66 -7 dirt
execute in minecraft:overworld run setblock 416 67 -7 coarse_dirt
execute in minecraft:overworld run fill 416 68 -7 416 144 -7 air
execute in minecraft:overworld run fill 416 58 -6 416 64 -6 stone
execute in minecraft:overworld run fill 416 65 -6 416 66 -6 dirt
execute in minecraft:overworld run setblock 416 67 -6 grass_block
execute in minecraft:overworld run fill 416 68 -6 416 144 -6 air
execute in minecraft:overworld run fill 416 58 -5 416 64 -5 stone
execute in minecraft:overworld run fill 416 65 -5 416 66 -5 dirt
execute in minecraft:overworld run setblock 416 67 -5 grass_block
execute in minecraft:overworld run fill 416 68 -5 416 144 -5 air
execute in minecraft:overworld run fill 416 58 -4 416 64 -4 stone
execute in minecraft:overworld run fill 416 65 -4 416 66 -4 dirt
execute in minecraft:overworld run setblock 416 67 -4 coarse_dirt
execute in minecraft:overworld run fill 416 68 -4 416 144 -4 air
execute in minecraft:overworld run fill 416 58 -3 416 63 -3 stone
execute in minecraft:overworld run fill 416 64 -3 416 65 -3 dirt
execute in minecraft:overworld run setblock 416 66 -3 coarse_dirt
execute in minecraft:overworld run fill 416 67 -3 416 144 -3 air
execute in minecraft:overworld run fill 416 58 -2 416 63 -2 stone
execute in minecraft:overworld run fill 416 64 -2 416 65 -2 dirt
execute in minecraft:overworld run setblock 416 66 -2 grass_block
execute in minecraft:overworld run fill 416 67 -2 416 144 -2 air
execute in minecraft:overworld run fill 416 58 -1 416 63 -1 stone
execute in minecraft:overworld run fill 416 64 -1 416 65 -1 dirt
execute in minecraft:overworld run setblock 416 66 -1 coarse_dirt
execute in minecraft:overworld run fill 416 67 -1 416 144 -1 air
execute in minecraft:overworld run fill 416 58 0 416 63 0 stone
execute in minecraft:overworld run fill 416 64 0 416 65 0 dirt
execute in minecraft:overworld run setblock 416 66 0 grass_block
execute in minecraft:overworld run fill 416 67 0 416 144 0 air
execute in minecraft:overworld run setblock 416 67 0 grass
execute in minecraft:overworld run fill 416 58 1 416 63 1 stone
execute in minecraft:overworld run fill 416 64 1 416 65 1 dirt
execute in minecraft:overworld run setblock 416 66 1 coarse_dirt
execute in minecraft:overworld run fill 416 67 1 416 144 1 air
execute in minecraft:overworld run fill 416 58 2 416 63 2 stone
execute in minecraft:overworld run fill 416 64 2 416 65 2 dirt
execute in minecraft:overworld run setblock 416 66 2 coarse_dirt
execute in minecraft:overworld run fill 416 67 2 416 144 2 air
execute in minecraft:overworld run fill 416 58 3 416 63 3 stone
execute in minecraft:overworld run fill 416 64 3 416 65 3 dirt
execute in minecraft:overworld run setblock 416 66 3 grass_block
execute in minecraft:overworld run fill 416 67 3 416 144 3 air
execute in minecraft:overworld run fill 416 58 4 416 64 4 stone
execute in minecraft:overworld run fill 416 65 4 416 66 4 dirt
execute in minecraft:overworld run setblock 416 67 4 coarse_dirt
execute in minecraft:overworld run fill 416 68 4 416 144 4 air
execute in minecraft:overworld run setblock 416 68 4 mossy_cobblestone
execute in minecraft:overworld run fill 416 58 5 416 64 5 stone
execute in minecraft:overworld run fill 416 65 5 416 66 5 dirt
execute in minecraft:overworld run setblock 416 67 5 grass_block
execute in minecraft:overworld run fill 416 68 5 416 144 5 air
execute in minecraft:overworld run fill 416 58 6 416 64 6 stone
execute in minecraft:overworld run fill 416 65 6 416 66 6 dirt
execute in minecraft:overworld run setblock 416 67 6 grass_block
execute in minecraft:overworld run fill 416 68 6 416 144 6 air
execute in minecraft:overworld run fill 416 58 7 416 65 7 stone
execute in minecraft:overworld run fill 416 66 7 416 67 7 dirt
execute in minecraft:overworld run setblock 416 68 7 coarse_dirt
execute in minecraft:overworld run fill 416 69 7 416 144 7 air
execute in minecraft:overworld run fill 416 58 8 416 65 8 stone
execute in minecraft:overworld run fill 416 66 8 416 67 8 dirt
execute in minecraft:overworld run setblock 416 68 8 coarse_dirt
execute in minecraft:overworld run fill 416 69 8 416 144 8 air
execute in minecraft:overworld run fill 416 58 9 416 65 9 stone
execute in minecraft:overworld run fill 416 66 9 416 67 9 dirt
execute in minecraft:overworld run setblock 416 68 9 grass_block
execute in minecraft:overworld run fill 416 69 9 416 144 9 air
execute in minecraft:overworld run setblock 416 69 9 grass
execute in minecraft:overworld run fill 416 58 10 416 66 10 stone
execute in minecraft:overworld run fill 416 67 10 416 68 10 dirt
execute in minecraft:overworld run setblock 416 69 10 grass_block
execute in minecraft:overworld run fill 416 70 10 416 144 10 air
execute in minecraft:overworld run setblock 416 70 10 grass
execute in minecraft:overworld run fill 416 58 11 416 66 11 stone
execute in minecraft:overworld run fill 416 67 11 416 68 11 dirt
execute in minecraft:overworld run setblock 416 69 11 coarse_dirt
execute in minecraft:overworld run fill 416 70 11 416 144 11 air
execute in minecraft:overworld run fill 416 58 12 416 66 12 stone
execute in minecraft:overworld run fill 416 67 12 416 68 12 dirt
execute in minecraft:overworld run setblock 416 69 12 coarse_dirt
execute in minecraft:overworld run fill 416 70 12 416 144 12 air
execute in minecraft:overworld run fill 416 58 13 416 67 13 stone
execute in minecraft:overworld run fill 416 68 13 416 69 13 dirt
execute in minecraft:overworld run setblock 416 70 13 grass_block
execute in minecraft:overworld run fill 416 71 13 416 144 13 air
execute in minecraft:overworld run fill 416 58 14 416 67 14 stone
execute in minecraft:overworld run fill 416 68 14 416 69 14 dirt
execute in minecraft:overworld run setblock 416 70 14 grass_block
execute in minecraft:overworld run fill 416 71 14 416 144 14 air
execute in minecraft:overworld run fill 416 58 15 416 67 15 stone
execute in minecraft:overworld run fill 416 68 15 416 69 15 dirt
execute in minecraft:overworld run setblock 416 70 15 coarse_dirt
execute in minecraft:overworld run fill 416 71 15 416 144 15 air
execute in minecraft:overworld run fill 416 58 16 416 68 16 stone
execute in minecraft:overworld run fill 416 69 16 416 70 16 dirt
execute in minecraft:overworld run setblock 416 71 16 grass_block
execute in minecraft:overworld run fill 416 72 16 416 144 16 air
execute in minecraft:overworld run fill 416 58 17 416 68 17 stone
execute in minecraft:overworld run fill 416 69 17 416 70 17 dirt
execute in minecraft:overworld run setblock 416 71 17 coarse_dirt
execute in minecraft:overworld run fill 416 72 17 416 144 17 air
execute in minecraft:overworld run fill 416 58 18 416 68 18 stone
execute in minecraft:overworld run fill 416 69 18 416 70 18 dirt
execute in minecraft:overworld run setblock 416 71 18 coarse_dirt
execute in minecraft:overworld run fill 416 72 18 416 144 18 air
execute in minecraft:overworld run fill 416 58 19 416 69 19 stone
execute in minecraft:overworld run fill 416 70 19 416 71 19 dirt
execute in minecraft:overworld run setblock 416 72 19 coarse_dirt
execute in minecraft:overworld run fill 416 73 19 416 144 19 air
execute in minecraft:overworld run fill 416 58 20 416 69 20 stone
execute in minecraft:overworld run fill 416 70 20 416 71 20 dirt
execute in minecraft:overworld run setblock 416 72 20 coarse_dirt
execute in minecraft:overworld run fill 416 73 20 416 144 20 air
execute in minecraft:overworld run fill 416 58 21 416 69 21 stone
execute in minecraft:overworld run fill 416 70 21 416 71 21 dirt
execute in minecraft:overworld run setblock 416 72 21 coarse_dirt
execute in minecraft:overworld run fill 416 73 21 416 144 21 air
execute in minecraft:overworld run fill 416 58 22 416 70 22 stone
execute in minecraft:overworld run fill 416 71 22 416 72 22 dirt
execute in minecraft:overworld run setblock 416 73 22 grass_block
execute in minecraft:overworld run fill 416 74 22 416 144 22 air
execute in minecraft:overworld run fill 416 58 23 416 70 23 stone
execute in minecraft:overworld run fill 416 71 23 416 72 23 dirt
execute in minecraft:overworld run setblock 416 73 23 coarse_dirt
execute in minecraft:overworld run fill 416 74 23 416 144 23 air
execute in minecraft:overworld run fill 416 58 24 416 70 24 stone
execute in minecraft:overworld run fill 416 71 24 416 72 24 dirt
execute in minecraft:overworld run setblock 416 73 24 coarse_dirt
execute in minecraft:overworld run fill 416 74 24 416 144 24 air
execute in minecraft:overworld run fill 416 58 25 416 71 25 stone
execute in minecraft:overworld run fill 416 72 25 416 73 25 dirt
execute in minecraft:overworld run setblock 416 74 25 grass_block
execute in minecraft:overworld run fill 416 75 25 416 144 25 air
execute in minecraft:overworld run setblock 416 75 25 grass
execute in minecraft:overworld run fill 416 58 26 416 71 26 stone
execute in minecraft:overworld run fill 416 72 26 416 73 26 dirt
execute in minecraft:overworld run setblock 416 74 26 coarse_dirt
execute in minecraft:overworld run fill 416 75 26 416 144 26 air
execute in minecraft:overworld run fill 416 58 27 416 71 27 stone
execute in minecraft:overworld run fill 416 72 27 416 73 27 dirt
execute in minecraft:overworld run setblock 416 74 27 coarse_dirt
execute in minecraft:overworld run fill 416 75 27 416 144 27 air
execute in minecraft:overworld run fill 416 58 28 416 71 28 stone
execute in minecraft:overworld run fill 416 72 28 416 73 28 dirt
execute in minecraft:overworld run setblock 416 74 28 coarse_dirt
execute in minecraft:overworld run fill 416 75 28 416 144 28 air
execute in minecraft:overworld run setblock 416 75 28 grass
execute in minecraft:overworld run fill 416 58 29 416 71 29 stone
execute in minecraft:overworld run fill 416 72 29 416 73 29 dirt
execute in minecraft:overworld run setblock 416 74 29 coarse_dirt
execute in minecraft:overworld run fill 416 75 29 416 144 29 air
execute in minecraft:overworld run fill 416 58 30 416 71 30 stone
execute in minecraft:overworld run fill 416 72 30 416 73 30 dirt
execute in minecraft:overworld run setblock 416 74 30 coarse_dirt
execute in minecraft:overworld run fill 416 75 30 416 144 30 air
execute in minecraft:overworld run fill 416 58 31 416 71 31 stone
execute in minecraft:overworld run fill 416 72 31 416 73 31 dirt
execute in minecraft:overworld run setblock 416 74 31 grass_block
execute in minecraft:overworld run fill 416 75 31 416 144 31 air
schedule function blade_gallery:random/battlefield/part_127 1t replace
