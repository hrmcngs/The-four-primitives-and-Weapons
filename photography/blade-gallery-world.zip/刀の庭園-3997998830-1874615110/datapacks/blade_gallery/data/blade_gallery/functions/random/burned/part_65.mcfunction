execute in minecraft:overworld run setblock 250 68 -17 grass_block
execute in minecraft:overworld run fill 250 69 -17 250 144 -17 air
execute in minecraft:overworld run fill 250 58 -16 250 65 -16 stone
execute in minecraft:overworld run fill 250 66 -16 250 67 -16 dirt
execute in minecraft:overworld run setblock 250 68 -16 coarse_dirt
execute in minecraft:overworld run fill 250 69 -16 250 144 -16 air
execute in minecraft:overworld run fill 250 58 -15 250 64 -15 stone
execute in minecraft:overworld run fill 250 65 -15 250 66 -15 dirt
execute in minecraft:overworld run setblock 250 67 -15 coarse_dirt
execute in minecraft:overworld run fill 250 68 -15 250 144 -15 air
execute in minecraft:overworld run fill 250 58 -14 250 64 -14 stone
execute in minecraft:overworld run fill 250 65 -14 250 66 -14 dirt
execute in minecraft:overworld run setblock 250 67 -14 grass_block
execute in minecraft:overworld run fill 250 68 -14 250 144 -14 air
execute in minecraft:overworld run fill 250 58 -13 250 63 -13 stone
execute in minecraft:overworld run fill 250 64 -13 250 65 -13 dirt
execute in minecraft:overworld run setblock 250 66 -13 grass_block
execute in minecraft:overworld run fill 250 67 -13 250 144 -13 air
execute in minecraft:overworld run fill 250 58 -12 250 63 -12 stone
execute in minecraft:overworld run fill 250 64 -12 250 65 -12 dirt
execute in minecraft:overworld run setblock 250 66 -12 grass_block
execute in minecraft:overworld run fill 250 67 -12 250 144 -12 air
execute in minecraft:overworld run fill 250 58 -11 250 63 -11 stone
execute in minecraft:overworld run fill 250 64 -11 250 65 -11 dirt
execute in minecraft:overworld run setblock 250 66 -11 coarse_dirt
execute in minecraft:overworld run fill 250 67 -11 250 144 -11 air
execute in minecraft:overworld run fill 250 58 -10 250 63 -10 stone
execute in minecraft:overworld run fill 250 64 -10 250 65 -10 dirt
execute in minecraft:overworld run setblock 250 66 -10 coarse_dirt
execute in minecraft:overworld run fill 250 67 -10 250 144 -10 air
execute in minecraft:overworld run setblock 250 67 -10 grass
execute in minecraft:overworld run fill 250 58 -9 250 62 -9 stone
execute in minecraft:overworld run fill 250 63 -9 250 64 -9 dirt
execute in minecraft:overworld run setblock 250 65 -9 coarse_dirt
execute in minecraft:overworld run fill 250 66 -9 250 144 -9 air
execute in minecraft:overworld run fill 250 58 -8 250 62 -8 stone
execute in minecraft:overworld run fill 250 63 -8 250 64 -8 dirt
execute in minecraft:overworld run setblock 250 65 -8 coarse_dirt
execute in minecraft:overworld run fill 250 66 -8 250 144 -8 air
execute in minecraft:overworld run fill 250 58 -7 250 62 -7 stone
execute in minecraft:overworld run fill 250 63 -7 250 64 -7 dirt
execute in minecraft:overworld run setblock 250 65 -7 coarse_dirt
execute in minecraft:overworld run fill 250 66 -7 250 144 -7 air
execute in minecraft:overworld run fill 250 58 -6 250 61 -6 stone
execute in minecraft:overworld run fill 250 62 -6 250 63 -6 dirt
execute in minecraft:overworld run setblock 250 64 -6 grass_block
execute in minecraft:overworld run fill 250 65 -6 250 144 -6 air
execute in minecraft:overworld run fill 250 58 -5 250 61 -5 stone
execute in minecraft:overworld run fill 250 62 -5 250 63 -5 dirt
execute in minecraft:overworld run setblock 250 64 -5 coarse_dirt
execute in minecraft:overworld run fill 250 65 -5 250 144 -5 air
execute in minecraft:overworld run fill 250 58 -4 250 61 -4 stone
execute in minecraft:overworld run fill 250 62 -4 250 63 -4 dirt
execute in minecraft:overworld run setblock 250 64 -4 grass_block
execute in minecraft:overworld run fill 250 65 -4 250 144 -4 air
execute in minecraft:overworld run fill 250 58 -3 250 60 -3 stone
execute in minecraft:overworld run fill 250 61 -3 250 62 -3 dirt
execute in minecraft:overworld run setblock 250 63 -3 gravel
execute in minecraft:overworld run fill 250 64 -3 250 144 -3 air
execute in minecraft:overworld run fill 250 64 -3 250 64 -3 water
execute in minecraft:overworld run fill 250 58 -2 250 60 -2 stone
execute in minecraft:overworld run fill 250 61 -2 250 62 -2 dirt
execute in minecraft:overworld run setblock 250 63 -2 gravel
execute in minecraft:overworld run fill 250 64 -2 250 144 -2 air
execute in minecraft:overworld run fill 250 64 -2 250 64 -2 water
execute in minecraft:overworld run fill 250 58 -1 250 60 -1 stone
execute in minecraft:overworld run fill 250 61 -1 250 62 -1 dirt
execute in minecraft:overworld run setblock 250 63 -1 gravel
execute in minecraft:overworld run fill 250 64 -1 250 144 -1 air
execute in minecraft:overworld run fill 250 64 -1 250 64 -1 water
execute in minecraft:overworld run fill 250 58 0 250 60 0 stone
execute in minecraft:overworld run fill 250 61 0 250 62 0 dirt
execute in minecraft:overworld run setblock 250 63 0 gravel
execute in minecraft:overworld run fill 250 64 0 250 144 0 air
execute in minecraft:overworld run fill 250 64 0 250 64 0 water
execute in minecraft:overworld run fill 250 58 1 250 60 1 stone
execute in minecraft:overworld run fill 250 61 1 250 62 1 dirt
execute in minecraft:overworld run setblock 250 63 1 gravel
execute in minecraft:overworld run fill 250 64 1 250 144 1 air
execute in minecraft:overworld run fill 250 64 1 250 64 1 water
execute in minecraft:overworld run fill 250 58 2 250 60 2 stone
execute in minecraft:overworld run fill 250 61 2 250 62 2 dirt
execute in minecraft:overworld run setblock 250 63 2 gravel
execute in minecraft:overworld run fill 250 64 2 250 144 2 air
execute in minecraft:overworld run fill 250 64 2 250 64 2 water
execute in minecraft:overworld run fill 250 58 3 250 60 3 stone
execute in minecraft:overworld run fill 250 61 3 250 62 3 dirt
execute in minecraft:overworld run setblock 250 63 3 gravel
execute in minecraft:overworld run fill 250 64 3 250 144 3 air
execute in minecraft:overworld run fill 250 64 3 250 64 3 water
execute in minecraft:overworld run fill 250 58 4 250 61 4 stone
execute in minecraft:overworld run fill 250 62 4 250 63 4 dirt
execute in minecraft:overworld run setblock 250 64 4 coarse_dirt
execute in minecraft:overworld run fill 250 65 4 250 144 4 air
execute in minecraft:overworld run fill 250 58 5 250 61 5 stone
execute in minecraft:overworld run fill 250 62 5 250 63 5 dirt
execute in minecraft:overworld run setblock 250 64 5 coarse_dirt
execute in minecraft:overworld run fill 250 65 5 250 144 5 air
execute in minecraft:overworld run fill 250 58 6 250 62 6 stone
execute in minecraft:overworld run fill 250 63 6 250 64 6 dirt
execute in minecraft:overworld run setblock 250 65 6 coarse_dirt
execute in minecraft:overworld run fill 250 66 6 250 144 6 air
execute in minecraft:overworld run fill 250 58 7 250 62 7 stone
execute in minecraft:overworld run fill 250 63 7 250 64 7 dirt
execute in minecraft:overworld run setblock 250 65 7 coarse_dirt
execute in minecraft:overworld run fill 250 66 7 250 144 7 air
execute in minecraft:overworld run fill 250 58 8 250 62 8 stone
execute in minecraft:overworld run fill 250 63 8 250 64 8 dirt
execute in minecraft:overworld run setblock 250 65 8 grass_block
execute in minecraft:overworld run fill 250 66 8 250 144 8 air
execute in minecraft:overworld run fill 250 58 9 250 63 9 stone
execute in minecraft:overworld run fill 250 64 9 250 65 9 dirt
execute in minecraft:overworld run setblock 250 66 9 grass_block
execute in minecraft:overworld run fill 250 67 9 250 144 9 air
execute in minecraft:overworld run fill 250 58 10 250 63 10 stone
execute in minecraft:overworld run fill 250 64 10 250 65 10 dirt
execute in minecraft:overworld run setblock 250 66 10 coarse_dirt
execute in minecraft:overworld run fill 250 67 10 250 144 10 air
execute in minecraft:overworld run fill 250 58 11 250 63 11 stone
execute in minecraft:overworld run fill 250 64 11 250 65 11 dirt
execute in minecraft:overworld run setblock 250 66 11 grass_block
execute in minecraft:overworld run fill 250 67 11 250 144 11 air
execute in minecraft:overworld run fill 250 58 12 250 63 12 stone
execute in minecraft:overworld run fill 250 64 12 250 65 12 dirt
execute in minecraft:overworld run setblock 250 66 12 coarse_dirt
execute in minecraft:overworld run fill 250 67 12 250 144 12 air
execute in minecraft:overworld run fill 250 58 13 250 63 13 stone
execute in minecraft:overworld run fill 250 64 13 250 65 13 dirt
execute in minecraft:overworld run setblock 250 66 13 coarse_dirt
execute in minecraft:overworld run fill 250 67 13 250 144 13 air
execute in minecraft:overworld run fill 250 58 14 250 64 14 stone
execute in minecraft:overworld run fill 250 65 14 250 66 14 dirt
execute in minecraft:overworld run setblock 250 67 14 coarse_dirt
execute in minecraft:overworld run fill 250 68 14 250 144 14 air
execute in minecraft:overworld run fill 250 58 15 250 64 15 stone
execute in minecraft:overworld run fill 250 65 15 250 66 15 dirt
execute in minecraft:overworld run setblock 250 67 15 coarse_dirt
execute in minecraft:overworld run fill 250 68 15 250 144 15 air
execute in minecraft:overworld run setblock 250 68 15 grass
execute in minecraft:overworld run fill 250 58 16 250 64 16 stone
execute in minecraft:overworld run fill 250 65 16 250 66 16 dirt
execute in minecraft:overworld run setblock 250 67 16 coarse_dirt
execute in minecraft:overworld run fill 250 68 16 250 144 16 air
execute in minecraft:overworld run fill 250 58 17 250 64 17 stone
execute in minecraft:overworld run fill 250 65 17 250 66 17 dirt
execute in minecraft:overworld run setblock 250 67 17 grass_block
execute in minecraft:overworld run fill 250 68 17 250 144 17 air
execute in minecraft:overworld run setblock 250 68 17 grass
execute in minecraft:overworld run fill 250 58 18 250 65 18 stone
execute in minecraft:overworld run fill 250 66 18 250 67 18 dirt
execute in minecraft:overworld run setblock 250 68 18 grass_block
execute in minecraft:overworld run fill 250 69 18 250 144 18 air
execute in minecraft:overworld run fill 250 58 19 250 65 19 stone
execute in minecraft:overworld run fill 250 66 19 250 67 19 dirt
execute in minecraft:overworld run setblock 250 68 19 coarse_dirt
execute in minecraft:overworld run fill 250 69 19 250 144 19 air
execute in minecraft:overworld run fill 250 58 20 250 65 20 stone
execute in minecraft:overworld run fill 250 66 20 250 67 20 dirt
execute in minecraft:overworld run setblock 250 68 20 coarse_dirt
execute in minecraft:overworld run fill 250 69 20 250 144 20 air
execute in minecraft:overworld run fill 250 58 21 250 65 21 stone
execute in minecraft:overworld run fill 250 66 21 250 67 21 dirt
execute in minecraft:overworld run setblock 250 68 21 grass_block
execute in minecraft:overworld run fill 250 69 21 250 144 21 air
execute in minecraft:overworld run fill 250 58 22 250 65 22 stone
execute in minecraft:overworld run fill 250 66 22 250 67 22 dirt
execute in minecraft:overworld run setblock 250 68 22 coarse_dirt
execute in minecraft:overworld run fill 250 69 22 250 144 22 air
execute in minecraft:overworld run fill 250 58 23 250 65 23 stone
execute in minecraft:overworld run fill 250 66 23 250 67 23 dirt
execute in minecraft:overworld run setblock 250 68 23 coarse_dirt
execute in minecraft:overworld run fill 250 69 23 250 144 23 air
execute in minecraft:overworld run fill 250 58 24 250 65 24 stone
execute in minecraft:overworld run fill 250 66 24 250 67 24 dirt
execute in minecraft:overworld run setblock 250 68 24 coarse_dirt
execute in minecraft:overworld run fill 250 69 24 250 144 24 air
execute in minecraft:overworld run fill 250 58 25 250 65 25 stone
execute in minecraft:overworld run fill 250 66 25 250 67 25 dirt
execute in minecraft:overworld run setblock 250 68 25 coarse_dirt
execute in minecraft:overworld run fill 250 69 25 250 144 25 air
execute in minecraft:overworld run fill 250 58 26 250 65 26 stone
execute in minecraft:overworld run fill 250 66 26 250 67 26 dirt
execute in minecraft:overworld run setblock 250 68 26 grass_block
execute in minecraft:overworld run fill 250 69 26 250 144 26 air
execute in minecraft:overworld run fill 250 58 27 250 65 27 stone
execute in minecraft:overworld run fill 250 66 27 250 67 27 dirt
execute in minecraft:overworld run setblock 250 68 27 coarse_dirt
execute in minecraft:overworld run fill 250 69 27 250 144 27 air
execute in minecraft:overworld run fill 250 58 28 250 65 28 stone
execute in minecraft:overworld run fill 250 66 28 250 67 28 dirt
execute in minecraft:overworld run setblock 250 68 28 coarse_dirt
execute in minecraft:overworld run fill 250 69 28 250 144 28 air
execute in minecraft:overworld run fill 250 58 29 250 65 29 stone
execute in minecraft:overworld run fill 250 66 29 250 67 29 dirt
execute in minecraft:overworld run setblock 250 68 29 coarse_dirt
execute in minecraft:overworld run fill 250 69 29 250 144 29 air
execute in minecraft:overworld run fill 250 58 30 250 65 30 stone
execute in minecraft:overworld run fill 250 66 30 250 67 30 dirt
execute in minecraft:overworld run setblock 250 68 30 grass_block
execute in minecraft:overworld run fill 250 69 30 250 144 30 air
execute in minecraft:overworld run fill 250 58 31 250 65 31 stone
execute in minecraft:overworld run fill 250 66 31 250 67 31 dirt
execute in minecraft:overworld run setblock 250 68 31 coarse_dirt
execute in minecraft:overworld run fill 250 69 31 250 144 31 air
execute in minecraft:overworld run fill 250 58 32 250 65 32 stone
execute in minecraft:overworld run fill 250 66 32 250 67 32 dirt
execute in minecraft:overworld run setblock 250 68 32 coarse_dirt
execute in minecraft:overworld run fill 250 69 32 250 144 32 air
execute in minecraft:overworld run fill 250 58 33 250 65 33 stone
execute in minecraft:overworld run fill 250 66 33 250 67 33 dirt
execute in minecraft:overworld run setblock 250 68 33 coarse_dirt
execute in minecraft:overworld run fill 250 69 33 250 144 33 air
execute in minecraft:overworld run fill 250 58 34 250 65 34 stone
execute in minecraft:overworld run fill 250 66 34 250 67 34 dirt
execute in minecraft:overworld run setblock 250 68 34 coarse_dirt
execute in minecraft:overworld run fill 250 69 34 250 144 34 air
execute in minecraft:overworld run fill 250 58 35 250 65 35 stone
execute in minecraft:overworld run fill 250 66 35 250 67 35 dirt
execute in minecraft:overworld run setblock 250 68 35 coarse_dirt
execute in minecraft:overworld run fill 250 69 35 250 144 35 air
execute in minecraft:overworld run setblock 250 69 35 mossy_cobblestone
execute in minecraft:overworld run fill 250 58 36 250 65 36 stone
execute in minecraft:overworld run fill 250 66 36 250 67 36 dirt
execute in minecraft:overworld run setblock 250 68 36 grass_block
execute in minecraft:overworld run fill 250 69 36 250 144 36 air
execute in minecraft:overworld run fill 250 58 37 250 64 37 stone
execute in minecraft:overworld run fill 250 65 37 250 66 37 dirt
execute in minecraft:overworld run setblock 250 67 37 grass_block
execute in minecraft:overworld run fill 250 68 37 250 144 37 air
execute in minecraft:overworld run fill 250 58 38 250 64 38 stone
execute in minecraft:overworld run fill 250 65 38 250 66 38 dirt
execute in minecraft:overworld run setblock 250 67 38 grass_block
execute in minecraft:overworld run fill 250 68 38 250 144 38 air
execute in minecraft:overworld run fill 250 58 39 250 63 39 stone
execute in minecraft:overworld run fill 250 64 39 250 65 39 dirt
execute in minecraft:overworld run setblock 250 66 39 coarse_dirt
execute in minecraft:overworld run fill 250 67 39 250 144 39 air
execute in minecraft:overworld run fill 250 58 40 250 63 40 stone
execute in minecraft:overworld run fill 250 64 40 250 65 40 dirt
execute in minecraft:overworld run setblock 250 66 40 grass_block
execute in minecraft:overworld run fill 250 67 40 250 144 40 air
execute in minecraft:overworld run fill 250 58 41 250 62 41 stone
execute in minecraft:overworld run fill 250 63 41 250 64 41 dirt
execute in minecraft:overworld run setblock 250 65 41 grass_block
execute in minecraft:overworld run fill 250 66 41 250 144 41 air
execute in minecraft:overworld run fill 250 58 42 250 61 42 stone
execute in minecraft:overworld run fill 250 62 42 250 63 42 dirt
execute in minecraft:overworld run setblock 250 64 42 coarse_dirt
execute in minecraft:overworld run fill 250 65 42 250 144 42 air
execute in minecraft:overworld run fill 250 58 43 250 61 43 stone
execute in minecraft:overworld run fill 250 62 43 250 63 43 dirt
execute in minecraft:overworld run setblock 250 64 43 coarse_dirt
execute in minecraft:overworld run fill 250 65 43 250 144 43 air
execute in minecraft:overworld run fill 250 58 44 250 61 44 stone
execute in minecraft:overworld run fill 250 62 44 250 63 44 dirt
execute in minecraft:overworld run setblock 250 64 44 coarse_dirt
schedule function blade_gallery:random/burned/part_66 1t replace
