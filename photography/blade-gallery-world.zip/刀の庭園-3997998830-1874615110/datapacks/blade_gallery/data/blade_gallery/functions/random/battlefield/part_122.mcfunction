execute in minecraft:overworld run fill 413 58 7 413 64 7 stone
execute in minecraft:overworld run fill 413 65 7 413 66 7 dirt
execute in minecraft:overworld run setblock 413 67 7 grass_block
execute in minecraft:overworld run fill 413 68 7 413 144 7 air
execute in minecraft:overworld run fill 413 58 8 413 65 8 stone
execute in minecraft:overworld run fill 413 66 8 413 67 8 dirt
execute in minecraft:overworld run setblock 413 68 8 grass_block
execute in minecraft:overworld run fill 413 69 8 413 144 8 air
execute in minecraft:overworld run fill 413 58 9 413 65 9 stone
execute in minecraft:overworld run fill 413 66 9 413 67 9 dirt
execute in minecraft:overworld run setblock 413 68 9 coarse_dirt
execute in minecraft:overworld run fill 413 69 9 413 144 9 air
execute in minecraft:overworld run fill 413 58 10 413 65 10 stone
execute in minecraft:overworld run fill 413 66 10 413 67 10 dirt
execute in minecraft:overworld run setblock 413 68 10 coarse_dirt
execute in minecraft:overworld run fill 413 69 10 413 144 10 air
execute in minecraft:overworld run fill 413 58 11 413 65 11 stone
execute in minecraft:overworld run fill 413 66 11 413 67 11 dirt
execute in minecraft:overworld run setblock 413 68 11 coarse_dirt
execute in minecraft:overworld run fill 413 69 11 413 144 11 air
execute in minecraft:overworld run fill 413 58 12 413 66 12 stone
execute in minecraft:overworld run fill 413 67 12 413 68 12 dirt
execute in minecraft:overworld run setblock 413 69 12 grass_block
execute in minecraft:overworld run fill 413 70 12 413 144 12 air
execute in minecraft:overworld run fill 413 58 13 413 66 13 stone
execute in minecraft:overworld run fill 413 67 13 413 68 13 dirt
execute in minecraft:overworld run setblock 413 69 13 coarse_dirt
execute in minecraft:overworld run fill 413 70 13 413 144 13 air
execute in minecraft:overworld run fill 413 58 14 413 66 14 stone
execute in minecraft:overworld run fill 413 67 14 413 68 14 dirt
execute in minecraft:overworld run setblock 413 69 14 coarse_dirt
execute in minecraft:overworld run fill 413 70 14 413 144 14 air
execute in minecraft:overworld run fill 413 58 15 413 67 15 stone
execute in minecraft:overworld run fill 413 68 15 413 69 15 dirt
execute in minecraft:overworld run setblock 413 70 15 grass_block
execute in minecraft:overworld run fill 413 71 15 413 144 15 air
execute in minecraft:overworld run fill 413 58 16 413 67 16 stone
execute in minecraft:overworld run fill 413 68 16 413 69 16 dirt
execute in minecraft:overworld run setblock 413 70 16 grass_block
execute in minecraft:overworld run fill 413 71 16 413 144 16 air
execute in minecraft:overworld run fill 413 58 17 413 67 17 stone
execute in minecraft:overworld run fill 413 68 17 413 69 17 dirt
execute in minecraft:overworld run setblock 413 70 17 grass_block
execute in minecraft:overworld run fill 413 71 17 413 144 17 air
execute in minecraft:overworld run fill 413 58 18 413 68 18 stone
execute in minecraft:overworld run fill 413 69 18 413 70 18 dirt
execute in minecraft:overworld run setblock 413 71 18 coarse_dirt
execute in minecraft:overworld run fill 413 72 18 413 144 18 air
execute in minecraft:overworld run fill 413 58 19 413 68 19 stone
execute in minecraft:overworld run fill 413 69 19 413 70 19 dirt
execute in minecraft:overworld run setblock 413 71 19 grass_block
execute in minecraft:overworld run fill 413 72 19 413 144 19 air
execute in minecraft:overworld run fill 413 58 20 413 68 20 stone
execute in minecraft:overworld run fill 413 69 20 413 70 20 dirt
execute in minecraft:overworld run setblock 413 71 20 coarse_dirt
execute in minecraft:overworld run fill 413 72 20 413 144 20 air
execute in minecraft:overworld run fill 413 58 21 413 69 21 stone
execute in minecraft:overworld run fill 413 70 21 413 71 21 dirt
execute in minecraft:overworld run setblock 413 72 21 coarse_dirt
execute in minecraft:overworld run fill 413 73 21 413 144 21 air
execute in minecraft:overworld run fill 413 58 22 413 69 22 stone
execute in minecraft:overworld run fill 413 70 22 413 71 22 dirt
execute in minecraft:overworld run setblock 413 72 22 coarse_dirt
execute in minecraft:overworld run fill 413 73 22 413 144 22 air
execute in minecraft:overworld run fill 413 58 23 413 69 23 stone
execute in minecraft:overworld run fill 413 70 23 413 71 23 dirt
execute in minecraft:overworld run setblock 413 72 23 coarse_dirt
execute in minecraft:overworld run fill 413 73 23 413 144 23 air
execute in minecraft:overworld run fill 413 58 24 413 70 24 stone
execute in minecraft:overworld run fill 413 71 24 413 72 24 dirt
execute in minecraft:overworld run setblock 413 73 24 coarse_dirt
execute in minecraft:overworld run fill 413 74 24 413 144 24 air
execute in minecraft:overworld run fill 413 58 25 413 70 25 stone
execute in minecraft:overworld run fill 413 71 25 413 72 25 dirt
execute in minecraft:overworld run setblock 413 73 25 coarse_dirt
execute in minecraft:overworld run fill 413 74 25 413 144 25 air
execute in minecraft:overworld run fill 413 58 26 413 70 26 stone
execute in minecraft:overworld run fill 413 71 26 413 72 26 dirt
execute in minecraft:overworld run setblock 413 73 26 coarse_dirt
execute in minecraft:overworld run fill 413 74 26 413 144 26 air
execute in minecraft:overworld run fill 413 58 27 413 70 27 stone
execute in minecraft:overworld run fill 413 71 27 413 72 27 dirt
execute in minecraft:overworld run setblock 413 73 27 coarse_dirt
execute in minecraft:overworld run fill 413 74 27 413 144 27 air
execute in minecraft:overworld run fill 413 58 28 413 70 28 stone
execute in minecraft:overworld run fill 413 71 28 413 72 28 dirt
execute in minecraft:overworld run setblock 413 73 28 grass_block
execute in minecraft:overworld run fill 413 74 28 413 144 28 air
execute in minecraft:overworld run fill 413 58 29 413 70 29 stone
execute in minecraft:overworld run fill 413 71 29 413 72 29 dirt
execute in minecraft:overworld run setblock 413 73 29 coarse_dirt
execute in minecraft:overworld run fill 413 74 29 413 144 29 air
execute in minecraft:overworld run fill 413 58 30 413 70 30 stone
execute in minecraft:overworld run fill 413 71 30 413 72 30 dirt
execute in minecraft:overworld run setblock 413 73 30 coarse_dirt
execute in minecraft:overworld run fill 413 74 30 413 144 30 air
execute in minecraft:overworld run fill 413 58 31 413 70 31 stone
execute in minecraft:overworld run fill 413 71 31 413 72 31 dirt
execute in minecraft:overworld run setblock 413 73 31 grass_block
execute in minecraft:overworld run fill 413 74 31 413 144 31 air
execute in minecraft:overworld run fill 413 58 32 413 70 32 stone
execute in minecraft:overworld run fill 413 71 32 413 72 32 dirt
execute in minecraft:overworld run setblock 413 73 32 coarse_dirt
execute in minecraft:overworld run fill 413 74 32 413 144 32 air
execute in minecraft:overworld run fill 413 58 33 413 70 33 stone
execute in minecraft:overworld run fill 413 71 33 413 72 33 dirt
execute in minecraft:overworld run setblock 413 73 33 coarse_dirt
execute in minecraft:overworld run fill 413 74 33 413 144 33 air
execute in minecraft:overworld run fill 413 58 34 413 69 34 stone
execute in minecraft:overworld run fill 413 70 34 413 71 34 dirt
execute in minecraft:overworld run setblock 413 72 34 coarse_dirt
execute in minecraft:overworld run fill 413 73 34 413 144 34 air
execute in minecraft:overworld run fill 413 58 35 413 69 35 stone
execute in minecraft:overworld run fill 413 70 35 413 71 35 dirt
execute in minecraft:overworld run setblock 413 72 35 coarse_dirt
execute in minecraft:overworld run fill 413 73 35 413 144 35 air
execute in minecraft:overworld run fill 413 58 36 413 69 36 stone
execute in minecraft:overworld run fill 413 70 36 413 71 36 dirt
execute in minecraft:overworld run setblock 413 72 36 grass_block
execute in minecraft:overworld run fill 413 73 36 413 144 36 air
execute in minecraft:overworld run fill 413 58 37 413 68 37 stone
execute in minecraft:overworld run fill 413 69 37 413 70 37 dirt
execute in minecraft:overworld run setblock 413 71 37 coarse_dirt
execute in minecraft:overworld run fill 413 72 37 413 144 37 air
execute in minecraft:overworld run fill 413 58 38 413 68 38 stone
execute in minecraft:overworld run fill 413 69 38 413 70 38 dirt
execute in minecraft:overworld run setblock 413 71 38 grass_block
execute in minecraft:overworld run fill 413 72 38 413 144 38 air
execute in minecraft:overworld run setblock 413 72 38 grass
execute in minecraft:overworld run fill 413 58 39 413 67 39 stone
execute in minecraft:overworld run fill 413 68 39 413 69 39 dirt
execute in minecraft:overworld run setblock 413 70 39 grass_block
execute in minecraft:overworld run fill 413 71 39 413 144 39 air
execute in minecraft:overworld run fill 413 58 40 413 66 40 stone
execute in minecraft:overworld run fill 413 67 40 413 68 40 dirt
execute in minecraft:overworld run setblock 413 69 40 coarse_dirt
execute in minecraft:overworld run fill 413 70 40 413 144 40 air
execute in minecraft:overworld run fill 413 58 41 413 65 41 stone
execute in minecraft:overworld run fill 413 66 41 413 67 41 dirt
execute in minecraft:overworld run setblock 413 68 41 grass_block
execute in minecraft:overworld run fill 413 69 41 413 144 41 air
execute in minecraft:overworld run fill 413 58 42 413 64 42 stone
execute in minecraft:overworld run fill 413 65 42 413 66 42 dirt
execute in minecraft:overworld run setblock 413 67 42 coarse_dirt
execute in minecraft:overworld run fill 413 68 42 413 144 42 air
execute in minecraft:overworld run fill 413 58 43 413 64 43 stone
execute in minecraft:overworld run fill 413 65 43 413 66 43 dirt
execute in minecraft:overworld run setblock 413 67 43 grass_block
execute in minecraft:overworld run fill 413 68 43 413 144 43 air
execute in minecraft:overworld run fill 413 58 44 413 63 44 stone
execute in minecraft:overworld run fill 413 64 44 413 65 44 dirt
execute in minecraft:overworld run setblock 413 66 44 grass_block
execute in minecraft:overworld run fill 413 67 44 413 144 44 air
execute in minecraft:overworld run fill 413 58 45 413 62 45 stone
execute in minecraft:overworld run fill 413 63 45 413 64 45 dirt
execute in minecraft:overworld run setblock 413 65 45 grass_block
execute in minecraft:overworld run fill 413 66 45 413 144 45 air
execute in minecraft:overworld run fill 413 58 46 413 62 46 stone
execute in minecraft:overworld run fill 413 63 46 413 64 46 dirt
execute in minecraft:overworld run setblock 413 65 46 coarse_dirt
execute in minecraft:overworld run fill 413 66 46 413 144 46 air
execute in minecraft:overworld run fill 413 58 47 413 61 47 stone
execute in minecraft:overworld run fill 413 62 47 413 63 47 dirt
execute in minecraft:overworld run setblock 413 64 47 coarse_dirt
execute in minecraft:overworld run fill 413 65 47 413 144 47 air
execute in minecraft:overworld run fill 414 58 -48 414 61 -48 stone
execute in minecraft:overworld run fill 414 62 -48 414 63 -48 dirt
execute in minecraft:overworld run setblock 414 64 -48 grass_block
execute in minecraft:overworld run fill 414 65 -48 414 144 -48 air
execute in minecraft:overworld run fill 414 58 -47 414 63 -47 stone
execute in minecraft:overworld run fill 414 64 -47 414 65 -47 dirt
execute in minecraft:overworld run setblock 414 66 -47 coarse_dirt
execute in minecraft:overworld run fill 414 67 -47 414 144 -47 air
execute in minecraft:overworld run fill 414 58 -46 414 64 -46 stone
execute in minecraft:overworld run fill 414 65 -46 414 66 -46 dirt
execute in minecraft:overworld run setblock 414 67 -46 grass_block
execute in minecraft:overworld run fill 414 68 -46 414 144 -46 air
execute in minecraft:overworld run fill 414 58 -45 414 66 -45 stone
execute in minecraft:overworld run fill 414 67 -45 414 68 -45 dirt
execute in minecraft:overworld run setblock 414 69 -45 coarse_dirt
execute in minecraft:overworld run fill 414 70 -45 414 144 -45 air
execute in minecraft:overworld run fill 414 58 -44 414 67 -44 stone
execute in minecraft:overworld run fill 414 68 -44 414 69 -44 dirt
execute in minecraft:overworld run setblock 414 70 -44 grass_block
execute in minecraft:overworld run fill 414 71 -44 414 144 -44 air
execute in minecraft:overworld run fill 414 58 -43 414 69 -43 stone
execute in minecraft:overworld run fill 414 70 -43 414 71 -43 dirt
execute in minecraft:overworld run setblock 414 72 -43 coarse_dirt
execute in minecraft:overworld run fill 414 73 -43 414 144 -43 air
execute in minecraft:overworld run fill 414 58 -42 414 70 -42 stone
execute in minecraft:overworld run fill 414 71 -42 414 72 -42 dirt
execute in minecraft:overworld run setblock 414 73 -42 grass_block
execute in minecraft:overworld run fill 414 74 -42 414 144 -42 air
execute in minecraft:overworld run fill 414 58 -41 414 71 -41 stone
execute in minecraft:overworld run fill 414 72 -41 414 73 -41 dirt
execute in minecraft:overworld run setblock 414 74 -41 coarse_dirt
execute in minecraft:overworld run fill 414 75 -41 414 144 -41 air
execute in minecraft:overworld run fill 414 58 -40 414 73 -40 stone
execute in minecraft:overworld run fill 414 74 -40 414 75 -40 dirt
execute in minecraft:overworld run setblock 414 76 -40 grass_block
execute in minecraft:overworld run fill 414 77 -40 414 144 -40 air
execute in minecraft:overworld run fill 414 58 -39 414 74 -39 stone
execute in minecraft:overworld run fill 414 75 -39 414 76 -39 dirt
execute in minecraft:overworld run setblock 414 77 -39 grass_block
execute in minecraft:overworld run fill 414 78 -39 414 144 -39 air
execute in minecraft:overworld run fill 414 58 -38 414 75 -38 stone
execute in minecraft:overworld run fill 414 76 -38 414 77 -38 dirt
execute in minecraft:overworld run setblock 414 78 -38 grass_block
execute in minecraft:overworld run fill 414 79 -38 414 144 -38 air
execute in minecraft:overworld run fill 414 58 -37 414 75 -37 stone
execute in minecraft:overworld run fill 414 76 -37 414 77 -37 dirt
execute in minecraft:overworld run setblock 414 78 -37 coarse_dirt
execute in minecraft:overworld run fill 414 79 -37 414 144 -37 air
execute in minecraft:overworld run fill 414 58 -36 414 74 -36 stone
execute in minecraft:overworld run fill 414 75 -36 414 76 -36 dirt
execute in minecraft:overworld run setblock 414 77 -36 grass_block
execute in minecraft:overworld run fill 414 78 -36 414 144 -36 air
execute in minecraft:overworld run fill 414 58 -35 414 74 -35 stone
execute in minecraft:overworld run fill 414 75 -35 414 76 -35 dirt
execute in minecraft:overworld run setblock 414 77 -35 coarse_dirt
execute in minecraft:overworld run fill 414 78 -35 414 144 -35 air
execute in minecraft:overworld run fill 414 58 -34 414 73 -34 stone
execute in minecraft:overworld run fill 414 74 -34 414 75 -34 dirt
execute in minecraft:overworld run setblock 414 76 -34 coarse_dirt
execute in minecraft:overworld run fill 414 77 -34 414 144 -34 air
execute in minecraft:overworld run fill 414 58 -33 414 73 -33 stone
execute in minecraft:overworld run fill 414 74 -33 414 75 -33 dirt
execute in minecraft:overworld run setblock 414 76 -33 coarse_dirt
execute in minecraft:overworld run fill 414 77 -33 414 144 -33 air
execute in minecraft:overworld run fill 414 58 -32 414 72 -32 stone
execute in minecraft:overworld run fill 414 73 -32 414 74 -32 dirt
execute in minecraft:overworld run setblock 414 75 -32 coarse_dirt
execute in minecraft:overworld run fill 414 76 -32 414 144 -32 air
execute in minecraft:overworld run setblock 414 76 -32 mossy_cobblestone
execute in minecraft:overworld run fill 414 58 -31 414 72 -31 stone
execute in minecraft:overworld run fill 414 73 -31 414 74 -31 dirt
execute in minecraft:overworld run setblock 414 75 -31 coarse_dirt
execute in minecraft:overworld run fill 414 76 -31 414 144 -31 air
execute in minecraft:overworld run fill 414 58 -30 414 72 -30 stone
execute in minecraft:overworld run fill 414 73 -30 414 74 -30 dirt
execute in minecraft:overworld run setblock 414 75 -30 coarse_dirt
execute in minecraft:overworld run fill 414 76 -30 414 144 -30 air
execute in minecraft:overworld run fill 414 58 -29 414 71 -29 stone
execute in minecraft:overworld run fill 414 72 -29 414 73 -29 dirt
execute in minecraft:overworld run setblock 414 74 -29 grass_block
execute in minecraft:overworld run fill 414 75 -29 414 144 -29 air
execute in minecraft:overworld run fill 414 58 -28 414 71 -28 stone
execute in minecraft:overworld run fill 414 72 -28 414 73 -28 dirt
execute in minecraft:overworld run setblock 414 74 -28 grass_block
execute in minecraft:overworld run fill 414 75 -28 414 144 -28 air
execute in minecraft:overworld run fill 414 58 -27 414 70 -27 stone
execute in minecraft:overworld run fill 414 71 -27 414 72 -27 dirt
execute in minecraft:overworld run setblock 414 73 -27 coarse_dirt
execute in minecraft:overworld run fill 414 74 -27 414 144 -27 air
execute in minecraft:overworld run setblock 414 74 -27 grass
execute in minecraft:overworld run fill 414 58 -26 414 70 -26 stone
schedule function blade_gallery:random/battlefield/part_123 1t replace
