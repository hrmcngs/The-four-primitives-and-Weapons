execute in minecraft:overworld run fill 370 66 10 370 67 10 dirt
execute in minecraft:overworld run setblock 370 68 10 grass_block
execute in minecraft:overworld run fill 370 69 10 370 144 10 air
execute in minecraft:overworld run fill 370 58 11 370 66 11 stone
execute in minecraft:overworld run fill 370 67 11 370 68 11 dirt
execute in minecraft:overworld run setblock 370 69 11 coarse_dirt
execute in minecraft:overworld run fill 370 70 11 370 144 11 air
execute in minecraft:overworld run setblock 370 70 11 grass
execute in minecraft:overworld run fill 370 58 12 370 66 12 stone
execute in minecraft:overworld run fill 370 67 12 370 68 12 dirt
execute in minecraft:overworld run setblock 370 69 12 coarse_dirt
execute in minecraft:overworld run fill 370 70 12 370 144 12 air
execute in minecraft:overworld run fill 370 58 13 370 66 13 stone
execute in minecraft:overworld run fill 370 67 13 370 68 13 dirt
execute in minecraft:overworld run setblock 370 69 13 coarse_dirt
execute in minecraft:overworld run fill 370 70 13 370 144 13 air
execute in minecraft:overworld run fill 370 58 14 370 66 14 stone
execute in minecraft:overworld run fill 370 67 14 370 68 14 dirt
execute in minecraft:overworld run setblock 370 69 14 coarse_dirt
execute in minecraft:overworld run fill 370 70 14 370 144 14 air
execute in minecraft:overworld run fill 370 58 15 370 67 15 stone
execute in minecraft:overworld run fill 370 68 15 370 69 15 dirt
execute in minecraft:overworld run setblock 370 70 15 coarse_dirt
execute in minecraft:overworld run fill 370 71 15 370 144 15 air
execute in minecraft:overworld run fill 370 58 16 370 67 16 stone
execute in minecraft:overworld run fill 370 68 16 370 69 16 dirt
execute in minecraft:overworld run setblock 370 70 16 coarse_dirt
execute in minecraft:overworld run fill 370 71 16 370 144 16 air
execute in minecraft:overworld run fill 370 58 17 370 67 17 stone
execute in minecraft:overworld run fill 370 68 17 370 69 17 dirt
execute in minecraft:overworld run setblock 370 70 17 coarse_dirt
execute in minecraft:overworld run fill 370 71 17 370 144 17 air
execute in minecraft:overworld run fill 370 58 18 370 67 18 stone
execute in minecraft:overworld run fill 370 68 18 370 69 18 dirt
execute in minecraft:overworld run setblock 370 70 18 grass_block
execute in minecraft:overworld run fill 370 71 18 370 144 18 air
execute in minecraft:overworld run setblock 370 71 18 grass
execute in minecraft:overworld run fill 370 58 19 370 68 19 stone
execute in minecraft:overworld run fill 370 69 19 370 70 19 dirt
execute in minecraft:overworld run setblock 370 71 19 grass_block
execute in minecraft:overworld run fill 370 72 19 370 144 19 air
execute in minecraft:overworld run fill 370 58 20 370 68 20 stone
execute in minecraft:overworld run fill 370 69 20 370 70 20 dirt
execute in minecraft:overworld run setblock 370 71 20 coarse_dirt
execute in minecraft:overworld run fill 370 72 20 370 144 20 air
execute in minecraft:overworld run fill 370 58 21 370 68 21 stone
execute in minecraft:overworld run fill 370 69 21 370 70 21 dirt
execute in minecraft:overworld run setblock 370 71 21 coarse_dirt
execute in minecraft:overworld run fill 370 72 21 370 144 21 air
execute in minecraft:overworld run setblock 370 72 21 grass
execute in minecraft:overworld run fill 370 58 22 370 68 22 stone
execute in minecraft:overworld run fill 370 69 22 370 70 22 dirt
execute in minecraft:overworld run setblock 370 71 22 grass_block
execute in minecraft:overworld run fill 370 72 22 370 144 22 air
execute in minecraft:overworld run setblock 370 72 22 grass
execute in minecraft:overworld run fill 370 58 23 370 68 23 stone
execute in minecraft:overworld run fill 370 69 23 370 70 23 dirt
execute in minecraft:overworld run setblock 370 71 23 coarse_dirt
execute in minecraft:overworld run fill 370 72 23 370 144 23 air
execute in minecraft:overworld run fill 370 58 24 370 68 24 stone
execute in minecraft:overworld run fill 370 69 24 370 70 24 dirt
execute in minecraft:overworld run setblock 370 71 24 coarse_dirt
execute in minecraft:overworld run fill 370 72 24 370 144 24 air
execute in minecraft:overworld run fill 370 58 25 370 68 25 stone
execute in minecraft:overworld run fill 370 69 25 370 70 25 dirt
execute in minecraft:overworld run setblock 370 71 25 coarse_dirt
execute in minecraft:overworld run fill 370 72 25 370 144 25 air
execute in minecraft:overworld run fill 370 58 26 370 68 26 stone
execute in minecraft:overworld run fill 370 69 26 370 70 26 dirt
execute in minecraft:overworld run setblock 370 71 26 coarse_dirt
execute in minecraft:overworld run fill 370 72 26 370 144 26 air
execute in minecraft:overworld run fill 370 58 27 370 68 27 stone
execute in minecraft:overworld run fill 370 69 27 370 70 27 dirt
execute in minecraft:overworld run setblock 370 71 27 coarse_dirt
execute in minecraft:overworld run fill 370 72 27 370 144 27 air
execute in minecraft:overworld run fill 370 58 28 370 68 28 stone
execute in minecraft:overworld run fill 370 69 28 370 70 28 dirt
execute in minecraft:overworld run setblock 370 71 28 grass_block
execute in minecraft:overworld run fill 370 72 28 370 144 28 air
execute in minecraft:overworld run fill 370 58 29 370 68 29 stone
execute in minecraft:overworld run fill 370 69 29 370 70 29 dirt
execute in minecraft:overworld run setblock 370 71 29 coarse_dirt
execute in minecraft:overworld run fill 370 72 29 370 144 29 air
execute in minecraft:overworld run setblock 370 72 29 mossy_cobblestone
execute in minecraft:overworld run fill 370 58 30 370 68 30 stone
execute in minecraft:overworld run fill 370 69 30 370 70 30 dirt
execute in minecraft:overworld run setblock 370 71 30 grass_block
execute in minecraft:overworld run fill 370 72 30 370 144 30 air
execute in minecraft:overworld run setblock 370 72 30 grass
execute in minecraft:overworld run fill 370 58 31 370 69 31 stone
execute in minecraft:overworld run fill 370 70 31 370 71 31 dirt
execute in minecraft:overworld run setblock 370 72 31 grass_block
execute in minecraft:overworld run fill 370 73 31 370 144 31 air
execute in minecraft:overworld run fill 370 58 32 370 69 32 stone
execute in minecraft:overworld run fill 370 70 32 370 71 32 dirt
execute in minecraft:overworld run setblock 370 72 32 coarse_dirt
execute in minecraft:overworld run fill 370 73 32 370 144 32 air
execute in minecraft:overworld run fill 370 58 33 370 70 33 stone
execute in minecraft:overworld run fill 370 71 33 370 72 33 dirt
execute in minecraft:overworld run setblock 370 73 33 coarse_dirt
execute in minecraft:overworld run fill 370 74 33 370 144 33 air
execute in minecraft:overworld run fill 370 58 34 370 70 34 stone
execute in minecraft:overworld run fill 370 71 34 370 72 34 dirt
execute in minecraft:overworld run setblock 370 73 34 coarse_dirt
execute in minecraft:overworld run fill 370 74 34 370 144 34 air
execute in minecraft:overworld run fill 370 58 35 370 70 35 stone
execute in minecraft:overworld run fill 370 71 35 370 72 35 dirt
execute in minecraft:overworld run setblock 370 73 35 grass_block
execute in minecraft:overworld run fill 370 74 35 370 144 35 air
execute in minecraft:overworld run fill 370 58 36 370 70 36 stone
execute in minecraft:overworld run fill 370 71 36 370 72 36 dirt
execute in minecraft:overworld run setblock 370 73 36 coarse_dirt
execute in minecraft:overworld run fill 370 74 36 370 144 36 air
execute in minecraft:overworld run setblock 370 74 36 grass
execute in minecraft:overworld run fill 370 58 37 370 70 37 stone
execute in minecraft:overworld run fill 370 71 37 370 72 37 dirt
execute in minecraft:overworld run setblock 370 73 37 coarse_dirt
execute in minecraft:overworld run fill 370 74 37 370 144 37 air
execute in minecraft:overworld run setblock 370 74 37 grass
execute in minecraft:overworld run fill 370 58 38 370 70 38 stone
execute in minecraft:overworld run fill 370 71 38 370 72 38 dirt
execute in minecraft:overworld run setblock 370 73 38 grass_block
execute in minecraft:overworld run fill 370 74 38 370 144 38 air
execute in minecraft:overworld run fill 370 58 39 370 69 39 stone
execute in minecraft:overworld run fill 370 70 39 370 71 39 dirt
execute in minecraft:overworld run setblock 370 72 39 coarse_dirt
execute in minecraft:overworld run fill 370 73 39 370 144 39 air
execute in minecraft:overworld run fill 370 58 40 370 68 40 stone
execute in minecraft:overworld run fill 370 69 40 370 70 40 dirt
execute in minecraft:overworld run setblock 370 71 40 coarse_dirt
execute in minecraft:overworld run fill 370 72 40 370 144 40 air
execute in minecraft:overworld run fill 370 58 41 370 68 41 stone
execute in minecraft:overworld run fill 370 69 41 370 70 41 dirt
execute in minecraft:overworld run setblock 370 71 41 coarse_dirt
execute in minecraft:overworld run fill 370 72 41 370 144 41 air
execute in minecraft:overworld run fill 370 58 42 370 67 42 stone
execute in minecraft:overworld run fill 370 68 42 370 69 42 dirt
execute in minecraft:overworld run setblock 370 70 42 grass_block
execute in minecraft:overworld run fill 370 71 42 370 144 42 air
execute in minecraft:overworld run fill 370 58 43 370 66 43 stone
execute in minecraft:overworld run fill 370 67 43 370 68 43 dirt
execute in minecraft:overworld run setblock 370 69 43 grass_block
execute in minecraft:overworld run fill 370 70 43 370 144 43 air
execute in minecraft:overworld run fill 370 58 44 370 65 44 stone
execute in minecraft:overworld run fill 370 66 44 370 67 44 dirt
execute in minecraft:overworld run setblock 370 68 44 grass_block
execute in minecraft:overworld run fill 370 69 44 370 144 44 air
execute in minecraft:overworld run fill 370 58 45 370 64 45 stone
execute in minecraft:overworld run fill 370 65 45 370 66 45 dirt
execute in minecraft:overworld run setblock 370 67 45 grass_block
execute in minecraft:overworld run fill 370 68 45 370 144 45 air
execute in minecraft:overworld run fill 370 58 46 370 63 46 stone
execute in minecraft:overworld run fill 370 64 46 370 65 46 dirt
execute in minecraft:overworld run setblock 370 66 46 coarse_dirt
execute in minecraft:overworld run fill 370 67 46 370 144 46 air
execute in minecraft:overworld run fill 370 58 47 370 62 47 stone
execute in minecraft:overworld run fill 370 63 47 370 64 47 dirt
execute in minecraft:overworld run setblock 370 65 47 coarse_dirt
execute in minecraft:overworld run fill 370 66 47 370 144 47 air
execute in minecraft:overworld run fill 371 58 -48 371 61 -48 stone
execute in minecraft:overworld run fill 371 62 -48 371 63 -48 dirt
execute in minecraft:overworld run setblock 371 64 -48 coarse_dirt
execute in minecraft:overworld run fill 371 65 -48 371 144 -48 air
execute in minecraft:overworld run fill 371 58 -47 371 62 -47 stone
execute in minecraft:overworld run fill 371 63 -47 371 64 -47 dirt
execute in minecraft:overworld run setblock 371 65 -47 coarse_dirt
execute in minecraft:overworld run fill 371 66 -47 371 144 -47 air
execute in minecraft:overworld run fill 371 58 -46 371 63 -46 stone
execute in minecraft:overworld run fill 371 64 -46 371 65 -46 dirt
execute in minecraft:overworld run setblock 371 66 -46 coarse_dirt
execute in minecraft:overworld run fill 371 67 -46 371 144 -46 air
execute in minecraft:overworld run fill 371 58 -45 371 64 -45 stone
execute in minecraft:overworld run fill 371 65 -45 371 66 -45 dirt
execute in minecraft:overworld run setblock 371 67 -45 coarse_dirt
execute in minecraft:overworld run fill 371 68 -45 371 144 -45 air
execute in minecraft:overworld run fill 371 58 -44 371 65 -44 stone
execute in minecraft:overworld run fill 371 66 -44 371 67 -44 dirt
execute in minecraft:overworld run setblock 371 68 -44 grass_block
execute in minecraft:overworld run fill 371 69 -44 371 144 -44 air
execute in minecraft:overworld run fill 371 58 -43 371 65 -43 stone
execute in minecraft:overworld run fill 371 66 -43 371 67 -43 dirt
execute in minecraft:overworld run setblock 371 68 -43 coarse_dirt
execute in minecraft:overworld run fill 371 69 -43 371 144 -43 air
execute in minecraft:overworld run fill 371 58 -42 371 66 -42 stone
execute in minecraft:overworld run fill 371 67 -42 371 68 -42 dirt
execute in minecraft:overworld run setblock 371 69 -42 coarse_dirt
execute in minecraft:overworld run fill 371 70 -42 371 144 -42 air
execute in minecraft:overworld run fill 371 58 -41 371 67 -41 stone
execute in minecraft:overworld run fill 371 68 -41 371 69 -41 dirt
execute in minecraft:overworld run setblock 371 70 -41 grass_block
execute in minecraft:overworld run fill 371 71 -41 371 144 -41 air
execute in minecraft:overworld run fill 371 58 -40 371 68 -40 stone
execute in minecraft:overworld run fill 371 69 -40 371 70 -40 dirt
execute in minecraft:overworld run setblock 371 71 -40 grass_block
execute in minecraft:overworld run fill 371 72 -40 371 144 -40 air
execute in minecraft:overworld run fill 371 58 -39 371 69 -39 stone
execute in minecraft:overworld run fill 371 70 -39 371 71 -39 dirt
execute in minecraft:overworld run setblock 371 72 -39 coarse_dirt
execute in minecraft:overworld run fill 371 73 -39 371 144 -39 air
execute in minecraft:overworld run fill 371 58 -38 371 69 -38 stone
execute in minecraft:overworld run fill 371 70 -38 371 71 -38 dirt
execute in minecraft:overworld run setblock 371 72 -38 coarse_dirt
execute in minecraft:overworld run fill 371 73 -38 371 144 -38 air
execute in minecraft:overworld run fill 371 58 -37 371 69 -37 stone
execute in minecraft:overworld run fill 371 70 -37 371 71 -37 dirt
execute in minecraft:overworld run setblock 371 72 -37 grass_block
execute in minecraft:overworld run fill 371 73 -37 371 144 -37 air
execute in minecraft:overworld run fill 371 58 -36 371 70 -36 stone
execute in minecraft:overworld run fill 371 71 -36 371 72 -36 dirt
execute in minecraft:overworld run setblock 371 73 -36 coarse_dirt
execute in minecraft:overworld run fill 371 74 -36 371 144 -36 air
execute in minecraft:overworld run fill 371 58 -35 371 70 -35 stone
execute in minecraft:overworld run fill 371 71 -35 371 72 -35 dirt
execute in minecraft:overworld run setblock 371 73 -35 coarse_dirt
execute in minecraft:overworld run fill 371 74 -35 371 144 -35 air
execute in minecraft:overworld run fill 371 58 -34 371 70 -34 stone
execute in minecraft:overworld run fill 371 71 -34 371 72 -34 dirt
execute in minecraft:overworld run setblock 371 73 -34 coarse_dirt
execute in minecraft:overworld run fill 371 74 -34 371 144 -34 air
execute in minecraft:overworld run fill 371 58 -33 371 70 -33 stone
execute in minecraft:overworld run fill 371 71 -33 371 72 -33 dirt
execute in minecraft:overworld run setblock 371 73 -33 coarse_dirt
execute in minecraft:overworld run fill 371 74 -33 371 144 -33 air
execute in minecraft:overworld run fill 371 58 -32 371 70 -32 stone
execute in minecraft:overworld run fill 371 71 -32 371 72 -32 dirt
execute in minecraft:overworld run setblock 371 73 -32 coarse_dirt
execute in minecraft:overworld run fill 371 74 -32 371 144 -32 air
execute in minecraft:overworld run fill 371 58 -31 371 70 -31 stone
execute in minecraft:overworld run fill 371 71 -31 371 72 -31 dirt
execute in minecraft:overworld run setblock 371 73 -31 grass_block
execute in minecraft:overworld run fill 371 74 -31 371 144 -31 air
execute in minecraft:overworld run setblock 371 74 -31 mossy_cobblestone
execute in minecraft:overworld run fill 371 58 -30 371 70 -30 stone
execute in minecraft:overworld run fill 371 71 -30 371 72 -30 dirt
execute in minecraft:overworld run setblock 371 73 -30 coarse_dirt
execute in minecraft:overworld run fill 371 74 -30 371 144 -30 air
execute in minecraft:overworld run setblock 371 74 -30 grass
execute in minecraft:overworld run fill 371 58 -29 371 70 -29 stone
execute in minecraft:overworld run fill 371 71 -29 371 72 -29 dirt
execute in minecraft:overworld run setblock 371 73 -29 grass_block
execute in minecraft:overworld run fill 371 74 -29 371 144 -29 air
execute in minecraft:overworld run fill 371 58 -28 371 70 -28 stone
execute in minecraft:overworld run fill 371 71 -28 371 72 -28 dirt
execute in minecraft:overworld run setblock 371 73 -28 grass_block
execute in minecraft:overworld run fill 371 74 -28 371 144 -28 air
execute in minecraft:overworld run fill 371 58 -27 371 70 -27 stone
execute in minecraft:overworld run fill 371 71 -27 371 72 -27 dirt
execute in minecraft:overworld run setblock 371 73 -27 coarse_dirt
execute in minecraft:overworld run fill 371 74 -27 371 144 -27 air
execute in minecraft:overworld run fill 371 58 -26 371 70 -26 stone
execute in minecraft:overworld run fill 371 71 -26 371 72 -26 dirt
execute in minecraft:overworld run setblock 371 73 -26 coarse_dirt
execute in minecraft:overworld run fill 371 74 -26 371 144 -26 air
execute in minecraft:overworld run fill 371 58 -25 371 69 -25 stone
execute in minecraft:overworld run fill 371 70 -25 371 71 -25 dirt
execute in minecraft:overworld run setblock 371 72 -25 coarse_dirt
schedule function blade_gallery:random/battlefield/part_54 1t replace
