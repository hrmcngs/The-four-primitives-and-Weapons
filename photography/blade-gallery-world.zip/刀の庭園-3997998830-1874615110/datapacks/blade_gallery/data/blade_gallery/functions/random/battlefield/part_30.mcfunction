execute in minecraft:overworld run setblock 355 70 16 grass_block
execute in minecraft:overworld run fill 355 71 16 355 144 16 air
execute in minecraft:overworld run fill 355 58 17 355 67 17 stone
execute in minecraft:overworld run fill 355 68 17 355 69 17 dirt
execute in minecraft:overworld run setblock 355 70 17 grass_block
execute in minecraft:overworld run fill 355 71 17 355 144 17 air
execute in minecraft:overworld run setblock 355 71 17 grass
execute in minecraft:overworld run fill 355 58 18 355 67 18 stone
execute in minecraft:overworld run fill 355 68 18 355 69 18 dirt
execute in minecraft:overworld run setblock 355 70 18 coarse_dirt
execute in minecraft:overworld run fill 355 71 18 355 144 18 air
execute in minecraft:overworld run fill 355 58 19 355 67 19 stone
execute in minecraft:overworld run fill 355 68 19 355 69 19 dirt
execute in minecraft:overworld run setblock 355 70 19 coarse_dirt
execute in minecraft:overworld run fill 355 71 19 355 144 19 air
execute in minecraft:overworld run fill 355 58 20 355 67 20 stone
execute in minecraft:overworld run fill 355 68 20 355 69 20 dirt
execute in minecraft:overworld run setblock 355 70 20 coarse_dirt
execute in minecraft:overworld run fill 355 71 20 355 144 20 air
execute in minecraft:overworld run fill 355 58 21 355 68 21 stone
execute in minecraft:overworld run fill 355 69 21 355 70 21 dirt
execute in minecraft:overworld run setblock 355 71 21 coarse_dirt
execute in minecraft:overworld run fill 355 72 21 355 144 21 air
execute in minecraft:overworld run fill 355 58 22 355 68 22 stone
execute in minecraft:overworld run fill 355 69 22 355 70 22 dirt
execute in minecraft:overworld run setblock 355 71 22 coarse_dirt
execute in minecraft:overworld run fill 355 72 22 355 144 22 air
execute in minecraft:overworld run fill 355 58 23 355 68 23 stone
execute in minecraft:overworld run fill 355 69 23 355 70 23 dirt
execute in minecraft:overworld run setblock 355 71 23 coarse_dirt
execute in minecraft:overworld run fill 355 72 23 355 144 23 air
execute in minecraft:overworld run setblock 355 72 23 grass
execute in minecraft:overworld run fill 355 58 24 355 68 24 stone
execute in minecraft:overworld run fill 355 69 24 355 70 24 dirt
execute in minecraft:overworld run setblock 355 71 24 coarse_dirt
execute in minecraft:overworld run fill 355 72 24 355 144 24 air
execute in minecraft:overworld run fill 355 58 25 355 68 25 stone
execute in minecraft:overworld run fill 355 69 25 355 70 25 dirt
execute in minecraft:overworld run setblock 355 71 25 coarse_dirt
execute in minecraft:overworld run fill 355 72 25 355 144 25 air
execute in minecraft:overworld run fill 355 58 26 355 68 26 stone
execute in minecraft:overworld run fill 355 69 26 355 70 26 dirt
execute in minecraft:overworld run setblock 355 71 26 coarse_dirt
execute in minecraft:overworld run fill 355 72 26 355 144 26 air
execute in minecraft:overworld run fill 355 58 27 355 68 27 stone
execute in minecraft:overworld run fill 355 69 27 355 70 27 dirt
execute in minecraft:overworld run setblock 355 71 27 grass_block
execute in minecraft:overworld run fill 355 72 27 355 144 27 air
execute in minecraft:overworld run fill 355 58 28 355 68 28 stone
execute in minecraft:overworld run fill 355 69 28 355 70 28 dirt
execute in minecraft:overworld run setblock 355 71 28 grass_block
execute in minecraft:overworld run fill 355 72 28 355 144 28 air
execute in minecraft:overworld run setblock 355 72 28 grass
execute in minecraft:overworld run fill 355 58 29 355 68 29 stone
execute in minecraft:overworld run fill 355 69 29 355 70 29 dirt
execute in minecraft:overworld run setblock 355 71 29 grass_block
execute in minecraft:overworld run fill 355 72 29 355 144 29 air
execute in minecraft:overworld run fill 355 58 30 355 68 30 stone
execute in minecraft:overworld run fill 355 69 30 355 70 30 dirt
execute in minecraft:overworld run setblock 355 71 30 grass_block
execute in minecraft:overworld run fill 355 72 30 355 144 30 air
execute in minecraft:overworld run fill 355 58 31 355 68 31 stone
execute in minecraft:overworld run fill 355 69 31 355 70 31 dirt
execute in minecraft:overworld run setblock 355 71 31 coarse_dirt
execute in minecraft:overworld run fill 355 72 31 355 144 31 air
execute in minecraft:overworld run fill 355 58 32 355 68 32 stone
execute in minecraft:overworld run fill 355 69 32 355 70 32 dirt
execute in minecraft:overworld run setblock 355 71 32 grass_block
execute in minecraft:overworld run fill 355 72 32 355 144 32 air
execute in minecraft:overworld run fill 355 58 33 355 68 33 stone
execute in minecraft:overworld run fill 355 69 33 355 70 33 dirt
execute in minecraft:overworld run setblock 355 71 33 grass_block
execute in minecraft:overworld run fill 355 72 33 355 144 33 air
execute in minecraft:overworld run fill 355 58 34 355 68 34 stone
execute in minecraft:overworld run fill 355 69 34 355 70 34 dirt
execute in minecraft:overworld run setblock 355 71 34 grass_block
execute in minecraft:overworld run fill 355 72 34 355 144 34 air
execute in minecraft:overworld run fill 355 58 35 355 68 35 stone
execute in minecraft:overworld run fill 355 69 35 355 70 35 dirt
execute in minecraft:overworld run setblock 355 71 35 coarse_dirt
execute in minecraft:overworld run fill 355 72 35 355 144 35 air
execute in minecraft:overworld run fill 355 58 36 355 68 36 stone
execute in minecraft:overworld run fill 355 69 36 355 70 36 dirt
execute in minecraft:overworld run setblock 355 71 36 coarse_dirt
execute in minecraft:overworld run fill 355 72 36 355 144 36 air
execute in minecraft:overworld run fill 355 58 37 355 68 37 stone
execute in minecraft:overworld run fill 355 69 37 355 70 37 dirt
execute in minecraft:overworld run setblock 355 71 37 coarse_dirt
execute in minecraft:overworld run fill 355 72 37 355 144 37 air
execute in minecraft:overworld run fill 355 58 38 355 68 38 stone
execute in minecraft:overworld run fill 355 69 38 355 70 38 dirt
execute in minecraft:overworld run setblock 355 71 38 coarse_dirt
execute in minecraft:overworld run fill 355 72 38 355 144 38 air
execute in minecraft:overworld run fill 355 58 39 355 67 39 stone
execute in minecraft:overworld run fill 355 68 39 355 69 39 dirt
execute in minecraft:overworld run setblock 355 70 39 grass_block
execute in minecraft:overworld run fill 355 71 39 355 144 39 air
execute in minecraft:overworld run fill 355 58 40 355 67 40 stone
execute in minecraft:overworld run fill 355 68 40 355 69 40 dirt
execute in minecraft:overworld run setblock 355 70 40 coarse_dirt
execute in minecraft:overworld run fill 355 71 40 355 144 40 air
execute in minecraft:overworld run setblock 355 71 40 grass
execute in minecraft:overworld run fill 355 58 41 355 66 41 stone
execute in minecraft:overworld run fill 355 67 41 355 68 41 dirt
execute in minecraft:overworld run setblock 355 69 41 coarse_dirt
execute in minecraft:overworld run fill 355 70 41 355 144 41 air
execute in minecraft:overworld run fill 355 58 42 355 65 42 stone
execute in minecraft:overworld run fill 355 66 42 355 67 42 dirt
execute in minecraft:overworld run setblock 355 68 42 coarse_dirt
execute in minecraft:overworld run fill 355 69 42 355 144 42 air
execute in minecraft:overworld run fill 355 58 43 355 64 43 stone
execute in minecraft:overworld run fill 355 65 43 355 66 43 dirt
execute in minecraft:overworld run setblock 355 67 43 coarse_dirt
execute in minecraft:overworld run fill 355 68 43 355 144 43 air
execute in minecraft:overworld run fill 355 58 44 355 64 44 stone
execute in minecraft:overworld run fill 355 65 44 355 66 44 dirt
execute in minecraft:overworld run setblock 355 67 44 coarse_dirt
execute in minecraft:overworld run fill 355 68 44 355 144 44 air
execute in minecraft:overworld run fill 355 58 45 355 63 45 stone
execute in minecraft:overworld run fill 355 64 45 355 65 45 dirt
execute in minecraft:overworld run setblock 355 66 45 coarse_dirt
execute in minecraft:overworld run fill 355 67 45 355 144 45 air
execute in minecraft:overworld run fill 355 58 46 355 62 46 stone
execute in minecraft:overworld run fill 355 63 46 355 64 46 dirt
execute in minecraft:overworld run setblock 355 65 46 grass_block
execute in minecraft:overworld run fill 355 66 46 355 144 46 air
execute in minecraft:overworld run fill 355 58 47 355 62 47 stone
execute in minecraft:overworld run fill 355 63 47 355 64 47 dirt
execute in minecraft:overworld run setblock 355 65 47 coarse_dirt
execute in minecraft:overworld run fill 355 66 47 355 144 47 air
execute in minecraft:overworld run fill 356 58 -48 356 61 -48 stone
execute in minecraft:overworld run fill 356 62 -48 356 63 -48 dirt
execute in minecraft:overworld run setblock 356 64 -48 grass_block
execute in minecraft:overworld run fill 356 65 -48 356 144 -48 air
execute in minecraft:overworld run fill 356 58 -47 356 63 -47 stone
execute in minecraft:overworld run fill 356 64 -47 356 65 -47 dirt
execute in minecraft:overworld run setblock 356 66 -47 grass_block
execute in minecraft:overworld run fill 356 67 -47 356 144 -47 air
execute in minecraft:overworld run fill 356 58 -46 356 65 -46 stone
execute in minecraft:overworld run fill 356 66 -46 356 67 -46 dirt
execute in minecraft:overworld run setblock 356 68 -46 grass_block
execute in minecraft:overworld run fill 356 69 -46 356 144 -46 air
execute in minecraft:overworld run fill 356 58 -45 356 67 -45 stone
execute in minecraft:overworld run fill 356 68 -45 356 69 -45 dirt
execute in minecraft:overworld run setblock 356 70 -45 coarse_dirt
execute in minecraft:overworld run fill 356 71 -45 356 144 -45 air
execute in minecraft:overworld run fill 356 58 -44 356 68 -44 stone
execute in minecraft:overworld run fill 356 69 -44 356 70 -44 dirt
execute in minecraft:overworld run setblock 356 71 -44 coarse_dirt
execute in minecraft:overworld run fill 356 72 -44 356 144 -44 air
execute in minecraft:overworld run fill 356 58 -43 356 70 -43 stone
execute in minecraft:overworld run fill 356 71 -43 356 72 -43 dirt
execute in minecraft:overworld run setblock 356 73 -43 coarse_dirt
execute in minecraft:overworld run fill 356 74 -43 356 144 -43 air
execute in minecraft:overworld run fill 356 58 -42 356 71 -42 stone
execute in minecraft:overworld run fill 356 72 -42 356 73 -42 dirt
execute in minecraft:overworld run setblock 356 74 -42 grass_block
execute in minecraft:overworld run fill 356 75 -42 356 144 -42 air
execute in minecraft:overworld run fill 356 58 -41 356 72 -41 stone
execute in minecraft:overworld run fill 356 73 -41 356 74 -41 dirt
execute in minecraft:overworld run setblock 356 75 -41 grass_block
execute in minecraft:overworld run fill 356 76 -41 356 144 -41 air
execute in minecraft:overworld run fill 356 58 -40 356 74 -40 stone
execute in minecraft:overworld run fill 356 75 -40 356 76 -40 dirt
execute in minecraft:overworld run setblock 356 77 -40 coarse_dirt
execute in minecraft:overworld run fill 356 78 -40 356 144 -40 air
execute in minecraft:overworld run fill 356 58 -39 356 75 -39 stone
execute in minecraft:overworld run fill 356 76 -39 356 77 -39 dirt
execute in minecraft:overworld run setblock 356 78 -39 coarse_dirt
execute in minecraft:overworld run fill 356 79 -39 356 144 -39 air
execute in minecraft:overworld run fill 356 58 -38 356 75 -38 stone
execute in minecraft:overworld run fill 356 76 -38 356 77 -38 dirt
execute in minecraft:overworld run setblock 356 78 -38 coarse_dirt
execute in minecraft:overworld run fill 356 79 -38 356 144 -38 air
execute in minecraft:overworld run fill 356 58 -37 356 75 -37 stone
execute in minecraft:overworld run fill 356 76 -37 356 77 -37 dirt
execute in minecraft:overworld run setblock 356 78 -37 coarse_dirt
execute in minecraft:overworld run fill 356 79 -37 356 144 -37 air
execute in minecraft:overworld run fill 356 58 -36 356 75 -36 stone
execute in minecraft:overworld run fill 356 76 -36 356 77 -36 dirt
execute in minecraft:overworld run setblock 356 78 -36 coarse_dirt
execute in minecraft:overworld run fill 356 79 -36 356 144 -36 air
execute in minecraft:overworld run fill 356 58 -35 356 74 -35 stone
execute in minecraft:overworld run fill 356 75 -35 356 76 -35 dirt
execute in minecraft:overworld run setblock 356 77 -35 coarse_dirt
execute in minecraft:overworld run fill 356 78 -35 356 144 -35 air
execute in minecraft:overworld run fill 356 58 -34 356 74 -34 stone
execute in minecraft:overworld run fill 356 75 -34 356 76 -34 dirt
execute in minecraft:overworld run setblock 356 77 -34 coarse_dirt
execute in minecraft:overworld run fill 356 78 -34 356 144 -34 air
execute in minecraft:overworld run fill 356 58 -33 356 74 -33 stone
execute in minecraft:overworld run fill 356 75 -33 356 76 -33 dirt
execute in minecraft:overworld run setblock 356 77 -33 grass_block
execute in minecraft:overworld run fill 356 78 -33 356 144 -33 air
execute in minecraft:overworld run fill 356 58 -32 356 74 -32 stone
execute in minecraft:overworld run fill 356 75 -32 356 76 -32 dirt
execute in minecraft:overworld run setblock 356 77 -32 coarse_dirt
execute in minecraft:overworld run fill 356 78 -32 356 144 -32 air
execute in minecraft:overworld run fill 356 58 -31 356 74 -31 stone
execute in minecraft:overworld run fill 356 75 -31 356 76 -31 dirt
execute in minecraft:overworld run setblock 356 77 -31 grass_block
execute in minecraft:overworld run fill 356 78 -31 356 144 -31 air
execute in minecraft:overworld run fill 356 58 -30 356 74 -30 stone
execute in minecraft:overworld run fill 356 75 -30 356 76 -30 dirt
execute in minecraft:overworld run setblock 356 77 -30 coarse_dirt
execute in minecraft:overworld run fill 356 78 -30 356 144 -30 air
execute in minecraft:overworld run fill 356 58 -29 356 73 -29 stone
execute in minecraft:overworld run fill 356 74 -29 356 75 -29 dirt
execute in minecraft:overworld run setblock 356 76 -29 coarse_dirt
execute in minecraft:overworld run fill 356 77 -29 356 144 -29 air
execute in minecraft:overworld run fill 356 58 -28 356 73 -28 stone
execute in minecraft:overworld run fill 356 74 -28 356 75 -28 dirt
execute in minecraft:overworld run setblock 356 76 -28 coarse_dirt
execute in minecraft:overworld run fill 356 77 -28 356 144 -28 air
execute in minecraft:overworld run setblock 356 77 -28 grass
execute in minecraft:overworld run fill 356 58 -27 356 73 -27 stone
execute in minecraft:overworld run fill 356 74 -27 356 75 -27 dirt
execute in minecraft:overworld run setblock 356 76 -27 coarse_dirt
execute in minecraft:overworld run fill 356 77 -27 356 144 -27 air
execute in minecraft:overworld run fill 356 58 -26 356 73 -26 stone
execute in minecraft:overworld run fill 356 74 -26 356 75 -26 dirt
execute in minecraft:overworld run setblock 356 76 -26 coarse_dirt
execute in minecraft:overworld run fill 356 77 -26 356 144 -26 air
execute in minecraft:overworld run fill 356 58 -25 356 72 -25 stone
execute in minecraft:overworld run fill 356 73 -25 356 74 -25 dirt
execute in minecraft:overworld run setblock 356 75 -25 coarse_dirt
execute in minecraft:overworld run fill 356 76 -25 356 144 -25 air
execute in minecraft:overworld run fill 356 58 -24 356 72 -24 stone
execute in minecraft:overworld run fill 356 73 -24 356 74 -24 dirt
execute in minecraft:overworld run setblock 356 75 -24 coarse_dirt
execute in minecraft:overworld run fill 356 76 -24 356 144 -24 air
execute in minecraft:overworld run fill 356 58 -23 356 72 -23 stone
execute in minecraft:overworld run fill 356 73 -23 356 74 -23 dirt
execute in minecraft:overworld run setblock 356 75 -23 coarse_dirt
execute in minecraft:overworld run fill 356 76 -23 356 144 -23 air
execute in minecraft:overworld run fill 356 58 -22 356 71 -22 stone
execute in minecraft:overworld run fill 356 72 -22 356 73 -22 dirt
execute in minecraft:overworld run setblock 356 74 -22 coarse_dirt
execute in minecraft:overworld run fill 356 75 -22 356 144 -22 air
execute in minecraft:overworld run fill 356 58 -21 356 71 -21 stone
execute in minecraft:overworld run fill 356 72 -21 356 73 -21 dirt
execute in minecraft:overworld run setblock 356 74 -21 coarse_dirt
execute in minecraft:overworld run fill 356 75 -21 356 144 -21 air
execute in minecraft:overworld run fill 356 58 -20 356 71 -20 stone
execute in minecraft:overworld run fill 356 72 -20 356 73 -20 dirt
execute in minecraft:overworld run setblock 356 74 -20 coarse_dirt
execute in minecraft:overworld run fill 356 75 -20 356 144 -20 air
execute in minecraft:overworld run setblock 356 75 -20 mossy_cobblestone
execute in minecraft:overworld run fill 356 58 -19 356 70 -19 stone
execute in minecraft:overworld run fill 356 71 -19 356 72 -19 dirt
execute in minecraft:overworld run setblock 356 73 -19 coarse_dirt
execute in minecraft:overworld run fill 356 74 -19 356 144 -19 air
execute in minecraft:overworld run fill 356 58 -18 356 70 -18 stone
execute in minecraft:overworld run fill 356 71 -18 356 72 -18 dirt
execute in minecraft:overworld run setblock 356 73 -18 grass_block
execute in minecraft:overworld run fill 356 74 -18 356 144 -18 air
schedule function blade_gallery:random/battlefield/part_31 1t replace
