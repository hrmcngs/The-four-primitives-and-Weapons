execute in minecraft:overworld run fill 401 58 45 401 63 45 stone
execute in minecraft:overworld run fill 401 64 45 401 65 45 dirt
execute in minecraft:overworld run setblock 401 66 45 coarse_dirt
execute in minecraft:overworld run fill 401 67 45 401 144 45 air
execute in minecraft:overworld run fill 401 58 46 401 62 46 stone
execute in minecraft:overworld run fill 401 63 46 401 64 46 dirt
execute in minecraft:overworld run setblock 401 65 46 coarse_dirt
execute in minecraft:overworld run fill 401 66 46 401 144 46 air
execute in minecraft:overworld run fill 401 58 47 401 62 47 stone
execute in minecraft:overworld run fill 401 63 47 401 64 47 dirt
execute in minecraft:overworld run setblock 401 65 47 coarse_dirt
execute in minecraft:overworld run fill 401 66 47 401 144 47 air
execute in minecraft:overworld run fill 402 58 -48 402 61 -48 stone
execute in minecraft:overworld run fill 402 62 -48 402 63 -48 dirt
execute in minecraft:overworld run setblock 402 64 -48 grass_block
execute in minecraft:overworld run fill 402 65 -48 402 144 -48 air
execute in minecraft:overworld run fill 402 58 -47 402 63 -47 stone
execute in minecraft:overworld run fill 402 64 -47 402 65 -47 dirt
execute in minecraft:overworld run setblock 402 66 -47 grass_block
execute in minecraft:overworld run fill 402 67 -47 402 144 -47 air
execute in minecraft:overworld run fill 402 58 -46 402 64 -46 stone
execute in minecraft:overworld run fill 402 65 -46 402 66 -46 dirt
execute in minecraft:overworld run setblock 402 67 -46 coarse_dirt
execute in minecraft:overworld run fill 402 68 -46 402 144 -46 air
execute in minecraft:overworld run fill 402 58 -45 402 66 -45 stone
execute in minecraft:overworld run fill 402 67 -45 402 68 -45 dirt
execute in minecraft:overworld run setblock 402 69 -45 coarse_dirt
execute in minecraft:overworld run fill 402 70 -45 402 144 -45 air
execute in minecraft:overworld run fill 402 58 -44 402 67 -44 stone
execute in minecraft:overworld run fill 402 68 -44 402 69 -44 dirt
execute in minecraft:overworld run setblock 402 70 -44 grass_block
execute in minecraft:overworld run fill 402 71 -44 402 144 -44 air
execute in minecraft:overworld run fill 402 58 -43 402 68 -43 stone
execute in minecraft:overworld run fill 402 69 -43 402 70 -43 dirt
execute in minecraft:overworld run setblock 402 71 -43 grass_block
execute in minecraft:overworld run fill 402 72 -43 402 144 -43 air
execute in minecraft:overworld run fill 402 58 -42 402 70 -42 stone
execute in minecraft:overworld run fill 402 71 -42 402 72 -42 dirt
execute in minecraft:overworld run setblock 402 73 -42 coarse_dirt
execute in minecraft:overworld run fill 402 74 -42 402 144 -42 air
execute in minecraft:overworld run fill 402 58 -41 402 71 -41 stone
execute in minecraft:overworld run fill 402 72 -41 402 73 -41 dirt
execute in minecraft:overworld run setblock 402 74 -41 coarse_dirt
execute in minecraft:overworld run fill 402 75 -41 402 144 -41 air
execute in minecraft:overworld run fill 402 58 -40 402 73 -40 stone
execute in minecraft:overworld run fill 402 74 -40 402 75 -40 dirt
execute in minecraft:overworld run setblock 402 76 -40 grass_block
execute in minecraft:overworld run fill 402 77 -40 402 144 -40 air
execute in minecraft:overworld run fill 402 58 -39 402 74 -39 stone
execute in minecraft:overworld run fill 402 75 -39 402 76 -39 dirt
execute in minecraft:overworld run setblock 402 77 -39 coarse_dirt
execute in minecraft:overworld run fill 402 78 -39 402 144 -39 air
execute in minecraft:overworld run fill 402 58 -38 402 75 -38 stone
execute in minecraft:overworld run fill 402 76 -38 402 77 -38 dirt
execute in minecraft:overworld run setblock 402 78 -38 coarse_dirt
execute in minecraft:overworld run fill 402 79 -38 402 144 -38 air
execute in minecraft:overworld run setblock 402 79 -38 grass
execute in minecraft:overworld run fill 402 58 -37 402 75 -37 stone
execute in minecraft:overworld run fill 402 76 -37 402 77 -37 dirt
execute in minecraft:overworld run setblock 402 78 -37 grass_block
execute in minecraft:overworld run fill 402 79 -37 402 144 -37 air
execute in minecraft:overworld run fill 402 58 -36 402 75 -36 stone
execute in minecraft:overworld run fill 402 76 -36 402 77 -36 dirt
execute in minecraft:overworld run setblock 402 78 -36 coarse_dirt
execute in minecraft:overworld run fill 402 79 -36 402 144 -36 air
execute in minecraft:overworld run fill 402 58 -35 402 75 -35 stone
execute in minecraft:overworld run fill 402 76 -35 402 77 -35 dirt
execute in minecraft:overworld run setblock 402 78 -35 grass_block
execute in minecraft:overworld run fill 402 79 -35 402 144 -35 air
execute in minecraft:overworld run fill 402 58 -34 402 74 -34 stone
execute in minecraft:overworld run fill 402 75 -34 402 76 -34 dirt
execute in minecraft:overworld run setblock 402 77 -34 grass_block
execute in minecraft:overworld run fill 402 78 -34 402 144 -34 air
execute in minecraft:overworld run fill 402 58 -33 402 74 -33 stone
execute in minecraft:overworld run fill 402 75 -33 402 76 -33 dirt
execute in minecraft:overworld run setblock 402 77 -33 grass_block
execute in minecraft:overworld run fill 402 78 -33 402 144 -33 air
execute in minecraft:overworld run setblock 402 78 -33 grass
execute in minecraft:overworld run fill 402 58 -32 402 74 -32 stone
execute in minecraft:overworld run fill 402 75 -32 402 76 -32 dirt
execute in minecraft:overworld run setblock 402 77 -32 coarse_dirt
execute in minecraft:overworld run fill 402 78 -32 402 144 -32 air
execute in minecraft:overworld run fill 402 58 -31 402 73 -31 stone
execute in minecraft:overworld run fill 402 74 -31 402 75 -31 dirt
execute in minecraft:overworld run setblock 402 76 -31 coarse_dirt
execute in minecraft:overworld run fill 402 77 -31 402 144 -31 air
execute in minecraft:overworld run fill 402 58 -30 402 73 -30 stone
execute in minecraft:overworld run fill 402 74 -30 402 75 -30 dirt
execute in minecraft:overworld run setblock 402 76 -30 coarse_dirt
execute in minecraft:overworld run fill 402 77 -30 402 144 -30 air
execute in minecraft:overworld run fill 402 58 -29 402 73 -29 stone
execute in minecraft:overworld run fill 402 74 -29 402 75 -29 dirt
execute in minecraft:overworld run setblock 402 76 -29 grass_block
execute in minecraft:overworld run fill 402 77 -29 402 144 -29 air
execute in minecraft:overworld run setblock 402 77 -29 grass
execute in minecraft:overworld run fill 402 58 -28 402 72 -28 stone
execute in minecraft:overworld run fill 402 73 -28 402 74 -28 dirt
execute in minecraft:overworld run setblock 402 75 -28 grass_block
execute in minecraft:overworld run fill 402 76 -28 402 144 -28 air
execute in minecraft:overworld run fill 402 58 -27 402 72 -27 stone
execute in minecraft:overworld run fill 402 73 -27 402 74 -27 dirt
execute in minecraft:overworld run setblock 402 75 -27 coarse_dirt
execute in minecraft:overworld run fill 402 76 -27 402 144 -27 air
execute in minecraft:overworld run fill 402 58 -26 402 71 -26 stone
execute in minecraft:overworld run fill 402 72 -26 402 73 -26 dirt
execute in minecraft:overworld run setblock 402 74 -26 coarse_dirt
execute in minecraft:overworld run fill 402 75 -26 402 144 -26 air
execute in minecraft:overworld run fill 402 58 -25 402 71 -25 stone
execute in minecraft:overworld run fill 402 72 -25 402 73 -25 dirt
execute in minecraft:overworld run setblock 402 74 -25 coarse_dirt
execute in minecraft:overworld run fill 402 75 -25 402 144 -25 air
execute in minecraft:overworld run fill 402 58 -24 402 71 -24 stone
execute in minecraft:overworld run fill 402 72 -24 402 73 -24 dirt
execute in minecraft:overworld run setblock 402 74 -24 grass_block
execute in minecraft:overworld run fill 402 75 -24 402 144 -24 air
execute in minecraft:overworld run fill 402 58 -23 402 70 -23 stone
execute in minecraft:overworld run fill 402 71 -23 402 72 -23 dirt
execute in minecraft:overworld run setblock 402 73 -23 coarse_dirt
execute in minecraft:overworld run fill 402 74 -23 402 144 -23 air
execute in minecraft:overworld run fill 402 58 -22 402 70 -22 stone
execute in minecraft:overworld run fill 402 71 -22 402 72 -22 dirt
execute in minecraft:overworld run setblock 402 73 -22 coarse_dirt
execute in minecraft:overworld run fill 402 74 -22 402 144 -22 air
execute in minecraft:overworld run fill 402 58 -21 402 70 -21 stone
execute in minecraft:overworld run fill 402 71 -21 402 72 -21 dirt
execute in minecraft:overworld run setblock 402 73 -21 coarse_dirt
execute in minecraft:overworld run fill 402 74 -21 402 144 -21 air
execute in minecraft:overworld run fill 402 58 -20 402 69 -20 stone
execute in minecraft:overworld run fill 402 70 -20 402 71 -20 dirt
execute in minecraft:overworld run setblock 402 72 -20 coarse_dirt
execute in minecraft:overworld run fill 402 73 -20 402 144 -20 air
execute in minecraft:overworld run fill 402 58 -19 402 69 -19 stone
execute in minecraft:overworld run fill 402 70 -19 402 71 -19 dirt
execute in minecraft:overworld run setblock 402 72 -19 coarse_dirt
execute in minecraft:overworld run fill 402 73 -19 402 144 -19 air
execute in minecraft:overworld run fill 402 58 -18 402 68 -18 stone
execute in minecraft:overworld run fill 402 69 -18 402 70 -18 dirt
execute in minecraft:overworld run setblock 402 71 -18 grass_block
execute in minecraft:overworld run fill 402 72 -18 402 144 -18 air
execute in minecraft:overworld run fill 402 58 -17 402 68 -17 stone
execute in minecraft:overworld run fill 402 69 -17 402 70 -17 dirt
execute in minecraft:overworld run setblock 402 71 -17 grass_block
execute in minecraft:overworld run fill 402 72 -17 402 144 -17 air
execute in minecraft:overworld run fill 402 58 -16 402 67 -16 stone
execute in minecraft:overworld run fill 402 68 -16 402 69 -16 dirt
execute in minecraft:overworld run setblock 402 70 -16 coarse_dirt
execute in minecraft:overworld run fill 402 71 -16 402 144 -16 air
execute in minecraft:overworld run fill 402 58 -15 402 66 -15 stone
execute in minecraft:overworld run fill 402 67 -15 402 68 -15 dirt
execute in minecraft:overworld run setblock 402 69 -15 grass_block
execute in minecraft:overworld run fill 402 70 -15 402 144 -15 air
execute in minecraft:overworld run fill 402 58 -14 402 65 -14 stone
execute in minecraft:overworld run fill 402 66 -14 402 67 -14 dirt
execute in minecraft:overworld run setblock 402 68 -14 coarse_dirt
execute in minecraft:overworld run fill 402 69 -14 402 144 -14 air
execute in minecraft:overworld run fill 402 58 -13 402 64 -13 stone
execute in minecraft:overworld run fill 402 65 -13 402 66 -13 dirt
execute in minecraft:overworld run setblock 402 67 -13 coarse_dirt
execute in minecraft:overworld run fill 402 68 -13 402 144 -13 air
execute in minecraft:overworld run fill 402 58 -12 402 63 -12 stone
execute in minecraft:overworld run fill 402 64 -12 402 65 -12 dirt
execute in minecraft:overworld run setblock 402 66 -12 coarse_dirt
execute in minecraft:overworld run fill 402 67 -12 402 144 -12 air
execute in minecraft:overworld run fill 402 58 -11 402 63 -11 stone
execute in minecraft:overworld run fill 402 64 -11 402 65 -11 dirt
execute in minecraft:overworld run setblock 402 66 -11 coarse_dirt
execute in minecraft:overworld run fill 402 67 -11 402 144 -11 air
execute in minecraft:overworld run fill 402 58 -10 402 62 -10 stone
execute in minecraft:overworld run fill 402 63 -10 402 64 -10 dirt
execute in minecraft:overworld run setblock 402 65 -10 coarse_dirt
execute in minecraft:overworld run fill 402 66 -10 402 144 -10 air
execute in minecraft:overworld run fill 402 58 -9 402 62 -9 stone
execute in minecraft:overworld run fill 402 63 -9 402 64 -9 dirt
execute in minecraft:overworld run setblock 402 65 -9 coarse_dirt
execute in minecraft:overworld run fill 402 66 -9 402 144 -9 air
execute in minecraft:overworld run fill 402 58 -8 402 62 -8 stone
execute in minecraft:overworld run fill 402 63 -8 402 64 -8 dirt
execute in minecraft:overworld run setblock 402 65 -8 coarse_dirt
execute in minecraft:overworld run fill 402 66 -8 402 144 -8 air
execute in minecraft:overworld run fill 402 58 -7 402 61 -7 stone
execute in minecraft:overworld run fill 402 62 -7 402 63 -7 dirt
execute in minecraft:overworld run setblock 402 64 -7 coarse_dirt
execute in minecraft:overworld run fill 402 65 -7 402 144 -7 air
execute in minecraft:overworld run fill 402 58 -6 402 61 -6 stone
execute in minecraft:overworld run fill 402 62 -6 402 63 -6 dirt
execute in minecraft:overworld run setblock 402 64 -6 coarse_dirt
execute in minecraft:overworld run fill 402 65 -6 402 144 -6 air
execute in minecraft:overworld run fill 402 58 -5 402 61 -5 stone
execute in minecraft:overworld run fill 402 62 -5 402 63 -5 dirt
execute in minecraft:overworld run setblock 402 64 -5 coarse_dirt
execute in minecraft:overworld run fill 402 65 -5 402 144 -5 air
execute in minecraft:overworld run fill 402 58 -4 402 60 -4 stone
execute in minecraft:overworld run fill 402 61 -4 402 62 -4 dirt
execute in minecraft:overworld run setblock 402 63 -4 gravel
execute in minecraft:overworld run fill 402 64 -4 402 144 -4 air
execute in minecraft:overworld run fill 402 64 -4 402 64 -4 water
execute in minecraft:overworld run fill 402 58 -3 402 60 -3 stone
execute in minecraft:overworld run fill 402 61 -3 402 62 -3 dirt
execute in minecraft:overworld run setblock 402 63 -3 gravel
execute in minecraft:overworld run fill 402 64 -3 402 144 -3 air
execute in minecraft:overworld run fill 402 64 -3 402 64 -3 water
execute in minecraft:overworld run fill 402 58 -2 402 59 -2 stone
execute in minecraft:overworld run fill 402 60 -2 402 61 -2 dirt
execute in minecraft:overworld run setblock 402 62 -2 gravel
execute in minecraft:overworld run fill 402 63 -2 402 144 -2 air
execute in minecraft:overworld run fill 402 63 -2 402 64 -2 water
execute in minecraft:overworld run fill 402 58 -1 402 59 -1 stone
execute in minecraft:overworld run fill 402 60 -1 402 61 -1 dirt
execute in minecraft:overworld run setblock 402 62 -1 gravel
execute in minecraft:overworld run fill 402 63 -1 402 144 -1 air
execute in minecraft:overworld run fill 402 63 -1 402 64 -1 water
execute in minecraft:overworld run fill 402 58 0 402 59 0 stone
execute in minecraft:overworld run fill 402 60 0 402 61 0 dirt
execute in minecraft:overworld run setblock 402 62 0 gravel
execute in minecraft:overworld run fill 402 63 0 402 144 0 air
execute in minecraft:overworld run fill 402 63 0 402 64 0 water
execute in minecraft:overworld run fill 402 58 1 402 59 1 stone
execute in minecraft:overworld run fill 402 60 1 402 61 1 dirt
execute in minecraft:overworld run setblock 402 62 1 gravel
execute in minecraft:overworld run fill 402 63 1 402 144 1 air
execute in minecraft:overworld run fill 402 63 1 402 64 1 water
execute in minecraft:overworld run fill 402 58 2 402 59 2 stone
execute in minecraft:overworld run fill 402 60 2 402 61 2 dirt
execute in minecraft:overworld run setblock 402 62 2 gravel
execute in minecraft:overworld run fill 402 63 2 402 144 2 air
execute in minecraft:overworld run fill 402 63 2 402 64 2 water
execute in minecraft:overworld run fill 402 58 3 402 58 3 stone
execute in minecraft:overworld run fill 402 59 3 402 60 3 dirt
execute in minecraft:overworld run setblock 402 61 3 gravel
execute in minecraft:overworld run fill 402 62 3 402 144 3 air
execute in minecraft:overworld run fill 402 62 3 402 64 3 water
execute in minecraft:overworld run fill 402 58 4 402 58 4 stone
execute in minecraft:overworld run fill 402 59 4 402 60 4 dirt
execute in minecraft:overworld run setblock 402 61 4 gravel
execute in minecraft:overworld run fill 402 62 4 402 144 4 air
execute in minecraft:overworld run fill 402 62 4 402 64 4 water
execute in minecraft:overworld run fill 402 58 5 402 58 5 stone
execute in minecraft:overworld run fill 402 59 5 402 60 5 dirt
execute in minecraft:overworld run setblock 402 61 5 gravel
execute in minecraft:overworld run fill 402 62 5 402 144 5 air
execute in minecraft:overworld run fill 402 62 5 402 64 5 water
execute in minecraft:overworld run fill 402 58 6 402 58 6 stone
execute in minecraft:overworld run fill 402 59 6 402 60 6 dirt
execute in minecraft:overworld run setblock 402 61 6 gravel
execute in minecraft:overworld run fill 402 62 6 402 144 6 air
execute in minecraft:overworld run fill 402 62 6 402 64 6 water
execute in minecraft:overworld run fill 402 58 7 402 58 7 stone
execute in minecraft:overworld run fill 402 59 7 402 60 7 dirt
execute in minecraft:overworld run setblock 402 61 7 gravel
execute in minecraft:overworld run fill 402 62 7 402 144 7 air
execute in minecraft:overworld run fill 402 62 7 402 64 7 water
execute in minecraft:overworld run fill 402 58 8 402 58 8 stone
execute in minecraft:overworld run fill 402 59 8 402 60 8 dirt
execute in minecraft:overworld run setblock 402 61 8 gravel
execute in minecraft:overworld run fill 402 62 8 402 144 8 air
execute in minecraft:overworld run fill 402 62 8 402 64 8 water
schedule function blade_gallery:random/battlefield/part_105 1t replace
