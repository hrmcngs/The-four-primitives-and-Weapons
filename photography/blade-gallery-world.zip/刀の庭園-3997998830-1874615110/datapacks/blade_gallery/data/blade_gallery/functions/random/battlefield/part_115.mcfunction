execute in minecraft:overworld run fill 409 65 -48 409 144 -48 air
execute in minecraft:overworld run fill 409 58 -47 409 63 -47 stone
execute in minecraft:overworld run fill 409 64 -47 409 65 -47 dirt
execute in minecraft:overworld run setblock 409 66 -47 coarse_dirt
execute in minecraft:overworld run fill 409 67 -47 409 144 -47 air
execute in minecraft:overworld run fill 409 58 -46 409 64 -46 stone
execute in minecraft:overworld run fill 409 65 -46 409 66 -46 dirt
execute in minecraft:overworld run setblock 409 67 -46 coarse_dirt
execute in minecraft:overworld run fill 409 68 -46 409 144 -46 air
execute in minecraft:overworld run fill 409 58 -45 409 66 -45 stone
execute in minecraft:overworld run fill 409 67 -45 409 68 -45 dirt
execute in minecraft:overworld run setblock 409 69 -45 grass_block
execute in minecraft:overworld run fill 409 70 -45 409 144 -45 air
execute in minecraft:overworld run fill 409 58 -44 409 67 -44 stone
execute in minecraft:overworld run fill 409 68 -44 409 69 -44 dirt
execute in minecraft:overworld run setblock 409 70 -44 coarse_dirt
execute in minecraft:overworld run fill 409 71 -44 409 144 -44 air
execute in minecraft:overworld run fill 409 58 -43 409 69 -43 stone
execute in minecraft:overworld run fill 409 70 -43 409 71 -43 dirt
execute in minecraft:overworld run setblock 409 72 -43 coarse_dirt
execute in minecraft:overworld run fill 409 73 -43 409 144 -43 air
execute in minecraft:overworld run fill 409 58 -42 409 70 -42 stone
execute in minecraft:overworld run fill 409 71 -42 409 72 -42 dirt
execute in minecraft:overworld run setblock 409 73 -42 coarse_dirt
execute in minecraft:overworld run fill 409 74 -42 409 144 -42 air
execute in minecraft:overworld run fill 409 58 -41 409 72 -41 stone
execute in minecraft:overworld run fill 409 73 -41 409 74 -41 dirt
execute in minecraft:overworld run setblock 409 75 -41 coarse_dirt
execute in minecraft:overworld run fill 409 76 -41 409 144 -41 air
execute in minecraft:overworld run fill 409 58 -40 409 73 -40 stone
execute in minecraft:overworld run fill 409 74 -40 409 75 -40 dirt
execute in minecraft:overworld run setblock 409 76 -40 grass_block
execute in minecraft:overworld run fill 409 77 -40 409 144 -40 air
execute in minecraft:overworld run fill 409 58 -39 409 74 -39 stone
execute in minecraft:overworld run fill 409 75 -39 409 76 -39 dirt
execute in minecraft:overworld run setblock 409 77 -39 coarse_dirt
execute in minecraft:overworld run fill 409 78 -39 409 144 -39 air
execute in minecraft:overworld run fill 409 58 -38 409 75 -38 stone
execute in minecraft:overworld run fill 409 76 -38 409 77 -38 dirt
execute in minecraft:overworld run setblock 409 78 -38 grass_block
execute in minecraft:overworld run fill 409 79 -38 409 144 -38 air
execute in minecraft:overworld run fill 409 58 -37 409 75 -37 stone
execute in minecraft:overworld run fill 409 76 -37 409 77 -37 dirt
execute in minecraft:overworld run setblock 409 78 -37 coarse_dirt
execute in minecraft:overworld run fill 409 79 -37 409 144 -37 air
execute in minecraft:overworld run fill 409 58 -36 409 75 -36 stone
execute in minecraft:overworld run fill 409 76 -36 409 77 -36 dirt
execute in minecraft:overworld run setblock 409 78 -36 coarse_dirt
execute in minecraft:overworld run fill 409 79 -36 409 144 -36 air
execute in minecraft:overworld run fill 409 58 -35 409 74 -35 stone
execute in minecraft:overworld run fill 409 75 -35 409 76 -35 dirt
execute in minecraft:overworld run setblock 409 77 -35 coarse_dirt
execute in minecraft:overworld run fill 409 78 -35 409 144 -35 air
execute in minecraft:overworld run fill 409 58 -34 409 74 -34 stone
execute in minecraft:overworld run fill 409 75 -34 409 76 -34 dirt
execute in minecraft:overworld run setblock 409 77 -34 grass_block
execute in minecraft:overworld run fill 409 78 -34 409 144 -34 air
execute in minecraft:overworld run fill 409 58 -33 409 74 -33 stone
execute in minecraft:overworld run fill 409 75 -33 409 76 -33 dirt
execute in minecraft:overworld run setblock 409 77 -33 coarse_dirt
execute in minecraft:overworld run fill 409 78 -33 409 144 -33 air
execute in minecraft:overworld run fill 409 58 -32 409 73 -32 stone
execute in minecraft:overworld run fill 409 74 -32 409 75 -32 dirt
execute in minecraft:overworld run setblock 409 76 -32 coarse_dirt
execute in minecraft:overworld run fill 409 77 -32 409 144 -32 air
execute in minecraft:overworld run fill 409 58 -31 409 73 -31 stone
execute in minecraft:overworld run fill 409 74 -31 409 75 -31 dirt
execute in minecraft:overworld run setblock 409 76 -31 coarse_dirt
execute in minecraft:overworld run fill 409 77 -31 409 144 -31 air
execute in minecraft:overworld run fill 409 58 -30 409 72 -30 stone
execute in minecraft:overworld run fill 409 73 -30 409 74 -30 dirt
execute in minecraft:overworld run setblock 409 75 -30 coarse_dirt
execute in minecraft:overworld run fill 409 76 -30 409 144 -30 air
execute in minecraft:overworld run fill 409 58 -29 409 72 -29 stone
execute in minecraft:overworld run fill 409 73 -29 409 74 -29 dirt
execute in minecraft:overworld run setblock 409 75 -29 coarse_dirt
execute in minecraft:overworld run fill 409 76 -29 409 144 -29 air
execute in minecraft:overworld run fill 409 58 -28 409 72 -28 stone
execute in minecraft:overworld run fill 409 73 -28 409 74 -28 dirt
execute in minecraft:overworld run setblock 409 75 -28 grass_block
execute in minecraft:overworld run fill 409 76 -28 409 144 -28 air
execute in minecraft:overworld run setblock 409 76 -28 grass
execute in minecraft:overworld run fill 409 58 -27 409 71 -27 stone
execute in minecraft:overworld run fill 409 72 -27 409 73 -27 dirt
execute in minecraft:overworld run setblock 409 74 -27 coarse_dirt
execute in minecraft:overworld run fill 409 75 -27 409 144 -27 air
execute in minecraft:overworld run fill 409 58 -26 409 71 -26 stone
execute in minecraft:overworld run fill 409 72 -26 409 73 -26 dirt
execute in minecraft:overworld run setblock 409 74 -26 grass_block
execute in minecraft:overworld run fill 409 75 -26 409 144 -26 air
execute in minecraft:overworld run fill 409 58 -25 409 71 -25 stone
execute in minecraft:overworld run fill 409 72 -25 409 73 -25 dirt
execute in minecraft:overworld run setblock 409 74 -25 coarse_dirt
execute in minecraft:overworld run fill 409 75 -25 409 144 -25 air
execute in minecraft:overworld run fill 409 58 -24 409 70 -24 stone
execute in minecraft:overworld run fill 409 71 -24 409 72 -24 dirt
execute in minecraft:overworld run setblock 409 73 -24 grass_block
execute in minecraft:overworld run fill 409 74 -24 409 144 -24 air
execute in minecraft:overworld run fill 409 58 -23 409 70 -23 stone
execute in minecraft:overworld run fill 409 71 -23 409 72 -23 dirt
execute in minecraft:overworld run setblock 409 73 -23 coarse_dirt
execute in minecraft:overworld run fill 409 74 -23 409 144 -23 air
execute in minecraft:overworld run fill 409 58 -22 409 70 -22 stone
execute in minecraft:overworld run fill 409 71 -22 409 72 -22 dirt
execute in minecraft:overworld run setblock 409 73 -22 grass_block
execute in minecraft:overworld run fill 409 74 -22 409 144 -22 air
execute in minecraft:overworld run fill 409 58 -21 409 69 -21 stone
execute in minecraft:overworld run fill 409 70 -21 409 71 -21 dirt
execute in minecraft:overworld run setblock 409 72 -21 coarse_dirt
execute in minecraft:overworld run fill 409 73 -21 409 144 -21 air
execute in minecraft:overworld run fill 409 58 -20 409 69 -20 stone
execute in minecraft:overworld run fill 409 70 -20 409 71 -20 dirt
execute in minecraft:overworld run setblock 409 72 -20 coarse_dirt
execute in minecraft:overworld run fill 409 73 -20 409 144 -20 air
execute in minecraft:overworld run fill 409 58 -19 409 69 -19 stone
execute in minecraft:overworld run fill 409 70 -19 409 71 -19 dirt
execute in minecraft:overworld run setblock 409 72 -19 grass_block
execute in minecraft:overworld run fill 409 73 -19 409 144 -19 air
execute in minecraft:overworld run fill 409 58 -18 409 68 -18 stone
execute in minecraft:overworld run fill 409 69 -18 409 70 -18 dirt
execute in minecraft:overworld run setblock 409 71 -18 coarse_dirt
execute in minecraft:overworld run fill 409 72 -18 409 144 -18 air
execute in minecraft:overworld run fill 409 58 -17 409 68 -17 stone
execute in minecraft:overworld run fill 409 69 -17 409 70 -17 dirt
execute in minecraft:overworld run setblock 409 71 -17 coarse_dirt
execute in minecraft:overworld run fill 409 72 -17 409 144 -17 air
execute in minecraft:overworld run fill 409 58 -16 409 67 -16 stone
execute in minecraft:overworld run fill 409 68 -16 409 69 -16 dirt
execute in minecraft:overworld run setblock 409 70 -16 coarse_dirt
execute in minecraft:overworld run fill 409 71 -16 409 144 -16 air
execute in minecraft:overworld run fill 409 58 -15 409 67 -15 stone
execute in minecraft:overworld run fill 409 68 -15 409 69 -15 dirt
execute in minecraft:overworld run setblock 409 70 -15 grass_block
execute in minecraft:overworld run fill 409 71 -15 409 144 -15 air
execute in minecraft:overworld run fill 409 58 -14 409 66 -14 stone
execute in minecraft:overworld run fill 409 67 -14 409 68 -14 dirt
execute in minecraft:overworld run setblock 409 69 -14 grass_block
execute in minecraft:overworld run fill 409 70 -14 409 144 -14 air
execute in minecraft:overworld run fill 409 58 -13 409 65 -13 stone
execute in minecraft:overworld run fill 409 66 -13 409 67 -13 dirt
execute in minecraft:overworld run setblock 409 68 -13 coarse_dirt
execute in minecraft:overworld run fill 409 69 -13 409 144 -13 air
execute in minecraft:overworld run fill 409 58 -12 409 64 -12 stone
execute in minecraft:overworld run fill 409 65 -12 409 66 -12 dirt
execute in minecraft:overworld run setblock 409 67 -12 coarse_dirt
execute in minecraft:overworld run fill 409 68 -12 409 144 -12 air
execute in minecraft:overworld run fill 409 58 -11 409 64 -11 stone
execute in minecraft:overworld run fill 409 65 -11 409 66 -11 dirt
execute in minecraft:overworld run setblock 409 67 -11 grass_block
execute in minecraft:overworld run fill 409 68 -11 409 144 -11 air
execute in minecraft:overworld run fill 409 58 -10 409 64 -10 stone
execute in minecraft:overworld run fill 409 65 -10 409 66 -10 dirt
execute in minecraft:overworld run setblock 409 67 -10 grass_block
execute in minecraft:overworld run fill 409 68 -10 409 144 -10 air
execute in minecraft:overworld run fill 409 58 -9 409 64 -9 stone
execute in minecraft:overworld run fill 409 65 -9 409 66 -9 dirt
execute in minecraft:overworld run setblock 409 67 -9 coarse_dirt
execute in minecraft:overworld run fill 409 68 -9 409 144 -9 air
execute in minecraft:overworld run fill 409 58 -8 409 63 -8 stone
execute in minecraft:overworld run fill 409 64 -8 409 65 -8 dirt
execute in minecraft:overworld run setblock 409 66 -8 coarse_dirt
execute in minecraft:overworld run fill 409 67 -8 409 144 -8 air
execute in minecraft:overworld run fill 409 58 -7 409 63 -7 stone
execute in minecraft:overworld run fill 409 64 -7 409 65 -7 dirt
execute in minecraft:overworld run setblock 409 66 -7 coarse_dirt
execute in minecraft:overworld run fill 409 67 -7 409 144 -7 air
execute in minecraft:overworld run fill 409 58 -6 409 63 -6 stone
execute in minecraft:overworld run fill 409 64 -6 409 65 -6 dirt
execute in minecraft:overworld run setblock 409 66 -6 coarse_dirt
execute in minecraft:overworld run fill 409 67 -6 409 144 -6 air
execute in minecraft:overworld run fill 409 58 -5 409 63 -5 stone
execute in minecraft:overworld run fill 409 64 -5 409 65 -5 dirt
execute in minecraft:overworld run setblock 409 66 -5 coarse_dirt
execute in minecraft:overworld run fill 409 67 -5 409 144 -5 air
execute in minecraft:overworld run fill 409 58 -4 409 63 -4 stone
execute in minecraft:overworld run fill 409 64 -4 409 65 -4 dirt
execute in minecraft:overworld run setblock 409 66 -4 coarse_dirt
execute in minecraft:overworld run fill 409 67 -4 409 144 -4 air
execute in minecraft:overworld run fill 409 58 -3 409 63 -3 stone
execute in minecraft:overworld run fill 409 64 -3 409 65 -3 dirt
execute in minecraft:overworld run setblock 409 66 -3 coarse_dirt
execute in minecraft:overworld run fill 409 67 -3 409 144 -3 air
execute in minecraft:overworld run fill 409 58 -2 409 63 -2 stone
execute in minecraft:overworld run fill 409 64 -2 409 65 -2 dirt
execute in minecraft:overworld run setblock 409 66 -2 grass_block
execute in minecraft:overworld run fill 409 67 -2 409 144 -2 air
execute in minecraft:overworld run fill 409 58 -1 409 62 -1 stone
execute in minecraft:overworld run fill 409 63 -1 409 64 -1 dirt
execute in minecraft:overworld run setblock 409 65 -1 coarse_dirt
execute in minecraft:overworld run fill 409 66 -1 409 144 -1 air
execute in minecraft:overworld run fill 409 58 0 409 62 0 stone
execute in minecraft:overworld run fill 409 63 0 409 64 0 dirt
execute in minecraft:overworld run setblock 409 65 0 coarse_dirt
execute in minecraft:overworld run fill 409 66 0 409 144 0 air
execute in minecraft:overworld run fill 409 58 1 409 62 1 stone
execute in minecraft:overworld run fill 409 63 1 409 64 1 dirt
execute in minecraft:overworld run setblock 409 65 1 grass_block
execute in minecraft:overworld run fill 409 66 1 409 144 1 air
execute in minecraft:overworld run fill 409 58 2 409 62 2 stone
execute in minecraft:overworld run fill 409 63 2 409 64 2 dirt
execute in minecraft:overworld run setblock 409 65 2 coarse_dirt
execute in minecraft:overworld run fill 409 66 2 409 144 2 air
execute in minecraft:overworld run fill 409 58 3 409 63 3 stone
execute in minecraft:overworld run fill 409 64 3 409 65 3 dirt
execute in minecraft:overworld run setblock 409 66 3 coarse_dirt
execute in minecraft:overworld run fill 409 67 3 409 144 3 air
execute in minecraft:overworld run fill 409 58 4 409 63 4 stone
execute in minecraft:overworld run fill 409 64 4 409 65 4 dirt
execute in minecraft:overworld run setblock 409 66 4 coarse_dirt
execute in minecraft:overworld run fill 409 67 4 409 144 4 air
execute in minecraft:overworld run fill 409 58 5 409 63 5 stone
execute in minecraft:overworld run fill 409 64 5 409 65 5 dirt
execute in minecraft:overworld run setblock 409 66 5 coarse_dirt
execute in minecraft:overworld run fill 409 67 5 409 144 5 air
execute in minecraft:overworld run setblock 409 67 5 grass
execute in minecraft:overworld run fill 409 58 6 409 63 6 stone
execute in minecraft:overworld run fill 409 64 6 409 65 6 dirt
execute in minecraft:overworld run setblock 409 66 6 grass_block
execute in minecraft:overworld run fill 409 67 6 409 144 6 air
execute in minecraft:overworld run fill 409 58 7 409 63 7 stone
execute in minecraft:overworld run fill 409 64 7 409 65 7 dirt
execute in minecraft:overworld run setblock 409 66 7 coarse_dirt
execute in minecraft:overworld run fill 409 67 7 409 144 7 air
execute in minecraft:overworld run fill 409 58 8 409 64 8 stone
execute in minecraft:overworld run fill 409 65 8 409 66 8 dirt
execute in minecraft:overworld run setblock 409 67 8 coarse_dirt
execute in minecraft:overworld run fill 409 68 8 409 144 8 air
execute in minecraft:overworld run fill 409 58 9 409 64 9 stone
execute in minecraft:overworld run fill 409 65 9 409 66 9 dirt
execute in minecraft:overworld run setblock 409 67 9 coarse_dirt
execute in minecraft:overworld run fill 409 68 9 409 144 9 air
execute in minecraft:overworld run fill 409 58 10 409 64 10 stone
execute in minecraft:overworld run fill 409 65 10 409 66 10 dirt
execute in minecraft:overworld run setblock 409 67 10 coarse_dirt
execute in minecraft:overworld run fill 409 68 10 409 144 10 air
execute in minecraft:overworld run fill 409 58 11 409 64 11 stone
execute in minecraft:overworld run fill 409 65 11 409 66 11 dirt
execute in minecraft:overworld run setblock 409 67 11 grass_block
execute in minecraft:overworld run fill 409 68 11 409 144 11 air
execute in minecraft:overworld run fill 409 58 12 409 65 12 stone
execute in minecraft:overworld run fill 409 66 12 409 67 12 dirt
execute in minecraft:overworld run setblock 409 68 12 grass_block
execute in minecraft:overworld run fill 409 69 12 409 144 12 air
execute in minecraft:overworld run fill 409 58 13 409 65 13 stone
execute in minecraft:overworld run fill 409 66 13 409 67 13 dirt
execute in minecraft:overworld run setblock 409 68 13 grass_block
execute in minecraft:overworld run fill 409 69 13 409 144 13 air
execute in minecraft:overworld run setblock 409 69 13 grass
execute in minecraft:overworld run fill 409 58 14 409 65 14 stone
execute in minecraft:overworld run fill 409 66 14 409 67 14 dirt
execute in minecraft:overworld run setblock 409 68 14 coarse_dirt
execute in minecraft:overworld run fill 409 69 14 409 144 14 air
execute in minecraft:overworld run fill 409 58 15 409 66 15 stone
execute in minecraft:overworld run fill 409 67 15 409 68 15 dirt
execute in minecraft:overworld run setblock 409 69 15 coarse_dirt
execute in minecraft:overworld run fill 409 70 15 409 144 15 air
schedule function blade_gallery:random/battlefield/part_116 1t replace
