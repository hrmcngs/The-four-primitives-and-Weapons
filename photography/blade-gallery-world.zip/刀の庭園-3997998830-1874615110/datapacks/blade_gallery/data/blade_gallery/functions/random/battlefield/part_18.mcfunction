execute in minecraft:overworld run fill 347 58 34 347 66 34 stone
execute in minecraft:overworld run fill 347 67 34 347 68 34 dirt
execute in minecraft:overworld run setblock 347 69 34 grass_block
execute in minecraft:overworld run fill 347 70 34 347 144 34 air
execute in minecraft:overworld run fill 347 58 35 347 65 35 stone
execute in minecraft:overworld run fill 347 66 35 347 67 35 dirt
execute in minecraft:overworld run setblock 347 68 35 grass_block
execute in minecraft:overworld run fill 347 69 35 347 144 35 air
execute in minecraft:overworld run fill 347 58 36 347 65 36 stone
execute in minecraft:overworld run fill 347 66 36 347 67 36 dirt
execute in minecraft:overworld run setblock 347 68 36 coarse_dirt
execute in minecraft:overworld run fill 347 69 36 347 144 36 air
execute in minecraft:overworld run setblock 347 69 36 grass
execute in minecraft:overworld run fill 347 58 37 347 65 37 stone
execute in minecraft:overworld run fill 347 66 37 347 67 37 dirt
execute in minecraft:overworld run setblock 347 68 37 grass_block
execute in minecraft:overworld run fill 347 69 37 347 144 37 air
execute in minecraft:overworld run fill 347 58 38 347 65 38 stone
execute in minecraft:overworld run fill 347 66 38 347 67 38 dirt
execute in minecraft:overworld run setblock 347 68 38 coarse_dirt
execute in minecraft:overworld run fill 347 69 38 347 144 38 air
execute in minecraft:overworld run fill 347 58 39 347 65 39 stone
execute in minecraft:overworld run fill 347 66 39 347 67 39 dirt
execute in minecraft:overworld run setblock 347 68 39 grass_block
execute in minecraft:overworld run fill 347 69 39 347 144 39 air
execute in minecraft:overworld run fill 347 58 40 347 65 40 stone
execute in minecraft:overworld run fill 347 66 40 347 67 40 dirt
execute in minecraft:overworld run setblock 347 68 40 coarse_dirt
execute in minecraft:overworld run fill 347 69 40 347 144 40 air
execute in minecraft:overworld run fill 347 58 41 347 64 41 stone
execute in minecraft:overworld run fill 347 65 41 347 66 41 dirt
execute in minecraft:overworld run setblock 347 67 41 coarse_dirt
execute in minecraft:overworld run fill 347 68 41 347 144 41 air
execute in minecraft:overworld run fill 347 58 42 347 64 42 stone
execute in minecraft:overworld run fill 347 65 42 347 66 42 dirt
execute in minecraft:overworld run setblock 347 67 42 grass_block
execute in minecraft:overworld run fill 347 68 42 347 144 42 air
execute in minecraft:overworld run fill 347 58 43 347 63 43 stone
execute in minecraft:overworld run fill 347 64 43 347 65 43 dirt
execute in minecraft:overworld run setblock 347 66 43 grass_block
execute in minecraft:overworld run fill 347 67 43 347 144 43 air
execute in minecraft:overworld run fill 347 58 44 347 63 44 stone
execute in minecraft:overworld run fill 347 64 44 347 65 44 dirt
execute in minecraft:overworld run setblock 347 66 44 grass_block
execute in minecraft:overworld run fill 347 67 44 347 144 44 air
execute in minecraft:overworld run fill 347 58 45 347 62 45 stone
execute in minecraft:overworld run fill 347 63 45 347 64 45 dirt
execute in minecraft:overworld run setblock 347 65 45 coarse_dirt
execute in minecraft:overworld run fill 347 66 45 347 144 45 air
execute in minecraft:overworld run fill 347 58 46 347 62 46 stone
execute in minecraft:overworld run fill 347 63 46 347 64 46 dirt
execute in minecraft:overworld run setblock 347 65 46 grass_block
execute in minecraft:overworld run fill 347 66 46 347 144 46 air
execute in minecraft:overworld run fill 347 58 47 347 61 47 stone
execute in minecraft:overworld run fill 347 62 47 347 63 47 dirt
execute in minecraft:overworld run setblock 347 64 47 grass_block
execute in minecraft:overworld run fill 347 65 47 347 144 47 air
execute in minecraft:overworld run fill 348 58 -48 348 61 -48 stone
execute in minecraft:overworld run fill 348 62 -48 348 63 -48 dirt
execute in minecraft:overworld run setblock 348 64 -48 grass_block
execute in minecraft:overworld run fill 348 65 -48 348 144 -48 air
execute in minecraft:overworld run fill 348 58 -47 348 63 -47 stone
execute in minecraft:overworld run fill 348 64 -47 348 65 -47 dirt
execute in minecraft:overworld run setblock 348 66 -47 coarse_dirt
execute in minecraft:overworld run fill 348 67 -47 348 144 -47 air
execute in minecraft:overworld run fill 348 58 -46 348 65 -46 stone
execute in minecraft:overworld run fill 348 66 -46 348 67 -46 dirt
execute in minecraft:overworld run setblock 348 68 -46 grass_block
execute in minecraft:overworld run fill 348 69 -46 348 144 -46 air
execute in minecraft:overworld run fill 348 58 -45 348 67 -45 stone
execute in minecraft:overworld run fill 348 68 -45 348 69 -45 dirt
execute in minecraft:overworld run setblock 348 70 -45 coarse_dirt
execute in minecraft:overworld run fill 348 71 -45 348 144 -45 air
execute in minecraft:overworld run fill 348 58 -44 348 68 -44 stone
execute in minecraft:overworld run fill 348 69 -44 348 70 -44 dirt
execute in minecraft:overworld run setblock 348 71 -44 grass_block
execute in minecraft:overworld run fill 348 72 -44 348 144 -44 air
execute in minecraft:overworld run fill 348 58 -43 348 70 -43 stone
execute in minecraft:overworld run fill 348 71 -43 348 72 -43 dirt
execute in minecraft:overworld run setblock 348 73 -43 coarse_dirt
execute in minecraft:overworld run fill 348 74 -43 348 144 -43 air
execute in minecraft:overworld run fill 348 58 -42 348 71 -42 stone
execute in minecraft:overworld run fill 348 72 -42 348 73 -42 dirt
execute in minecraft:overworld run setblock 348 74 -42 coarse_dirt
execute in minecraft:overworld run fill 348 75 -42 348 144 -42 air
execute in minecraft:overworld run fill 348 58 -41 348 73 -41 stone
execute in minecraft:overworld run fill 348 74 -41 348 75 -41 dirt
execute in minecraft:overworld run setblock 348 76 -41 grass_block
execute in minecraft:overworld run fill 348 77 -41 348 144 -41 air
execute in minecraft:overworld run fill 348 58 -40 348 74 -40 stone
execute in minecraft:overworld run fill 348 75 -40 348 76 -40 dirt
execute in minecraft:overworld run setblock 348 77 -40 grass_block
execute in minecraft:overworld run fill 348 78 -40 348 144 -40 air
execute in minecraft:overworld run fill 348 58 -39 348 75 -39 stone
execute in minecraft:overworld run fill 348 76 -39 348 77 -39 dirt
execute in minecraft:overworld run setblock 348 78 -39 coarse_dirt
execute in minecraft:overworld run fill 348 79 -39 348 144 -39 air
execute in minecraft:overworld run fill 348 58 -38 348 76 -38 stone
execute in minecraft:overworld run fill 348 77 -38 348 78 -38 dirt
execute in minecraft:overworld run setblock 348 79 -38 grass_block
execute in minecraft:overworld run fill 348 80 -38 348 144 -38 air
execute in minecraft:overworld run fill 348 58 -37 348 76 -37 stone
execute in minecraft:overworld run fill 348 77 -37 348 78 -37 dirt
execute in minecraft:overworld run setblock 348 79 -37 coarse_dirt
execute in minecraft:overworld run fill 348 80 -37 348 144 -37 air
execute in minecraft:overworld run fill 348 58 -36 348 75 -36 stone
execute in minecraft:overworld run fill 348 76 -36 348 77 -36 dirt
execute in minecraft:overworld run setblock 348 78 -36 coarse_dirt
execute in minecraft:overworld run fill 348 79 -36 348 144 -36 air
execute in minecraft:overworld run setblock 348 79 -36 grass
execute in minecraft:overworld run fill 348 58 -35 348 75 -35 stone
execute in minecraft:overworld run fill 348 76 -35 348 77 -35 dirt
execute in minecraft:overworld run setblock 348 78 -35 grass_block
execute in minecraft:overworld run fill 348 79 -35 348 144 -35 air
execute in minecraft:overworld run fill 348 58 -34 348 75 -34 stone
execute in minecraft:overworld run fill 348 76 -34 348 77 -34 dirt
execute in minecraft:overworld run setblock 348 78 -34 grass_block
execute in minecraft:overworld run fill 348 79 -34 348 144 -34 air
execute in minecraft:overworld run fill 348 58 -33 348 75 -33 stone
execute in minecraft:overworld run fill 348 76 -33 348 77 -33 dirt
execute in minecraft:overworld run setblock 348 78 -33 coarse_dirt
execute in minecraft:overworld run fill 348 79 -33 348 144 -33 air
execute in minecraft:overworld run fill 348 58 -32 348 74 -32 stone
execute in minecraft:overworld run fill 348 75 -32 348 76 -32 dirt
execute in minecraft:overworld run setblock 348 77 -32 coarse_dirt
execute in minecraft:overworld run fill 348 78 -32 348 144 -32 air
execute in minecraft:overworld run fill 348 58 -31 348 74 -31 stone
execute in minecraft:overworld run fill 348 75 -31 348 76 -31 dirt
execute in minecraft:overworld run setblock 348 77 -31 coarse_dirt
execute in minecraft:overworld run fill 348 78 -31 348 144 -31 air
execute in minecraft:overworld run fill 348 58 -30 348 74 -30 stone
execute in minecraft:overworld run fill 348 75 -30 348 76 -30 dirt
execute in minecraft:overworld run setblock 348 77 -30 grass_block
execute in minecraft:overworld run fill 348 78 -30 348 144 -30 air
execute in minecraft:overworld run fill 348 58 -29 348 74 -29 stone
execute in minecraft:overworld run fill 348 75 -29 348 76 -29 dirt
execute in minecraft:overworld run setblock 348 77 -29 coarse_dirt
execute in minecraft:overworld run fill 348 78 -29 348 144 -29 air
execute in minecraft:overworld run fill 348 58 -28 348 73 -28 stone
execute in minecraft:overworld run fill 348 74 -28 348 75 -28 dirt
execute in minecraft:overworld run setblock 348 76 -28 coarse_dirt
execute in minecraft:overworld run fill 348 77 -28 348 144 -28 air
execute in minecraft:overworld run fill 348 58 -27 348 73 -27 stone
execute in minecraft:overworld run fill 348 74 -27 348 75 -27 dirt
execute in minecraft:overworld run setblock 348 76 -27 grass_block
execute in minecraft:overworld run fill 348 77 -27 348 144 -27 air
execute in minecraft:overworld run fill 348 58 -26 348 73 -26 stone
execute in minecraft:overworld run fill 348 74 -26 348 75 -26 dirt
execute in minecraft:overworld run setblock 348 76 -26 coarse_dirt
execute in minecraft:overworld run fill 348 77 -26 348 144 -26 air
execute in minecraft:overworld run fill 348 58 -25 348 72 -25 stone
execute in minecraft:overworld run fill 348 73 -25 348 74 -25 dirt
execute in minecraft:overworld run setblock 348 75 -25 grass_block
execute in minecraft:overworld run fill 348 76 -25 348 144 -25 air
execute in minecraft:overworld run fill 348 58 -24 348 72 -24 stone
execute in minecraft:overworld run fill 348 73 -24 348 74 -24 dirt
execute in minecraft:overworld run setblock 348 75 -24 grass_block
execute in minecraft:overworld run fill 348 76 -24 348 144 -24 air
execute in minecraft:overworld run fill 348 58 -23 348 72 -23 stone
execute in minecraft:overworld run fill 348 73 -23 348 74 -23 dirt
execute in minecraft:overworld run setblock 348 75 -23 coarse_dirt
execute in minecraft:overworld run fill 348 76 -23 348 144 -23 air
execute in minecraft:overworld run fill 348 58 -22 348 71 -22 stone
execute in minecraft:overworld run fill 348 72 -22 348 73 -22 dirt
execute in minecraft:overworld run setblock 348 74 -22 coarse_dirt
execute in minecraft:overworld run fill 348 75 -22 348 144 -22 air
execute in minecraft:overworld run setblock 348 75 -22 grass
execute in minecraft:overworld run fill 348 58 -21 348 71 -21 stone
execute in minecraft:overworld run fill 348 72 -21 348 73 -21 dirt
execute in minecraft:overworld run setblock 348 74 -21 coarse_dirt
execute in minecraft:overworld run fill 348 75 -21 348 144 -21 air
execute in minecraft:overworld run setblock 348 75 -21 grass
execute in minecraft:overworld run fill 348 58 -20 348 71 -20 stone
execute in minecraft:overworld run fill 348 72 -20 348 73 -20 dirt
execute in minecraft:overworld run setblock 348 74 -20 coarse_dirt
execute in minecraft:overworld run fill 348 75 -20 348 144 -20 air
execute in minecraft:overworld run fill 348 58 -19 348 70 -19 stone
execute in minecraft:overworld run fill 348 71 -19 348 72 -19 dirt
execute in minecraft:overworld run setblock 348 73 -19 coarse_dirt
execute in minecraft:overworld run fill 348 74 -19 348 144 -19 air
execute in minecraft:overworld run fill 348 58 -18 348 70 -18 stone
execute in minecraft:overworld run fill 348 71 -18 348 72 -18 dirt
execute in minecraft:overworld run setblock 348 73 -18 grass_block
execute in minecraft:overworld run fill 348 74 -18 348 144 -18 air
execute in minecraft:overworld run fill 348 58 -17 348 70 -17 stone
execute in minecraft:overworld run fill 348 71 -17 348 72 -17 dirt
execute in minecraft:overworld run setblock 348 73 -17 coarse_dirt
execute in minecraft:overworld run fill 348 74 -17 348 144 -17 air
execute in minecraft:overworld run fill 348 58 -16 348 69 -16 stone
execute in minecraft:overworld run fill 348 70 -16 348 71 -16 dirt
execute in minecraft:overworld run setblock 348 72 -16 coarse_dirt
execute in minecraft:overworld run fill 348 73 -16 348 144 -16 air
execute in minecraft:overworld run fill 348 58 -15 348 69 -15 stone
execute in minecraft:overworld run fill 348 70 -15 348 71 -15 dirt
execute in minecraft:overworld run setblock 348 72 -15 coarse_dirt
execute in minecraft:overworld run fill 348 73 -15 348 144 -15 air
execute in minecraft:overworld run fill 348 58 -14 348 68 -14 stone
execute in minecraft:overworld run fill 348 69 -14 348 70 -14 dirt
execute in minecraft:overworld run setblock 348 71 -14 grass_block
execute in minecraft:overworld run fill 348 72 -14 348 144 -14 air
execute in minecraft:overworld run fill 348 58 -13 348 68 -13 stone
execute in minecraft:overworld run fill 348 69 -13 348 70 -13 dirt
execute in minecraft:overworld run setblock 348 71 -13 grass_block
execute in minecraft:overworld run fill 348 72 -13 348 144 -13 air
execute in minecraft:overworld run fill 348 58 -12 348 67 -12 stone
execute in minecraft:overworld run fill 348 68 -12 348 69 -12 dirt
execute in minecraft:overworld run setblock 348 70 -12 coarse_dirt
execute in minecraft:overworld run fill 348 71 -12 348 144 -12 air
execute in minecraft:overworld run fill 348 58 -11 348 67 -11 stone
execute in minecraft:overworld run fill 348 68 -11 348 69 -11 dirt
execute in minecraft:overworld run setblock 348 70 -11 coarse_dirt
execute in minecraft:overworld run fill 348 71 -11 348 144 -11 air
execute in minecraft:overworld run fill 348 58 -10 348 67 -10 stone
execute in minecraft:overworld run fill 348 68 -10 348 69 -10 dirt
execute in minecraft:overworld run setblock 348 70 -10 grass_block
execute in minecraft:overworld run fill 348 71 -10 348 144 -10 air
execute in minecraft:overworld run fill 348 58 -9 348 67 -9 stone
execute in minecraft:overworld run fill 348 68 -9 348 69 -9 dirt
execute in minecraft:overworld run setblock 348 70 -9 coarse_dirt
execute in minecraft:overworld run fill 348 71 -9 348 144 -9 air
execute in minecraft:overworld run fill 348 58 -8 348 67 -8 stone
execute in minecraft:overworld run fill 348 68 -8 348 69 -8 dirt
execute in minecraft:overworld run setblock 348 70 -8 coarse_dirt
execute in minecraft:overworld run fill 348 71 -8 348 144 -8 air
execute in minecraft:overworld run setblock 348 71 -8 mossy_cobblestone
execute in minecraft:overworld run fill 348 58 -7 348 67 -7 stone
execute in minecraft:overworld run fill 348 68 -7 348 69 -7 dirt
execute in minecraft:overworld run setblock 348 70 -7 grass_block
execute in minecraft:overworld run fill 348 71 -7 348 144 -7 air
execute in minecraft:overworld run fill 348 58 -6 348 67 -6 stone
execute in minecraft:overworld run fill 348 68 -6 348 69 -6 dirt
execute in minecraft:overworld run setblock 348 70 -6 coarse_dirt
execute in minecraft:overworld run fill 348 71 -6 348 144 -6 air
execute in minecraft:overworld run fill 348 58 -5 348 67 -5 stone
execute in minecraft:overworld run fill 348 68 -5 348 69 -5 dirt
execute in minecraft:overworld run setblock 348 70 -5 coarse_dirt
execute in minecraft:overworld run fill 348 71 -5 348 144 -5 air
execute in minecraft:overworld run fill 348 58 -4 348 67 -4 stone
execute in minecraft:overworld run fill 348 68 -4 348 69 -4 dirt
execute in minecraft:overworld run setblock 348 70 -4 grass_block
execute in minecraft:overworld run fill 348 71 -4 348 144 -4 air
execute in minecraft:overworld run fill 348 58 -3 348 67 -3 stone
execute in minecraft:overworld run fill 348 68 -3 348 69 -3 dirt
execute in minecraft:overworld run setblock 348 70 -3 coarse_dirt
execute in minecraft:overworld run fill 348 71 -3 348 144 -3 air
execute in minecraft:overworld run fill 348 58 -2 348 67 -2 stone
execute in minecraft:overworld run fill 348 68 -2 348 69 -2 dirt
execute in minecraft:overworld run setblock 348 70 -2 coarse_dirt
execute in minecraft:overworld run fill 348 71 -2 348 144 -2 air
execute in minecraft:overworld run fill 348 58 -1 348 67 -1 stone
execute in minecraft:overworld run fill 348 68 -1 348 69 -1 dirt
execute in minecraft:overworld run setblock 348 70 -1 coarse_dirt
execute in minecraft:overworld run fill 348 71 -1 348 144 -1 air
execute in minecraft:overworld run fill 348 58 0 348 67 0 stone
execute in minecraft:overworld run fill 348 68 0 348 69 0 dirt
execute in minecraft:overworld run setblock 348 70 0 grass_block
schedule function blade_gallery:random/battlefield/part_19 1t replace
