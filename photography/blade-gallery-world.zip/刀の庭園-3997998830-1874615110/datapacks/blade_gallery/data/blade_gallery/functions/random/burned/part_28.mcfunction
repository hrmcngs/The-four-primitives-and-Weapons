execute in minecraft:overworld run fill 226 70 -17 226 144 -17 air
execute in minecraft:overworld run fill 226 58 -16 226 66 -16 stone
execute in minecraft:overworld run fill 226 67 -16 226 68 -16 dirt
execute in minecraft:overworld run setblock 226 69 -16 coarse_dirt
execute in minecraft:overworld run fill 226 70 -16 226 144 -16 air
execute in minecraft:overworld run fill 226 58 -15 226 65 -15 stone
execute in minecraft:overworld run fill 226 66 -15 226 67 -15 dirt
execute in minecraft:overworld run setblock 226 68 -15 grass_block
execute in minecraft:overworld run fill 226 69 -15 226 144 -15 air
execute in minecraft:overworld run fill 226 58 -14 226 65 -14 stone
execute in minecraft:overworld run fill 226 66 -14 226 67 -14 dirt
execute in minecraft:overworld run setblock 226 68 -14 grass_block
execute in minecraft:overworld run fill 226 69 -14 226 144 -14 air
execute in minecraft:overworld run setblock 226 69 -14 grass
execute in minecraft:overworld run fill 226 58 -13 226 64 -13 stone
execute in minecraft:overworld run fill 226 65 -13 226 66 -13 dirt
execute in minecraft:overworld run setblock 226 67 -13 coarse_dirt
execute in minecraft:overworld run fill 226 68 -13 226 144 -13 air
execute in minecraft:overworld run fill 226 58 -12 226 64 -12 stone
execute in minecraft:overworld run fill 226 65 -12 226 66 -12 dirt
execute in minecraft:overworld run setblock 226 67 -12 coarse_dirt
execute in minecraft:overworld run fill 226 68 -12 226 144 -12 air
execute in minecraft:overworld run fill 226 58 -11 226 64 -11 stone
execute in minecraft:overworld run fill 226 65 -11 226 66 -11 dirt
execute in minecraft:overworld run setblock 226 67 -11 coarse_dirt
execute in minecraft:overworld run fill 226 68 -11 226 144 -11 air
execute in minecraft:overworld run fill 226 58 -10 226 64 -10 stone
execute in minecraft:overworld run fill 226 65 -10 226 66 -10 dirt
execute in minecraft:overworld run setblock 226 67 -10 coarse_dirt
execute in minecraft:overworld run fill 226 68 -10 226 144 -10 air
execute in minecraft:overworld run fill 226 58 -9 226 64 -9 stone
execute in minecraft:overworld run fill 226 65 -9 226 66 -9 dirt
execute in minecraft:overworld run setblock 226 67 -9 coarse_dirt
execute in minecraft:overworld run fill 226 68 -9 226 144 -9 air
execute in minecraft:overworld run fill 226 58 -8 226 65 -8 stone
execute in minecraft:overworld run fill 226 66 -8 226 67 -8 dirt
execute in minecraft:overworld run setblock 226 68 -8 coarse_dirt
execute in minecraft:overworld run fill 226 69 -8 226 144 -8 air
execute in minecraft:overworld run setblock 226 69 -8 grass
execute in minecraft:overworld run fill 226 58 -7 226 65 -7 stone
execute in minecraft:overworld run fill 226 66 -7 226 67 -7 dirt
execute in minecraft:overworld run setblock 226 68 -7 coarse_dirt
execute in minecraft:overworld run fill 226 69 -7 226 144 -7 air
execute in minecraft:overworld run fill 226 58 -6 226 66 -6 stone
execute in minecraft:overworld run fill 226 67 -6 226 68 -6 dirt
execute in minecraft:overworld run setblock 226 69 -6 grass_block
execute in minecraft:overworld run fill 226 70 -6 226 144 -6 air
execute in minecraft:overworld run fill 226 58 -5 226 66 -5 stone
execute in minecraft:overworld run fill 226 67 -5 226 68 -5 dirt
execute in minecraft:overworld run setblock 226 69 -5 coarse_dirt
execute in minecraft:overworld run fill 226 70 -5 226 144 -5 air
execute in minecraft:overworld run fill 226 58 -4 226 67 -4 stone
execute in minecraft:overworld run fill 226 68 -4 226 69 -4 dirt
execute in minecraft:overworld run setblock 226 70 -4 coarse_dirt
execute in minecraft:overworld run fill 226 71 -4 226 144 -4 air
execute in minecraft:overworld run fill 226 58 -3 226 67 -3 stone
execute in minecraft:overworld run fill 226 68 -3 226 69 -3 dirt
execute in minecraft:overworld run setblock 226 70 -3 coarse_dirt
execute in minecraft:overworld run fill 226 71 -3 226 144 -3 air
execute in minecraft:overworld run fill 226 58 -2 226 67 -2 stone
execute in minecraft:overworld run fill 226 68 -2 226 69 -2 dirt
execute in minecraft:overworld run setblock 226 70 -2 grass_block
execute in minecraft:overworld run fill 226 71 -2 226 144 -2 air
execute in minecraft:overworld run fill 226 58 -1 226 68 -1 stone
execute in minecraft:overworld run fill 226 69 -1 226 70 -1 dirt
execute in minecraft:overworld run setblock 226 71 -1 coarse_dirt
execute in minecraft:overworld run fill 226 72 -1 226 144 -1 air
execute in minecraft:overworld run setblock 226 72 -1 grass
execute in minecraft:overworld run fill 226 58 0 226 68 0 stone
execute in minecraft:overworld run fill 226 69 0 226 70 0 dirt
execute in minecraft:overworld run setblock 226 71 0 grass_block
execute in minecraft:overworld run fill 226 72 0 226 144 0 air
execute in minecraft:overworld run fill 226 58 1 226 68 1 stone
execute in minecraft:overworld run fill 226 69 1 226 70 1 dirt
execute in minecraft:overworld run setblock 226 71 1 coarse_dirt
execute in minecraft:overworld run fill 226 72 1 226 144 1 air
execute in minecraft:overworld run fill 226 58 2 226 67 2 stone
execute in minecraft:overworld run fill 226 68 2 226 69 2 dirt
execute in minecraft:overworld run setblock 226 70 2 coarse_dirt
execute in minecraft:overworld run fill 226 71 2 226 144 2 air
execute in minecraft:overworld run fill 226 58 3 226 67 3 stone
execute in minecraft:overworld run fill 226 68 3 226 69 3 dirt
execute in minecraft:overworld run setblock 226 70 3 coarse_dirt
execute in minecraft:overworld run fill 226 71 3 226 144 3 air
execute in minecraft:overworld run fill 226 58 4 226 67 4 stone
execute in minecraft:overworld run fill 226 68 4 226 69 4 dirt
execute in minecraft:overworld run setblock 226 70 4 coarse_dirt
execute in minecraft:overworld run fill 226 71 4 226 144 4 air
execute in minecraft:overworld run fill 226 58 5 226 67 5 stone
execute in minecraft:overworld run fill 226 68 5 226 69 5 dirt
execute in minecraft:overworld run setblock 226 70 5 grass_block
execute in minecraft:overworld run fill 226 71 5 226 144 5 air
execute in minecraft:overworld run setblock 226 71 5 grass
execute in minecraft:overworld run fill 226 58 6 226 66 6 stone
execute in minecraft:overworld run fill 226 67 6 226 68 6 dirt
execute in minecraft:overworld run setblock 226 69 6 grass_block
execute in minecraft:overworld run fill 226 70 6 226 144 6 air
execute in minecraft:overworld run setblock 226 70 6 grass
execute in minecraft:overworld run fill 226 58 7 226 66 7 stone
execute in minecraft:overworld run fill 226 67 7 226 68 7 dirt
execute in minecraft:overworld run setblock 226 69 7 coarse_dirt
execute in minecraft:overworld run fill 226 70 7 226 144 7 air
execute in minecraft:overworld run setblock 226 70 7 grass
execute in minecraft:overworld run fill 226 58 8 226 66 8 stone
execute in minecraft:overworld run fill 226 67 8 226 68 8 dirt
execute in minecraft:overworld run setblock 226 69 8 coarse_dirt
execute in minecraft:overworld run fill 226 70 8 226 144 8 air
execute in minecraft:overworld run fill 226 58 9 226 66 9 stone
execute in minecraft:overworld run fill 226 67 9 226 68 9 dirt
execute in minecraft:overworld run setblock 226 69 9 coarse_dirt
execute in minecraft:overworld run fill 226 70 9 226 144 9 air
execute in minecraft:overworld run fill 226 58 10 226 67 10 stone
execute in minecraft:overworld run fill 226 68 10 226 69 10 dirt
execute in minecraft:overworld run setblock 226 70 10 coarse_dirt
execute in minecraft:overworld run fill 226 71 10 226 144 10 air
execute in minecraft:overworld run fill 226 58 11 226 67 11 stone
execute in minecraft:overworld run fill 226 68 11 226 69 11 dirt
execute in minecraft:overworld run setblock 226 70 11 coarse_dirt
execute in minecraft:overworld run fill 226 71 11 226 144 11 air
execute in minecraft:overworld run fill 226 58 12 226 67 12 stone
execute in minecraft:overworld run fill 226 68 12 226 69 12 dirt
execute in minecraft:overworld run setblock 226 70 12 coarse_dirt
execute in minecraft:overworld run fill 226 71 12 226 144 12 air
execute in minecraft:overworld run fill 226 58 13 226 68 13 stone
execute in minecraft:overworld run fill 226 69 13 226 70 13 dirt
execute in minecraft:overworld run setblock 226 71 13 coarse_dirt
execute in minecraft:overworld run fill 226 72 13 226 144 13 air
execute in minecraft:overworld run fill 226 58 14 226 68 14 stone
execute in minecraft:overworld run fill 226 69 14 226 70 14 dirt
execute in minecraft:overworld run setblock 226 71 14 coarse_dirt
execute in minecraft:overworld run fill 226 72 14 226 144 14 air
execute in minecraft:overworld run fill 226 58 15 226 69 15 stone
execute in minecraft:overworld run fill 226 70 15 226 71 15 dirt
execute in minecraft:overworld run setblock 226 72 15 grass_block
execute in minecraft:overworld run fill 226 73 15 226 144 15 air
execute in minecraft:overworld run setblock 226 73 15 grass
execute in minecraft:overworld run fill 226 58 16 226 69 16 stone
execute in minecraft:overworld run fill 226 70 16 226 71 16 dirt
execute in minecraft:overworld run setblock 226 72 16 coarse_dirt
execute in minecraft:overworld run fill 226 73 16 226 144 16 air
execute in minecraft:overworld run fill 226 58 17 226 69 17 stone
execute in minecraft:overworld run fill 226 70 17 226 71 17 dirt
execute in minecraft:overworld run setblock 226 72 17 grass_block
execute in minecraft:overworld run fill 226 73 17 226 144 17 air
execute in minecraft:overworld run fill 226 58 18 226 70 18 stone
execute in minecraft:overworld run fill 226 71 18 226 72 18 dirt
execute in minecraft:overworld run setblock 226 73 18 coarse_dirt
execute in minecraft:overworld run fill 226 74 18 226 144 18 air
execute in minecraft:overworld run fill 226 58 19 226 70 19 stone
execute in minecraft:overworld run fill 226 71 19 226 72 19 dirt
execute in minecraft:overworld run setblock 226 73 19 coarse_dirt
execute in minecraft:overworld run fill 226 74 19 226 144 19 air
execute in minecraft:overworld run fill 226 58 20 226 70 20 stone
execute in minecraft:overworld run fill 226 71 20 226 72 20 dirt
execute in minecraft:overworld run setblock 226 73 20 coarse_dirt
execute in minecraft:overworld run fill 226 74 20 226 144 20 air
execute in minecraft:overworld run fill 226 58 21 226 70 21 stone
execute in minecraft:overworld run fill 226 71 21 226 72 21 dirt
execute in minecraft:overworld run setblock 226 73 21 coarse_dirt
execute in minecraft:overworld run fill 226 74 21 226 144 21 air
execute in minecraft:overworld run fill 226 58 22 226 70 22 stone
execute in minecraft:overworld run fill 226 71 22 226 72 22 dirt
execute in minecraft:overworld run setblock 226 73 22 grass_block
execute in minecraft:overworld run fill 226 74 22 226 144 22 air
execute in minecraft:overworld run setblock 226 74 22 grass
execute in minecraft:overworld run fill 226 58 23 226 70 23 stone
execute in minecraft:overworld run fill 226 71 23 226 72 23 dirt
execute in minecraft:overworld run setblock 226 73 23 coarse_dirt
execute in minecraft:overworld run fill 226 74 23 226 144 23 air
execute in minecraft:overworld run fill 226 58 24 226 70 24 stone
execute in minecraft:overworld run fill 226 71 24 226 72 24 dirt
execute in minecraft:overworld run setblock 226 73 24 coarse_dirt
execute in minecraft:overworld run fill 226 74 24 226 144 24 air
execute in minecraft:overworld run fill 226 58 25 226 70 25 stone
execute in minecraft:overworld run fill 226 71 25 226 72 25 dirt
execute in minecraft:overworld run setblock 226 73 25 grass_block
execute in minecraft:overworld run fill 226 74 25 226 144 25 air
execute in minecraft:overworld run fill 226 58 26 226 70 26 stone
execute in minecraft:overworld run fill 226 71 26 226 72 26 dirt
execute in minecraft:overworld run setblock 226 73 26 coarse_dirt
execute in minecraft:overworld run fill 226 74 26 226 144 26 air
execute in minecraft:overworld run setblock 226 74 26 grass
execute in minecraft:overworld run fill 226 58 27 226 70 27 stone
execute in minecraft:overworld run fill 226 71 27 226 72 27 dirt
execute in minecraft:overworld run setblock 226 73 27 coarse_dirt
execute in minecraft:overworld run fill 226 74 27 226 144 27 air
execute in minecraft:overworld run fill 226 58 28 226 70 28 stone
execute in minecraft:overworld run fill 226 71 28 226 72 28 dirt
execute in minecraft:overworld run setblock 226 73 28 grass_block
execute in minecraft:overworld run fill 226 74 28 226 144 28 air
execute in minecraft:overworld run fill 226 58 29 226 70 29 stone
execute in minecraft:overworld run fill 226 71 29 226 72 29 dirt
execute in minecraft:overworld run setblock 226 73 29 grass_block
execute in minecraft:overworld run fill 226 74 29 226 144 29 air
execute in minecraft:overworld run fill 226 58 30 226 70 30 stone
execute in minecraft:overworld run fill 226 71 30 226 72 30 dirt
execute in minecraft:overworld run setblock 226 73 30 coarse_dirt
execute in minecraft:overworld run fill 226 74 30 226 144 30 air
execute in minecraft:overworld run fill 226 58 31 226 70 31 stone
execute in minecraft:overworld run fill 226 71 31 226 72 31 dirt
execute in minecraft:overworld run setblock 226 73 31 coarse_dirt
execute in minecraft:overworld run fill 226 74 31 226 144 31 air
execute in minecraft:overworld run setblock 226 74 31 grass
execute in minecraft:overworld run fill 226 58 32 226 70 32 stone
execute in minecraft:overworld run fill 226 71 32 226 72 32 dirt
execute in minecraft:overworld run setblock 226 73 32 grass_block
execute in minecraft:overworld run fill 226 74 32 226 144 32 air
execute in minecraft:overworld run fill 226 58 33 226 70 33 stone
execute in minecraft:overworld run fill 226 71 33 226 72 33 dirt
execute in minecraft:overworld run setblock 226 73 33 coarse_dirt
execute in minecraft:overworld run fill 226 74 33 226 144 33 air
execute in minecraft:overworld run fill 226 58 34 226 69 34 stone
execute in minecraft:overworld run fill 226 70 34 226 71 34 dirt
execute in minecraft:overworld run setblock 226 72 34 coarse_dirt
execute in minecraft:overworld run fill 226 73 34 226 144 34 air
execute in minecraft:overworld run fill 226 58 35 226 69 35 stone
execute in minecraft:overworld run fill 226 70 35 226 71 35 dirt
execute in minecraft:overworld run setblock 226 72 35 grass_block
execute in minecraft:overworld run fill 226 73 35 226 144 35 air
execute in minecraft:overworld run fill 226 58 36 226 69 36 stone
execute in minecraft:overworld run fill 226 70 36 226 71 36 dirt
execute in minecraft:overworld run setblock 226 72 36 coarse_dirt
execute in minecraft:overworld run fill 226 73 36 226 144 36 air
execute in minecraft:overworld run fill 226 58 37 226 68 37 stone
execute in minecraft:overworld run fill 226 69 37 226 70 37 dirt
execute in minecraft:overworld run setblock 226 71 37 coarse_dirt
execute in minecraft:overworld run fill 226 72 37 226 144 37 air
execute in minecraft:overworld run setblock 226 72 37 mossy_cobblestone
execute in minecraft:overworld run fill 226 58 38 226 68 38 stone
execute in minecraft:overworld run fill 226 69 38 226 70 38 dirt
execute in minecraft:overworld run setblock 226 71 38 coarse_dirt
execute in minecraft:overworld run fill 226 72 38 226 144 38 air
execute in minecraft:overworld run fill 226 58 39 226 67 39 stone
execute in minecraft:overworld run fill 226 68 39 226 69 39 dirt
execute in minecraft:overworld run setblock 226 70 39 grass_block
execute in minecraft:overworld run fill 226 71 39 226 144 39 air
execute in minecraft:overworld run fill 226 58 40 226 66 40 stone
execute in minecraft:overworld run fill 226 67 40 226 68 40 dirt
execute in minecraft:overworld run setblock 226 69 40 coarse_dirt
execute in minecraft:overworld run fill 226 70 40 226 144 40 air
execute in minecraft:overworld run fill 226 58 41 226 65 41 stone
execute in minecraft:overworld run fill 226 66 41 226 67 41 dirt
execute in minecraft:overworld run setblock 226 68 41 coarse_dirt
execute in minecraft:overworld run fill 226 69 41 226 144 41 air
execute in minecraft:overworld run fill 226 58 42 226 64 42 stone
execute in minecraft:overworld run fill 226 65 42 226 66 42 dirt
execute in minecraft:overworld run setblock 226 67 42 coarse_dirt
execute in minecraft:overworld run fill 226 68 42 226 144 42 air
execute in minecraft:overworld run fill 226 58 43 226 63 43 stone
execute in minecraft:overworld run fill 226 64 43 226 65 43 dirt
execute in minecraft:overworld run setblock 226 66 43 grass_block
execute in minecraft:overworld run fill 226 67 43 226 144 43 air
execute in minecraft:overworld run fill 226 58 44 226 62 44 stone
execute in minecraft:overworld run fill 226 63 44 226 64 44 dirt
execute in minecraft:overworld run setblock 226 65 44 grass_block
execute in minecraft:overworld run fill 226 66 44 226 144 44 air
schedule function blade_gallery:random/burned/part_29 1t replace
