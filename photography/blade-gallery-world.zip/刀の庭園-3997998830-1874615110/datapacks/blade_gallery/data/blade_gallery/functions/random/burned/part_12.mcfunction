execute in minecraft:overworld run fill 215 64 44 215 65 44 dirt
execute in minecraft:overworld run setblock 215 66 44 coarse_dirt
execute in minecraft:overworld run fill 215 67 44 215 144 44 air
execute in minecraft:overworld run fill 215 58 45 215 62 45 stone
execute in minecraft:overworld run fill 215 63 45 215 64 45 dirt
execute in minecraft:overworld run setblock 215 65 45 coarse_dirt
execute in minecraft:overworld run fill 215 66 45 215 144 45 air
execute in minecraft:overworld run fill 215 58 46 215 62 46 stone
execute in minecraft:overworld run fill 215 63 46 215 64 46 dirt
execute in minecraft:overworld run setblock 215 65 46 coarse_dirt
execute in minecraft:overworld run fill 215 66 46 215 144 46 air
execute in minecraft:overworld run fill 215 58 47 215 61 47 stone
execute in minecraft:overworld run fill 215 62 47 215 63 47 dirt
execute in minecraft:overworld run setblock 215 64 47 grass_block
execute in minecraft:overworld run fill 215 65 47 215 144 47 air
execute in minecraft:overworld run fill 216 58 -48 216 61 -48 stone
execute in minecraft:overworld run fill 216 62 -48 216 63 -48 dirt
execute in minecraft:overworld run setblock 216 64 -48 coarse_dirt
execute in minecraft:overworld run fill 216 65 -48 216 144 -48 air
execute in minecraft:overworld run fill 216 58 -47 216 63 -47 stone
execute in minecraft:overworld run fill 216 64 -47 216 65 -47 dirt
execute in minecraft:overworld run setblock 216 66 -47 coarse_dirt
execute in minecraft:overworld run fill 216 67 -47 216 144 -47 air
execute in minecraft:overworld run fill 216 58 -46 216 64 -46 stone
execute in minecraft:overworld run fill 216 65 -46 216 66 -46 dirt
execute in minecraft:overworld run setblock 216 67 -46 coarse_dirt
execute in minecraft:overworld run fill 216 68 -46 216 144 -46 air
execute in minecraft:overworld run fill 216 58 -45 216 66 -45 stone
execute in minecraft:overworld run fill 216 67 -45 216 68 -45 dirt
execute in minecraft:overworld run setblock 216 69 -45 grass_block
execute in minecraft:overworld run fill 216 70 -45 216 144 -45 air
execute in minecraft:overworld run fill 216 58 -44 216 67 -44 stone
execute in minecraft:overworld run fill 216 68 -44 216 69 -44 dirt
execute in minecraft:overworld run setblock 216 70 -44 coarse_dirt
execute in minecraft:overworld run fill 216 71 -44 216 144 -44 air
execute in minecraft:overworld run fill 216 58 -43 216 68 -43 stone
execute in minecraft:overworld run fill 216 69 -43 216 70 -43 dirt
execute in minecraft:overworld run setblock 216 71 -43 coarse_dirt
execute in minecraft:overworld run fill 216 72 -43 216 144 -43 air
execute in minecraft:overworld run fill 216 58 -42 216 69 -42 stone
execute in minecraft:overworld run fill 216 70 -42 216 71 -42 dirt
execute in minecraft:overworld run setblock 216 72 -42 grass_block
execute in minecraft:overworld run fill 216 73 -42 216 144 -42 air
execute in minecraft:overworld run fill 216 58 -41 216 70 -41 stone
execute in minecraft:overworld run fill 216 71 -41 216 72 -41 dirt
execute in minecraft:overworld run setblock 216 73 -41 coarse_dirt
execute in minecraft:overworld run fill 216 74 -41 216 144 -41 air
execute in minecraft:overworld run fill 216 58 -40 216 71 -40 stone
execute in minecraft:overworld run fill 216 72 -40 216 73 -40 dirt
execute in minecraft:overworld run setblock 216 74 -40 coarse_dirt
execute in minecraft:overworld run fill 216 75 -40 216 144 -40 air
execute in minecraft:overworld run fill 216 58 -39 216 70 -39 stone
execute in minecraft:overworld run fill 216 71 -39 216 72 -39 dirt
execute in minecraft:overworld run setblock 216 73 -39 grass_block
execute in minecraft:overworld run fill 216 74 -39 216 144 -39 air
execute in minecraft:overworld run fill 216 58 -38 216 70 -38 stone
execute in minecraft:overworld run fill 216 71 -38 216 72 -38 dirt
execute in minecraft:overworld run setblock 216 73 -38 grass_block
execute in minecraft:overworld run fill 216 74 -38 216 144 -38 air
execute in minecraft:overworld run fill 216 58 -37 216 69 -37 stone
execute in minecraft:overworld run fill 216 70 -37 216 71 -37 dirt
execute in minecraft:overworld run setblock 216 72 -37 grass_block
execute in minecraft:overworld run fill 216 73 -37 216 144 -37 air
execute in minecraft:overworld run fill 216 58 -36 216 68 -36 stone
execute in minecraft:overworld run fill 216 69 -36 216 70 -36 dirt
execute in minecraft:overworld run setblock 216 71 -36 grass_block
execute in minecraft:overworld run fill 216 72 -36 216 144 -36 air
execute in minecraft:overworld run fill 216 58 -35 216 68 -35 stone
execute in minecraft:overworld run fill 216 69 -35 216 70 -35 dirt
execute in minecraft:overworld run setblock 216 71 -35 coarse_dirt
execute in minecraft:overworld run fill 216 72 -35 216 144 -35 air
execute in minecraft:overworld run fill 216 58 -34 216 67 -34 stone
execute in minecraft:overworld run fill 216 68 -34 216 69 -34 dirt
execute in minecraft:overworld run setblock 216 70 -34 coarse_dirt
execute in minecraft:overworld run fill 216 71 -34 216 144 -34 air
execute in minecraft:overworld run fill 216 58 -33 216 67 -33 stone
execute in minecraft:overworld run fill 216 68 -33 216 69 -33 dirt
execute in minecraft:overworld run setblock 216 70 -33 coarse_dirt
execute in minecraft:overworld run fill 216 71 -33 216 144 -33 air
execute in minecraft:overworld run fill 216 58 -32 216 66 -32 stone
execute in minecraft:overworld run fill 216 67 -32 216 68 -32 dirt
execute in minecraft:overworld run setblock 216 69 -32 coarse_dirt
execute in minecraft:overworld run fill 216 70 -32 216 144 -32 air
execute in minecraft:overworld run fill 216 58 -31 216 66 -31 stone
execute in minecraft:overworld run fill 216 67 -31 216 68 -31 dirt
execute in minecraft:overworld run setblock 216 69 -31 coarse_dirt
execute in minecraft:overworld run fill 216 70 -31 216 144 -31 air
execute in minecraft:overworld run fill 216 58 -30 216 65 -30 stone
execute in minecraft:overworld run fill 216 66 -30 216 67 -30 dirt
execute in minecraft:overworld run setblock 216 68 -30 grass_block
execute in minecraft:overworld run fill 216 69 -30 216 144 -30 air
execute in minecraft:overworld run fill 216 58 -29 216 65 -29 stone
execute in minecraft:overworld run fill 216 66 -29 216 67 -29 dirt
execute in minecraft:overworld run setblock 216 68 -29 coarse_dirt
execute in minecraft:overworld run fill 216 69 -29 216 144 -29 air
execute in minecraft:overworld run setblock 216 69 -29 grass
execute in minecraft:overworld run fill 216 58 -28 216 65 -28 stone
execute in minecraft:overworld run fill 216 66 -28 216 67 -28 dirt
execute in minecraft:overworld run setblock 216 68 -28 coarse_dirt
execute in minecraft:overworld run fill 216 69 -28 216 144 -28 air
execute in minecraft:overworld run setblock 216 69 -28 grass
execute in minecraft:overworld run fill 216 58 -27 216 65 -27 stone
execute in minecraft:overworld run fill 216 66 -27 216 67 -27 dirt
execute in minecraft:overworld run setblock 216 68 -27 grass_block
execute in minecraft:overworld run fill 216 69 -27 216 144 -27 air
execute in minecraft:overworld run setblock 216 69 -27 grass
execute in minecraft:overworld run fill 216 58 -26 216 64 -26 stone
execute in minecraft:overworld run fill 216 65 -26 216 66 -26 dirt
execute in minecraft:overworld run setblock 216 67 -26 coarse_dirt
execute in minecraft:overworld run fill 216 68 -26 216 144 -26 air
execute in minecraft:overworld run setblock 216 68 -26 mossy_cobblestone
execute in minecraft:overworld run fill 216 58 -25 216 64 -25 stone
execute in minecraft:overworld run fill 216 65 -25 216 66 -25 dirt
execute in minecraft:overworld run setblock 216 67 -25 coarse_dirt
execute in minecraft:overworld run fill 216 68 -25 216 144 -25 air
execute in minecraft:overworld run setblock 216 68 -25 grass
execute in minecraft:overworld run fill 216 58 -24 216 64 -24 stone
execute in minecraft:overworld run fill 216 65 -24 216 66 -24 dirt
execute in minecraft:overworld run setblock 216 67 -24 coarse_dirt
execute in minecraft:overworld run fill 216 68 -24 216 144 -24 air
execute in minecraft:overworld run setblock 216 68 -24 grass
execute in minecraft:overworld run fill 216 58 -23 216 65 -23 stone
execute in minecraft:overworld run fill 216 66 -23 216 67 -23 dirt
execute in minecraft:overworld run setblock 216 68 -23 grass_block
execute in minecraft:overworld run fill 216 69 -23 216 144 -23 air
execute in minecraft:overworld run fill 216 58 -22 216 65 -22 stone
execute in minecraft:overworld run fill 216 66 -22 216 67 -22 dirt
execute in minecraft:overworld run setblock 216 68 -22 coarse_dirt
execute in minecraft:overworld run fill 216 69 -22 216 144 -22 air
execute in minecraft:overworld run fill 216 58 -21 216 65 -21 stone
execute in minecraft:overworld run fill 216 66 -21 216 67 -21 dirt
execute in minecraft:overworld run setblock 216 68 -21 coarse_dirt
execute in minecraft:overworld run fill 216 69 -21 216 144 -21 air
execute in minecraft:overworld run fill 216 58 -20 216 65 -20 stone
execute in minecraft:overworld run fill 216 66 -20 216 67 -20 dirt
execute in minecraft:overworld run setblock 216 68 -20 coarse_dirt
execute in minecraft:overworld run fill 216 69 -20 216 144 -20 air
execute in minecraft:overworld run fill 216 58 -19 216 65 -19 stone
execute in minecraft:overworld run fill 216 66 -19 216 67 -19 dirt
execute in minecraft:overworld run setblock 216 68 -19 coarse_dirt
execute in minecraft:overworld run fill 216 69 -19 216 144 -19 air
execute in minecraft:overworld run fill 216 58 -18 216 65 -18 stone
execute in minecraft:overworld run fill 216 66 -18 216 67 -18 dirt
execute in minecraft:overworld run setblock 216 68 -18 coarse_dirt
execute in minecraft:overworld run fill 216 69 -18 216 144 -18 air
execute in minecraft:overworld run fill 216 58 -17 216 65 -17 stone
execute in minecraft:overworld run fill 216 66 -17 216 67 -17 dirt
execute in minecraft:overworld run setblock 216 68 -17 coarse_dirt
execute in minecraft:overworld run fill 216 69 -17 216 144 -17 air
execute in minecraft:overworld run fill 216 58 -16 216 65 -16 stone
execute in minecraft:overworld run fill 216 66 -16 216 67 -16 dirt
execute in minecraft:overworld run setblock 216 68 -16 coarse_dirt
execute in minecraft:overworld run fill 216 69 -16 216 144 -16 air
execute in minecraft:overworld run fill 216 58 -15 216 65 -15 stone
execute in minecraft:overworld run fill 216 66 -15 216 67 -15 dirt
execute in minecraft:overworld run setblock 216 68 -15 grass_block
execute in minecraft:overworld run fill 216 69 -15 216 144 -15 air
execute in minecraft:overworld run fill 216 58 -14 216 65 -14 stone
execute in minecraft:overworld run fill 216 66 -14 216 67 -14 dirt
execute in minecraft:overworld run setblock 216 68 -14 grass_block
execute in minecraft:overworld run fill 216 69 -14 216 144 -14 air
execute in minecraft:overworld run fill 216 58 -13 216 65 -13 stone
execute in minecraft:overworld run fill 216 66 -13 216 67 -13 dirt
execute in minecraft:overworld run setblock 216 68 -13 coarse_dirt
execute in minecraft:overworld run fill 216 69 -13 216 144 -13 air
execute in minecraft:overworld run fill 216 58 -12 216 65 -12 stone
execute in minecraft:overworld run fill 216 66 -12 216 67 -12 dirt
execute in minecraft:overworld run setblock 216 68 -12 coarse_dirt
execute in minecraft:overworld run fill 216 69 -12 216 144 -12 air
execute in minecraft:overworld run fill 216 58 -11 216 65 -11 stone
execute in minecraft:overworld run fill 216 66 -11 216 67 -11 dirt
execute in minecraft:overworld run setblock 216 68 -11 coarse_dirt
execute in minecraft:overworld run fill 216 69 -11 216 144 -11 air
execute in minecraft:overworld run fill 216 58 -10 216 65 -10 stone
execute in minecraft:overworld run fill 216 66 -10 216 67 -10 dirt
execute in minecraft:overworld run setblock 216 68 -10 grass_block
execute in minecraft:overworld run fill 216 69 -10 216 144 -10 air
execute in minecraft:overworld run setblock 216 69 -10 grass
execute in minecraft:overworld run fill 216 58 -9 216 65 -9 stone
execute in minecraft:overworld run fill 216 66 -9 216 67 -9 dirt
execute in minecraft:overworld run setblock 216 68 -9 coarse_dirt
execute in minecraft:overworld run fill 216 69 -9 216 144 -9 air
execute in minecraft:overworld run fill 216 58 -8 216 66 -8 stone
execute in minecraft:overworld run fill 216 67 -8 216 68 -8 dirt
execute in minecraft:overworld run setblock 216 69 -8 coarse_dirt
execute in minecraft:overworld run fill 216 70 -8 216 144 -8 air
execute in minecraft:overworld run fill 216 58 -7 216 66 -7 stone
execute in minecraft:overworld run fill 216 67 -7 216 68 -7 dirt
execute in minecraft:overworld run setblock 216 69 -7 coarse_dirt
execute in minecraft:overworld run fill 216 70 -7 216 144 -7 air
execute in minecraft:overworld run fill 216 58 -6 216 66 -6 stone
execute in minecraft:overworld run fill 216 67 -6 216 68 -6 dirt
execute in minecraft:overworld run setblock 216 69 -6 coarse_dirt
execute in minecraft:overworld run fill 216 70 -6 216 144 -6 air
execute in minecraft:overworld run fill 216 58 -5 216 66 -5 stone
execute in minecraft:overworld run fill 216 67 -5 216 68 -5 dirt
execute in minecraft:overworld run setblock 216 69 -5 grass_block
execute in minecraft:overworld run fill 216 70 -5 216 144 -5 air
execute in minecraft:overworld run fill 216 58 -4 216 66 -4 stone
execute in minecraft:overworld run fill 216 67 -4 216 68 -4 dirt
execute in minecraft:overworld run setblock 216 69 -4 grass_block
execute in minecraft:overworld run fill 216 70 -4 216 144 -4 air
execute in minecraft:overworld run fill 216 58 -3 216 66 -3 stone
execute in minecraft:overworld run fill 216 67 -3 216 68 -3 dirt
execute in minecraft:overworld run setblock 216 69 -3 grass_block
execute in minecraft:overworld run fill 216 70 -3 216 144 -3 air
execute in minecraft:overworld run fill 216 58 -2 216 66 -2 stone
execute in minecraft:overworld run fill 216 67 -2 216 68 -2 dirt
execute in minecraft:overworld run setblock 216 69 -2 coarse_dirt
execute in minecraft:overworld run fill 216 70 -2 216 144 -2 air
execute in minecraft:overworld run setblock 216 70 -2 grass
execute in minecraft:overworld run fill 216 58 -1 216 66 -1 stone
execute in minecraft:overworld run fill 216 67 -1 216 68 -1 dirt
execute in minecraft:overworld run setblock 216 69 -1 coarse_dirt
execute in minecraft:overworld run fill 216 70 -1 216 144 -1 air
execute in minecraft:overworld run fill 216 58 0 216 66 0 stone
execute in minecraft:overworld run fill 216 67 0 216 68 0 dirt
execute in minecraft:overworld run setblock 216 69 0 grass_block
execute in minecraft:overworld run fill 216 70 0 216 144 0 air
execute in minecraft:overworld run fill 216 58 1 216 66 1 stone
execute in minecraft:overworld run fill 216 67 1 216 68 1 dirt
execute in minecraft:overworld run setblock 216 69 1 grass_block
execute in minecraft:overworld run fill 216 70 1 216 144 1 air
execute in minecraft:overworld run setblock 216 70 1 grass
execute in minecraft:overworld run fill 216 58 2 216 66 2 stone
execute in minecraft:overworld run fill 216 67 2 216 68 2 dirt
execute in minecraft:overworld run setblock 216 69 2 grass_block
execute in minecraft:overworld run fill 216 70 2 216 144 2 air
execute in minecraft:overworld run fill 216 58 3 216 66 3 stone
execute in minecraft:overworld run fill 216 67 3 216 68 3 dirt
execute in minecraft:overworld run setblock 216 69 3 coarse_dirt
execute in minecraft:overworld run fill 216 70 3 216 144 3 air
execute in minecraft:overworld run fill 216 58 4 216 66 4 stone
execute in minecraft:overworld run fill 216 67 4 216 68 4 dirt
execute in minecraft:overworld run setblock 216 69 4 coarse_dirt
execute in minecraft:overworld run fill 216 70 4 216 144 4 air
execute in minecraft:overworld run fill 216 58 5 216 66 5 stone
execute in minecraft:overworld run fill 216 67 5 216 68 5 dirt
execute in minecraft:overworld run setblock 216 69 5 grass_block
execute in minecraft:overworld run fill 216 70 5 216 144 5 air
execute in minecraft:overworld run setblock 216 70 5 mossy_cobblestone
execute in minecraft:overworld run fill 216 58 6 216 66 6 stone
execute in minecraft:overworld run fill 216 67 6 216 68 6 dirt
execute in minecraft:overworld run setblock 216 69 6 coarse_dirt
execute in minecraft:overworld run fill 216 70 6 216 144 6 air
execute in minecraft:overworld run fill 216 58 7 216 66 7 stone
execute in minecraft:overworld run fill 216 67 7 216 68 7 dirt
execute in minecraft:overworld run setblock 216 69 7 coarse_dirt
execute in minecraft:overworld run fill 216 70 7 216 144 7 air
execute in minecraft:overworld run fill 216 58 8 216 66 8 stone
execute in minecraft:overworld run fill 216 67 8 216 68 8 dirt
execute in minecraft:overworld run setblock 216 69 8 coarse_dirt
execute in minecraft:overworld run fill 216 70 8 216 144 8 air
execute in minecraft:overworld run fill 216 58 9 216 66 9 stone
execute in minecraft:overworld run fill 216 67 9 216 68 9 dirt
execute in minecraft:overworld run setblock 216 69 9 grass_block
schedule function blade_gallery:random/burned/part_13 1t replace
