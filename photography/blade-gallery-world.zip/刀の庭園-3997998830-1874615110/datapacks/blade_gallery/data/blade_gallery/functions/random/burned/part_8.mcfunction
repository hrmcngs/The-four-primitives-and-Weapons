execute in minecraft:overworld run setblock 213 67 -17 grass_block
execute in minecraft:overworld run fill 213 68 -17 213 144 -17 air
execute in minecraft:overworld run fill 213 58 -16 213 64 -16 stone
execute in minecraft:overworld run fill 213 65 -16 213 66 -16 dirt
execute in minecraft:overworld run setblock 213 67 -16 coarse_dirt
execute in minecraft:overworld run fill 213 68 -16 213 144 -16 air
execute in minecraft:overworld run fill 213 58 -15 213 64 -15 stone
execute in minecraft:overworld run fill 213 65 -15 213 66 -15 dirt
execute in minecraft:overworld run setblock 213 67 -15 coarse_dirt
execute in minecraft:overworld run fill 213 68 -15 213 144 -15 air
execute in minecraft:overworld run fill 213 58 -14 213 64 -14 stone
execute in minecraft:overworld run fill 213 65 -14 213 66 -14 dirt
execute in minecraft:overworld run setblock 213 67 -14 coarse_dirt
execute in minecraft:overworld run fill 213 68 -14 213 144 -14 air
execute in minecraft:overworld run fill 213 58 -13 213 64 -13 stone
execute in minecraft:overworld run fill 213 65 -13 213 66 -13 dirt
execute in minecraft:overworld run setblock 213 67 -13 grass_block
execute in minecraft:overworld run fill 213 68 -13 213 144 -13 air
execute in minecraft:overworld run fill 213 58 -12 213 63 -12 stone
execute in minecraft:overworld run fill 213 64 -12 213 65 -12 dirt
execute in minecraft:overworld run setblock 213 66 -12 grass_block
execute in minecraft:overworld run fill 213 67 -12 213 144 -12 air
execute in minecraft:overworld run fill 213 58 -11 213 64 -11 stone
execute in minecraft:overworld run fill 213 65 -11 213 66 -11 dirt
execute in minecraft:overworld run setblock 213 67 -11 grass_block
execute in minecraft:overworld run fill 213 68 -11 213 144 -11 air
execute in minecraft:overworld run fill 213 58 -10 213 64 -10 stone
execute in minecraft:overworld run fill 213 65 -10 213 66 -10 dirt
execute in minecraft:overworld run setblock 213 67 -10 grass_block
execute in minecraft:overworld run fill 213 68 -10 213 144 -10 air
execute in minecraft:overworld run fill 213 58 -9 213 64 -9 stone
execute in minecraft:overworld run fill 213 65 -9 213 66 -9 dirt
execute in minecraft:overworld run setblock 213 67 -9 grass_block
execute in minecraft:overworld run fill 213 68 -9 213 144 -9 air
execute in minecraft:overworld run fill 213 58 -8 213 64 -8 stone
execute in minecraft:overworld run fill 213 65 -8 213 66 -8 dirt
execute in minecraft:overworld run setblock 213 67 -8 grass_block
execute in minecraft:overworld run fill 213 68 -8 213 144 -8 air
execute in minecraft:overworld run fill 213 58 -7 213 64 -7 stone
execute in minecraft:overworld run fill 213 65 -7 213 66 -7 dirt
execute in minecraft:overworld run setblock 213 67 -7 coarse_dirt
execute in minecraft:overworld run fill 213 68 -7 213 144 -7 air
execute in minecraft:overworld run fill 213 58 -6 213 64 -6 stone
execute in minecraft:overworld run fill 213 65 -6 213 66 -6 dirt
execute in minecraft:overworld run setblock 213 67 -6 coarse_dirt
execute in minecraft:overworld run fill 213 68 -6 213 144 -6 air
execute in minecraft:overworld run fill 213 58 -5 213 64 -5 stone
execute in minecraft:overworld run fill 213 65 -5 213 66 -5 dirt
execute in minecraft:overworld run setblock 213 67 -5 coarse_dirt
execute in minecraft:overworld run fill 213 68 -5 213 144 -5 air
execute in minecraft:overworld run fill 213 58 -4 213 64 -4 stone
execute in minecraft:overworld run fill 213 65 -4 213 66 -4 dirt
execute in minecraft:overworld run setblock 213 67 -4 coarse_dirt
execute in minecraft:overworld run fill 213 68 -4 213 144 -4 air
execute in minecraft:overworld run fill 213 58 -3 213 64 -3 stone
execute in minecraft:overworld run fill 213 65 -3 213 66 -3 dirt
execute in minecraft:overworld run setblock 213 67 -3 grass_block
execute in minecraft:overworld run fill 213 68 -3 213 144 -3 air
execute in minecraft:overworld run fill 213 58 -2 213 64 -2 stone
execute in minecraft:overworld run fill 213 65 -2 213 66 -2 dirt
execute in minecraft:overworld run setblock 213 67 -2 grass_block
execute in minecraft:overworld run fill 213 68 -2 213 144 -2 air
execute in minecraft:overworld run fill 213 58 -1 213 64 -1 stone
execute in minecraft:overworld run fill 213 65 -1 213 66 -1 dirt
execute in minecraft:overworld run setblock 213 67 -1 coarse_dirt
execute in minecraft:overworld run fill 213 68 -1 213 144 -1 air
execute in minecraft:overworld run fill 213 58 0 213 64 0 stone
execute in minecraft:overworld run fill 213 65 0 213 66 0 dirt
execute in minecraft:overworld run setblock 213 67 0 coarse_dirt
execute in minecraft:overworld run fill 213 68 0 213 144 0 air
execute in minecraft:overworld run fill 213 58 1 213 64 1 stone
execute in minecraft:overworld run fill 213 65 1 213 66 1 dirt
execute in minecraft:overworld run setblock 213 67 1 grass_block
execute in minecraft:overworld run fill 213 68 1 213 144 1 air
execute in minecraft:overworld run fill 213 58 2 213 64 2 stone
execute in minecraft:overworld run fill 213 65 2 213 66 2 dirt
execute in minecraft:overworld run setblock 213 67 2 grass_block
execute in minecraft:overworld run fill 213 68 2 213 144 2 air
execute in minecraft:overworld run fill 213 58 3 213 64 3 stone
execute in minecraft:overworld run fill 213 65 3 213 66 3 dirt
execute in minecraft:overworld run setblock 213 67 3 grass_block
execute in minecraft:overworld run fill 213 68 3 213 144 3 air
execute in minecraft:overworld run fill 213 58 4 213 64 4 stone
execute in minecraft:overworld run fill 213 65 4 213 66 4 dirt
execute in minecraft:overworld run setblock 213 67 4 coarse_dirt
execute in minecraft:overworld run fill 213 68 4 213 144 4 air
execute in minecraft:overworld run fill 213 58 5 213 64 5 stone
execute in minecraft:overworld run fill 213 65 5 213 66 5 dirt
execute in minecraft:overworld run setblock 213 67 5 coarse_dirt
execute in minecraft:overworld run fill 213 68 5 213 144 5 air
execute in minecraft:overworld run fill 213 58 6 213 64 6 stone
execute in minecraft:overworld run fill 213 65 6 213 66 6 dirt
execute in minecraft:overworld run setblock 213 67 6 grass_block
execute in minecraft:overworld run fill 213 68 6 213 144 6 air
execute in minecraft:overworld run fill 213 58 7 213 64 7 stone
execute in minecraft:overworld run fill 213 65 7 213 66 7 dirt
execute in minecraft:overworld run setblock 213 67 7 coarse_dirt
execute in minecraft:overworld run fill 213 68 7 213 144 7 air
execute in minecraft:overworld run fill 213 58 8 213 64 8 stone
execute in minecraft:overworld run fill 213 65 8 213 66 8 dirt
execute in minecraft:overworld run setblock 213 67 8 grass_block
execute in minecraft:overworld run fill 213 68 8 213 144 8 air
execute in minecraft:overworld run fill 213 58 9 213 64 9 stone
execute in minecraft:overworld run fill 213 65 9 213 66 9 dirt
execute in minecraft:overworld run setblock 213 67 9 coarse_dirt
execute in minecraft:overworld run fill 213 68 9 213 144 9 air
execute in minecraft:overworld run fill 213 58 10 213 64 10 stone
execute in minecraft:overworld run fill 213 65 10 213 66 10 dirt
execute in minecraft:overworld run setblock 213 67 10 grass_block
execute in minecraft:overworld run fill 213 68 10 213 144 10 air
execute in minecraft:overworld run fill 213 58 11 213 64 11 stone
execute in minecraft:overworld run fill 213 65 11 213 66 11 dirt
execute in minecraft:overworld run setblock 213 67 11 coarse_dirt
execute in minecraft:overworld run fill 213 68 11 213 144 11 air
execute in minecraft:overworld run fill 213 58 12 213 64 12 stone
execute in minecraft:overworld run fill 213 65 12 213 66 12 dirt
execute in minecraft:overworld run setblock 213 67 12 coarse_dirt
execute in minecraft:overworld run fill 213 68 12 213 144 12 air
execute in minecraft:overworld run fill 213 58 13 213 64 13 stone
execute in minecraft:overworld run fill 213 65 13 213 66 13 dirt
execute in minecraft:overworld run setblock 213 67 13 grass_block
execute in minecraft:overworld run fill 213 68 13 213 144 13 air
execute in minecraft:overworld run fill 213 58 14 213 65 14 stone
execute in minecraft:overworld run fill 213 66 14 213 67 14 dirt
execute in minecraft:overworld run setblock 213 68 14 coarse_dirt
execute in minecraft:overworld run fill 213 69 14 213 144 14 air
execute in minecraft:overworld run fill 213 58 15 213 65 15 stone
execute in minecraft:overworld run fill 213 66 15 213 67 15 dirt
execute in minecraft:overworld run setblock 213 68 15 grass_block
execute in minecraft:overworld run fill 213 69 15 213 144 15 air
execute in minecraft:overworld run fill 213 58 16 213 65 16 stone
execute in minecraft:overworld run fill 213 66 16 213 67 16 dirt
execute in minecraft:overworld run setblock 213 68 16 coarse_dirt
execute in minecraft:overworld run fill 213 69 16 213 144 16 air
execute in minecraft:overworld run fill 213 58 17 213 65 17 stone
execute in minecraft:overworld run fill 213 66 17 213 67 17 dirt
execute in minecraft:overworld run setblock 213 68 17 coarse_dirt
execute in minecraft:overworld run fill 213 69 17 213 144 17 air
execute in minecraft:overworld run fill 213 58 18 213 65 18 stone
execute in minecraft:overworld run fill 213 66 18 213 67 18 dirt
execute in minecraft:overworld run setblock 213 68 18 coarse_dirt
execute in minecraft:overworld run fill 213 69 18 213 144 18 air
execute in minecraft:overworld run fill 213 58 19 213 65 19 stone
execute in minecraft:overworld run fill 213 66 19 213 67 19 dirt
execute in minecraft:overworld run setblock 213 68 19 grass_block
execute in minecraft:overworld run fill 213 69 19 213 144 19 air
execute in minecraft:overworld run fill 213 58 20 213 65 20 stone
execute in minecraft:overworld run fill 213 66 20 213 67 20 dirt
execute in minecraft:overworld run setblock 213 68 20 coarse_dirt
execute in minecraft:overworld run fill 213 69 20 213 144 20 air
execute in minecraft:overworld run fill 213 58 21 213 65 21 stone
execute in minecraft:overworld run fill 213 66 21 213 67 21 dirt
execute in minecraft:overworld run setblock 213 68 21 grass_block
execute in minecraft:overworld run fill 213 69 21 213 144 21 air
execute in minecraft:overworld run fill 213 58 22 213 65 22 stone
execute in minecraft:overworld run fill 213 66 22 213 67 22 dirt
execute in minecraft:overworld run setblock 213 68 22 coarse_dirt
execute in minecraft:overworld run fill 213 69 22 213 144 22 air
execute in minecraft:overworld run fill 213 58 23 213 65 23 stone
execute in minecraft:overworld run fill 213 66 23 213 67 23 dirt
execute in minecraft:overworld run setblock 213 68 23 grass_block
execute in minecraft:overworld run fill 213 69 23 213 144 23 air
execute in minecraft:overworld run fill 213 58 24 213 65 24 stone
execute in minecraft:overworld run fill 213 66 24 213 67 24 dirt
execute in minecraft:overworld run setblock 213 68 24 coarse_dirt
execute in minecraft:overworld run fill 213 69 24 213 144 24 air
execute in minecraft:overworld run fill 213 58 25 213 65 25 stone
execute in minecraft:overworld run fill 213 66 25 213 67 25 dirt
execute in minecraft:overworld run setblock 213 68 25 coarse_dirt
execute in minecraft:overworld run fill 213 69 25 213 144 25 air
execute in minecraft:overworld run fill 213 58 26 213 65 26 stone
execute in minecraft:overworld run fill 213 66 26 213 67 26 dirt
execute in minecraft:overworld run setblock 213 68 26 coarse_dirt
execute in minecraft:overworld run fill 213 69 26 213 144 26 air
execute in minecraft:overworld run fill 213 58 27 213 65 27 stone
execute in minecraft:overworld run fill 213 66 27 213 67 27 dirt
execute in minecraft:overworld run setblock 213 68 27 grass_block
execute in minecraft:overworld run fill 213 69 27 213 144 27 air
execute in minecraft:overworld run fill 213 58 28 213 65 28 stone
execute in minecraft:overworld run fill 213 66 28 213 67 28 dirt
execute in minecraft:overworld run setblock 213 68 28 coarse_dirt
execute in minecraft:overworld run fill 213 69 28 213 144 28 air
execute in minecraft:overworld run fill 213 58 29 213 65 29 stone
execute in minecraft:overworld run fill 213 66 29 213 67 29 dirt
execute in minecraft:overworld run setblock 213 68 29 grass_block
execute in minecraft:overworld run fill 213 69 29 213 144 29 air
execute in minecraft:overworld run fill 213 58 30 213 65 30 stone
execute in minecraft:overworld run fill 213 66 30 213 67 30 dirt
execute in minecraft:overworld run setblock 213 68 30 grass_block
execute in minecraft:overworld run fill 213 69 30 213 144 30 air
execute in minecraft:overworld run fill 213 58 31 213 65 31 stone
execute in minecraft:overworld run fill 213 66 31 213 67 31 dirt
execute in minecraft:overworld run setblock 213 68 31 grass_block
execute in minecraft:overworld run fill 213 69 31 213 144 31 air
execute in minecraft:overworld run fill 213 58 32 213 65 32 stone
execute in minecraft:overworld run fill 213 66 32 213 67 32 dirt
execute in minecraft:overworld run setblock 213 68 32 coarse_dirt
execute in minecraft:overworld run fill 213 69 32 213 144 32 air
execute in minecraft:overworld run fill 213 58 33 213 65 33 stone
execute in minecraft:overworld run fill 213 66 33 213 67 33 dirt
execute in minecraft:overworld run setblock 213 68 33 coarse_dirt
execute in minecraft:overworld run fill 213 69 33 213 144 33 air
execute in minecraft:overworld run fill 213 58 34 213 65 34 stone
execute in minecraft:overworld run fill 213 66 34 213 67 34 dirt
execute in minecraft:overworld run setblock 213 68 34 grass_block
execute in minecraft:overworld run fill 213 69 34 213 144 34 air
execute in minecraft:overworld run fill 213 58 35 213 65 35 stone
execute in minecraft:overworld run fill 213 66 35 213 67 35 dirt
execute in minecraft:overworld run setblock 213 68 35 coarse_dirt
execute in minecraft:overworld run fill 213 69 35 213 144 35 air
execute in minecraft:overworld run fill 213 58 36 213 65 36 stone
execute in minecraft:overworld run fill 213 66 36 213 67 36 dirt
execute in minecraft:overworld run setblock 213 68 36 coarse_dirt
execute in minecraft:overworld run fill 213 69 36 213 144 36 air
execute in minecraft:overworld run fill 213 58 37 213 64 37 stone
execute in minecraft:overworld run fill 213 65 37 213 66 37 dirt
execute in minecraft:overworld run setblock 213 67 37 coarse_dirt
execute in minecraft:overworld run fill 213 68 37 213 144 37 air
execute in minecraft:overworld run fill 213 58 38 213 64 38 stone
execute in minecraft:overworld run fill 213 65 38 213 66 38 dirt
execute in minecraft:overworld run setblock 213 67 38 grass_block
execute in minecraft:overworld run fill 213 68 38 213 144 38 air
execute in minecraft:overworld run fill 213 58 39 213 64 39 stone
execute in minecraft:overworld run fill 213 65 39 213 66 39 dirt
execute in minecraft:overworld run setblock 213 67 39 coarse_dirt
execute in minecraft:overworld run fill 213 68 39 213 144 39 air
execute in minecraft:overworld run fill 213 58 40 213 64 40 stone
execute in minecraft:overworld run fill 213 65 40 213 66 40 dirt
execute in minecraft:overworld run setblock 213 67 40 coarse_dirt
execute in minecraft:overworld run fill 213 68 40 213 144 40 air
execute in minecraft:overworld run fill 213 58 41 213 64 41 stone
execute in minecraft:overworld run fill 213 65 41 213 66 41 dirt
execute in minecraft:overworld run setblock 213 67 41 coarse_dirt
execute in minecraft:overworld run fill 213 68 41 213 144 41 air
execute in minecraft:overworld run fill 213 58 42 213 64 42 stone
execute in minecraft:overworld run fill 213 65 42 213 66 42 dirt
execute in minecraft:overworld run setblock 213 67 42 coarse_dirt
execute in minecraft:overworld run fill 213 68 42 213 144 42 air
execute in minecraft:overworld run fill 213 58 43 213 64 43 stone
execute in minecraft:overworld run fill 213 65 43 213 66 43 dirt
execute in minecraft:overworld run setblock 213 67 43 grass_block
execute in minecraft:overworld run fill 213 68 43 213 144 43 air
execute in minecraft:overworld run fill 213 58 44 213 63 44 stone
execute in minecraft:overworld run fill 213 64 44 213 65 44 dirt
execute in minecraft:overworld run setblock 213 66 44 coarse_dirt
execute in minecraft:overworld run fill 213 67 44 213 144 44 air
execute in minecraft:overworld run fill 213 58 45 213 62 45 stone
execute in minecraft:overworld run fill 213 63 45 213 64 45 dirt
execute in minecraft:overworld run setblock 213 65 45 coarse_dirt
execute in minecraft:overworld run fill 213 66 45 213 144 45 air
execute in minecraft:overworld run fill 213 58 46 213 62 46 stone
execute in minecraft:overworld run fill 213 63 46 213 64 46 dirt
execute in minecraft:overworld run setblock 213 65 46 coarse_dirt
execute in minecraft:overworld run fill 213 66 46 213 144 46 air
execute in minecraft:overworld run fill 213 58 47 213 61 47 stone
execute in minecraft:overworld run fill 213 62 47 213 63 47 dirt
schedule function blade_gallery:random/burned/part_9 1t replace
