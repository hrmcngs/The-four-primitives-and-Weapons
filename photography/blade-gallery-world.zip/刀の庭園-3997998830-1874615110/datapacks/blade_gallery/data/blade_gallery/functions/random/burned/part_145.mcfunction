execute in minecraft:overworld run fill 300 69 -39 300 70 -39 dirt
execute in minecraft:overworld run setblock 300 71 -39 coarse_dirt
execute in minecraft:overworld run fill 300 72 -39 300 144 -39 air
execute in minecraft:overworld run fill 300 58 -38 300 68 -38 stone
execute in minecraft:overworld run fill 300 69 -38 300 70 -38 dirt
execute in minecraft:overworld run setblock 300 71 -38 coarse_dirt
execute in minecraft:overworld run fill 300 72 -38 300 144 -38 air
execute in minecraft:overworld run fill 300 58 -37 300 68 -37 stone
execute in minecraft:overworld run fill 300 69 -37 300 70 -37 dirt
execute in minecraft:overworld run setblock 300 71 -37 coarse_dirt
execute in minecraft:overworld run fill 300 72 -37 300 144 -37 air
execute in minecraft:overworld run fill 300 58 -36 300 68 -36 stone
execute in minecraft:overworld run fill 300 69 -36 300 70 -36 dirt
execute in minecraft:overworld run setblock 300 71 -36 coarse_dirt
execute in minecraft:overworld run fill 300 72 -36 300 144 -36 air
execute in minecraft:overworld run fill 300 58 -35 300 68 -35 stone
execute in minecraft:overworld run fill 300 69 -35 300 70 -35 dirt
execute in minecraft:overworld run setblock 300 71 -35 coarse_dirt
execute in minecraft:overworld run fill 300 72 -35 300 144 -35 air
execute in minecraft:overworld run fill 300 58 -34 300 68 -34 stone
execute in minecraft:overworld run fill 300 69 -34 300 70 -34 dirt
execute in minecraft:overworld run setblock 300 71 -34 coarse_dirt
execute in minecraft:overworld run fill 300 72 -34 300 144 -34 air
execute in minecraft:overworld run fill 300 58 -33 300 68 -33 stone
execute in minecraft:overworld run fill 300 69 -33 300 70 -33 dirt
execute in minecraft:overworld run setblock 300 71 -33 grass_block
execute in minecraft:overworld run fill 300 72 -33 300 144 -33 air
execute in minecraft:overworld run fill 300 58 -32 300 67 -32 stone
execute in minecraft:overworld run fill 300 68 -32 300 69 -32 dirt
execute in minecraft:overworld run setblock 300 70 -32 grass_block
execute in minecraft:overworld run fill 300 71 -32 300 144 -32 air
execute in minecraft:overworld run fill 300 58 -31 300 67 -31 stone
execute in minecraft:overworld run fill 300 68 -31 300 69 -31 dirt
execute in minecraft:overworld run setblock 300 70 -31 coarse_dirt
execute in minecraft:overworld run fill 300 71 -31 300 144 -31 air
execute in minecraft:overworld run fill 300 58 -30 300 67 -30 stone
execute in minecraft:overworld run fill 300 68 -30 300 69 -30 dirt
execute in minecraft:overworld run setblock 300 70 -30 coarse_dirt
execute in minecraft:overworld run fill 300 71 -30 300 144 -30 air
execute in minecraft:overworld run fill 300 58 -29 300 67 -29 stone
execute in minecraft:overworld run fill 300 68 -29 300 69 -29 dirt
execute in minecraft:overworld run setblock 300 70 -29 coarse_dirt
execute in minecraft:overworld run fill 300 71 -29 300 144 -29 air
execute in minecraft:overworld run fill 300 58 -28 300 67 -28 stone
execute in minecraft:overworld run fill 300 68 -28 300 69 -28 dirt
execute in minecraft:overworld run setblock 300 70 -28 grass_block
execute in minecraft:overworld run fill 300 71 -28 300 144 -28 air
execute in minecraft:overworld run fill 300 58 -27 300 67 -27 stone
execute in minecraft:overworld run fill 300 68 -27 300 69 -27 dirt
execute in minecraft:overworld run setblock 300 70 -27 coarse_dirt
execute in minecraft:overworld run fill 300 71 -27 300 144 -27 air
execute in minecraft:overworld run fill 300 58 -26 300 66 -26 stone
execute in minecraft:overworld run fill 300 67 -26 300 68 -26 dirt
execute in minecraft:overworld run setblock 300 69 -26 grass_block
execute in minecraft:overworld run fill 300 70 -26 300 144 -26 air
execute in minecraft:overworld run fill 300 58 -25 300 66 -25 stone
execute in minecraft:overworld run fill 300 67 -25 300 68 -25 dirt
execute in minecraft:overworld run setblock 300 69 -25 coarse_dirt
execute in minecraft:overworld run fill 300 70 -25 300 144 -25 air
execute in minecraft:overworld run fill 300 58 -24 300 66 -24 stone
execute in minecraft:overworld run fill 300 67 -24 300 68 -24 dirt
execute in minecraft:overworld run setblock 300 69 -24 grass_block
execute in minecraft:overworld run fill 300 70 -24 300 144 -24 air
execute in minecraft:overworld run fill 300 58 -23 300 66 -23 stone
execute in minecraft:overworld run fill 300 67 -23 300 68 -23 dirt
execute in minecraft:overworld run setblock 300 69 -23 coarse_dirt
execute in minecraft:overworld run fill 300 70 -23 300 144 -23 air
execute in minecraft:overworld run fill 300 58 -22 300 66 -22 stone
execute in minecraft:overworld run fill 300 67 -22 300 68 -22 dirt
execute in minecraft:overworld run setblock 300 69 -22 grass_block
execute in minecraft:overworld run fill 300 70 -22 300 144 -22 air
execute in minecraft:overworld run fill 300 58 -21 300 65 -21 stone
execute in minecraft:overworld run fill 300 66 -21 300 67 -21 dirt
execute in minecraft:overworld run setblock 300 68 -21 coarse_dirt
execute in minecraft:overworld run fill 300 69 -21 300 144 -21 air
execute in minecraft:overworld run fill 300 58 -20 300 65 -20 stone
execute in minecraft:overworld run fill 300 66 -20 300 67 -20 dirt
execute in minecraft:overworld run setblock 300 68 -20 coarse_dirt
execute in minecraft:overworld run fill 300 69 -20 300 144 -20 air
execute in minecraft:overworld run fill 300 58 -19 300 65 -19 stone
execute in minecraft:overworld run fill 300 66 -19 300 67 -19 dirt
execute in minecraft:overworld run setblock 300 68 -19 grass_block
execute in minecraft:overworld run fill 300 69 -19 300 144 -19 air
execute in minecraft:overworld run fill 300 58 -18 300 65 -18 stone
execute in minecraft:overworld run fill 300 66 -18 300 67 -18 dirt
execute in minecraft:overworld run setblock 300 68 -18 coarse_dirt
execute in minecraft:overworld run fill 300 69 -18 300 144 -18 air
execute in minecraft:overworld run fill 300 58 -17 300 65 -17 stone
execute in minecraft:overworld run fill 300 66 -17 300 67 -17 dirt
execute in minecraft:overworld run setblock 300 68 -17 coarse_dirt
execute in minecraft:overworld run fill 300 69 -17 300 144 -17 air
execute in minecraft:overworld run fill 300 58 -16 300 64 -16 stone
execute in minecraft:overworld run fill 300 65 -16 300 66 -16 dirt
execute in minecraft:overworld run setblock 300 67 -16 coarse_dirt
execute in minecraft:overworld run fill 300 68 -16 300 144 -16 air
execute in minecraft:overworld run fill 300 58 -15 300 64 -15 stone
execute in minecraft:overworld run fill 300 65 -15 300 66 -15 dirt
execute in minecraft:overworld run setblock 300 67 -15 coarse_dirt
execute in minecraft:overworld run fill 300 68 -15 300 144 -15 air
execute in minecraft:overworld run fill 300 58 -14 300 64 -14 stone
execute in minecraft:overworld run fill 300 65 -14 300 66 -14 dirt
execute in minecraft:overworld run setblock 300 67 -14 grass_block
execute in minecraft:overworld run fill 300 68 -14 300 144 -14 air
execute in minecraft:overworld run fill 300 58 -13 300 64 -13 stone
execute in minecraft:overworld run fill 300 65 -13 300 66 -13 dirt
execute in minecraft:overworld run setblock 300 67 -13 coarse_dirt
execute in minecraft:overworld run fill 300 68 -13 300 144 -13 air
execute in minecraft:overworld run fill 300 58 -12 300 64 -12 stone
execute in minecraft:overworld run fill 300 65 -12 300 66 -12 dirt
execute in minecraft:overworld run setblock 300 67 -12 grass_block
execute in minecraft:overworld run fill 300 68 -12 300 144 -12 air
execute in minecraft:overworld run fill 300 58 -11 300 64 -11 stone
execute in minecraft:overworld run fill 300 65 -11 300 66 -11 dirt
execute in minecraft:overworld run setblock 300 67 -11 coarse_dirt
execute in minecraft:overworld run fill 300 68 -11 300 144 -11 air
execute in minecraft:overworld run fill 300 58 -10 300 64 -10 stone
execute in minecraft:overworld run fill 300 65 -10 300 66 -10 dirt
execute in minecraft:overworld run setblock 300 67 -10 grass_block
execute in minecraft:overworld run fill 300 68 -10 300 144 -10 air
execute in minecraft:overworld run fill 300 58 -9 300 64 -9 stone
execute in minecraft:overworld run fill 300 65 -9 300 66 -9 dirt
execute in minecraft:overworld run setblock 300 67 -9 coarse_dirt
execute in minecraft:overworld run fill 300 68 -9 300 144 -9 air
execute in minecraft:overworld run fill 300 58 -8 300 64 -8 stone
execute in minecraft:overworld run fill 300 65 -8 300 66 -8 dirt
execute in minecraft:overworld run setblock 300 67 -8 coarse_dirt
execute in minecraft:overworld run fill 300 68 -8 300 144 -8 air
execute in minecraft:overworld run fill 300 58 -7 300 64 -7 stone
execute in minecraft:overworld run fill 300 65 -7 300 66 -7 dirt
execute in minecraft:overworld run setblock 300 67 -7 coarse_dirt
execute in minecraft:overworld run fill 300 68 -7 300 144 -7 air
execute in minecraft:overworld run fill 300 58 -6 300 64 -6 stone
execute in minecraft:overworld run fill 300 65 -6 300 66 -6 dirt
execute in minecraft:overworld run setblock 300 67 -6 coarse_dirt
execute in minecraft:overworld run fill 300 68 -6 300 144 -6 air
execute in minecraft:overworld run fill 300 58 -5 300 64 -5 stone
execute in minecraft:overworld run fill 300 65 -5 300 66 -5 dirt
execute in minecraft:overworld run setblock 300 67 -5 grass_block
execute in minecraft:overworld run fill 300 68 -5 300 144 -5 air
execute in minecraft:overworld run fill 300 58 -4 300 64 -4 stone
execute in minecraft:overworld run fill 300 65 -4 300 66 -4 dirt
execute in minecraft:overworld run setblock 300 67 -4 grass_block
execute in minecraft:overworld run fill 300 68 -4 300 144 -4 air
execute in minecraft:overworld run fill 300 58 -3 300 64 -3 stone
execute in minecraft:overworld run fill 300 65 -3 300 66 -3 dirt
execute in minecraft:overworld run setblock 300 67 -3 grass_block
execute in minecraft:overworld run fill 300 68 -3 300 144 -3 air
execute in minecraft:overworld run fill 300 58 -2 300 64 -2 stone
execute in minecraft:overworld run fill 300 65 -2 300 66 -2 dirt
execute in minecraft:overworld run setblock 300 67 -2 grass_block
execute in minecraft:overworld run fill 300 68 -2 300 144 -2 air
execute in minecraft:overworld run fill 300 58 -1 300 64 -1 stone
execute in minecraft:overworld run fill 300 65 -1 300 66 -1 dirt
execute in minecraft:overworld run setblock 300 67 -1 coarse_dirt
execute in minecraft:overworld run fill 300 68 -1 300 144 -1 air
execute in minecraft:overworld run fill 300 58 0 300 64 0 stone
execute in minecraft:overworld run fill 300 65 0 300 66 0 dirt
execute in minecraft:overworld run setblock 300 67 0 coarse_dirt
execute in minecraft:overworld run fill 300 68 0 300 144 0 air
execute in minecraft:overworld run fill 300 58 1 300 64 1 stone
execute in minecraft:overworld run fill 300 65 1 300 66 1 dirt
execute in minecraft:overworld run setblock 300 67 1 coarse_dirt
execute in minecraft:overworld run fill 300 68 1 300 144 1 air
execute in minecraft:overworld run fill 300 58 2 300 64 2 stone
execute in minecraft:overworld run fill 300 65 2 300 66 2 dirt
execute in minecraft:overworld run setblock 300 67 2 grass_block
execute in minecraft:overworld run fill 300 68 2 300 144 2 air
execute in minecraft:overworld run fill 300 58 3 300 64 3 stone
execute in minecraft:overworld run fill 300 65 3 300 66 3 dirt
execute in minecraft:overworld run setblock 300 67 3 coarse_dirt
execute in minecraft:overworld run fill 300 68 3 300 144 3 air
execute in minecraft:overworld run fill 300 58 4 300 64 4 stone
execute in minecraft:overworld run fill 300 65 4 300 66 4 dirt
execute in minecraft:overworld run setblock 300 67 4 coarse_dirt
execute in minecraft:overworld run fill 300 68 4 300 144 4 air
execute in minecraft:overworld run fill 300 58 5 300 64 5 stone
execute in minecraft:overworld run fill 300 65 5 300 66 5 dirt
execute in minecraft:overworld run setblock 300 67 5 coarse_dirt
execute in minecraft:overworld run fill 300 68 5 300 144 5 air
execute in minecraft:overworld run fill 300 58 6 300 64 6 stone
execute in minecraft:overworld run fill 300 65 6 300 66 6 dirt
execute in minecraft:overworld run setblock 300 67 6 coarse_dirt
execute in minecraft:overworld run fill 300 68 6 300 144 6 air
execute in minecraft:overworld run fill 300 58 7 300 64 7 stone
execute in minecraft:overworld run fill 300 65 7 300 66 7 dirt
execute in minecraft:overworld run setblock 300 67 7 coarse_dirt
execute in minecraft:overworld run fill 300 68 7 300 144 7 air
execute in minecraft:overworld run fill 300 58 8 300 64 8 stone
execute in minecraft:overworld run fill 300 65 8 300 66 8 dirt
execute in minecraft:overworld run setblock 300 67 8 coarse_dirt
execute in minecraft:overworld run fill 300 68 8 300 144 8 air
execute in minecraft:overworld run fill 300 58 9 300 64 9 stone
execute in minecraft:overworld run fill 300 65 9 300 66 9 dirt
execute in minecraft:overworld run setblock 300 67 9 grass_block
execute in minecraft:overworld run fill 300 68 9 300 144 9 air
execute in minecraft:overworld run fill 300 58 10 300 64 10 stone
execute in minecraft:overworld run fill 300 65 10 300 66 10 dirt
execute in minecraft:overworld run setblock 300 67 10 grass_block
execute in minecraft:overworld run fill 300 68 10 300 144 10 air
execute in minecraft:overworld run fill 300 58 11 300 64 11 stone
execute in minecraft:overworld run fill 300 65 11 300 66 11 dirt
execute in minecraft:overworld run setblock 300 67 11 grass_block
execute in minecraft:overworld run fill 300 68 11 300 144 11 air
execute in minecraft:overworld run fill 300 58 12 300 63 12 stone
execute in minecraft:overworld run fill 300 64 12 300 65 12 dirt
execute in minecraft:overworld run setblock 300 66 12 coarse_dirt
execute in minecraft:overworld run fill 300 67 12 300 144 12 air
execute in minecraft:overworld run fill 300 58 13 300 63 13 stone
execute in minecraft:overworld run fill 300 64 13 300 65 13 dirt
execute in minecraft:overworld run setblock 300 66 13 grass_block
execute in minecraft:overworld run fill 300 67 13 300 144 13 air
execute in minecraft:overworld run fill 300 58 14 300 63 14 stone
execute in minecraft:overworld run fill 300 64 14 300 65 14 dirt
execute in minecraft:overworld run setblock 300 66 14 coarse_dirt
execute in minecraft:overworld run fill 300 67 14 300 144 14 air
execute in minecraft:overworld run fill 300 58 15 300 63 15 stone
execute in minecraft:overworld run fill 300 64 15 300 65 15 dirt
execute in minecraft:overworld run setblock 300 66 15 grass_block
execute in minecraft:overworld run fill 300 67 15 300 144 15 air
execute in minecraft:overworld run fill 300 58 16 300 63 16 stone
execute in minecraft:overworld run fill 300 64 16 300 65 16 dirt
execute in minecraft:overworld run setblock 300 66 16 grass_block
execute in minecraft:overworld run fill 300 67 16 300 144 16 air
execute in minecraft:overworld run fill 300 58 17 300 63 17 stone
execute in minecraft:overworld run fill 300 64 17 300 65 17 dirt
execute in minecraft:overworld run setblock 300 66 17 grass_block
execute in minecraft:overworld run fill 300 67 17 300 144 17 air
execute in minecraft:overworld run fill 300 58 18 300 63 18 stone
execute in minecraft:overworld run fill 300 64 18 300 65 18 dirt
execute in minecraft:overworld run setblock 300 66 18 coarse_dirt
execute in minecraft:overworld run fill 300 67 18 300 144 18 air
execute in minecraft:overworld run fill 300 58 19 300 63 19 stone
execute in minecraft:overworld run fill 300 64 19 300 65 19 dirt
execute in minecraft:overworld run setblock 300 66 19 coarse_dirt
execute in minecraft:overworld run fill 300 67 19 300 144 19 air
execute in minecraft:overworld run fill 300 58 20 300 63 20 stone
execute in minecraft:overworld run fill 300 64 20 300 65 20 dirt
execute in minecraft:overworld run setblock 300 66 20 grass_block
execute in minecraft:overworld run fill 300 67 20 300 144 20 air
execute in minecraft:overworld run fill 300 58 21 300 63 21 stone
execute in minecraft:overworld run fill 300 64 21 300 65 21 dirt
execute in minecraft:overworld run setblock 300 66 21 grass_block
execute in minecraft:overworld run fill 300 67 21 300 144 21 air
execute in minecraft:overworld run fill 300 58 22 300 63 22 stone
execute in minecraft:overworld run fill 300 64 22 300 65 22 dirt
execute in minecraft:overworld run setblock 300 66 22 coarse_dirt
execute in minecraft:overworld run fill 300 67 22 300 144 22 air
execute in minecraft:overworld run fill 300 58 23 300 63 23 stone
execute in minecraft:overworld run fill 300 64 23 300 65 23 dirt
execute in minecraft:overworld run setblock 300 66 23 grass_block
execute in minecraft:overworld run fill 300 67 23 300 144 23 air
execute in minecraft:overworld run fill 300 58 24 300 63 24 stone
execute in minecraft:overworld run fill 300 64 24 300 65 24 dirt
execute in minecraft:overworld run setblock 300 66 24 coarse_dirt
execute in minecraft:overworld run fill 300 67 24 300 144 24 air
execute in minecraft:overworld run fill 300 58 25 300 63 25 stone
schedule function blade_gallery:random/burned/part_146 1t replace
