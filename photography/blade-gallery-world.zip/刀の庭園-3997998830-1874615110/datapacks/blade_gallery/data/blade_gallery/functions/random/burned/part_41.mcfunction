execute in minecraft:overworld run setblock 234 73 23 grass
execute in minecraft:overworld run fill 234 58 24 234 69 24 stone
execute in minecraft:overworld run fill 234 70 24 234 71 24 dirt
execute in minecraft:overworld run setblock 234 72 24 grass_block
execute in minecraft:overworld run fill 234 73 24 234 144 24 air
execute in minecraft:overworld run fill 234 58 25 234 69 25 stone
execute in minecraft:overworld run fill 234 70 25 234 71 25 dirt
execute in minecraft:overworld run setblock 234 72 25 coarse_dirt
execute in minecraft:overworld run fill 234 73 25 234 144 25 air
execute in minecraft:overworld run setblock 234 73 25 grass
execute in minecraft:overworld run fill 234 58 26 234 69 26 stone
execute in minecraft:overworld run fill 234 70 26 234 71 26 dirt
execute in minecraft:overworld run setblock 234 72 26 coarse_dirt
execute in minecraft:overworld run fill 234 73 26 234 144 26 air
execute in minecraft:overworld run fill 234 58 27 234 69 27 stone
execute in minecraft:overworld run fill 234 70 27 234 71 27 dirt
execute in minecraft:overworld run setblock 234 72 27 coarse_dirt
execute in minecraft:overworld run fill 234 73 27 234 144 27 air
execute in minecraft:overworld run fill 234 58 28 234 69 28 stone
execute in minecraft:overworld run fill 234 70 28 234 71 28 dirt
execute in minecraft:overworld run setblock 234 72 28 grass_block
execute in minecraft:overworld run fill 234 73 28 234 144 28 air
execute in minecraft:overworld run fill 234 58 29 234 69 29 stone
execute in minecraft:overworld run fill 234 70 29 234 71 29 dirt
execute in minecraft:overworld run setblock 234 72 29 coarse_dirt
execute in minecraft:overworld run fill 234 73 29 234 144 29 air
execute in minecraft:overworld run fill 234 58 30 234 69 30 stone
execute in minecraft:overworld run fill 234 70 30 234 71 30 dirt
execute in minecraft:overworld run setblock 234 72 30 grass_block
execute in minecraft:overworld run fill 234 73 30 234 144 30 air
execute in minecraft:overworld run setblock 234 73 30 grass
execute in minecraft:overworld run fill 234 58 31 234 69 31 stone
execute in minecraft:overworld run fill 234 70 31 234 71 31 dirt
execute in minecraft:overworld run setblock 234 72 31 grass_block
execute in minecraft:overworld run fill 234 73 31 234 144 31 air
execute in minecraft:overworld run fill 234 58 32 234 69 32 stone
execute in minecraft:overworld run fill 234 70 32 234 71 32 dirt
execute in minecraft:overworld run setblock 234 72 32 coarse_dirt
execute in minecraft:overworld run fill 234 73 32 234 144 32 air
execute in minecraft:overworld run fill 234 58 33 234 69 33 stone
execute in minecraft:overworld run fill 234 70 33 234 71 33 dirt
execute in minecraft:overworld run setblock 234 72 33 grass_block
execute in minecraft:overworld run fill 234 73 33 234 144 33 air
execute in minecraft:overworld run fill 234 58 34 234 69 34 stone
execute in minecraft:overworld run fill 234 70 34 234 71 34 dirt
execute in minecraft:overworld run setblock 234 72 34 coarse_dirt
execute in minecraft:overworld run fill 234 73 34 234 144 34 air
execute in minecraft:overworld run fill 234 58 35 234 69 35 stone
execute in minecraft:overworld run fill 234 70 35 234 71 35 dirt
execute in minecraft:overworld run setblock 234 72 35 coarse_dirt
execute in minecraft:overworld run fill 234 73 35 234 144 35 air
execute in minecraft:overworld run fill 234 58 36 234 68 36 stone
execute in minecraft:overworld run fill 234 69 36 234 70 36 dirt
execute in minecraft:overworld run setblock 234 71 36 grass_block
execute in minecraft:overworld run fill 234 72 36 234 144 36 air
execute in minecraft:overworld run setblock 234 72 36 grass
execute in minecraft:overworld run fill 234 58 37 234 68 37 stone
execute in minecraft:overworld run fill 234 69 37 234 70 37 dirt
execute in minecraft:overworld run setblock 234 71 37 coarse_dirt
execute in minecraft:overworld run fill 234 72 37 234 144 37 air
execute in minecraft:overworld run fill 234 58 38 234 68 38 stone
execute in minecraft:overworld run fill 234 69 38 234 70 38 dirt
execute in minecraft:overworld run setblock 234 71 38 coarse_dirt
execute in minecraft:overworld run fill 234 72 38 234 144 38 air
execute in minecraft:overworld run fill 234 58 39 234 67 39 stone
execute in minecraft:overworld run fill 234 68 39 234 69 39 dirt
execute in minecraft:overworld run setblock 234 70 39 grass_block
execute in minecraft:overworld run fill 234 71 39 234 144 39 air
execute in minecraft:overworld run fill 234 58 40 234 66 40 stone
execute in minecraft:overworld run fill 234 67 40 234 68 40 dirt
execute in minecraft:overworld run setblock 234 69 40 coarse_dirt
execute in minecraft:overworld run fill 234 70 40 234 144 40 air
execute in minecraft:overworld run fill 234 58 41 234 65 41 stone
execute in minecraft:overworld run fill 234 66 41 234 67 41 dirt
execute in minecraft:overworld run setblock 234 68 41 coarse_dirt
execute in minecraft:overworld run fill 234 69 41 234 144 41 air
execute in minecraft:overworld run fill 234 58 42 234 64 42 stone
execute in minecraft:overworld run fill 234 65 42 234 66 42 dirt
execute in minecraft:overworld run setblock 234 67 42 coarse_dirt
execute in minecraft:overworld run fill 234 68 42 234 144 42 air
execute in minecraft:overworld run fill 234 58 43 234 63 43 stone
execute in minecraft:overworld run fill 234 64 43 234 65 43 dirt
execute in minecraft:overworld run setblock 234 66 43 coarse_dirt
execute in minecraft:overworld run fill 234 67 43 234 144 43 air
execute in minecraft:overworld run fill 234 58 44 234 63 44 stone
execute in minecraft:overworld run fill 234 64 44 234 65 44 dirt
execute in minecraft:overworld run setblock 234 66 44 grass_block
execute in minecraft:overworld run fill 234 67 44 234 144 44 air
execute in minecraft:overworld run fill 234 58 45 234 62 45 stone
execute in minecraft:overworld run fill 234 63 45 234 64 45 dirt
execute in minecraft:overworld run setblock 234 65 45 coarse_dirt
execute in minecraft:overworld run fill 234 66 45 234 144 45 air
execute in minecraft:overworld run fill 234 58 46 234 62 46 stone
execute in minecraft:overworld run fill 234 63 46 234 64 46 dirt
execute in minecraft:overworld run setblock 234 65 46 grass_block
execute in minecraft:overworld run fill 234 66 46 234 144 46 air
execute in minecraft:overworld run fill 234 58 47 234 61 47 stone
execute in minecraft:overworld run fill 234 62 47 234 63 47 dirt
execute in minecraft:overworld run setblock 234 64 47 coarse_dirt
execute in minecraft:overworld run fill 234 65 47 234 144 47 air
execute in minecraft:overworld run fill 235 58 -48 235 61 -48 stone
execute in minecraft:overworld run fill 235 62 -48 235 63 -48 dirt
execute in minecraft:overworld run setblock 235 64 -48 coarse_dirt
execute in minecraft:overworld run fill 235 65 -48 235 144 -48 air
execute in minecraft:overworld run fill 235 58 -47 235 63 -47 stone
execute in minecraft:overworld run fill 235 64 -47 235 65 -47 dirt
execute in minecraft:overworld run setblock 235 66 -47 coarse_dirt
execute in minecraft:overworld run fill 235 67 -47 235 144 -47 air
execute in minecraft:overworld run fill 235 58 -46 235 64 -46 stone
execute in minecraft:overworld run fill 235 65 -46 235 66 -46 dirt
execute in minecraft:overworld run setblock 235 67 -46 grass_block
execute in minecraft:overworld run fill 235 68 -46 235 144 -46 air
execute in minecraft:overworld run fill 235 58 -45 235 65 -45 stone
execute in minecraft:overworld run fill 235 66 -45 235 67 -45 dirt
execute in minecraft:overworld run setblock 235 68 -45 grass_block
execute in minecraft:overworld run fill 235 69 -45 235 144 -45 air
execute in minecraft:overworld run fill 235 58 -44 235 67 -44 stone
execute in minecraft:overworld run fill 235 68 -44 235 69 -44 dirt
execute in minecraft:overworld run setblock 235 70 -44 coarse_dirt
execute in minecraft:overworld run fill 235 71 -44 235 144 -44 air
execute in minecraft:overworld run fill 235 58 -43 235 68 -43 stone
execute in minecraft:overworld run fill 235 69 -43 235 70 -43 dirt
execute in minecraft:overworld run setblock 235 71 -43 grass_block
execute in minecraft:overworld run fill 235 72 -43 235 144 -43 air
execute in minecraft:overworld run fill 235 58 -42 235 69 -42 stone
execute in minecraft:overworld run fill 235 70 -42 235 71 -42 dirt
execute in minecraft:overworld run setblock 235 72 -42 coarse_dirt
execute in minecraft:overworld run fill 235 73 -42 235 144 -42 air
execute in minecraft:overworld run fill 235 58 -41 235 71 -41 stone
execute in minecraft:overworld run fill 235 72 -41 235 73 -41 dirt
execute in minecraft:overworld run setblock 235 74 -41 coarse_dirt
execute in minecraft:overworld run fill 235 75 -41 235 144 -41 air
execute in minecraft:overworld run fill 235 58 -40 235 72 -40 stone
execute in minecraft:overworld run fill 235 73 -40 235 74 -40 dirt
execute in minecraft:overworld run setblock 235 75 -40 grass_block
execute in minecraft:overworld run fill 235 76 -40 235 144 -40 air
execute in minecraft:overworld run fill 235 58 -39 235 73 -39 stone
execute in minecraft:overworld run fill 235 74 -39 235 75 -39 dirt
execute in minecraft:overworld run setblock 235 76 -39 coarse_dirt
execute in minecraft:overworld run fill 235 77 -39 235 144 -39 air
execute in minecraft:overworld run fill 235 58 -38 235 74 -38 stone
execute in minecraft:overworld run fill 235 75 -38 235 76 -38 dirt
execute in minecraft:overworld run setblock 235 77 -38 grass_block
execute in minecraft:overworld run fill 235 78 -38 235 144 -38 air
execute in minecraft:overworld run fill 235 58 -37 235 74 -37 stone
execute in minecraft:overworld run fill 235 75 -37 235 76 -37 dirt
execute in minecraft:overworld run setblock 235 77 -37 grass_block
execute in minecraft:overworld run fill 235 78 -37 235 144 -37 air
execute in minecraft:overworld run fill 235 58 -36 235 74 -36 stone
execute in minecraft:overworld run fill 235 75 -36 235 76 -36 dirt
execute in minecraft:overworld run setblock 235 77 -36 coarse_dirt
execute in minecraft:overworld run fill 235 78 -36 235 144 -36 air
execute in minecraft:overworld run fill 235 58 -35 235 73 -35 stone
execute in minecraft:overworld run fill 235 74 -35 235 75 -35 dirt
execute in minecraft:overworld run setblock 235 76 -35 grass_block
execute in minecraft:overworld run fill 235 77 -35 235 144 -35 air
execute in minecraft:overworld run fill 235 58 -34 235 73 -34 stone
execute in minecraft:overworld run fill 235 74 -34 235 75 -34 dirt
execute in minecraft:overworld run setblock 235 76 -34 coarse_dirt
execute in minecraft:overworld run fill 235 77 -34 235 144 -34 air
execute in minecraft:overworld run fill 235 58 -33 235 73 -33 stone
execute in minecraft:overworld run fill 235 74 -33 235 75 -33 dirt
execute in minecraft:overworld run setblock 235 76 -33 coarse_dirt
execute in minecraft:overworld run fill 235 77 -33 235 144 -33 air
execute in minecraft:overworld run fill 235 58 -32 235 72 -32 stone
execute in minecraft:overworld run fill 235 73 -32 235 74 -32 dirt
execute in minecraft:overworld run setblock 235 75 -32 coarse_dirt
execute in minecraft:overworld run fill 235 76 -32 235 144 -32 air
execute in minecraft:overworld run fill 235 58 -31 235 72 -31 stone
execute in minecraft:overworld run fill 235 73 -31 235 74 -31 dirt
execute in minecraft:overworld run setblock 235 75 -31 coarse_dirt
execute in minecraft:overworld run fill 235 76 -31 235 144 -31 air
execute in minecraft:overworld run fill 235 58 -30 235 71 -30 stone
execute in minecraft:overworld run fill 235 72 -30 235 73 -30 dirt
execute in minecraft:overworld run setblock 235 74 -30 grass_block
execute in minecraft:overworld run fill 235 75 -30 235 144 -30 air
execute in minecraft:overworld run fill 235 58 -29 235 71 -29 stone
execute in minecraft:overworld run fill 235 72 -29 235 73 -29 dirt
execute in minecraft:overworld run setblock 235 74 -29 coarse_dirt
execute in minecraft:overworld run fill 235 75 -29 235 144 -29 air
execute in minecraft:overworld run fill 235 58 -28 235 70 -28 stone
execute in minecraft:overworld run fill 235 71 -28 235 72 -28 dirt
execute in minecraft:overworld run setblock 235 73 -28 coarse_dirt
execute in minecraft:overworld run fill 235 74 -28 235 144 -28 air
execute in minecraft:overworld run fill 235 58 -27 235 70 -27 stone
execute in minecraft:overworld run fill 235 71 -27 235 72 -27 dirt
execute in minecraft:overworld run setblock 235 73 -27 grass_block
execute in minecraft:overworld run fill 235 74 -27 235 144 -27 air
execute in minecraft:overworld run fill 235 58 -26 235 70 -26 stone
execute in minecraft:overworld run fill 235 71 -26 235 72 -26 dirt
execute in minecraft:overworld run setblock 235 73 -26 grass_block
execute in minecraft:overworld run fill 235 74 -26 235 144 -26 air
execute in minecraft:overworld run fill 235 58 -25 235 69 -25 stone
execute in minecraft:overworld run fill 235 70 -25 235 71 -25 dirt
execute in minecraft:overworld run setblock 235 72 -25 coarse_dirt
execute in minecraft:overworld run fill 235 73 -25 235 144 -25 air
execute in minecraft:overworld run fill 235 58 -24 235 69 -24 stone
execute in minecraft:overworld run fill 235 70 -24 235 71 -24 dirt
execute in minecraft:overworld run setblock 235 72 -24 grass_block
execute in minecraft:overworld run fill 235 73 -24 235 144 -24 air
execute in minecraft:overworld run fill 235 58 -23 235 68 -23 stone
execute in minecraft:overworld run fill 235 69 -23 235 70 -23 dirt
execute in minecraft:overworld run setblock 235 71 -23 coarse_dirt
execute in minecraft:overworld run fill 235 72 -23 235 144 -23 air
execute in minecraft:overworld run fill 235 58 -22 235 68 -22 stone
execute in minecraft:overworld run fill 235 69 -22 235 70 -22 dirt
execute in minecraft:overworld run setblock 235 71 -22 coarse_dirt
execute in minecraft:overworld run fill 235 72 -22 235 144 -22 air
execute in minecraft:overworld run setblock 235 72 -22 grass
execute in minecraft:overworld run fill 235 58 -21 235 68 -21 stone
execute in minecraft:overworld run fill 235 69 -21 235 70 -21 dirt
execute in minecraft:overworld run setblock 235 71 -21 coarse_dirt
execute in minecraft:overworld run fill 235 72 -21 235 144 -21 air
execute in minecraft:overworld run fill 235 58 -20 235 67 -20 stone
execute in minecraft:overworld run fill 235 68 -20 235 69 -20 dirt
execute in minecraft:overworld run setblock 235 70 -20 grass_block
execute in minecraft:overworld run fill 235 71 -20 235 144 -20 air
execute in minecraft:overworld run fill 235 58 -19 235 67 -19 stone
execute in minecraft:overworld run fill 235 68 -19 235 69 -19 dirt
execute in minecraft:overworld run setblock 235 70 -19 coarse_dirt
execute in minecraft:overworld run fill 235 71 -19 235 144 -19 air
execute in minecraft:overworld run setblock 235 71 -19 grass
execute in minecraft:overworld run fill 235 58 -18 235 67 -18 stone
execute in minecraft:overworld run fill 235 68 -18 235 69 -18 dirt
execute in minecraft:overworld run setblock 235 70 -18 coarse_dirt
execute in minecraft:overworld run fill 235 71 -18 235 144 -18 air
execute in minecraft:overworld run fill 235 58 -17 235 66 -17 stone
execute in minecraft:overworld run fill 235 67 -17 235 68 -17 dirt
execute in minecraft:overworld run setblock 235 69 -17 coarse_dirt
execute in minecraft:overworld run fill 235 70 -17 235 144 -17 air
execute in minecraft:overworld run fill 235 58 -16 235 66 -16 stone
execute in minecraft:overworld run fill 235 67 -16 235 68 -16 dirt
execute in minecraft:overworld run setblock 235 69 -16 coarse_dirt
execute in minecraft:overworld run fill 235 70 -16 235 144 -16 air
execute in minecraft:overworld run fill 235 58 -15 235 66 -15 stone
execute in minecraft:overworld run fill 235 67 -15 235 68 -15 dirt
execute in minecraft:overworld run setblock 235 69 -15 coarse_dirt
execute in minecraft:overworld run fill 235 70 -15 235 144 -15 air
execute in minecraft:overworld run fill 235 58 -14 235 65 -14 stone
execute in minecraft:overworld run fill 235 66 -14 235 67 -14 dirt
execute in minecraft:overworld run setblock 235 68 -14 coarse_dirt
execute in minecraft:overworld run fill 235 69 -14 235 144 -14 air
execute in minecraft:overworld run fill 235 58 -13 235 65 -13 stone
execute in minecraft:overworld run fill 235 66 -13 235 67 -13 dirt
execute in minecraft:overworld run setblock 235 68 -13 grass_block
execute in minecraft:overworld run fill 235 69 -13 235 144 -13 air
execute in minecraft:overworld run fill 235 58 -12 235 65 -12 stone
execute in minecraft:overworld run fill 235 66 -12 235 67 -12 dirt
execute in minecraft:overworld run setblock 235 68 -12 grass_block
execute in minecraft:overworld run fill 235 69 -12 235 144 -12 air
execute in minecraft:overworld run fill 235 58 -11 235 65 -11 stone
execute in minecraft:overworld run fill 235 66 -11 235 67 -11 dirt
execute in minecraft:overworld run setblock 235 68 -11 grass_block
execute in minecraft:overworld run fill 235 69 -11 235 144 -11 air
execute in minecraft:overworld run fill 235 58 -10 235 65 -10 stone
execute in minecraft:overworld run fill 235 66 -10 235 67 -10 dirt
schedule function blade_gallery:random/burned/part_42 1t replace
