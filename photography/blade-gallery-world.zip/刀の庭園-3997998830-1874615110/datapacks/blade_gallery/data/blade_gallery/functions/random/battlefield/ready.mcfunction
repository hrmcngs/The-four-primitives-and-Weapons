schedule clear blade_gallery:random/battlefield/wait
execute in minecraft:overworld run function blade_gallery:random/battlefield/part_0
