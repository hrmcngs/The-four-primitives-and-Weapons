execute in minecraft:overworld run setblock 341 69 -17 coarse_dirt
execute in minecraft:overworld run fill 341 70 -17 341 144 -17 air
execute in minecraft:overworld run fill 341 58 -16 341 65 -16 stone
execute in minecraft:overworld run fill 341 66 -16 341 67 -16 dirt
execute in minecraft:overworld run setblock 341 68 -16 coarse_dirt
execute in minecraft:overworld run fill 341 69 -16 341 144 -16 air
execute in minecraft:overworld run fill 341 58 -15 341 65 -15 stone
execute in minecraft:overworld run fill 341 66 -15 341 67 -15 dirt
execute in minecraft:overworld run setblock 341 68 -15 coarse_dirt
execute in minecraft:overworld run fill 341 69 -15 341 144 -15 air
execute in minecraft:overworld run fill 341 58 -14 341 65 -14 stone
execute in minecraft:overworld run fill 341 66 -14 341 67 -14 dirt
execute in minecraft:overworld run setblock 341 68 -14 coarse_dirt
execute in minecraft:overworld run fill 341 69 -14 341 144 -14 air
execute in minecraft:overworld run fill 341 58 -13 341 64 -13 stone
execute in minecraft:overworld run fill 341 65 -13 341 66 -13 dirt
execute in minecraft:overworld run setblock 341 67 -13 coarse_dirt
execute in minecraft:overworld run fill 341 68 -13 341 144 -13 air
execute in minecraft:overworld run fill 341 58 -12 341 64 -12 stone
execute in minecraft:overworld run fill 341 65 -12 341 66 -12 dirt
execute in minecraft:overworld run setblock 341 67 -12 coarse_dirt
execute in minecraft:overworld run fill 341 68 -12 341 144 -12 air
execute in minecraft:overworld run fill 341 58 -11 341 64 -11 stone
execute in minecraft:overworld run fill 341 65 -11 341 66 -11 dirt
execute in minecraft:overworld run setblock 341 67 -11 coarse_dirt
execute in minecraft:overworld run fill 341 68 -11 341 144 -11 air
execute in minecraft:overworld run fill 341 58 -10 341 64 -10 stone
execute in minecraft:overworld run fill 341 65 -10 341 66 -10 dirt
execute in minecraft:overworld run setblock 341 67 -10 coarse_dirt
execute in minecraft:overworld run fill 341 68 -10 341 144 -10 air
execute in minecraft:overworld run fill 341 58 -9 341 64 -9 stone
execute in minecraft:overworld run fill 341 65 -9 341 66 -9 dirt
execute in minecraft:overworld run setblock 341 67 -9 coarse_dirt
execute in minecraft:overworld run fill 341 68 -9 341 144 -9 air
execute in minecraft:overworld run fill 341 58 -8 341 64 -8 stone
execute in minecraft:overworld run fill 341 65 -8 341 66 -8 dirt
execute in minecraft:overworld run setblock 341 67 -8 coarse_dirt
execute in minecraft:overworld run fill 341 68 -8 341 144 -8 air
execute in minecraft:overworld run fill 341 58 -7 341 64 -7 stone
execute in minecraft:overworld run fill 341 65 -7 341 66 -7 dirt
execute in minecraft:overworld run setblock 341 67 -7 coarse_dirt
execute in minecraft:overworld run fill 341 68 -7 341 144 -7 air
execute in minecraft:overworld run fill 341 58 -6 341 64 -6 stone
execute in minecraft:overworld run fill 341 65 -6 341 66 -6 dirt
execute in minecraft:overworld run setblock 341 67 -6 coarse_dirt
execute in minecraft:overworld run fill 341 68 -6 341 144 -6 air
execute in minecraft:overworld run fill 341 58 -5 341 64 -5 stone
execute in minecraft:overworld run fill 341 65 -5 341 66 -5 dirt
execute in minecraft:overworld run setblock 341 67 -5 coarse_dirt
execute in minecraft:overworld run fill 341 68 -5 341 144 -5 air
execute in minecraft:overworld run fill 341 58 -4 341 64 -4 stone
execute in minecraft:overworld run fill 341 65 -4 341 66 -4 dirt
execute in minecraft:overworld run setblock 341 67 -4 grass_block
execute in minecraft:overworld run fill 341 68 -4 341 144 -4 air
execute in minecraft:overworld run fill 341 58 -3 341 64 -3 stone
execute in minecraft:overworld run fill 341 65 -3 341 66 -3 dirt
execute in minecraft:overworld run setblock 341 67 -3 grass_block
execute in minecraft:overworld run fill 341 68 -3 341 144 -3 air
execute in minecraft:overworld run fill 341 58 -2 341 64 -2 stone
execute in minecraft:overworld run fill 341 65 -2 341 66 -2 dirt
execute in minecraft:overworld run setblock 341 67 -2 coarse_dirt
execute in minecraft:overworld run fill 341 68 -2 341 144 -2 air
execute in minecraft:overworld run fill 341 58 -1 341 64 -1 stone
execute in minecraft:overworld run fill 341 65 -1 341 66 -1 dirt
execute in minecraft:overworld run setblock 341 67 -1 coarse_dirt
execute in minecraft:overworld run fill 341 68 -1 341 144 -1 air
execute in minecraft:overworld run fill 341 58 0 341 64 0 stone
execute in minecraft:overworld run fill 341 65 0 341 66 0 dirt
execute in minecraft:overworld run setblock 341 67 0 grass_block
execute in minecraft:overworld run fill 341 68 0 341 144 0 air
execute in minecraft:overworld run fill 341 58 1 341 64 1 stone
execute in minecraft:overworld run fill 341 65 1 341 66 1 dirt
execute in minecraft:overworld run setblock 341 67 1 grass_block
execute in minecraft:overworld run fill 341 68 1 341 144 1 air
execute in minecraft:overworld run fill 341 58 2 341 64 2 stone
execute in minecraft:overworld run fill 341 65 2 341 66 2 dirt
execute in minecraft:overworld run setblock 341 67 2 coarse_dirt
execute in minecraft:overworld run fill 341 68 2 341 144 2 air
execute in minecraft:overworld run fill 341 58 3 341 64 3 stone
execute in minecraft:overworld run fill 341 65 3 341 66 3 dirt
execute in minecraft:overworld run setblock 341 67 3 grass_block
execute in minecraft:overworld run fill 341 68 3 341 144 3 air
execute in minecraft:overworld run fill 341 58 4 341 64 4 stone
execute in minecraft:overworld run fill 341 65 4 341 66 4 dirt
execute in minecraft:overworld run setblock 341 67 4 coarse_dirt
execute in minecraft:overworld run fill 341 68 4 341 144 4 air
execute in minecraft:overworld run fill 341 58 5 341 64 5 stone
execute in minecraft:overworld run fill 341 65 5 341 66 5 dirt
execute in minecraft:overworld run setblock 341 67 5 coarse_dirt
execute in minecraft:overworld run fill 341 68 5 341 144 5 air
execute in minecraft:overworld run fill 341 58 6 341 64 6 stone
execute in minecraft:overworld run fill 341 65 6 341 66 6 dirt
execute in minecraft:overworld run setblock 341 67 6 coarse_dirt
execute in minecraft:overworld run fill 341 68 6 341 144 6 air
execute in minecraft:overworld run fill 341 58 7 341 64 7 stone
execute in minecraft:overworld run fill 341 65 7 341 66 7 dirt
execute in minecraft:overworld run setblock 341 67 7 coarse_dirt
execute in minecraft:overworld run fill 341 68 7 341 144 7 air
execute in minecraft:overworld run fill 341 58 8 341 64 8 stone
execute in minecraft:overworld run fill 341 65 8 341 66 8 dirt
execute in minecraft:overworld run setblock 341 67 8 coarse_dirt
execute in minecraft:overworld run fill 341 68 8 341 144 8 air
execute in minecraft:overworld run fill 341 58 9 341 64 9 stone
execute in minecraft:overworld run fill 341 65 9 341 66 9 dirt
execute in minecraft:overworld run setblock 341 67 9 coarse_dirt
execute in minecraft:overworld run fill 341 68 9 341 144 9 air
execute in minecraft:overworld run fill 341 58 10 341 64 10 stone
execute in minecraft:overworld run fill 341 65 10 341 66 10 dirt
execute in minecraft:overworld run setblock 341 67 10 grass_block
execute in minecraft:overworld run fill 341 68 10 341 144 10 air
execute in minecraft:overworld run fill 341 58 11 341 64 11 stone
execute in minecraft:overworld run fill 341 65 11 341 66 11 dirt
execute in minecraft:overworld run setblock 341 67 11 coarse_dirt
execute in minecraft:overworld run fill 341 68 11 341 144 11 air
execute in minecraft:overworld run fill 341 58 12 341 63 12 stone
execute in minecraft:overworld run fill 341 64 12 341 65 12 dirt
execute in minecraft:overworld run setblock 341 66 12 coarse_dirt
execute in minecraft:overworld run fill 341 67 12 341 144 12 air
execute in minecraft:overworld run fill 341 58 13 341 63 13 stone
execute in minecraft:overworld run fill 341 64 13 341 65 13 dirt
execute in minecraft:overworld run setblock 341 66 13 grass_block
execute in minecraft:overworld run fill 341 67 13 341 144 13 air
execute in minecraft:overworld run fill 341 58 14 341 63 14 stone
execute in minecraft:overworld run fill 341 64 14 341 65 14 dirt
execute in minecraft:overworld run setblock 341 66 14 coarse_dirt
execute in minecraft:overworld run fill 341 67 14 341 144 14 air
execute in minecraft:overworld run fill 341 58 15 341 63 15 stone
execute in minecraft:overworld run fill 341 64 15 341 65 15 dirt
execute in minecraft:overworld run setblock 341 66 15 coarse_dirt
execute in minecraft:overworld run fill 341 67 15 341 144 15 air
execute in minecraft:overworld run fill 341 58 16 341 63 16 stone
execute in minecraft:overworld run fill 341 64 16 341 65 16 dirt
execute in minecraft:overworld run setblock 341 66 16 grass_block
execute in minecraft:overworld run fill 341 67 16 341 144 16 air
execute in minecraft:overworld run fill 341 58 17 341 62 17 stone
execute in minecraft:overworld run fill 341 63 17 341 64 17 dirt
execute in minecraft:overworld run setblock 341 65 17 coarse_dirt
execute in minecraft:overworld run fill 341 66 17 341 144 17 air
execute in minecraft:overworld run fill 341 58 18 341 62 18 stone
execute in minecraft:overworld run fill 341 63 18 341 64 18 dirt
execute in minecraft:overworld run setblock 341 65 18 coarse_dirt
execute in minecraft:overworld run fill 341 66 18 341 144 18 air
execute in minecraft:overworld run fill 341 58 19 341 62 19 stone
execute in minecraft:overworld run fill 341 63 19 341 64 19 dirt
execute in minecraft:overworld run setblock 341 65 19 coarse_dirt
execute in minecraft:overworld run fill 341 66 19 341 144 19 air
execute in minecraft:overworld run fill 341 58 20 341 62 20 stone
execute in minecraft:overworld run fill 341 63 20 341 64 20 dirt
execute in minecraft:overworld run setblock 341 65 20 grass_block
execute in minecraft:overworld run fill 341 66 20 341 144 20 air
execute in minecraft:overworld run fill 341 58 21 341 62 21 stone
execute in minecraft:overworld run fill 341 63 21 341 64 21 dirt
execute in minecraft:overworld run setblock 341 65 21 coarse_dirt
execute in minecraft:overworld run fill 341 66 21 341 144 21 air
execute in minecraft:overworld run fill 341 58 22 341 62 22 stone
execute in minecraft:overworld run fill 341 63 22 341 64 22 dirt
execute in minecraft:overworld run setblock 341 65 22 grass_block
execute in minecraft:overworld run fill 341 66 22 341 144 22 air
execute in minecraft:overworld run fill 341 58 23 341 62 23 stone
execute in minecraft:overworld run fill 341 63 23 341 64 23 dirt
execute in minecraft:overworld run setblock 341 65 23 coarse_dirt
execute in minecraft:overworld run fill 341 66 23 341 144 23 air
execute in minecraft:overworld run fill 341 58 24 341 62 24 stone
execute in minecraft:overworld run fill 341 63 24 341 64 24 dirt
execute in minecraft:overworld run setblock 341 65 24 coarse_dirt
execute in minecraft:overworld run fill 341 66 24 341 144 24 air
execute in minecraft:overworld run fill 341 58 25 341 62 25 stone
execute in minecraft:overworld run fill 341 63 25 341 64 25 dirt
execute in minecraft:overworld run setblock 341 65 25 coarse_dirt
execute in minecraft:overworld run fill 341 66 25 341 144 25 air
execute in minecraft:overworld run fill 341 58 26 341 62 26 stone
execute in minecraft:overworld run fill 341 63 26 341 64 26 dirt
execute in minecraft:overworld run setblock 341 65 26 grass_block
execute in minecraft:overworld run fill 341 66 26 341 144 26 air
execute in minecraft:overworld run fill 341 58 27 341 62 27 stone
execute in minecraft:overworld run fill 341 63 27 341 64 27 dirt
execute in minecraft:overworld run setblock 341 65 27 coarse_dirt
execute in minecraft:overworld run fill 341 66 27 341 144 27 air
execute in minecraft:overworld run fill 341 58 28 341 62 28 stone
execute in minecraft:overworld run fill 341 63 28 341 64 28 dirt
execute in minecraft:overworld run setblock 341 65 28 coarse_dirt
execute in minecraft:overworld run fill 341 66 28 341 144 28 air
execute in minecraft:overworld run fill 341 58 29 341 62 29 stone
execute in minecraft:overworld run fill 341 63 29 341 64 29 dirt
execute in minecraft:overworld run setblock 341 65 29 grass_block
execute in minecraft:overworld run fill 341 66 29 341 144 29 air
execute in minecraft:overworld run fill 341 58 30 341 62 30 stone
execute in minecraft:overworld run fill 341 63 30 341 64 30 dirt
execute in minecraft:overworld run setblock 341 65 30 grass_block
execute in minecraft:overworld run fill 341 66 30 341 144 30 air
execute in minecraft:overworld run fill 341 58 31 341 62 31 stone
execute in minecraft:overworld run fill 341 63 31 341 64 31 dirt
execute in minecraft:overworld run setblock 341 65 31 coarse_dirt
execute in minecraft:overworld run fill 341 66 31 341 144 31 air
execute in minecraft:overworld run fill 341 58 32 341 62 32 stone
execute in minecraft:overworld run fill 341 63 32 341 64 32 dirt
execute in minecraft:overworld run setblock 341 65 32 coarse_dirt
execute in minecraft:overworld run fill 341 66 32 341 144 32 air
execute in minecraft:overworld run fill 341 58 33 341 62 33 stone
execute in minecraft:overworld run fill 341 63 33 341 64 33 dirt
execute in minecraft:overworld run setblock 341 65 33 coarse_dirt
execute in minecraft:overworld run fill 341 66 33 341 144 33 air
execute in minecraft:overworld run fill 341 58 34 341 62 34 stone
execute in minecraft:overworld run fill 341 63 34 341 64 34 dirt
execute in minecraft:overworld run setblock 341 65 34 coarse_dirt
execute in minecraft:overworld run fill 341 66 34 341 144 34 air
execute in minecraft:overworld run fill 341 58 35 341 62 35 stone
execute in minecraft:overworld run fill 341 63 35 341 64 35 dirt
execute in minecraft:overworld run setblock 341 65 35 grass_block
execute in minecraft:overworld run fill 341 66 35 341 144 35 air
execute in minecraft:overworld run fill 341 58 36 341 62 36 stone
execute in minecraft:overworld run fill 341 63 36 341 64 36 dirt
execute in minecraft:overworld run setblock 341 65 36 coarse_dirt
execute in minecraft:overworld run fill 341 66 36 341 144 36 air
execute in minecraft:overworld run fill 341 58 37 341 62 37 stone
execute in minecraft:overworld run fill 341 63 37 341 64 37 dirt
execute in minecraft:overworld run setblock 341 65 37 grass_block
execute in minecraft:overworld run fill 341 66 37 341 144 37 air
execute in minecraft:overworld run fill 341 58 38 341 62 38 stone
execute in minecraft:overworld run fill 341 63 38 341 64 38 dirt
execute in minecraft:overworld run setblock 341 65 38 coarse_dirt
execute in minecraft:overworld run fill 341 66 38 341 144 38 air
execute in minecraft:overworld run fill 341 58 39 341 62 39 stone
execute in minecraft:overworld run fill 341 63 39 341 64 39 dirt
execute in minecraft:overworld run setblock 341 65 39 grass_block
execute in minecraft:overworld run fill 341 66 39 341 144 39 air
execute in minecraft:overworld run fill 341 58 40 341 62 40 stone
execute in minecraft:overworld run fill 341 63 40 341 64 40 dirt
execute in minecraft:overworld run setblock 341 65 40 coarse_dirt
execute in minecraft:overworld run fill 341 66 40 341 144 40 air
execute in minecraft:overworld run fill 341 58 41 341 62 41 stone
execute in minecraft:overworld run fill 341 63 41 341 64 41 dirt
execute in minecraft:overworld run setblock 341 65 41 coarse_dirt
execute in minecraft:overworld run fill 341 66 41 341 144 41 air
execute in minecraft:overworld run fill 341 58 42 341 62 42 stone
execute in minecraft:overworld run fill 341 63 42 341 64 42 dirt
execute in minecraft:overworld run setblock 341 65 42 coarse_dirt
execute in minecraft:overworld run fill 341 66 42 341 144 42 air
execute in minecraft:overworld run fill 341 58 43 341 62 43 stone
execute in minecraft:overworld run fill 341 63 43 341 64 43 dirt
execute in minecraft:overworld run setblock 341 65 43 coarse_dirt
execute in minecraft:overworld run fill 341 66 43 341 144 43 air
execute in minecraft:overworld run fill 341 58 44 341 62 44 stone
execute in minecraft:overworld run fill 341 63 44 341 64 44 dirt
execute in minecraft:overworld run setblock 341 65 44 coarse_dirt
execute in minecraft:overworld run fill 341 66 44 341 144 44 air
execute in minecraft:overworld run fill 341 58 45 341 62 45 stone
execute in minecraft:overworld run fill 341 63 45 341 64 45 dirt
execute in minecraft:overworld run setblock 341 65 45 coarse_dirt
execute in minecraft:overworld run fill 341 66 45 341 144 45 air
execute in minecraft:overworld run fill 341 58 46 341 62 46 stone
execute in minecraft:overworld run fill 341 63 46 341 64 46 dirt
execute in minecraft:overworld run setblock 341 65 46 grass_block
execute in minecraft:overworld run fill 341 66 46 341 144 46 air
execute in minecraft:overworld run fill 341 58 47 341 61 47 stone
execute in minecraft:overworld run fill 341 62 47 341 63 47 dirt
schedule function blade_gallery:random/battlefield/part_9 1t replace
