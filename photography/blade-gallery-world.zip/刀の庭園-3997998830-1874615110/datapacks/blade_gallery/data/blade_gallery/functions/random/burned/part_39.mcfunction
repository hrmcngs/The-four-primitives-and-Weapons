execute in minecraft:overworld run setblock 233 68 -6 coarse_dirt
execute in minecraft:overworld run fill 233 69 -6 233 144 -6 air
execute in minecraft:overworld run fill 233 58 -5 233 65 -5 stone
execute in minecraft:overworld run fill 233 66 -5 233 67 -5 dirt
execute in minecraft:overworld run setblock 233 68 -5 coarse_dirt
execute in minecraft:overworld run fill 233 69 -5 233 144 -5 air
execute in minecraft:overworld run fill 233 58 -4 233 65 -4 stone
execute in minecraft:overworld run fill 233 66 -4 233 67 -4 dirt
execute in minecraft:overworld run setblock 233 68 -4 grass_block
execute in minecraft:overworld run fill 233 69 -4 233 144 -4 air
execute in minecraft:overworld run setblock 233 69 -4 grass
execute in minecraft:overworld run fill 233 58 -3 233 65 -3 stone
execute in minecraft:overworld run fill 233 66 -3 233 67 -3 dirt
execute in minecraft:overworld run setblock 233 68 -3 coarse_dirt
execute in minecraft:overworld run fill 233 69 -3 233 144 -3 air
execute in minecraft:overworld run fill 233 58 -2 233 65 -2 stone
execute in minecraft:overworld run fill 233 66 -2 233 67 -2 dirt
execute in minecraft:overworld run setblock 233 68 -2 coarse_dirt
execute in minecraft:overworld run fill 233 69 -2 233 144 -2 air
execute in minecraft:overworld run setblock 233 69 -2 mossy_cobblestone
execute in minecraft:overworld run fill 233 58 -1 233 65 -1 stone
execute in minecraft:overworld run fill 233 66 -1 233 67 -1 dirt
execute in minecraft:overworld run setblock 233 68 -1 coarse_dirt
execute in minecraft:overworld run fill 233 69 -1 233 144 -1 air
execute in minecraft:overworld run fill 233 58 0 233 64 0 stone
execute in minecraft:overworld run fill 233 65 0 233 66 0 dirt
execute in minecraft:overworld run setblock 233 67 0 grass_block
execute in minecraft:overworld run fill 233 68 0 233 144 0 air
execute in minecraft:overworld run fill 233 58 1 233 65 1 stone
execute in minecraft:overworld run fill 233 66 1 233 67 1 dirt
execute in minecraft:overworld run setblock 233 68 1 grass_block
execute in minecraft:overworld run fill 233 69 1 233 144 1 air
execute in minecraft:overworld run fill 233 58 2 233 65 2 stone
execute in minecraft:overworld run fill 233 66 2 233 67 2 dirt
execute in minecraft:overworld run setblock 233 68 2 grass_block
execute in minecraft:overworld run fill 233 69 2 233 144 2 air
execute in minecraft:overworld run fill 233 58 3 233 65 3 stone
execute in minecraft:overworld run fill 233 66 3 233 67 3 dirt
execute in minecraft:overworld run setblock 233 68 3 coarse_dirt
execute in minecraft:overworld run fill 233 69 3 233 144 3 air
execute in minecraft:overworld run fill 233 58 4 233 65 4 stone
execute in minecraft:overworld run fill 233 66 4 233 67 4 dirt
execute in minecraft:overworld run setblock 233 68 4 coarse_dirt
execute in minecraft:overworld run fill 233 69 4 233 144 4 air
execute in minecraft:overworld run fill 233 58 5 233 65 5 stone
execute in minecraft:overworld run fill 233 66 5 233 67 5 dirt
execute in minecraft:overworld run setblock 233 68 5 grass_block
execute in minecraft:overworld run fill 233 69 5 233 144 5 air
execute in minecraft:overworld run fill 233 58 6 233 65 6 stone
execute in minecraft:overworld run fill 233 66 6 233 67 6 dirt
execute in minecraft:overworld run setblock 233 68 6 coarse_dirt
execute in minecraft:overworld run fill 233 69 6 233 144 6 air
execute in minecraft:overworld run fill 233 58 7 233 66 7 stone
execute in minecraft:overworld run fill 233 67 7 233 68 7 dirt
execute in minecraft:overworld run setblock 233 69 7 coarse_dirt
execute in minecraft:overworld run fill 233 70 7 233 144 7 air
execute in minecraft:overworld run fill 233 58 8 233 66 8 stone
execute in minecraft:overworld run fill 233 67 8 233 68 8 dirt
execute in minecraft:overworld run setblock 233 69 8 coarse_dirt
execute in minecraft:overworld run fill 233 70 8 233 144 8 air
execute in minecraft:overworld run fill 233 58 9 233 66 9 stone
execute in minecraft:overworld run fill 233 67 9 233 68 9 dirt
execute in minecraft:overworld run setblock 233 69 9 coarse_dirt
execute in minecraft:overworld run fill 233 70 9 233 144 9 air
execute in minecraft:overworld run fill 233 58 10 233 66 10 stone
execute in minecraft:overworld run fill 233 67 10 233 68 10 dirt
execute in minecraft:overworld run setblock 233 69 10 coarse_dirt
execute in minecraft:overworld run fill 233 70 10 233 144 10 air
execute in minecraft:overworld run fill 233 58 11 233 67 11 stone
execute in minecraft:overworld run fill 233 68 11 233 69 11 dirt
execute in minecraft:overworld run setblock 233 70 11 grass_block
execute in minecraft:overworld run fill 233 71 11 233 144 11 air
execute in minecraft:overworld run fill 233 58 12 233 67 12 stone
execute in minecraft:overworld run fill 233 68 12 233 69 12 dirt
execute in minecraft:overworld run setblock 233 70 12 grass_block
execute in minecraft:overworld run fill 233 71 12 233 144 12 air
execute in minecraft:overworld run fill 233 58 13 233 67 13 stone
execute in minecraft:overworld run fill 233 68 13 233 69 13 dirt
execute in minecraft:overworld run setblock 233 70 13 coarse_dirt
execute in minecraft:overworld run fill 233 71 13 233 144 13 air
execute in minecraft:overworld run fill 233 58 14 233 67 14 stone
execute in minecraft:overworld run fill 233 68 14 233 69 14 dirt
execute in minecraft:overworld run setblock 233 70 14 grass_block
execute in minecraft:overworld run fill 233 71 14 233 144 14 air
execute in minecraft:overworld run fill 233 58 15 233 68 15 stone
execute in minecraft:overworld run fill 233 69 15 233 70 15 dirt
execute in minecraft:overworld run setblock 233 71 15 coarse_dirt
execute in minecraft:overworld run fill 233 72 15 233 144 15 air
execute in minecraft:overworld run fill 233 58 16 233 68 16 stone
execute in minecraft:overworld run fill 233 69 16 233 70 16 dirt
execute in minecraft:overworld run setblock 233 71 16 grass_block
execute in minecraft:overworld run fill 233 72 16 233 144 16 air
execute in minecraft:overworld run fill 233 58 17 233 68 17 stone
execute in minecraft:overworld run fill 233 69 17 233 70 17 dirt
execute in minecraft:overworld run setblock 233 71 17 grass_block
execute in minecraft:overworld run fill 233 72 17 233 144 17 air
execute in minecraft:overworld run fill 233 58 18 233 68 18 stone
execute in minecraft:overworld run fill 233 69 18 233 70 18 dirt
execute in minecraft:overworld run setblock 233 71 18 grass_block
execute in minecraft:overworld run fill 233 72 18 233 144 18 air
execute in minecraft:overworld run fill 233 58 19 233 69 19 stone
execute in minecraft:overworld run fill 233 70 19 233 71 19 dirt
execute in minecraft:overworld run setblock 233 72 19 grass_block
execute in minecraft:overworld run fill 233 73 19 233 144 19 air
execute in minecraft:overworld run fill 233 58 20 233 69 20 stone
execute in minecraft:overworld run fill 233 70 20 233 71 20 dirt
execute in minecraft:overworld run setblock 233 72 20 coarse_dirt
execute in minecraft:overworld run fill 233 73 20 233 144 20 air
execute in minecraft:overworld run fill 233 58 21 233 69 21 stone
execute in minecraft:overworld run fill 233 70 21 233 71 21 dirt
execute in minecraft:overworld run setblock 233 72 21 grass_block
execute in minecraft:overworld run fill 233 73 21 233 144 21 air
execute in minecraft:overworld run fill 233 58 22 233 69 22 stone
execute in minecraft:overworld run fill 233 70 22 233 71 22 dirt
execute in minecraft:overworld run setblock 233 72 22 grass_block
execute in minecraft:overworld run fill 233 73 22 233 144 22 air
execute in minecraft:overworld run fill 233 58 23 233 69 23 stone
execute in minecraft:overworld run fill 233 70 23 233 71 23 dirt
execute in minecraft:overworld run setblock 233 72 23 grass_block
execute in minecraft:overworld run fill 233 73 23 233 144 23 air
execute in minecraft:overworld run fill 233 58 24 233 69 24 stone
execute in minecraft:overworld run fill 233 70 24 233 71 24 dirt
execute in minecraft:overworld run setblock 233 72 24 grass_block
execute in minecraft:overworld run fill 233 73 24 233 144 24 air
execute in minecraft:overworld run fill 233 58 25 233 69 25 stone
execute in minecraft:overworld run fill 233 70 25 233 71 25 dirt
execute in minecraft:overworld run setblock 233 72 25 coarse_dirt
execute in minecraft:overworld run fill 233 73 25 233 144 25 air
execute in minecraft:overworld run fill 233 58 26 233 69 26 stone
execute in minecraft:overworld run fill 233 70 26 233 71 26 dirt
execute in minecraft:overworld run setblock 233 72 26 grass_block
execute in minecraft:overworld run fill 233 73 26 233 144 26 air
execute in minecraft:overworld run fill 233 58 27 233 69 27 stone
execute in minecraft:overworld run fill 233 70 27 233 71 27 dirt
execute in minecraft:overworld run setblock 233 72 27 grass_block
execute in minecraft:overworld run fill 233 73 27 233 144 27 air
execute in minecraft:overworld run fill 233 58 28 233 69 28 stone
execute in minecraft:overworld run fill 233 70 28 233 71 28 dirt
execute in minecraft:overworld run setblock 233 72 28 coarse_dirt
execute in minecraft:overworld run fill 233 73 28 233 144 28 air
execute in minecraft:overworld run fill 233 58 29 233 69 29 stone
execute in minecraft:overworld run fill 233 70 29 233 71 29 dirt
execute in minecraft:overworld run setblock 233 72 29 grass_block
execute in minecraft:overworld run fill 233 73 29 233 144 29 air
execute in minecraft:overworld run fill 233 58 30 233 69 30 stone
execute in minecraft:overworld run fill 233 70 30 233 71 30 dirt
execute in minecraft:overworld run setblock 233 72 30 coarse_dirt
execute in minecraft:overworld run fill 233 73 30 233 144 30 air
execute in minecraft:overworld run fill 233 58 31 233 69 31 stone
execute in minecraft:overworld run fill 233 70 31 233 71 31 dirt
execute in minecraft:overworld run setblock 233 72 31 coarse_dirt
execute in minecraft:overworld run fill 233 73 31 233 144 31 air
execute in minecraft:overworld run fill 233 58 32 233 69 32 stone
execute in minecraft:overworld run fill 233 70 32 233 71 32 dirt
execute in minecraft:overworld run setblock 233 72 32 grass_block
execute in minecraft:overworld run fill 233 73 32 233 144 32 air
execute in minecraft:overworld run setblock 233 73 32 grass
execute in minecraft:overworld run fill 233 58 33 233 69 33 stone
execute in minecraft:overworld run fill 233 70 33 233 71 33 dirt
execute in minecraft:overworld run setblock 233 72 33 grass_block
execute in minecraft:overworld run fill 233 73 33 233 144 33 air
execute in minecraft:overworld run fill 233 58 34 233 69 34 stone
execute in minecraft:overworld run fill 233 70 34 233 71 34 dirt
execute in minecraft:overworld run setblock 233 72 34 coarse_dirt
execute in minecraft:overworld run fill 233 73 34 233 144 34 air
execute in minecraft:overworld run fill 233 58 35 233 69 35 stone
execute in minecraft:overworld run fill 233 70 35 233 71 35 dirt
execute in minecraft:overworld run setblock 233 72 35 grass_block
execute in minecraft:overworld run fill 233 73 35 233 144 35 air
execute in minecraft:overworld run setblock 233 73 35 grass
execute in minecraft:overworld run fill 233 58 36 233 69 36 stone
execute in minecraft:overworld run fill 233 70 36 233 71 36 dirt
execute in minecraft:overworld run setblock 233 72 36 coarse_dirt
execute in minecraft:overworld run fill 233 73 36 233 144 36 air
execute in minecraft:overworld run fill 233 58 37 233 68 37 stone
execute in minecraft:overworld run fill 233 69 37 233 70 37 dirt
execute in minecraft:overworld run setblock 233 71 37 coarse_dirt
execute in minecraft:overworld run fill 233 72 37 233 144 37 air
execute in minecraft:overworld run setblock 233 72 37 mossy_cobblestone
execute in minecraft:overworld run fill 233 58 38 233 68 38 stone
execute in minecraft:overworld run fill 233 69 38 233 70 38 dirt
execute in minecraft:overworld run setblock 233 71 38 coarse_dirt
execute in minecraft:overworld run fill 233 72 38 233 144 38 air
execute in minecraft:overworld run fill 233 58 39 233 67 39 stone
execute in minecraft:overworld run fill 233 68 39 233 69 39 dirt
execute in minecraft:overworld run setblock 233 70 39 grass_block
execute in minecraft:overworld run fill 233 71 39 233 144 39 air
execute in minecraft:overworld run fill 233 58 40 233 66 40 stone
execute in minecraft:overworld run fill 233 67 40 233 68 40 dirt
execute in minecraft:overworld run setblock 233 69 40 coarse_dirt
execute in minecraft:overworld run fill 233 70 40 233 144 40 air
execute in minecraft:overworld run fill 233 58 41 233 65 41 stone
execute in minecraft:overworld run fill 233 66 41 233 67 41 dirt
execute in minecraft:overworld run setblock 233 68 41 coarse_dirt
execute in minecraft:overworld run fill 233 69 41 233 144 41 air
execute in minecraft:overworld run setblock 233 69 41 grass
execute in minecraft:overworld run fill 233 58 42 233 64 42 stone
execute in minecraft:overworld run fill 233 65 42 233 66 42 dirt
execute in minecraft:overworld run setblock 233 67 42 grass_block
execute in minecraft:overworld run fill 233 68 42 233 144 42 air
execute in minecraft:overworld run fill 233 58 43 233 63 43 stone
execute in minecraft:overworld run fill 233 64 43 233 65 43 dirt
execute in minecraft:overworld run setblock 233 66 43 coarse_dirt
execute in minecraft:overworld run fill 233 67 43 233 144 43 air
execute in minecraft:overworld run fill 233 58 44 233 63 44 stone
execute in minecraft:overworld run fill 233 64 44 233 65 44 dirt
execute in minecraft:overworld run setblock 233 66 44 grass_block
execute in minecraft:overworld run fill 233 67 44 233 144 44 air
execute in minecraft:overworld run fill 233 58 45 233 62 45 stone
execute in minecraft:overworld run fill 233 63 45 233 64 45 dirt
execute in minecraft:overworld run setblock 233 65 45 coarse_dirt
execute in minecraft:overworld run fill 233 66 45 233 144 45 air
execute in minecraft:overworld run fill 233 58 46 233 62 46 stone
execute in minecraft:overworld run fill 233 63 46 233 64 46 dirt
execute in minecraft:overworld run setblock 233 65 46 coarse_dirt
execute in minecraft:overworld run fill 233 66 46 233 144 46 air
execute in minecraft:overworld run fill 233 58 47 233 61 47 stone
execute in minecraft:overworld run fill 233 62 47 233 63 47 dirt
execute in minecraft:overworld run setblock 233 64 47 grass_block
execute in minecraft:overworld run fill 233 65 47 233 144 47 air
execute in minecraft:overworld run fill 234 58 -48 234 61 -48 stone
execute in minecraft:overworld run fill 234 62 -48 234 63 -48 dirt
execute in minecraft:overworld run setblock 234 64 -48 grass_block
execute in minecraft:overworld run fill 234 65 -48 234 144 -48 air
execute in minecraft:overworld run fill 234 58 -47 234 63 -47 stone
execute in minecraft:overworld run fill 234 64 -47 234 65 -47 dirt
execute in minecraft:overworld run setblock 234 66 -47 coarse_dirt
execute in minecraft:overworld run fill 234 67 -47 234 144 -47 air
execute in minecraft:overworld run fill 234 58 -46 234 64 -46 stone
execute in minecraft:overworld run fill 234 65 -46 234 66 -46 dirt
execute in minecraft:overworld run setblock 234 67 -46 coarse_dirt
execute in minecraft:overworld run fill 234 68 -46 234 144 -46 air
execute in minecraft:overworld run fill 234 58 -45 234 66 -45 stone
execute in minecraft:overworld run fill 234 67 -45 234 68 -45 dirt
execute in minecraft:overworld run setblock 234 69 -45 coarse_dirt
execute in minecraft:overworld run fill 234 70 -45 234 144 -45 air
execute in minecraft:overworld run fill 234 58 -44 234 67 -44 stone
execute in minecraft:overworld run fill 234 68 -44 234 69 -44 dirt
execute in minecraft:overworld run setblock 234 70 -44 grass_block
execute in minecraft:overworld run fill 234 71 -44 234 144 -44 air
execute in minecraft:overworld run fill 234 58 -43 234 68 -43 stone
execute in minecraft:overworld run fill 234 69 -43 234 70 -43 dirt
execute in minecraft:overworld run setblock 234 71 -43 coarse_dirt
execute in minecraft:overworld run fill 234 72 -43 234 144 -43 air
execute in minecraft:overworld run fill 234 58 -42 234 70 -42 stone
execute in minecraft:overworld run fill 234 71 -42 234 72 -42 dirt
execute in minecraft:overworld run setblock 234 73 -42 coarse_dirt
execute in minecraft:overworld run fill 234 74 -42 234 144 -42 air
execute in minecraft:overworld run fill 234 58 -41 234 71 -41 stone
execute in minecraft:overworld run fill 234 72 -41 234 73 -41 dirt
execute in minecraft:overworld run setblock 234 74 -41 coarse_dirt
execute in minecraft:overworld run fill 234 75 -41 234 144 -41 air
execute in minecraft:overworld run fill 234 58 -40 234 72 -40 stone
execute in minecraft:overworld run fill 234 73 -40 234 74 -40 dirt
execute in minecraft:overworld run setblock 234 75 -40 coarse_dirt
execute in minecraft:overworld run fill 234 76 -40 234 144 -40 air
schedule function blade_gallery:random/burned/part_40 1t replace
