execute in minecraft:overworld run setblock 362 78 -33 grass
execute in minecraft:overworld run fill 362 58 -32 362 74 -32 stone
execute in minecraft:overworld run fill 362 75 -32 362 76 -32 dirt
execute in minecraft:overworld run setblock 362 77 -32 coarse_dirt
execute in minecraft:overworld run fill 362 78 -32 362 144 -32 air
execute in minecraft:overworld run fill 362 58 -31 362 74 -31 stone
execute in minecraft:overworld run fill 362 75 -31 362 76 -31 dirt
execute in minecraft:overworld run setblock 362 77 -31 grass_block
execute in minecraft:overworld run fill 362 78 -31 362 144 -31 air
execute in minecraft:overworld run fill 362 58 -30 362 73 -30 stone
execute in minecraft:overworld run fill 362 74 -30 362 75 -30 dirt
execute in minecraft:overworld run setblock 362 76 -30 coarse_dirt
execute in minecraft:overworld run fill 362 77 -30 362 144 -30 air
execute in minecraft:overworld run fill 362 58 -29 362 73 -29 stone
execute in minecraft:overworld run fill 362 74 -29 362 75 -29 dirt
execute in minecraft:overworld run setblock 362 76 -29 grass_block
execute in minecraft:overworld run fill 362 77 -29 362 144 -29 air
execute in minecraft:overworld run fill 362 58 -28 362 73 -28 stone
execute in minecraft:overworld run fill 362 74 -28 362 75 -28 dirt
execute in minecraft:overworld run setblock 362 76 -28 coarse_dirt
execute in minecraft:overworld run fill 362 77 -28 362 144 -28 air
execute in minecraft:overworld run fill 362 58 -27 362 73 -27 stone
execute in minecraft:overworld run fill 362 74 -27 362 75 -27 dirt
execute in minecraft:overworld run setblock 362 76 -27 coarse_dirt
execute in minecraft:overworld run fill 362 77 -27 362 144 -27 air
execute in minecraft:overworld run fill 362 58 -26 362 72 -26 stone
execute in minecraft:overworld run fill 362 73 -26 362 74 -26 dirt
execute in minecraft:overworld run setblock 362 75 -26 coarse_dirt
execute in minecraft:overworld run fill 362 76 -26 362 144 -26 air
execute in minecraft:overworld run fill 362 58 -25 362 72 -25 stone
execute in minecraft:overworld run fill 362 73 -25 362 74 -25 dirt
execute in minecraft:overworld run setblock 362 75 -25 grass_block
execute in minecraft:overworld run fill 362 76 -25 362 144 -25 air
execute in minecraft:overworld run fill 362 58 -24 362 72 -24 stone
execute in minecraft:overworld run fill 362 73 -24 362 74 -24 dirt
execute in minecraft:overworld run setblock 362 75 -24 coarse_dirt
execute in minecraft:overworld run fill 362 76 -24 362 144 -24 air
execute in minecraft:overworld run fill 362 58 -23 362 72 -23 stone
execute in minecraft:overworld run fill 362 73 -23 362 74 -23 dirt
execute in minecraft:overworld run setblock 362 75 -23 coarse_dirt
execute in minecraft:overworld run fill 362 76 -23 362 144 -23 air
execute in minecraft:overworld run setblock 362 76 -23 grass
execute in minecraft:overworld run fill 362 58 -22 362 71 -22 stone
execute in minecraft:overworld run fill 362 72 -22 362 73 -22 dirt
execute in minecraft:overworld run setblock 362 74 -22 coarse_dirt
execute in minecraft:overworld run fill 362 75 -22 362 144 -22 air
execute in minecraft:overworld run fill 362 58 -21 362 71 -21 stone
execute in minecraft:overworld run fill 362 72 -21 362 73 -21 dirt
execute in minecraft:overworld run setblock 362 74 -21 coarse_dirt
execute in minecraft:overworld run fill 362 75 -21 362 144 -21 air
execute in minecraft:overworld run fill 362 58 -20 362 71 -20 stone
execute in minecraft:overworld run fill 362 72 -20 362 73 -20 dirt
execute in minecraft:overworld run setblock 362 74 -20 coarse_dirt
execute in minecraft:overworld run fill 362 75 -20 362 144 -20 air
execute in minecraft:overworld run fill 362 58 -19 362 70 -19 stone
execute in minecraft:overworld run fill 362 71 -19 362 72 -19 dirt
execute in minecraft:overworld run setblock 362 73 -19 grass_block
execute in minecraft:overworld run fill 362 74 -19 362 144 -19 air
execute in minecraft:overworld run setblock 362 74 -19 grass
execute in minecraft:overworld run fill 362 58 -18 362 70 -18 stone
execute in minecraft:overworld run fill 362 71 -18 362 72 -18 dirt
execute in minecraft:overworld run setblock 362 73 -18 coarse_dirt
execute in minecraft:overworld run fill 362 74 -18 362 144 -18 air
execute in minecraft:overworld run setblock 362 74 -18 grass
execute in minecraft:overworld run fill 362 58 -17 362 69 -17 stone
execute in minecraft:overworld run fill 362 70 -17 362 71 -17 dirt
execute in minecraft:overworld run setblock 362 72 -17 grass_block
execute in minecraft:overworld run fill 362 73 -17 362 144 -17 air
execute in minecraft:overworld run fill 362 58 -16 362 69 -16 stone
execute in minecraft:overworld run fill 362 70 -16 362 71 -16 dirt
execute in minecraft:overworld run setblock 362 72 -16 coarse_dirt
execute in minecraft:overworld run fill 362 73 -16 362 144 -16 air
execute in minecraft:overworld run fill 362 58 -15 362 68 -15 stone
execute in minecraft:overworld run fill 362 69 -15 362 70 -15 dirt
execute in minecraft:overworld run setblock 362 71 -15 coarse_dirt
execute in minecraft:overworld run fill 362 72 -15 362 144 -15 air
execute in minecraft:overworld run fill 362 58 -14 362 67 -14 stone
execute in minecraft:overworld run fill 362 68 -14 362 69 -14 dirt
execute in minecraft:overworld run setblock 362 70 -14 coarse_dirt
execute in minecraft:overworld run fill 362 71 -14 362 144 -14 air
execute in minecraft:overworld run fill 362 58 -13 362 67 -13 stone
execute in minecraft:overworld run fill 362 68 -13 362 69 -13 dirt
execute in minecraft:overworld run setblock 362 70 -13 grass_block
execute in minecraft:overworld run fill 362 71 -13 362 144 -13 air
execute in minecraft:overworld run fill 362 58 -12 362 66 -12 stone
execute in minecraft:overworld run fill 362 67 -12 362 68 -12 dirt
execute in minecraft:overworld run setblock 362 69 -12 coarse_dirt
execute in minecraft:overworld run fill 362 70 -12 362 144 -12 air
execute in minecraft:overworld run fill 362 58 -11 362 66 -11 stone
execute in minecraft:overworld run fill 362 67 -11 362 68 -11 dirt
execute in minecraft:overworld run setblock 362 69 -11 grass_block
execute in minecraft:overworld run fill 362 70 -11 362 144 -11 air
execute in minecraft:overworld run fill 362 58 -10 362 65 -10 stone
execute in minecraft:overworld run fill 362 66 -10 362 67 -10 dirt
execute in minecraft:overworld run setblock 362 68 -10 coarse_dirt
execute in minecraft:overworld run fill 362 69 -10 362 144 -10 air
execute in minecraft:overworld run fill 362 58 -9 362 65 -9 stone
execute in minecraft:overworld run fill 362 66 -9 362 67 -9 dirt
execute in minecraft:overworld run setblock 362 68 -9 coarse_dirt
execute in minecraft:overworld run fill 362 69 -9 362 144 -9 air
execute in minecraft:overworld run fill 362 58 -8 362 65 -8 stone
execute in minecraft:overworld run fill 362 66 -8 362 67 -8 dirt
execute in minecraft:overworld run setblock 362 68 -8 grass_block
execute in minecraft:overworld run fill 362 69 -8 362 144 -8 air
execute in minecraft:overworld run fill 362 58 -7 362 65 -7 stone
execute in minecraft:overworld run fill 362 66 -7 362 67 -7 dirt
execute in minecraft:overworld run setblock 362 68 -7 grass_block
execute in minecraft:overworld run fill 362 69 -7 362 144 -7 air
execute in minecraft:overworld run fill 362 58 -6 362 65 -6 stone
execute in minecraft:overworld run fill 362 66 -6 362 67 -6 dirt
execute in minecraft:overworld run setblock 362 68 -6 coarse_dirt
execute in minecraft:overworld run fill 362 69 -6 362 144 -6 air
execute in minecraft:overworld run fill 362 58 -5 362 65 -5 stone
execute in minecraft:overworld run fill 362 66 -5 362 67 -5 dirt
execute in minecraft:overworld run setblock 362 68 -5 coarse_dirt
execute in minecraft:overworld run fill 362 69 -5 362 144 -5 air
execute in minecraft:overworld run fill 362 58 -4 362 65 -4 stone
execute in minecraft:overworld run fill 362 66 -4 362 67 -4 dirt
execute in minecraft:overworld run setblock 362 68 -4 coarse_dirt
execute in minecraft:overworld run fill 362 69 -4 362 144 -4 air
execute in minecraft:overworld run fill 362 58 -3 362 65 -3 stone
execute in minecraft:overworld run fill 362 66 -3 362 67 -3 dirt
execute in minecraft:overworld run setblock 362 68 -3 coarse_dirt
execute in minecraft:overworld run fill 362 69 -3 362 144 -3 air
execute in minecraft:overworld run fill 362 58 -2 362 65 -2 stone
execute in minecraft:overworld run fill 362 66 -2 362 67 -2 dirt
execute in minecraft:overworld run setblock 362 68 -2 grass_block
execute in minecraft:overworld run fill 362 69 -2 362 144 -2 air
execute in minecraft:overworld run fill 362 58 -1 362 65 -1 stone
execute in minecraft:overworld run fill 362 66 -1 362 67 -1 dirt
execute in minecraft:overworld run setblock 362 68 -1 coarse_dirt
execute in minecraft:overworld run fill 362 69 -1 362 144 -1 air
execute in minecraft:overworld run fill 362 58 0 362 65 0 stone
execute in minecraft:overworld run fill 362 66 0 362 67 0 dirt
execute in minecraft:overworld run setblock 362 68 0 coarse_dirt
execute in minecraft:overworld run fill 362 69 0 362 144 0 air
execute in minecraft:overworld run fill 362 58 1 362 65 1 stone
execute in minecraft:overworld run fill 362 66 1 362 67 1 dirt
execute in minecraft:overworld run setblock 362 68 1 coarse_dirt
execute in minecraft:overworld run fill 362 69 1 362 144 1 air
execute in minecraft:overworld run fill 362 58 2 362 65 2 stone
execute in minecraft:overworld run fill 362 66 2 362 67 2 dirt
execute in minecraft:overworld run setblock 362 68 2 coarse_dirt
execute in minecraft:overworld run fill 362 69 2 362 144 2 air
execute in minecraft:overworld run setblock 362 69 2 grass
execute in minecraft:overworld run fill 362 58 3 362 66 3 stone
execute in minecraft:overworld run fill 362 67 3 362 68 3 dirt
execute in minecraft:overworld run setblock 362 69 3 coarse_dirt
execute in minecraft:overworld run fill 362 70 3 362 144 3 air
execute in minecraft:overworld run fill 362 58 4 362 66 4 stone
execute in minecraft:overworld run fill 362 67 4 362 68 4 dirt
execute in minecraft:overworld run setblock 362 69 4 coarse_dirt
execute in minecraft:overworld run fill 362 70 4 362 144 4 air
execute in minecraft:overworld run setblock 362 70 4 grass
execute in minecraft:overworld run fill 362 58 5 362 66 5 stone
execute in minecraft:overworld run fill 362 67 5 362 68 5 dirt
execute in minecraft:overworld run setblock 362 69 5 coarse_dirt
execute in minecraft:overworld run fill 362 70 5 362 144 5 air
execute in minecraft:overworld run setblock 362 70 5 grass
execute in minecraft:overworld run fill 362 58 6 362 67 6 stone
execute in minecraft:overworld run fill 362 68 6 362 69 6 dirt
execute in minecraft:overworld run setblock 362 70 6 grass_block
execute in minecraft:overworld run fill 362 71 6 362 144 6 air
execute in minecraft:overworld run fill 362 58 7 362 67 7 stone
execute in minecraft:overworld run fill 362 68 7 362 69 7 dirt
execute in minecraft:overworld run setblock 362 70 7 coarse_dirt
execute in minecraft:overworld run fill 362 71 7 362 144 7 air
execute in minecraft:overworld run fill 362 58 8 362 68 8 stone
execute in minecraft:overworld run fill 362 69 8 362 70 8 dirt
execute in minecraft:overworld run setblock 362 71 8 grass_block
execute in minecraft:overworld run fill 362 72 8 362 144 8 air
execute in minecraft:overworld run fill 362 58 9 362 68 9 stone
execute in minecraft:overworld run fill 362 69 9 362 70 9 dirt
execute in minecraft:overworld run setblock 362 71 9 coarse_dirt
execute in minecraft:overworld run fill 362 72 9 362 144 9 air
execute in minecraft:overworld run fill 362 58 10 362 68 10 stone
execute in minecraft:overworld run fill 362 69 10 362 70 10 dirt
execute in minecraft:overworld run setblock 362 71 10 coarse_dirt
execute in minecraft:overworld run fill 362 72 10 362 144 10 air
execute in minecraft:overworld run fill 362 58 11 362 68 11 stone
execute in minecraft:overworld run fill 362 69 11 362 70 11 dirt
execute in minecraft:overworld run setblock 362 71 11 coarse_dirt
execute in minecraft:overworld run fill 362 72 11 362 144 11 air
execute in minecraft:overworld run fill 362 58 12 362 68 12 stone
execute in minecraft:overworld run fill 362 69 12 362 70 12 dirt
execute in minecraft:overworld run setblock 362 71 12 grass_block
execute in minecraft:overworld run fill 362 72 12 362 144 12 air
execute in minecraft:overworld run fill 362 58 13 362 68 13 stone
execute in minecraft:overworld run fill 362 69 13 362 70 13 dirt
execute in minecraft:overworld run setblock 362 71 13 coarse_dirt
execute in minecraft:overworld run fill 362 72 13 362 144 13 air
execute in minecraft:overworld run fill 362 58 14 362 68 14 stone
execute in minecraft:overworld run fill 362 69 14 362 70 14 dirt
execute in minecraft:overworld run setblock 362 71 14 coarse_dirt
execute in minecraft:overworld run fill 362 72 14 362 144 14 air
execute in minecraft:overworld run fill 362 58 15 362 69 15 stone
execute in minecraft:overworld run fill 362 70 15 362 71 15 dirt
execute in minecraft:overworld run setblock 362 72 15 coarse_dirt
execute in minecraft:overworld run fill 362 73 15 362 144 15 air
execute in minecraft:overworld run fill 362 58 16 362 69 16 stone
execute in minecraft:overworld run fill 362 70 16 362 71 16 dirt
execute in minecraft:overworld run setblock 362 72 16 coarse_dirt
execute in minecraft:overworld run fill 362 73 16 362 144 16 air
execute in minecraft:overworld run fill 362 58 17 362 69 17 stone
execute in minecraft:overworld run fill 362 70 17 362 71 17 dirt
execute in minecraft:overworld run setblock 362 72 17 coarse_dirt
execute in minecraft:overworld run fill 362 73 17 362 144 17 air
execute in minecraft:overworld run fill 362 58 18 362 69 18 stone
execute in minecraft:overworld run fill 362 70 18 362 71 18 dirt
execute in minecraft:overworld run setblock 362 72 18 coarse_dirt
execute in minecraft:overworld run fill 362 73 18 362 144 18 air
execute in minecraft:overworld run setblock 362 73 18 grass
execute in minecraft:overworld run fill 362 58 19 362 69 19 stone
execute in minecraft:overworld run fill 362 70 19 362 71 19 dirt
execute in minecraft:overworld run setblock 362 72 19 coarse_dirt
execute in minecraft:overworld run fill 362 73 19 362 144 19 air
execute in minecraft:overworld run fill 362 58 20 362 69 20 stone
execute in minecraft:overworld run fill 362 70 20 362 71 20 dirt
execute in minecraft:overworld run setblock 362 72 20 coarse_dirt
execute in minecraft:overworld run fill 362 73 20 362 144 20 air
execute in minecraft:overworld run fill 362 58 21 362 69 21 stone
execute in minecraft:overworld run fill 362 70 21 362 71 21 dirt
execute in minecraft:overworld run setblock 362 72 21 coarse_dirt
execute in minecraft:overworld run fill 362 73 21 362 144 21 air
execute in minecraft:overworld run setblock 362 73 21 grass
execute in minecraft:overworld run fill 362 58 22 362 69 22 stone
execute in minecraft:overworld run fill 362 70 22 362 71 22 dirt
execute in minecraft:overworld run setblock 362 72 22 coarse_dirt
execute in minecraft:overworld run fill 362 73 22 362 144 22 air
execute in minecraft:overworld run fill 362 58 23 362 69 23 stone
execute in minecraft:overworld run fill 362 70 23 362 71 23 dirt
execute in minecraft:overworld run setblock 362 72 23 grass_block
execute in minecraft:overworld run fill 362 73 23 362 144 23 air
execute in minecraft:overworld run fill 362 58 24 362 69 24 stone
execute in minecraft:overworld run fill 362 70 24 362 71 24 dirt
execute in minecraft:overworld run setblock 362 72 24 coarse_dirt
execute in minecraft:overworld run fill 362 73 24 362 144 24 air
execute in minecraft:overworld run fill 362 58 25 362 69 25 stone
execute in minecraft:overworld run fill 362 70 25 362 71 25 dirt
execute in minecraft:overworld run setblock 362 72 25 coarse_dirt
execute in minecraft:overworld run fill 362 73 25 362 144 25 air
execute in minecraft:overworld run fill 362 58 26 362 69 26 stone
execute in minecraft:overworld run fill 362 70 26 362 71 26 dirt
execute in minecraft:overworld run setblock 362 72 26 coarse_dirt
execute in minecraft:overworld run fill 362 73 26 362 144 26 air
execute in minecraft:overworld run fill 362 58 27 362 69 27 stone
execute in minecraft:overworld run fill 362 70 27 362 71 27 dirt
execute in minecraft:overworld run setblock 362 72 27 coarse_dirt
execute in minecraft:overworld run fill 362 73 27 362 144 27 air
execute in minecraft:overworld run fill 362 58 28 362 69 28 stone
execute in minecraft:overworld run fill 362 70 28 362 71 28 dirt
execute in minecraft:overworld run setblock 362 72 28 grass_block
execute in minecraft:overworld run fill 362 73 28 362 144 28 air
execute in minecraft:overworld run fill 362 58 29 362 69 29 stone
execute in minecraft:overworld run fill 362 70 29 362 71 29 dirt
execute in minecraft:overworld run setblock 362 72 29 grass_block
schedule function blade_gallery:random/battlefield/part_41 1t replace
