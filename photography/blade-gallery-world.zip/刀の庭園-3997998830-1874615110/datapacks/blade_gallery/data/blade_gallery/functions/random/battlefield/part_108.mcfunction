execute in minecraft:overworld run fill 404 65 -1 404 144 -1 air
execute in minecraft:overworld run fill 404 58 0 404 60 0 stone
execute in minecraft:overworld run fill 404 61 0 404 62 0 dirt
execute in minecraft:overworld run setblock 404 63 0 gravel
execute in minecraft:overworld run fill 404 64 0 404 144 0 air
execute in minecraft:overworld run fill 404 64 0 404 64 0 water
execute in minecraft:overworld run fill 404 58 1 404 60 1 stone
execute in minecraft:overworld run fill 404 61 1 404 62 1 dirt
execute in minecraft:overworld run setblock 404 63 1 gravel
execute in minecraft:overworld run fill 404 64 1 404 144 1 air
execute in minecraft:overworld run fill 404 64 1 404 64 1 water
execute in minecraft:overworld run fill 404 58 2 404 60 2 stone
execute in minecraft:overworld run fill 404 61 2 404 62 2 dirt
execute in minecraft:overworld run setblock 404 63 2 gravel
execute in minecraft:overworld run fill 404 64 2 404 144 2 air
execute in minecraft:overworld run fill 404 64 2 404 64 2 water
execute in minecraft:overworld run fill 404 58 3 404 60 3 stone
execute in minecraft:overworld run fill 404 61 3 404 62 3 dirt
execute in minecraft:overworld run setblock 404 63 3 gravel
execute in minecraft:overworld run fill 404 64 3 404 144 3 air
execute in minecraft:overworld run fill 404 64 3 404 64 3 water
execute in minecraft:overworld run fill 404 58 4 404 60 4 stone
execute in minecraft:overworld run fill 404 61 4 404 62 4 dirt
execute in minecraft:overworld run setblock 404 63 4 gravel
execute in minecraft:overworld run fill 404 64 4 404 144 4 air
execute in minecraft:overworld run fill 404 64 4 404 64 4 water
execute in minecraft:overworld run fill 404 58 5 404 60 5 stone
execute in minecraft:overworld run fill 404 61 5 404 62 5 dirt
execute in minecraft:overworld run setblock 404 63 5 gravel
execute in minecraft:overworld run fill 404 64 5 404 144 5 air
execute in minecraft:overworld run fill 404 64 5 404 64 5 water
execute in minecraft:overworld run fill 404 58 6 404 60 6 stone
execute in minecraft:overworld run fill 404 61 6 404 62 6 dirt
execute in minecraft:overworld run setblock 404 63 6 gravel
execute in minecraft:overworld run fill 404 64 6 404 144 6 air
execute in minecraft:overworld run fill 404 64 6 404 64 6 water
execute in minecraft:overworld run fill 404 58 7 404 60 7 stone
execute in minecraft:overworld run fill 404 61 7 404 62 7 dirt
execute in minecraft:overworld run setblock 404 63 7 gravel
execute in minecraft:overworld run fill 404 64 7 404 144 7 air
execute in minecraft:overworld run fill 404 64 7 404 64 7 water
execute in minecraft:overworld run fill 404 58 8 404 60 8 stone
execute in minecraft:overworld run fill 404 61 8 404 62 8 dirt
execute in minecraft:overworld run setblock 404 63 8 gravel
execute in minecraft:overworld run fill 404 64 8 404 144 8 air
execute in minecraft:overworld run fill 404 64 8 404 64 8 water
execute in minecraft:overworld run fill 404 58 9 404 60 9 stone
execute in minecraft:overworld run fill 404 61 9 404 62 9 dirt
execute in minecraft:overworld run setblock 404 63 9 gravel
execute in minecraft:overworld run fill 404 64 9 404 144 9 air
execute in minecraft:overworld run fill 404 64 9 404 64 9 water
execute in minecraft:overworld run fill 404 58 10 404 61 10 stone
execute in minecraft:overworld run fill 404 62 10 404 63 10 dirt
execute in minecraft:overworld run setblock 404 64 10 grass_block
execute in minecraft:overworld run fill 404 65 10 404 144 10 air
execute in minecraft:overworld run fill 404 58 11 404 61 11 stone
execute in minecraft:overworld run fill 404 62 11 404 63 11 dirt
execute in minecraft:overworld run setblock 404 64 11 coarse_dirt
execute in minecraft:overworld run fill 404 65 11 404 144 11 air
execute in minecraft:overworld run fill 404 58 12 404 61 12 stone
execute in minecraft:overworld run fill 404 62 12 404 63 12 dirt
execute in minecraft:overworld run setblock 404 64 12 coarse_dirt
execute in minecraft:overworld run fill 404 65 12 404 144 12 air
execute in minecraft:overworld run fill 404 58 13 404 61 13 stone
execute in minecraft:overworld run fill 404 62 13 404 63 13 dirt
execute in minecraft:overworld run setblock 404 64 13 coarse_dirt
execute in minecraft:overworld run fill 404 65 13 404 144 13 air
execute in minecraft:overworld run fill 404 58 14 404 62 14 stone
execute in minecraft:overworld run fill 404 63 14 404 64 14 dirt
execute in minecraft:overworld run setblock 404 65 14 coarse_dirt
execute in minecraft:overworld run fill 404 66 14 404 144 14 air
execute in minecraft:overworld run fill 404 58 15 404 62 15 stone
execute in minecraft:overworld run fill 404 63 15 404 64 15 dirt
execute in minecraft:overworld run setblock 404 65 15 coarse_dirt
execute in minecraft:overworld run fill 404 66 15 404 144 15 air
execute in minecraft:overworld run fill 404 58 16 404 62 16 stone
execute in minecraft:overworld run fill 404 63 16 404 64 16 dirt
execute in minecraft:overworld run setblock 404 65 16 grass_block
execute in minecraft:overworld run fill 404 66 16 404 144 16 air
execute in minecraft:overworld run fill 404 58 17 404 63 17 stone
execute in minecraft:overworld run fill 404 64 17 404 65 17 dirt
execute in minecraft:overworld run setblock 404 66 17 grass_block
execute in minecraft:overworld run fill 404 67 17 404 144 17 air
execute in minecraft:overworld run fill 404 58 18 404 63 18 stone
execute in minecraft:overworld run fill 404 64 18 404 65 18 dirt
execute in minecraft:overworld run setblock 404 66 18 coarse_dirt
execute in minecraft:overworld run fill 404 67 18 404 144 18 air
execute in minecraft:overworld run fill 404 58 19 404 63 19 stone
execute in minecraft:overworld run fill 404 64 19 404 65 19 dirt
execute in minecraft:overworld run setblock 404 66 19 coarse_dirt
execute in minecraft:overworld run fill 404 67 19 404 144 19 air
execute in minecraft:overworld run fill 404 58 20 404 64 20 stone
execute in minecraft:overworld run fill 404 65 20 404 66 20 dirt
execute in minecraft:overworld run setblock 404 67 20 coarse_dirt
execute in minecraft:overworld run fill 404 68 20 404 144 20 air
execute in minecraft:overworld run fill 404 58 21 404 64 21 stone
execute in minecraft:overworld run fill 404 65 21 404 66 21 dirt
execute in minecraft:overworld run setblock 404 67 21 coarse_dirt
execute in minecraft:overworld run fill 404 68 21 404 144 21 air
execute in minecraft:overworld run setblock 404 68 21 grass
execute in minecraft:overworld run fill 404 58 22 404 65 22 stone
execute in minecraft:overworld run fill 404 66 22 404 67 22 dirt
execute in minecraft:overworld run setblock 404 68 22 grass_block
execute in minecraft:overworld run fill 404 69 22 404 144 22 air
execute in minecraft:overworld run fill 404 58 23 404 65 23 stone
execute in minecraft:overworld run fill 404 66 23 404 67 23 dirt
execute in minecraft:overworld run setblock 404 68 23 coarse_dirt
execute in minecraft:overworld run fill 404 69 23 404 144 23 air
execute in minecraft:overworld run fill 404 58 24 404 65 24 stone
execute in minecraft:overworld run fill 404 66 24 404 67 24 dirt
execute in minecraft:overworld run setblock 404 68 24 coarse_dirt
execute in minecraft:overworld run fill 404 69 24 404 144 24 air
execute in minecraft:overworld run fill 404 58 25 404 66 25 stone
execute in minecraft:overworld run fill 404 67 25 404 68 25 dirt
execute in minecraft:overworld run setblock 404 69 25 coarse_dirt
execute in minecraft:overworld run fill 404 70 25 404 144 25 air
execute in minecraft:overworld run fill 404 58 26 404 66 26 stone
execute in minecraft:overworld run fill 404 67 26 404 68 26 dirt
execute in minecraft:overworld run setblock 404 69 26 coarse_dirt
execute in minecraft:overworld run fill 404 70 26 404 144 26 air
execute in minecraft:overworld run fill 404 58 27 404 66 27 stone
execute in minecraft:overworld run fill 404 67 27 404 68 27 dirt
execute in minecraft:overworld run setblock 404 69 27 coarse_dirt
execute in minecraft:overworld run fill 404 70 27 404 144 27 air
execute in minecraft:overworld run setblock 404 70 27 mossy_cobblestone
execute in minecraft:overworld run fill 404 58 28 404 66 28 stone
execute in minecraft:overworld run fill 404 67 28 404 68 28 dirt
execute in minecraft:overworld run setblock 404 69 28 coarse_dirt
execute in minecraft:overworld run fill 404 70 28 404 144 28 air
execute in minecraft:overworld run setblock 404 70 28 grass
execute in minecraft:overworld run fill 404 58 29 404 66 29 stone
execute in minecraft:overworld run fill 404 67 29 404 68 29 dirt
execute in minecraft:overworld run setblock 404 69 29 coarse_dirt
execute in minecraft:overworld run fill 404 70 29 404 144 29 air
execute in minecraft:overworld run setblock 404 70 29 grass
execute in minecraft:overworld run fill 404 58 30 404 66 30 stone
execute in minecraft:overworld run fill 404 67 30 404 68 30 dirt
execute in minecraft:overworld run setblock 404 69 30 grass_block
execute in minecraft:overworld run fill 404 70 30 404 144 30 air
execute in minecraft:overworld run setblock 404 70 30 grass
execute in minecraft:overworld run fill 404 58 31 404 66 31 stone
execute in minecraft:overworld run fill 404 67 31 404 68 31 dirt
execute in minecraft:overworld run setblock 404 69 31 coarse_dirt
execute in minecraft:overworld run fill 404 70 31 404 144 31 air
execute in minecraft:overworld run fill 404 58 32 404 66 32 stone
execute in minecraft:overworld run fill 404 67 32 404 68 32 dirt
execute in minecraft:overworld run setblock 404 69 32 grass_block
execute in minecraft:overworld run fill 404 70 32 404 144 32 air
execute in minecraft:overworld run fill 404 58 33 404 66 33 stone
execute in minecraft:overworld run fill 404 67 33 404 68 33 dirt
execute in minecraft:overworld run setblock 404 69 33 coarse_dirt
execute in minecraft:overworld run fill 404 70 33 404 144 33 air
execute in minecraft:overworld run fill 404 58 34 404 66 34 stone
execute in minecraft:overworld run fill 404 67 34 404 68 34 dirt
execute in minecraft:overworld run setblock 404 69 34 coarse_dirt
execute in minecraft:overworld run fill 404 70 34 404 144 34 air
execute in minecraft:overworld run fill 404 58 35 404 66 35 stone
execute in minecraft:overworld run fill 404 67 35 404 68 35 dirt
execute in minecraft:overworld run setblock 404 69 35 coarse_dirt
execute in minecraft:overworld run fill 404 70 35 404 144 35 air
execute in minecraft:overworld run fill 404 58 36 404 66 36 stone
execute in minecraft:overworld run fill 404 67 36 404 68 36 dirt
execute in minecraft:overworld run setblock 404 69 36 grass_block
execute in minecraft:overworld run fill 404 70 36 404 144 36 air
execute in minecraft:overworld run setblock 404 70 36 grass
execute in minecraft:overworld run fill 404 58 37 404 66 37 stone
execute in minecraft:overworld run fill 404 67 37 404 68 37 dirt
execute in minecraft:overworld run setblock 404 69 37 grass_block
execute in minecraft:overworld run fill 404 70 37 404 144 37 air
execute in minecraft:overworld run fill 404 58 38 404 66 38 stone
execute in minecraft:overworld run fill 404 67 38 404 68 38 dirt
execute in minecraft:overworld run setblock 404 69 38 grass_block
execute in minecraft:overworld run fill 404 70 38 404 144 38 air
execute in minecraft:overworld run fill 404 58 39 404 66 39 stone
execute in minecraft:overworld run fill 404 67 39 404 68 39 dirt
execute in minecraft:overworld run setblock 404 69 39 grass_block
execute in minecraft:overworld run fill 404 70 39 404 144 39 air
execute in minecraft:overworld run fill 404 58 40 404 65 40 stone
execute in minecraft:overworld run fill 404 66 40 404 67 40 dirt
execute in minecraft:overworld run setblock 404 68 40 coarse_dirt
execute in minecraft:overworld run fill 404 69 40 404 144 40 air
execute in minecraft:overworld run setblock 404 69 40 grass
execute in minecraft:overworld run fill 404 58 41 404 65 41 stone
execute in minecraft:overworld run fill 404 66 41 404 67 41 dirt
execute in minecraft:overworld run setblock 404 68 41 coarse_dirt
execute in minecraft:overworld run fill 404 69 41 404 144 41 air
execute in minecraft:overworld run fill 404 58 42 404 65 42 stone
execute in minecraft:overworld run fill 404 66 42 404 67 42 dirt
execute in minecraft:overworld run setblock 404 68 42 coarse_dirt
execute in minecraft:overworld run fill 404 69 42 404 144 42 air
execute in minecraft:overworld run fill 404 58 43 404 64 43 stone
execute in minecraft:overworld run fill 404 65 43 404 66 43 dirt
execute in minecraft:overworld run setblock 404 67 43 coarse_dirt
execute in minecraft:overworld run fill 404 68 43 404 144 43 air
execute in minecraft:overworld run fill 404 58 44 404 64 44 stone
execute in minecraft:overworld run fill 404 65 44 404 66 44 dirt
execute in minecraft:overworld run setblock 404 67 44 coarse_dirt
execute in minecraft:overworld run fill 404 68 44 404 144 44 air
execute in minecraft:overworld run fill 404 58 45 404 63 45 stone
execute in minecraft:overworld run fill 404 64 45 404 65 45 dirt
execute in minecraft:overworld run setblock 404 66 45 coarse_dirt
execute in minecraft:overworld run fill 404 67 45 404 144 45 air
execute in minecraft:overworld run fill 404 58 46 404 62 46 stone
execute in minecraft:overworld run fill 404 63 46 404 64 46 dirt
execute in minecraft:overworld run setblock 404 65 46 grass_block
execute in minecraft:overworld run fill 404 66 46 404 144 46 air
execute in minecraft:overworld run fill 404 58 47 404 62 47 stone
execute in minecraft:overworld run fill 404 63 47 404 64 47 dirt
execute in minecraft:overworld run setblock 404 65 47 coarse_dirt
execute in minecraft:overworld run fill 404 66 47 404 144 47 air
execute in minecraft:overworld run fill 405 58 -48 405 61 -48 stone
execute in minecraft:overworld run fill 405 62 -48 405 63 -48 dirt
execute in minecraft:overworld run setblock 405 64 -48 coarse_dirt
execute in minecraft:overworld run fill 405 65 -48 405 144 -48 air
execute in minecraft:overworld run fill 405 58 -47 405 63 -47 stone
execute in minecraft:overworld run fill 405 64 -47 405 65 -47 dirt
execute in minecraft:overworld run setblock 405 66 -47 coarse_dirt
execute in minecraft:overworld run fill 405 67 -47 405 144 -47 air
execute in minecraft:overworld run fill 405 58 -46 405 64 -46 stone
execute in minecraft:overworld run fill 405 65 -46 405 66 -46 dirt
execute in minecraft:overworld run setblock 405 67 -46 coarse_dirt
execute in minecraft:overworld run fill 405 68 -46 405 144 -46 air
execute in minecraft:overworld run fill 405 58 -45 405 66 -45 stone
execute in minecraft:overworld run fill 405 67 -45 405 68 -45 dirt
execute in minecraft:overworld run setblock 405 69 -45 grass_block
execute in minecraft:overworld run fill 405 70 -45 405 144 -45 air
execute in minecraft:overworld run fill 405 58 -44 405 67 -44 stone
execute in minecraft:overworld run fill 405 68 -44 405 69 -44 dirt
execute in minecraft:overworld run setblock 405 70 -44 coarse_dirt
execute in minecraft:overworld run fill 405 71 -44 405 144 -44 air
execute in minecraft:overworld run fill 405 58 -43 405 69 -43 stone
execute in minecraft:overworld run fill 405 70 -43 405 71 -43 dirt
execute in minecraft:overworld run setblock 405 72 -43 coarse_dirt
execute in minecraft:overworld run fill 405 73 -43 405 144 -43 air
execute in minecraft:overworld run fill 405 58 -42 405 70 -42 stone
execute in minecraft:overworld run fill 405 71 -42 405 72 -42 dirt
execute in minecraft:overworld run setblock 405 73 -42 coarse_dirt
execute in minecraft:overworld run fill 405 74 -42 405 144 -42 air
execute in minecraft:overworld run fill 405 58 -41 405 72 -41 stone
execute in minecraft:overworld run fill 405 73 -41 405 74 -41 dirt
execute in minecraft:overworld run setblock 405 75 -41 coarse_dirt
execute in minecraft:overworld run fill 405 76 -41 405 144 -41 air
execute in minecraft:overworld run fill 405 58 -40 405 73 -40 stone
execute in minecraft:overworld run fill 405 74 -40 405 75 -40 dirt
execute in minecraft:overworld run setblock 405 76 -40 coarse_dirt
execute in minecraft:overworld run fill 405 77 -40 405 144 -40 air
execute in minecraft:overworld run fill 405 58 -39 405 74 -39 stone
execute in minecraft:overworld run fill 405 75 -39 405 76 -39 dirt
execute in minecraft:overworld run setblock 405 77 -39 coarse_dirt
execute in minecraft:overworld run fill 405 78 -39 405 144 -39 air
execute in minecraft:overworld run setblock 405 78 -39 grass
execute in minecraft:overworld run fill 405 58 -38 405 76 -38 stone
execute in minecraft:overworld run fill 405 77 -38 405 78 -38 dirt
execute in minecraft:overworld run setblock 405 79 -38 grass_block
execute in minecraft:overworld run fill 405 80 -38 405 144 -38 air
execute in minecraft:overworld run fill 405 58 -37 405 75 -37 stone
schedule function blade_gallery:random/battlefield/part_109 1t replace
