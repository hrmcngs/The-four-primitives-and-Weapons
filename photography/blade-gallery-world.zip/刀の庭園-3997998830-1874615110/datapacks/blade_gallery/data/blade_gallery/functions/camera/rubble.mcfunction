execute in minecraft:overworld run tp @s 118 74 22 facing 128 76 -12
