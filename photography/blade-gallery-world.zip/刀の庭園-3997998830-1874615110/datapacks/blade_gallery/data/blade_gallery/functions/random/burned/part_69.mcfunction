execute in minecraft:overworld run setblock 252 68 33 coarse_dirt
execute in minecraft:overworld run fill 252 69 33 252 144 33 air
execute in minecraft:overworld run fill 252 58 34 252 65 34 stone
execute in minecraft:overworld run fill 252 66 34 252 67 34 dirt
execute in minecraft:overworld run setblock 252 68 34 coarse_dirt
execute in minecraft:overworld run fill 252 69 34 252 144 34 air
execute in minecraft:overworld run fill 252 58 35 252 64 35 stone
execute in minecraft:overworld run fill 252 65 35 252 66 35 dirt
execute in minecraft:overworld run setblock 252 67 35 grass_block
execute in minecraft:overworld run fill 252 68 35 252 144 35 air
execute in minecraft:overworld run fill 252 58 36 252 64 36 stone
execute in minecraft:overworld run fill 252 65 36 252 66 36 dirt
execute in minecraft:overworld run setblock 252 67 36 coarse_dirt
execute in minecraft:overworld run fill 252 68 36 252 144 36 air
execute in minecraft:overworld run fill 252 58 37 252 63 37 stone
execute in minecraft:overworld run fill 252 64 37 252 65 37 dirt
execute in minecraft:overworld run setblock 252 66 37 grass_block
execute in minecraft:overworld run fill 252 67 37 252 144 37 air
execute in minecraft:overworld run fill 252 58 38 252 63 38 stone
execute in minecraft:overworld run fill 252 64 38 252 65 38 dirt
execute in minecraft:overworld run setblock 252 66 38 coarse_dirt
execute in minecraft:overworld run fill 252 67 38 252 144 38 air
execute in minecraft:overworld run fill 252 58 39 252 62 39 stone
execute in minecraft:overworld run fill 252 63 39 252 64 39 dirt
execute in minecraft:overworld run setblock 252 65 39 coarse_dirt
execute in minecraft:overworld run fill 252 66 39 252 144 39 air
execute in minecraft:overworld run fill 252 58 40 252 61 40 stone
execute in minecraft:overworld run fill 252 62 40 252 63 40 dirt
execute in minecraft:overworld run setblock 252 64 40 coarse_dirt
execute in minecraft:overworld run fill 252 65 40 252 144 40 air
execute in minecraft:overworld run fill 252 58 41 252 61 41 stone
execute in minecraft:overworld run fill 252 62 41 252 63 41 dirt
execute in minecraft:overworld run setblock 252 64 41 coarse_dirt
execute in minecraft:overworld run fill 252 65 41 252 144 41 air
execute in minecraft:overworld run fill 252 58 42 252 60 42 stone
execute in minecraft:overworld run fill 252 61 42 252 62 42 dirt
execute in minecraft:overworld run setblock 252 63 42 gravel
execute in minecraft:overworld run fill 252 64 42 252 144 42 air
execute in minecraft:overworld run fill 252 64 42 252 64 42 water
execute in minecraft:overworld run fill 252 58 43 252 60 43 stone
execute in minecraft:overworld run fill 252 61 43 252 62 43 dirt
execute in minecraft:overworld run setblock 252 63 43 gravel
execute in minecraft:overworld run fill 252 64 43 252 144 43 air
execute in minecraft:overworld run fill 252 64 43 252 64 43 water
execute in minecraft:overworld run fill 252 58 44 252 60 44 stone
execute in minecraft:overworld run fill 252 61 44 252 62 44 dirt
execute in minecraft:overworld run setblock 252 63 44 gravel
execute in minecraft:overworld run fill 252 64 44 252 144 44 air
execute in minecraft:overworld run fill 252 64 44 252 64 44 water
execute in minecraft:overworld run fill 252 58 45 252 60 45 stone
execute in minecraft:overworld run fill 252 61 45 252 62 45 dirt
execute in minecraft:overworld run setblock 252 63 45 gravel
execute in minecraft:overworld run fill 252 64 45 252 144 45 air
execute in minecraft:overworld run fill 252 64 45 252 64 45 water
execute in minecraft:overworld run fill 252 58 46 252 60 46 stone
execute in minecraft:overworld run fill 252 61 46 252 62 46 dirt
execute in minecraft:overworld run setblock 252 63 46 gravel
execute in minecraft:overworld run fill 252 64 46 252 144 46 air
execute in minecraft:overworld run fill 252 64 46 252 64 46 water
execute in minecraft:overworld run fill 252 58 47 252 61 47 stone
execute in minecraft:overworld run fill 252 62 47 252 63 47 dirt
execute in minecraft:overworld run setblock 252 64 47 coarse_dirt
execute in minecraft:overworld run fill 252 65 47 252 144 47 air
execute in minecraft:overworld run fill 253 58 -48 253 61 -48 stone
execute in minecraft:overworld run fill 253 62 -48 253 63 -48 dirt
execute in minecraft:overworld run setblock 253 64 -48 grass_block
execute in minecraft:overworld run fill 253 65 -48 253 144 -48 air
execute in minecraft:overworld run fill 253 58 -47 253 62 -47 stone
execute in minecraft:overworld run fill 253 63 -47 253 64 -47 dirt
execute in minecraft:overworld run setblock 253 65 -47 coarse_dirt
execute in minecraft:overworld run fill 253 66 -47 253 144 -47 air
execute in minecraft:overworld run fill 253 58 -46 253 63 -46 stone
execute in minecraft:overworld run fill 253 64 -46 253 65 -46 dirt
execute in minecraft:overworld run setblock 253 66 -46 coarse_dirt
execute in minecraft:overworld run fill 253 67 -46 253 144 -46 air
execute in minecraft:overworld run fill 253 58 -45 253 64 -45 stone
execute in minecraft:overworld run fill 253 65 -45 253 66 -45 dirt
execute in minecraft:overworld run setblock 253 67 -45 coarse_dirt
execute in minecraft:overworld run fill 253 68 -45 253 144 -45 air
execute in minecraft:overworld run fill 253 58 -44 253 66 -44 stone
execute in minecraft:overworld run fill 253 67 -44 253 68 -44 dirt
execute in minecraft:overworld run setblock 253 69 -44 coarse_dirt
execute in minecraft:overworld run fill 253 70 -44 253 144 -44 air
execute in minecraft:overworld run fill 253 58 -43 253 67 -43 stone
execute in minecraft:overworld run fill 253 68 -43 253 69 -43 dirt
execute in minecraft:overworld run setblock 253 70 -43 grass_block
execute in minecraft:overworld run fill 253 71 -43 253 144 -43 air
execute in minecraft:overworld run fill 253 58 -42 253 68 -42 stone
execute in minecraft:overworld run fill 253 69 -42 253 70 -42 dirt
execute in minecraft:overworld run setblock 253 71 -42 grass_block
execute in minecraft:overworld run fill 253 72 -42 253 144 -42 air
execute in minecraft:overworld run fill 253 58 -41 253 69 -41 stone
execute in minecraft:overworld run fill 253 70 -41 253 71 -41 dirt
execute in minecraft:overworld run setblock 253 72 -41 grass_block
execute in minecraft:overworld run fill 253 73 -41 253 144 -41 air
execute in minecraft:overworld run fill 253 58 -40 253 69 -40 stone
execute in minecraft:overworld run fill 253 70 -40 253 71 -40 dirt
execute in minecraft:overworld run setblock 253 72 -40 grass_block
execute in minecraft:overworld run fill 253 73 -40 253 144 -40 air
execute in minecraft:overworld run fill 253 58 -39 253 70 -39 stone
execute in minecraft:overworld run fill 253 71 -39 253 72 -39 dirt
execute in minecraft:overworld run setblock 253 73 -39 grass_block
execute in minecraft:overworld run fill 253 74 -39 253 144 -39 air
execute in minecraft:overworld run fill 253 58 -38 253 71 -38 stone
execute in minecraft:overworld run fill 253 72 -38 253 73 -38 dirt
execute in minecraft:overworld run setblock 253 74 -38 coarse_dirt
execute in minecraft:overworld run fill 253 75 -38 253 144 -38 air
execute in minecraft:overworld run fill 253 58 -37 253 71 -37 stone
execute in minecraft:overworld run fill 253 72 -37 253 73 -37 dirt
execute in minecraft:overworld run setblock 253 74 -37 coarse_dirt
execute in minecraft:overworld run fill 253 75 -37 253 144 -37 air
execute in minecraft:overworld run fill 253 58 -36 253 70 -36 stone
execute in minecraft:overworld run fill 253 71 -36 253 72 -36 dirt
execute in minecraft:overworld run setblock 253 73 -36 coarse_dirt
execute in minecraft:overworld run fill 253 74 -36 253 144 -36 air
execute in minecraft:overworld run fill 253 58 -35 253 70 -35 stone
execute in minecraft:overworld run fill 253 71 -35 253 72 -35 dirt
execute in minecraft:overworld run setblock 253 73 -35 grass_block
execute in minecraft:overworld run fill 253 74 -35 253 144 -35 air
execute in minecraft:overworld run fill 253 58 -34 253 69 -34 stone
execute in minecraft:overworld run fill 253 70 -34 253 71 -34 dirt
execute in minecraft:overworld run setblock 253 72 -34 coarse_dirt
execute in minecraft:overworld run fill 253 73 -34 253 144 -34 air
execute in minecraft:overworld run fill 253 58 -33 253 69 -33 stone
execute in minecraft:overworld run fill 253 70 -33 253 71 -33 dirt
execute in minecraft:overworld run setblock 253 72 -33 coarse_dirt
execute in minecraft:overworld run fill 253 73 -33 253 144 -33 air
execute in minecraft:overworld run fill 253 58 -32 253 69 -32 stone
execute in minecraft:overworld run fill 253 70 -32 253 71 -32 dirt
execute in minecraft:overworld run setblock 253 72 -32 grass_block
execute in minecraft:overworld run fill 253 73 -32 253 144 -32 air
execute in minecraft:overworld run fill 253 58 -31 253 68 -31 stone
execute in minecraft:overworld run fill 253 69 -31 253 70 -31 dirt
execute in minecraft:overworld run setblock 253 71 -31 coarse_dirt
execute in minecraft:overworld run fill 253 72 -31 253 144 -31 air
execute in minecraft:overworld run setblock 253 72 -31 grass
execute in minecraft:overworld run fill 253 58 -30 253 68 -30 stone
execute in minecraft:overworld run fill 253 69 -30 253 70 -30 dirt
execute in minecraft:overworld run setblock 253 71 -30 coarse_dirt
execute in minecraft:overworld run fill 253 72 -30 253 144 -30 air
execute in minecraft:overworld run fill 253 58 -29 253 68 -29 stone
execute in minecraft:overworld run fill 253 69 -29 253 70 -29 dirt
execute in minecraft:overworld run setblock 253 71 -29 coarse_dirt
execute in minecraft:overworld run fill 253 72 -29 253 144 -29 air
execute in minecraft:overworld run fill 253 58 -28 253 67 -28 stone
execute in minecraft:overworld run fill 253 68 -28 253 69 -28 dirt
execute in minecraft:overworld run setblock 253 70 -28 coarse_dirt
execute in minecraft:overworld run fill 253 71 -28 253 144 -28 air
execute in minecraft:overworld run fill 253 58 -27 253 67 -27 stone
execute in minecraft:overworld run fill 253 68 -27 253 69 -27 dirt
execute in minecraft:overworld run setblock 253 70 -27 coarse_dirt
execute in minecraft:overworld run fill 253 71 -27 253 144 -27 air
execute in minecraft:overworld run setblock 253 71 -27 grass
execute in minecraft:overworld run fill 253 58 -26 253 67 -26 stone
execute in minecraft:overworld run fill 253 68 -26 253 69 -26 dirt
execute in minecraft:overworld run setblock 253 70 -26 coarse_dirt
execute in minecraft:overworld run fill 253 71 -26 253 144 -26 air
execute in minecraft:overworld run fill 253 58 -25 253 66 -25 stone
execute in minecraft:overworld run fill 253 67 -25 253 68 -25 dirt
execute in minecraft:overworld run setblock 253 69 -25 coarse_dirt
execute in minecraft:overworld run fill 253 70 -25 253 144 -25 air
execute in minecraft:overworld run fill 253 58 -24 253 66 -24 stone
execute in minecraft:overworld run fill 253 67 -24 253 68 -24 dirt
execute in minecraft:overworld run setblock 253 69 -24 grass_block
execute in minecraft:overworld run fill 253 70 -24 253 144 -24 air
execute in minecraft:overworld run fill 253 58 -23 253 65 -23 stone
execute in minecraft:overworld run fill 253 66 -23 253 67 -23 dirt
execute in minecraft:overworld run setblock 253 68 -23 grass_block
execute in minecraft:overworld run fill 253 69 -23 253 144 -23 air
execute in minecraft:overworld run fill 253 58 -22 253 65 -22 stone
execute in minecraft:overworld run fill 253 66 -22 253 67 -22 dirt
execute in minecraft:overworld run setblock 253 68 -22 coarse_dirt
execute in minecraft:overworld run fill 253 69 -22 253 144 -22 air
execute in minecraft:overworld run fill 253 58 -21 253 64 -21 stone
execute in minecraft:overworld run fill 253 65 -21 253 66 -21 dirt
execute in minecraft:overworld run setblock 253 67 -21 grass_block
execute in minecraft:overworld run fill 253 68 -21 253 144 -21 air
execute in minecraft:overworld run fill 253 58 -20 253 64 -20 stone
execute in minecraft:overworld run fill 253 65 -20 253 66 -20 dirt
execute in minecraft:overworld run setblock 253 67 -20 coarse_dirt
execute in minecraft:overworld run fill 253 68 -20 253 144 -20 air
execute in minecraft:overworld run fill 253 58 -19 253 63 -19 stone
execute in minecraft:overworld run fill 253 64 -19 253 65 -19 dirt
execute in minecraft:overworld run setblock 253 66 -19 coarse_dirt
execute in minecraft:overworld run fill 253 67 -19 253 144 -19 air
execute in minecraft:overworld run fill 253 58 -18 253 63 -18 stone
execute in minecraft:overworld run fill 253 64 -18 253 65 -18 dirt
execute in minecraft:overworld run setblock 253 66 -18 grass_block
execute in minecraft:overworld run fill 253 67 -18 253 144 -18 air
execute in minecraft:overworld run fill 253 58 -17 253 63 -17 stone
execute in minecraft:overworld run fill 253 64 -17 253 65 -17 dirt
execute in minecraft:overworld run setblock 253 66 -17 coarse_dirt
execute in minecraft:overworld run fill 253 67 -17 253 144 -17 air
execute in minecraft:overworld run fill 253 58 -16 253 62 -16 stone
execute in minecraft:overworld run fill 253 63 -16 253 64 -16 dirt
execute in minecraft:overworld run setblock 253 65 -16 coarse_dirt
execute in minecraft:overworld run fill 253 66 -16 253 144 -16 air
execute in minecraft:overworld run fill 253 58 -15 253 62 -15 stone
execute in minecraft:overworld run fill 253 63 -15 253 64 -15 dirt
execute in minecraft:overworld run setblock 253 65 -15 grass_block
execute in minecraft:overworld run fill 253 66 -15 253 144 -15 air
execute in minecraft:overworld run fill 253 58 -14 253 62 -14 stone
execute in minecraft:overworld run fill 253 63 -14 253 64 -14 dirt
execute in minecraft:overworld run setblock 253 65 -14 coarse_dirt
execute in minecraft:overworld run fill 253 66 -14 253 144 -14 air
execute in minecraft:overworld run fill 253 58 -13 253 61 -13 stone
execute in minecraft:overworld run fill 253 62 -13 253 63 -13 dirt
execute in minecraft:overworld run setblock 253 64 -13 coarse_dirt
execute in minecraft:overworld run fill 253 65 -13 253 144 -13 air
execute in minecraft:overworld run fill 253 58 -12 253 61 -12 stone
execute in minecraft:overworld run fill 253 62 -12 253 63 -12 dirt
execute in minecraft:overworld run setblock 253 64 -12 coarse_dirt
execute in minecraft:overworld run fill 253 65 -12 253 144 -12 air
execute in minecraft:overworld run fill 253 58 -11 253 61 -11 stone
execute in minecraft:overworld run fill 253 62 -11 253 63 -11 dirt
execute in minecraft:overworld run setblock 253 64 -11 coarse_dirt
execute in minecraft:overworld run fill 253 65 -11 253 144 -11 air
execute in minecraft:overworld run fill 253 58 -10 253 61 -10 stone
execute in minecraft:overworld run fill 253 62 -10 253 63 -10 dirt
execute in minecraft:overworld run setblock 253 64 -10 grass_block
execute in minecraft:overworld run fill 253 65 -10 253 144 -10 air
execute in minecraft:overworld run fill 253 58 -9 253 61 -9 stone
execute in minecraft:overworld run fill 253 62 -9 253 63 -9 dirt
execute in minecraft:overworld run setblock 253 64 -9 grass_block
execute in minecraft:overworld run fill 253 65 -9 253 144 -9 air
execute in minecraft:overworld run fill 253 58 -8 253 61 -8 stone
execute in minecraft:overworld run fill 253 62 -8 253 63 -8 dirt
execute in minecraft:overworld run setblock 253 64 -8 coarse_dirt
execute in minecraft:overworld run fill 253 65 -8 253 144 -8 air
execute in minecraft:overworld run fill 253 58 -7 253 60 -7 stone
execute in minecraft:overworld run fill 253 61 -7 253 62 -7 dirt
execute in minecraft:overworld run setblock 253 63 -7 gravel
execute in minecraft:overworld run fill 253 64 -7 253 144 -7 air
execute in minecraft:overworld run fill 253 64 -7 253 64 -7 water
execute in minecraft:overworld run fill 253 58 -6 253 60 -6 stone
execute in minecraft:overworld run fill 253 61 -6 253 62 -6 dirt
execute in minecraft:overworld run setblock 253 63 -6 gravel
execute in minecraft:overworld run fill 253 64 -6 253 144 -6 air
execute in minecraft:overworld run fill 253 64 -6 253 64 -6 water
execute in minecraft:overworld run fill 253 58 -5 253 60 -5 stone
execute in minecraft:overworld run fill 253 61 -5 253 62 -5 dirt
execute in minecraft:overworld run setblock 253 63 -5 gravel
execute in minecraft:overworld run fill 253 64 -5 253 144 -5 air
execute in minecraft:overworld run fill 253 64 -5 253 64 -5 water
execute in minecraft:overworld run fill 253 58 -4 253 60 -4 stone
execute in minecraft:overworld run fill 253 61 -4 253 62 -4 dirt
execute in minecraft:overworld run setblock 253 63 -4 gravel
execute in minecraft:overworld run fill 253 64 -4 253 144 -4 air
execute in minecraft:overworld run fill 253 64 -4 253 64 -4 water
execute in minecraft:overworld run fill 253 58 -3 253 59 -3 stone
execute in minecraft:overworld run fill 253 60 -3 253 61 -3 dirt
execute in minecraft:overworld run setblock 253 62 -3 gravel
execute in minecraft:overworld run fill 253 63 -3 253 144 -3 air
execute in minecraft:overworld run fill 253 63 -3 253 64 -3 water
execute in minecraft:overworld run fill 253 58 -2 253 59 -2 stone
execute in minecraft:overworld run fill 253 60 -2 253 61 -2 dirt
schedule function blade_gallery:random/burned/part_70 1t replace
