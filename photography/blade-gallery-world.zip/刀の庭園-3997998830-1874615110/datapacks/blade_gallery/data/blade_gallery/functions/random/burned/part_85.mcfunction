execute in minecraft:overworld run fill 262 61 -12 262 64 -12 water
execute in minecraft:overworld run fill 262 58 -11 262 56 -11 stone
execute in minecraft:overworld run fill 262 57 -11 262 58 -11 dirt
execute in minecraft:overworld run setblock 262 59 -11 gravel
execute in minecraft:overworld run fill 262 60 -11 262 144 -11 air
execute in minecraft:overworld run fill 262 60 -11 262 64 -11 water
execute in minecraft:overworld run fill 262 58 -10 262 56 -10 stone
execute in minecraft:overworld run fill 262 57 -10 262 58 -10 dirt
execute in minecraft:overworld run setblock 262 59 -10 gravel
execute in minecraft:overworld run fill 262 60 -10 262 144 -10 air
execute in minecraft:overworld run fill 262 60 -10 262 64 -10 water
execute in minecraft:overworld run fill 262 58 -9 262 56 -9 stone
execute in minecraft:overworld run fill 262 57 -9 262 58 -9 dirt
execute in minecraft:overworld run setblock 262 59 -9 gravel
execute in minecraft:overworld run fill 262 60 -9 262 144 -9 air
execute in minecraft:overworld run fill 262 60 -9 262 64 -9 water
execute in minecraft:overworld run fill 262 58 -8 262 55 -8 stone
execute in minecraft:overworld run fill 262 56 -8 262 57 -8 dirt
execute in minecraft:overworld run setblock 262 58 -8 gravel
execute in minecraft:overworld run fill 262 59 -8 262 144 -8 air
execute in minecraft:overworld run fill 262 59 -8 262 64 -8 water
execute in minecraft:overworld run fill 262 58 -7 262 55 -7 stone
execute in minecraft:overworld run fill 262 56 -7 262 57 -7 dirt
execute in minecraft:overworld run setblock 262 58 -7 gravel
execute in minecraft:overworld run fill 262 59 -7 262 144 -7 air
execute in minecraft:overworld run fill 262 59 -7 262 64 -7 water
execute in minecraft:overworld run fill 262 58 -6 262 55 -6 stone
execute in minecraft:overworld run fill 262 56 -6 262 57 -6 dirt
execute in minecraft:overworld run setblock 262 58 -6 gravel
execute in minecraft:overworld run fill 262 59 -6 262 144 -6 air
execute in minecraft:overworld run fill 262 59 -6 262 64 -6 water
execute in minecraft:overworld run fill 262 58 -5 262 55 -5 stone
execute in minecraft:overworld run fill 262 56 -5 262 57 -5 dirt
execute in minecraft:overworld run setblock 262 58 -5 gravel
execute in minecraft:overworld run fill 262 59 -5 262 144 -5 air
execute in minecraft:overworld run fill 262 59 -5 262 64 -5 water
execute in minecraft:overworld run fill 262 58 -4 262 55 -4 stone
execute in minecraft:overworld run fill 262 56 -4 262 57 -4 dirt
execute in minecraft:overworld run setblock 262 58 -4 gravel
execute in minecraft:overworld run fill 262 59 -4 262 144 -4 air
execute in minecraft:overworld run fill 262 59 -4 262 64 -4 water
execute in minecraft:overworld run fill 262 58 -3 262 55 -3 stone
execute in minecraft:overworld run fill 262 56 -3 262 57 -3 dirt
execute in minecraft:overworld run setblock 262 58 -3 gravel
execute in minecraft:overworld run fill 262 59 -3 262 144 -3 air
execute in minecraft:overworld run fill 262 59 -3 262 64 -3 water
execute in minecraft:overworld run fill 262 58 -2 262 55 -2 stone
execute in minecraft:overworld run fill 262 56 -2 262 57 -2 dirt
execute in minecraft:overworld run setblock 262 58 -2 gravel
execute in minecraft:overworld run fill 262 59 -2 262 144 -2 air
execute in minecraft:overworld run fill 262 59 -2 262 64 -2 water
execute in minecraft:overworld run fill 262 58 -1 262 55 -1 stone
execute in minecraft:overworld run fill 262 56 -1 262 57 -1 dirt
execute in minecraft:overworld run setblock 262 58 -1 gravel
execute in minecraft:overworld run fill 262 59 -1 262 144 -1 air
execute in minecraft:overworld run fill 262 59 -1 262 64 -1 water
execute in minecraft:overworld run fill 262 58 0 262 55 0 stone
execute in minecraft:overworld run fill 262 56 0 262 57 0 dirt
execute in minecraft:overworld run setblock 262 58 0 gravel
execute in minecraft:overworld run fill 262 59 0 262 144 0 air
execute in minecraft:overworld run fill 262 59 0 262 64 0 water
execute in minecraft:overworld run fill 262 58 1 262 55 1 stone
execute in minecraft:overworld run fill 262 56 1 262 57 1 dirt
execute in minecraft:overworld run setblock 262 58 1 gravel
execute in minecraft:overworld run fill 262 59 1 262 144 1 air
execute in minecraft:overworld run fill 262 59 1 262 64 1 water
execute in minecraft:overworld run fill 262 58 2 262 55 2 stone
execute in minecraft:overworld run fill 262 56 2 262 57 2 dirt
execute in minecraft:overworld run setblock 262 58 2 gravel
execute in minecraft:overworld run fill 262 59 2 262 144 2 air
execute in minecraft:overworld run fill 262 59 2 262 64 2 water
execute in minecraft:overworld run fill 262 58 3 262 56 3 stone
execute in minecraft:overworld run fill 262 57 3 262 58 3 dirt
execute in minecraft:overworld run setblock 262 59 3 gravel
execute in minecraft:overworld run fill 262 60 3 262 144 3 air
execute in minecraft:overworld run fill 262 60 3 262 64 3 water
execute in minecraft:overworld run fill 262 58 4 262 56 4 stone
execute in minecraft:overworld run fill 262 57 4 262 58 4 dirt
execute in minecraft:overworld run setblock 262 59 4 gravel
execute in minecraft:overworld run fill 262 60 4 262 144 4 air
execute in minecraft:overworld run fill 262 60 4 262 64 4 water
execute in minecraft:overworld run fill 262 58 5 262 56 5 stone
execute in minecraft:overworld run fill 262 57 5 262 58 5 dirt
execute in minecraft:overworld run setblock 262 59 5 gravel
execute in minecraft:overworld run fill 262 60 5 262 144 5 air
execute in minecraft:overworld run fill 262 60 5 262 64 5 water
execute in minecraft:overworld run fill 262 58 6 262 56 6 stone
execute in minecraft:overworld run fill 262 57 6 262 58 6 dirt
execute in minecraft:overworld run setblock 262 59 6 gravel
execute in minecraft:overworld run fill 262 60 6 262 144 6 air
execute in minecraft:overworld run fill 262 60 6 262 64 6 water
execute in minecraft:overworld run fill 262 58 7 262 56 7 stone
execute in minecraft:overworld run fill 262 57 7 262 58 7 dirt
execute in minecraft:overworld run setblock 262 59 7 gravel
execute in minecraft:overworld run fill 262 60 7 262 144 7 air
execute in minecraft:overworld run fill 262 60 7 262 64 7 water
execute in minecraft:overworld run fill 262 58 8 262 57 8 stone
execute in minecraft:overworld run fill 262 58 8 262 59 8 dirt
execute in minecraft:overworld run setblock 262 60 8 gravel
execute in minecraft:overworld run fill 262 61 8 262 144 8 air
execute in minecraft:overworld run fill 262 61 8 262 64 8 water
execute in minecraft:overworld run fill 262 58 9 262 57 9 stone
execute in minecraft:overworld run fill 262 58 9 262 59 9 dirt
execute in minecraft:overworld run setblock 262 60 9 gravel
execute in minecraft:overworld run fill 262 61 9 262 144 9 air
execute in minecraft:overworld run fill 262 61 9 262 64 9 water
execute in minecraft:overworld run fill 262 58 10 262 57 10 stone
execute in minecraft:overworld run fill 262 58 10 262 59 10 dirt
execute in minecraft:overworld run setblock 262 60 10 gravel
execute in minecraft:overworld run fill 262 61 10 262 144 10 air
execute in minecraft:overworld run fill 262 61 10 262 64 10 water
execute in minecraft:overworld run fill 262 58 11 262 57 11 stone
execute in minecraft:overworld run fill 262 58 11 262 59 11 dirt
execute in minecraft:overworld run setblock 262 60 11 gravel
execute in minecraft:overworld run fill 262 61 11 262 144 11 air
execute in minecraft:overworld run fill 262 61 11 262 64 11 water
execute in minecraft:overworld run fill 262 58 12 262 58 12 stone
execute in minecraft:overworld run fill 262 59 12 262 60 12 dirt
execute in minecraft:overworld run setblock 262 61 12 gravel
execute in minecraft:overworld run fill 262 62 12 262 144 12 air
execute in minecraft:overworld run fill 262 62 12 262 64 12 water
execute in minecraft:overworld run fill 262 58 13 262 58 13 stone
execute in minecraft:overworld run fill 262 59 13 262 60 13 dirt
execute in minecraft:overworld run setblock 262 61 13 gravel
execute in minecraft:overworld run fill 262 62 13 262 144 13 air
execute in minecraft:overworld run fill 262 62 13 262 64 13 water
execute in minecraft:overworld run fill 262 58 14 262 58 14 stone
execute in minecraft:overworld run fill 262 59 14 262 60 14 dirt
execute in minecraft:overworld run setblock 262 61 14 gravel
execute in minecraft:overworld run fill 262 62 14 262 144 14 air
execute in minecraft:overworld run fill 262 62 14 262 64 14 water
execute in minecraft:overworld run fill 262 58 15 262 59 15 stone
execute in minecraft:overworld run fill 262 60 15 262 61 15 dirt
execute in minecraft:overworld run setblock 262 62 15 gravel
execute in minecraft:overworld run fill 262 63 15 262 144 15 air
execute in minecraft:overworld run fill 262 63 15 262 64 15 water
execute in minecraft:overworld run fill 262 58 16 262 59 16 stone
execute in minecraft:overworld run fill 262 60 16 262 61 16 dirt
execute in minecraft:overworld run setblock 262 62 16 gravel
execute in minecraft:overworld run fill 262 63 16 262 144 16 air
execute in minecraft:overworld run fill 262 63 16 262 64 16 water
execute in minecraft:overworld run fill 262 58 17 262 59 17 stone
execute in minecraft:overworld run fill 262 60 17 262 61 17 dirt
execute in minecraft:overworld run setblock 262 62 17 gravel
execute in minecraft:overworld run fill 262 63 17 262 144 17 air
execute in minecraft:overworld run fill 262 63 17 262 64 17 water
execute in minecraft:overworld run fill 262 58 18 262 59 18 stone
execute in minecraft:overworld run fill 262 60 18 262 61 18 dirt
execute in minecraft:overworld run setblock 262 62 18 gravel
execute in minecraft:overworld run fill 262 63 18 262 144 18 air
execute in minecraft:overworld run fill 262 63 18 262 64 18 water
execute in minecraft:overworld run fill 262 58 19 262 59 19 stone
execute in minecraft:overworld run fill 262 60 19 262 61 19 dirt
execute in minecraft:overworld run setblock 262 62 19 gravel
execute in minecraft:overworld run fill 262 63 19 262 144 19 air
execute in minecraft:overworld run fill 262 63 19 262 64 19 water
execute in minecraft:overworld run fill 262 58 20 262 59 20 stone
execute in minecraft:overworld run fill 262 60 20 262 61 20 dirt
execute in minecraft:overworld run setblock 262 62 20 gravel
execute in minecraft:overworld run fill 262 63 20 262 144 20 air
execute in minecraft:overworld run fill 262 63 20 262 64 20 water
execute in minecraft:overworld run fill 262 58 21 262 59 21 stone
execute in minecraft:overworld run fill 262 60 21 262 61 21 dirt
execute in minecraft:overworld run setblock 262 62 21 gravel
execute in minecraft:overworld run fill 262 63 21 262 144 21 air
execute in minecraft:overworld run fill 262 63 21 262 64 21 water
execute in minecraft:overworld run fill 262 58 22 262 58 22 stone
execute in minecraft:overworld run fill 262 59 22 262 60 22 dirt
execute in minecraft:overworld run setblock 262 61 22 gravel
execute in minecraft:overworld run fill 262 62 22 262 144 22 air
execute in minecraft:overworld run fill 262 62 22 262 64 22 water
execute in minecraft:overworld run fill 262 58 23 262 58 23 stone
execute in minecraft:overworld run fill 262 59 23 262 60 23 dirt
execute in minecraft:overworld run setblock 262 61 23 gravel
execute in minecraft:overworld run fill 262 62 23 262 144 23 air
execute in minecraft:overworld run fill 262 62 23 262 64 23 water
execute in minecraft:overworld run fill 262 58 24 262 58 24 stone
execute in minecraft:overworld run fill 262 59 24 262 60 24 dirt
execute in minecraft:overworld run setblock 262 61 24 gravel
execute in minecraft:overworld run fill 262 62 24 262 144 24 air
execute in minecraft:overworld run fill 262 62 24 262 64 24 water
execute in minecraft:overworld run fill 262 58 25 262 57 25 stone
execute in minecraft:overworld run fill 262 58 25 262 59 25 dirt
execute in minecraft:overworld run setblock 262 60 25 gravel
execute in minecraft:overworld run fill 262 61 25 262 144 25 air
execute in minecraft:overworld run fill 262 61 25 262 64 25 water
execute in minecraft:overworld run fill 262 58 26 262 57 26 stone
execute in minecraft:overworld run fill 262 58 26 262 59 26 dirt
execute in minecraft:overworld run setblock 262 60 26 gravel
execute in minecraft:overworld run fill 262 61 26 262 144 26 air
execute in minecraft:overworld run fill 262 61 26 262 64 26 water
execute in minecraft:overworld run fill 262 58 27 262 57 27 stone
execute in minecraft:overworld run fill 262 58 27 262 59 27 dirt
execute in minecraft:overworld run setblock 262 60 27 gravel
execute in minecraft:overworld run fill 262 61 27 262 144 27 air
execute in minecraft:overworld run fill 262 61 27 262 64 27 water
execute in minecraft:overworld run fill 262 58 28 262 57 28 stone
execute in minecraft:overworld run fill 262 58 28 262 59 28 dirt
execute in minecraft:overworld run setblock 262 60 28 gravel
execute in minecraft:overworld run fill 262 61 28 262 144 28 air
execute in minecraft:overworld run fill 262 61 28 262 64 28 water
execute in minecraft:overworld run fill 262 58 29 262 56 29 stone
execute in minecraft:overworld run fill 262 57 29 262 58 29 dirt
execute in minecraft:overworld run setblock 262 59 29 gravel
execute in minecraft:overworld run fill 262 60 29 262 144 29 air
execute in minecraft:overworld run fill 262 60 29 262 64 29 water
execute in minecraft:overworld run fill 262 58 30 262 56 30 stone
execute in minecraft:overworld run fill 262 57 30 262 58 30 dirt
execute in minecraft:overworld run setblock 262 59 30 gravel
execute in minecraft:overworld run fill 262 60 30 262 144 30 air
execute in minecraft:overworld run fill 262 60 30 262 64 30 water
execute in minecraft:overworld run fill 262 58 31 262 56 31 stone
execute in minecraft:overworld run fill 262 57 31 262 58 31 dirt
execute in minecraft:overworld run setblock 262 59 31 gravel
execute in minecraft:overworld run fill 262 60 31 262 144 31 air
execute in minecraft:overworld run fill 262 60 31 262 64 31 water
execute in minecraft:overworld run fill 262 58 32 262 55 32 stone
execute in minecraft:overworld run fill 262 56 32 262 57 32 dirt
execute in minecraft:overworld run setblock 262 58 32 gravel
execute in minecraft:overworld run fill 262 59 32 262 144 32 air
execute in minecraft:overworld run fill 262 59 32 262 64 32 water
execute in minecraft:overworld run fill 262 58 33 262 55 33 stone
execute in minecraft:overworld run fill 262 56 33 262 57 33 dirt
execute in minecraft:overworld run setblock 262 58 33 gravel
execute in minecraft:overworld run fill 262 59 33 262 144 33 air
execute in minecraft:overworld run fill 262 59 33 262 64 33 water
execute in minecraft:overworld run fill 262 58 34 262 55 34 stone
execute in minecraft:overworld run fill 262 56 34 262 57 34 dirt
execute in minecraft:overworld run setblock 262 58 34 gravel
execute in minecraft:overworld run fill 262 59 34 262 144 34 air
execute in minecraft:overworld run fill 262 59 34 262 64 34 water
execute in minecraft:overworld run fill 262 58 35 262 55 35 stone
execute in minecraft:overworld run fill 262 56 35 262 57 35 dirt
execute in minecraft:overworld run setblock 262 58 35 gravel
execute in minecraft:overworld run fill 262 59 35 262 144 35 air
execute in minecraft:overworld run fill 262 59 35 262 64 35 water
execute in minecraft:overworld run fill 262 58 36 262 55 36 stone
execute in minecraft:overworld run fill 262 56 36 262 57 36 dirt
execute in minecraft:overworld run setblock 262 58 36 gravel
execute in minecraft:overworld run fill 262 59 36 262 144 36 air
execute in minecraft:overworld run fill 262 59 36 262 64 36 water
execute in minecraft:overworld run fill 262 58 37 262 55 37 stone
execute in minecraft:overworld run fill 262 56 37 262 57 37 dirt
execute in minecraft:overworld run setblock 262 58 37 gravel
execute in minecraft:overworld run fill 262 59 37 262 144 37 air
execute in minecraft:overworld run fill 262 59 37 262 64 37 water
execute in minecraft:overworld run fill 262 58 38 262 55 38 stone
execute in minecraft:overworld run fill 262 56 38 262 57 38 dirt
execute in minecraft:overworld run setblock 262 58 38 gravel
execute in minecraft:overworld run fill 262 59 38 262 144 38 air
execute in minecraft:overworld run fill 262 59 38 262 64 38 water
execute in minecraft:overworld run fill 262 58 39 262 56 39 stone
execute in minecraft:overworld run fill 262 57 39 262 58 39 dirt
execute in minecraft:overworld run setblock 262 59 39 gravel
execute in minecraft:overworld run fill 262 60 39 262 144 39 air
execute in minecraft:overworld run fill 262 60 39 262 64 39 water
schedule function blade_gallery:random/burned/part_86 1t replace
