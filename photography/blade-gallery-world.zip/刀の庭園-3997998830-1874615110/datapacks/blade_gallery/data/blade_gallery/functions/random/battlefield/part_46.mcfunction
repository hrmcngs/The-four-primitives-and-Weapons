execute in minecraft:overworld run fill 366 69 -43 366 70 -43 dirt
execute in minecraft:overworld run setblock 366 71 -43 coarse_dirt
execute in minecraft:overworld run fill 366 72 -43 366 144 -43 air
execute in minecraft:overworld run fill 366 58 -42 366 69 -42 stone
execute in minecraft:overworld run fill 366 70 -42 366 71 -42 dirt
execute in minecraft:overworld run setblock 366 72 -42 coarse_dirt
execute in minecraft:overworld run fill 366 73 -42 366 144 -42 air
execute in minecraft:overworld run fill 366 58 -41 366 70 -41 stone
execute in minecraft:overworld run fill 366 71 -41 366 72 -41 dirt
execute in minecraft:overworld run setblock 366 73 -41 coarse_dirt
execute in minecraft:overworld run fill 366 74 -41 366 144 -41 air
execute in minecraft:overworld run fill 366 58 -40 366 71 -40 stone
execute in minecraft:overworld run fill 366 72 -40 366 73 -40 dirt
execute in minecraft:overworld run setblock 366 74 -40 grass_block
execute in minecraft:overworld run fill 366 75 -40 366 144 -40 air
execute in minecraft:overworld run fill 366 58 -39 366 73 -39 stone
execute in minecraft:overworld run fill 366 74 -39 366 75 -39 dirt
execute in minecraft:overworld run setblock 366 76 -39 coarse_dirt
execute in minecraft:overworld run fill 366 77 -39 366 144 -39 air
execute in minecraft:overworld run fill 366 58 -38 366 74 -38 stone
execute in minecraft:overworld run fill 366 75 -38 366 76 -38 dirt
execute in minecraft:overworld run setblock 366 77 -38 coarse_dirt
execute in minecraft:overworld run fill 366 78 -38 366 144 -38 air
execute in minecraft:overworld run fill 366 58 -37 366 74 -37 stone
execute in minecraft:overworld run fill 366 75 -37 366 76 -37 dirt
execute in minecraft:overworld run setblock 366 77 -37 grass_block
execute in minecraft:overworld run fill 366 78 -37 366 144 -37 air
execute in minecraft:overworld run fill 366 58 -36 366 73 -36 stone
execute in minecraft:overworld run fill 366 74 -36 366 75 -36 dirt
execute in minecraft:overworld run setblock 366 76 -36 coarse_dirt
execute in minecraft:overworld run fill 366 77 -36 366 144 -36 air
execute in minecraft:overworld run fill 366 58 -35 366 73 -35 stone
execute in minecraft:overworld run fill 366 74 -35 366 75 -35 dirt
execute in minecraft:overworld run setblock 366 76 -35 coarse_dirt
execute in minecraft:overworld run fill 366 77 -35 366 144 -35 air
execute in minecraft:overworld run fill 366 58 -34 366 73 -34 stone
execute in minecraft:overworld run fill 366 74 -34 366 75 -34 dirt
execute in minecraft:overworld run setblock 366 76 -34 coarse_dirt
execute in minecraft:overworld run fill 366 77 -34 366 144 -34 air
execute in minecraft:overworld run fill 366 58 -33 366 73 -33 stone
execute in minecraft:overworld run fill 366 74 -33 366 75 -33 dirt
execute in minecraft:overworld run setblock 366 76 -33 grass_block
execute in minecraft:overworld run fill 366 77 -33 366 144 -33 air
execute in minecraft:overworld run fill 366 58 -32 366 73 -32 stone
execute in minecraft:overworld run fill 366 74 -32 366 75 -32 dirt
execute in minecraft:overworld run setblock 366 76 -32 grass_block
execute in minecraft:overworld run fill 366 77 -32 366 144 -32 air
execute in minecraft:overworld run fill 366 58 -31 366 73 -31 stone
execute in minecraft:overworld run fill 366 74 -31 366 75 -31 dirt
execute in minecraft:overworld run setblock 366 76 -31 coarse_dirt
execute in minecraft:overworld run fill 366 77 -31 366 144 -31 air
execute in minecraft:overworld run fill 366 58 -30 366 72 -30 stone
execute in minecraft:overworld run fill 366 73 -30 366 74 -30 dirt
execute in minecraft:overworld run setblock 366 75 -30 grass_block
execute in minecraft:overworld run fill 366 76 -30 366 144 -30 air
execute in minecraft:overworld run setblock 366 76 -30 grass
execute in minecraft:overworld run fill 366 58 -29 366 72 -29 stone
execute in minecraft:overworld run fill 366 73 -29 366 74 -29 dirt
execute in minecraft:overworld run setblock 366 75 -29 grass_block
execute in minecraft:overworld run fill 366 76 -29 366 144 -29 air
execute in minecraft:overworld run fill 366 58 -28 366 72 -28 stone
execute in minecraft:overworld run fill 366 73 -28 366 74 -28 dirt
execute in minecraft:overworld run setblock 366 75 -28 coarse_dirt
execute in minecraft:overworld run fill 366 76 -28 366 144 -28 air
execute in minecraft:overworld run fill 366 58 -27 366 72 -27 stone
execute in minecraft:overworld run fill 366 73 -27 366 74 -27 dirt
execute in minecraft:overworld run setblock 366 75 -27 coarse_dirt
execute in minecraft:overworld run fill 366 76 -27 366 144 -27 air
execute in minecraft:overworld run fill 366 58 -26 366 71 -26 stone
execute in minecraft:overworld run fill 366 72 -26 366 73 -26 dirt
execute in minecraft:overworld run setblock 366 74 -26 grass_block
execute in minecraft:overworld run fill 366 75 -26 366 144 -26 air
execute in minecraft:overworld run fill 366 58 -25 366 71 -25 stone
execute in minecraft:overworld run fill 366 72 -25 366 73 -25 dirt
execute in minecraft:overworld run setblock 366 74 -25 coarse_dirt
execute in minecraft:overworld run fill 366 75 -25 366 144 -25 air
execute in minecraft:overworld run fill 366 58 -24 366 71 -24 stone
execute in minecraft:overworld run fill 366 72 -24 366 73 -24 dirt
execute in minecraft:overworld run setblock 366 74 -24 coarse_dirt
execute in minecraft:overworld run fill 366 75 -24 366 144 -24 air
execute in minecraft:overworld run fill 366 58 -23 366 70 -23 stone
execute in minecraft:overworld run fill 366 71 -23 366 72 -23 dirt
execute in minecraft:overworld run setblock 366 73 -23 coarse_dirt
execute in minecraft:overworld run fill 366 74 -23 366 144 -23 air
execute in minecraft:overworld run setblock 366 74 -23 grass
execute in minecraft:overworld run fill 366 58 -22 366 70 -22 stone
execute in minecraft:overworld run fill 366 71 -22 366 72 -22 dirt
execute in minecraft:overworld run setblock 366 73 -22 grass_block
execute in minecraft:overworld run fill 366 74 -22 366 144 -22 air
execute in minecraft:overworld run fill 366 58 -21 366 69 -21 stone
execute in minecraft:overworld run fill 366 70 -21 366 71 -21 dirt
execute in minecraft:overworld run setblock 366 72 -21 grass_block
execute in minecraft:overworld run fill 366 73 -21 366 144 -21 air
execute in minecraft:overworld run fill 366 58 -20 366 69 -20 stone
execute in minecraft:overworld run fill 366 70 -20 366 71 -20 dirt
execute in minecraft:overworld run setblock 366 72 -20 coarse_dirt
execute in minecraft:overworld run fill 366 73 -20 366 144 -20 air
execute in minecraft:overworld run fill 366 58 -19 366 69 -19 stone
execute in minecraft:overworld run fill 366 70 -19 366 71 -19 dirt
execute in minecraft:overworld run setblock 366 72 -19 coarse_dirt
execute in minecraft:overworld run fill 366 73 -19 366 144 -19 air
execute in minecraft:overworld run fill 366 58 -18 366 68 -18 stone
execute in minecraft:overworld run fill 366 69 -18 366 70 -18 dirt
execute in minecraft:overworld run setblock 366 71 -18 coarse_dirt
execute in minecraft:overworld run fill 366 72 -18 366 144 -18 air
execute in minecraft:overworld run fill 366 58 -17 366 68 -17 stone
execute in minecraft:overworld run fill 366 69 -17 366 70 -17 dirt
execute in minecraft:overworld run setblock 366 71 -17 grass_block
execute in minecraft:overworld run fill 366 72 -17 366 144 -17 air
execute in minecraft:overworld run fill 366 58 -16 366 67 -16 stone
execute in minecraft:overworld run fill 366 68 -16 366 69 -16 dirt
execute in minecraft:overworld run setblock 366 70 -16 grass_block
execute in minecraft:overworld run fill 366 71 -16 366 144 -16 air
execute in minecraft:overworld run fill 366 58 -15 366 67 -15 stone
execute in minecraft:overworld run fill 366 68 -15 366 69 -15 dirt
execute in minecraft:overworld run setblock 366 70 -15 coarse_dirt
execute in minecraft:overworld run fill 366 71 -15 366 144 -15 air
execute in minecraft:overworld run fill 366 58 -14 366 67 -14 stone
execute in minecraft:overworld run fill 366 68 -14 366 69 -14 dirt
execute in minecraft:overworld run setblock 366 70 -14 coarse_dirt
execute in minecraft:overworld run fill 366 71 -14 366 144 -14 air
execute in minecraft:overworld run fill 366 58 -13 366 66 -13 stone
execute in minecraft:overworld run fill 366 67 -13 366 68 -13 dirt
execute in minecraft:overworld run setblock 366 69 -13 grass_block
execute in minecraft:overworld run fill 366 70 -13 366 144 -13 air
execute in minecraft:overworld run fill 366 58 -12 366 66 -12 stone
execute in minecraft:overworld run fill 366 67 -12 366 68 -12 dirt
execute in minecraft:overworld run setblock 366 69 -12 coarse_dirt
execute in minecraft:overworld run fill 366 70 -12 366 144 -12 air
execute in minecraft:overworld run fill 366 58 -11 366 66 -11 stone
execute in minecraft:overworld run fill 366 67 -11 366 68 -11 dirt
execute in minecraft:overworld run setblock 366 69 -11 grass_block
execute in minecraft:overworld run fill 366 70 -11 366 144 -11 air
execute in minecraft:overworld run fill 366 58 -10 366 66 -10 stone
execute in minecraft:overworld run fill 366 67 -10 366 68 -10 dirt
execute in minecraft:overworld run setblock 366 69 -10 coarse_dirt
execute in minecraft:overworld run fill 366 70 -10 366 144 -10 air
execute in minecraft:overworld run fill 366 58 -9 366 66 -9 stone
execute in minecraft:overworld run fill 366 67 -9 366 68 -9 dirt
execute in minecraft:overworld run setblock 366 69 -9 coarse_dirt
execute in minecraft:overworld run fill 366 70 -9 366 144 -9 air
execute in minecraft:overworld run fill 366 58 -8 366 66 -8 stone
execute in minecraft:overworld run fill 366 67 -8 366 68 -8 dirt
execute in minecraft:overworld run setblock 366 69 -8 coarse_dirt
execute in minecraft:overworld run fill 366 70 -8 366 144 -8 air
execute in minecraft:overworld run fill 366 58 -7 366 66 -7 stone
execute in minecraft:overworld run fill 366 67 -7 366 68 -7 dirt
execute in minecraft:overworld run setblock 366 69 -7 coarse_dirt
execute in minecraft:overworld run fill 366 70 -7 366 144 -7 air
execute in minecraft:overworld run fill 366 58 -6 366 65 -6 stone
execute in minecraft:overworld run fill 366 66 -6 366 67 -6 dirt
execute in minecraft:overworld run setblock 366 68 -6 coarse_dirt
execute in minecraft:overworld run fill 366 69 -6 366 144 -6 air
execute in minecraft:overworld run fill 366 58 -5 366 65 -5 stone
execute in minecraft:overworld run fill 366 66 -5 366 67 -5 dirt
execute in minecraft:overworld run setblock 366 68 -5 grass_block
execute in minecraft:overworld run fill 366 69 -5 366 144 -5 air
execute in minecraft:overworld run fill 366 58 -4 366 65 -4 stone
execute in minecraft:overworld run fill 366 66 -4 366 67 -4 dirt
execute in minecraft:overworld run setblock 366 68 -4 grass_block
execute in minecraft:overworld run fill 366 69 -4 366 144 -4 air
execute in minecraft:overworld run fill 366 58 -3 366 65 -3 stone
execute in minecraft:overworld run fill 366 66 -3 366 67 -3 dirt
execute in minecraft:overworld run setblock 366 68 -3 coarse_dirt
execute in minecraft:overworld run fill 366 69 -3 366 144 -3 air
execute in minecraft:overworld run fill 366 58 -2 366 65 -2 stone
execute in minecraft:overworld run fill 366 66 -2 366 67 -2 dirt
execute in minecraft:overworld run setblock 366 68 -2 coarse_dirt
execute in minecraft:overworld run fill 366 69 -2 366 144 -2 air
execute in minecraft:overworld run fill 366 58 -1 366 65 -1 stone
execute in minecraft:overworld run fill 366 66 -1 366 67 -1 dirt
execute in minecraft:overworld run setblock 366 68 -1 coarse_dirt
execute in minecraft:overworld run fill 366 69 -1 366 144 -1 air
execute in minecraft:overworld run fill 366 58 0 366 65 0 stone
execute in minecraft:overworld run fill 366 66 0 366 67 0 dirt
execute in minecraft:overworld run setblock 366 68 0 coarse_dirt
execute in minecraft:overworld run fill 366 69 0 366 144 0 air
execute in minecraft:overworld run fill 366 58 1 366 65 1 stone
execute in minecraft:overworld run fill 366 66 1 366 67 1 dirt
execute in minecraft:overworld run setblock 366 68 1 coarse_dirt
execute in minecraft:overworld run fill 366 69 1 366 144 1 air
execute in minecraft:overworld run fill 366 58 2 366 65 2 stone
execute in minecraft:overworld run fill 366 66 2 366 67 2 dirt
execute in minecraft:overworld run setblock 366 68 2 coarse_dirt
execute in minecraft:overworld run fill 366 69 2 366 144 2 air
execute in minecraft:overworld run fill 366 58 3 366 65 3 stone
execute in minecraft:overworld run fill 366 66 3 366 67 3 dirt
execute in minecraft:overworld run setblock 366 68 3 coarse_dirt
execute in minecraft:overworld run fill 366 69 3 366 144 3 air
execute in minecraft:overworld run fill 366 58 4 366 65 4 stone
execute in minecraft:overworld run fill 366 66 4 366 67 4 dirt
execute in minecraft:overworld run setblock 366 68 4 coarse_dirt
execute in minecraft:overworld run fill 366 69 4 366 144 4 air
execute in minecraft:overworld run fill 366 58 5 366 66 5 stone
execute in minecraft:overworld run fill 366 67 5 366 68 5 dirt
execute in minecraft:overworld run setblock 366 69 5 grass_block
execute in minecraft:overworld run fill 366 70 5 366 144 5 air
execute in minecraft:overworld run fill 366 58 6 366 66 6 stone
execute in minecraft:overworld run fill 366 67 6 366 68 6 dirt
execute in minecraft:overworld run setblock 366 69 6 grass_block
execute in minecraft:overworld run fill 366 70 6 366 144 6 air
execute in minecraft:overworld run fill 366 58 7 366 66 7 stone
execute in minecraft:overworld run fill 366 67 7 366 68 7 dirt
execute in minecraft:overworld run setblock 366 69 7 grass_block
execute in minecraft:overworld run fill 366 70 7 366 144 7 air
execute in minecraft:overworld run fill 366 58 8 366 66 8 stone
execute in minecraft:overworld run fill 366 67 8 366 68 8 dirt
execute in minecraft:overworld run setblock 366 69 8 coarse_dirt
execute in minecraft:overworld run fill 366 70 8 366 144 8 air
execute in minecraft:overworld run fill 366 58 9 366 66 9 stone
execute in minecraft:overworld run fill 366 67 9 366 68 9 dirt
execute in minecraft:overworld run setblock 366 69 9 grass_block
execute in minecraft:overworld run fill 366 70 9 366 144 9 air
execute in minecraft:overworld run fill 366 58 10 366 66 10 stone
execute in minecraft:overworld run fill 366 67 10 366 68 10 dirt
execute in minecraft:overworld run setblock 366 69 10 coarse_dirt
execute in minecraft:overworld run fill 366 70 10 366 144 10 air
execute in minecraft:overworld run fill 366 58 11 366 66 11 stone
execute in minecraft:overworld run fill 366 67 11 366 68 11 dirt
execute in minecraft:overworld run setblock 366 69 11 coarse_dirt
execute in minecraft:overworld run fill 366 70 11 366 144 11 air
execute in minecraft:overworld run fill 366 58 12 366 67 12 stone
execute in minecraft:overworld run fill 366 68 12 366 69 12 dirt
execute in minecraft:overworld run setblock 366 70 12 coarse_dirt
execute in minecraft:overworld run fill 366 71 12 366 144 12 air
execute in minecraft:overworld run fill 366 58 13 366 67 13 stone
execute in minecraft:overworld run fill 366 68 13 366 69 13 dirt
execute in minecraft:overworld run setblock 366 70 13 coarse_dirt
execute in minecraft:overworld run fill 366 71 13 366 144 13 air
execute in minecraft:overworld run fill 366 58 14 366 67 14 stone
execute in minecraft:overworld run fill 366 68 14 366 69 14 dirt
execute in minecraft:overworld run setblock 366 70 14 coarse_dirt
execute in minecraft:overworld run fill 366 71 14 366 144 14 air
execute in minecraft:overworld run fill 366 58 15 366 67 15 stone
execute in minecraft:overworld run fill 366 68 15 366 69 15 dirt
execute in minecraft:overworld run setblock 366 70 15 grass_block
execute in minecraft:overworld run fill 366 71 15 366 144 15 air
execute in minecraft:overworld run fill 366 58 16 366 68 16 stone
execute in minecraft:overworld run fill 366 69 16 366 70 16 dirt
execute in minecraft:overworld run setblock 366 71 16 coarse_dirt
execute in minecraft:overworld run fill 366 72 16 366 144 16 air
execute in minecraft:overworld run fill 366 58 17 366 68 17 stone
execute in minecraft:overworld run fill 366 69 17 366 70 17 dirt
execute in minecraft:overworld run setblock 366 71 17 coarse_dirt
execute in minecraft:overworld run fill 366 72 17 366 144 17 air
execute in minecraft:overworld run fill 366 58 18 366 68 18 stone
execute in minecraft:overworld run fill 366 69 18 366 70 18 dirt
execute in minecraft:overworld run setblock 366 71 18 coarse_dirt
execute in minecraft:overworld run fill 366 72 18 366 144 18 air
execute in minecraft:overworld run setblock 366 72 18 grass
execute in minecraft:overworld run fill 366 58 19 366 68 19 stone
execute in minecraft:overworld run fill 366 69 19 366 70 19 dirt
execute in minecraft:overworld run setblock 366 71 19 coarse_dirt
execute in minecraft:overworld run fill 366 72 19 366 144 19 air
execute in minecraft:overworld run fill 366 58 20 366 68 20 stone
execute in minecraft:overworld run fill 366 69 20 366 70 20 dirt
schedule function blade_gallery:random/battlefield/part_47 1t replace
