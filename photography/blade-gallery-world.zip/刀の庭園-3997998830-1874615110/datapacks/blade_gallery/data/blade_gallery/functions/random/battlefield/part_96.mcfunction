execute in minecraft:overworld run fill 397 78 -35 397 144 -35 air
execute in minecraft:overworld run fill 397 58 -34 397 74 -34 stone
execute in minecraft:overworld run fill 397 75 -34 397 76 -34 dirt
execute in minecraft:overworld run setblock 397 77 -34 coarse_dirt
execute in minecraft:overworld run fill 397 78 -34 397 144 -34 air
execute in minecraft:overworld run fill 397 58 -33 397 73 -33 stone
execute in minecraft:overworld run fill 397 74 -33 397 75 -33 dirt
execute in minecraft:overworld run setblock 397 76 -33 coarse_dirt
execute in minecraft:overworld run fill 397 77 -33 397 144 -33 air
execute in minecraft:overworld run fill 397 58 -32 397 73 -32 stone
execute in minecraft:overworld run fill 397 74 -32 397 75 -32 dirt
execute in minecraft:overworld run setblock 397 76 -32 grass_block
execute in minecraft:overworld run fill 397 77 -32 397 144 -32 air
execute in minecraft:overworld run setblock 397 77 -32 grass
execute in minecraft:overworld run fill 397 58 -31 397 72 -31 stone
execute in minecraft:overworld run fill 397 73 -31 397 74 -31 dirt
execute in minecraft:overworld run setblock 397 75 -31 coarse_dirt
execute in minecraft:overworld run fill 397 76 -31 397 144 -31 air
execute in minecraft:overworld run fill 397 58 -30 397 72 -30 stone
execute in minecraft:overworld run fill 397 73 -30 397 74 -30 dirt
execute in minecraft:overworld run setblock 397 75 -30 grass_block
execute in minecraft:overworld run fill 397 76 -30 397 144 -30 air
execute in minecraft:overworld run fill 397 58 -29 397 72 -29 stone
execute in minecraft:overworld run fill 397 73 -29 397 74 -29 dirt
execute in minecraft:overworld run setblock 397 75 -29 grass_block
execute in minecraft:overworld run fill 397 76 -29 397 144 -29 air
execute in minecraft:overworld run setblock 397 76 -29 grass
execute in minecraft:overworld run fill 397 58 -28 397 71 -28 stone
execute in minecraft:overworld run fill 397 72 -28 397 73 -28 dirt
execute in minecraft:overworld run setblock 397 74 -28 grass_block
execute in minecraft:overworld run fill 397 75 -28 397 144 -28 air
execute in minecraft:overworld run fill 397 58 -27 397 71 -27 stone
execute in minecraft:overworld run fill 397 72 -27 397 73 -27 dirt
execute in minecraft:overworld run setblock 397 74 -27 coarse_dirt
execute in minecraft:overworld run fill 397 75 -27 397 144 -27 air
execute in minecraft:overworld run fill 397 58 -26 397 70 -26 stone
execute in minecraft:overworld run fill 397 71 -26 397 72 -26 dirt
execute in minecraft:overworld run setblock 397 73 -26 grass_block
execute in minecraft:overworld run fill 397 74 -26 397 144 -26 air
execute in minecraft:overworld run fill 397 58 -25 397 70 -25 stone
execute in minecraft:overworld run fill 397 71 -25 397 72 -25 dirt
execute in minecraft:overworld run setblock 397 73 -25 grass_block
execute in minecraft:overworld run fill 397 74 -25 397 144 -25 air
execute in minecraft:overworld run setblock 397 74 -25 grass
execute in minecraft:overworld run fill 397 58 -24 397 70 -24 stone
execute in minecraft:overworld run fill 397 71 -24 397 72 -24 dirt
execute in minecraft:overworld run setblock 397 73 -24 coarse_dirt
execute in minecraft:overworld run fill 397 74 -24 397 144 -24 air
execute in minecraft:overworld run fill 397 58 -23 397 69 -23 stone
execute in minecraft:overworld run fill 397 70 -23 397 71 -23 dirt
execute in minecraft:overworld run setblock 397 72 -23 grass_block
execute in minecraft:overworld run fill 397 73 -23 397 144 -23 air
execute in minecraft:overworld run setblock 397 73 -23 grass
execute in minecraft:overworld run fill 397 58 -22 397 69 -22 stone
execute in minecraft:overworld run fill 397 70 -22 397 71 -22 dirt
execute in minecraft:overworld run setblock 397 72 -22 coarse_dirt
execute in minecraft:overworld run fill 397 73 -22 397 144 -22 air
execute in minecraft:overworld run fill 397 58 -21 397 69 -21 stone
execute in minecraft:overworld run fill 397 70 -21 397 71 -21 dirt
execute in minecraft:overworld run setblock 397 72 -21 grass_block
execute in minecraft:overworld run fill 397 73 -21 397 144 -21 air
execute in minecraft:overworld run fill 397 58 -20 397 68 -20 stone
execute in minecraft:overworld run fill 397 69 -20 397 70 -20 dirt
execute in minecraft:overworld run setblock 397 71 -20 grass_block
execute in minecraft:overworld run fill 397 72 -20 397 144 -20 air
execute in minecraft:overworld run fill 397 58 -19 397 68 -19 stone
execute in minecraft:overworld run fill 397 69 -19 397 70 -19 dirt
execute in minecraft:overworld run setblock 397 71 -19 grass_block
execute in minecraft:overworld run fill 397 72 -19 397 144 -19 air
execute in minecraft:overworld run fill 397 58 -18 397 67 -18 stone
execute in minecraft:overworld run fill 397 68 -18 397 69 -18 dirt
execute in minecraft:overworld run setblock 397 70 -18 coarse_dirt
execute in minecraft:overworld run fill 397 71 -18 397 144 -18 air
execute in minecraft:overworld run fill 397 58 -17 397 66 -17 stone
execute in minecraft:overworld run fill 397 67 -17 397 68 -17 dirt
execute in minecraft:overworld run setblock 397 69 -17 grass_block
execute in minecraft:overworld run fill 397 70 -17 397 144 -17 air
execute in minecraft:overworld run fill 397 58 -16 397 65 -16 stone
execute in minecraft:overworld run fill 397 66 -16 397 67 -16 dirt
execute in minecraft:overworld run setblock 397 68 -16 grass_block
execute in minecraft:overworld run fill 397 69 -16 397 144 -16 air
execute in minecraft:overworld run setblock 397 69 -16 mossy_cobblestone
execute in minecraft:overworld run fill 397 58 -15 397 64 -15 stone
execute in minecraft:overworld run fill 397 65 -15 397 66 -15 dirt
execute in minecraft:overworld run setblock 397 67 -15 coarse_dirt
execute in minecraft:overworld run fill 397 68 -15 397 144 -15 air
execute in minecraft:overworld run fill 397 58 -14 397 63 -14 stone
execute in minecraft:overworld run fill 397 64 -14 397 65 -14 dirt
execute in minecraft:overworld run setblock 397 66 -14 coarse_dirt
execute in minecraft:overworld run fill 397 67 -14 397 144 -14 air
execute in minecraft:overworld run fill 397 58 -13 397 62 -13 stone
execute in minecraft:overworld run fill 397 63 -13 397 64 -13 dirt
execute in minecraft:overworld run setblock 397 65 -13 coarse_dirt
execute in minecraft:overworld run fill 397 66 -13 397 144 -13 air
execute in minecraft:overworld run fill 397 58 -12 397 61 -12 stone
execute in minecraft:overworld run fill 397 62 -12 397 63 -12 dirt
execute in minecraft:overworld run setblock 397 64 -12 grass_block
execute in minecraft:overworld run fill 397 65 -12 397 144 -12 air
execute in minecraft:overworld run fill 397 58 -11 397 61 -11 stone
execute in minecraft:overworld run fill 397 62 -11 397 63 -11 dirt
execute in minecraft:overworld run setblock 397 64 -11 coarse_dirt
execute in minecraft:overworld run fill 397 65 -11 397 144 -11 air
execute in minecraft:overworld run fill 397 58 -10 397 60 -10 stone
execute in minecraft:overworld run fill 397 61 -10 397 62 -10 dirt
execute in minecraft:overworld run setblock 397 63 -10 gravel
execute in minecraft:overworld run fill 397 64 -10 397 144 -10 air
execute in minecraft:overworld run fill 397 64 -10 397 64 -10 water
execute in minecraft:overworld run fill 397 58 -9 397 60 -9 stone
execute in minecraft:overworld run fill 397 61 -9 397 62 -9 dirt
execute in minecraft:overworld run setblock 397 63 -9 gravel
execute in minecraft:overworld run fill 397 64 -9 397 144 -9 air
execute in minecraft:overworld run fill 397 64 -9 397 64 -9 water
execute in minecraft:overworld run fill 397 58 -8 397 59 -8 stone
execute in minecraft:overworld run fill 397 60 -8 397 61 -8 dirt
execute in minecraft:overworld run setblock 397 62 -8 gravel
execute in minecraft:overworld run fill 397 63 -8 397 144 -8 air
execute in minecraft:overworld run fill 397 63 -8 397 64 -8 water
execute in minecraft:overworld run fill 397 58 -7 397 58 -7 stone
execute in minecraft:overworld run fill 397 59 -7 397 60 -7 dirt
execute in minecraft:overworld run setblock 397 61 -7 gravel
execute in minecraft:overworld run fill 397 62 -7 397 144 -7 air
execute in minecraft:overworld run fill 397 62 -7 397 64 -7 water
execute in minecraft:overworld run fill 397 58 -6 397 58 -6 stone
execute in minecraft:overworld run fill 397 59 -6 397 60 -6 dirt
execute in minecraft:overworld run setblock 397 61 -6 gravel
execute in minecraft:overworld run fill 397 62 -6 397 144 -6 air
execute in minecraft:overworld run fill 397 62 -6 397 64 -6 water
execute in minecraft:overworld run fill 397 58 -5 397 57 -5 stone
execute in minecraft:overworld run fill 397 58 -5 397 59 -5 dirt
execute in minecraft:overworld run setblock 397 60 -5 gravel
execute in minecraft:overworld run fill 397 61 -5 397 144 -5 air
execute in minecraft:overworld run fill 397 61 -5 397 64 -5 water
execute in minecraft:overworld run fill 397 58 -4 397 56 -4 stone
execute in minecraft:overworld run fill 397 57 -4 397 58 -4 dirt
execute in minecraft:overworld run setblock 397 59 -4 gravel
execute in minecraft:overworld run fill 397 60 -4 397 144 -4 air
execute in minecraft:overworld run fill 397 60 -4 397 64 -4 water
execute in minecraft:overworld run fill 397 58 -3 397 56 -3 stone
execute in minecraft:overworld run fill 397 57 -3 397 58 -3 dirt
execute in minecraft:overworld run setblock 397 59 -3 gravel
execute in minecraft:overworld run fill 397 60 -3 397 144 -3 air
execute in minecraft:overworld run fill 397 60 -3 397 64 -3 water
execute in minecraft:overworld run fill 397 58 -2 397 55 -2 stone
execute in minecraft:overworld run fill 397 56 -2 397 57 -2 dirt
execute in minecraft:overworld run setblock 397 58 -2 gravel
execute in minecraft:overworld run fill 397 59 -2 397 144 -2 air
execute in minecraft:overworld run fill 397 59 -2 397 64 -2 water
execute in minecraft:overworld run fill 397 58 -1 397 55 -1 stone
execute in minecraft:overworld run fill 397 56 -1 397 57 -1 dirt
execute in minecraft:overworld run setblock 397 58 -1 gravel
execute in minecraft:overworld run fill 397 59 -1 397 144 -1 air
execute in minecraft:overworld run fill 397 59 -1 397 64 -1 water
execute in minecraft:overworld run fill 397 58 0 397 55 0 stone
execute in minecraft:overworld run fill 397 56 0 397 57 0 dirt
execute in minecraft:overworld run setblock 397 58 0 gravel
execute in minecraft:overworld run fill 397 59 0 397 144 0 air
execute in minecraft:overworld run fill 397 59 0 397 64 0 water
execute in minecraft:overworld run fill 397 58 1 397 54 1 stone
execute in minecraft:overworld run fill 397 55 1 397 56 1 dirt
execute in minecraft:overworld run setblock 397 57 1 gravel
execute in minecraft:overworld run fill 397 58 1 397 144 1 air
execute in minecraft:overworld run fill 397 58 1 397 64 1 water
execute in minecraft:overworld run fill 397 58 2 397 54 2 stone
execute in minecraft:overworld run fill 397 55 2 397 56 2 dirt
execute in minecraft:overworld run setblock 397 57 2 gravel
execute in minecraft:overworld run fill 397 58 2 397 144 2 air
execute in minecraft:overworld run fill 397 58 2 397 64 2 water
execute in minecraft:overworld run fill 397 58 3 397 54 3 stone
execute in minecraft:overworld run fill 397 55 3 397 56 3 dirt
execute in minecraft:overworld run setblock 397 57 3 gravel
execute in minecraft:overworld run fill 397 58 3 397 144 3 air
execute in minecraft:overworld run fill 397 58 3 397 64 3 water
execute in minecraft:overworld run fill 397 58 4 397 54 4 stone
execute in minecraft:overworld run fill 397 55 4 397 56 4 dirt
execute in minecraft:overworld run setblock 397 57 4 gravel
execute in minecraft:overworld run fill 397 58 4 397 144 4 air
execute in minecraft:overworld run fill 397 58 4 397 64 4 water
execute in minecraft:overworld run fill 397 58 5 397 54 5 stone
execute in minecraft:overworld run fill 397 55 5 397 56 5 dirt
execute in minecraft:overworld run setblock 397 57 5 gravel
execute in minecraft:overworld run fill 397 58 5 397 144 5 air
execute in minecraft:overworld run fill 397 58 5 397 64 5 water
execute in minecraft:overworld run fill 397 58 6 397 54 6 stone
execute in minecraft:overworld run fill 397 55 6 397 56 6 dirt
execute in minecraft:overworld run setblock 397 57 6 gravel
execute in minecraft:overworld run fill 397 58 6 397 144 6 air
execute in minecraft:overworld run fill 397 58 6 397 64 6 water
execute in minecraft:overworld run fill 397 58 7 397 54 7 stone
execute in minecraft:overworld run fill 397 55 7 397 56 7 dirt
execute in minecraft:overworld run setblock 397 57 7 gravel
execute in minecraft:overworld run fill 397 58 7 397 144 7 air
execute in minecraft:overworld run fill 397 58 7 397 64 7 water
execute in minecraft:overworld run fill 397 58 8 397 54 8 stone
execute in minecraft:overworld run fill 397 55 8 397 56 8 dirt
execute in minecraft:overworld run setblock 397 57 8 gravel
execute in minecraft:overworld run fill 397 58 8 397 144 8 air
execute in minecraft:overworld run fill 397 58 8 397 64 8 water
execute in minecraft:overworld run fill 397 58 9 397 54 9 stone
execute in minecraft:overworld run fill 397 55 9 397 56 9 dirt
execute in minecraft:overworld run setblock 397 57 9 gravel
execute in minecraft:overworld run fill 397 58 9 397 144 9 air
execute in minecraft:overworld run fill 397 58 9 397 64 9 water
execute in minecraft:overworld run fill 397 58 10 397 55 10 stone
execute in minecraft:overworld run fill 397 56 10 397 57 10 dirt
execute in minecraft:overworld run setblock 397 58 10 gravel
execute in minecraft:overworld run fill 397 59 10 397 144 10 air
execute in minecraft:overworld run fill 397 59 10 397 64 10 water
execute in minecraft:overworld run fill 397 58 11 397 55 11 stone
execute in minecraft:overworld run fill 397 56 11 397 57 11 dirt
execute in minecraft:overworld run setblock 397 58 11 gravel
execute in minecraft:overworld run fill 397 59 11 397 144 11 air
execute in minecraft:overworld run fill 397 59 11 397 64 11 water
execute in minecraft:overworld run fill 397 58 12 397 55 12 stone
execute in minecraft:overworld run fill 397 56 12 397 57 12 dirt
execute in minecraft:overworld run setblock 397 58 12 gravel
execute in minecraft:overworld run fill 397 59 12 397 144 12 air
execute in minecraft:overworld run fill 397 59 12 397 64 12 water
execute in minecraft:overworld run fill 397 58 13 397 56 13 stone
execute in minecraft:overworld run fill 397 57 13 397 58 13 dirt
execute in minecraft:overworld run setblock 397 59 13 gravel
execute in minecraft:overworld run fill 397 60 13 397 144 13 air
execute in minecraft:overworld run fill 397 60 13 397 64 13 water
execute in minecraft:overworld run fill 397 58 14 397 56 14 stone
execute in minecraft:overworld run fill 397 57 14 397 58 14 dirt
execute in minecraft:overworld run setblock 397 59 14 gravel
execute in minecraft:overworld run fill 397 60 14 397 144 14 air
execute in minecraft:overworld run fill 397 60 14 397 64 14 water
execute in minecraft:overworld run fill 397 58 15 397 57 15 stone
execute in minecraft:overworld run fill 397 58 15 397 59 15 dirt
execute in minecraft:overworld run setblock 397 60 15 gravel
execute in minecraft:overworld run fill 397 61 15 397 144 15 air
execute in minecraft:overworld run fill 397 61 15 397 64 15 water
execute in minecraft:overworld run fill 397 58 16 397 57 16 stone
execute in minecraft:overworld run fill 397 58 16 397 59 16 dirt
execute in minecraft:overworld run setblock 397 60 16 gravel
execute in minecraft:overworld run fill 397 61 16 397 144 16 air
execute in minecraft:overworld run fill 397 61 16 397 64 16 water
execute in minecraft:overworld run fill 397 58 17 397 58 17 stone
execute in minecraft:overworld run fill 397 59 17 397 60 17 dirt
execute in minecraft:overworld run setblock 397 61 17 gravel
execute in minecraft:overworld run fill 397 62 17 397 144 17 air
execute in minecraft:overworld run fill 397 62 17 397 64 17 water
execute in minecraft:overworld run fill 397 58 18 397 58 18 stone
execute in minecraft:overworld run fill 397 59 18 397 60 18 dirt
execute in minecraft:overworld run setblock 397 61 18 gravel
execute in minecraft:overworld run fill 397 62 18 397 144 18 air
execute in minecraft:overworld run fill 397 62 18 397 64 18 water
execute in minecraft:overworld run fill 397 58 19 397 58 19 stone
execute in minecraft:overworld run fill 397 59 19 397 60 19 dirt
execute in minecraft:overworld run setblock 397 61 19 gravel
execute in minecraft:overworld run fill 397 62 19 397 144 19 air
execute in minecraft:overworld run fill 397 62 19 397 64 19 water
execute in minecraft:overworld run fill 397 58 20 397 58 20 stone
execute in minecraft:overworld run fill 397 59 20 397 60 20 dirt
execute in minecraft:overworld run setblock 397 61 20 gravel
execute in minecraft:overworld run fill 397 62 20 397 144 20 air
schedule function blade_gallery:random/battlefield/part_97 1t replace
