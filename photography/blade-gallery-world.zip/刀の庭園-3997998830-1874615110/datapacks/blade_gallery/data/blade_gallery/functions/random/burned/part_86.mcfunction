execute in minecraft:overworld run fill 262 58 40 262 57 40 stone
execute in minecraft:overworld run fill 262 58 40 262 59 40 dirt
execute in minecraft:overworld run setblock 262 60 40 gravel
execute in minecraft:overworld run fill 262 61 40 262 144 40 air
execute in minecraft:overworld run fill 262 61 40 262 64 40 water
execute in minecraft:overworld run fill 262 58 41 262 57 41 stone
execute in minecraft:overworld run fill 262 58 41 262 59 41 dirt
execute in minecraft:overworld run setblock 262 60 41 gravel
execute in minecraft:overworld run fill 262 61 41 262 144 41 air
execute in minecraft:overworld run fill 262 61 41 262 64 41 water
execute in minecraft:overworld run fill 262 58 42 262 58 42 stone
execute in minecraft:overworld run fill 262 59 42 262 60 42 dirt
execute in minecraft:overworld run setblock 262 61 42 gravel
execute in minecraft:overworld run fill 262 62 42 262 144 42 air
execute in minecraft:overworld run fill 262 62 42 262 64 42 water
execute in minecraft:overworld run fill 262 58 43 262 59 43 stone
execute in minecraft:overworld run fill 262 60 43 262 61 43 dirt
execute in minecraft:overworld run setblock 262 62 43 gravel
execute in minecraft:overworld run fill 262 63 43 262 144 43 air
execute in minecraft:overworld run fill 262 63 43 262 64 43 water
execute in minecraft:overworld run fill 262 58 44 262 60 44 stone
execute in minecraft:overworld run fill 262 61 44 262 62 44 dirt
execute in minecraft:overworld run setblock 262 63 44 gravel
execute in minecraft:overworld run fill 262 64 44 262 144 44 air
execute in minecraft:overworld run fill 262 64 44 262 64 44 water
execute in minecraft:overworld run fill 262 58 45 262 60 45 stone
execute in minecraft:overworld run fill 262 61 45 262 62 45 dirt
execute in minecraft:overworld run setblock 262 63 45 gravel
execute in minecraft:overworld run fill 262 64 45 262 144 45 air
execute in minecraft:overworld run fill 262 64 45 262 64 45 water
execute in minecraft:overworld run fill 262 58 46 262 60 46 stone
execute in minecraft:overworld run fill 262 61 46 262 62 46 dirt
execute in minecraft:overworld run setblock 262 63 46 gravel
execute in minecraft:overworld run fill 262 64 46 262 144 46 air
execute in minecraft:overworld run fill 262 64 46 262 64 46 water
execute in minecraft:overworld run fill 262 58 47 262 61 47 stone
execute in minecraft:overworld run fill 262 62 47 262 63 47 dirt
execute in minecraft:overworld run setblock 262 64 47 grass_block
execute in minecraft:overworld run fill 262 65 47 262 144 47 air
execute in minecraft:overworld run fill 263 58 -48 263 61 -48 stone
execute in minecraft:overworld run fill 263 62 -48 263 63 -48 dirt
execute in minecraft:overworld run setblock 263 64 -48 coarse_dirt
execute in minecraft:overworld run fill 263 65 -48 263 144 -48 air
execute in minecraft:overworld run fill 263 58 -47 263 63 -47 stone
execute in minecraft:overworld run fill 263 64 -47 263 65 -47 dirt
execute in minecraft:overworld run setblock 263 66 -47 coarse_dirt
execute in minecraft:overworld run fill 263 67 -47 263 144 -47 air
execute in minecraft:overworld run fill 263 58 -46 263 65 -46 stone
execute in minecraft:overworld run fill 263 66 -46 263 67 -46 dirt
execute in minecraft:overworld run setblock 263 68 -46 grass_block
execute in minecraft:overworld run fill 263 69 -46 263 144 -46 air
execute in minecraft:overworld run fill 263 58 -45 263 66 -45 stone
execute in minecraft:overworld run fill 263 67 -45 263 68 -45 dirt
execute in minecraft:overworld run setblock 263 69 -45 coarse_dirt
execute in minecraft:overworld run fill 263 70 -45 263 144 -45 air
execute in minecraft:overworld run fill 263 58 -44 263 68 -44 stone
execute in minecraft:overworld run fill 263 69 -44 263 70 -44 dirt
execute in minecraft:overworld run setblock 263 71 -44 coarse_dirt
execute in minecraft:overworld run fill 263 72 -44 263 144 -44 air
execute in minecraft:overworld run fill 263 58 -43 263 70 -43 stone
execute in minecraft:overworld run fill 263 71 -43 263 72 -43 dirt
execute in minecraft:overworld run setblock 263 73 -43 coarse_dirt
execute in minecraft:overworld run fill 263 74 -43 263 144 -43 air
execute in minecraft:overworld run fill 263 58 -42 263 72 -42 stone
execute in minecraft:overworld run fill 263 73 -42 263 74 -42 dirt
execute in minecraft:overworld run setblock 263 75 -42 coarse_dirt
execute in minecraft:overworld run fill 263 76 -42 263 144 -42 air
execute in minecraft:overworld run fill 263 58 -41 263 73 -41 stone
execute in minecraft:overworld run fill 263 74 -41 263 75 -41 dirt
execute in minecraft:overworld run setblock 263 76 -41 coarse_dirt
execute in minecraft:overworld run fill 263 77 -41 263 144 -41 air
execute in minecraft:overworld run setblock 263 77 -41 grass
execute in minecraft:overworld run fill 263 58 -40 263 75 -40 stone
execute in minecraft:overworld run fill 263 76 -40 263 77 -40 dirt
execute in minecraft:overworld run setblock 263 78 -40 coarse_dirt
execute in minecraft:overworld run fill 263 79 -40 263 144 -40 air
execute in minecraft:overworld run fill 263 58 -39 263 76 -39 stone
execute in minecraft:overworld run fill 263 77 -39 263 78 -39 dirt
execute in minecraft:overworld run setblock 263 79 -39 grass_block
execute in minecraft:overworld run fill 263 80 -39 263 144 -39 air
execute in minecraft:overworld run fill 263 58 -38 263 78 -38 stone
execute in minecraft:overworld run fill 263 79 -38 263 80 -38 dirt
execute in minecraft:overworld run setblock 263 81 -38 grass_block
execute in minecraft:overworld run fill 263 82 -38 263 144 -38 air
execute in minecraft:overworld run fill 263 58 -37 263 78 -37 stone
execute in minecraft:overworld run fill 263 79 -37 263 80 -37 dirt
execute in minecraft:overworld run setblock 263 81 -37 coarse_dirt
execute in minecraft:overworld run fill 263 82 -37 263 144 -37 air
execute in minecraft:overworld run fill 263 58 -36 263 78 -36 stone
execute in minecraft:overworld run fill 263 79 -36 263 80 -36 dirt
execute in minecraft:overworld run setblock 263 81 -36 grass_block
execute in minecraft:overworld run fill 263 82 -36 263 144 -36 air
execute in minecraft:overworld run fill 263 58 -35 263 77 -35 stone
execute in minecraft:overworld run fill 263 78 -35 263 79 -35 dirt
execute in minecraft:overworld run setblock 263 80 -35 coarse_dirt
execute in minecraft:overworld run fill 263 81 -35 263 144 -35 air
execute in minecraft:overworld run setblock 263 81 -35 grass
execute in minecraft:overworld run fill 263 58 -34 263 77 -34 stone
execute in minecraft:overworld run fill 263 78 -34 263 79 -34 dirt
execute in minecraft:overworld run setblock 263 80 -34 grass_block
execute in minecraft:overworld run fill 263 81 -34 263 144 -34 air
execute in minecraft:overworld run fill 263 58 -33 263 77 -33 stone
execute in minecraft:overworld run fill 263 78 -33 263 79 -33 dirt
execute in minecraft:overworld run setblock 263 80 -33 coarse_dirt
execute in minecraft:overworld run fill 263 81 -33 263 144 -33 air
execute in minecraft:overworld run fill 263 58 -32 263 77 -32 stone
execute in minecraft:overworld run fill 263 78 -32 263 79 -32 dirt
execute in minecraft:overworld run setblock 263 80 -32 coarse_dirt
execute in minecraft:overworld run fill 263 81 -32 263 144 -32 air
execute in minecraft:overworld run fill 263 58 -31 263 76 -31 stone
execute in minecraft:overworld run fill 263 77 -31 263 78 -31 dirt
execute in minecraft:overworld run setblock 263 79 -31 coarse_dirt
execute in minecraft:overworld run fill 263 80 -31 263 144 -31 air
execute in minecraft:overworld run fill 263 58 -30 263 76 -30 stone
execute in minecraft:overworld run fill 263 77 -30 263 78 -30 dirt
execute in minecraft:overworld run setblock 263 79 -30 coarse_dirt
execute in minecraft:overworld run fill 263 80 -30 263 144 -30 air
execute in minecraft:overworld run fill 263 58 -29 263 76 -29 stone
execute in minecraft:overworld run fill 263 77 -29 263 78 -29 dirt
execute in minecraft:overworld run setblock 263 79 -29 coarse_dirt
execute in minecraft:overworld run fill 263 80 -29 263 144 -29 air
execute in minecraft:overworld run setblock 263 80 -29 grass
execute in minecraft:overworld run fill 263 58 -28 263 75 -28 stone
execute in minecraft:overworld run fill 263 76 -28 263 77 -28 dirt
execute in minecraft:overworld run setblock 263 78 -28 coarse_dirt
execute in minecraft:overworld run fill 263 79 -28 263 144 -28 air
execute in minecraft:overworld run fill 263 58 -27 263 75 -27 stone
execute in minecraft:overworld run fill 263 76 -27 263 77 -27 dirt
execute in minecraft:overworld run setblock 263 78 -27 coarse_dirt
execute in minecraft:overworld run fill 263 79 -27 263 144 -27 air
execute in minecraft:overworld run fill 263 58 -26 263 74 -26 stone
execute in minecraft:overworld run fill 263 75 -26 263 76 -26 dirt
execute in minecraft:overworld run setblock 263 77 -26 grass_block
execute in minecraft:overworld run fill 263 78 -26 263 144 -26 air
execute in minecraft:overworld run fill 263 58 -25 263 73 -25 stone
execute in minecraft:overworld run fill 263 74 -25 263 75 -25 dirt
execute in minecraft:overworld run setblock 263 76 -25 coarse_dirt
execute in minecraft:overworld run fill 263 77 -25 263 144 -25 air
execute in minecraft:overworld run fill 263 58 -24 263 72 -24 stone
execute in minecraft:overworld run fill 263 73 -24 263 74 -24 dirt
execute in minecraft:overworld run setblock 263 75 -24 coarse_dirt
execute in minecraft:overworld run fill 263 76 -24 263 144 -24 air
execute in minecraft:overworld run fill 263 58 -23 263 71 -23 stone
execute in minecraft:overworld run fill 263 72 -23 263 73 -23 dirt
execute in minecraft:overworld run setblock 263 74 -23 grass_block
execute in minecraft:overworld run fill 263 75 -23 263 144 -23 air
execute in minecraft:overworld run fill 263 58 -22 263 69 -22 stone
execute in minecraft:overworld run fill 263 70 -22 263 71 -22 dirt
execute in minecraft:overworld run setblock 263 72 -22 coarse_dirt
execute in minecraft:overworld run fill 263 73 -22 263 144 -22 air
execute in minecraft:overworld run fill 263 58 -21 263 68 -21 stone
execute in minecraft:overworld run fill 263 69 -21 263 70 -21 dirt
execute in minecraft:overworld run setblock 263 71 -21 grass_block
execute in minecraft:overworld run fill 263 72 -21 263 144 -21 air
execute in minecraft:overworld run fill 263 58 -20 263 67 -20 stone
execute in minecraft:overworld run fill 263 68 -20 263 69 -20 dirt
execute in minecraft:overworld run setblock 263 70 -20 grass_block
execute in minecraft:overworld run fill 263 71 -20 263 144 -20 air
execute in minecraft:overworld run setblock 263 71 -20 grass
execute in minecraft:overworld run fill 263 58 -19 263 66 -19 stone
execute in minecraft:overworld run fill 263 67 -19 263 68 -19 dirt
execute in minecraft:overworld run setblock 263 69 -19 coarse_dirt
execute in minecraft:overworld run fill 263 70 -19 263 144 -19 air
execute in minecraft:overworld run setblock 263 70 -19 grass
execute in minecraft:overworld run fill 263 58 -18 263 65 -18 stone
execute in minecraft:overworld run fill 263 66 -18 263 67 -18 dirt
execute in minecraft:overworld run setblock 263 68 -18 coarse_dirt
execute in minecraft:overworld run fill 263 69 -18 263 144 -18 air
execute in minecraft:overworld run fill 263 58 -17 263 63 -17 stone
execute in minecraft:overworld run fill 263 64 -17 263 65 -17 dirt
execute in minecraft:overworld run setblock 263 66 -17 grass_block
execute in minecraft:overworld run fill 263 67 -17 263 144 -17 air
execute in minecraft:overworld run fill 263 58 -16 263 62 -16 stone
execute in minecraft:overworld run fill 263 63 -16 263 64 -16 dirt
execute in minecraft:overworld run setblock 263 65 -16 coarse_dirt
execute in minecraft:overworld run fill 263 66 -16 263 144 -16 air
execute in minecraft:overworld run fill 263 58 -15 263 61 -15 stone
execute in minecraft:overworld run fill 263 62 -15 263 63 -15 dirt
execute in minecraft:overworld run setblock 263 64 -15 grass_block
execute in minecraft:overworld run fill 263 65 -15 263 144 -15 air
execute in minecraft:overworld run fill 263 58 -14 263 60 -14 stone
execute in minecraft:overworld run fill 263 61 -14 263 62 -14 dirt
execute in minecraft:overworld run setblock 263 63 -14 gravel
execute in minecraft:overworld run fill 263 64 -14 263 144 -14 air
execute in minecraft:overworld run fill 263 64 -14 263 64 -14 water
execute in minecraft:overworld run fill 263 58 -13 263 59 -13 stone
execute in minecraft:overworld run fill 263 60 -13 263 61 -13 dirt
execute in minecraft:overworld run setblock 263 62 -13 gravel
execute in minecraft:overworld run fill 263 63 -13 263 144 -13 air
execute in minecraft:overworld run fill 263 63 -13 263 64 -13 water
execute in minecraft:overworld run fill 263 58 -12 263 57 -12 stone
execute in minecraft:overworld run fill 263 58 -12 263 59 -12 dirt
execute in minecraft:overworld run setblock 263 60 -12 gravel
execute in minecraft:overworld run fill 263 61 -12 263 144 -12 air
execute in minecraft:overworld run fill 263 61 -12 263 64 -12 water
execute in minecraft:overworld run fill 263 58 -11 263 57 -11 stone
execute in minecraft:overworld run fill 263 58 -11 263 59 -11 dirt
execute in minecraft:overworld run setblock 263 60 -11 gravel
execute in minecraft:overworld run fill 263 61 -11 263 144 -11 air
execute in minecraft:overworld run fill 263 61 -11 263 64 -11 water
execute in minecraft:overworld run fill 263 58 -10 263 56 -10 stone
execute in minecraft:overworld run fill 263 57 -10 263 58 -10 dirt
execute in minecraft:overworld run setblock 263 59 -10 gravel
execute in minecraft:overworld run fill 263 60 -10 263 144 -10 air
execute in minecraft:overworld run fill 263 60 -10 263 64 -10 water
execute in minecraft:overworld run fill 263 58 -9 263 56 -9 stone
execute in minecraft:overworld run fill 263 57 -9 263 58 -9 dirt
execute in minecraft:overworld run setblock 263 59 -9 gravel
execute in minecraft:overworld run fill 263 60 -9 263 144 -9 air
execute in minecraft:overworld run fill 263 60 -9 263 64 -9 water
execute in minecraft:overworld run fill 263 58 -8 263 56 -8 stone
execute in minecraft:overworld run fill 263 57 -8 263 58 -8 dirt
execute in minecraft:overworld run setblock 263 59 -8 gravel
execute in minecraft:overworld run fill 263 60 -8 263 144 -8 air
execute in minecraft:overworld run fill 263 60 -8 263 64 -8 water
execute in minecraft:overworld run fill 263 58 -7 263 55 -7 stone
execute in minecraft:overworld run fill 263 56 -7 263 57 -7 dirt
execute in minecraft:overworld run setblock 263 58 -7 gravel
execute in minecraft:overworld run fill 263 59 -7 263 144 -7 air
execute in minecraft:overworld run fill 263 59 -7 263 64 -7 water
execute in minecraft:overworld run fill 263 58 -6 263 55 -6 stone
execute in minecraft:overworld run fill 263 56 -6 263 57 -6 dirt
execute in minecraft:overworld run setblock 263 58 -6 gravel
execute in minecraft:overworld run fill 263 59 -6 263 144 -6 air
execute in minecraft:overworld run fill 263 59 -6 263 64 -6 water
execute in minecraft:overworld run fill 263 58 -5 263 55 -5 stone
execute in minecraft:overworld run fill 263 56 -5 263 57 -5 dirt
execute in minecraft:overworld run setblock 263 58 -5 gravel
execute in minecraft:overworld run fill 263 59 -5 263 144 -5 air
execute in minecraft:overworld run fill 263 59 -5 263 64 -5 water
execute in minecraft:overworld run fill 263 58 -4 263 54 -4 stone
execute in minecraft:overworld run fill 263 55 -4 263 56 -4 dirt
execute in minecraft:overworld run setblock 263 57 -4 gravel
execute in minecraft:overworld run fill 263 58 -4 263 144 -4 air
execute in minecraft:overworld run fill 263 58 -4 263 64 -4 water
execute in minecraft:overworld run fill 263 58 -3 263 54 -3 stone
execute in minecraft:overworld run fill 263 55 -3 263 56 -3 dirt
execute in minecraft:overworld run setblock 263 57 -3 gravel
execute in minecraft:overworld run fill 263 58 -3 263 144 -3 air
execute in minecraft:overworld run fill 263 58 -3 263 64 -3 water
execute in minecraft:overworld run fill 263 58 -2 263 54 -2 stone
execute in minecraft:overworld run fill 263 55 -2 263 56 -2 dirt
execute in minecraft:overworld run setblock 263 57 -2 gravel
execute in minecraft:overworld run fill 263 58 -2 263 144 -2 air
execute in minecraft:overworld run fill 263 58 -2 263 64 -2 water
execute in minecraft:overworld run fill 263 58 -1 263 54 -1 stone
execute in minecraft:overworld run fill 263 55 -1 263 56 -1 dirt
execute in minecraft:overworld run setblock 263 57 -1 gravel
execute in minecraft:overworld run fill 263 58 -1 263 144 -1 air
execute in minecraft:overworld run fill 263 58 -1 263 64 -1 water
execute in minecraft:overworld run fill 263 58 0 263 55 0 stone
execute in minecraft:overworld run fill 263 56 0 263 57 0 dirt
execute in minecraft:overworld run setblock 263 58 0 gravel
execute in minecraft:overworld run fill 263 59 0 263 144 0 air
execute in minecraft:overworld run fill 263 59 0 263 64 0 water
execute in minecraft:overworld run fill 263 58 1 263 55 1 stone
schedule function blade_gallery:random/burned/part_87 1t replace
