function blade_gallery:random/setup
