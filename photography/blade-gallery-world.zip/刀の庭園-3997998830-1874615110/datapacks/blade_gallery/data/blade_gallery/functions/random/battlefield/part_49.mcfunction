execute in minecraft:overworld run fill 368 66 -47 368 144 -47 air
execute in minecraft:overworld run fill 368 58 -46 368 63 -46 stone
execute in minecraft:overworld run fill 368 64 -46 368 65 -46 dirt
execute in minecraft:overworld run setblock 368 66 -46 coarse_dirt
execute in minecraft:overworld run fill 368 67 -46 368 144 -46 air
execute in minecraft:overworld run fill 368 58 -45 368 65 -45 stone
execute in minecraft:overworld run fill 368 66 -45 368 67 -45 dirt
execute in minecraft:overworld run setblock 368 68 -45 coarse_dirt
execute in minecraft:overworld run fill 368 69 -45 368 144 -45 air
execute in minecraft:overworld run fill 368 58 -44 368 66 -44 stone
execute in minecraft:overworld run fill 368 67 -44 368 68 -44 dirt
execute in minecraft:overworld run setblock 368 69 -44 coarse_dirt
execute in minecraft:overworld run fill 368 70 -44 368 144 -44 air
execute in minecraft:overworld run fill 368 58 -43 368 67 -43 stone
execute in minecraft:overworld run fill 368 68 -43 368 69 -43 dirt
execute in minecraft:overworld run setblock 368 70 -43 coarse_dirt
execute in minecraft:overworld run fill 368 71 -43 368 144 -43 air
execute in minecraft:overworld run fill 368 58 -42 368 68 -42 stone
execute in minecraft:overworld run fill 368 69 -42 368 70 -42 dirt
execute in minecraft:overworld run setblock 368 71 -42 grass_block
execute in minecraft:overworld run fill 368 72 -42 368 144 -42 air
execute in minecraft:overworld run fill 368 58 -41 368 69 -41 stone
execute in minecraft:overworld run fill 368 70 -41 368 71 -41 dirt
execute in minecraft:overworld run setblock 368 72 -41 coarse_dirt
execute in minecraft:overworld run fill 368 73 -41 368 144 -41 air
execute in minecraft:overworld run fill 368 58 -40 368 70 -40 stone
execute in minecraft:overworld run fill 368 71 -40 368 72 -40 dirt
execute in minecraft:overworld run setblock 368 73 -40 grass_block
execute in minecraft:overworld run fill 368 74 -40 368 144 -40 air
execute in minecraft:overworld run setblock 368 74 -40 grass
execute in minecraft:overworld run fill 368 58 -39 368 71 -39 stone
execute in minecraft:overworld run fill 368 72 -39 368 73 -39 dirt
execute in minecraft:overworld run setblock 368 74 -39 coarse_dirt
execute in minecraft:overworld run fill 368 75 -39 368 144 -39 air
execute in minecraft:overworld run fill 368 58 -38 368 72 -38 stone
execute in minecraft:overworld run fill 368 73 -38 368 74 -38 dirt
execute in minecraft:overworld run setblock 368 75 -38 coarse_dirt
execute in minecraft:overworld run fill 368 76 -38 368 144 -38 air
execute in minecraft:overworld run fill 368 58 -37 368 72 -37 stone
execute in minecraft:overworld run fill 368 73 -37 368 74 -37 dirt
execute in minecraft:overworld run setblock 368 75 -37 coarse_dirt
execute in minecraft:overworld run fill 368 76 -37 368 144 -37 air
execute in minecraft:overworld run fill 368 58 -36 368 72 -36 stone
execute in minecraft:overworld run fill 368 73 -36 368 74 -36 dirt
execute in minecraft:overworld run setblock 368 75 -36 coarse_dirt
execute in minecraft:overworld run fill 368 76 -36 368 144 -36 air
execute in minecraft:overworld run fill 368 58 -35 368 72 -35 stone
execute in minecraft:overworld run fill 368 73 -35 368 74 -35 dirt
execute in minecraft:overworld run setblock 368 75 -35 grass_block
execute in minecraft:overworld run fill 368 76 -35 368 144 -35 air
execute in minecraft:overworld run fill 368 58 -34 368 72 -34 stone
execute in minecraft:overworld run fill 368 73 -34 368 74 -34 dirt
execute in minecraft:overworld run setblock 368 75 -34 coarse_dirt
execute in minecraft:overworld run fill 368 76 -34 368 144 -34 air
execute in minecraft:overworld run fill 368 58 -33 368 72 -33 stone
execute in minecraft:overworld run fill 368 73 -33 368 74 -33 dirt
execute in minecraft:overworld run setblock 368 75 -33 grass_block
execute in minecraft:overworld run fill 368 76 -33 368 144 -33 air
execute in minecraft:overworld run fill 368 58 -32 368 72 -32 stone
execute in minecraft:overworld run fill 368 73 -32 368 74 -32 dirt
execute in minecraft:overworld run setblock 368 75 -32 grass_block
execute in minecraft:overworld run fill 368 76 -32 368 144 -32 air
execute in minecraft:overworld run fill 368 58 -31 368 72 -31 stone
execute in minecraft:overworld run fill 368 73 -31 368 74 -31 dirt
execute in minecraft:overworld run setblock 368 75 -31 coarse_dirt
execute in minecraft:overworld run fill 368 76 -31 368 144 -31 air
execute in minecraft:overworld run fill 368 58 -30 368 72 -30 stone
execute in minecraft:overworld run fill 368 73 -30 368 74 -30 dirt
execute in minecraft:overworld run setblock 368 75 -30 grass_block
execute in minecraft:overworld run fill 368 76 -30 368 144 -30 air
execute in minecraft:overworld run fill 368 58 -29 368 71 -29 stone
execute in minecraft:overworld run fill 368 72 -29 368 73 -29 dirt
execute in minecraft:overworld run setblock 368 74 -29 grass_block
execute in minecraft:overworld run fill 368 75 -29 368 144 -29 air
execute in minecraft:overworld run fill 368 58 -28 368 71 -28 stone
execute in minecraft:overworld run fill 368 72 -28 368 73 -28 dirt
execute in minecraft:overworld run setblock 368 74 -28 coarse_dirt
execute in minecraft:overworld run fill 368 75 -28 368 144 -28 air
execute in minecraft:overworld run fill 368 58 -27 368 71 -27 stone
execute in minecraft:overworld run fill 368 72 -27 368 73 -27 dirt
execute in minecraft:overworld run setblock 368 74 -27 coarse_dirt
execute in minecraft:overworld run fill 368 75 -27 368 144 -27 air
execute in minecraft:overworld run setblock 368 75 -27 grass
execute in minecraft:overworld run fill 368 58 -26 368 71 -26 stone
execute in minecraft:overworld run fill 368 72 -26 368 73 -26 dirt
execute in minecraft:overworld run setblock 368 74 -26 coarse_dirt
execute in minecraft:overworld run fill 368 75 -26 368 144 -26 air
execute in minecraft:overworld run fill 368 58 -25 368 70 -25 stone
execute in minecraft:overworld run fill 368 71 -25 368 72 -25 dirt
execute in minecraft:overworld run setblock 368 73 -25 coarse_dirt
execute in minecraft:overworld run fill 368 74 -25 368 144 -25 air
execute in minecraft:overworld run setblock 368 74 -25 grass
execute in minecraft:overworld run fill 368 58 -24 368 70 -24 stone
execute in minecraft:overworld run fill 368 71 -24 368 72 -24 dirt
execute in minecraft:overworld run setblock 368 73 -24 coarse_dirt
execute in minecraft:overworld run fill 368 74 -24 368 144 -24 air
execute in minecraft:overworld run setblock 368 74 -24 mossy_cobblestone
execute in minecraft:overworld run fill 368 58 -23 368 70 -23 stone
execute in minecraft:overworld run fill 368 71 -23 368 72 -23 dirt
execute in minecraft:overworld run setblock 368 73 -23 coarse_dirt
execute in minecraft:overworld run fill 368 74 -23 368 144 -23 air
execute in minecraft:overworld run fill 368 58 -22 368 69 -22 stone
execute in minecraft:overworld run fill 368 70 -22 368 71 -22 dirt
execute in minecraft:overworld run setblock 368 72 -22 coarse_dirt
execute in minecraft:overworld run fill 368 73 -22 368 144 -22 air
execute in minecraft:overworld run fill 368 58 -21 368 69 -21 stone
execute in minecraft:overworld run fill 368 70 -21 368 71 -21 dirt
execute in minecraft:overworld run setblock 368 72 -21 grass_block
execute in minecraft:overworld run fill 368 73 -21 368 144 -21 air
execute in minecraft:overworld run setblock 368 73 -21 mossy_cobblestone
execute in minecraft:overworld run fill 368 58 -20 368 68 -20 stone
execute in minecraft:overworld run fill 368 69 -20 368 70 -20 dirt
execute in minecraft:overworld run setblock 368 71 -20 coarse_dirt
execute in minecraft:overworld run fill 368 72 -20 368 144 -20 air
execute in minecraft:overworld run fill 368 58 -19 368 68 -19 stone
execute in minecraft:overworld run fill 368 69 -19 368 70 -19 dirt
execute in minecraft:overworld run setblock 368 71 -19 grass_block
execute in minecraft:overworld run fill 368 72 -19 368 144 -19 air
execute in minecraft:overworld run fill 368 58 -18 368 68 -18 stone
execute in minecraft:overworld run fill 368 69 -18 368 70 -18 dirt
execute in minecraft:overworld run setblock 368 71 -18 coarse_dirt
execute in minecraft:overworld run fill 368 72 -18 368 144 -18 air
execute in minecraft:overworld run fill 368 58 -17 368 67 -17 stone
execute in minecraft:overworld run fill 368 68 -17 368 69 -17 dirt
execute in minecraft:overworld run setblock 368 70 -17 coarse_dirt
execute in minecraft:overworld run fill 368 71 -17 368 144 -17 air
execute in minecraft:overworld run fill 368 58 -16 368 67 -16 stone
execute in minecraft:overworld run fill 368 68 -16 368 69 -16 dirt
execute in minecraft:overworld run setblock 368 70 -16 coarse_dirt
execute in minecraft:overworld run fill 368 71 -16 368 144 -16 air
execute in minecraft:overworld run fill 368 58 -15 368 67 -15 stone
execute in minecraft:overworld run fill 368 68 -15 368 69 -15 dirt
execute in minecraft:overworld run setblock 368 70 -15 grass_block
execute in minecraft:overworld run fill 368 71 -15 368 144 -15 air
execute in minecraft:overworld run fill 368 58 -14 368 66 -14 stone
execute in minecraft:overworld run fill 368 67 -14 368 68 -14 dirt
execute in minecraft:overworld run setblock 368 69 -14 coarse_dirt
execute in minecraft:overworld run fill 368 70 -14 368 144 -14 air
execute in minecraft:overworld run fill 368 58 -13 368 66 -13 stone
execute in minecraft:overworld run fill 368 67 -13 368 68 -13 dirt
execute in minecraft:overworld run setblock 368 69 -13 grass_block
execute in minecraft:overworld run fill 368 70 -13 368 144 -13 air
execute in minecraft:overworld run fill 368 58 -12 368 66 -12 stone
execute in minecraft:overworld run fill 368 67 -12 368 68 -12 dirt
execute in minecraft:overworld run setblock 368 69 -12 coarse_dirt
execute in minecraft:overworld run fill 368 70 -12 368 144 -12 air
execute in minecraft:overworld run fill 368 58 -11 368 66 -11 stone
execute in minecraft:overworld run fill 368 67 -11 368 68 -11 dirt
execute in minecraft:overworld run setblock 368 69 -11 grass_block
execute in minecraft:overworld run fill 368 70 -11 368 144 -11 air
execute in minecraft:overworld run setblock 368 70 -11 grass
execute in minecraft:overworld run fill 368 58 -10 368 66 -10 stone
execute in minecraft:overworld run fill 368 67 -10 368 68 -10 dirt
execute in minecraft:overworld run setblock 368 69 -10 grass_block
execute in minecraft:overworld run fill 368 70 -10 368 144 -10 air
execute in minecraft:overworld run fill 368 58 -9 368 66 -9 stone
execute in minecraft:overworld run fill 368 67 -9 368 68 -9 dirt
execute in minecraft:overworld run setblock 368 69 -9 coarse_dirt
execute in minecraft:overworld run fill 368 70 -9 368 144 -9 air
execute in minecraft:overworld run fill 368 58 -8 368 66 -8 stone
execute in minecraft:overworld run fill 368 67 -8 368 68 -8 dirt
execute in minecraft:overworld run setblock 368 69 -8 grass_block
execute in minecraft:overworld run fill 368 70 -8 368 144 -8 air
execute in minecraft:overworld run fill 368 58 -7 368 66 -7 stone
execute in minecraft:overworld run fill 368 67 -7 368 68 -7 dirt
execute in minecraft:overworld run setblock 368 69 -7 grass_block
execute in minecraft:overworld run fill 368 70 -7 368 144 -7 air
execute in minecraft:overworld run fill 368 58 -6 368 66 -6 stone
execute in minecraft:overworld run fill 368 67 -6 368 68 -6 dirt
execute in minecraft:overworld run setblock 368 69 -6 coarse_dirt
execute in minecraft:overworld run fill 368 70 -6 368 144 -6 air
execute in minecraft:overworld run setblock 368 70 -6 grass
execute in minecraft:overworld run fill 368 58 -5 368 65 -5 stone
execute in minecraft:overworld run fill 368 66 -5 368 67 -5 dirt
execute in minecraft:overworld run setblock 368 68 -5 coarse_dirt
execute in minecraft:overworld run fill 368 69 -5 368 144 -5 air
execute in minecraft:overworld run setblock 368 69 -5 mossy_cobblestone
execute in minecraft:overworld run fill 368 58 -4 368 65 -4 stone
execute in minecraft:overworld run fill 368 66 -4 368 67 -4 dirt
execute in minecraft:overworld run setblock 368 68 -4 coarse_dirt
execute in minecraft:overworld run fill 368 69 -4 368 144 -4 air
execute in minecraft:overworld run fill 368 58 -3 368 65 -3 stone
execute in minecraft:overworld run fill 368 66 -3 368 67 -3 dirt
execute in minecraft:overworld run setblock 368 68 -3 coarse_dirt
execute in minecraft:overworld run fill 368 69 -3 368 144 -3 air
execute in minecraft:overworld run fill 368 58 -2 368 65 -2 stone
execute in minecraft:overworld run fill 368 66 -2 368 67 -2 dirt
execute in minecraft:overworld run setblock 368 68 -2 coarse_dirt
execute in minecraft:overworld run fill 368 69 -2 368 144 -2 air
execute in minecraft:overworld run fill 368 58 -1 368 65 -1 stone
execute in minecraft:overworld run fill 368 66 -1 368 67 -1 dirt
execute in minecraft:overworld run setblock 368 68 -1 coarse_dirt
execute in minecraft:overworld run fill 368 69 -1 368 144 -1 air
execute in minecraft:overworld run fill 368 58 0 368 65 0 stone
execute in minecraft:overworld run fill 368 66 0 368 67 0 dirt
execute in minecraft:overworld run setblock 368 68 0 coarse_dirt
execute in minecraft:overworld run fill 368 69 0 368 144 0 air
execute in minecraft:overworld run fill 368 58 1 368 65 1 stone
execute in minecraft:overworld run fill 368 66 1 368 67 1 dirt
execute in minecraft:overworld run setblock 368 68 1 grass_block
execute in minecraft:overworld run fill 368 69 1 368 144 1 air
execute in minecraft:overworld run fill 368 58 2 368 65 2 stone
execute in minecraft:overworld run fill 368 66 2 368 67 2 dirt
execute in minecraft:overworld run setblock 368 68 2 coarse_dirt
execute in minecraft:overworld run fill 368 69 2 368 144 2 air
execute in minecraft:overworld run fill 368 58 3 368 65 3 stone
execute in minecraft:overworld run fill 368 66 3 368 67 3 dirt
execute in minecraft:overworld run setblock 368 68 3 coarse_dirt
execute in minecraft:overworld run fill 368 69 3 368 144 3 air
execute in minecraft:overworld run fill 368 58 4 368 65 4 stone
execute in minecraft:overworld run fill 368 66 4 368 67 4 dirt
execute in minecraft:overworld run setblock 368 68 4 coarse_dirt
execute in minecraft:overworld run fill 368 69 4 368 144 4 air
execute in minecraft:overworld run fill 368 58 5 368 65 5 stone
execute in minecraft:overworld run fill 368 66 5 368 67 5 dirt
execute in minecraft:overworld run setblock 368 68 5 grass_block
execute in minecraft:overworld run fill 368 69 5 368 144 5 air
execute in minecraft:overworld run fill 368 58 6 368 65 6 stone
execute in minecraft:overworld run fill 368 66 6 368 67 6 dirt
execute in minecraft:overworld run setblock 368 68 6 coarse_dirt
execute in minecraft:overworld run fill 368 69 6 368 144 6 air
execute in minecraft:overworld run fill 368 58 7 368 65 7 stone
execute in minecraft:overworld run fill 368 66 7 368 67 7 dirt
execute in minecraft:overworld run setblock 368 68 7 grass_block
execute in minecraft:overworld run fill 368 69 7 368 144 7 air
execute in minecraft:overworld run fill 368 58 8 368 65 8 stone
execute in minecraft:overworld run fill 368 66 8 368 67 8 dirt
execute in minecraft:overworld run setblock 368 68 8 coarse_dirt
execute in minecraft:overworld run fill 368 69 8 368 144 8 air
execute in minecraft:overworld run fill 368 58 9 368 65 9 stone
execute in minecraft:overworld run fill 368 66 9 368 67 9 dirt
execute in minecraft:overworld run setblock 368 68 9 coarse_dirt
execute in minecraft:overworld run fill 368 69 9 368 144 9 air
execute in minecraft:overworld run fill 368 58 10 368 66 10 stone
execute in minecraft:overworld run fill 368 67 10 368 68 10 dirt
execute in minecraft:overworld run setblock 368 69 10 coarse_dirt
execute in minecraft:overworld run fill 368 70 10 368 144 10 air
execute in minecraft:overworld run fill 368 58 11 368 66 11 stone
execute in minecraft:overworld run fill 368 67 11 368 68 11 dirt
execute in minecraft:overworld run setblock 368 69 11 coarse_dirt
execute in minecraft:overworld run fill 368 70 11 368 144 11 air
execute in minecraft:overworld run fill 368 58 12 368 66 12 stone
execute in minecraft:overworld run fill 368 67 12 368 68 12 dirt
execute in minecraft:overworld run setblock 368 69 12 coarse_dirt
execute in minecraft:overworld run fill 368 70 12 368 144 12 air
execute in minecraft:overworld run setblock 368 70 12 grass
execute in minecraft:overworld run fill 368 58 13 368 66 13 stone
execute in minecraft:overworld run fill 368 67 13 368 68 13 dirt
execute in minecraft:overworld run setblock 368 69 13 coarse_dirt
execute in minecraft:overworld run fill 368 70 13 368 144 13 air
execute in minecraft:overworld run fill 368 58 14 368 67 14 stone
execute in minecraft:overworld run fill 368 68 14 368 69 14 dirt
execute in minecraft:overworld run setblock 368 70 14 coarse_dirt
execute in minecraft:overworld run fill 368 71 14 368 144 14 air
execute in minecraft:overworld run fill 368 58 15 368 67 15 stone
execute in minecraft:overworld run fill 368 68 15 368 69 15 dirt
schedule function blade_gallery:random/battlefield/part_50 1t replace
