execute in minecraft:overworld run setblock 420 73 21 grass_block
execute in minecraft:overworld run fill 420 74 21 420 144 21 air
execute in minecraft:overworld run fill 420 58 22 420 71 22 stone
execute in minecraft:overworld run fill 420 72 22 420 73 22 dirt
execute in minecraft:overworld run setblock 420 74 22 grass_block
execute in minecraft:overworld run fill 420 75 22 420 144 22 air
execute in minecraft:overworld run fill 420 58 23 420 71 23 stone
execute in minecraft:overworld run fill 420 72 23 420 73 23 dirt
execute in minecraft:overworld run setblock 420 74 23 grass_block
execute in minecraft:overworld run fill 420 75 23 420 144 23 air
execute in minecraft:overworld run fill 420 58 24 420 71 24 stone
execute in minecraft:overworld run fill 420 72 24 420 73 24 dirt
execute in minecraft:overworld run setblock 420 74 24 coarse_dirt
execute in minecraft:overworld run fill 420 75 24 420 144 24 air
execute in minecraft:overworld run fill 420 58 25 420 71 25 stone
execute in minecraft:overworld run fill 420 72 25 420 73 25 dirt
execute in minecraft:overworld run setblock 420 74 25 coarse_dirt
execute in minecraft:overworld run fill 420 75 25 420 144 25 air
execute in minecraft:overworld run fill 420 58 26 420 71 26 stone
execute in minecraft:overworld run fill 420 72 26 420 73 26 dirt
execute in minecraft:overworld run setblock 420 74 26 grass_block
execute in minecraft:overworld run fill 420 75 26 420 144 26 air
execute in minecraft:overworld run fill 420 58 27 420 72 27 stone
execute in minecraft:overworld run fill 420 73 27 420 74 27 dirt
execute in minecraft:overworld run setblock 420 75 27 coarse_dirt
execute in minecraft:overworld run fill 420 76 27 420 144 27 air
execute in minecraft:overworld run setblock 420 76 27 grass
execute in minecraft:overworld run fill 420 58 28 420 72 28 stone
execute in minecraft:overworld run fill 420 73 28 420 74 28 dirt
execute in minecraft:overworld run setblock 420 75 28 coarse_dirt
execute in minecraft:overworld run fill 420 76 28 420 144 28 air
execute in minecraft:overworld run fill 420 58 29 420 72 29 stone
execute in minecraft:overworld run fill 420 73 29 420 74 29 dirt
execute in minecraft:overworld run setblock 420 75 29 grass_block
execute in minecraft:overworld run fill 420 76 29 420 144 29 air
execute in minecraft:overworld run fill 420 58 30 420 71 30 stone
execute in minecraft:overworld run fill 420 72 30 420 73 30 dirt
execute in minecraft:overworld run setblock 420 74 30 coarse_dirt
execute in minecraft:overworld run fill 420 75 30 420 144 30 air
execute in minecraft:overworld run fill 420 58 31 420 71 31 stone
execute in minecraft:overworld run fill 420 72 31 420 73 31 dirt
execute in minecraft:overworld run setblock 420 74 31 coarse_dirt
execute in minecraft:overworld run fill 420 75 31 420 144 31 air
execute in minecraft:overworld run fill 420 58 32 420 71 32 stone
execute in minecraft:overworld run fill 420 72 32 420 73 32 dirt
execute in minecraft:overworld run setblock 420 74 32 coarse_dirt
execute in minecraft:overworld run fill 420 75 32 420 144 32 air
execute in minecraft:overworld run fill 420 58 33 420 71 33 stone
execute in minecraft:overworld run fill 420 72 33 420 73 33 dirt
execute in minecraft:overworld run setblock 420 74 33 grass_block
execute in minecraft:overworld run fill 420 75 33 420 144 33 air
execute in minecraft:overworld run fill 420 58 34 420 71 34 stone
execute in minecraft:overworld run fill 420 72 34 420 73 34 dirt
execute in minecraft:overworld run setblock 420 74 34 grass_block
execute in minecraft:overworld run fill 420 75 34 420 144 34 air
execute in minecraft:overworld run fill 420 58 35 420 70 35 stone
execute in minecraft:overworld run fill 420 71 35 420 72 35 dirt
execute in minecraft:overworld run setblock 420 73 35 grass_block
execute in minecraft:overworld run fill 420 74 35 420 144 35 air
execute in minecraft:overworld run fill 420 58 36 420 70 36 stone
execute in minecraft:overworld run fill 420 71 36 420 72 36 dirt
execute in minecraft:overworld run setblock 420 73 36 coarse_dirt
execute in minecraft:overworld run fill 420 74 36 420 144 36 air
execute in minecraft:overworld run setblock 420 74 36 grass
execute in minecraft:overworld run fill 420 58 37 420 69 37 stone
execute in minecraft:overworld run fill 420 70 37 420 71 37 dirt
execute in minecraft:overworld run setblock 420 72 37 coarse_dirt
execute in minecraft:overworld run fill 420 73 37 420 144 37 air
execute in minecraft:overworld run fill 420 58 38 420 69 38 stone
execute in minecraft:overworld run fill 420 70 38 420 71 38 dirt
execute in minecraft:overworld run setblock 420 72 38 grass_block
execute in minecraft:overworld run fill 420 73 38 420 144 38 air
execute in minecraft:overworld run fill 420 58 39 420 67 39 stone
execute in minecraft:overworld run fill 420 68 39 420 69 39 dirt
execute in minecraft:overworld run setblock 420 70 39 grass_block
execute in minecraft:overworld run fill 420 71 39 420 144 39 air
execute in minecraft:overworld run fill 420 58 40 420 66 40 stone
execute in minecraft:overworld run fill 420 67 40 420 68 40 dirt
execute in minecraft:overworld run setblock 420 69 40 grass_block
execute in minecraft:overworld run fill 420 70 40 420 144 40 air
execute in minecraft:overworld run fill 420 58 41 420 65 41 stone
execute in minecraft:overworld run fill 420 66 41 420 67 41 dirt
execute in minecraft:overworld run setblock 420 68 41 coarse_dirt
execute in minecraft:overworld run fill 420 69 41 420 144 41 air
execute in minecraft:overworld run fill 420 58 42 420 64 42 stone
execute in minecraft:overworld run fill 420 65 42 420 66 42 dirt
execute in minecraft:overworld run setblock 420 67 42 grass_block
execute in minecraft:overworld run fill 420 68 42 420 144 42 air
execute in minecraft:overworld run fill 420 58 43 420 63 43 stone
execute in minecraft:overworld run fill 420 64 43 420 65 43 dirt
execute in minecraft:overworld run setblock 420 66 43 grass_block
execute in minecraft:overworld run fill 420 67 43 420 144 43 air
execute in minecraft:overworld run fill 420 58 44 420 62 44 stone
execute in minecraft:overworld run fill 420 63 44 420 64 44 dirt
execute in minecraft:overworld run setblock 420 65 44 coarse_dirt
execute in minecraft:overworld run fill 420 66 44 420 144 44 air
execute in minecraft:overworld run fill 420 58 45 420 62 45 stone
execute in minecraft:overworld run fill 420 63 45 420 64 45 dirt
execute in minecraft:overworld run setblock 420 65 45 grass_block
execute in minecraft:overworld run fill 420 66 45 420 144 45 air
execute in minecraft:overworld run fill 420 58 46 420 61 46 stone
execute in minecraft:overworld run fill 420 62 46 420 63 46 dirt
execute in minecraft:overworld run setblock 420 64 46 grass_block
execute in minecraft:overworld run fill 420 65 46 420 144 46 air
execute in minecraft:overworld run fill 420 58 47 420 61 47 stone
execute in minecraft:overworld run fill 420 62 47 420 63 47 dirt
execute in minecraft:overworld run setblock 420 64 47 grass_block
execute in minecraft:overworld run fill 420 65 47 420 144 47 air
execute in minecraft:overworld run fill 421 58 -48 421 61 -48 stone
execute in minecraft:overworld run fill 421 62 -48 421 63 -48 dirt
execute in minecraft:overworld run setblock 421 64 -48 grass_block
execute in minecraft:overworld run fill 421 65 -48 421 144 -48 air
execute in minecraft:overworld run fill 421 58 -47 421 63 -47 stone
execute in minecraft:overworld run fill 421 64 -47 421 65 -47 dirt
execute in minecraft:overworld run setblock 421 66 -47 coarse_dirt
execute in minecraft:overworld run fill 421 67 -47 421 144 -47 air
execute in minecraft:overworld run fill 421 58 -46 421 64 -46 stone
execute in minecraft:overworld run fill 421 65 -46 421 66 -46 dirt
execute in minecraft:overworld run setblock 421 67 -46 coarse_dirt
execute in minecraft:overworld run fill 421 68 -46 421 144 -46 air
execute in minecraft:overworld run fill 421 58 -45 421 66 -45 stone
execute in minecraft:overworld run fill 421 67 -45 421 68 -45 dirt
execute in minecraft:overworld run setblock 421 69 -45 coarse_dirt
execute in minecraft:overworld run fill 421 70 -45 421 144 -45 air
execute in minecraft:overworld run fill 421 58 -44 421 67 -44 stone
execute in minecraft:overworld run fill 421 68 -44 421 69 -44 dirt
execute in minecraft:overworld run setblock 421 70 -44 grass_block
execute in minecraft:overworld run fill 421 71 -44 421 144 -44 air
execute in minecraft:overworld run fill 421 58 -43 421 69 -43 stone
execute in minecraft:overworld run fill 421 70 -43 421 71 -43 dirt
execute in minecraft:overworld run setblock 421 72 -43 coarse_dirt
execute in minecraft:overworld run fill 421 73 -43 421 144 -43 air
execute in minecraft:overworld run fill 421 58 -42 421 70 -42 stone
execute in minecraft:overworld run fill 421 71 -42 421 72 -42 dirt
execute in minecraft:overworld run setblock 421 73 -42 grass_block
execute in minecraft:overworld run fill 421 74 -42 421 144 -42 air
execute in minecraft:overworld run fill 421 58 -41 421 72 -41 stone
execute in minecraft:overworld run fill 421 73 -41 421 74 -41 dirt
execute in minecraft:overworld run setblock 421 75 -41 coarse_dirt
execute in minecraft:overworld run fill 421 76 -41 421 144 -41 air
execute in minecraft:overworld run fill 421 58 -40 421 73 -40 stone
execute in minecraft:overworld run fill 421 74 -40 421 75 -40 dirt
execute in minecraft:overworld run setblock 421 76 -40 coarse_dirt
execute in minecraft:overworld run fill 421 77 -40 421 144 -40 air
execute in minecraft:overworld run fill 421 58 -39 421 74 -39 stone
execute in minecraft:overworld run fill 421 75 -39 421 76 -39 dirt
execute in minecraft:overworld run setblock 421 77 -39 coarse_dirt
execute in minecraft:overworld run fill 421 78 -39 421 144 -39 air
execute in minecraft:overworld run setblock 421 78 -39 grass
execute in minecraft:overworld run fill 421 58 -38 421 76 -38 stone
execute in minecraft:overworld run fill 421 77 -38 421 78 -38 dirt
execute in minecraft:overworld run setblock 421 79 -38 coarse_dirt
execute in minecraft:overworld run fill 421 80 -38 421 144 -38 air
execute in minecraft:overworld run fill 421 58 -37 421 75 -37 stone
execute in minecraft:overworld run fill 421 76 -37 421 77 -37 dirt
execute in minecraft:overworld run setblock 421 78 -37 coarse_dirt
execute in minecraft:overworld run fill 421 79 -37 421 144 -37 air
execute in minecraft:overworld run fill 421 58 -36 421 75 -36 stone
execute in minecraft:overworld run fill 421 76 -36 421 77 -36 dirt
execute in minecraft:overworld run setblock 421 78 -36 coarse_dirt
execute in minecraft:overworld run fill 421 79 -36 421 144 -36 air
execute in minecraft:overworld run fill 421 58 -35 421 74 -35 stone
execute in minecraft:overworld run fill 421 75 -35 421 76 -35 dirt
execute in minecraft:overworld run setblock 421 77 -35 grass_block
execute in minecraft:overworld run fill 421 78 -35 421 144 -35 air
execute in minecraft:overworld run setblock 421 78 -35 mossy_cobblestone
execute in minecraft:overworld run fill 421 58 -34 421 74 -34 stone
execute in minecraft:overworld run fill 421 75 -34 421 76 -34 dirt
execute in minecraft:overworld run setblock 421 77 -34 coarse_dirt
execute in minecraft:overworld run fill 421 78 -34 421 144 -34 air
execute in minecraft:overworld run fill 421 58 -33 421 74 -33 stone
execute in minecraft:overworld run fill 421 75 -33 421 76 -33 dirt
execute in minecraft:overworld run setblock 421 77 -33 coarse_dirt
execute in minecraft:overworld run fill 421 78 -33 421 144 -33 air
execute in minecraft:overworld run fill 421 58 -32 421 73 -32 stone
execute in minecraft:overworld run fill 421 74 -32 421 75 -32 dirt
execute in minecraft:overworld run setblock 421 76 -32 coarse_dirt
execute in minecraft:overworld run fill 421 77 -32 421 144 -32 air
execute in minecraft:overworld run fill 421 58 -31 421 73 -31 stone
execute in minecraft:overworld run fill 421 74 -31 421 75 -31 dirt
execute in minecraft:overworld run setblock 421 76 -31 coarse_dirt
execute in minecraft:overworld run fill 421 77 -31 421 144 -31 air
execute in minecraft:overworld run fill 421 58 -30 421 72 -30 stone
execute in minecraft:overworld run fill 421 73 -30 421 74 -30 dirt
execute in minecraft:overworld run setblock 421 75 -30 coarse_dirt
execute in minecraft:overworld run fill 421 76 -30 421 144 -30 air
execute in minecraft:overworld run fill 421 58 -29 421 72 -29 stone
execute in minecraft:overworld run fill 421 73 -29 421 74 -29 dirt
execute in minecraft:overworld run setblock 421 75 -29 coarse_dirt
execute in minecraft:overworld run fill 421 76 -29 421 144 -29 air
execute in minecraft:overworld run fill 421 58 -28 421 71 -28 stone
execute in minecraft:overworld run fill 421 72 -28 421 73 -28 dirt
execute in minecraft:overworld run setblock 421 74 -28 grass_block
execute in minecraft:overworld run fill 421 75 -28 421 144 -28 air
execute in minecraft:overworld run fill 421 58 -27 421 71 -27 stone
execute in minecraft:overworld run fill 421 72 -27 421 73 -27 dirt
execute in minecraft:overworld run setblock 421 74 -27 grass_block
execute in minecraft:overworld run fill 421 75 -27 421 144 -27 air
execute in minecraft:overworld run fill 421 58 -26 421 71 -26 stone
execute in minecraft:overworld run fill 421 72 -26 421 73 -26 dirt
execute in minecraft:overworld run setblock 421 74 -26 coarse_dirt
execute in minecraft:overworld run fill 421 75 -26 421 144 -26 air
execute in minecraft:overworld run fill 421 58 -25 421 70 -25 stone
execute in minecraft:overworld run fill 421 71 -25 421 72 -25 dirt
execute in minecraft:overworld run setblock 421 73 -25 coarse_dirt
execute in minecraft:overworld run fill 421 74 -25 421 144 -25 air
execute in minecraft:overworld run fill 421 58 -24 421 70 -24 stone
execute in minecraft:overworld run fill 421 71 -24 421 72 -24 dirt
execute in minecraft:overworld run setblock 421 73 -24 coarse_dirt
execute in minecraft:overworld run fill 421 74 -24 421 144 -24 air
execute in minecraft:overworld run fill 421 58 -23 421 70 -23 stone
execute in minecraft:overworld run fill 421 71 -23 421 72 -23 dirt
execute in minecraft:overworld run setblock 421 73 -23 grass_block
execute in minecraft:overworld run fill 421 74 -23 421 144 -23 air
execute in minecraft:overworld run fill 421 58 -22 421 70 -22 stone
execute in minecraft:overworld run fill 421 71 -22 421 72 -22 dirt
execute in minecraft:overworld run setblock 421 73 -22 grass_block
execute in minecraft:overworld run fill 421 74 -22 421 144 -22 air
execute in minecraft:overworld run fill 421 58 -21 421 69 -21 stone
execute in minecraft:overworld run fill 421 70 -21 421 71 -21 dirt
execute in minecraft:overworld run setblock 421 72 -21 coarse_dirt
execute in minecraft:overworld run fill 421 73 -21 421 144 -21 air
execute in minecraft:overworld run setblock 421 73 -21 grass
execute in minecraft:overworld run fill 421 58 -20 421 69 -20 stone
execute in minecraft:overworld run fill 421 70 -20 421 71 -20 dirt
execute in minecraft:overworld run setblock 421 72 -20 coarse_dirt
execute in minecraft:overworld run fill 421 73 -20 421 144 -20 air
execute in minecraft:overworld run setblock 421 73 -20 mossy_cobblestone
execute in minecraft:overworld run fill 421 58 -19 421 69 -19 stone
execute in minecraft:overworld run fill 421 70 -19 421 71 -19 dirt
execute in minecraft:overworld run setblock 421 72 -19 coarse_dirt
execute in minecraft:overworld run fill 421 73 -19 421 144 -19 air
execute in minecraft:overworld run fill 421 58 -18 421 68 -18 stone
execute in minecraft:overworld run fill 421 69 -18 421 70 -18 dirt
execute in minecraft:overworld run setblock 421 71 -18 coarse_dirt
execute in minecraft:overworld run fill 421 72 -18 421 144 -18 air
execute in minecraft:overworld run fill 421 58 -17 421 68 -17 stone
execute in minecraft:overworld run fill 421 69 -17 421 70 -17 dirt
execute in minecraft:overworld run setblock 421 71 -17 coarse_dirt
execute in minecraft:overworld run fill 421 72 -17 421 144 -17 air
execute in minecraft:overworld run fill 421 58 -16 421 67 -16 stone
execute in minecraft:overworld run fill 421 68 -16 421 69 -16 dirt
execute in minecraft:overworld run setblock 421 70 -16 coarse_dirt
execute in minecraft:overworld run fill 421 71 -16 421 144 -16 air
execute in minecraft:overworld run fill 421 58 -15 421 67 -15 stone
execute in minecraft:overworld run fill 421 68 -15 421 69 -15 dirt
execute in minecraft:overworld run setblock 421 70 -15 grass_block
execute in minecraft:overworld run fill 421 71 -15 421 144 -15 air
execute in minecraft:overworld run setblock 421 71 -15 mossy_cobblestone
execute in minecraft:overworld run fill 421 58 -14 421 66 -14 stone
execute in minecraft:overworld run fill 421 67 -14 421 68 -14 dirt
execute in minecraft:overworld run setblock 421 69 -14 coarse_dirt
execute in minecraft:overworld run fill 421 70 -14 421 144 -14 air
execute in minecraft:overworld run fill 421 58 -13 421 66 -13 stone
execute in minecraft:overworld run fill 421 67 -13 421 68 -13 dirt
execute in minecraft:overworld run setblock 421 69 -13 coarse_dirt
schedule function blade_gallery:random/battlefield/part_134 1t replace
