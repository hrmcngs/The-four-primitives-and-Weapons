execute in minecraft:overworld run fill 246 58 -5 246 62 -5 stone
execute in minecraft:overworld run fill 246 63 -5 246 64 -5 dirt
execute in minecraft:overworld run setblock 246 65 -5 grass_block
execute in minecraft:overworld run fill 246 66 -5 246 144 -5 air
execute in minecraft:overworld run fill 246 58 -4 246 62 -4 stone
execute in minecraft:overworld run fill 246 63 -4 246 64 -4 dirt
execute in minecraft:overworld run setblock 246 65 -4 coarse_dirt
execute in minecraft:overworld run fill 246 66 -4 246 144 -4 air
execute in minecraft:overworld run fill 246 58 -3 246 61 -3 stone
execute in minecraft:overworld run fill 246 62 -3 246 63 -3 dirt
execute in minecraft:overworld run setblock 246 64 -3 coarse_dirt
execute in minecraft:overworld run fill 246 65 -3 246 144 -3 air
execute in minecraft:overworld run fill 246 58 -2 246 61 -2 stone
execute in minecraft:overworld run fill 246 62 -2 246 63 -2 dirt
execute in minecraft:overworld run setblock 246 64 -2 coarse_dirt
execute in minecraft:overworld run fill 246 65 -2 246 144 -2 air
execute in minecraft:overworld run fill 246 58 -1 246 61 -1 stone
execute in minecraft:overworld run fill 246 62 -1 246 63 -1 dirt
execute in minecraft:overworld run setblock 246 64 -1 coarse_dirt
execute in minecraft:overworld run fill 246 65 -1 246 144 -1 air
execute in minecraft:overworld run fill 246 58 0 246 61 0 stone
execute in minecraft:overworld run fill 246 62 0 246 63 0 dirt
execute in minecraft:overworld run setblock 246 64 0 coarse_dirt
execute in minecraft:overworld run fill 246 65 0 246 144 0 air
execute in minecraft:overworld run fill 246 58 1 246 61 1 stone
execute in minecraft:overworld run fill 246 62 1 246 63 1 dirt
execute in minecraft:overworld run setblock 246 64 1 coarse_dirt
execute in minecraft:overworld run fill 246 65 1 246 144 1 air
execute in minecraft:overworld run fill 246 58 2 246 61 2 stone
execute in minecraft:overworld run fill 246 62 2 246 63 2 dirt
execute in minecraft:overworld run setblock 246 64 2 grass_block
execute in minecraft:overworld run fill 246 65 2 246 144 2 air
execute in minecraft:overworld run fill 246 58 3 246 61 3 stone
execute in minecraft:overworld run fill 246 62 3 246 63 3 dirt
execute in minecraft:overworld run setblock 246 64 3 grass_block
execute in minecraft:overworld run fill 246 65 3 246 144 3 air
execute in minecraft:overworld run fill 246 58 4 246 62 4 stone
execute in minecraft:overworld run fill 246 63 4 246 64 4 dirt
execute in minecraft:overworld run setblock 246 65 4 coarse_dirt
execute in minecraft:overworld run fill 246 66 4 246 144 4 air
execute in minecraft:overworld run fill 246 58 5 246 62 5 stone
execute in minecraft:overworld run fill 246 63 5 246 64 5 dirt
execute in minecraft:overworld run setblock 246 65 5 grass_block
execute in minecraft:overworld run fill 246 66 5 246 144 5 air
execute in minecraft:overworld run fill 246 58 6 246 63 6 stone
execute in minecraft:overworld run fill 246 64 6 246 65 6 dirt
execute in minecraft:overworld run setblock 246 66 6 grass_block
execute in minecraft:overworld run fill 246 67 6 246 144 6 air
execute in minecraft:overworld run fill 246 58 7 246 63 7 stone
execute in minecraft:overworld run fill 246 64 7 246 65 7 dirt
execute in minecraft:overworld run setblock 246 66 7 coarse_dirt
execute in minecraft:overworld run fill 246 67 7 246 144 7 air
execute in minecraft:overworld run fill 246 58 8 246 63 8 stone
execute in minecraft:overworld run fill 246 64 8 246 65 8 dirt
execute in minecraft:overworld run setblock 246 66 8 coarse_dirt
execute in minecraft:overworld run fill 246 67 8 246 144 8 air
execute in minecraft:overworld run fill 246 58 9 246 64 9 stone
execute in minecraft:overworld run fill 246 65 9 246 66 9 dirt
execute in minecraft:overworld run setblock 246 67 9 coarse_dirt
execute in minecraft:overworld run fill 246 68 9 246 144 9 air
execute in minecraft:overworld run fill 246 58 10 246 64 10 stone
execute in minecraft:overworld run fill 246 65 10 246 66 10 dirt
execute in minecraft:overworld run setblock 246 67 10 coarse_dirt
execute in minecraft:overworld run fill 246 68 10 246 144 10 air
execute in minecraft:overworld run fill 246 58 11 246 64 11 stone
execute in minecraft:overworld run fill 246 65 11 246 66 11 dirt
execute in minecraft:overworld run setblock 246 67 11 coarse_dirt
execute in minecraft:overworld run fill 246 68 11 246 144 11 air
execute in minecraft:overworld run fill 246 58 12 246 64 12 stone
execute in minecraft:overworld run fill 246 65 12 246 66 12 dirt
execute in minecraft:overworld run setblock 246 67 12 coarse_dirt
execute in minecraft:overworld run fill 246 68 12 246 144 12 air
execute in minecraft:overworld run setblock 246 68 12 grass
execute in minecraft:overworld run fill 246 58 13 246 64 13 stone
execute in minecraft:overworld run fill 246 65 13 246 66 13 dirt
execute in minecraft:overworld run setblock 246 67 13 coarse_dirt
execute in minecraft:overworld run fill 246 68 13 246 144 13 air
execute in minecraft:overworld run fill 246 58 14 246 64 14 stone
execute in minecraft:overworld run fill 246 65 14 246 66 14 dirt
execute in minecraft:overworld run setblock 246 67 14 grass_block
execute in minecraft:overworld run fill 246 68 14 246 144 14 air
execute in minecraft:overworld run fill 246 58 15 246 65 15 stone
execute in minecraft:overworld run fill 246 66 15 246 67 15 dirt
execute in minecraft:overworld run setblock 246 68 15 grass_block
execute in minecraft:overworld run fill 246 69 15 246 144 15 air
execute in minecraft:overworld run fill 246 58 16 246 65 16 stone
execute in minecraft:overworld run fill 246 66 16 246 67 16 dirt
execute in minecraft:overworld run setblock 246 68 16 coarse_dirt
execute in minecraft:overworld run fill 246 69 16 246 144 16 air
execute in minecraft:overworld run fill 246 58 17 246 65 17 stone
execute in minecraft:overworld run fill 246 66 17 246 67 17 dirt
execute in minecraft:overworld run setblock 246 68 17 coarse_dirt
execute in minecraft:overworld run fill 246 69 17 246 144 17 air
execute in minecraft:overworld run fill 246 58 18 246 65 18 stone
execute in minecraft:overworld run fill 246 66 18 246 67 18 dirt
execute in minecraft:overworld run setblock 246 68 18 coarse_dirt
execute in minecraft:overworld run fill 246 69 18 246 144 18 air
execute in minecraft:overworld run setblock 246 69 18 grass
execute in minecraft:overworld run fill 246 58 19 246 65 19 stone
execute in minecraft:overworld run fill 246 66 19 246 67 19 dirt
execute in minecraft:overworld run setblock 246 68 19 coarse_dirt
execute in minecraft:overworld run fill 246 69 19 246 144 19 air
execute in minecraft:overworld run fill 246 58 20 246 65 20 stone
execute in minecraft:overworld run fill 246 66 20 246 67 20 dirt
execute in minecraft:overworld run setblock 246 68 20 coarse_dirt
execute in minecraft:overworld run fill 246 69 20 246 144 20 air
execute in minecraft:overworld run fill 246 58 21 246 65 21 stone
execute in minecraft:overworld run fill 246 66 21 246 67 21 dirt
execute in minecraft:overworld run setblock 246 68 21 coarse_dirt
execute in minecraft:overworld run fill 246 69 21 246 144 21 air
execute in minecraft:overworld run fill 246 58 22 246 65 22 stone
execute in minecraft:overworld run fill 246 66 22 246 67 22 dirt
execute in minecraft:overworld run setblock 246 68 22 coarse_dirt
execute in minecraft:overworld run fill 246 69 22 246 144 22 air
execute in minecraft:overworld run fill 246 58 23 246 65 23 stone
execute in minecraft:overworld run fill 246 66 23 246 67 23 dirt
execute in minecraft:overworld run setblock 246 68 23 grass_block
execute in minecraft:overworld run fill 246 69 23 246 144 23 air
execute in minecraft:overworld run fill 246 58 24 246 65 24 stone
execute in minecraft:overworld run fill 246 66 24 246 67 24 dirt
execute in minecraft:overworld run setblock 246 68 24 coarse_dirt
execute in minecraft:overworld run fill 246 69 24 246 144 24 air
execute in minecraft:overworld run fill 246 58 25 246 65 25 stone
execute in minecraft:overworld run fill 246 66 25 246 67 25 dirt
execute in minecraft:overworld run setblock 246 68 25 grass_block
execute in minecraft:overworld run fill 246 69 25 246 144 25 air
execute in minecraft:overworld run fill 246 58 26 246 65 26 stone
execute in minecraft:overworld run fill 246 66 26 246 67 26 dirt
execute in minecraft:overworld run setblock 246 68 26 coarse_dirt
execute in minecraft:overworld run fill 246 69 26 246 144 26 air
execute in minecraft:overworld run fill 246 58 27 246 65 27 stone
execute in minecraft:overworld run fill 246 66 27 246 67 27 dirt
execute in minecraft:overworld run setblock 246 68 27 grass_block
execute in minecraft:overworld run fill 246 69 27 246 144 27 air
execute in minecraft:overworld run fill 246 58 28 246 65 28 stone
execute in minecraft:overworld run fill 246 66 28 246 67 28 dirt
execute in minecraft:overworld run setblock 246 68 28 coarse_dirt
execute in minecraft:overworld run fill 246 69 28 246 144 28 air
execute in minecraft:overworld run setblock 246 69 28 grass
execute in minecraft:overworld run fill 246 58 29 246 65 29 stone
execute in minecraft:overworld run fill 246 66 29 246 67 29 dirt
execute in minecraft:overworld run setblock 246 68 29 coarse_dirt
execute in minecraft:overworld run fill 246 69 29 246 144 29 air
execute in minecraft:overworld run setblock 246 69 29 grass
execute in minecraft:overworld run fill 246 58 30 246 65 30 stone
execute in minecraft:overworld run fill 246 66 30 246 67 30 dirt
execute in minecraft:overworld run setblock 246 68 30 coarse_dirt
execute in minecraft:overworld run fill 246 69 30 246 144 30 air
execute in minecraft:overworld run fill 246 58 31 246 65 31 stone
execute in minecraft:overworld run fill 246 66 31 246 67 31 dirt
execute in minecraft:overworld run setblock 246 68 31 grass_block
execute in minecraft:overworld run fill 246 69 31 246 144 31 air
execute in minecraft:overworld run fill 246 58 32 246 65 32 stone
execute in minecraft:overworld run fill 246 66 32 246 67 32 dirt
execute in minecraft:overworld run setblock 246 68 32 grass_block
execute in minecraft:overworld run fill 246 69 32 246 144 32 air
execute in minecraft:overworld run fill 246 58 33 246 65 33 stone
execute in minecraft:overworld run fill 246 66 33 246 67 33 dirt
execute in minecraft:overworld run setblock 246 68 33 coarse_dirt
execute in minecraft:overworld run fill 246 69 33 246 144 33 air
execute in minecraft:overworld run fill 246 58 34 246 65 34 stone
execute in minecraft:overworld run fill 246 66 34 246 67 34 dirt
execute in minecraft:overworld run setblock 246 68 34 coarse_dirt
execute in minecraft:overworld run fill 246 69 34 246 144 34 air
execute in minecraft:overworld run fill 246 58 35 246 65 35 stone
execute in minecraft:overworld run fill 246 66 35 246 67 35 dirt
execute in minecraft:overworld run setblock 246 68 35 coarse_dirt
execute in minecraft:overworld run fill 246 69 35 246 144 35 air
execute in minecraft:overworld run fill 246 58 36 246 64 36 stone
execute in minecraft:overworld run fill 246 65 36 246 66 36 dirt
execute in minecraft:overworld run setblock 246 67 36 coarse_dirt
execute in minecraft:overworld run fill 246 68 36 246 144 36 air
execute in minecraft:overworld run fill 246 58 37 246 64 37 stone
execute in minecraft:overworld run fill 246 65 37 246 66 37 dirt
execute in minecraft:overworld run setblock 246 67 37 coarse_dirt
execute in minecraft:overworld run fill 246 68 37 246 144 37 air
execute in minecraft:overworld run fill 246 58 38 246 64 38 stone
execute in minecraft:overworld run fill 246 65 38 246 66 38 dirt
execute in minecraft:overworld run setblock 246 67 38 coarse_dirt
execute in minecraft:overworld run fill 246 68 38 246 144 38 air
execute in minecraft:overworld run setblock 246 68 38 grass
execute in minecraft:overworld run fill 246 58 39 246 64 39 stone
execute in minecraft:overworld run fill 246 65 39 246 66 39 dirt
execute in minecraft:overworld run setblock 246 67 39 coarse_dirt
execute in minecraft:overworld run fill 246 68 39 246 144 39 air
execute in minecraft:overworld run fill 246 58 40 246 63 40 stone
execute in minecraft:overworld run fill 246 64 40 246 65 40 dirt
execute in minecraft:overworld run setblock 246 66 40 coarse_dirt
execute in minecraft:overworld run fill 246 67 40 246 144 40 air
execute in minecraft:overworld run fill 246 58 41 246 63 41 stone
execute in minecraft:overworld run fill 246 64 41 246 65 41 dirt
execute in minecraft:overworld run setblock 246 66 41 coarse_dirt
execute in minecraft:overworld run fill 246 67 41 246 144 41 air
execute in minecraft:overworld run fill 246 58 42 246 63 42 stone
execute in minecraft:overworld run fill 246 64 42 246 65 42 dirt
execute in minecraft:overworld run setblock 246 66 42 coarse_dirt
execute in minecraft:overworld run fill 246 67 42 246 144 42 air
execute in minecraft:overworld run fill 246 58 43 246 62 43 stone
execute in minecraft:overworld run fill 246 63 43 246 64 43 dirt
execute in minecraft:overworld run setblock 246 65 43 grass_block
execute in minecraft:overworld run fill 246 66 43 246 144 43 air
execute in minecraft:overworld run fill 246 58 44 246 62 44 stone
execute in minecraft:overworld run fill 246 63 44 246 64 44 dirt
execute in minecraft:overworld run setblock 246 65 44 grass_block
execute in minecraft:overworld run fill 246 66 44 246 144 44 air
execute in minecraft:overworld run fill 246 58 45 246 61 45 stone
execute in minecraft:overworld run fill 246 62 45 246 63 45 dirt
execute in minecraft:overworld run setblock 246 64 45 coarse_dirt
execute in minecraft:overworld run fill 246 65 45 246 144 45 air
execute in minecraft:overworld run fill 246 58 46 246 61 46 stone
execute in minecraft:overworld run fill 246 62 46 246 63 46 dirt
execute in minecraft:overworld run setblock 246 64 46 coarse_dirt
execute in minecraft:overworld run fill 246 65 46 246 144 46 air
execute in minecraft:overworld run fill 246 58 47 246 61 47 stone
execute in minecraft:overworld run fill 246 62 47 246 63 47 dirt
execute in minecraft:overworld run setblock 246 64 47 coarse_dirt
execute in minecraft:overworld run fill 246 65 47 246 144 47 air
execute in minecraft:overworld run fill 247 58 -48 247 61 -48 stone
execute in minecraft:overworld run fill 247 62 -48 247 63 -48 dirt
execute in minecraft:overworld run setblock 247 64 -48 coarse_dirt
execute in minecraft:overworld run fill 247 65 -48 247 144 -48 air
execute in minecraft:overworld run fill 247 58 -47 247 62 -47 stone
execute in minecraft:overworld run fill 247 63 -47 247 64 -47 dirt
execute in minecraft:overworld run setblock 247 65 -47 coarse_dirt
execute in minecraft:overworld run fill 247 66 -47 247 144 -47 air
execute in minecraft:overworld run fill 247 58 -46 247 63 -46 stone
execute in minecraft:overworld run fill 247 64 -46 247 65 -46 dirt
execute in minecraft:overworld run setblock 247 66 -46 coarse_dirt
execute in minecraft:overworld run fill 247 67 -46 247 144 -46 air
execute in minecraft:overworld run fill 247 58 -45 247 63 -45 stone
execute in minecraft:overworld run fill 247 64 -45 247 65 -45 dirt
execute in minecraft:overworld run setblock 247 66 -45 coarse_dirt
execute in minecraft:overworld run fill 247 67 -45 247 144 -45 air
execute in minecraft:overworld run fill 247 58 -44 247 64 -44 stone
execute in minecraft:overworld run fill 247 65 -44 247 66 -44 dirt
execute in minecraft:overworld run setblock 247 67 -44 grass_block
execute in minecraft:overworld run fill 247 68 -44 247 144 -44 air
execute in minecraft:overworld run fill 247 58 -43 247 65 -43 stone
execute in minecraft:overworld run fill 247 66 -43 247 67 -43 dirt
execute in minecraft:overworld run setblock 247 68 -43 grass_block
execute in minecraft:overworld run fill 247 69 -43 247 144 -43 air
execute in minecraft:overworld run fill 247 58 -42 247 65 -42 stone
execute in minecraft:overworld run fill 247 66 -42 247 67 -42 dirt
execute in minecraft:overworld run setblock 247 68 -42 grass_block
execute in minecraft:overworld run fill 247 69 -42 247 144 -42 air
execute in minecraft:overworld run fill 247 58 -41 247 66 -41 stone
execute in minecraft:overworld run fill 247 67 -41 247 68 -41 dirt
execute in minecraft:overworld run setblock 247 69 -41 coarse_dirt
execute in minecraft:overworld run fill 247 70 -41 247 144 -41 air
execute in minecraft:overworld run fill 247 58 -40 247 67 -40 stone
execute in minecraft:overworld run fill 247 68 -40 247 69 -40 dirt
execute in minecraft:overworld run setblock 247 70 -40 grass_block
execute in minecraft:overworld run fill 247 71 -40 247 144 -40 air
execute in minecraft:overworld run fill 247 58 -39 247 67 -39 stone
execute in minecraft:overworld run fill 247 68 -39 247 69 -39 dirt
execute in minecraft:overworld run setblock 247 70 -39 coarse_dirt
schedule function blade_gallery:random/burned/part_60 1t replace
