execute in minecraft:overworld run fill 249 68 16 249 144 16 air
execute in minecraft:overworld run fill 249 58 17 249 64 17 stone
execute in minecraft:overworld run fill 249 65 17 249 66 17 dirt
execute in minecraft:overworld run setblock 249 67 17 coarse_dirt
execute in minecraft:overworld run fill 249 68 17 249 144 17 air
execute in minecraft:overworld run setblock 249 68 17 grass
execute in minecraft:overworld run fill 249 58 18 249 65 18 stone
execute in minecraft:overworld run fill 249 66 18 249 67 18 dirt
execute in minecraft:overworld run setblock 249 68 18 grass_block
execute in minecraft:overworld run fill 249 69 18 249 144 18 air
execute in minecraft:overworld run fill 249 58 19 249 65 19 stone
execute in minecraft:overworld run fill 249 66 19 249 67 19 dirt
execute in minecraft:overworld run setblock 249 68 19 coarse_dirt
execute in minecraft:overworld run fill 249 69 19 249 144 19 air
execute in minecraft:overworld run fill 249 58 20 249 65 20 stone
execute in minecraft:overworld run fill 249 66 20 249 67 20 dirt
execute in minecraft:overworld run setblock 249 68 20 grass_block
execute in minecraft:overworld run fill 249 69 20 249 144 20 air
execute in minecraft:overworld run fill 249 58 21 249 65 21 stone
execute in minecraft:overworld run fill 249 66 21 249 67 21 dirt
execute in minecraft:overworld run setblock 249 68 21 coarse_dirt
execute in minecraft:overworld run fill 249 69 21 249 144 21 air
execute in minecraft:overworld run fill 249 58 22 249 65 22 stone
execute in minecraft:overworld run fill 249 66 22 249 67 22 dirt
execute in minecraft:overworld run setblock 249 68 22 coarse_dirt
execute in minecraft:overworld run fill 249 69 22 249 144 22 air
execute in minecraft:overworld run fill 249 58 23 249 65 23 stone
execute in minecraft:overworld run fill 249 66 23 249 67 23 dirt
execute in minecraft:overworld run setblock 249 68 23 coarse_dirt
execute in minecraft:overworld run fill 249 69 23 249 144 23 air
execute in minecraft:overworld run setblock 249 69 23 grass
execute in minecraft:overworld run fill 249 58 24 249 65 24 stone
execute in minecraft:overworld run fill 249 66 24 249 67 24 dirt
execute in minecraft:overworld run setblock 249 68 24 grass_block
execute in minecraft:overworld run fill 249 69 24 249 144 24 air
execute in minecraft:overworld run fill 249 58 25 249 65 25 stone
execute in minecraft:overworld run fill 249 66 25 249 67 25 dirt
execute in minecraft:overworld run setblock 249 68 25 coarse_dirt
execute in minecraft:overworld run fill 249 69 25 249 144 25 air
execute in minecraft:overworld run fill 249 58 26 249 65 26 stone
execute in minecraft:overworld run fill 249 66 26 249 67 26 dirt
execute in minecraft:overworld run setblock 249 68 26 coarse_dirt
execute in minecraft:overworld run fill 249 69 26 249 144 26 air
execute in minecraft:overworld run fill 249 58 27 249 65 27 stone
execute in minecraft:overworld run fill 249 66 27 249 67 27 dirt
execute in minecraft:overworld run setblock 249 68 27 coarse_dirt
execute in minecraft:overworld run fill 249 69 27 249 144 27 air
execute in minecraft:overworld run fill 249 58 28 249 65 28 stone
execute in minecraft:overworld run fill 249 66 28 249 67 28 dirt
execute in minecraft:overworld run setblock 249 68 28 grass_block
execute in minecraft:overworld run fill 249 69 28 249 144 28 air
execute in minecraft:overworld run setblock 249 69 28 grass
execute in minecraft:overworld run fill 249 58 29 249 65 29 stone
execute in minecraft:overworld run fill 249 66 29 249 67 29 dirt
execute in minecraft:overworld run setblock 249 68 29 grass_block
execute in minecraft:overworld run fill 249 69 29 249 144 29 air
execute in minecraft:overworld run fill 249 58 30 249 65 30 stone
execute in minecraft:overworld run fill 249 66 30 249 67 30 dirt
execute in minecraft:overworld run setblock 249 68 30 coarse_dirt
execute in minecraft:overworld run fill 249 69 30 249 144 30 air
execute in minecraft:overworld run fill 249 58 31 249 65 31 stone
execute in minecraft:overworld run fill 249 66 31 249 67 31 dirt
execute in minecraft:overworld run setblock 249 68 31 coarse_dirt
execute in minecraft:overworld run fill 249 69 31 249 144 31 air
execute in minecraft:overworld run fill 249 58 32 249 65 32 stone
execute in minecraft:overworld run fill 249 66 32 249 67 32 dirt
execute in minecraft:overworld run setblock 249 68 32 grass_block
execute in minecraft:overworld run fill 249 69 32 249 144 32 air
execute in minecraft:overworld run fill 249 58 33 249 65 33 stone
execute in minecraft:overworld run fill 249 66 33 249 67 33 dirt
execute in minecraft:overworld run setblock 249 68 33 coarse_dirt
execute in minecraft:overworld run fill 249 69 33 249 144 33 air
execute in minecraft:overworld run fill 249 58 34 249 65 34 stone
execute in minecraft:overworld run fill 249 66 34 249 67 34 dirt
execute in minecraft:overworld run setblock 249 68 34 coarse_dirt
execute in minecraft:overworld run fill 249 69 34 249 144 34 air
execute in minecraft:overworld run fill 249 58 35 249 65 35 stone
execute in minecraft:overworld run fill 249 66 35 249 67 35 dirt
execute in minecraft:overworld run setblock 249 68 35 grass_block
execute in minecraft:overworld run fill 249 69 35 249 144 35 air
execute in minecraft:overworld run fill 249 58 36 249 65 36 stone
execute in minecraft:overworld run fill 249 66 36 249 67 36 dirt
execute in minecraft:overworld run setblock 249 68 36 grass_block
execute in minecraft:overworld run fill 249 69 36 249 144 36 air
execute in minecraft:overworld run fill 249 58 37 249 64 37 stone
execute in minecraft:overworld run fill 249 65 37 249 66 37 dirt
execute in minecraft:overworld run setblock 249 67 37 grass_block
execute in minecraft:overworld run fill 249 68 37 249 144 37 air
execute in minecraft:overworld run fill 249 58 38 249 64 38 stone
execute in minecraft:overworld run fill 249 65 38 249 66 38 dirt
execute in minecraft:overworld run setblock 249 67 38 coarse_dirt
execute in minecraft:overworld run fill 249 68 38 249 144 38 air
execute in minecraft:overworld run fill 249 58 39 249 63 39 stone
execute in minecraft:overworld run fill 249 64 39 249 65 39 dirt
execute in minecraft:overworld run setblock 249 66 39 grass_block
execute in minecraft:overworld run fill 249 67 39 249 144 39 air
execute in minecraft:overworld run fill 249 58 40 249 63 40 stone
execute in minecraft:overworld run fill 249 64 40 249 65 40 dirt
execute in minecraft:overworld run setblock 249 66 40 grass_block
execute in minecraft:overworld run fill 249 67 40 249 144 40 air
execute in minecraft:overworld run fill 249 58 41 249 62 41 stone
execute in minecraft:overworld run fill 249 63 41 249 64 41 dirt
execute in minecraft:overworld run setblock 249 65 41 grass_block
execute in minecraft:overworld run fill 249 66 41 249 144 41 air
execute in minecraft:overworld run fill 249 58 42 249 62 42 stone
execute in minecraft:overworld run fill 249 63 42 249 64 42 dirt
execute in minecraft:overworld run setblock 249 65 42 grass_block
execute in minecraft:overworld run fill 249 66 42 249 144 42 air
execute in minecraft:overworld run fill 249 58 43 249 61 43 stone
execute in minecraft:overworld run fill 249 62 43 249 63 43 dirt
execute in minecraft:overworld run setblock 249 64 43 coarse_dirt
execute in minecraft:overworld run fill 249 65 43 249 144 43 air
execute in minecraft:overworld run fill 249 58 44 249 61 44 stone
execute in minecraft:overworld run fill 249 62 44 249 63 44 dirt
execute in minecraft:overworld run setblock 249 64 44 grass_block
execute in minecraft:overworld run fill 249 65 44 249 144 44 air
execute in minecraft:overworld run fill 249 58 45 249 61 45 stone
execute in minecraft:overworld run fill 249 62 45 249 63 45 dirt
execute in minecraft:overworld run setblock 249 64 45 coarse_dirt
execute in minecraft:overworld run fill 249 65 45 249 144 45 air
execute in minecraft:overworld run fill 249 58 46 249 61 46 stone
execute in minecraft:overworld run fill 249 62 46 249 63 46 dirt
execute in minecraft:overworld run setblock 249 64 46 coarse_dirt
execute in minecraft:overworld run fill 249 65 46 249 144 46 air
execute in minecraft:overworld run fill 249 58 47 249 61 47 stone
execute in minecraft:overworld run fill 249 62 47 249 63 47 dirt
execute in minecraft:overworld run setblock 249 64 47 coarse_dirt
execute in minecraft:overworld run fill 249 65 47 249 144 47 air
execute in minecraft:overworld run fill 250 58 -48 250 61 -48 stone
execute in minecraft:overworld run fill 250 62 -48 250 63 -48 dirt
execute in minecraft:overworld run setblock 250 64 -48 coarse_dirt
execute in minecraft:overworld run fill 250 65 -48 250 144 -48 air
execute in minecraft:overworld run fill 250 58 -47 250 62 -47 stone
execute in minecraft:overworld run fill 250 63 -47 250 64 -47 dirt
execute in minecraft:overworld run setblock 250 65 -47 grass_block
execute in minecraft:overworld run fill 250 66 -47 250 144 -47 air
execute in minecraft:overworld run fill 250 58 -46 250 63 -46 stone
execute in minecraft:overworld run fill 250 64 -46 250 65 -46 dirt
execute in minecraft:overworld run setblock 250 66 -46 coarse_dirt
execute in minecraft:overworld run fill 250 67 -46 250 144 -46 air
execute in minecraft:overworld run fill 250 58 -45 250 64 -45 stone
execute in minecraft:overworld run fill 250 65 -45 250 66 -45 dirt
execute in minecraft:overworld run setblock 250 67 -45 grass_block
execute in minecraft:overworld run fill 250 68 -45 250 144 -45 air
execute in minecraft:overworld run fill 250 58 -44 250 65 -44 stone
execute in minecraft:overworld run fill 250 66 -44 250 67 -44 dirt
execute in minecraft:overworld run setblock 250 68 -44 coarse_dirt
execute in minecraft:overworld run fill 250 69 -44 250 144 -44 air
execute in minecraft:overworld run fill 250 58 -43 250 65 -43 stone
execute in minecraft:overworld run fill 250 66 -43 250 67 -43 dirt
execute in minecraft:overworld run setblock 250 68 -43 grass_block
execute in minecraft:overworld run fill 250 69 -43 250 144 -43 air
execute in minecraft:overworld run fill 250 58 -42 250 66 -42 stone
execute in minecraft:overworld run fill 250 67 -42 250 68 -42 dirt
execute in minecraft:overworld run setblock 250 69 -42 grass_block
execute in minecraft:overworld run fill 250 70 -42 250 144 -42 air
execute in minecraft:overworld run fill 250 58 -41 250 67 -41 stone
execute in minecraft:overworld run fill 250 68 -41 250 69 -41 dirt
execute in minecraft:overworld run setblock 250 70 -41 coarse_dirt
execute in minecraft:overworld run fill 250 71 -41 250 144 -41 air
execute in minecraft:overworld run setblock 250 71 -41 grass
execute in minecraft:overworld run fill 250 58 -40 250 67 -40 stone
execute in minecraft:overworld run fill 250 68 -40 250 69 -40 dirt
execute in minecraft:overworld run setblock 250 70 -40 coarse_dirt
execute in minecraft:overworld run fill 250 71 -40 250 144 -40 air
execute in minecraft:overworld run fill 250 58 -39 250 68 -39 stone
execute in minecraft:overworld run fill 250 69 -39 250 70 -39 dirt
execute in minecraft:overworld run setblock 250 71 -39 grass_block
execute in minecraft:overworld run fill 250 72 -39 250 144 -39 air
execute in minecraft:overworld run fill 250 58 -38 250 69 -38 stone
execute in minecraft:overworld run fill 250 70 -38 250 71 -38 dirt
execute in minecraft:overworld run setblock 250 72 -38 coarse_dirt
execute in minecraft:overworld run fill 250 73 -38 250 144 -38 air
execute in minecraft:overworld run fill 250 58 -37 250 68 -37 stone
execute in minecraft:overworld run fill 250 69 -37 250 70 -37 dirt
execute in minecraft:overworld run setblock 250 71 -37 grass_block
execute in minecraft:overworld run fill 250 72 -37 250 144 -37 air
execute in minecraft:overworld run fill 250 58 -36 250 68 -36 stone
execute in minecraft:overworld run fill 250 69 -36 250 70 -36 dirt
execute in minecraft:overworld run setblock 250 71 -36 coarse_dirt
execute in minecraft:overworld run fill 250 72 -36 250 144 -36 air
execute in minecraft:overworld run fill 250 58 -35 250 68 -35 stone
execute in minecraft:overworld run fill 250 69 -35 250 70 -35 dirt
execute in minecraft:overworld run setblock 250 71 -35 grass_block
execute in minecraft:overworld run fill 250 72 -35 250 144 -35 air
execute in minecraft:overworld run fill 250 58 -34 250 68 -34 stone
execute in minecraft:overworld run fill 250 69 -34 250 70 -34 dirt
execute in minecraft:overworld run setblock 250 71 -34 coarse_dirt
execute in minecraft:overworld run fill 250 72 -34 250 144 -34 air
execute in minecraft:overworld run fill 250 58 -33 250 68 -33 stone
execute in minecraft:overworld run fill 250 69 -33 250 70 -33 dirt
execute in minecraft:overworld run setblock 250 71 -33 coarse_dirt
execute in minecraft:overworld run fill 250 72 -33 250 144 -33 air
execute in minecraft:overworld run fill 250 58 -32 250 68 -32 stone
execute in minecraft:overworld run fill 250 69 -32 250 70 -32 dirt
execute in minecraft:overworld run setblock 250 71 -32 grass_block
execute in minecraft:overworld run fill 250 72 -32 250 144 -32 air
execute in minecraft:overworld run fill 250 58 -31 250 68 -31 stone
execute in minecraft:overworld run fill 250 69 -31 250 70 -31 dirt
execute in minecraft:overworld run setblock 250 71 -31 coarse_dirt
execute in minecraft:overworld run fill 250 72 -31 250 144 -31 air
execute in minecraft:overworld run fill 250 58 -30 250 68 -30 stone
execute in minecraft:overworld run fill 250 69 -30 250 70 -30 dirt
execute in minecraft:overworld run setblock 250 71 -30 coarse_dirt
execute in minecraft:overworld run fill 250 72 -30 250 144 -30 air
execute in minecraft:overworld run fill 250 58 -29 250 68 -29 stone
execute in minecraft:overworld run fill 250 69 -29 250 70 -29 dirt
execute in minecraft:overworld run setblock 250 71 -29 grass_block
execute in minecraft:overworld run fill 250 72 -29 250 144 -29 air
execute in minecraft:overworld run setblock 250 72 -29 grass
execute in minecraft:overworld run fill 250 58 -28 250 68 -28 stone
execute in minecraft:overworld run fill 250 69 -28 250 70 -28 dirt
execute in minecraft:overworld run setblock 250 71 -28 coarse_dirt
execute in minecraft:overworld run fill 250 72 -28 250 144 -28 air
execute in minecraft:overworld run fill 250 58 -27 250 68 -27 stone
execute in minecraft:overworld run fill 250 69 -27 250 70 -27 dirt
execute in minecraft:overworld run setblock 250 71 -27 coarse_dirt
execute in minecraft:overworld run fill 250 72 -27 250 144 -27 air
execute in minecraft:overworld run fill 250 58 -26 250 68 -26 stone
execute in minecraft:overworld run fill 250 69 -26 250 70 -26 dirt
execute in minecraft:overworld run setblock 250 71 -26 grass_block
execute in minecraft:overworld run fill 250 72 -26 250 144 -26 air
execute in minecraft:overworld run fill 250 58 -25 250 68 -25 stone
execute in minecraft:overworld run fill 250 69 -25 250 70 -25 dirt
execute in minecraft:overworld run setblock 250 71 -25 coarse_dirt
execute in minecraft:overworld run fill 250 72 -25 250 144 -25 air
execute in minecraft:overworld run fill 250 58 -24 250 68 -24 stone
execute in minecraft:overworld run fill 250 69 -24 250 70 -24 dirt
execute in minecraft:overworld run setblock 250 71 -24 grass_block
execute in minecraft:overworld run fill 250 72 -24 250 144 -24 air
execute in minecraft:overworld run fill 250 58 -23 250 67 -23 stone
execute in minecraft:overworld run fill 250 68 -23 250 69 -23 dirt
execute in minecraft:overworld run setblock 250 70 -23 coarse_dirt
execute in minecraft:overworld run fill 250 71 -23 250 144 -23 air
execute in minecraft:overworld run fill 250 58 -22 250 67 -22 stone
execute in minecraft:overworld run fill 250 68 -22 250 69 -22 dirt
execute in minecraft:overworld run setblock 250 70 -22 coarse_dirt
execute in minecraft:overworld run fill 250 71 -22 250 144 -22 air
execute in minecraft:overworld run fill 250 58 -21 250 67 -21 stone
execute in minecraft:overworld run fill 250 68 -21 250 69 -21 dirt
execute in minecraft:overworld run setblock 250 70 -21 coarse_dirt
execute in minecraft:overworld run fill 250 71 -21 250 144 -21 air
execute in minecraft:overworld run fill 250 58 -20 250 66 -20 stone
execute in minecraft:overworld run fill 250 67 -20 250 68 -20 dirt
execute in minecraft:overworld run setblock 250 69 -20 coarse_dirt
execute in minecraft:overworld run fill 250 70 -20 250 144 -20 air
execute in minecraft:overworld run fill 250 58 -19 250 66 -19 stone
execute in minecraft:overworld run fill 250 67 -19 250 68 -19 dirt
execute in minecraft:overworld run setblock 250 69 -19 coarse_dirt
execute in minecraft:overworld run fill 250 70 -19 250 144 -19 air
execute in minecraft:overworld run fill 250 58 -18 250 65 -18 stone
execute in minecraft:overworld run fill 250 66 -18 250 67 -18 dirt
execute in minecraft:overworld run setblock 250 68 -18 grass_block
execute in minecraft:overworld run fill 250 69 -18 250 144 -18 air
execute in minecraft:overworld run fill 250 58 -17 250 65 -17 stone
execute in minecraft:overworld run fill 250 66 -17 250 67 -17 dirt
schedule function blade_gallery:random/burned/part_65 1t replace
