execute in minecraft:overworld run fill 385 59 -9 385 60 -9 dirt
execute in minecraft:overworld run setblock 385 61 -9 gravel
execute in minecraft:overworld run fill 385 62 -9 385 144 -9 air
execute in minecraft:overworld run fill 385 62 -9 385 64 -9 water
execute in minecraft:overworld run fill 385 58 -8 385 58 -8 stone
execute in minecraft:overworld run fill 385 59 -8 385 60 -8 dirt
execute in minecraft:overworld run setblock 385 61 -8 gravel
execute in minecraft:overworld run fill 385 62 -8 385 144 -8 air
execute in minecraft:overworld run fill 385 62 -8 385 64 -8 water
execute in minecraft:overworld run fill 385 58 -7 385 59 -7 stone
execute in minecraft:overworld run fill 385 60 -7 385 61 -7 dirt
execute in minecraft:overworld run setblock 385 62 -7 gravel
execute in minecraft:overworld run fill 385 63 -7 385 144 -7 air
execute in minecraft:overworld run fill 385 63 -7 385 64 -7 water
execute in minecraft:overworld run fill 385 58 -6 385 59 -6 stone
execute in minecraft:overworld run fill 385 60 -6 385 61 -6 dirt
execute in minecraft:overworld run setblock 385 62 -6 gravel
execute in minecraft:overworld run fill 385 63 -6 385 144 -6 air
execute in minecraft:overworld run fill 385 63 -6 385 64 -6 water
execute in minecraft:overworld run fill 385 58 -5 385 59 -5 stone
execute in minecraft:overworld run fill 385 60 -5 385 61 -5 dirt
execute in minecraft:overworld run setblock 385 62 -5 gravel
execute in minecraft:overworld run fill 385 63 -5 385 144 -5 air
execute in minecraft:overworld run fill 385 63 -5 385 64 -5 water
execute in minecraft:overworld run fill 385 58 -4 385 60 -4 stone
execute in minecraft:overworld run fill 385 61 -4 385 62 -4 dirt
execute in minecraft:overworld run setblock 385 63 -4 gravel
execute in minecraft:overworld run fill 385 64 -4 385 144 -4 air
execute in minecraft:overworld run fill 385 64 -4 385 64 -4 water
execute in minecraft:overworld run fill 385 58 -3 385 60 -3 stone
execute in minecraft:overworld run fill 385 61 -3 385 62 -3 dirt
execute in minecraft:overworld run setblock 385 63 -3 gravel
execute in minecraft:overworld run fill 385 64 -3 385 144 -3 air
execute in minecraft:overworld run fill 385 64 -3 385 64 -3 water
execute in minecraft:overworld run fill 385 58 -2 385 60 -2 stone
execute in minecraft:overworld run fill 385 61 -2 385 62 -2 dirt
execute in minecraft:overworld run setblock 385 63 -2 gravel
execute in minecraft:overworld run fill 385 64 -2 385 144 -2 air
execute in minecraft:overworld run fill 385 64 -2 385 64 -2 water
execute in minecraft:overworld run fill 385 58 -1 385 61 -1 stone
execute in minecraft:overworld run fill 385 62 -1 385 63 -1 dirt
execute in minecraft:overworld run setblock 385 64 -1 coarse_dirt
execute in minecraft:overworld run fill 385 65 -1 385 144 -1 air
execute in minecraft:overworld run fill 385 58 0 385 61 0 stone
execute in minecraft:overworld run fill 385 62 0 385 63 0 dirt
execute in minecraft:overworld run setblock 385 64 0 grass_block
execute in minecraft:overworld run fill 385 65 0 385 144 0 air
execute in minecraft:overworld run fill 385 58 1 385 61 1 stone
execute in minecraft:overworld run fill 385 62 1 385 63 1 dirt
execute in minecraft:overworld run setblock 385 64 1 coarse_dirt
execute in minecraft:overworld run fill 385 65 1 385 144 1 air
execute in minecraft:overworld run fill 385 58 2 385 61 2 stone
execute in minecraft:overworld run fill 385 62 2 385 63 2 dirt
execute in minecraft:overworld run setblock 385 64 2 grass_block
execute in minecraft:overworld run fill 385 65 2 385 144 2 air
execute in minecraft:overworld run fill 385 58 3 385 61 3 stone
execute in minecraft:overworld run fill 385 62 3 385 63 3 dirt
execute in minecraft:overworld run setblock 385 64 3 coarse_dirt
execute in minecraft:overworld run fill 385 65 3 385 144 3 air
execute in minecraft:overworld run fill 385 58 4 385 61 4 stone
execute in minecraft:overworld run fill 385 62 4 385 63 4 dirt
execute in minecraft:overworld run setblock 385 64 4 grass_block
execute in minecraft:overworld run fill 385 65 4 385 144 4 air
execute in minecraft:overworld run fill 385 58 5 385 61 5 stone
execute in minecraft:overworld run fill 385 62 5 385 63 5 dirt
execute in minecraft:overworld run setblock 385 64 5 grass_block
execute in minecraft:overworld run fill 385 65 5 385 144 5 air
execute in minecraft:overworld run fill 385 58 6 385 61 6 stone
execute in minecraft:overworld run fill 385 62 6 385 63 6 dirt
execute in minecraft:overworld run setblock 385 64 6 coarse_dirt
execute in minecraft:overworld run fill 385 65 6 385 144 6 air
execute in minecraft:overworld run fill 385 58 7 385 62 7 stone
execute in minecraft:overworld run fill 385 63 7 385 64 7 dirt
execute in minecraft:overworld run setblock 385 65 7 grass_block
execute in minecraft:overworld run fill 385 66 7 385 144 7 air
execute in minecraft:overworld run fill 385 58 8 385 62 8 stone
execute in minecraft:overworld run fill 385 63 8 385 64 8 dirt
execute in minecraft:overworld run setblock 385 65 8 coarse_dirt
execute in minecraft:overworld run fill 385 66 8 385 144 8 air
execute in minecraft:overworld run fill 385 58 9 385 62 9 stone
execute in minecraft:overworld run fill 385 63 9 385 64 9 dirt
execute in minecraft:overworld run setblock 385 65 9 coarse_dirt
execute in minecraft:overworld run fill 385 66 9 385 144 9 air
execute in minecraft:overworld run fill 385 58 10 385 62 10 stone
execute in minecraft:overworld run fill 385 63 10 385 64 10 dirt
execute in minecraft:overworld run setblock 385 65 10 coarse_dirt
execute in minecraft:overworld run fill 385 66 10 385 144 10 air
execute in minecraft:overworld run fill 385 58 11 385 62 11 stone
execute in minecraft:overworld run fill 385 63 11 385 64 11 dirt
execute in minecraft:overworld run setblock 385 65 11 coarse_dirt
execute in minecraft:overworld run fill 385 66 11 385 144 11 air
execute in minecraft:overworld run fill 385 58 12 385 62 12 stone
execute in minecraft:overworld run fill 385 63 12 385 64 12 dirt
execute in minecraft:overworld run setblock 385 65 12 coarse_dirt
execute in minecraft:overworld run fill 385 66 12 385 144 12 air
execute in minecraft:overworld run fill 385 58 13 385 63 13 stone
execute in minecraft:overworld run fill 385 64 13 385 65 13 dirt
execute in minecraft:overworld run setblock 385 66 13 grass_block
execute in minecraft:overworld run fill 385 67 13 385 144 13 air
execute in minecraft:overworld run fill 385 58 14 385 63 14 stone
execute in minecraft:overworld run fill 385 64 14 385 65 14 dirt
execute in minecraft:overworld run setblock 385 66 14 grass_block
execute in minecraft:overworld run fill 385 67 14 385 144 14 air
execute in minecraft:overworld run fill 385 58 15 385 63 15 stone
execute in minecraft:overworld run fill 385 64 15 385 65 15 dirt
execute in minecraft:overworld run setblock 385 66 15 coarse_dirt
execute in minecraft:overworld run fill 385 67 15 385 144 15 air
execute in minecraft:overworld run fill 385 58 16 385 63 16 stone
execute in minecraft:overworld run fill 385 64 16 385 65 16 dirt
execute in minecraft:overworld run setblock 385 66 16 coarse_dirt
execute in minecraft:overworld run fill 385 67 16 385 144 16 air
execute in minecraft:overworld run fill 385 58 17 385 63 17 stone
execute in minecraft:overworld run fill 385 64 17 385 65 17 dirt
execute in minecraft:overworld run setblock 385 66 17 grass_block
execute in minecraft:overworld run fill 385 67 17 385 144 17 air
execute in minecraft:overworld run setblock 385 67 17 grass
execute in minecraft:overworld run fill 385 58 18 385 63 18 stone
execute in minecraft:overworld run fill 385 64 18 385 65 18 dirt
execute in minecraft:overworld run setblock 385 66 18 coarse_dirt
execute in minecraft:overworld run fill 385 67 18 385 144 18 air
execute in minecraft:overworld run fill 385 58 19 385 63 19 stone
execute in minecraft:overworld run fill 385 64 19 385 65 19 dirt
execute in minecraft:overworld run setblock 385 66 19 grass_block
execute in minecraft:overworld run fill 385 67 19 385 144 19 air
execute in minecraft:overworld run fill 385 58 20 385 63 20 stone
execute in minecraft:overworld run fill 385 64 20 385 65 20 dirt
execute in minecraft:overworld run setblock 385 66 20 grass_block
execute in minecraft:overworld run fill 385 67 20 385 144 20 air
execute in minecraft:overworld run fill 385 58 21 385 63 21 stone
execute in minecraft:overworld run fill 385 64 21 385 65 21 dirt
execute in minecraft:overworld run setblock 385 66 21 coarse_dirt
execute in minecraft:overworld run fill 385 67 21 385 144 21 air
execute in minecraft:overworld run fill 385 58 22 385 63 22 stone
execute in minecraft:overworld run fill 385 64 22 385 65 22 dirt
execute in minecraft:overworld run setblock 385 66 22 coarse_dirt
execute in minecraft:overworld run fill 385 67 22 385 144 22 air
execute in minecraft:overworld run fill 385 58 23 385 63 23 stone
execute in minecraft:overworld run fill 385 64 23 385 65 23 dirt
execute in minecraft:overworld run setblock 385 66 23 grass_block
execute in minecraft:overworld run fill 385 67 23 385 144 23 air
execute in minecraft:overworld run fill 385 58 24 385 63 24 stone
execute in minecraft:overworld run fill 385 64 24 385 65 24 dirt
execute in minecraft:overworld run setblock 385 66 24 coarse_dirt
execute in minecraft:overworld run fill 385 67 24 385 144 24 air
execute in minecraft:overworld run fill 385 58 25 385 63 25 stone
execute in minecraft:overworld run fill 385 64 25 385 65 25 dirt
execute in minecraft:overworld run setblock 385 66 25 coarse_dirt
execute in minecraft:overworld run fill 385 67 25 385 144 25 air
execute in minecraft:overworld run fill 385 58 26 385 63 26 stone
execute in minecraft:overworld run fill 385 64 26 385 65 26 dirt
execute in minecraft:overworld run setblock 385 66 26 coarse_dirt
execute in minecraft:overworld run fill 385 67 26 385 144 26 air
execute in minecraft:overworld run fill 385 58 27 385 63 27 stone
execute in minecraft:overworld run fill 385 64 27 385 65 27 dirt
execute in minecraft:overworld run setblock 385 66 27 coarse_dirt
execute in minecraft:overworld run fill 385 67 27 385 144 27 air
execute in minecraft:overworld run fill 385 58 28 385 63 28 stone
execute in minecraft:overworld run fill 385 64 28 385 65 28 dirt
execute in minecraft:overworld run setblock 385 66 28 grass_block
execute in minecraft:overworld run fill 385 67 28 385 144 28 air
execute in minecraft:overworld run fill 385 58 29 385 62 29 stone
execute in minecraft:overworld run fill 385 63 29 385 64 29 dirt
execute in minecraft:overworld run setblock 385 65 29 coarse_dirt
execute in minecraft:overworld run fill 385 66 29 385 144 29 air
execute in minecraft:overworld run setblock 385 66 29 mossy_cobblestone
execute in minecraft:overworld run fill 385 58 30 385 62 30 stone
execute in minecraft:overworld run fill 385 63 30 385 64 30 dirt
execute in minecraft:overworld run setblock 385 65 30 coarse_dirt
execute in minecraft:overworld run fill 385 66 30 385 144 30 air
execute in minecraft:overworld run fill 385 58 31 385 62 31 stone
execute in minecraft:overworld run fill 385 63 31 385 64 31 dirt
execute in minecraft:overworld run setblock 385 65 31 coarse_dirt
execute in minecraft:overworld run fill 385 66 31 385 144 31 air
execute in minecraft:overworld run fill 385 58 32 385 62 32 stone
execute in minecraft:overworld run fill 385 63 32 385 64 32 dirt
execute in minecraft:overworld run setblock 385 65 32 coarse_dirt
execute in minecraft:overworld run fill 385 66 32 385 144 32 air
execute in minecraft:overworld run fill 385 58 33 385 62 33 stone
execute in minecraft:overworld run fill 385 63 33 385 64 33 dirt
execute in minecraft:overworld run setblock 385 65 33 coarse_dirt
execute in minecraft:overworld run fill 385 66 33 385 144 33 air
execute in minecraft:overworld run fill 385 58 34 385 62 34 stone
execute in minecraft:overworld run fill 385 63 34 385 64 34 dirt
execute in minecraft:overworld run setblock 385 65 34 coarse_dirt
execute in minecraft:overworld run fill 385 66 34 385 144 34 air
execute in minecraft:overworld run setblock 385 66 34 grass
execute in minecraft:overworld run fill 385 58 35 385 61 35 stone
execute in minecraft:overworld run fill 385 62 35 385 63 35 dirt
execute in minecraft:overworld run setblock 385 64 35 grass_block
execute in minecraft:overworld run fill 385 65 35 385 144 35 air
execute in minecraft:overworld run fill 385 58 36 385 61 36 stone
execute in minecraft:overworld run fill 385 62 36 385 63 36 dirt
execute in minecraft:overworld run setblock 385 64 36 coarse_dirt
execute in minecraft:overworld run fill 385 65 36 385 144 36 air
execute in minecraft:overworld run fill 385 58 37 385 61 37 stone
execute in minecraft:overworld run fill 385 62 37 385 63 37 dirt
execute in minecraft:overworld run setblock 385 64 37 grass_block
execute in minecraft:overworld run fill 385 65 37 385 144 37 air
execute in minecraft:overworld run fill 385 58 38 385 61 38 stone
execute in minecraft:overworld run fill 385 62 38 385 63 38 dirt
execute in minecraft:overworld run setblock 385 64 38 grass_block
execute in minecraft:overworld run fill 385 65 38 385 144 38 air
execute in minecraft:overworld run fill 385 58 39 385 60 39 stone
execute in minecraft:overworld run fill 385 61 39 385 62 39 dirt
execute in minecraft:overworld run setblock 385 63 39 gravel
execute in minecraft:overworld run fill 385 64 39 385 144 39 air
execute in minecraft:overworld run fill 385 64 39 385 64 39 water
execute in minecraft:overworld run fill 385 58 40 385 60 40 stone
execute in minecraft:overworld run fill 385 61 40 385 62 40 dirt
execute in minecraft:overworld run setblock 385 63 40 gravel
execute in minecraft:overworld run fill 385 64 40 385 144 40 air
execute in minecraft:overworld run fill 385 64 40 385 64 40 water
execute in minecraft:overworld run fill 385 58 41 385 60 41 stone
execute in minecraft:overworld run fill 385 61 41 385 62 41 dirt
execute in minecraft:overworld run setblock 385 63 41 gravel
execute in minecraft:overworld run fill 385 64 41 385 144 41 air
execute in minecraft:overworld run fill 385 64 41 385 64 41 water
execute in minecraft:overworld run fill 385 58 42 385 60 42 stone
execute in minecraft:overworld run fill 385 61 42 385 62 42 dirt
execute in minecraft:overworld run setblock 385 63 42 gravel
execute in minecraft:overworld run fill 385 64 42 385 144 42 air
execute in minecraft:overworld run fill 385 64 42 385 64 42 water
execute in minecraft:overworld run fill 385 58 43 385 60 43 stone
execute in minecraft:overworld run fill 385 61 43 385 62 43 dirt
execute in minecraft:overworld run setblock 385 63 43 gravel
execute in minecraft:overworld run fill 385 64 43 385 144 43 air
execute in minecraft:overworld run fill 385 64 43 385 64 43 water
execute in minecraft:overworld run fill 385 58 44 385 60 44 stone
execute in minecraft:overworld run fill 385 61 44 385 62 44 dirt
execute in minecraft:overworld run setblock 385 63 44 gravel
execute in minecraft:overworld run fill 385 64 44 385 144 44 air
execute in minecraft:overworld run fill 385 64 44 385 64 44 water
execute in minecraft:overworld run fill 385 58 45 385 61 45 stone
execute in minecraft:overworld run fill 385 62 45 385 63 45 dirt
execute in minecraft:overworld run setblock 385 64 45 grass_block
execute in minecraft:overworld run fill 385 65 45 385 144 45 air
execute in minecraft:overworld run fill 385 58 46 385 61 46 stone
execute in minecraft:overworld run fill 385 62 46 385 63 46 dirt
execute in minecraft:overworld run setblock 385 64 46 grass_block
execute in minecraft:overworld run fill 385 65 46 385 144 46 air
execute in minecraft:overworld run fill 385 58 47 385 61 47 stone
execute in minecraft:overworld run fill 385 62 47 385 63 47 dirt
execute in minecraft:overworld run setblock 385 64 47 coarse_dirt
execute in minecraft:overworld run fill 385 65 47 385 144 47 air
execute in minecraft:overworld run fill 386 58 -48 386 61 -48 stone
execute in minecraft:overworld run fill 386 62 -48 386 63 -48 dirt
execute in minecraft:overworld run setblock 386 64 -48 coarse_dirt
execute in minecraft:overworld run fill 386 65 -48 386 144 -48 air
execute in minecraft:overworld run fill 386 58 -47 386 62 -47 stone
execute in minecraft:overworld run fill 386 63 -47 386 64 -47 dirt
execute in minecraft:overworld run setblock 386 65 -47 coarse_dirt
execute in minecraft:overworld run fill 386 66 -47 386 144 -47 air
execute in minecraft:overworld run fill 386 58 -46 386 64 -46 stone
execute in minecraft:overworld run fill 386 65 -46 386 66 -46 dirt
execute in minecraft:overworld run setblock 386 67 -46 coarse_dirt
execute in minecraft:overworld run fill 386 68 -46 386 144 -46 air
schedule function blade_gallery:random/battlefield/part_77 1t replace
