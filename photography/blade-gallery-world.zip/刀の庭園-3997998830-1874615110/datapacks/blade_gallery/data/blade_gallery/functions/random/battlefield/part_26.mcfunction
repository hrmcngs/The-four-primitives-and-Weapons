execute in minecraft:overworld run setblock 353 74 -42 coarse_dirt
execute in minecraft:overworld run fill 353 75 -42 353 144 -42 air
execute in minecraft:overworld run fill 353 58 -41 353 72 -41 stone
execute in minecraft:overworld run fill 353 73 -41 353 74 -41 dirt
execute in minecraft:overworld run setblock 353 75 -41 coarse_dirt
execute in minecraft:overworld run fill 353 76 -41 353 144 -41 air
execute in minecraft:overworld run fill 353 58 -40 353 74 -40 stone
execute in minecraft:overworld run fill 353 75 -40 353 76 -40 dirt
execute in minecraft:overworld run setblock 353 77 -40 grass_block
execute in minecraft:overworld run fill 353 78 -40 353 144 -40 air
execute in minecraft:overworld run setblock 353 78 -40 grass
execute in minecraft:overworld run fill 353 58 -39 353 75 -39 stone
execute in minecraft:overworld run fill 353 76 -39 353 77 -39 dirt
execute in minecraft:overworld run setblock 353 78 -39 coarse_dirt
execute in minecraft:overworld run fill 353 79 -39 353 144 -39 air
execute in minecraft:overworld run fill 353 58 -38 353 75 -38 stone
execute in minecraft:overworld run fill 353 76 -38 353 77 -38 dirt
execute in minecraft:overworld run setblock 353 78 -38 coarse_dirt
execute in minecraft:overworld run fill 353 79 -38 353 144 -38 air
execute in minecraft:overworld run fill 353 58 -37 353 75 -37 stone
execute in minecraft:overworld run fill 353 76 -37 353 77 -37 dirt
execute in minecraft:overworld run setblock 353 78 -37 coarse_dirt
execute in minecraft:overworld run fill 353 79 -37 353 144 -37 air
execute in minecraft:overworld run fill 353 58 -36 353 75 -36 stone
execute in minecraft:overworld run fill 353 76 -36 353 77 -36 dirt
execute in minecraft:overworld run setblock 353 78 -36 grass_block
execute in minecraft:overworld run fill 353 79 -36 353 144 -36 air
execute in minecraft:overworld run fill 353 58 -35 353 74 -35 stone
execute in minecraft:overworld run fill 353 75 -35 353 76 -35 dirt
execute in minecraft:overworld run setblock 353 77 -35 grass_block
execute in minecraft:overworld run fill 353 78 -35 353 144 -35 air
execute in minecraft:overworld run fill 353 58 -34 353 74 -34 stone
execute in minecraft:overworld run fill 353 75 -34 353 76 -34 dirt
execute in minecraft:overworld run setblock 353 77 -34 coarse_dirt
execute in minecraft:overworld run fill 353 78 -34 353 144 -34 air
execute in minecraft:overworld run fill 353 58 -33 353 74 -33 stone
execute in minecraft:overworld run fill 353 75 -33 353 76 -33 dirt
execute in minecraft:overworld run setblock 353 77 -33 coarse_dirt
execute in minecraft:overworld run fill 353 78 -33 353 144 -33 air
execute in minecraft:overworld run fill 353 58 -32 353 74 -32 stone
execute in minecraft:overworld run fill 353 75 -32 353 76 -32 dirt
execute in minecraft:overworld run setblock 353 77 -32 coarse_dirt
execute in minecraft:overworld run fill 353 78 -32 353 144 -32 air
execute in minecraft:overworld run fill 353 58 -31 353 74 -31 stone
execute in minecraft:overworld run fill 353 75 -31 353 76 -31 dirt
execute in minecraft:overworld run setblock 353 77 -31 coarse_dirt
execute in minecraft:overworld run fill 353 78 -31 353 144 -31 air
execute in minecraft:overworld run fill 353 58 -30 353 74 -30 stone
execute in minecraft:overworld run fill 353 75 -30 353 76 -30 dirt
execute in minecraft:overworld run setblock 353 77 -30 grass_block
execute in minecraft:overworld run fill 353 78 -30 353 144 -30 air
execute in minecraft:overworld run fill 353 58 -29 353 73 -29 stone
execute in minecraft:overworld run fill 353 74 -29 353 75 -29 dirt
execute in minecraft:overworld run setblock 353 76 -29 grass_block
execute in minecraft:overworld run fill 353 77 -29 353 144 -29 air
execute in minecraft:overworld run fill 353 58 -28 353 73 -28 stone
execute in minecraft:overworld run fill 353 74 -28 353 75 -28 dirt
execute in minecraft:overworld run setblock 353 76 -28 coarse_dirt
execute in minecraft:overworld run fill 353 77 -28 353 144 -28 air
execute in minecraft:overworld run fill 353 58 -27 353 73 -27 stone
execute in minecraft:overworld run fill 353 74 -27 353 75 -27 dirt
execute in minecraft:overworld run setblock 353 76 -27 coarse_dirt
execute in minecraft:overworld run fill 353 77 -27 353 144 -27 air
execute in minecraft:overworld run fill 353 58 -26 353 72 -26 stone
execute in minecraft:overworld run fill 353 73 -26 353 74 -26 dirt
execute in minecraft:overworld run setblock 353 75 -26 coarse_dirt
execute in minecraft:overworld run fill 353 76 -26 353 144 -26 air
execute in minecraft:overworld run fill 353 58 -25 353 72 -25 stone
execute in minecraft:overworld run fill 353 73 -25 353 74 -25 dirt
execute in minecraft:overworld run setblock 353 75 -25 coarse_dirt
execute in minecraft:overworld run fill 353 76 -25 353 144 -25 air
execute in minecraft:overworld run setblock 353 76 -25 grass
execute in minecraft:overworld run fill 353 58 -24 353 72 -24 stone
execute in minecraft:overworld run fill 353 73 -24 353 74 -24 dirt
execute in minecraft:overworld run setblock 353 75 -24 coarse_dirt
execute in minecraft:overworld run fill 353 76 -24 353 144 -24 air
execute in minecraft:overworld run fill 353 58 -23 353 71 -23 stone
execute in minecraft:overworld run fill 353 72 -23 353 73 -23 dirt
execute in minecraft:overworld run setblock 353 74 -23 coarse_dirt
execute in minecraft:overworld run fill 353 75 -23 353 144 -23 air
execute in minecraft:overworld run fill 353 58 -22 353 71 -22 stone
execute in minecraft:overworld run fill 353 72 -22 353 73 -22 dirt
execute in minecraft:overworld run setblock 353 74 -22 grass_block
execute in minecraft:overworld run fill 353 75 -22 353 144 -22 air
execute in minecraft:overworld run fill 353 58 -21 353 71 -21 stone
execute in minecraft:overworld run fill 353 72 -21 353 73 -21 dirt
execute in minecraft:overworld run setblock 353 74 -21 grass_block
execute in minecraft:overworld run fill 353 75 -21 353 144 -21 air
execute in minecraft:overworld run fill 353 58 -20 353 70 -20 stone
execute in minecraft:overworld run fill 353 71 -20 353 72 -20 dirt
execute in minecraft:overworld run setblock 353 73 -20 grass_block
execute in minecraft:overworld run fill 353 74 -20 353 144 -20 air
execute in minecraft:overworld run fill 353 58 -19 353 70 -19 stone
execute in minecraft:overworld run fill 353 71 -19 353 72 -19 dirt
execute in minecraft:overworld run setblock 353 73 -19 coarse_dirt
execute in minecraft:overworld run fill 353 74 -19 353 144 -19 air
execute in minecraft:overworld run fill 353 58 -18 353 70 -18 stone
execute in minecraft:overworld run fill 353 71 -18 353 72 -18 dirt
execute in minecraft:overworld run setblock 353 73 -18 coarse_dirt
execute in minecraft:overworld run fill 353 74 -18 353 144 -18 air
execute in minecraft:overworld run fill 353 58 -17 353 69 -17 stone
execute in minecraft:overworld run fill 353 70 -17 353 71 -17 dirt
execute in minecraft:overworld run setblock 353 72 -17 coarse_dirt
execute in minecraft:overworld run fill 353 73 -17 353 144 -17 air
execute in minecraft:overworld run fill 353 58 -16 353 69 -16 stone
execute in minecraft:overworld run fill 353 70 -16 353 71 -16 dirt
execute in minecraft:overworld run setblock 353 72 -16 coarse_dirt
execute in minecraft:overworld run fill 353 73 -16 353 144 -16 air
execute in minecraft:overworld run fill 353 58 -15 353 68 -15 stone
execute in minecraft:overworld run fill 353 69 -15 353 70 -15 dirt
execute in minecraft:overworld run setblock 353 71 -15 grass_block
execute in minecraft:overworld run fill 353 72 -15 353 144 -15 air
execute in minecraft:overworld run fill 353 58 -14 353 68 -14 stone
execute in minecraft:overworld run fill 353 69 -14 353 70 -14 dirt
execute in minecraft:overworld run setblock 353 71 -14 grass_block
execute in minecraft:overworld run fill 353 72 -14 353 144 -14 air
execute in minecraft:overworld run fill 353 58 -13 353 67 -13 stone
execute in minecraft:overworld run fill 353 68 -13 353 69 -13 dirt
execute in minecraft:overworld run setblock 353 70 -13 coarse_dirt
execute in minecraft:overworld run fill 353 71 -13 353 144 -13 air
execute in minecraft:overworld run fill 353 58 -12 353 67 -12 stone
execute in minecraft:overworld run fill 353 68 -12 353 69 -12 dirt
execute in minecraft:overworld run setblock 353 70 -12 coarse_dirt
execute in minecraft:overworld run fill 353 71 -12 353 144 -12 air
execute in minecraft:overworld run fill 353 58 -11 353 67 -11 stone
execute in minecraft:overworld run fill 353 68 -11 353 69 -11 dirt
execute in minecraft:overworld run setblock 353 70 -11 coarse_dirt
execute in minecraft:overworld run fill 353 71 -11 353 144 -11 air
execute in minecraft:overworld run fill 353 58 -10 353 67 -10 stone
execute in minecraft:overworld run fill 353 68 -10 353 69 -10 dirt
execute in minecraft:overworld run setblock 353 70 -10 grass_block
execute in minecraft:overworld run fill 353 71 -10 353 144 -10 air
execute in minecraft:overworld run fill 353 58 -9 353 67 -9 stone
execute in minecraft:overworld run fill 353 68 -9 353 69 -9 dirt
execute in minecraft:overworld run setblock 353 70 -9 coarse_dirt
execute in minecraft:overworld run fill 353 71 -9 353 144 -9 air
execute in minecraft:overworld run fill 353 58 -8 353 67 -8 stone
execute in minecraft:overworld run fill 353 68 -8 353 69 -8 dirt
execute in minecraft:overworld run setblock 353 70 -8 coarse_dirt
execute in minecraft:overworld run fill 353 71 -8 353 144 -8 air
execute in minecraft:overworld run fill 353 58 -7 353 67 -7 stone
execute in minecraft:overworld run fill 353 68 -7 353 69 -7 dirt
execute in minecraft:overworld run setblock 353 70 -7 grass_block
execute in minecraft:overworld run fill 353 71 -7 353 144 -7 air
execute in minecraft:overworld run fill 353 58 -6 353 66 -6 stone
execute in minecraft:overworld run fill 353 67 -6 353 68 -6 dirt
execute in minecraft:overworld run setblock 353 69 -6 grass_block
execute in minecraft:overworld run fill 353 70 -6 353 144 -6 air
execute in minecraft:overworld run fill 353 58 -5 353 66 -5 stone
execute in minecraft:overworld run fill 353 67 -5 353 68 -5 dirt
execute in minecraft:overworld run setblock 353 69 -5 coarse_dirt
execute in minecraft:overworld run fill 353 70 -5 353 144 -5 air
execute in minecraft:overworld run fill 353 58 -4 353 66 -4 stone
execute in minecraft:overworld run fill 353 67 -4 353 68 -4 dirt
execute in minecraft:overworld run setblock 353 69 -4 grass_block
execute in minecraft:overworld run fill 353 70 -4 353 144 -4 air
execute in minecraft:overworld run fill 353 58 -3 353 66 -3 stone
execute in minecraft:overworld run fill 353 67 -3 353 68 -3 dirt
execute in minecraft:overworld run setblock 353 69 -3 grass_block
execute in minecraft:overworld run fill 353 70 -3 353 144 -3 air
execute in minecraft:overworld run fill 353 58 -2 353 66 -2 stone
execute in minecraft:overworld run fill 353 67 -2 353 68 -2 dirt
execute in minecraft:overworld run setblock 353 69 -2 coarse_dirt
execute in minecraft:overworld run fill 353 70 -2 353 144 -2 air
execute in minecraft:overworld run fill 353 58 -1 353 66 -1 stone
execute in minecraft:overworld run fill 353 67 -1 353 68 -1 dirt
execute in minecraft:overworld run setblock 353 69 -1 coarse_dirt
execute in minecraft:overworld run fill 353 70 -1 353 144 -1 air
execute in minecraft:overworld run fill 353 58 0 353 66 0 stone
execute in minecraft:overworld run fill 353 67 0 353 68 0 dirt
execute in minecraft:overworld run setblock 353 69 0 grass_block
execute in minecraft:overworld run fill 353 70 0 353 144 0 air
execute in minecraft:overworld run fill 353 58 1 353 66 1 stone
execute in minecraft:overworld run fill 353 67 1 353 68 1 dirt
execute in minecraft:overworld run setblock 353 69 1 coarse_dirt
execute in minecraft:overworld run fill 353 70 1 353 144 1 air
execute in minecraft:overworld run fill 353 58 2 353 66 2 stone
execute in minecraft:overworld run fill 353 67 2 353 68 2 dirt
execute in minecraft:overworld run setblock 353 69 2 grass_block
execute in minecraft:overworld run fill 353 70 2 353 144 2 air
execute in minecraft:overworld run fill 353 58 3 353 66 3 stone
execute in minecraft:overworld run fill 353 67 3 353 68 3 dirt
execute in minecraft:overworld run setblock 353 69 3 coarse_dirt
execute in minecraft:overworld run fill 353 70 3 353 144 3 air
execute in minecraft:overworld run fill 353 58 4 353 67 4 stone
execute in minecraft:overworld run fill 353 68 4 353 69 4 dirt
execute in minecraft:overworld run setblock 353 70 4 coarse_dirt
execute in minecraft:overworld run fill 353 71 4 353 144 4 air
execute in minecraft:overworld run fill 353 58 5 353 67 5 stone
execute in minecraft:overworld run fill 353 68 5 353 69 5 dirt
execute in minecraft:overworld run setblock 353 70 5 coarse_dirt
execute in minecraft:overworld run fill 353 71 5 353 144 5 air
execute in minecraft:overworld run fill 353 58 6 353 67 6 stone
execute in minecraft:overworld run fill 353 68 6 353 69 6 dirt
execute in minecraft:overworld run setblock 353 70 6 coarse_dirt
execute in minecraft:overworld run fill 353 71 6 353 144 6 air
execute in minecraft:overworld run fill 353 58 7 353 67 7 stone
execute in minecraft:overworld run fill 353 68 7 353 69 7 dirt
execute in minecraft:overworld run setblock 353 70 7 grass_block
execute in minecraft:overworld run fill 353 71 7 353 144 7 air
execute in minecraft:overworld run fill 353 58 8 353 67 8 stone
execute in minecraft:overworld run fill 353 68 8 353 69 8 dirt
execute in minecraft:overworld run setblock 353 70 8 grass_block
execute in minecraft:overworld run fill 353 71 8 353 144 8 air
execute in minecraft:overworld run fill 353 58 9 353 67 9 stone
execute in minecraft:overworld run fill 353 68 9 353 69 9 dirt
execute in minecraft:overworld run setblock 353 70 9 coarse_dirt
execute in minecraft:overworld run fill 353 71 9 353 144 9 air
execute in minecraft:overworld run fill 353 58 10 353 67 10 stone
execute in minecraft:overworld run fill 353 68 10 353 69 10 dirt
execute in minecraft:overworld run setblock 353 70 10 coarse_dirt
execute in minecraft:overworld run fill 353 71 10 353 144 10 air
execute in minecraft:overworld run fill 353 58 11 353 67 11 stone
execute in minecraft:overworld run fill 353 68 11 353 69 11 dirt
execute in minecraft:overworld run setblock 353 70 11 coarse_dirt
execute in minecraft:overworld run fill 353 71 11 353 144 11 air
execute in minecraft:overworld run fill 353 58 12 353 67 12 stone
execute in minecraft:overworld run fill 353 68 12 353 69 12 dirt
execute in minecraft:overworld run setblock 353 70 12 coarse_dirt
execute in minecraft:overworld run fill 353 71 12 353 144 12 air
execute in minecraft:overworld run fill 353 58 13 353 67 13 stone
execute in minecraft:overworld run fill 353 68 13 353 69 13 dirt
execute in minecraft:overworld run setblock 353 70 13 grass_block
execute in minecraft:overworld run fill 353 71 13 353 144 13 air
execute in minecraft:overworld run fill 353 58 14 353 67 14 stone
execute in minecraft:overworld run fill 353 68 14 353 69 14 dirt
execute in minecraft:overworld run setblock 353 70 14 coarse_dirt
execute in minecraft:overworld run fill 353 71 14 353 144 14 air
execute in minecraft:overworld run fill 353 58 15 353 66 15 stone
execute in minecraft:overworld run fill 353 67 15 353 68 15 dirt
execute in minecraft:overworld run setblock 353 69 15 grass_block
execute in minecraft:overworld run fill 353 70 15 353 144 15 air
execute in minecraft:overworld run fill 353 58 16 353 66 16 stone
execute in minecraft:overworld run fill 353 67 16 353 68 16 dirt
execute in minecraft:overworld run setblock 353 69 16 coarse_dirt
execute in minecraft:overworld run fill 353 70 16 353 144 16 air
execute in minecraft:overworld run fill 353 58 17 353 66 17 stone
execute in minecraft:overworld run fill 353 67 17 353 68 17 dirt
execute in minecraft:overworld run setblock 353 69 17 coarse_dirt
execute in minecraft:overworld run fill 353 70 17 353 144 17 air
execute in minecraft:overworld run fill 353 58 18 353 66 18 stone
execute in minecraft:overworld run fill 353 67 18 353 68 18 dirt
execute in minecraft:overworld run setblock 353 69 18 grass_block
execute in minecraft:overworld run fill 353 70 18 353 144 18 air
execute in minecraft:overworld run fill 353 58 19 353 66 19 stone
execute in minecraft:overworld run fill 353 67 19 353 68 19 dirt
execute in minecraft:overworld run setblock 353 69 19 coarse_dirt
execute in minecraft:overworld run fill 353 70 19 353 144 19 air
execute in minecraft:overworld run fill 353 58 20 353 66 20 stone
execute in minecraft:overworld run fill 353 67 20 353 68 20 dirt
execute in minecraft:overworld run setblock 353 69 20 grass_block
execute in minecraft:overworld run fill 353 70 20 353 144 20 air
execute in minecraft:overworld run fill 353 58 21 353 67 21 stone
execute in minecraft:overworld run fill 353 68 21 353 69 21 dirt
execute in minecraft:overworld run setblock 353 70 21 coarse_dirt
execute in minecraft:overworld run fill 353 71 21 353 144 21 air
schedule function blade_gallery:random/battlefield/part_27 1t replace
