execute in minecraft:overworld run fill 358 58 39 358 68 39 stone
execute in minecraft:overworld run fill 358 69 39 358 70 39 dirt
execute in minecraft:overworld run setblock 358 71 39 grass_block
execute in minecraft:overworld run fill 358 72 39 358 144 39 air
execute in minecraft:overworld run fill 358 58 40 358 67 40 stone
execute in minecraft:overworld run fill 358 68 40 358 69 40 dirt
execute in minecraft:overworld run setblock 358 70 40 grass_block
execute in minecraft:overworld run fill 358 71 40 358 144 40 air
execute in minecraft:overworld run fill 358 58 41 358 66 41 stone
execute in minecraft:overworld run fill 358 67 41 358 68 41 dirt
execute in minecraft:overworld run setblock 358 69 41 grass_block
execute in minecraft:overworld run fill 358 70 41 358 144 41 air
execute in minecraft:overworld run fill 358 58 42 358 65 42 stone
execute in minecraft:overworld run fill 358 66 42 358 67 42 dirt
execute in minecraft:overworld run setblock 358 68 42 coarse_dirt
execute in minecraft:overworld run fill 358 69 42 358 144 42 air
execute in minecraft:overworld run fill 358 58 43 358 65 43 stone
execute in minecraft:overworld run fill 358 66 43 358 67 43 dirt
execute in minecraft:overworld run setblock 358 68 43 coarse_dirt
execute in minecraft:overworld run fill 358 69 43 358 144 43 air
execute in minecraft:overworld run fill 358 58 44 358 64 44 stone
execute in minecraft:overworld run fill 358 65 44 358 66 44 dirt
execute in minecraft:overworld run setblock 358 67 44 grass_block
execute in minecraft:overworld run fill 358 68 44 358 144 44 air
execute in minecraft:overworld run fill 358 58 45 358 63 45 stone
execute in minecraft:overworld run fill 358 64 45 358 65 45 dirt
execute in minecraft:overworld run setblock 358 66 45 coarse_dirt
execute in minecraft:overworld run fill 358 67 45 358 144 45 air
execute in minecraft:overworld run fill 358 58 46 358 62 46 stone
execute in minecraft:overworld run fill 358 63 46 358 64 46 dirt
execute in minecraft:overworld run setblock 358 65 46 grass_block
execute in minecraft:overworld run fill 358 66 46 358 144 46 air
execute in minecraft:overworld run fill 358 58 47 358 62 47 stone
execute in minecraft:overworld run fill 358 63 47 358 64 47 dirt
execute in minecraft:overworld run setblock 358 65 47 coarse_dirt
execute in minecraft:overworld run fill 358 66 47 358 144 47 air
execute in minecraft:overworld run fill 359 58 -48 359 61 -48 stone
execute in minecraft:overworld run fill 359 62 -48 359 63 -48 dirt
execute in minecraft:overworld run setblock 359 64 -48 coarse_dirt
execute in minecraft:overworld run fill 359 65 -48 359 144 -48 air
execute in minecraft:overworld run fill 359 58 -47 359 63 -47 stone
execute in minecraft:overworld run fill 359 64 -47 359 65 -47 dirt
execute in minecraft:overworld run setblock 359 66 -47 grass_block
execute in minecraft:overworld run fill 359 67 -47 359 144 -47 air
execute in minecraft:overworld run fill 359 58 -46 359 65 -46 stone
execute in minecraft:overworld run fill 359 66 -46 359 67 -46 dirt
execute in minecraft:overworld run setblock 359 68 -46 coarse_dirt
execute in minecraft:overworld run fill 359 69 -46 359 144 -46 air
execute in minecraft:overworld run fill 359 58 -45 359 66 -45 stone
execute in minecraft:overworld run fill 359 67 -45 359 68 -45 dirt
execute in minecraft:overworld run setblock 359 69 -45 grass_block
execute in minecraft:overworld run fill 359 70 -45 359 144 -45 air
execute in minecraft:overworld run fill 359 58 -44 359 68 -44 stone
execute in minecraft:overworld run fill 359 69 -44 359 70 -44 dirt
execute in minecraft:overworld run setblock 359 71 -44 coarse_dirt
execute in minecraft:overworld run fill 359 72 -44 359 144 -44 air
execute in minecraft:overworld run fill 359 58 -43 359 70 -43 stone
execute in minecraft:overworld run fill 359 71 -43 359 72 -43 dirt
execute in minecraft:overworld run setblock 359 73 -43 grass_block
execute in minecraft:overworld run fill 359 74 -43 359 144 -43 air
execute in minecraft:overworld run fill 359 58 -42 359 71 -42 stone
execute in minecraft:overworld run fill 359 72 -42 359 73 -42 dirt
execute in minecraft:overworld run setblock 359 74 -42 coarse_dirt
execute in minecraft:overworld run fill 359 75 -42 359 144 -42 air
execute in minecraft:overworld run fill 359 58 -41 359 72 -41 stone
execute in minecraft:overworld run fill 359 73 -41 359 74 -41 dirt
execute in minecraft:overworld run setblock 359 75 -41 coarse_dirt
execute in minecraft:overworld run fill 359 76 -41 359 144 -41 air
execute in minecraft:overworld run fill 359 58 -40 359 73 -40 stone
execute in minecraft:overworld run fill 359 74 -40 359 75 -40 dirt
execute in minecraft:overworld run setblock 359 76 -40 coarse_dirt
execute in minecraft:overworld run fill 359 77 -40 359 144 -40 air
execute in minecraft:overworld run fill 359 58 -39 359 74 -39 stone
execute in minecraft:overworld run fill 359 75 -39 359 76 -39 dirt
execute in minecraft:overworld run setblock 359 77 -39 coarse_dirt
execute in minecraft:overworld run fill 359 78 -39 359 144 -39 air
execute in minecraft:overworld run fill 359 58 -38 359 75 -38 stone
execute in minecraft:overworld run fill 359 76 -38 359 77 -38 dirt
execute in minecraft:overworld run setblock 359 78 -38 grass_block
execute in minecraft:overworld run fill 359 79 -38 359 144 -38 air
execute in minecraft:overworld run setblock 359 79 -38 grass
execute in minecraft:overworld run fill 359 58 -37 359 75 -37 stone
execute in minecraft:overworld run fill 359 76 -37 359 77 -37 dirt
execute in minecraft:overworld run setblock 359 78 -37 coarse_dirt
execute in minecraft:overworld run fill 359 79 -37 359 144 -37 air
execute in minecraft:overworld run setblock 359 79 -37 mossy_cobblestone
execute in minecraft:overworld run fill 359 58 -36 359 75 -36 stone
execute in minecraft:overworld run fill 359 76 -36 359 77 -36 dirt
execute in minecraft:overworld run setblock 359 78 -36 coarse_dirt
execute in minecraft:overworld run fill 359 79 -36 359 144 -36 air
execute in minecraft:overworld run fill 359 58 -35 359 74 -35 stone
execute in minecraft:overworld run fill 359 75 -35 359 76 -35 dirt
execute in minecraft:overworld run setblock 359 77 -35 grass_block
execute in minecraft:overworld run fill 359 78 -35 359 144 -35 air
execute in minecraft:overworld run fill 359 58 -34 359 74 -34 stone
execute in minecraft:overworld run fill 359 75 -34 359 76 -34 dirt
execute in minecraft:overworld run setblock 359 77 -34 coarse_dirt
execute in minecraft:overworld run fill 359 78 -34 359 144 -34 air
execute in minecraft:overworld run fill 359 58 -33 359 74 -33 stone
execute in minecraft:overworld run fill 359 75 -33 359 76 -33 dirt
execute in minecraft:overworld run setblock 359 77 -33 grass_block
execute in minecraft:overworld run fill 359 78 -33 359 144 -33 air
execute in minecraft:overworld run fill 359 58 -32 359 74 -32 stone
execute in minecraft:overworld run fill 359 75 -32 359 76 -32 dirt
execute in minecraft:overworld run setblock 359 77 -32 coarse_dirt
execute in minecraft:overworld run fill 359 78 -32 359 144 -32 air
execute in minecraft:overworld run fill 359 58 -31 359 74 -31 stone
execute in minecraft:overworld run fill 359 75 -31 359 76 -31 dirt
execute in minecraft:overworld run setblock 359 77 -31 coarse_dirt
execute in minecraft:overworld run fill 359 78 -31 359 144 -31 air
execute in minecraft:overworld run fill 359 58 -30 359 74 -30 stone
execute in minecraft:overworld run fill 359 75 -30 359 76 -30 dirt
execute in minecraft:overworld run setblock 359 77 -30 grass_block
execute in minecraft:overworld run fill 359 78 -30 359 144 -30 air
execute in minecraft:overworld run fill 359 58 -29 359 74 -29 stone
execute in minecraft:overworld run fill 359 75 -29 359 76 -29 dirt
execute in minecraft:overworld run setblock 359 77 -29 coarse_dirt
execute in minecraft:overworld run fill 359 78 -29 359 144 -29 air
execute in minecraft:overworld run fill 359 58 -28 359 73 -28 stone
execute in minecraft:overworld run fill 359 74 -28 359 75 -28 dirt
execute in minecraft:overworld run setblock 359 76 -28 coarse_dirt
execute in minecraft:overworld run fill 359 77 -28 359 144 -28 air
execute in minecraft:overworld run fill 359 58 -27 359 73 -27 stone
execute in minecraft:overworld run fill 359 74 -27 359 75 -27 dirt
execute in minecraft:overworld run setblock 359 76 -27 coarse_dirt
execute in minecraft:overworld run fill 359 77 -27 359 144 -27 air
execute in minecraft:overworld run fill 359 58 -26 359 73 -26 stone
execute in minecraft:overworld run fill 359 74 -26 359 75 -26 dirt
execute in minecraft:overworld run setblock 359 76 -26 coarse_dirt
execute in minecraft:overworld run fill 359 77 -26 359 144 -26 air
execute in minecraft:overworld run fill 359 58 -25 359 72 -25 stone
execute in minecraft:overworld run fill 359 73 -25 359 74 -25 dirt
execute in minecraft:overworld run setblock 359 75 -25 coarse_dirt
execute in minecraft:overworld run fill 359 76 -25 359 144 -25 air
execute in minecraft:overworld run fill 359 58 -24 359 72 -24 stone
execute in minecraft:overworld run fill 359 73 -24 359 74 -24 dirt
execute in minecraft:overworld run setblock 359 75 -24 grass_block
execute in minecraft:overworld run fill 359 76 -24 359 144 -24 air
execute in minecraft:overworld run fill 359 58 -23 359 72 -23 stone
execute in minecraft:overworld run fill 359 73 -23 359 74 -23 dirt
execute in minecraft:overworld run setblock 359 75 -23 coarse_dirt
execute in minecraft:overworld run fill 359 76 -23 359 144 -23 air
execute in minecraft:overworld run setblock 359 76 -23 grass
execute in minecraft:overworld run fill 359 58 -22 359 72 -22 stone
execute in minecraft:overworld run fill 359 73 -22 359 74 -22 dirt
execute in minecraft:overworld run setblock 359 75 -22 coarse_dirt
execute in minecraft:overworld run fill 359 76 -22 359 144 -22 air
execute in minecraft:overworld run fill 359 58 -21 359 71 -21 stone
execute in minecraft:overworld run fill 359 72 -21 359 73 -21 dirt
execute in minecraft:overworld run setblock 359 74 -21 coarse_dirt
execute in minecraft:overworld run fill 359 75 -21 359 144 -21 air
execute in minecraft:overworld run fill 359 58 -20 359 71 -20 stone
execute in minecraft:overworld run fill 359 72 -20 359 73 -20 dirt
execute in minecraft:overworld run setblock 359 74 -20 coarse_dirt
execute in minecraft:overworld run fill 359 75 -20 359 144 -20 air
execute in minecraft:overworld run fill 359 58 -19 359 71 -19 stone
execute in minecraft:overworld run fill 359 72 -19 359 73 -19 dirt
execute in minecraft:overworld run setblock 359 74 -19 coarse_dirt
execute in minecraft:overworld run fill 359 75 -19 359 144 -19 air
execute in minecraft:overworld run fill 359 58 -18 359 70 -18 stone
execute in minecraft:overworld run fill 359 71 -18 359 72 -18 dirt
execute in minecraft:overworld run setblock 359 73 -18 coarse_dirt
execute in minecraft:overworld run fill 359 74 -18 359 144 -18 air
execute in minecraft:overworld run setblock 359 74 -18 grass
execute in minecraft:overworld run fill 359 58 -17 359 70 -17 stone
execute in minecraft:overworld run fill 359 71 -17 359 72 -17 dirt
execute in minecraft:overworld run setblock 359 73 -17 coarse_dirt
execute in minecraft:overworld run fill 359 74 -17 359 144 -17 air
execute in minecraft:overworld run setblock 359 74 -17 grass
execute in minecraft:overworld run fill 359 58 -16 359 69 -16 stone
execute in minecraft:overworld run fill 359 70 -16 359 71 -16 dirt
execute in minecraft:overworld run setblock 359 72 -16 coarse_dirt
execute in minecraft:overworld run fill 359 73 -16 359 144 -16 air
execute in minecraft:overworld run fill 359 58 -15 359 68 -15 stone
execute in minecraft:overworld run fill 359 69 -15 359 70 -15 dirt
execute in minecraft:overworld run setblock 359 71 -15 coarse_dirt
execute in minecraft:overworld run fill 359 72 -15 359 144 -15 air
execute in minecraft:overworld run setblock 359 72 -15 mossy_cobblestone
execute in minecraft:overworld run fill 359 58 -14 359 68 -14 stone
execute in minecraft:overworld run fill 359 69 -14 359 70 -14 dirt
execute in minecraft:overworld run setblock 359 71 -14 grass_block
execute in minecraft:overworld run fill 359 72 -14 359 144 -14 air
execute in minecraft:overworld run fill 359 58 -13 359 67 -13 stone
execute in minecraft:overworld run fill 359 68 -13 359 69 -13 dirt
execute in minecraft:overworld run setblock 359 70 -13 grass_block
execute in minecraft:overworld run fill 359 71 -13 359 144 -13 air
execute in minecraft:overworld run fill 359 58 -12 359 66 -12 stone
execute in minecraft:overworld run fill 359 67 -12 359 68 -12 dirt
execute in minecraft:overworld run setblock 359 69 -12 grass_block
execute in minecraft:overworld run fill 359 70 -12 359 144 -12 air
execute in minecraft:overworld run fill 359 58 -11 359 66 -11 stone
execute in minecraft:overworld run fill 359 67 -11 359 68 -11 dirt
execute in minecraft:overworld run setblock 359 69 -11 coarse_dirt
execute in minecraft:overworld run fill 359 70 -11 359 144 -11 air
execute in minecraft:overworld run setblock 359 70 -11 grass
execute in minecraft:overworld run fill 359 58 -10 359 65 -10 stone
execute in minecraft:overworld run fill 359 66 -10 359 67 -10 dirt
execute in minecraft:overworld run setblock 359 68 -10 grass_block
execute in minecraft:overworld run fill 359 69 -10 359 144 -10 air
execute in minecraft:overworld run fill 359 58 -9 359 65 -9 stone
execute in minecraft:overworld run fill 359 66 -9 359 67 -9 dirt
execute in minecraft:overworld run setblock 359 68 -9 coarse_dirt
execute in minecraft:overworld run fill 359 69 -9 359 144 -9 air
execute in minecraft:overworld run setblock 359 69 -9 grass
execute in minecraft:overworld run fill 359 58 -8 359 65 -8 stone
execute in minecraft:overworld run fill 359 66 -8 359 67 -8 dirt
execute in minecraft:overworld run setblock 359 68 -8 coarse_dirt
execute in minecraft:overworld run fill 359 69 -8 359 144 -8 air
execute in minecraft:overworld run fill 359 58 -7 359 65 -7 stone
execute in minecraft:overworld run fill 359 66 -7 359 67 -7 dirt
execute in minecraft:overworld run setblock 359 68 -7 coarse_dirt
execute in minecraft:overworld run fill 359 69 -7 359 144 -7 air
execute in minecraft:overworld run fill 359 58 -6 359 65 -6 stone
execute in minecraft:overworld run fill 359 66 -6 359 67 -6 dirt
execute in minecraft:overworld run setblock 359 68 -6 coarse_dirt
execute in minecraft:overworld run fill 359 69 -6 359 144 -6 air
execute in minecraft:overworld run fill 359 58 -5 359 65 -5 stone
execute in minecraft:overworld run fill 359 66 -5 359 67 -5 dirt
execute in minecraft:overworld run setblock 359 68 -5 coarse_dirt
execute in minecraft:overworld run fill 359 69 -5 359 144 -5 air
execute in minecraft:overworld run setblock 359 69 -5 grass
execute in minecraft:overworld run fill 359 58 -4 359 65 -4 stone
execute in minecraft:overworld run fill 359 66 -4 359 67 -4 dirt
execute in minecraft:overworld run setblock 359 68 -4 grass_block
execute in minecraft:overworld run fill 359 69 -4 359 144 -4 air
execute in minecraft:overworld run fill 359 58 -3 359 65 -3 stone
execute in minecraft:overworld run fill 359 66 -3 359 67 -3 dirt
execute in minecraft:overworld run setblock 359 68 -3 coarse_dirt
execute in minecraft:overworld run fill 359 69 -3 359 144 -3 air
execute in minecraft:overworld run fill 359 58 -2 359 65 -2 stone
execute in minecraft:overworld run fill 359 66 -2 359 67 -2 dirt
execute in minecraft:overworld run setblock 359 68 -2 coarse_dirt
execute in minecraft:overworld run fill 359 69 -2 359 144 -2 air
execute in minecraft:overworld run fill 359 58 -1 359 65 -1 stone
execute in minecraft:overworld run fill 359 66 -1 359 67 -1 dirt
execute in minecraft:overworld run setblock 359 68 -1 grass_block
execute in minecraft:overworld run fill 359 69 -1 359 144 -1 air
execute in minecraft:overworld run fill 359 58 0 359 65 0 stone
execute in minecraft:overworld run fill 359 66 0 359 67 0 dirt
execute in minecraft:overworld run setblock 359 68 0 coarse_dirt
execute in minecraft:overworld run fill 359 69 0 359 144 0 air
execute in minecraft:overworld run fill 359 58 1 359 65 1 stone
execute in minecraft:overworld run fill 359 66 1 359 67 1 dirt
execute in minecraft:overworld run setblock 359 68 1 coarse_dirt
execute in minecraft:overworld run fill 359 69 1 359 144 1 air
execute in minecraft:overworld run fill 359 58 2 359 66 2 stone
execute in minecraft:overworld run fill 359 67 2 359 68 2 dirt
execute in minecraft:overworld run setblock 359 69 2 coarse_dirt
execute in minecraft:overworld run fill 359 70 2 359 144 2 air
execute in minecraft:overworld run fill 359 58 3 359 66 3 stone
execute in minecraft:overworld run fill 359 67 3 359 68 3 dirt
execute in minecraft:overworld run setblock 359 69 3 coarse_dirt
execute in minecraft:overworld run fill 359 70 3 359 144 3 air
execute in minecraft:overworld run fill 359 58 4 359 66 4 stone
execute in minecraft:overworld run fill 359 67 4 359 68 4 dirt
execute in minecraft:overworld run setblock 359 69 4 coarse_dirt
schedule function blade_gallery:random/battlefield/part_36 1t replace
