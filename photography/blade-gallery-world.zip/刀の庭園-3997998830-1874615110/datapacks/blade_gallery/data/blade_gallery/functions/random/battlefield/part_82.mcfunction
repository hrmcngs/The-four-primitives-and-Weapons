execute in minecraft:overworld run fill 388 58 47 388 61 47 stone
execute in minecraft:overworld run fill 388 62 47 388 63 47 dirt
execute in minecraft:overworld run setblock 388 64 47 coarse_dirt
execute in minecraft:overworld run fill 388 65 47 388 144 47 air
execute in minecraft:overworld run fill 389 58 -48 389 61 -48 stone
execute in minecraft:overworld run fill 389 62 -48 389 63 -48 dirt
execute in minecraft:overworld run setblock 389 64 -48 grass_block
execute in minecraft:overworld run fill 389 65 -48 389 144 -48 air
execute in minecraft:overworld run fill 389 58 -47 389 62 -47 stone
execute in minecraft:overworld run fill 389 63 -47 389 64 -47 dirt
execute in minecraft:overworld run setblock 389 65 -47 coarse_dirt
execute in minecraft:overworld run fill 389 66 -47 389 144 -47 air
execute in minecraft:overworld run fill 389 58 -46 389 64 -46 stone
execute in minecraft:overworld run fill 389 65 -46 389 66 -46 dirt
execute in minecraft:overworld run setblock 389 67 -46 coarse_dirt
execute in minecraft:overworld run fill 389 68 -46 389 144 -46 air
execute in minecraft:overworld run fill 389 58 -45 389 65 -45 stone
execute in minecraft:overworld run fill 389 66 -45 389 67 -45 dirt
execute in minecraft:overworld run setblock 389 68 -45 coarse_dirt
execute in minecraft:overworld run fill 389 69 -45 389 144 -45 air
execute in minecraft:overworld run fill 389 58 -44 389 67 -44 stone
execute in minecraft:overworld run fill 389 68 -44 389 69 -44 dirt
execute in minecraft:overworld run setblock 389 70 -44 coarse_dirt
execute in minecraft:overworld run fill 389 71 -44 389 144 -44 air
execute in minecraft:overworld run fill 389 58 -43 389 68 -43 stone
execute in minecraft:overworld run fill 389 69 -43 389 70 -43 dirt
execute in minecraft:overworld run setblock 389 71 -43 coarse_dirt
execute in minecraft:overworld run fill 389 72 -43 389 144 -43 air
execute in minecraft:overworld run fill 389 58 -42 389 69 -42 stone
execute in minecraft:overworld run fill 389 70 -42 389 71 -42 dirt
execute in minecraft:overworld run setblock 389 72 -42 grass_block
execute in minecraft:overworld run fill 389 73 -42 389 144 -42 air
execute in minecraft:overworld run fill 389 58 -41 389 71 -41 stone
execute in minecraft:overworld run fill 389 72 -41 389 73 -41 dirt
execute in minecraft:overworld run setblock 389 74 -41 grass_block
execute in minecraft:overworld run fill 389 75 -41 389 144 -41 air
execute in minecraft:overworld run fill 389 58 -40 389 72 -40 stone
execute in minecraft:overworld run fill 389 73 -40 389 74 -40 dirt
execute in minecraft:overworld run setblock 389 75 -40 coarse_dirt
execute in minecraft:overworld run fill 389 76 -40 389 144 -40 air
execute in minecraft:overworld run fill 389 58 -39 389 73 -39 stone
execute in minecraft:overworld run fill 389 74 -39 389 75 -39 dirt
execute in minecraft:overworld run setblock 389 76 -39 grass_block
execute in minecraft:overworld run fill 389 77 -39 389 144 -39 air
execute in minecraft:overworld run fill 389 58 -38 389 73 -38 stone
execute in minecraft:overworld run fill 389 74 -38 389 75 -38 dirt
execute in minecraft:overworld run setblock 389 76 -38 grass_block
execute in minecraft:overworld run fill 389 77 -38 389 144 -38 air
execute in minecraft:overworld run setblock 389 77 -38 grass
execute in minecraft:overworld run fill 389 58 -37 389 73 -37 stone
execute in minecraft:overworld run fill 389 74 -37 389 75 -37 dirt
execute in minecraft:overworld run setblock 389 76 -37 coarse_dirt
execute in minecraft:overworld run fill 389 77 -37 389 144 -37 air
execute in minecraft:overworld run setblock 389 77 -37 grass
execute in minecraft:overworld run fill 389 58 -36 389 73 -36 stone
execute in minecraft:overworld run fill 389 74 -36 389 75 -36 dirt
execute in minecraft:overworld run setblock 389 76 -36 grass_block
execute in minecraft:overworld run fill 389 77 -36 389 144 -36 air
execute in minecraft:overworld run fill 389 58 -35 389 72 -35 stone
execute in minecraft:overworld run fill 389 73 -35 389 74 -35 dirt
execute in minecraft:overworld run setblock 389 75 -35 grass_block
execute in minecraft:overworld run fill 389 76 -35 389 144 -35 air
execute in minecraft:overworld run fill 389 58 -34 389 72 -34 stone
execute in minecraft:overworld run fill 389 73 -34 389 74 -34 dirt
execute in minecraft:overworld run setblock 389 75 -34 coarse_dirt
execute in minecraft:overworld run fill 389 76 -34 389 144 -34 air
execute in minecraft:overworld run fill 389 58 -33 389 72 -33 stone
execute in minecraft:overworld run fill 389 73 -33 389 74 -33 dirt
execute in minecraft:overworld run setblock 389 75 -33 coarse_dirt
execute in minecraft:overworld run fill 389 76 -33 389 144 -33 air
execute in minecraft:overworld run fill 389 58 -32 389 72 -32 stone
execute in minecraft:overworld run fill 389 73 -32 389 74 -32 dirt
execute in minecraft:overworld run setblock 389 75 -32 grass_block
execute in minecraft:overworld run fill 389 76 -32 389 144 -32 air
execute in minecraft:overworld run fill 389 58 -31 389 71 -31 stone
execute in minecraft:overworld run fill 389 72 -31 389 73 -31 dirt
execute in minecraft:overworld run setblock 389 74 -31 coarse_dirt
execute in minecraft:overworld run fill 389 75 -31 389 144 -31 air
execute in minecraft:overworld run fill 389 58 -30 389 71 -30 stone
execute in minecraft:overworld run fill 389 72 -30 389 73 -30 dirt
execute in minecraft:overworld run setblock 389 74 -30 grass_block
execute in minecraft:overworld run fill 389 75 -30 389 144 -30 air
execute in minecraft:overworld run setblock 389 75 -30 grass
execute in minecraft:overworld run fill 389 58 -29 389 70 -29 stone
execute in minecraft:overworld run fill 389 71 -29 389 72 -29 dirt
execute in minecraft:overworld run setblock 389 73 -29 coarse_dirt
execute in minecraft:overworld run fill 389 74 -29 389 144 -29 air
execute in minecraft:overworld run fill 389 58 -28 389 70 -28 stone
execute in minecraft:overworld run fill 389 71 -28 389 72 -28 dirt
execute in minecraft:overworld run setblock 389 73 -28 grass_block
execute in minecraft:overworld run fill 389 74 -28 389 144 -28 air
execute in minecraft:overworld run fill 389 58 -27 389 69 -27 stone
execute in minecraft:overworld run fill 389 70 -27 389 71 -27 dirt
execute in minecraft:overworld run setblock 389 72 -27 coarse_dirt
execute in minecraft:overworld run fill 389 73 -27 389 144 -27 air
execute in minecraft:overworld run fill 389 58 -26 389 68 -26 stone
execute in minecraft:overworld run fill 389 69 -26 389 70 -26 dirt
execute in minecraft:overworld run setblock 389 71 -26 grass_block
execute in minecraft:overworld run fill 389 72 -26 389 144 -26 air
execute in minecraft:overworld run fill 389 58 -25 389 67 -25 stone
execute in minecraft:overworld run fill 389 68 -25 389 69 -25 dirt
execute in minecraft:overworld run setblock 389 70 -25 coarse_dirt
execute in minecraft:overworld run fill 389 71 -25 389 144 -25 air
execute in minecraft:overworld run fill 389 58 -24 389 66 -24 stone
execute in minecraft:overworld run fill 389 67 -24 389 68 -24 dirt
execute in minecraft:overworld run setblock 389 69 -24 coarse_dirt
execute in minecraft:overworld run fill 389 70 -24 389 144 -24 air
execute in minecraft:overworld run fill 389 58 -23 389 65 -23 stone
execute in minecraft:overworld run fill 389 66 -23 389 67 -23 dirt
execute in minecraft:overworld run setblock 389 68 -23 coarse_dirt
execute in minecraft:overworld run fill 389 69 -23 389 144 -23 air
execute in minecraft:overworld run fill 389 58 -22 389 64 -22 stone
execute in minecraft:overworld run fill 389 65 -22 389 66 -22 dirt
execute in minecraft:overworld run setblock 389 67 -22 coarse_dirt
execute in minecraft:overworld run fill 389 68 -22 389 144 -22 air
execute in minecraft:overworld run fill 389 58 -21 389 62 -21 stone
execute in minecraft:overworld run fill 389 63 -21 389 64 -21 dirt
execute in minecraft:overworld run setblock 389 65 -21 coarse_dirt
execute in minecraft:overworld run fill 389 66 -21 389 144 -21 air
execute in minecraft:overworld run fill 389 58 -20 389 61 -20 stone
execute in minecraft:overworld run fill 389 62 -20 389 63 -20 dirt
execute in minecraft:overworld run setblock 389 64 -20 coarse_dirt
execute in minecraft:overworld run fill 389 65 -20 389 144 -20 air
execute in minecraft:overworld run fill 389 58 -19 389 60 -19 stone
execute in minecraft:overworld run fill 389 61 -19 389 62 -19 dirt
execute in minecraft:overworld run setblock 389 63 -19 gravel
execute in minecraft:overworld run fill 389 64 -19 389 144 -19 air
execute in minecraft:overworld run fill 389 64 -19 389 64 -19 water
execute in minecraft:overworld run fill 389 58 -18 389 59 -18 stone
execute in minecraft:overworld run fill 389 60 -18 389 61 -18 dirt
execute in minecraft:overworld run setblock 389 62 -18 gravel
execute in minecraft:overworld run fill 389 63 -18 389 144 -18 air
execute in minecraft:overworld run fill 389 63 -18 389 64 -18 water
execute in minecraft:overworld run fill 389 58 -17 389 59 -17 stone
execute in minecraft:overworld run fill 389 60 -17 389 61 -17 dirt
execute in minecraft:overworld run setblock 389 62 -17 gravel
execute in minecraft:overworld run fill 389 63 -17 389 144 -17 air
execute in minecraft:overworld run fill 389 63 -17 389 64 -17 water
execute in minecraft:overworld run fill 389 58 -16 389 58 -16 stone
execute in minecraft:overworld run fill 389 59 -16 389 60 -16 dirt
execute in minecraft:overworld run setblock 389 61 -16 gravel
execute in minecraft:overworld run fill 389 62 -16 389 144 -16 air
execute in minecraft:overworld run fill 389 62 -16 389 64 -16 water
execute in minecraft:overworld run fill 389 58 -15 389 57 -15 stone
execute in minecraft:overworld run fill 389 58 -15 389 59 -15 dirt
execute in minecraft:overworld run setblock 389 60 -15 gravel
execute in minecraft:overworld run fill 389 61 -15 389 144 -15 air
execute in minecraft:overworld run fill 389 61 -15 389 64 -15 water
execute in minecraft:overworld run fill 389 58 -14 389 56 -14 stone
execute in minecraft:overworld run fill 389 57 -14 389 58 -14 dirt
execute in minecraft:overworld run setblock 389 59 -14 gravel
execute in minecraft:overworld run fill 389 60 -14 389 144 -14 air
execute in minecraft:overworld run fill 389 60 -14 389 64 -14 water
execute in minecraft:overworld run fill 389 58 -13 389 56 -13 stone
execute in minecraft:overworld run fill 389 57 -13 389 58 -13 dirt
execute in minecraft:overworld run setblock 389 59 -13 gravel
execute in minecraft:overworld run fill 389 60 -13 389 144 -13 air
execute in minecraft:overworld run fill 389 60 -13 389 64 -13 water
execute in minecraft:overworld run fill 389 58 -12 389 55 -12 stone
execute in minecraft:overworld run fill 389 56 -12 389 57 -12 dirt
execute in minecraft:overworld run setblock 389 58 -12 gravel
execute in minecraft:overworld run fill 389 59 -12 389 144 -12 air
execute in minecraft:overworld run fill 389 59 -12 389 64 -12 water
execute in minecraft:overworld run fill 389 58 -11 389 55 -11 stone
execute in minecraft:overworld run fill 389 56 -11 389 57 -11 dirt
execute in minecraft:overworld run setblock 389 58 -11 gravel
execute in minecraft:overworld run fill 389 59 -11 389 144 -11 air
execute in minecraft:overworld run fill 389 59 -11 389 64 -11 water
execute in minecraft:overworld run fill 389 58 -10 389 55 -10 stone
execute in minecraft:overworld run fill 389 56 -10 389 57 -10 dirt
execute in minecraft:overworld run setblock 389 58 -10 gravel
execute in minecraft:overworld run fill 389 59 -10 389 144 -10 air
execute in minecraft:overworld run fill 389 59 -10 389 64 -10 water
execute in minecraft:overworld run fill 389 58 -9 389 55 -9 stone
execute in minecraft:overworld run fill 389 56 -9 389 57 -9 dirt
execute in minecraft:overworld run setblock 389 58 -9 gravel
execute in minecraft:overworld run fill 389 59 -9 389 144 -9 air
execute in minecraft:overworld run fill 389 59 -9 389 64 -9 water
execute in minecraft:overworld run fill 389 58 -8 389 55 -8 stone
execute in minecraft:overworld run fill 389 56 -8 389 57 -8 dirt
execute in minecraft:overworld run setblock 389 58 -8 gravel
execute in minecraft:overworld run fill 389 59 -8 389 144 -8 air
execute in minecraft:overworld run fill 389 59 -8 389 64 -8 water
execute in minecraft:overworld run fill 389 58 -7 389 55 -7 stone
execute in minecraft:overworld run fill 389 56 -7 389 57 -7 dirt
execute in minecraft:overworld run setblock 389 58 -7 gravel
execute in minecraft:overworld run fill 389 59 -7 389 144 -7 air
execute in minecraft:overworld run fill 389 59 -7 389 64 -7 water
execute in minecraft:overworld run fill 389 58 -6 389 55 -6 stone
execute in minecraft:overworld run fill 389 56 -6 389 57 -6 dirt
execute in minecraft:overworld run setblock 389 58 -6 gravel
execute in minecraft:overworld run fill 389 59 -6 389 144 -6 air
execute in minecraft:overworld run fill 389 59 -6 389 64 -6 water
execute in minecraft:overworld run fill 389 58 -5 389 56 -5 stone
execute in minecraft:overworld run fill 389 57 -5 389 58 -5 dirt
execute in minecraft:overworld run setblock 389 59 -5 gravel
execute in minecraft:overworld run fill 389 60 -5 389 144 -5 air
execute in minecraft:overworld run fill 389 60 -5 389 64 -5 water
execute in minecraft:overworld run fill 389 58 -4 389 56 -4 stone
execute in minecraft:overworld run fill 389 57 -4 389 58 -4 dirt
execute in minecraft:overworld run setblock 389 59 -4 gravel
execute in minecraft:overworld run fill 389 60 -4 389 144 -4 air
execute in minecraft:overworld run fill 389 60 -4 389 64 -4 water
execute in minecraft:overworld run fill 389 58 -3 389 56 -3 stone
execute in minecraft:overworld run fill 389 57 -3 389 58 -3 dirt
execute in minecraft:overworld run setblock 389 59 -3 gravel
execute in minecraft:overworld run fill 389 60 -3 389 144 -3 air
execute in minecraft:overworld run fill 389 60 -3 389 64 -3 water
execute in minecraft:overworld run fill 389 58 -2 389 56 -2 stone
execute in minecraft:overworld run fill 389 57 -2 389 58 -2 dirt
execute in minecraft:overworld run setblock 389 59 -2 gravel
execute in minecraft:overworld run fill 389 60 -2 389 144 -2 air
execute in minecraft:overworld run fill 389 60 -2 389 64 -2 water
execute in minecraft:overworld run fill 389 58 -1 389 57 -1 stone
execute in minecraft:overworld run fill 389 58 -1 389 59 -1 dirt
execute in minecraft:overworld run setblock 389 60 -1 gravel
execute in minecraft:overworld run fill 389 61 -1 389 144 -1 air
execute in minecraft:overworld run fill 389 61 -1 389 64 -1 water
execute in minecraft:overworld run fill 389 58 0 389 57 0 stone
execute in minecraft:overworld run fill 389 58 0 389 59 0 dirt
execute in minecraft:overworld run setblock 389 60 0 gravel
execute in minecraft:overworld run fill 389 61 0 389 144 0 air
execute in minecraft:overworld run fill 389 61 0 389 64 0 water
execute in minecraft:overworld run fill 389 58 1 389 57 1 stone
execute in minecraft:overworld run fill 389 58 1 389 59 1 dirt
execute in minecraft:overworld run setblock 389 60 1 gravel
execute in minecraft:overworld run fill 389 61 1 389 144 1 air
execute in minecraft:overworld run fill 389 61 1 389 64 1 water
execute in minecraft:overworld run fill 389 58 2 389 57 2 stone
execute in minecraft:overworld run fill 389 58 2 389 59 2 dirt
execute in minecraft:overworld run setblock 389 60 2 gravel
execute in minecraft:overworld run fill 389 61 2 389 144 2 air
execute in minecraft:overworld run fill 389 61 2 389 64 2 water
execute in minecraft:overworld run fill 389 58 3 389 57 3 stone
execute in minecraft:overworld run fill 389 58 3 389 59 3 dirt
execute in minecraft:overworld run setblock 389 60 3 gravel
execute in minecraft:overworld run fill 389 61 3 389 144 3 air
execute in minecraft:overworld run fill 389 61 3 389 64 3 water
execute in minecraft:overworld run fill 389 58 4 389 58 4 stone
execute in minecraft:overworld run fill 389 59 4 389 60 4 dirt
execute in minecraft:overworld run setblock 389 61 4 gravel
execute in minecraft:overworld run fill 389 62 4 389 144 4 air
execute in minecraft:overworld run fill 389 62 4 389 64 4 water
execute in minecraft:overworld run fill 389 58 5 389 58 5 stone
execute in minecraft:overworld run fill 389 59 5 389 60 5 dirt
execute in minecraft:overworld run setblock 389 61 5 gravel
execute in minecraft:overworld run fill 389 62 5 389 144 5 air
execute in minecraft:overworld run fill 389 62 5 389 64 5 water
execute in minecraft:overworld run fill 389 58 6 389 58 6 stone
execute in minecraft:overworld run fill 389 59 6 389 60 6 dirt
execute in minecraft:overworld run setblock 389 61 6 gravel
execute in minecraft:overworld run fill 389 62 6 389 144 6 air
execute in minecraft:overworld run fill 389 62 6 389 64 6 water
execute in minecraft:overworld run fill 389 58 7 389 58 7 stone
execute in minecraft:overworld run fill 389 59 7 389 60 7 dirt
execute in minecraft:overworld run setblock 389 61 7 gravel
schedule function blade_gallery:random/battlefield/part_83 1t replace
