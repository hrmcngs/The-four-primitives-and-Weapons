execute in minecraft:overworld run fill 294 78 -31 294 79 -31 dirt
execute in minecraft:overworld run setblock 294 80 -31 coarse_dirt
execute in minecraft:overworld run fill 294 81 -31 294 144 -31 air
execute in minecraft:overworld run setblock 294 81 -31 grass
execute in minecraft:overworld run fill 294 58 -30 294 76 -30 stone
execute in minecraft:overworld run fill 294 77 -30 294 78 -30 dirt
execute in minecraft:overworld run setblock 294 79 -30 coarse_dirt
execute in minecraft:overworld run fill 294 80 -30 294 144 -30 air
execute in minecraft:overworld run fill 294 58 -29 294 76 -29 stone
execute in minecraft:overworld run fill 294 77 -29 294 78 -29 dirt
execute in minecraft:overworld run setblock 294 79 -29 coarse_dirt
execute in minecraft:overworld run fill 294 80 -29 294 144 -29 air
execute in minecraft:overworld run fill 294 58 -28 294 75 -28 stone
execute in minecraft:overworld run fill 294 76 -28 294 77 -28 dirt
execute in minecraft:overworld run setblock 294 78 -28 coarse_dirt
execute in minecraft:overworld run fill 294 79 -28 294 144 -28 air
execute in minecraft:overworld run setblock 294 79 -28 grass
execute in minecraft:overworld run fill 294 58 -27 294 75 -27 stone
execute in minecraft:overworld run fill 294 76 -27 294 77 -27 dirt
execute in minecraft:overworld run setblock 294 78 -27 coarse_dirt
execute in minecraft:overworld run fill 294 79 -27 294 144 -27 air
execute in minecraft:overworld run fill 294 58 -26 294 74 -26 stone
execute in minecraft:overworld run fill 294 75 -26 294 76 -26 dirt
execute in minecraft:overworld run setblock 294 77 -26 grass_block
execute in minecraft:overworld run fill 294 78 -26 294 144 -26 air
execute in minecraft:overworld run fill 294 58 -25 294 74 -25 stone
execute in minecraft:overworld run fill 294 75 -25 294 76 -25 dirt
execute in minecraft:overworld run setblock 294 77 -25 coarse_dirt
execute in minecraft:overworld run fill 294 78 -25 294 144 -25 air
execute in minecraft:overworld run fill 294 58 -24 294 74 -24 stone
execute in minecraft:overworld run fill 294 75 -24 294 76 -24 dirt
execute in minecraft:overworld run setblock 294 77 -24 coarse_dirt
execute in minecraft:overworld run fill 294 78 -24 294 144 -24 air
execute in minecraft:overworld run fill 294 58 -23 294 73 -23 stone
execute in minecraft:overworld run fill 294 74 -23 294 75 -23 dirt
execute in minecraft:overworld run setblock 294 76 -23 coarse_dirt
execute in minecraft:overworld run fill 294 77 -23 294 144 -23 air
execute in minecraft:overworld run fill 294 58 -22 294 72 -22 stone
execute in minecraft:overworld run fill 294 73 -22 294 74 -22 dirt
execute in minecraft:overworld run setblock 294 75 -22 coarse_dirt
execute in minecraft:overworld run fill 294 76 -22 294 144 -22 air
execute in minecraft:overworld run fill 294 58 -21 294 72 -21 stone
execute in minecraft:overworld run fill 294 73 -21 294 74 -21 dirt
execute in minecraft:overworld run setblock 294 75 -21 coarse_dirt
execute in minecraft:overworld run fill 294 76 -21 294 144 -21 air
execute in minecraft:overworld run fill 294 58 -20 294 71 -20 stone
execute in minecraft:overworld run fill 294 72 -20 294 73 -20 dirt
execute in minecraft:overworld run setblock 294 74 -20 coarse_dirt
execute in minecraft:overworld run fill 294 75 -20 294 144 -20 air
execute in minecraft:overworld run setblock 294 75 -20 grass
execute in minecraft:overworld run fill 294 58 -19 294 71 -19 stone
execute in minecraft:overworld run fill 294 72 -19 294 73 -19 dirt
execute in minecraft:overworld run setblock 294 74 -19 grass_block
execute in minecraft:overworld run fill 294 75 -19 294 144 -19 air
execute in minecraft:overworld run setblock 294 75 -19 grass
execute in minecraft:overworld run fill 294 58 -18 294 71 -18 stone
execute in minecraft:overworld run fill 294 72 -18 294 73 -18 dirt
execute in minecraft:overworld run setblock 294 74 -18 coarse_dirt
execute in minecraft:overworld run fill 294 75 -18 294 144 -18 air
execute in minecraft:overworld run fill 294 58 -17 294 70 -17 stone
execute in minecraft:overworld run fill 294 71 -17 294 72 -17 dirt
execute in minecraft:overworld run setblock 294 73 -17 coarse_dirt
execute in minecraft:overworld run fill 294 74 -17 294 144 -17 air
execute in minecraft:overworld run setblock 294 74 -17 grass
execute in minecraft:overworld run fill 294 58 -16 294 70 -16 stone
execute in minecraft:overworld run fill 294 71 -16 294 72 -16 dirt
execute in minecraft:overworld run setblock 294 73 -16 grass_block
execute in minecraft:overworld run fill 294 74 -16 294 144 -16 air
execute in minecraft:overworld run fill 294 58 -15 294 69 -15 stone
execute in minecraft:overworld run fill 294 70 -15 294 71 -15 dirt
execute in minecraft:overworld run setblock 294 72 -15 coarse_dirt
execute in minecraft:overworld run fill 294 73 -15 294 144 -15 air
execute in minecraft:overworld run fill 294 58 -14 294 69 -14 stone
execute in minecraft:overworld run fill 294 70 -14 294 71 -14 dirt
execute in minecraft:overworld run setblock 294 72 -14 grass_block
execute in minecraft:overworld run fill 294 73 -14 294 144 -14 air
execute in minecraft:overworld run fill 294 58 -13 294 69 -13 stone
execute in minecraft:overworld run fill 294 70 -13 294 71 -13 dirt
execute in minecraft:overworld run setblock 294 72 -13 coarse_dirt
execute in minecraft:overworld run fill 294 73 -13 294 144 -13 air
execute in minecraft:overworld run fill 294 58 -12 294 68 -12 stone
execute in minecraft:overworld run fill 294 69 -12 294 70 -12 dirt
execute in minecraft:overworld run setblock 294 71 -12 coarse_dirt
execute in minecraft:overworld run fill 294 72 -12 294 144 -12 air
execute in minecraft:overworld run fill 294 58 -11 294 68 -11 stone
execute in minecraft:overworld run fill 294 69 -11 294 70 -11 dirt
execute in minecraft:overworld run setblock 294 71 -11 grass_block
execute in minecraft:overworld run fill 294 72 -11 294 144 -11 air
execute in minecraft:overworld run setblock 294 72 -11 mossy_cobblestone
execute in minecraft:overworld run fill 294 58 -10 294 68 -10 stone
execute in minecraft:overworld run fill 294 69 -10 294 70 -10 dirt
execute in minecraft:overworld run setblock 294 71 -10 coarse_dirt
execute in minecraft:overworld run fill 294 72 -10 294 144 -10 air
execute in minecraft:overworld run fill 294 58 -9 294 68 -9 stone
execute in minecraft:overworld run fill 294 69 -9 294 70 -9 dirt
execute in minecraft:overworld run setblock 294 71 -9 grass_block
execute in minecraft:overworld run fill 294 72 -9 294 144 -9 air
execute in minecraft:overworld run fill 294 58 -8 294 68 -8 stone
execute in minecraft:overworld run fill 294 69 -8 294 70 -8 dirt
execute in minecraft:overworld run setblock 294 71 -8 coarse_dirt
execute in minecraft:overworld run fill 294 72 -8 294 144 -8 air
execute in minecraft:overworld run setblock 294 72 -8 grass
execute in minecraft:overworld run fill 294 58 -7 294 68 -7 stone
execute in minecraft:overworld run fill 294 69 -7 294 70 -7 dirt
execute in minecraft:overworld run setblock 294 71 -7 coarse_dirt
execute in minecraft:overworld run fill 294 72 -7 294 144 -7 air
execute in minecraft:overworld run fill 294 58 -6 294 68 -6 stone
execute in minecraft:overworld run fill 294 69 -6 294 70 -6 dirt
execute in minecraft:overworld run setblock 294 71 -6 coarse_dirt
execute in minecraft:overworld run fill 294 72 -6 294 144 -6 air
execute in minecraft:overworld run fill 294 58 -5 294 69 -5 stone
execute in minecraft:overworld run fill 294 70 -5 294 71 -5 dirt
execute in minecraft:overworld run setblock 294 72 -5 grass_block
execute in minecraft:overworld run fill 294 73 -5 294 144 -5 air
execute in minecraft:overworld run fill 294 58 -4 294 69 -4 stone
execute in minecraft:overworld run fill 294 70 -4 294 71 -4 dirt
execute in minecraft:overworld run setblock 294 72 -4 grass_block
execute in minecraft:overworld run fill 294 73 -4 294 144 -4 air
execute in minecraft:overworld run fill 294 58 -3 294 69 -3 stone
execute in minecraft:overworld run fill 294 70 -3 294 71 -3 dirt
execute in minecraft:overworld run setblock 294 72 -3 coarse_dirt
execute in minecraft:overworld run fill 294 73 -3 294 144 -3 air
execute in minecraft:overworld run fill 294 58 -2 294 69 -2 stone
execute in minecraft:overworld run fill 294 70 -2 294 71 -2 dirt
execute in minecraft:overworld run setblock 294 72 -2 coarse_dirt
execute in minecraft:overworld run fill 294 73 -2 294 144 -2 air
execute in minecraft:overworld run fill 294 58 -1 294 69 -1 stone
execute in minecraft:overworld run fill 294 70 -1 294 71 -1 dirt
execute in minecraft:overworld run setblock 294 72 -1 coarse_dirt
execute in minecraft:overworld run fill 294 73 -1 294 144 -1 air
execute in minecraft:overworld run fill 294 58 0 294 69 0 stone
execute in minecraft:overworld run fill 294 70 0 294 71 0 dirt
execute in minecraft:overworld run setblock 294 72 0 grass_block
execute in minecraft:overworld run fill 294 73 0 294 144 0 air
execute in minecraft:overworld run fill 294 58 1 294 69 1 stone
execute in minecraft:overworld run fill 294 70 1 294 71 1 dirt
execute in minecraft:overworld run setblock 294 72 1 coarse_dirt
execute in minecraft:overworld run fill 294 73 1 294 144 1 air
execute in minecraft:overworld run fill 294 58 2 294 69 2 stone
execute in minecraft:overworld run fill 294 70 2 294 71 2 dirt
execute in minecraft:overworld run setblock 294 72 2 grass_block
execute in minecraft:overworld run fill 294 73 2 294 144 2 air
execute in minecraft:overworld run fill 294 58 3 294 69 3 stone
execute in minecraft:overworld run fill 294 70 3 294 71 3 dirt
execute in minecraft:overworld run setblock 294 72 3 grass_block
execute in minecraft:overworld run fill 294 73 3 294 144 3 air
execute in minecraft:overworld run fill 294 58 4 294 69 4 stone
execute in minecraft:overworld run fill 294 70 4 294 71 4 dirt
execute in minecraft:overworld run setblock 294 72 4 grass_block
execute in minecraft:overworld run fill 294 73 4 294 144 4 air
execute in minecraft:overworld run fill 294 58 5 294 68 5 stone
execute in minecraft:overworld run fill 294 69 5 294 70 5 dirt
execute in minecraft:overworld run setblock 294 71 5 coarse_dirt
execute in minecraft:overworld run fill 294 72 5 294 144 5 air
execute in minecraft:overworld run fill 294 58 6 294 68 6 stone
execute in minecraft:overworld run fill 294 69 6 294 70 6 dirt
execute in minecraft:overworld run setblock 294 71 6 coarse_dirt
execute in minecraft:overworld run fill 294 72 6 294 144 6 air
execute in minecraft:overworld run fill 294 58 7 294 67 7 stone
execute in minecraft:overworld run fill 294 68 7 294 69 7 dirt
execute in minecraft:overworld run setblock 294 70 7 coarse_dirt
execute in minecraft:overworld run fill 294 71 7 294 144 7 air
execute in minecraft:overworld run fill 294 58 8 294 67 8 stone
execute in minecraft:overworld run fill 294 68 8 294 69 8 dirt
execute in minecraft:overworld run setblock 294 70 8 grass_block
execute in minecraft:overworld run fill 294 71 8 294 144 8 air
execute in minecraft:overworld run fill 294 58 9 294 67 9 stone
execute in minecraft:overworld run fill 294 68 9 294 69 9 dirt
execute in minecraft:overworld run setblock 294 70 9 coarse_dirt
execute in minecraft:overworld run fill 294 71 9 294 144 9 air
execute in minecraft:overworld run setblock 294 71 9 mossy_cobblestone
execute in minecraft:overworld run fill 294 58 10 294 67 10 stone
execute in minecraft:overworld run fill 294 68 10 294 69 10 dirt
execute in minecraft:overworld run setblock 294 70 10 coarse_dirt
execute in minecraft:overworld run fill 294 71 10 294 144 10 air
execute in minecraft:overworld run fill 294 58 11 294 66 11 stone
execute in minecraft:overworld run fill 294 67 11 294 68 11 dirt
execute in minecraft:overworld run setblock 294 69 11 coarse_dirt
execute in minecraft:overworld run fill 294 70 11 294 144 11 air
execute in minecraft:overworld run fill 294 58 12 294 66 12 stone
execute in minecraft:overworld run fill 294 67 12 294 68 12 dirt
execute in minecraft:overworld run setblock 294 69 12 coarse_dirt
execute in minecraft:overworld run fill 294 70 12 294 144 12 air
execute in minecraft:overworld run fill 294 58 13 294 66 13 stone
execute in minecraft:overworld run fill 294 67 13 294 68 13 dirt
execute in minecraft:overworld run setblock 294 69 13 coarse_dirt
execute in minecraft:overworld run fill 294 70 13 294 144 13 air
execute in minecraft:overworld run fill 294 58 14 294 66 14 stone
execute in minecraft:overworld run fill 294 67 14 294 68 14 dirt
execute in minecraft:overworld run setblock 294 69 14 coarse_dirt
execute in minecraft:overworld run fill 294 70 14 294 144 14 air
execute in minecraft:overworld run fill 294 58 15 294 66 15 stone
execute in minecraft:overworld run fill 294 67 15 294 68 15 dirt
execute in minecraft:overworld run setblock 294 69 15 coarse_dirt
execute in minecraft:overworld run fill 294 70 15 294 144 15 air
execute in minecraft:overworld run setblock 294 70 15 mossy_cobblestone
execute in minecraft:overworld run fill 294 58 16 294 65 16 stone
execute in minecraft:overworld run fill 294 66 16 294 67 16 dirt
execute in minecraft:overworld run setblock 294 68 16 coarse_dirt
execute in minecraft:overworld run fill 294 69 16 294 144 16 air
execute in minecraft:overworld run fill 294 58 17 294 65 17 stone
execute in minecraft:overworld run fill 294 66 17 294 67 17 dirt
execute in minecraft:overworld run setblock 294 68 17 grass_block
execute in minecraft:overworld run fill 294 69 17 294 144 17 air
execute in minecraft:overworld run fill 294 58 18 294 65 18 stone
execute in minecraft:overworld run fill 294 66 18 294 67 18 dirt
execute in minecraft:overworld run setblock 294 68 18 coarse_dirt
execute in minecraft:overworld run fill 294 69 18 294 144 18 air
execute in minecraft:overworld run fill 294 58 19 294 65 19 stone
execute in minecraft:overworld run fill 294 66 19 294 67 19 dirt
execute in minecraft:overworld run setblock 294 68 19 coarse_dirt
execute in minecraft:overworld run fill 294 69 19 294 144 19 air
execute in minecraft:overworld run fill 294 58 20 294 65 20 stone
execute in minecraft:overworld run fill 294 66 20 294 67 20 dirt
execute in minecraft:overworld run setblock 294 68 20 grass_block
execute in minecraft:overworld run fill 294 69 20 294 144 20 air
execute in minecraft:overworld run fill 294 58 21 294 65 21 stone
execute in minecraft:overworld run fill 294 66 21 294 67 21 dirt
execute in minecraft:overworld run setblock 294 68 21 grass_block
execute in minecraft:overworld run fill 294 69 21 294 144 21 air
execute in minecraft:overworld run setblock 294 69 21 grass
execute in minecraft:overworld run fill 294 58 22 294 65 22 stone
execute in minecraft:overworld run fill 294 66 22 294 67 22 dirt
execute in minecraft:overworld run setblock 294 68 22 coarse_dirt
execute in minecraft:overworld run fill 294 69 22 294 144 22 air
execute in minecraft:overworld run fill 294 58 23 294 65 23 stone
execute in minecraft:overworld run fill 294 66 23 294 67 23 dirt
execute in minecraft:overworld run setblock 294 68 23 grass_block
execute in minecraft:overworld run fill 294 69 23 294 144 23 air
execute in minecraft:overworld run fill 294 58 24 294 65 24 stone
execute in minecraft:overworld run fill 294 66 24 294 67 24 dirt
execute in minecraft:overworld run setblock 294 68 24 coarse_dirt
execute in minecraft:overworld run fill 294 69 24 294 144 24 air
execute in minecraft:overworld run fill 294 58 25 294 65 25 stone
execute in minecraft:overworld run fill 294 66 25 294 67 25 dirt
execute in minecraft:overworld run setblock 294 68 25 coarse_dirt
execute in minecraft:overworld run fill 294 69 25 294 144 25 air
execute in minecraft:overworld run fill 294 58 26 294 66 26 stone
execute in minecraft:overworld run fill 294 67 26 294 68 26 dirt
execute in minecraft:overworld run setblock 294 69 26 grass_block
execute in minecraft:overworld run fill 294 70 26 294 144 26 air
execute in minecraft:overworld run fill 294 58 27 294 66 27 stone
execute in minecraft:overworld run fill 294 67 27 294 68 27 dirt
execute in minecraft:overworld run setblock 294 69 27 coarse_dirt
execute in minecraft:overworld run fill 294 70 27 294 144 27 air
execute in minecraft:overworld run fill 294 58 28 294 66 28 stone
execute in minecraft:overworld run fill 294 67 28 294 68 28 dirt
execute in minecraft:overworld run setblock 294 69 28 coarse_dirt
execute in minecraft:overworld run fill 294 70 28 294 144 28 air
execute in minecraft:overworld run fill 294 58 29 294 65 29 stone
execute in minecraft:overworld run fill 294 66 29 294 67 29 dirt
execute in minecraft:overworld run setblock 294 68 29 grass_block
execute in minecraft:overworld run fill 294 69 29 294 144 29 air
execute in minecraft:overworld run fill 294 58 30 294 65 30 stone
execute in minecraft:overworld run fill 294 66 30 294 67 30 dirt
execute in minecraft:overworld run setblock 294 68 30 coarse_dirt
schedule function blade_gallery:random/burned/part_137 1t replace
