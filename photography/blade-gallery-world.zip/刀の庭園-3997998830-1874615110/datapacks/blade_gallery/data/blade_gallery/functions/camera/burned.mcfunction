execute in minecraft:overworld run tp @s 246 71 22 facing 256 73 -12
