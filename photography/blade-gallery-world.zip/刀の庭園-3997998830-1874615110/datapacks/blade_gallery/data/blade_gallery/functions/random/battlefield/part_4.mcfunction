execute in minecraft:overworld run setblock 338 65 15 coarse_dirt
execute in minecraft:overworld run fill 338 66 15 338 144 15 air
execute in minecraft:overworld run fill 338 58 16 338 62 16 stone
execute in minecraft:overworld run fill 338 63 16 338 64 16 dirt
execute in minecraft:overworld run setblock 338 65 16 coarse_dirt
execute in minecraft:overworld run fill 338 66 16 338 144 16 air
execute in minecraft:overworld run fill 338 58 17 338 62 17 stone
execute in minecraft:overworld run fill 338 63 17 338 64 17 dirt
execute in minecraft:overworld run setblock 338 65 17 coarse_dirt
execute in minecraft:overworld run fill 338 66 17 338 144 17 air
execute in minecraft:overworld run fill 338 58 18 338 62 18 stone
execute in minecraft:overworld run fill 338 63 18 338 64 18 dirt
execute in minecraft:overworld run setblock 338 65 18 coarse_dirt
execute in minecraft:overworld run fill 338 66 18 338 144 18 air
execute in minecraft:overworld run fill 338 58 19 338 62 19 stone
execute in minecraft:overworld run fill 338 63 19 338 64 19 dirt
execute in minecraft:overworld run setblock 338 65 19 grass_block
execute in minecraft:overworld run fill 338 66 19 338 144 19 air
execute in minecraft:overworld run fill 338 58 20 338 62 20 stone
execute in minecraft:overworld run fill 338 63 20 338 64 20 dirt
execute in minecraft:overworld run setblock 338 65 20 grass_block
execute in minecraft:overworld run fill 338 66 20 338 144 20 air
execute in minecraft:overworld run fill 338 58 21 338 61 21 stone
execute in minecraft:overworld run fill 338 62 21 338 63 21 dirt
execute in minecraft:overworld run setblock 338 64 21 grass_block
execute in minecraft:overworld run fill 338 65 21 338 144 21 air
execute in minecraft:overworld run fill 338 58 22 338 61 22 stone
execute in minecraft:overworld run fill 338 62 22 338 63 22 dirt
execute in minecraft:overworld run setblock 338 64 22 coarse_dirt
execute in minecraft:overworld run fill 338 65 22 338 144 22 air
execute in minecraft:overworld run fill 338 58 23 338 61 23 stone
execute in minecraft:overworld run fill 338 62 23 338 63 23 dirt
execute in minecraft:overworld run setblock 338 64 23 coarse_dirt
execute in minecraft:overworld run fill 338 65 23 338 144 23 air
execute in minecraft:overworld run fill 338 58 24 338 61 24 stone
execute in minecraft:overworld run fill 338 62 24 338 63 24 dirt
execute in minecraft:overworld run setblock 338 64 24 grass_block
execute in minecraft:overworld run fill 338 65 24 338 144 24 air
execute in minecraft:overworld run fill 338 58 25 338 61 25 stone
execute in minecraft:overworld run fill 338 62 25 338 63 25 dirt
execute in minecraft:overworld run setblock 338 64 25 coarse_dirt
execute in minecraft:overworld run fill 338 65 25 338 144 25 air
execute in minecraft:overworld run fill 338 58 26 338 61 26 stone
execute in minecraft:overworld run fill 338 62 26 338 63 26 dirt
execute in minecraft:overworld run setblock 338 64 26 grass_block
execute in minecraft:overworld run fill 338 65 26 338 144 26 air
execute in minecraft:overworld run fill 338 58 27 338 61 27 stone
execute in minecraft:overworld run fill 338 62 27 338 63 27 dirt
execute in minecraft:overworld run setblock 338 64 27 coarse_dirt
execute in minecraft:overworld run fill 338 65 27 338 144 27 air
execute in minecraft:overworld run fill 338 58 28 338 61 28 stone
execute in minecraft:overworld run fill 338 62 28 338 63 28 dirt
execute in minecraft:overworld run setblock 338 64 28 grass_block
execute in minecraft:overworld run fill 338 65 28 338 144 28 air
execute in minecraft:overworld run fill 338 58 29 338 62 29 stone
execute in minecraft:overworld run fill 338 63 29 338 64 29 dirt
execute in minecraft:overworld run setblock 338 65 29 grass_block
execute in minecraft:overworld run fill 338 66 29 338 144 29 air
execute in minecraft:overworld run fill 338 58 30 338 62 30 stone
execute in minecraft:overworld run fill 338 63 30 338 64 30 dirt
execute in minecraft:overworld run setblock 338 65 30 grass_block
execute in minecraft:overworld run fill 338 66 30 338 144 30 air
execute in minecraft:overworld run fill 338 58 31 338 62 31 stone
execute in minecraft:overworld run fill 338 63 31 338 64 31 dirt
execute in minecraft:overworld run setblock 338 65 31 coarse_dirt
execute in minecraft:overworld run fill 338 66 31 338 144 31 air
execute in minecraft:overworld run fill 338 58 32 338 62 32 stone
execute in minecraft:overworld run fill 338 63 32 338 64 32 dirt
execute in minecraft:overworld run setblock 338 65 32 grass_block
execute in minecraft:overworld run fill 338 66 32 338 144 32 air
execute in minecraft:overworld run fill 338 58 33 338 62 33 stone
execute in minecraft:overworld run fill 338 63 33 338 64 33 dirt
execute in minecraft:overworld run setblock 338 65 33 coarse_dirt
execute in minecraft:overworld run fill 338 66 33 338 144 33 air
execute in minecraft:overworld run fill 338 58 34 338 62 34 stone
execute in minecraft:overworld run fill 338 63 34 338 64 34 dirt
execute in minecraft:overworld run setblock 338 65 34 grass_block
execute in minecraft:overworld run fill 338 66 34 338 144 34 air
execute in minecraft:overworld run fill 338 58 35 338 62 35 stone
execute in minecraft:overworld run fill 338 63 35 338 64 35 dirt
execute in minecraft:overworld run setblock 338 65 35 grass_block
execute in minecraft:overworld run fill 338 66 35 338 144 35 air
execute in minecraft:overworld run fill 338 58 36 338 62 36 stone
execute in minecraft:overworld run fill 338 63 36 338 64 36 dirt
execute in minecraft:overworld run setblock 338 65 36 coarse_dirt
execute in minecraft:overworld run fill 338 66 36 338 144 36 air
execute in minecraft:overworld run fill 338 58 37 338 62 37 stone
execute in minecraft:overworld run fill 338 63 37 338 64 37 dirt
execute in minecraft:overworld run setblock 338 65 37 grass_block
execute in minecraft:overworld run fill 338 66 37 338 144 37 air
execute in minecraft:overworld run fill 338 58 38 338 62 38 stone
execute in minecraft:overworld run fill 338 63 38 338 64 38 dirt
execute in minecraft:overworld run setblock 338 65 38 coarse_dirt
execute in minecraft:overworld run fill 338 66 38 338 144 38 air
execute in minecraft:overworld run fill 338 58 39 338 62 39 stone
execute in minecraft:overworld run fill 338 63 39 338 64 39 dirt
execute in minecraft:overworld run setblock 338 65 39 coarse_dirt
execute in minecraft:overworld run fill 338 66 39 338 144 39 air
execute in minecraft:overworld run fill 338 58 40 338 62 40 stone
execute in minecraft:overworld run fill 338 63 40 338 64 40 dirt
execute in minecraft:overworld run setblock 338 65 40 coarse_dirt
execute in minecraft:overworld run fill 338 66 40 338 144 40 air
execute in minecraft:overworld run fill 338 58 41 338 62 41 stone
execute in minecraft:overworld run fill 338 63 41 338 64 41 dirt
execute in minecraft:overworld run setblock 338 65 41 grass_block
execute in minecraft:overworld run fill 338 66 41 338 144 41 air
execute in minecraft:overworld run fill 338 58 42 338 62 42 stone
execute in minecraft:overworld run fill 338 63 42 338 64 42 dirt
execute in minecraft:overworld run setblock 338 65 42 coarse_dirt
execute in minecraft:overworld run fill 338 66 42 338 144 42 air
execute in minecraft:overworld run fill 338 58 43 338 62 43 stone
execute in minecraft:overworld run fill 338 63 43 338 64 43 dirt
execute in minecraft:overworld run setblock 338 65 43 coarse_dirt
execute in minecraft:overworld run fill 338 66 43 338 144 43 air
execute in minecraft:overworld run fill 338 58 44 338 62 44 stone
execute in minecraft:overworld run fill 338 63 44 338 64 44 dirt
execute in minecraft:overworld run setblock 338 65 44 coarse_dirt
execute in minecraft:overworld run fill 338 66 44 338 144 44 air
execute in minecraft:overworld run fill 338 58 45 338 62 45 stone
execute in minecraft:overworld run fill 338 63 45 338 64 45 dirt
execute in minecraft:overworld run setblock 338 65 45 coarse_dirt
execute in minecraft:overworld run fill 338 66 45 338 144 45 air
execute in minecraft:overworld run fill 338 58 46 338 61 46 stone
execute in minecraft:overworld run fill 338 62 46 338 63 46 dirt
execute in minecraft:overworld run setblock 338 64 46 grass_block
execute in minecraft:overworld run fill 338 65 46 338 144 46 air
execute in minecraft:overworld run fill 338 58 47 338 61 47 stone
execute in minecraft:overworld run fill 338 62 47 338 63 47 dirt
execute in minecraft:overworld run setblock 338 64 47 coarse_dirt
execute in minecraft:overworld run fill 338 65 47 338 144 47 air
execute in minecraft:overworld run fill 339 58 -48 339 61 -48 stone
execute in minecraft:overworld run fill 339 62 -48 339 63 -48 dirt
execute in minecraft:overworld run setblock 339 64 -48 grass_block
execute in minecraft:overworld run fill 339 65 -48 339 144 -48 air
execute in minecraft:overworld run fill 339 58 -47 339 63 -47 stone
execute in minecraft:overworld run fill 339 64 -47 339 65 -47 dirt
execute in minecraft:overworld run setblock 339 66 -47 coarse_dirt
execute in minecraft:overworld run fill 339 67 -47 339 144 -47 air
execute in minecraft:overworld run fill 339 58 -46 339 65 -46 stone
execute in minecraft:overworld run fill 339 66 -46 339 67 -46 dirt
execute in minecraft:overworld run setblock 339 68 -46 coarse_dirt
execute in minecraft:overworld run fill 339 69 -46 339 144 -46 air
execute in minecraft:overworld run fill 339 58 -45 339 66 -45 stone
execute in minecraft:overworld run fill 339 67 -45 339 68 -45 dirt
execute in minecraft:overworld run setblock 339 69 -45 grass_block
execute in minecraft:overworld run fill 339 70 -45 339 144 -45 air
execute in minecraft:overworld run fill 339 58 -44 339 66 -44 stone
execute in minecraft:overworld run fill 339 67 -44 339 68 -44 dirt
execute in minecraft:overworld run setblock 339 69 -44 grass_block
execute in minecraft:overworld run fill 339 70 -44 339 144 -44 air
execute in minecraft:overworld run fill 339 58 -43 339 66 -43 stone
execute in minecraft:overworld run fill 339 67 -43 339 68 -43 dirt
execute in minecraft:overworld run setblock 339 69 -43 coarse_dirt
execute in minecraft:overworld run fill 339 70 -43 339 144 -43 air
execute in minecraft:overworld run fill 339 58 -42 339 66 -42 stone
execute in minecraft:overworld run fill 339 67 -42 339 68 -42 dirt
execute in minecraft:overworld run setblock 339 69 -42 grass_block
execute in minecraft:overworld run fill 339 70 -42 339 144 -42 air
execute in minecraft:overworld run fill 339 58 -41 339 66 -41 stone
execute in minecraft:overworld run fill 339 67 -41 339 68 -41 dirt
execute in minecraft:overworld run setblock 339 69 -41 coarse_dirt
execute in minecraft:overworld run fill 339 70 -41 339 144 -41 air
execute in minecraft:overworld run fill 339 58 -40 339 66 -40 stone
execute in minecraft:overworld run fill 339 67 -40 339 68 -40 dirt
execute in minecraft:overworld run setblock 339 69 -40 coarse_dirt
execute in minecraft:overworld run fill 339 70 -40 339 144 -40 air
execute in minecraft:overworld run fill 339 58 -39 339 66 -39 stone
execute in minecraft:overworld run fill 339 67 -39 339 68 -39 dirt
execute in minecraft:overworld run setblock 339 69 -39 coarse_dirt
execute in minecraft:overworld run fill 339 70 -39 339 144 -39 air
execute in minecraft:overworld run fill 339 58 -38 339 66 -38 stone
execute in minecraft:overworld run fill 339 67 -38 339 68 -38 dirt
execute in minecraft:overworld run setblock 339 69 -38 coarse_dirt
execute in minecraft:overworld run fill 339 70 -38 339 144 -38 air
execute in minecraft:overworld run fill 339 58 -37 339 66 -37 stone
execute in minecraft:overworld run fill 339 67 -37 339 68 -37 dirt
execute in minecraft:overworld run setblock 339 69 -37 grass_block
execute in minecraft:overworld run fill 339 70 -37 339 144 -37 air
execute in minecraft:overworld run fill 339 58 -36 339 66 -36 stone
execute in minecraft:overworld run fill 339 67 -36 339 68 -36 dirt
execute in minecraft:overworld run setblock 339 69 -36 coarse_dirt
execute in minecraft:overworld run fill 339 70 -36 339 144 -36 air
execute in minecraft:overworld run fill 339 58 -35 339 66 -35 stone
execute in minecraft:overworld run fill 339 67 -35 339 68 -35 dirt
execute in minecraft:overworld run setblock 339 69 -35 coarse_dirt
execute in minecraft:overworld run fill 339 70 -35 339 144 -35 air
execute in minecraft:overworld run fill 339 58 -34 339 66 -34 stone
execute in minecraft:overworld run fill 339 67 -34 339 68 -34 dirt
execute in minecraft:overworld run setblock 339 69 -34 coarse_dirt
execute in minecraft:overworld run fill 339 70 -34 339 144 -34 air
execute in minecraft:overworld run fill 339 58 -33 339 65 -33 stone
execute in minecraft:overworld run fill 339 66 -33 339 67 -33 dirt
execute in minecraft:overworld run setblock 339 68 -33 coarse_dirt
execute in minecraft:overworld run fill 339 69 -33 339 144 -33 air
execute in minecraft:overworld run fill 339 58 -32 339 65 -32 stone
execute in minecraft:overworld run fill 339 66 -32 339 67 -32 dirt
execute in minecraft:overworld run setblock 339 68 -32 coarse_dirt
execute in minecraft:overworld run fill 339 69 -32 339 144 -32 air
execute in minecraft:overworld run fill 339 58 -31 339 65 -31 stone
execute in minecraft:overworld run fill 339 66 -31 339 67 -31 dirt
execute in minecraft:overworld run setblock 339 68 -31 grass_block
execute in minecraft:overworld run fill 339 69 -31 339 144 -31 air
execute in minecraft:overworld run fill 339 58 -30 339 65 -30 stone
execute in minecraft:overworld run fill 339 66 -30 339 67 -30 dirt
execute in minecraft:overworld run setblock 339 68 -30 grass_block
execute in minecraft:overworld run fill 339 69 -30 339 144 -30 air
execute in minecraft:overworld run fill 339 58 -29 339 65 -29 stone
execute in minecraft:overworld run fill 339 66 -29 339 67 -29 dirt
execute in minecraft:overworld run setblock 339 68 -29 grass_block
execute in minecraft:overworld run fill 339 69 -29 339 144 -29 air
execute in minecraft:overworld run fill 339 58 -28 339 65 -28 stone
execute in minecraft:overworld run fill 339 66 -28 339 67 -28 dirt
execute in minecraft:overworld run setblock 339 68 -28 grass_block
execute in minecraft:overworld run fill 339 69 -28 339 144 -28 air
execute in minecraft:overworld run fill 339 58 -27 339 65 -27 stone
execute in minecraft:overworld run fill 339 66 -27 339 67 -27 dirt
execute in minecraft:overworld run setblock 339 68 -27 coarse_dirt
execute in minecraft:overworld run fill 339 69 -27 339 144 -27 air
execute in minecraft:overworld run fill 339 58 -26 339 65 -26 stone
execute in minecraft:overworld run fill 339 66 -26 339 67 -26 dirt
execute in minecraft:overworld run setblock 339 68 -26 coarse_dirt
execute in minecraft:overworld run fill 339 69 -26 339 144 -26 air
execute in minecraft:overworld run fill 339 58 -25 339 65 -25 stone
execute in minecraft:overworld run fill 339 66 -25 339 67 -25 dirt
execute in minecraft:overworld run setblock 339 68 -25 coarse_dirt
execute in minecraft:overworld run fill 339 69 -25 339 144 -25 air
execute in minecraft:overworld run fill 339 58 -24 339 64 -24 stone
execute in minecraft:overworld run fill 339 65 -24 339 66 -24 dirt
execute in minecraft:overworld run setblock 339 67 -24 coarse_dirt
execute in minecraft:overworld run fill 339 68 -24 339 144 -24 air
execute in minecraft:overworld run fill 339 58 -23 339 64 -23 stone
execute in minecraft:overworld run fill 339 65 -23 339 66 -23 dirt
execute in minecraft:overworld run setblock 339 67 -23 coarse_dirt
execute in minecraft:overworld run fill 339 68 -23 339 144 -23 air
execute in minecraft:overworld run fill 339 58 -22 339 64 -22 stone
execute in minecraft:overworld run fill 339 65 -22 339 66 -22 dirt
execute in minecraft:overworld run setblock 339 67 -22 grass_block
execute in minecraft:overworld run fill 339 68 -22 339 144 -22 air
execute in minecraft:overworld run fill 339 58 -21 339 64 -21 stone
execute in minecraft:overworld run fill 339 65 -21 339 66 -21 dirt
execute in minecraft:overworld run setblock 339 67 -21 grass_block
execute in minecraft:overworld run fill 339 68 -21 339 144 -21 air
execute in minecraft:overworld run fill 339 58 -20 339 64 -20 stone
execute in minecraft:overworld run fill 339 65 -20 339 66 -20 dirt
execute in minecraft:overworld run setblock 339 67 -20 coarse_dirt
execute in minecraft:overworld run fill 339 68 -20 339 144 -20 air
execute in minecraft:overworld run fill 339 58 -19 339 64 -19 stone
execute in minecraft:overworld run fill 339 65 -19 339 66 -19 dirt
execute in minecraft:overworld run setblock 339 67 -19 coarse_dirt
execute in minecraft:overworld run fill 339 68 -19 339 144 -19 air
execute in minecraft:overworld run fill 339 58 -18 339 64 -18 stone
execute in minecraft:overworld run fill 339 65 -18 339 66 -18 dirt
execute in minecraft:overworld run setblock 339 67 -18 coarse_dirt
execute in minecraft:overworld run fill 339 68 -18 339 144 -18 air
execute in minecraft:overworld run fill 339 58 -17 339 64 -17 stone
execute in minecraft:overworld run fill 339 65 -17 339 66 -17 dirt
schedule function blade_gallery:random/battlefield/part_5 1t replace
