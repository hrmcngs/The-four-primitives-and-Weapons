execute in minecraft:overworld run fill 426 68 6 426 144 6 air
execute in minecraft:overworld run fill 426 58 7 426 64 7 stone
execute in minecraft:overworld run fill 426 65 7 426 66 7 dirt
execute in minecraft:overworld run setblock 426 67 7 grass_block
execute in minecraft:overworld run fill 426 68 7 426 144 7 air
execute in minecraft:overworld run fill 426 58 8 426 64 8 stone
execute in minecraft:overworld run fill 426 65 8 426 66 8 dirt
execute in minecraft:overworld run setblock 426 67 8 coarse_dirt
execute in minecraft:overworld run fill 426 68 8 426 144 8 air
execute in minecraft:overworld run fill 426 58 9 426 64 9 stone
execute in minecraft:overworld run fill 426 65 9 426 66 9 dirt
execute in minecraft:overworld run setblock 426 67 9 coarse_dirt
execute in minecraft:overworld run fill 426 68 9 426 144 9 air
execute in minecraft:overworld run fill 426 58 10 426 64 10 stone
execute in minecraft:overworld run fill 426 65 10 426 66 10 dirt
execute in minecraft:overworld run setblock 426 67 10 coarse_dirt
execute in minecraft:overworld run fill 426 68 10 426 144 10 air
execute in minecraft:overworld run fill 426 58 11 426 64 11 stone
execute in minecraft:overworld run fill 426 65 11 426 66 11 dirt
execute in minecraft:overworld run setblock 426 67 11 grass_block
execute in minecraft:overworld run fill 426 68 11 426 144 11 air
execute in minecraft:overworld run fill 426 58 12 426 65 12 stone
execute in minecraft:overworld run fill 426 66 12 426 67 12 dirt
execute in minecraft:overworld run setblock 426 68 12 grass_block
execute in minecraft:overworld run fill 426 69 12 426 144 12 air
execute in minecraft:overworld run fill 426 58 13 426 65 13 stone
execute in minecraft:overworld run fill 426 66 13 426 67 13 dirt
execute in minecraft:overworld run setblock 426 68 13 coarse_dirt
execute in minecraft:overworld run fill 426 69 13 426 144 13 air
execute in minecraft:overworld run fill 426 58 14 426 65 14 stone
execute in minecraft:overworld run fill 426 66 14 426 67 14 dirt
execute in minecraft:overworld run setblock 426 68 14 coarse_dirt
execute in minecraft:overworld run fill 426 69 14 426 144 14 air
execute in minecraft:overworld run fill 426 58 15 426 65 15 stone
execute in minecraft:overworld run fill 426 66 15 426 67 15 dirt
execute in minecraft:overworld run setblock 426 68 15 coarse_dirt
execute in minecraft:overworld run fill 426 69 15 426 144 15 air
execute in minecraft:overworld run fill 426 58 16 426 66 16 stone
execute in minecraft:overworld run fill 426 67 16 426 68 16 dirt
execute in minecraft:overworld run setblock 426 69 16 coarse_dirt
execute in minecraft:overworld run fill 426 70 16 426 144 16 air
execute in minecraft:overworld run fill 426 58 17 426 66 17 stone
execute in minecraft:overworld run fill 426 67 17 426 68 17 dirt
execute in minecraft:overworld run setblock 426 69 17 coarse_dirt
execute in minecraft:overworld run fill 426 70 17 426 144 17 air
execute in minecraft:overworld run fill 426 58 18 426 66 18 stone
execute in minecraft:overworld run fill 426 67 18 426 68 18 dirt
execute in minecraft:overworld run setblock 426 69 18 grass_block
execute in minecraft:overworld run fill 426 70 18 426 144 18 air
execute in minecraft:overworld run fill 426 58 19 426 66 19 stone
execute in minecraft:overworld run fill 426 67 19 426 68 19 dirt
execute in minecraft:overworld run setblock 426 69 19 coarse_dirt
execute in minecraft:overworld run fill 426 70 19 426 144 19 air
execute in minecraft:overworld run fill 426 58 20 426 66 20 stone
execute in minecraft:overworld run fill 426 67 20 426 68 20 dirt
execute in minecraft:overworld run setblock 426 69 20 coarse_dirt
execute in minecraft:overworld run fill 426 70 20 426 144 20 air
execute in minecraft:overworld run fill 426 58 21 426 66 21 stone
execute in minecraft:overworld run fill 426 67 21 426 68 21 dirt
execute in minecraft:overworld run setblock 426 69 21 coarse_dirt
execute in minecraft:overworld run fill 426 70 21 426 144 21 air
execute in minecraft:overworld run fill 426 58 22 426 67 22 stone
execute in minecraft:overworld run fill 426 68 22 426 69 22 dirt
execute in minecraft:overworld run setblock 426 70 22 coarse_dirt
execute in minecraft:overworld run fill 426 71 22 426 144 22 air
execute in minecraft:overworld run fill 426 58 23 426 67 23 stone
execute in minecraft:overworld run fill 426 68 23 426 69 23 dirt
execute in minecraft:overworld run setblock 426 70 23 coarse_dirt
execute in minecraft:overworld run fill 426 71 23 426 144 23 air
execute in minecraft:overworld run fill 426 58 24 426 67 24 stone
execute in minecraft:overworld run fill 426 68 24 426 69 24 dirt
execute in minecraft:overworld run setblock 426 70 24 coarse_dirt
execute in minecraft:overworld run fill 426 71 24 426 144 24 air
execute in minecraft:overworld run fill 426 58 25 426 67 25 stone
execute in minecraft:overworld run fill 426 68 25 426 69 25 dirt
execute in minecraft:overworld run setblock 426 70 25 grass_block
execute in minecraft:overworld run fill 426 71 25 426 144 25 air
execute in minecraft:overworld run fill 426 58 26 426 67 26 stone
execute in minecraft:overworld run fill 426 68 26 426 69 26 dirt
execute in minecraft:overworld run setblock 426 70 26 grass_block
execute in minecraft:overworld run fill 426 71 26 426 144 26 air
execute in minecraft:overworld run fill 426 58 27 426 67 27 stone
execute in minecraft:overworld run fill 426 68 27 426 69 27 dirt
execute in minecraft:overworld run setblock 426 70 27 grass_block
execute in minecraft:overworld run fill 426 71 27 426 144 27 air
execute in minecraft:overworld run fill 426 58 28 426 67 28 stone
execute in minecraft:overworld run fill 426 68 28 426 69 28 dirt
execute in minecraft:overworld run setblock 426 70 28 coarse_dirt
execute in minecraft:overworld run fill 426 71 28 426 144 28 air
execute in minecraft:overworld run fill 426 58 29 426 67 29 stone
execute in minecraft:overworld run fill 426 68 29 426 69 29 dirt
execute in minecraft:overworld run setblock 426 70 29 grass_block
execute in minecraft:overworld run fill 426 71 29 426 144 29 air
execute in minecraft:overworld run fill 426 58 30 426 67 30 stone
execute in minecraft:overworld run fill 426 68 30 426 69 30 dirt
execute in minecraft:overworld run setblock 426 70 30 coarse_dirt
execute in minecraft:overworld run fill 426 71 30 426 144 30 air
execute in minecraft:overworld run fill 426 58 31 426 67 31 stone
execute in minecraft:overworld run fill 426 68 31 426 69 31 dirt
execute in minecraft:overworld run setblock 426 70 31 coarse_dirt
execute in minecraft:overworld run fill 426 71 31 426 144 31 air
execute in minecraft:overworld run fill 426 58 32 426 67 32 stone
execute in minecraft:overworld run fill 426 68 32 426 69 32 dirt
execute in minecraft:overworld run setblock 426 70 32 coarse_dirt
execute in minecraft:overworld run fill 426 71 32 426 144 32 air
execute in minecraft:overworld run fill 426 58 33 426 67 33 stone
execute in minecraft:overworld run fill 426 68 33 426 69 33 dirt
execute in minecraft:overworld run setblock 426 70 33 grass_block
execute in minecraft:overworld run fill 426 71 33 426 144 33 air
execute in minecraft:overworld run fill 426 58 34 426 67 34 stone
execute in minecraft:overworld run fill 426 68 34 426 69 34 dirt
execute in minecraft:overworld run setblock 426 70 34 coarse_dirt
execute in minecraft:overworld run fill 426 71 34 426 144 34 air
execute in minecraft:overworld run fill 426 58 35 426 66 35 stone
execute in minecraft:overworld run fill 426 67 35 426 68 35 dirt
execute in minecraft:overworld run setblock 426 69 35 coarse_dirt
execute in minecraft:overworld run fill 426 70 35 426 144 35 air
execute in minecraft:overworld run fill 426 58 36 426 66 36 stone
execute in minecraft:overworld run fill 426 67 36 426 68 36 dirt
execute in minecraft:overworld run setblock 426 69 36 grass_block
execute in minecraft:overworld run fill 426 70 36 426 144 36 air
execute in minecraft:overworld run fill 426 58 37 426 66 37 stone
execute in minecraft:overworld run fill 426 67 37 426 68 37 dirt
execute in minecraft:overworld run setblock 426 69 37 coarse_dirt
execute in minecraft:overworld run fill 426 70 37 426 144 37 air
execute in minecraft:overworld run fill 426 58 38 426 66 38 stone
execute in minecraft:overworld run fill 426 67 38 426 68 38 dirt
execute in minecraft:overworld run setblock 426 69 38 grass_block
execute in minecraft:overworld run fill 426 70 38 426 144 38 air
execute in minecraft:overworld run fill 426 58 39 426 65 39 stone
execute in minecraft:overworld run fill 426 66 39 426 67 39 dirt
execute in minecraft:overworld run setblock 426 68 39 grass_block
execute in minecraft:overworld run fill 426 69 39 426 144 39 air
execute in minecraft:overworld run fill 426 58 40 426 65 40 stone
execute in minecraft:overworld run fill 426 66 40 426 67 40 dirt
execute in minecraft:overworld run setblock 426 68 40 coarse_dirt
execute in minecraft:overworld run fill 426 69 40 426 144 40 air
execute in minecraft:overworld run fill 426 58 41 426 64 41 stone
execute in minecraft:overworld run fill 426 65 41 426 66 41 dirt
execute in minecraft:overworld run setblock 426 67 41 coarse_dirt
execute in minecraft:overworld run fill 426 68 41 426 144 41 air
execute in minecraft:overworld run fill 426 58 42 426 64 42 stone
execute in minecraft:overworld run fill 426 65 42 426 66 42 dirt
execute in minecraft:overworld run setblock 426 67 42 grass_block
execute in minecraft:overworld run fill 426 68 42 426 144 42 air
execute in minecraft:overworld run fill 426 58 43 426 63 43 stone
execute in minecraft:overworld run fill 426 64 43 426 65 43 dirt
execute in minecraft:overworld run setblock 426 66 43 coarse_dirt
execute in minecraft:overworld run fill 426 67 43 426 144 43 air
execute in minecraft:overworld run fill 426 58 44 426 62 44 stone
execute in minecraft:overworld run fill 426 63 44 426 64 44 dirt
execute in minecraft:overworld run setblock 426 65 44 coarse_dirt
execute in minecraft:overworld run fill 426 66 44 426 144 44 air
execute in minecraft:overworld run fill 426 58 45 426 62 45 stone
execute in minecraft:overworld run fill 426 63 45 426 64 45 dirt
execute in minecraft:overworld run setblock 426 65 45 coarse_dirt
execute in minecraft:overworld run fill 426 66 45 426 144 45 air
execute in minecraft:overworld run fill 426 58 46 426 61 46 stone
execute in minecraft:overworld run fill 426 62 46 426 63 46 dirt
execute in minecraft:overworld run setblock 426 64 46 grass_block
execute in minecraft:overworld run fill 426 65 46 426 144 46 air
execute in minecraft:overworld run fill 426 58 47 426 61 47 stone
execute in minecraft:overworld run fill 426 62 47 426 63 47 dirt
execute in minecraft:overworld run setblock 426 64 47 coarse_dirt
execute in minecraft:overworld run fill 426 65 47 426 144 47 air
execute in minecraft:overworld run fill 427 58 -48 427 61 -48 stone
execute in minecraft:overworld run fill 427 62 -48 427 63 -48 dirt
execute in minecraft:overworld run setblock 427 64 -48 coarse_dirt
execute in minecraft:overworld run fill 427 65 -48 427 144 -48 air
execute in minecraft:overworld run fill 427 58 -47 427 63 -47 stone
execute in minecraft:overworld run fill 427 64 -47 427 65 -47 dirt
execute in minecraft:overworld run setblock 427 66 -47 coarse_dirt
execute in minecraft:overworld run fill 427 67 -47 427 144 -47 air
execute in minecraft:overworld run fill 427 58 -46 427 64 -46 stone
execute in minecraft:overworld run fill 427 65 -46 427 66 -46 dirt
execute in minecraft:overworld run setblock 427 67 -46 coarse_dirt
execute in minecraft:overworld run fill 427 68 -46 427 144 -46 air
execute in minecraft:overworld run fill 427 58 -45 427 66 -45 stone
execute in minecraft:overworld run fill 427 67 -45 427 68 -45 dirt
execute in minecraft:overworld run setblock 427 69 -45 grass_block
execute in minecraft:overworld run fill 427 70 -45 427 144 -45 air
execute in minecraft:overworld run fill 427 58 -44 427 68 -44 stone
execute in minecraft:overworld run fill 427 69 -44 427 70 -44 dirt
execute in minecraft:overworld run setblock 427 71 -44 grass_block
execute in minecraft:overworld run fill 427 72 -44 427 144 -44 air
execute in minecraft:overworld run fill 427 58 -43 427 69 -43 stone
execute in minecraft:overworld run fill 427 70 -43 427 71 -43 dirt
execute in minecraft:overworld run setblock 427 72 -43 coarse_dirt
execute in minecraft:overworld run fill 427 73 -43 427 144 -43 air
execute in minecraft:overworld run fill 427 58 -42 427 69 -42 stone
execute in minecraft:overworld run fill 427 70 -42 427 71 -42 dirt
execute in minecraft:overworld run setblock 427 72 -42 coarse_dirt
execute in minecraft:overworld run fill 427 73 -42 427 144 -42 air
execute in minecraft:overworld run fill 427 58 -41 427 69 -41 stone
execute in minecraft:overworld run fill 427 70 -41 427 71 -41 dirt
execute in minecraft:overworld run setblock 427 72 -41 coarse_dirt
execute in minecraft:overworld run fill 427 73 -41 427 144 -41 air
execute in minecraft:overworld run fill 427 58 -40 427 69 -40 stone
execute in minecraft:overworld run fill 427 70 -40 427 71 -40 dirt
execute in minecraft:overworld run setblock 427 72 -40 grass_block
execute in minecraft:overworld run fill 427 73 -40 427 144 -40 air
execute in minecraft:overworld run fill 427 58 -39 427 69 -39 stone
execute in minecraft:overworld run fill 427 70 -39 427 71 -39 dirt
execute in minecraft:overworld run setblock 427 72 -39 coarse_dirt
execute in minecraft:overworld run fill 427 73 -39 427 144 -39 air
execute in minecraft:overworld run fill 427 58 -38 427 68 -38 stone
execute in minecraft:overworld run fill 427 69 -38 427 70 -38 dirt
execute in minecraft:overworld run setblock 427 71 -38 coarse_dirt
execute in minecraft:overworld run fill 427 72 -38 427 144 -38 air
execute in minecraft:overworld run fill 427 58 -37 427 68 -37 stone
execute in minecraft:overworld run fill 427 69 -37 427 70 -37 dirt
execute in minecraft:overworld run setblock 427 71 -37 coarse_dirt
execute in minecraft:overworld run fill 427 72 -37 427 144 -37 air
execute in minecraft:overworld run fill 427 58 -36 427 68 -36 stone
execute in minecraft:overworld run fill 427 69 -36 427 70 -36 dirt
execute in minecraft:overworld run setblock 427 71 -36 grass_block
execute in minecraft:overworld run fill 427 72 -36 427 144 -36 air
execute in minecraft:overworld run fill 427 58 -35 427 68 -35 stone
execute in minecraft:overworld run fill 427 69 -35 427 70 -35 dirt
execute in minecraft:overworld run setblock 427 71 -35 coarse_dirt
execute in minecraft:overworld run fill 427 72 -35 427 144 -35 air
execute in minecraft:overworld run fill 427 58 -34 427 68 -34 stone
execute in minecraft:overworld run fill 427 69 -34 427 70 -34 dirt
execute in minecraft:overworld run setblock 427 71 -34 grass_block
execute in minecraft:overworld run fill 427 72 -34 427 144 -34 air
execute in minecraft:overworld run fill 427 58 -33 427 67 -33 stone
execute in minecraft:overworld run fill 427 68 -33 427 69 -33 dirt
execute in minecraft:overworld run setblock 427 70 -33 grass_block
execute in minecraft:overworld run fill 427 71 -33 427 144 -33 air
execute in minecraft:overworld run fill 427 58 -32 427 67 -32 stone
execute in minecraft:overworld run fill 427 68 -32 427 69 -32 dirt
execute in minecraft:overworld run setblock 427 70 -32 coarse_dirt
execute in minecraft:overworld run fill 427 71 -32 427 144 -32 air
execute in minecraft:overworld run fill 427 58 -31 427 67 -31 stone
execute in minecraft:overworld run fill 427 68 -31 427 69 -31 dirt
execute in minecraft:overworld run setblock 427 70 -31 coarse_dirt
execute in minecraft:overworld run fill 427 71 -31 427 144 -31 air
execute in minecraft:overworld run fill 427 58 -30 427 66 -30 stone
execute in minecraft:overworld run fill 427 67 -30 427 68 -30 dirt
execute in minecraft:overworld run setblock 427 69 -30 coarse_dirt
execute in minecraft:overworld run fill 427 70 -30 427 144 -30 air
execute in minecraft:overworld run fill 427 58 -29 427 66 -29 stone
execute in minecraft:overworld run fill 427 67 -29 427 68 -29 dirt
execute in minecraft:overworld run setblock 427 69 -29 grass_block
execute in minecraft:overworld run fill 427 70 -29 427 144 -29 air
execute in minecraft:overworld run fill 427 58 -28 427 66 -28 stone
execute in minecraft:overworld run fill 427 67 -28 427 68 -28 dirt
execute in minecraft:overworld run setblock 427 69 -28 coarse_dirt
execute in minecraft:overworld run fill 427 70 -28 427 144 -28 air
execute in minecraft:overworld run fill 427 58 -27 427 66 -27 stone
execute in minecraft:overworld run fill 427 67 -27 427 68 -27 dirt
execute in minecraft:overworld run setblock 427 69 -27 coarse_dirt
execute in minecraft:overworld run fill 427 70 -27 427 144 -27 air
execute in minecraft:overworld run fill 427 58 -26 427 66 -26 stone
execute in minecraft:overworld run fill 427 67 -26 427 68 -26 dirt
execute in minecraft:overworld run setblock 427 69 -26 coarse_dirt
schedule function blade_gallery:random/battlefield/part_143 1t replace
