execute in minecraft:overworld run setblock 279 77 -23 coarse_dirt
execute in minecraft:overworld run fill 279 78 -23 279 144 -23 air
execute in minecraft:overworld run fill 279 58 -22 279 74 -22 stone
execute in minecraft:overworld run fill 279 75 -22 279 76 -22 dirt
execute in minecraft:overworld run setblock 279 77 -22 coarse_dirt
execute in minecraft:overworld run fill 279 78 -22 279 144 -22 air
execute in minecraft:overworld run fill 279 58 -21 279 74 -21 stone
execute in minecraft:overworld run fill 279 75 -21 279 76 -21 dirt
execute in minecraft:overworld run setblock 279 77 -21 coarse_dirt
execute in minecraft:overworld run fill 279 78 -21 279 144 -21 air
execute in minecraft:overworld run fill 279 58 -20 279 73 -20 stone
execute in minecraft:overworld run fill 279 74 -20 279 75 -20 dirt
execute in minecraft:overworld run setblock 279 76 -20 coarse_dirt
execute in minecraft:overworld run fill 279 77 -20 279 144 -20 air
execute in minecraft:overworld run fill 279 58 -19 279 73 -19 stone
execute in minecraft:overworld run fill 279 74 -19 279 75 -19 dirt
execute in minecraft:overworld run setblock 279 76 -19 grass_block
execute in minecraft:overworld run fill 279 77 -19 279 144 -19 air
execute in minecraft:overworld run fill 279 58 -18 279 73 -18 stone
execute in minecraft:overworld run fill 279 74 -18 279 75 -18 dirt
execute in minecraft:overworld run setblock 279 76 -18 coarse_dirt
execute in minecraft:overworld run fill 279 77 -18 279 144 -18 air
execute in minecraft:overworld run fill 279 58 -17 279 72 -17 stone
execute in minecraft:overworld run fill 279 73 -17 279 74 -17 dirt
execute in minecraft:overworld run setblock 279 75 -17 coarse_dirt
execute in minecraft:overworld run fill 279 76 -17 279 144 -17 air
execute in minecraft:overworld run fill 279 58 -16 279 71 -16 stone
execute in minecraft:overworld run fill 279 72 -16 279 73 -16 dirt
execute in minecraft:overworld run setblock 279 74 -16 coarse_dirt
execute in minecraft:overworld run fill 279 75 -16 279 144 -16 air
execute in minecraft:overworld run fill 279 58 -15 279 71 -15 stone
execute in minecraft:overworld run fill 279 72 -15 279 73 -15 dirt
execute in minecraft:overworld run setblock 279 74 -15 coarse_dirt
execute in minecraft:overworld run fill 279 75 -15 279 144 -15 air
execute in minecraft:overworld run fill 279 58 -14 279 70 -14 stone
execute in minecraft:overworld run fill 279 71 -14 279 72 -14 dirt
execute in minecraft:overworld run setblock 279 73 -14 grass_block
execute in minecraft:overworld run fill 279 74 -14 279 144 -14 air
execute in minecraft:overworld run fill 279 58 -13 279 69 -13 stone
execute in minecraft:overworld run fill 279 70 -13 279 71 -13 dirt
execute in minecraft:overworld run setblock 279 72 -13 grass_block
execute in minecraft:overworld run fill 279 73 -13 279 144 -13 air
execute in minecraft:overworld run fill 279 58 -12 279 68 -12 stone
execute in minecraft:overworld run fill 279 69 -12 279 70 -12 dirt
execute in minecraft:overworld run setblock 279 71 -12 grass_block
execute in minecraft:overworld run fill 279 72 -12 279 144 -12 air
execute in minecraft:overworld run fill 279 58 -11 279 68 -11 stone
execute in minecraft:overworld run fill 279 69 -11 279 70 -11 dirt
execute in minecraft:overworld run setblock 279 71 -11 grass_block
execute in minecraft:overworld run fill 279 72 -11 279 144 -11 air
execute in minecraft:overworld run fill 279 58 -10 279 68 -10 stone
execute in minecraft:overworld run fill 279 69 -10 279 70 -10 dirt
execute in minecraft:overworld run setblock 279 71 -10 grass_block
execute in minecraft:overworld run fill 279 72 -10 279 144 -10 air
execute in minecraft:overworld run setblock 279 72 -10 grass
execute in minecraft:overworld run fill 279 58 -9 279 68 -9 stone
execute in minecraft:overworld run fill 279 69 -9 279 70 -9 dirt
execute in minecraft:overworld run setblock 279 71 -9 coarse_dirt
execute in minecraft:overworld run fill 279 72 -9 279 144 -9 air
execute in minecraft:overworld run fill 279 58 -8 279 67 -8 stone
execute in minecraft:overworld run fill 279 68 -8 279 69 -8 dirt
execute in minecraft:overworld run setblock 279 70 -8 coarse_dirt
execute in minecraft:overworld run fill 279 71 -8 279 144 -8 air
execute in minecraft:overworld run fill 279 58 -7 279 67 -7 stone
execute in minecraft:overworld run fill 279 68 -7 279 69 -7 dirt
execute in minecraft:overworld run setblock 279 70 -7 grass_block
execute in minecraft:overworld run fill 279 71 -7 279 144 -7 air
execute in minecraft:overworld run fill 279 58 -6 279 67 -6 stone
execute in minecraft:overworld run fill 279 68 -6 279 69 -6 dirt
execute in minecraft:overworld run setblock 279 70 -6 coarse_dirt
execute in minecraft:overworld run fill 279 71 -6 279 144 -6 air
execute in minecraft:overworld run fill 279 58 -5 279 67 -5 stone
execute in minecraft:overworld run fill 279 68 -5 279 69 -5 dirt
execute in minecraft:overworld run setblock 279 70 -5 grass_block
execute in minecraft:overworld run fill 279 71 -5 279 144 -5 air
execute in minecraft:overworld run fill 279 58 -4 279 67 -4 stone
execute in minecraft:overworld run fill 279 68 -4 279 69 -4 dirt
execute in minecraft:overworld run setblock 279 70 -4 coarse_dirt
execute in minecraft:overworld run fill 279 71 -4 279 144 -4 air
execute in minecraft:overworld run fill 279 58 -3 279 67 -3 stone
execute in minecraft:overworld run fill 279 68 -3 279 69 -3 dirt
execute in minecraft:overworld run setblock 279 70 -3 grass_block
execute in minecraft:overworld run fill 279 71 -3 279 144 -3 air
execute in minecraft:overworld run fill 279 58 -2 279 67 -2 stone
execute in minecraft:overworld run fill 279 68 -2 279 69 -2 dirt
execute in minecraft:overworld run setblock 279 70 -2 coarse_dirt
execute in minecraft:overworld run fill 279 71 -2 279 144 -2 air
execute in minecraft:overworld run fill 279 58 -1 279 67 -1 stone
execute in minecraft:overworld run fill 279 68 -1 279 69 -1 dirt
execute in minecraft:overworld run setblock 279 70 -1 grass_block
execute in minecraft:overworld run fill 279 71 -1 279 144 -1 air
execute in minecraft:overworld run fill 279 58 0 279 67 0 stone
execute in minecraft:overworld run fill 279 68 0 279 69 0 dirt
execute in minecraft:overworld run setblock 279 70 0 grass_block
execute in minecraft:overworld run fill 279 71 0 279 144 0 air
execute in minecraft:overworld run fill 279 58 1 279 67 1 stone
execute in minecraft:overworld run fill 279 68 1 279 69 1 dirt
execute in minecraft:overworld run setblock 279 70 1 coarse_dirt
execute in minecraft:overworld run fill 279 71 1 279 144 1 air
execute in minecraft:overworld run setblock 279 71 1 grass
execute in minecraft:overworld run fill 279 58 2 279 67 2 stone
execute in minecraft:overworld run fill 279 68 2 279 69 2 dirt
execute in minecraft:overworld run setblock 279 70 2 coarse_dirt
execute in minecraft:overworld run fill 279 71 2 279 144 2 air
execute in minecraft:overworld run fill 279 58 3 279 67 3 stone
execute in minecraft:overworld run fill 279 68 3 279 69 3 dirt
execute in minecraft:overworld run setblock 279 70 3 grass_block
execute in minecraft:overworld run fill 279 71 3 279 144 3 air
execute in minecraft:overworld run fill 279 58 4 279 66 4 stone
execute in minecraft:overworld run fill 279 67 4 279 68 4 dirt
execute in minecraft:overworld run setblock 279 69 4 coarse_dirt
execute in minecraft:overworld run fill 279 70 4 279 144 4 air
execute in minecraft:overworld run fill 279 58 5 279 66 5 stone
execute in minecraft:overworld run fill 279 67 5 279 68 5 dirt
execute in minecraft:overworld run setblock 279 69 5 coarse_dirt
execute in minecraft:overworld run fill 279 70 5 279 144 5 air
execute in minecraft:overworld run fill 279 58 6 279 66 6 stone
execute in minecraft:overworld run fill 279 67 6 279 68 6 dirt
execute in minecraft:overworld run setblock 279 69 6 grass_block
execute in minecraft:overworld run fill 279 70 6 279 144 6 air
execute in minecraft:overworld run fill 279 58 7 279 65 7 stone
execute in minecraft:overworld run fill 279 66 7 279 67 7 dirt
execute in minecraft:overworld run setblock 279 68 7 coarse_dirt
execute in minecraft:overworld run fill 279 69 7 279 144 7 air
execute in minecraft:overworld run fill 279 58 8 279 65 8 stone
execute in minecraft:overworld run fill 279 66 8 279 67 8 dirt
execute in minecraft:overworld run setblock 279 68 8 grass_block
execute in minecraft:overworld run fill 279 69 8 279 144 8 air
execute in minecraft:overworld run fill 279 58 9 279 65 9 stone
execute in minecraft:overworld run fill 279 66 9 279 67 9 dirt
execute in minecraft:overworld run setblock 279 68 9 coarse_dirt
execute in minecraft:overworld run fill 279 69 9 279 144 9 air
execute in minecraft:overworld run fill 279 58 10 279 64 10 stone
execute in minecraft:overworld run fill 279 65 10 279 66 10 dirt
execute in minecraft:overworld run setblock 279 67 10 coarse_dirt
execute in minecraft:overworld run fill 279 68 10 279 144 10 air
execute in minecraft:overworld run fill 279 58 11 279 64 11 stone
execute in minecraft:overworld run fill 279 65 11 279 66 11 dirt
execute in minecraft:overworld run setblock 279 67 11 coarse_dirt
execute in minecraft:overworld run fill 279 68 11 279 144 11 air
execute in minecraft:overworld run fill 279 58 12 279 64 12 stone
execute in minecraft:overworld run fill 279 65 12 279 66 12 dirt
execute in minecraft:overworld run setblock 279 67 12 grass_block
execute in minecraft:overworld run fill 279 68 12 279 144 12 air
execute in minecraft:overworld run fill 279 58 13 279 64 13 stone
execute in minecraft:overworld run fill 279 65 13 279 66 13 dirt
execute in minecraft:overworld run setblock 279 67 13 grass_block
execute in minecraft:overworld run fill 279 68 13 279 144 13 air
execute in minecraft:overworld run fill 279 58 14 279 64 14 stone
execute in minecraft:overworld run fill 279 65 14 279 66 14 dirt
execute in minecraft:overworld run setblock 279 67 14 grass_block
execute in minecraft:overworld run fill 279 68 14 279 144 14 air
execute in minecraft:overworld run fill 279 58 15 279 64 15 stone
execute in minecraft:overworld run fill 279 65 15 279 66 15 dirt
execute in minecraft:overworld run setblock 279 67 15 coarse_dirt
execute in minecraft:overworld run fill 279 68 15 279 144 15 air
execute in minecraft:overworld run fill 279 58 16 279 64 16 stone
execute in minecraft:overworld run fill 279 65 16 279 66 16 dirt
execute in minecraft:overworld run setblock 279 67 16 coarse_dirt
execute in minecraft:overworld run fill 279 68 16 279 144 16 air
execute in minecraft:overworld run fill 279 58 17 279 64 17 stone
execute in minecraft:overworld run fill 279 65 17 279 66 17 dirt
execute in minecraft:overworld run setblock 279 67 17 grass_block
execute in minecraft:overworld run fill 279 68 17 279 144 17 air
execute in minecraft:overworld run fill 279 58 18 279 64 18 stone
execute in minecraft:overworld run fill 279 65 18 279 66 18 dirt
execute in minecraft:overworld run setblock 279 67 18 grass_block
execute in minecraft:overworld run fill 279 68 18 279 144 18 air
execute in minecraft:overworld run fill 279 58 19 279 63 19 stone
execute in minecraft:overworld run fill 279 64 19 279 65 19 dirt
execute in minecraft:overworld run setblock 279 66 19 coarse_dirt
execute in minecraft:overworld run fill 279 67 19 279 144 19 air
execute in minecraft:overworld run fill 279 58 20 279 63 20 stone
execute in minecraft:overworld run fill 279 64 20 279 65 20 dirt
execute in minecraft:overworld run setblock 279 66 20 grass_block
execute in minecraft:overworld run fill 279 67 20 279 144 20 air
execute in minecraft:overworld run fill 279 58 21 279 63 21 stone
execute in minecraft:overworld run fill 279 64 21 279 65 21 dirt
execute in minecraft:overworld run setblock 279 66 21 coarse_dirt
execute in minecraft:overworld run fill 279 67 21 279 144 21 air
execute in minecraft:overworld run fill 279 58 22 279 63 22 stone
execute in minecraft:overworld run fill 279 64 22 279 65 22 dirt
execute in minecraft:overworld run setblock 279 66 22 coarse_dirt
execute in minecraft:overworld run fill 279 67 22 279 144 22 air
execute in minecraft:overworld run fill 279 58 23 279 63 23 stone
execute in minecraft:overworld run fill 279 64 23 279 65 23 dirt
execute in minecraft:overworld run setblock 279 66 23 grass_block
execute in minecraft:overworld run fill 279 67 23 279 144 23 air
execute in minecraft:overworld run fill 279 58 24 279 63 24 stone
execute in minecraft:overworld run fill 279 64 24 279 65 24 dirt
execute in minecraft:overworld run setblock 279 66 24 grass_block
execute in minecraft:overworld run fill 279 67 24 279 144 24 air
execute in minecraft:overworld run fill 279 58 25 279 63 25 stone
execute in minecraft:overworld run fill 279 64 25 279 65 25 dirt
execute in minecraft:overworld run setblock 279 66 25 grass_block
execute in minecraft:overworld run fill 279 67 25 279 144 25 air
execute in minecraft:overworld run fill 279 58 26 279 63 26 stone
execute in minecraft:overworld run fill 279 64 26 279 65 26 dirt
execute in minecraft:overworld run setblock 279 66 26 coarse_dirt
execute in minecraft:overworld run fill 279 67 26 279 144 26 air
execute in minecraft:overworld run fill 279 58 27 279 63 27 stone
execute in minecraft:overworld run fill 279 64 27 279 65 27 dirt
execute in minecraft:overworld run setblock 279 66 27 grass_block
execute in minecraft:overworld run fill 279 67 27 279 144 27 air
execute in minecraft:overworld run setblock 279 67 27 mossy_cobblestone
execute in minecraft:overworld run fill 279 58 28 279 63 28 stone
execute in minecraft:overworld run fill 279 64 28 279 65 28 dirt
execute in minecraft:overworld run setblock 279 66 28 grass_block
execute in minecraft:overworld run fill 279 67 28 279 144 28 air
execute in minecraft:overworld run fill 279 58 29 279 63 29 stone
execute in minecraft:overworld run fill 279 64 29 279 65 29 dirt
execute in minecraft:overworld run setblock 279 66 29 grass_block
execute in minecraft:overworld run fill 279 67 29 279 144 29 air
execute in minecraft:overworld run fill 279 58 30 279 62 30 stone
execute in minecraft:overworld run fill 279 63 30 279 64 30 dirt
execute in minecraft:overworld run setblock 279 65 30 coarse_dirt
execute in minecraft:overworld run fill 279 66 30 279 144 30 air
execute in minecraft:overworld run fill 279 58 31 279 62 31 stone
execute in minecraft:overworld run fill 279 63 31 279 64 31 dirt
execute in minecraft:overworld run setblock 279 65 31 grass_block
execute in minecraft:overworld run fill 279 66 31 279 144 31 air
execute in minecraft:overworld run fill 279 58 32 279 62 32 stone
execute in minecraft:overworld run fill 279 63 32 279 64 32 dirt
execute in minecraft:overworld run setblock 279 65 32 grass_block
execute in minecraft:overworld run fill 279 66 32 279 144 32 air
execute in minecraft:overworld run fill 279 58 33 279 62 33 stone
execute in minecraft:overworld run fill 279 63 33 279 64 33 dirt
execute in minecraft:overworld run setblock 279 65 33 coarse_dirt
execute in minecraft:overworld run fill 279 66 33 279 144 33 air
execute in minecraft:overworld run fill 279 58 34 279 61 34 stone
execute in minecraft:overworld run fill 279 62 34 279 63 34 dirt
execute in minecraft:overworld run setblock 279 64 34 grass_block
execute in minecraft:overworld run fill 279 65 34 279 144 34 air
execute in minecraft:overworld run fill 279 58 35 279 61 35 stone
execute in minecraft:overworld run fill 279 62 35 279 63 35 dirt
execute in minecraft:overworld run setblock 279 64 35 grass_block
execute in minecraft:overworld run fill 279 65 35 279 144 35 air
execute in minecraft:overworld run fill 279 58 36 279 61 36 stone
execute in minecraft:overworld run fill 279 62 36 279 63 36 dirt
execute in minecraft:overworld run setblock 279 64 36 coarse_dirt
execute in minecraft:overworld run fill 279 65 36 279 144 36 air
execute in minecraft:overworld run fill 279 58 37 279 61 37 stone
execute in minecraft:overworld run fill 279 62 37 279 63 37 dirt
execute in minecraft:overworld run setblock 279 64 37 coarse_dirt
execute in minecraft:overworld run fill 279 65 37 279 144 37 air
execute in minecraft:overworld run fill 279 58 38 279 61 38 stone
execute in minecraft:overworld run fill 279 62 38 279 63 38 dirt
execute in minecraft:overworld run setblock 279 64 38 coarse_dirt
execute in minecraft:overworld run fill 279 65 38 279 144 38 air
execute in minecraft:overworld run fill 279 58 39 279 61 39 stone
execute in minecraft:overworld run fill 279 62 39 279 63 39 dirt
execute in minecraft:overworld run setblock 279 64 39 grass_block
execute in minecraft:overworld run fill 279 65 39 279 144 39 air
execute in minecraft:overworld run fill 279 58 40 279 61 40 stone
execute in minecraft:overworld run fill 279 62 40 279 63 40 dirt
execute in minecraft:overworld run setblock 279 64 40 coarse_dirt
schedule function blade_gallery:random/burned/part_114 1t replace
