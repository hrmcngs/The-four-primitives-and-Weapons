execute in minecraft:overworld run fill 394 58 25 394 59 25 dirt
execute in minecraft:overworld run setblock 394 60 25 gravel
execute in minecraft:overworld run fill 394 61 25 394 144 25 air
execute in minecraft:overworld run fill 394 61 25 394 64 25 water
execute in minecraft:overworld run fill 394 58 26 394 57 26 stone
execute in minecraft:overworld run fill 394 58 26 394 59 26 dirt
execute in minecraft:overworld run setblock 394 60 26 gravel
execute in minecraft:overworld run fill 394 61 26 394 144 26 air
execute in minecraft:overworld run fill 394 61 26 394 64 26 water
execute in minecraft:overworld run fill 394 58 27 394 57 27 stone
execute in minecraft:overworld run fill 394 58 27 394 59 27 dirt
execute in minecraft:overworld run setblock 394 60 27 gravel
execute in minecraft:overworld run fill 394 61 27 394 144 27 air
execute in minecraft:overworld run fill 394 61 27 394 64 27 water
execute in minecraft:overworld run fill 394 58 28 394 58 28 stone
execute in minecraft:overworld run fill 394 59 28 394 60 28 dirt
execute in minecraft:overworld run setblock 394 61 28 gravel
execute in minecraft:overworld run fill 394 62 28 394 144 28 air
execute in minecraft:overworld run fill 394 62 28 394 64 28 water
execute in minecraft:overworld run fill 394 58 29 394 58 29 stone
execute in minecraft:overworld run fill 394 59 29 394 60 29 dirt
execute in minecraft:overworld run setblock 394 61 29 gravel
execute in minecraft:overworld run fill 394 62 29 394 144 29 air
execute in minecraft:overworld run fill 394 62 29 394 64 29 water
execute in minecraft:overworld run fill 394 58 30 394 58 30 stone
execute in minecraft:overworld run fill 394 59 30 394 60 30 dirt
execute in minecraft:overworld run setblock 394 61 30 gravel
execute in minecraft:overworld run fill 394 62 30 394 144 30 air
execute in minecraft:overworld run fill 394 62 30 394 64 30 water
execute in minecraft:overworld run fill 394 58 31 394 58 31 stone
execute in minecraft:overworld run fill 394 59 31 394 60 31 dirt
execute in minecraft:overworld run setblock 394 61 31 gravel
execute in minecraft:overworld run fill 394 62 31 394 144 31 air
execute in minecraft:overworld run fill 394 62 31 394 64 31 water
execute in minecraft:overworld run fill 394 58 32 394 58 32 stone
execute in minecraft:overworld run fill 394 59 32 394 60 32 dirt
execute in minecraft:overworld run setblock 394 61 32 gravel
execute in minecraft:overworld run fill 394 62 32 394 144 32 air
execute in minecraft:overworld run fill 394 62 32 394 64 32 water
execute in minecraft:overworld run fill 394 58 33 394 59 33 stone
execute in minecraft:overworld run fill 394 60 33 394 61 33 dirt
execute in minecraft:overworld run setblock 394 62 33 gravel
execute in minecraft:overworld run fill 394 63 33 394 144 33 air
execute in minecraft:overworld run fill 394 63 33 394 64 33 water
execute in minecraft:overworld run fill 394 58 34 394 59 34 stone
execute in minecraft:overworld run fill 394 60 34 394 61 34 dirt
execute in minecraft:overworld run setblock 394 62 34 gravel
execute in minecraft:overworld run fill 394 63 34 394 144 34 air
execute in minecraft:overworld run fill 394 63 34 394 64 34 water
execute in minecraft:overworld run fill 394 58 35 394 60 35 stone
execute in minecraft:overworld run fill 394 61 35 394 62 35 dirt
execute in minecraft:overworld run setblock 394 63 35 gravel
execute in minecraft:overworld run fill 394 64 35 394 144 35 air
execute in minecraft:overworld run fill 394 64 35 394 64 35 water
execute in minecraft:overworld run fill 394 58 36 394 60 36 stone
execute in minecraft:overworld run fill 394 61 36 394 62 36 dirt
execute in minecraft:overworld run setblock 394 63 36 gravel
execute in minecraft:overworld run fill 394 64 36 394 144 36 air
execute in minecraft:overworld run fill 394 64 36 394 64 36 water
execute in minecraft:overworld run fill 394 58 37 394 61 37 stone
execute in minecraft:overworld run fill 394 62 37 394 63 37 dirt
execute in minecraft:overworld run setblock 394 64 37 grass_block
execute in minecraft:overworld run fill 394 65 37 394 144 37 air
execute in minecraft:overworld run fill 394 58 38 394 62 38 stone
execute in minecraft:overworld run fill 394 63 38 394 64 38 dirt
execute in minecraft:overworld run setblock 394 65 38 coarse_dirt
execute in minecraft:overworld run fill 394 66 38 394 144 38 air
execute in minecraft:overworld run fill 394 58 39 394 62 39 stone
execute in minecraft:overworld run fill 394 63 39 394 64 39 dirt
execute in minecraft:overworld run setblock 394 65 39 coarse_dirt
execute in minecraft:overworld run fill 394 66 39 394 144 39 air
execute in minecraft:overworld run setblock 394 66 39 grass
execute in minecraft:overworld run fill 394 58 40 394 63 40 stone
execute in minecraft:overworld run fill 394 64 40 394 65 40 dirt
execute in minecraft:overworld run setblock 394 66 40 coarse_dirt
execute in minecraft:overworld run fill 394 67 40 394 144 40 air
execute in minecraft:overworld run fill 394 58 41 394 63 41 stone
execute in minecraft:overworld run fill 394 64 41 394 65 41 dirt
execute in minecraft:overworld run setblock 394 66 41 grass_block
execute in minecraft:overworld run fill 394 67 41 394 144 41 air
execute in minecraft:overworld run fill 394 58 42 394 63 42 stone
execute in minecraft:overworld run fill 394 64 42 394 65 42 dirt
execute in minecraft:overworld run setblock 394 66 42 coarse_dirt
execute in minecraft:overworld run fill 394 67 42 394 144 42 air
execute in minecraft:overworld run fill 394 58 43 394 63 43 stone
execute in minecraft:overworld run fill 394 64 43 394 65 43 dirt
execute in minecraft:overworld run setblock 394 66 43 coarse_dirt
execute in minecraft:overworld run fill 394 67 43 394 144 43 air
execute in minecraft:overworld run fill 394 58 44 394 63 44 stone
execute in minecraft:overworld run fill 394 64 44 394 65 44 dirt
execute in minecraft:overworld run setblock 394 66 44 coarse_dirt
execute in minecraft:overworld run fill 394 67 44 394 144 44 air
execute in minecraft:overworld run fill 394 58 45 394 63 45 stone
execute in minecraft:overworld run fill 394 64 45 394 65 45 dirt
execute in minecraft:overworld run setblock 394 66 45 grass_block
execute in minecraft:overworld run fill 394 67 45 394 144 45 air
execute in minecraft:overworld run fill 394 58 46 394 62 46 stone
execute in minecraft:overworld run fill 394 63 46 394 64 46 dirt
execute in minecraft:overworld run setblock 394 65 46 coarse_dirt
execute in minecraft:overworld run fill 394 66 46 394 144 46 air
execute in minecraft:overworld run fill 394 58 47 394 62 47 stone
execute in minecraft:overworld run fill 394 63 47 394 64 47 dirt
execute in minecraft:overworld run setblock 394 65 47 grass_block
execute in minecraft:overworld run fill 394 66 47 394 144 47 air
execute in minecraft:overworld run fill 395 58 -48 395 61 -48 stone
execute in minecraft:overworld run fill 395 62 -48 395 63 -48 dirt
execute in minecraft:overworld run setblock 395 64 -48 coarse_dirt
execute in minecraft:overworld run fill 395 65 -48 395 144 -48 air
execute in minecraft:overworld run fill 395 58 -47 395 62 -47 stone
execute in minecraft:overworld run fill 395 63 -47 395 64 -47 dirt
execute in minecraft:overworld run setblock 395 65 -47 grass_block
execute in minecraft:overworld run fill 395 66 -47 395 144 -47 air
execute in minecraft:overworld run fill 395 58 -46 395 64 -46 stone
execute in minecraft:overworld run fill 395 65 -46 395 66 -46 dirt
execute in minecraft:overworld run setblock 395 67 -46 coarse_dirt
execute in minecraft:overworld run fill 395 68 -46 395 144 -46 air
execute in minecraft:overworld run fill 395 58 -45 395 65 -45 stone
execute in minecraft:overworld run fill 395 66 -45 395 67 -45 dirt
execute in minecraft:overworld run setblock 395 68 -45 grass_block
execute in minecraft:overworld run fill 395 69 -45 395 144 -45 air
execute in minecraft:overworld run fill 395 58 -44 395 66 -44 stone
execute in minecraft:overworld run fill 395 67 -44 395 68 -44 dirt
execute in minecraft:overworld run setblock 395 69 -44 coarse_dirt
execute in minecraft:overworld run fill 395 70 -44 395 144 -44 air
execute in minecraft:overworld run fill 395 58 -43 395 67 -43 stone
execute in minecraft:overworld run fill 395 68 -43 395 69 -43 dirt
execute in minecraft:overworld run setblock 395 70 -43 grass_block
execute in minecraft:overworld run fill 395 71 -43 395 144 -43 air
execute in minecraft:overworld run fill 395 58 -42 395 69 -42 stone
execute in minecraft:overworld run fill 395 70 -42 395 71 -42 dirt
execute in minecraft:overworld run setblock 395 72 -42 grass_block
execute in minecraft:overworld run fill 395 73 -42 395 144 -42 air
execute in minecraft:overworld run fill 395 58 -41 395 70 -41 stone
execute in minecraft:overworld run fill 395 71 -41 395 72 -41 dirt
execute in minecraft:overworld run setblock 395 73 -41 grass_block
execute in minecraft:overworld run fill 395 74 -41 395 144 -41 air
execute in minecraft:overworld run fill 395 58 -40 395 71 -40 stone
execute in minecraft:overworld run fill 395 72 -40 395 73 -40 dirt
execute in minecraft:overworld run setblock 395 74 -40 grass_block
execute in minecraft:overworld run fill 395 75 -40 395 144 -40 air
execute in minecraft:overworld run fill 395 58 -39 395 73 -39 stone
execute in minecraft:overworld run fill 395 74 -39 395 75 -39 dirt
execute in minecraft:overworld run setblock 395 76 -39 coarse_dirt
execute in minecraft:overworld run fill 395 77 -39 395 144 -39 air
execute in minecraft:overworld run setblock 395 77 -39 mossy_cobblestone
execute in minecraft:overworld run fill 395 58 -38 395 74 -38 stone
execute in minecraft:overworld run fill 395 75 -38 395 76 -38 dirt
execute in minecraft:overworld run setblock 395 77 -38 coarse_dirt
execute in minecraft:overworld run fill 395 78 -38 395 144 -38 air
execute in minecraft:overworld run fill 395 58 -37 395 74 -37 stone
execute in minecraft:overworld run fill 395 75 -37 395 76 -37 dirt
execute in minecraft:overworld run setblock 395 77 -37 grass_block
execute in minecraft:overworld run fill 395 78 -37 395 144 -37 air
execute in minecraft:overworld run fill 395 58 -36 395 74 -36 stone
execute in minecraft:overworld run fill 395 75 -36 395 76 -36 dirt
execute in minecraft:overworld run setblock 395 77 -36 coarse_dirt
execute in minecraft:overworld run fill 395 78 -36 395 144 -36 air
execute in minecraft:overworld run fill 395 58 -35 395 74 -35 stone
execute in minecraft:overworld run fill 395 75 -35 395 76 -35 dirt
execute in minecraft:overworld run setblock 395 77 -35 coarse_dirt
execute in minecraft:overworld run fill 395 78 -35 395 144 -35 air
execute in minecraft:overworld run fill 395 58 -34 395 74 -34 stone
execute in minecraft:overworld run fill 395 75 -34 395 76 -34 dirt
execute in minecraft:overworld run setblock 395 77 -34 coarse_dirt
execute in minecraft:overworld run fill 395 78 -34 395 144 -34 air
execute in minecraft:overworld run fill 395 58 -33 395 73 -33 stone
execute in minecraft:overworld run fill 395 74 -33 395 75 -33 dirt
execute in minecraft:overworld run setblock 395 76 -33 grass_block
execute in minecraft:overworld run fill 395 77 -33 395 144 -33 air
execute in minecraft:overworld run fill 395 58 -32 395 73 -32 stone
execute in minecraft:overworld run fill 395 74 -32 395 75 -32 dirt
execute in minecraft:overworld run setblock 395 76 -32 grass_block
execute in minecraft:overworld run fill 395 77 -32 395 144 -32 air
execute in minecraft:overworld run fill 395 58 -31 395 72 -31 stone
execute in minecraft:overworld run fill 395 73 -31 395 74 -31 dirt
execute in minecraft:overworld run setblock 395 75 -31 coarse_dirt
execute in minecraft:overworld run fill 395 76 -31 395 144 -31 air
execute in minecraft:overworld run fill 395 58 -30 395 72 -30 stone
execute in minecraft:overworld run fill 395 73 -30 395 74 -30 dirt
execute in minecraft:overworld run setblock 395 75 -30 grass_block
execute in minecraft:overworld run fill 395 76 -30 395 144 -30 air
execute in minecraft:overworld run fill 395 58 -29 395 71 -29 stone
execute in minecraft:overworld run fill 395 72 -29 395 73 -29 dirt
execute in minecraft:overworld run setblock 395 74 -29 coarse_dirt
execute in minecraft:overworld run fill 395 75 -29 395 144 -29 air
execute in minecraft:overworld run fill 395 58 -28 395 71 -28 stone
execute in minecraft:overworld run fill 395 72 -28 395 73 -28 dirt
execute in minecraft:overworld run setblock 395 74 -28 coarse_dirt
execute in minecraft:overworld run fill 395 75 -28 395 144 -28 air
execute in minecraft:overworld run fill 395 58 -27 395 70 -27 stone
execute in minecraft:overworld run fill 395 71 -27 395 72 -27 dirt
execute in minecraft:overworld run setblock 395 73 -27 coarse_dirt
execute in minecraft:overworld run fill 395 74 -27 395 144 -27 air
execute in minecraft:overworld run fill 395 58 -26 395 70 -26 stone
execute in minecraft:overworld run fill 395 71 -26 395 72 -26 dirt
execute in minecraft:overworld run setblock 395 73 -26 coarse_dirt
execute in minecraft:overworld run fill 395 74 -26 395 144 -26 air
execute in minecraft:overworld run fill 395 58 -25 395 69 -25 stone
execute in minecraft:overworld run fill 395 70 -25 395 71 -25 dirt
execute in minecraft:overworld run setblock 395 72 -25 grass_block
execute in minecraft:overworld run fill 395 73 -25 395 144 -25 air
execute in minecraft:overworld run fill 395 58 -24 395 69 -24 stone
execute in minecraft:overworld run fill 395 70 -24 395 71 -24 dirt
execute in minecraft:overworld run setblock 395 72 -24 grass_block
execute in minecraft:overworld run fill 395 73 -24 395 144 -24 air
execute in minecraft:overworld run fill 395 58 -23 395 69 -23 stone
execute in minecraft:overworld run fill 395 70 -23 395 71 -23 dirt
execute in minecraft:overworld run setblock 395 72 -23 grass_block
execute in minecraft:overworld run fill 395 73 -23 395 144 -23 air
execute in minecraft:overworld run fill 395 58 -22 395 68 -22 stone
execute in minecraft:overworld run fill 395 69 -22 395 70 -22 dirt
execute in minecraft:overworld run setblock 395 71 -22 coarse_dirt
execute in minecraft:overworld run fill 395 72 -22 395 144 -22 air
execute in minecraft:overworld run fill 395 58 -21 395 68 -21 stone
execute in minecraft:overworld run fill 395 69 -21 395 70 -21 dirt
execute in minecraft:overworld run setblock 395 71 -21 grass_block
execute in minecraft:overworld run fill 395 72 -21 395 144 -21 air
execute in minecraft:overworld run fill 395 58 -20 395 67 -20 stone
execute in minecraft:overworld run fill 395 68 -20 395 69 -20 dirt
execute in minecraft:overworld run setblock 395 70 -20 coarse_dirt
execute in minecraft:overworld run fill 395 71 -20 395 144 -20 air
execute in minecraft:overworld run fill 395 58 -19 395 66 -19 stone
execute in minecraft:overworld run fill 395 67 -19 395 68 -19 dirt
execute in minecraft:overworld run setblock 395 69 -19 coarse_dirt
execute in minecraft:overworld run fill 395 70 -19 395 144 -19 air
execute in minecraft:overworld run fill 395 58 -18 395 66 -18 stone
execute in minecraft:overworld run fill 395 67 -18 395 68 -18 dirt
execute in minecraft:overworld run setblock 395 69 -18 coarse_dirt
execute in minecraft:overworld run fill 395 70 -18 395 144 -18 air
execute in minecraft:overworld run fill 395 58 -17 395 65 -17 stone
execute in minecraft:overworld run fill 395 66 -17 395 67 -17 dirt
execute in minecraft:overworld run setblock 395 68 -17 coarse_dirt
execute in minecraft:overworld run fill 395 69 -17 395 144 -17 air
execute in minecraft:overworld run fill 395 58 -16 395 64 -16 stone
execute in minecraft:overworld run fill 395 65 -16 395 66 -16 dirt
execute in minecraft:overworld run setblock 395 67 -16 grass_block
execute in minecraft:overworld run fill 395 68 -16 395 144 -16 air
execute in minecraft:overworld run fill 395 58 -15 395 63 -15 stone
execute in minecraft:overworld run fill 395 64 -15 395 65 -15 dirt
execute in minecraft:overworld run setblock 395 66 -15 coarse_dirt
execute in minecraft:overworld run fill 395 67 -15 395 144 -15 air
execute in minecraft:overworld run fill 395 58 -14 395 62 -14 stone
execute in minecraft:overworld run fill 395 63 -14 395 64 -14 dirt
execute in minecraft:overworld run setblock 395 65 -14 coarse_dirt
execute in minecraft:overworld run fill 395 66 -14 395 144 -14 air
execute in minecraft:overworld run fill 395 58 -13 395 61 -13 stone
execute in minecraft:overworld run fill 395 62 -13 395 63 -13 dirt
execute in minecraft:overworld run setblock 395 64 -13 coarse_dirt
execute in minecraft:overworld run fill 395 65 -13 395 144 -13 air
execute in minecraft:overworld run fill 395 58 -12 395 60 -12 stone
execute in minecraft:overworld run fill 395 61 -12 395 62 -12 dirt
execute in minecraft:overworld run setblock 395 63 -12 gravel
execute in minecraft:overworld run fill 395 64 -12 395 144 -12 air
execute in minecraft:overworld run fill 395 64 -12 395 64 -12 water
execute in minecraft:overworld run fill 395 58 -11 395 59 -11 stone
execute in minecraft:overworld run fill 395 60 -11 395 61 -11 dirt
schedule function blade_gallery:random/battlefield/part_93 1t replace
