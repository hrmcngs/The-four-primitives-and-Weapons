execute in minecraft:overworld run setblock 420 75 -41 coarse_dirt
execute in minecraft:overworld run fill 420 76 -41 420 144 -41 air
execute in minecraft:overworld run fill 420 58 -40 420 73 -40 stone
execute in minecraft:overworld run fill 420 74 -40 420 75 -40 dirt
execute in minecraft:overworld run setblock 420 76 -40 coarse_dirt
execute in minecraft:overworld run fill 420 77 -40 420 144 -40 air
execute in minecraft:overworld run fill 420 58 -39 420 74 -39 stone
execute in minecraft:overworld run fill 420 75 -39 420 76 -39 dirt
execute in minecraft:overworld run setblock 420 77 -39 coarse_dirt
execute in minecraft:overworld run fill 420 78 -39 420 144 -39 air
execute in minecraft:overworld run fill 420 58 -38 420 76 -38 stone
execute in minecraft:overworld run fill 420 77 -38 420 78 -38 dirt
execute in minecraft:overworld run setblock 420 79 -38 coarse_dirt
execute in minecraft:overworld run fill 420 80 -38 420 144 -38 air
execute in minecraft:overworld run setblock 420 80 -38 grass
execute in minecraft:overworld run fill 420 58 -37 420 75 -37 stone
execute in minecraft:overworld run fill 420 76 -37 420 77 -37 dirt
execute in minecraft:overworld run setblock 420 78 -37 coarse_dirt
execute in minecraft:overworld run fill 420 79 -37 420 144 -37 air
execute in minecraft:overworld run fill 420 58 -36 420 75 -36 stone
execute in minecraft:overworld run fill 420 76 -36 420 77 -36 dirt
execute in minecraft:overworld run setblock 420 78 -36 coarse_dirt
execute in minecraft:overworld run fill 420 79 -36 420 144 -36 air
execute in minecraft:overworld run fill 420 58 -35 420 74 -35 stone
execute in minecraft:overworld run fill 420 75 -35 420 76 -35 dirt
execute in minecraft:overworld run setblock 420 77 -35 coarse_dirt
execute in minecraft:overworld run fill 420 78 -35 420 144 -35 air
execute in minecraft:overworld run fill 420 58 -34 420 74 -34 stone
execute in minecraft:overworld run fill 420 75 -34 420 76 -34 dirt
execute in minecraft:overworld run setblock 420 77 -34 coarse_dirt
execute in minecraft:overworld run fill 420 78 -34 420 144 -34 air
execute in minecraft:overworld run setblock 420 78 -34 grass
execute in minecraft:overworld run fill 420 58 -33 420 73 -33 stone
execute in minecraft:overworld run fill 420 74 -33 420 75 -33 dirt
execute in minecraft:overworld run setblock 420 76 -33 coarse_dirt
execute in minecraft:overworld run fill 420 77 -33 420 144 -33 air
execute in minecraft:overworld run setblock 420 77 -33 grass
execute in minecraft:overworld run fill 420 58 -32 420 73 -32 stone
execute in minecraft:overworld run fill 420 74 -32 420 75 -32 dirt
execute in minecraft:overworld run setblock 420 76 -32 coarse_dirt
execute in minecraft:overworld run fill 420 77 -32 420 144 -32 air
execute in minecraft:overworld run fill 420 58 -31 420 73 -31 stone
execute in minecraft:overworld run fill 420 74 -31 420 75 -31 dirt
execute in minecraft:overworld run setblock 420 76 -31 grass_block
execute in minecraft:overworld run fill 420 77 -31 420 144 -31 air
execute in minecraft:overworld run fill 420 58 -30 420 72 -30 stone
execute in minecraft:overworld run fill 420 73 -30 420 74 -30 dirt
execute in minecraft:overworld run setblock 420 75 -30 coarse_dirt
execute in minecraft:overworld run fill 420 76 -30 420 144 -30 air
execute in minecraft:overworld run fill 420 58 -29 420 72 -29 stone
execute in minecraft:overworld run fill 420 73 -29 420 74 -29 dirt
execute in minecraft:overworld run setblock 420 75 -29 coarse_dirt
execute in minecraft:overworld run fill 420 76 -29 420 144 -29 air
execute in minecraft:overworld run fill 420 58 -28 420 71 -28 stone
execute in minecraft:overworld run fill 420 72 -28 420 73 -28 dirt
execute in minecraft:overworld run setblock 420 74 -28 coarse_dirt
execute in minecraft:overworld run fill 420 75 -28 420 144 -28 air
execute in minecraft:overworld run fill 420 58 -27 420 71 -27 stone
execute in minecraft:overworld run fill 420 72 -27 420 73 -27 dirt
execute in minecraft:overworld run setblock 420 74 -27 grass_block
execute in minecraft:overworld run fill 420 75 -27 420 144 -27 air
execute in minecraft:overworld run fill 420 58 -26 420 71 -26 stone
execute in minecraft:overworld run fill 420 72 -26 420 73 -26 dirt
execute in minecraft:overworld run setblock 420 74 -26 coarse_dirt
execute in minecraft:overworld run fill 420 75 -26 420 144 -26 air
execute in minecraft:overworld run fill 420 58 -25 420 70 -25 stone
execute in minecraft:overworld run fill 420 71 -25 420 72 -25 dirt
execute in minecraft:overworld run setblock 420 73 -25 coarse_dirt
execute in minecraft:overworld run fill 420 74 -25 420 144 -25 air
execute in minecraft:overworld run fill 420 58 -24 420 70 -24 stone
execute in minecraft:overworld run fill 420 71 -24 420 72 -24 dirt
execute in minecraft:overworld run setblock 420 73 -24 coarse_dirt
execute in minecraft:overworld run fill 420 74 -24 420 144 -24 air
execute in minecraft:overworld run fill 420 58 -23 420 70 -23 stone
execute in minecraft:overworld run fill 420 71 -23 420 72 -23 dirt
execute in minecraft:overworld run setblock 420 73 -23 coarse_dirt
execute in minecraft:overworld run fill 420 74 -23 420 144 -23 air
execute in minecraft:overworld run fill 420 58 -22 420 69 -22 stone
execute in minecraft:overworld run fill 420 70 -22 420 71 -22 dirt
execute in minecraft:overworld run setblock 420 72 -22 grass_block
execute in minecraft:overworld run fill 420 73 -22 420 144 -22 air
execute in minecraft:overworld run fill 420 58 -21 420 69 -21 stone
execute in minecraft:overworld run fill 420 70 -21 420 71 -21 dirt
execute in minecraft:overworld run setblock 420 72 -21 grass_block
execute in minecraft:overworld run fill 420 73 -21 420 144 -21 air
execute in minecraft:overworld run fill 420 58 -20 420 69 -20 stone
execute in minecraft:overworld run fill 420 70 -20 420 71 -20 dirt
execute in minecraft:overworld run setblock 420 72 -20 grass_block
execute in minecraft:overworld run fill 420 73 -20 420 144 -20 air
execute in minecraft:overworld run fill 420 58 -19 420 68 -19 stone
execute in minecraft:overworld run fill 420 69 -19 420 70 -19 dirt
execute in minecraft:overworld run setblock 420 71 -19 coarse_dirt
execute in minecraft:overworld run fill 420 72 -19 420 144 -19 air
execute in minecraft:overworld run fill 420 58 -18 420 68 -18 stone
execute in minecraft:overworld run fill 420 69 -18 420 70 -18 dirt
execute in minecraft:overworld run setblock 420 71 -18 coarse_dirt
execute in minecraft:overworld run fill 420 72 -18 420 144 -18 air
execute in minecraft:overworld run fill 420 58 -17 420 68 -17 stone
execute in minecraft:overworld run fill 420 69 -17 420 70 -17 dirt
execute in minecraft:overworld run setblock 420 71 -17 grass_block
execute in minecraft:overworld run fill 420 72 -17 420 144 -17 air
execute in minecraft:overworld run fill 420 58 -16 420 67 -16 stone
execute in minecraft:overworld run fill 420 68 -16 420 69 -16 dirt
execute in minecraft:overworld run setblock 420 70 -16 coarse_dirt
execute in minecraft:overworld run fill 420 71 -16 420 144 -16 air
execute in minecraft:overworld run fill 420 58 -15 420 67 -15 stone
execute in minecraft:overworld run fill 420 68 -15 420 69 -15 dirt
execute in minecraft:overworld run setblock 420 70 -15 grass_block
execute in minecraft:overworld run fill 420 71 -15 420 144 -15 air
execute in minecraft:overworld run fill 420 58 -14 420 66 -14 stone
execute in minecraft:overworld run fill 420 67 -14 420 68 -14 dirt
execute in minecraft:overworld run setblock 420 69 -14 grass_block
execute in minecraft:overworld run fill 420 70 -14 420 144 -14 air
execute in minecraft:overworld run fill 420 58 -13 420 66 -13 stone
execute in minecraft:overworld run fill 420 67 -13 420 68 -13 dirt
execute in minecraft:overworld run setblock 420 69 -13 coarse_dirt
execute in minecraft:overworld run fill 420 70 -13 420 144 -13 air
execute in minecraft:overworld run fill 420 58 -12 420 65 -12 stone
execute in minecraft:overworld run fill 420 66 -12 420 67 -12 dirt
execute in minecraft:overworld run setblock 420 68 -12 coarse_dirt
execute in minecraft:overworld run fill 420 69 -12 420 144 -12 air
execute in minecraft:overworld run fill 420 58 -11 420 65 -11 stone
execute in minecraft:overworld run fill 420 66 -11 420 67 -11 dirt
execute in minecraft:overworld run setblock 420 68 -11 grass_block
execute in minecraft:overworld run fill 420 69 -11 420 144 -11 air
execute in minecraft:overworld run setblock 420 69 -11 grass
execute in minecraft:overworld run fill 420 58 -10 420 65 -10 stone
execute in minecraft:overworld run fill 420 66 -10 420 67 -10 dirt
execute in minecraft:overworld run setblock 420 68 -10 coarse_dirt
execute in minecraft:overworld run fill 420 69 -10 420 144 -10 air
execute in minecraft:overworld run setblock 420 69 -10 grass
execute in minecraft:overworld run fill 420 58 -9 420 65 -9 stone
execute in minecraft:overworld run fill 420 66 -9 420 67 -9 dirt
execute in minecraft:overworld run setblock 420 68 -9 coarse_dirt
execute in minecraft:overworld run fill 420 69 -9 420 144 -9 air
execute in minecraft:overworld run fill 420 58 -8 420 65 -8 stone
execute in minecraft:overworld run fill 420 66 -8 420 67 -8 dirt
execute in minecraft:overworld run setblock 420 68 -8 grass_block
execute in minecraft:overworld run fill 420 69 -8 420 144 -8 air
execute in minecraft:overworld run fill 420 58 -7 420 65 -7 stone
execute in minecraft:overworld run fill 420 66 -7 420 67 -7 dirt
execute in minecraft:overworld run setblock 420 68 -7 coarse_dirt
execute in minecraft:overworld run fill 420 69 -7 420 144 -7 air
execute in minecraft:overworld run setblock 420 69 -7 grass
execute in minecraft:overworld run fill 420 58 -6 420 65 -6 stone
execute in minecraft:overworld run fill 420 66 -6 420 67 -6 dirt
execute in minecraft:overworld run setblock 420 68 -6 coarse_dirt
execute in minecraft:overworld run fill 420 69 -6 420 144 -6 air
execute in minecraft:overworld run fill 420 58 -5 420 64 -5 stone
execute in minecraft:overworld run fill 420 65 -5 420 66 -5 dirt
execute in minecraft:overworld run setblock 420 67 -5 grass_block
execute in minecraft:overworld run fill 420 68 -5 420 144 -5 air
execute in minecraft:overworld run fill 420 58 -4 420 64 -4 stone
execute in minecraft:overworld run fill 420 65 -4 420 66 -4 dirt
execute in minecraft:overworld run setblock 420 67 -4 coarse_dirt
execute in minecraft:overworld run fill 420 68 -4 420 144 -4 air
execute in minecraft:overworld run fill 420 58 -3 420 64 -3 stone
execute in minecraft:overworld run fill 420 65 -3 420 66 -3 dirt
execute in minecraft:overworld run setblock 420 67 -3 coarse_dirt
execute in minecraft:overworld run fill 420 68 -3 420 144 -3 air
execute in minecraft:overworld run fill 420 58 -2 420 64 -2 stone
execute in minecraft:overworld run fill 420 65 -2 420 66 -2 dirt
execute in minecraft:overworld run setblock 420 67 -2 coarse_dirt
execute in minecraft:overworld run fill 420 68 -2 420 144 -2 air
execute in minecraft:overworld run fill 420 58 -1 420 63 -1 stone
execute in minecraft:overworld run fill 420 64 -1 420 65 -1 dirt
execute in minecraft:overworld run setblock 420 66 -1 coarse_dirt
execute in minecraft:overworld run fill 420 67 -1 420 144 -1 air
execute in minecraft:overworld run fill 420 58 0 420 63 0 stone
execute in minecraft:overworld run fill 420 64 0 420 65 0 dirt
execute in minecraft:overworld run setblock 420 66 0 grass_block
execute in minecraft:overworld run fill 420 67 0 420 144 0 air
execute in minecraft:overworld run fill 420 58 1 420 63 1 stone
execute in minecraft:overworld run fill 420 64 1 420 65 1 dirt
execute in minecraft:overworld run setblock 420 66 1 grass_block
execute in minecraft:overworld run fill 420 67 1 420 144 1 air
execute in minecraft:overworld run fill 420 58 2 420 64 2 stone
execute in minecraft:overworld run fill 420 65 2 420 66 2 dirt
execute in minecraft:overworld run setblock 420 67 2 coarse_dirt
execute in minecraft:overworld run fill 420 68 2 420 144 2 air
execute in minecraft:overworld run fill 420 58 3 420 64 3 stone
execute in minecraft:overworld run fill 420 65 3 420 66 3 dirt
execute in minecraft:overworld run setblock 420 67 3 grass_block
execute in minecraft:overworld run fill 420 68 3 420 144 3 air
execute in minecraft:overworld run setblock 420 68 3 grass
execute in minecraft:overworld run fill 420 58 4 420 64 4 stone
execute in minecraft:overworld run fill 420 65 4 420 66 4 dirt
execute in minecraft:overworld run setblock 420 67 4 coarse_dirt
execute in minecraft:overworld run fill 420 68 4 420 144 4 air
execute in minecraft:overworld run fill 420 58 5 420 64 5 stone
execute in minecraft:overworld run fill 420 65 5 420 66 5 dirt
execute in minecraft:overworld run setblock 420 67 5 grass_block
execute in minecraft:overworld run fill 420 68 5 420 144 5 air
execute in minecraft:overworld run fill 420 58 6 420 65 6 stone
execute in minecraft:overworld run fill 420 66 6 420 67 6 dirt
execute in minecraft:overworld run setblock 420 68 6 coarse_dirt
execute in minecraft:overworld run fill 420 69 6 420 144 6 air
execute in minecraft:overworld run fill 420 58 7 420 65 7 stone
execute in minecraft:overworld run fill 420 66 7 420 67 7 dirt
execute in minecraft:overworld run setblock 420 68 7 grass_block
execute in minecraft:overworld run fill 420 69 7 420 144 7 air
execute in minecraft:overworld run fill 420 58 8 420 65 8 stone
execute in minecraft:overworld run fill 420 66 8 420 67 8 dirt
execute in minecraft:overworld run setblock 420 68 8 coarse_dirt
execute in minecraft:overworld run fill 420 69 8 420 144 8 air
execute in minecraft:overworld run fill 420 58 9 420 66 9 stone
execute in minecraft:overworld run fill 420 67 9 420 68 9 dirt
execute in minecraft:overworld run setblock 420 69 9 coarse_dirt
execute in minecraft:overworld run fill 420 70 9 420 144 9 air
execute in minecraft:overworld run fill 420 58 10 420 66 10 stone
execute in minecraft:overworld run fill 420 67 10 420 68 10 dirt
execute in minecraft:overworld run setblock 420 69 10 coarse_dirt
execute in minecraft:overworld run fill 420 70 10 420 144 10 air
execute in minecraft:overworld run fill 420 58 11 420 66 11 stone
execute in minecraft:overworld run fill 420 67 11 420 68 11 dirt
execute in minecraft:overworld run setblock 420 69 11 coarse_dirt
execute in minecraft:overworld run fill 420 70 11 420 144 11 air
execute in minecraft:overworld run fill 420 58 12 420 67 12 stone
execute in minecraft:overworld run fill 420 68 12 420 69 12 dirt
execute in minecraft:overworld run setblock 420 70 12 coarse_dirt
execute in minecraft:overworld run fill 420 71 12 420 144 12 air
execute in minecraft:overworld run fill 420 58 13 420 67 13 stone
execute in minecraft:overworld run fill 420 68 13 420 69 13 dirt
execute in minecraft:overworld run setblock 420 70 13 coarse_dirt
execute in minecraft:overworld run fill 420 71 13 420 144 13 air
execute in minecraft:overworld run fill 420 58 14 420 68 14 stone
execute in minecraft:overworld run fill 420 69 14 420 70 14 dirt
execute in minecraft:overworld run setblock 420 71 14 coarse_dirt
execute in minecraft:overworld run fill 420 72 14 420 144 14 air
execute in minecraft:overworld run fill 420 58 15 420 68 15 stone
execute in minecraft:overworld run fill 420 69 15 420 70 15 dirt
execute in minecraft:overworld run setblock 420 71 15 coarse_dirt
execute in minecraft:overworld run fill 420 72 15 420 144 15 air
execute in minecraft:overworld run fill 420 58 16 420 69 16 stone
execute in minecraft:overworld run fill 420 70 16 420 71 16 dirt
execute in minecraft:overworld run setblock 420 72 16 coarse_dirt
execute in minecraft:overworld run fill 420 73 16 420 144 16 air
execute in minecraft:overworld run fill 420 58 17 420 69 17 stone
execute in minecraft:overworld run fill 420 70 17 420 71 17 dirt
execute in minecraft:overworld run setblock 420 72 17 grass_block
execute in minecraft:overworld run fill 420 73 17 420 144 17 air
execute in minecraft:overworld run fill 420 58 18 420 69 18 stone
execute in minecraft:overworld run fill 420 70 18 420 71 18 dirt
execute in minecraft:overworld run setblock 420 72 18 coarse_dirt
execute in minecraft:overworld run fill 420 73 18 420 144 18 air
execute in minecraft:overworld run fill 420 58 19 420 70 19 stone
execute in minecraft:overworld run fill 420 71 19 420 72 19 dirt
execute in minecraft:overworld run setblock 420 73 19 grass_block
execute in minecraft:overworld run fill 420 74 19 420 144 19 air
execute in minecraft:overworld run fill 420 58 20 420 70 20 stone
execute in minecraft:overworld run fill 420 71 20 420 72 20 dirt
execute in minecraft:overworld run setblock 420 73 20 coarse_dirt
execute in minecraft:overworld run fill 420 74 20 420 144 20 air
execute in minecraft:overworld run setblock 420 74 20 grass
execute in minecraft:overworld run fill 420 58 21 420 70 21 stone
execute in minecraft:overworld run fill 420 71 21 420 72 21 dirt
schedule function blade_gallery:random/battlefield/part_133 1t replace
