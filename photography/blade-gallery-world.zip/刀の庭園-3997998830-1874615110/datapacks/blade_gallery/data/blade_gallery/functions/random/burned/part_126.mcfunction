execute in minecraft:overworld run fill 287 69 19 287 144 19 air
execute in minecraft:overworld run setblock 287 69 19 grass
execute in minecraft:overworld run fill 287 58 20 287 64 20 stone
execute in minecraft:overworld run fill 287 65 20 287 66 20 dirt
execute in minecraft:overworld run setblock 287 67 20 coarse_dirt
execute in minecraft:overworld run fill 287 68 20 287 144 20 air
execute in minecraft:overworld run setblock 287 68 20 grass
execute in minecraft:overworld run fill 287 58 21 287 64 21 stone
execute in minecraft:overworld run fill 287 65 21 287 66 21 dirt
execute in minecraft:overworld run setblock 287 67 21 grass_block
execute in minecraft:overworld run fill 287 68 21 287 144 21 air
execute in minecraft:overworld run fill 287 58 22 287 64 22 stone
execute in minecraft:overworld run fill 287 65 22 287 66 22 dirt
execute in minecraft:overworld run setblock 287 67 22 grass_block
execute in minecraft:overworld run fill 287 68 22 287 144 22 air
execute in minecraft:overworld run fill 287 58 23 287 64 23 stone
execute in minecraft:overworld run fill 287 65 23 287 66 23 dirt
execute in minecraft:overworld run setblock 287 67 23 coarse_dirt
execute in minecraft:overworld run fill 287 68 23 287 144 23 air
execute in minecraft:overworld run setblock 287 68 23 grass
execute in minecraft:overworld run fill 287 58 24 287 65 24 stone
execute in minecraft:overworld run fill 287 66 24 287 67 24 dirt
execute in minecraft:overworld run setblock 287 68 24 grass_block
execute in minecraft:overworld run fill 287 69 24 287 144 24 air
execute in minecraft:overworld run fill 287 58 25 287 65 25 stone
execute in minecraft:overworld run fill 287 66 25 287 67 25 dirt
execute in minecraft:overworld run setblock 287 68 25 coarse_dirt
execute in minecraft:overworld run fill 287 69 25 287 144 25 air
execute in minecraft:overworld run fill 287 58 26 287 65 26 stone
execute in minecraft:overworld run fill 287 66 26 287 67 26 dirt
execute in minecraft:overworld run setblock 287 68 26 coarse_dirt
execute in minecraft:overworld run fill 287 69 26 287 144 26 air
execute in minecraft:overworld run fill 287 58 27 287 65 27 stone
execute in minecraft:overworld run fill 287 66 27 287 67 27 dirt
execute in minecraft:overworld run setblock 287 68 27 coarse_dirt
execute in minecraft:overworld run fill 287 69 27 287 144 27 air
execute in minecraft:overworld run fill 287 58 28 287 64 28 stone
execute in minecraft:overworld run fill 287 65 28 287 66 28 dirt
execute in minecraft:overworld run setblock 287 67 28 grass_block
execute in minecraft:overworld run fill 287 68 28 287 144 28 air
execute in minecraft:overworld run fill 287 58 29 287 64 29 stone
execute in minecraft:overworld run fill 287 65 29 287 66 29 dirt
execute in minecraft:overworld run setblock 287 67 29 grass_block
execute in minecraft:overworld run fill 287 68 29 287 144 29 air
execute in minecraft:overworld run fill 287 58 30 287 64 30 stone
execute in minecraft:overworld run fill 287 65 30 287 66 30 dirt
execute in minecraft:overworld run setblock 287 67 30 coarse_dirt
execute in minecraft:overworld run fill 287 68 30 287 144 30 air
execute in minecraft:overworld run fill 287 58 31 287 64 31 stone
execute in minecraft:overworld run fill 287 65 31 287 66 31 dirt
execute in minecraft:overworld run setblock 287 67 31 grass_block
execute in minecraft:overworld run fill 287 68 31 287 144 31 air
execute in minecraft:overworld run fill 287 58 32 287 63 32 stone
execute in minecraft:overworld run fill 287 64 32 287 65 32 dirt
execute in minecraft:overworld run setblock 287 66 32 coarse_dirt
execute in minecraft:overworld run fill 287 67 32 287 144 32 air
execute in minecraft:overworld run fill 287 58 33 287 63 33 stone
execute in minecraft:overworld run fill 287 64 33 287 65 33 dirt
execute in minecraft:overworld run setblock 287 66 33 coarse_dirt
execute in minecraft:overworld run fill 287 67 33 287 144 33 air
execute in minecraft:overworld run fill 287 58 34 287 62 34 stone
execute in minecraft:overworld run fill 287 63 34 287 64 34 dirt
execute in minecraft:overworld run setblock 287 65 34 grass_block
execute in minecraft:overworld run fill 287 66 34 287 144 34 air
execute in minecraft:overworld run fill 287 58 35 287 62 35 stone
execute in minecraft:overworld run fill 287 63 35 287 64 35 dirt
execute in minecraft:overworld run setblock 287 65 35 coarse_dirt
execute in minecraft:overworld run fill 287 66 35 287 144 35 air
execute in minecraft:overworld run fill 287 58 36 287 62 36 stone
execute in minecraft:overworld run fill 287 63 36 287 64 36 dirt
execute in minecraft:overworld run setblock 287 65 36 grass_block
execute in minecraft:overworld run fill 287 66 36 287 144 36 air
execute in minecraft:overworld run fill 287 58 37 287 62 37 stone
execute in minecraft:overworld run fill 287 63 37 287 64 37 dirt
execute in minecraft:overworld run setblock 287 65 37 coarse_dirt
execute in minecraft:overworld run fill 287 66 37 287 144 37 air
execute in minecraft:overworld run fill 287 58 38 287 62 38 stone
execute in minecraft:overworld run fill 287 63 38 287 64 38 dirt
execute in minecraft:overworld run setblock 287 65 38 coarse_dirt
execute in minecraft:overworld run fill 287 66 38 287 144 38 air
execute in minecraft:overworld run fill 287 58 39 287 62 39 stone
execute in minecraft:overworld run fill 287 63 39 287 64 39 dirt
execute in minecraft:overworld run setblock 287 65 39 coarse_dirt
execute in minecraft:overworld run fill 287 66 39 287 144 39 air
execute in minecraft:overworld run setblock 287 66 39 grass
execute in minecraft:overworld run fill 287 58 40 287 62 40 stone
execute in minecraft:overworld run fill 287 63 40 287 64 40 dirt
execute in minecraft:overworld run setblock 287 65 40 coarse_dirt
execute in minecraft:overworld run fill 287 66 40 287 144 40 air
execute in minecraft:overworld run fill 287 58 41 287 62 41 stone
execute in minecraft:overworld run fill 287 63 41 287 64 41 dirt
execute in minecraft:overworld run setblock 287 65 41 grass_block
execute in minecraft:overworld run fill 287 66 41 287 144 41 air
execute in minecraft:overworld run fill 287 58 42 287 62 42 stone
execute in minecraft:overworld run fill 287 63 42 287 64 42 dirt
execute in minecraft:overworld run setblock 287 65 42 grass_block
execute in minecraft:overworld run fill 287 66 42 287 144 42 air
execute in minecraft:overworld run fill 287 58 43 287 62 43 stone
execute in minecraft:overworld run fill 287 63 43 287 64 43 dirt
execute in minecraft:overworld run setblock 287 65 43 coarse_dirt
execute in minecraft:overworld run fill 287 66 43 287 144 43 air
execute in minecraft:overworld run fill 287 58 44 287 62 44 stone
execute in minecraft:overworld run fill 287 63 44 287 64 44 dirt
execute in minecraft:overworld run setblock 287 65 44 coarse_dirt
execute in minecraft:overworld run fill 287 66 44 287 144 44 air
execute in minecraft:overworld run fill 287 58 45 287 62 45 stone
execute in minecraft:overworld run fill 287 63 45 287 64 45 dirt
execute in minecraft:overworld run setblock 287 65 45 grass_block
execute in minecraft:overworld run fill 287 66 45 287 144 45 air
execute in minecraft:overworld run fill 287 58 46 287 61 46 stone
execute in minecraft:overworld run fill 287 62 46 287 63 46 dirt
execute in minecraft:overworld run setblock 287 64 46 coarse_dirt
execute in minecraft:overworld run fill 287 65 46 287 144 46 air
execute in minecraft:overworld run fill 287 58 47 287 61 47 stone
execute in minecraft:overworld run fill 287 62 47 287 63 47 dirt
execute in minecraft:overworld run setblock 287 64 47 coarse_dirt
execute in minecraft:overworld run fill 287 65 47 287 144 47 air
execute in minecraft:overworld run fill 288 58 -48 288 61 -48 stone
execute in minecraft:overworld run fill 288 62 -48 288 63 -48 dirt
execute in minecraft:overworld run setblock 288 64 -48 coarse_dirt
execute in minecraft:overworld run fill 288 65 -48 288 144 -48 air
execute in minecraft:overworld run fill 288 58 -47 288 63 -47 stone
execute in minecraft:overworld run fill 288 64 -47 288 65 -47 dirt
execute in minecraft:overworld run setblock 288 66 -47 coarse_dirt
execute in minecraft:overworld run fill 288 67 -47 288 144 -47 air
execute in minecraft:overworld run fill 288 58 -46 288 65 -46 stone
execute in minecraft:overworld run fill 288 66 -46 288 67 -46 dirt
execute in minecraft:overworld run setblock 288 68 -46 coarse_dirt
execute in minecraft:overworld run fill 288 69 -46 288 144 -46 air
execute in minecraft:overworld run fill 288 58 -45 288 67 -45 stone
execute in minecraft:overworld run fill 288 68 -45 288 69 -45 dirt
execute in minecraft:overworld run setblock 288 70 -45 coarse_dirt
execute in minecraft:overworld run fill 288 71 -45 288 144 -45 air
execute in minecraft:overworld run fill 288 58 -44 288 69 -44 stone
execute in minecraft:overworld run fill 288 70 -44 288 71 -44 dirt
execute in minecraft:overworld run setblock 288 72 -44 coarse_dirt
execute in minecraft:overworld run fill 288 73 -44 288 144 -44 air
execute in minecraft:overworld run fill 288 58 -43 288 70 -43 stone
execute in minecraft:overworld run fill 288 71 -43 288 72 -43 dirt
execute in minecraft:overworld run setblock 288 73 -43 coarse_dirt
execute in minecraft:overworld run fill 288 74 -43 288 144 -43 air
execute in minecraft:overworld run fill 288 58 -42 288 72 -42 stone
execute in minecraft:overworld run fill 288 73 -42 288 74 -42 dirt
execute in minecraft:overworld run setblock 288 75 -42 grass_block
execute in minecraft:overworld run fill 288 76 -42 288 144 -42 air
execute in minecraft:overworld run fill 288 58 -41 288 74 -41 stone
execute in minecraft:overworld run fill 288 75 -41 288 76 -41 dirt
execute in minecraft:overworld run setblock 288 77 -41 coarse_dirt
execute in minecraft:overworld run fill 288 78 -41 288 144 -41 air
execute in minecraft:overworld run fill 288 58 -40 288 76 -40 stone
execute in minecraft:overworld run fill 288 77 -40 288 78 -40 dirt
execute in minecraft:overworld run setblock 288 79 -40 grass_block
execute in minecraft:overworld run fill 288 80 -40 288 144 -40 air
execute in minecraft:overworld run setblock 288 80 -40 grass
execute in minecraft:overworld run fill 288 58 -39 288 77 -39 stone
execute in minecraft:overworld run fill 288 78 -39 288 79 -39 dirt
execute in minecraft:overworld run setblock 288 80 -39 grass_block
execute in minecraft:overworld run fill 288 81 -39 288 144 -39 air
execute in minecraft:overworld run fill 288 58 -38 288 79 -38 stone
execute in minecraft:overworld run fill 288 80 -38 288 81 -38 dirt
execute in minecraft:overworld run setblock 288 82 -38 grass_block
execute in minecraft:overworld run fill 288 83 -38 288 144 -38 air
execute in minecraft:overworld run fill 288 58 -37 288 79 -37 stone
execute in minecraft:overworld run fill 288 80 -37 288 81 -37 dirt
execute in minecraft:overworld run setblock 288 82 -37 coarse_dirt
execute in minecraft:overworld run fill 288 83 -37 288 144 -37 air
execute in minecraft:overworld run setblock 288 83 -37 mossy_cobblestone
execute in minecraft:overworld run fill 288 58 -36 288 78 -36 stone
execute in minecraft:overworld run fill 288 79 -36 288 80 -36 dirt
execute in minecraft:overworld run setblock 288 81 -36 coarse_dirt
execute in minecraft:overworld run fill 288 82 -36 288 144 -36 air
execute in minecraft:overworld run fill 288 58 -35 288 78 -35 stone
execute in minecraft:overworld run fill 288 79 -35 288 80 -35 dirt
execute in minecraft:overworld run setblock 288 81 -35 coarse_dirt
execute in minecraft:overworld run fill 288 82 -35 288 144 -35 air
execute in minecraft:overworld run fill 288 58 -34 288 77 -34 stone
execute in minecraft:overworld run fill 288 78 -34 288 79 -34 dirt
execute in minecraft:overworld run setblock 288 80 -34 coarse_dirt
execute in minecraft:overworld run fill 288 81 -34 288 144 -34 air
execute in minecraft:overworld run setblock 288 81 -34 mossy_cobblestone
execute in minecraft:overworld run fill 288 58 -33 288 77 -33 stone
execute in minecraft:overworld run fill 288 78 -33 288 79 -33 dirt
execute in minecraft:overworld run setblock 288 80 -33 grass_block
execute in minecraft:overworld run fill 288 81 -33 288 144 -33 air
execute in minecraft:overworld run fill 288 58 -32 288 76 -32 stone
execute in minecraft:overworld run fill 288 77 -32 288 78 -32 dirt
execute in minecraft:overworld run setblock 288 79 -32 grass_block
execute in minecraft:overworld run fill 288 80 -32 288 144 -32 air
execute in minecraft:overworld run fill 288 58 -31 288 76 -31 stone
execute in minecraft:overworld run fill 288 77 -31 288 78 -31 dirt
execute in minecraft:overworld run setblock 288 79 -31 coarse_dirt
execute in minecraft:overworld run fill 288 80 -31 288 144 -31 air
execute in minecraft:overworld run fill 288 58 -30 288 75 -30 stone
execute in minecraft:overworld run fill 288 76 -30 288 77 -30 dirt
execute in minecraft:overworld run setblock 288 78 -30 coarse_dirt
execute in minecraft:overworld run fill 288 79 -30 288 144 -30 air
execute in minecraft:overworld run fill 288 58 -29 288 74 -29 stone
execute in minecraft:overworld run fill 288 75 -29 288 76 -29 dirt
execute in minecraft:overworld run setblock 288 77 -29 grass_block
execute in minecraft:overworld run fill 288 78 -29 288 144 -29 air
execute in minecraft:overworld run fill 288 58 -28 288 74 -28 stone
execute in minecraft:overworld run fill 288 75 -28 288 76 -28 dirt
execute in minecraft:overworld run setblock 288 77 -28 coarse_dirt
execute in minecraft:overworld run fill 288 78 -28 288 144 -28 air
execute in minecraft:overworld run fill 288 58 -27 288 73 -27 stone
execute in minecraft:overworld run fill 288 74 -27 288 75 -27 dirt
execute in minecraft:overworld run setblock 288 76 -27 coarse_dirt
execute in minecraft:overworld run fill 288 77 -27 288 144 -27 air
execute in minecraft:overworld run setblock 288 77 -27 grass
execute in minecraft:overworld run fill 288 58 -26 288 73 -26 stone
execute in minecraft:overworld run fill 288 74 -26 288 75 -26 dirt
execute in minecraft:overworld run setblock 288 76 -26 grass_block
execute in minecraft:overworld run fill 288 77 -26 288 144 -26 air
execute in minecraft:overworld run setblock 288 77 -26 grass
execute in minecraft:overworld run fill 288 58 -25 288 73 -25 stone
execute in minecraft:overworld run fill 288 74 -25 288 75 -25 dirt
execute in minecraft:overworld run setblock 288 76 -25 coarse_dirt
execute in minecraft:overworld run fill 288 77 -25 288 144 -25 air
execute in minecraft:overworld run setblock 288 77 -25 grass
execute in minecraft:overworld run fill 288 58 -24 288 73 -24 stone
execute in minecraft:overworld run fill 288 74 -24 288 75 -24 dirt
execute in minecraft:overworld run setblock 288 76 -24 coarse_dirt
execute in minecraft:overworld run fill 288 77 -24 288 144 -24 air
execute in minecraft:overworld run fill 288 58 -23 288 72 -23 stone
execute in minecraft:overworld run fill 288 73 -23 288 74 -23 dirt
execute in minecraft:overworld run setblock 288 75 -23 coarse_dirt
execute in minecraft:overworld run fill 288 76 -23 288 144 -23 air
execute in minecraft:overworld run fill 288 58 -22 288 72 -22 stone
execute in minecraft:overworld run fill 288 73 -22 288 74 -22 dirt
execute in minecraft:overworld run setblock 288 75 -22 grass_block
execute in minecraft:overworld run fill 288 76 -22 288 144 -22 air
execute in minecraft:overworld run setblock 288 76 -22 grass
execute in minecraft:overworld run fill 288 58 -21 288 72 -21 stone
execute in minecraft:overworld run fill 288 73 -21 288 74 -21 dirt
execute in minecraft:overworld run setblock 288 75 -21 coarse_dirt
execute in minecraft:overworld run fill 288 76 -21 288 144 -21 air
execute in minecraft:overworld run fill 288 58 -20 288 71 -20 stone
execute in minecraft:overworld run fill 288 72 -20 288 73 -20 dirt
execute in minecraft:overworld run setblock 288 74 -20 coarse_dirt
execute in minecraft:overworld run fill 288 75 -20 288 144 -20 air
execute in minecraft:overworld run fill 288 58 -19 288 71 -19 stone
execute in minecraft:overworld run fill 288 72 -19 288 73 -19 dirt
execute in minecraft:overworld run setblock 288 74 -19 grass_block
execute in minecraft:overworld run fill 288 75 -19 288 144 -19 air
execute in minecraft:overworld run fill 288 58 -18 288 71 -18 stone
execute in minecraft:overworld run fill 288 72 -18 288 73 -18 dirt
execute in minecraft:overworld run setblock 288 74 -18 grass_block
execute in minecraft:overworld run fill 288 75 -18 288 144 -18 air
execute in minecraft:overworld run fill 288 58 -17 288 70 -17 stone
execute in minecraft:overworld run fill 288 71 -17 288 72 -17 dirt
execute in minecraft:overworld run setblock 288 73 -17 coarse_dirt
execute in minecraft:overworld run fill 288 74 -17 288 144 -17 air
execute in minecraft:overworld run fill 288 58 -16 288 70 -16 stone
execute in minecraft:overworld run fill 288 71 -16 288 72 -16 dirt
execute in minecraft:overworld run setblock 288 73 -16 coarse_dirt
execute in minecraft:overworld run fill 288 74 -16 288 144 -16 air
schedule function blade_gallery:random/burned/part_127 1t replace
