execute in minecraft:overworld run setblock 253 62 -2 gravel
execute in minecraft:overworld run fill 253 63 -2 253 144 -2 air
execute in minecraft:overworld run fill 253 63 -2 253 64 -2 water
execute in minecraft:overworld run fill 253 58 -1 253 59 -1 stone
execute in minecraft:overworld run fill 253 60 -1 253 61 -1 dirt
execute in minecraft:overworld run setblock 253 62 -1 gravel
execute in minecraft:overworld run fill 253 63 -1 253 144 -1 air
execute in minecraft:overworld run fill 253 63 -1 253 64 -1 water
execute in minecraft:overworld run fill 253 58 0 253 59 0 stone
execute in minecraft:overworld run fill 253 60 0 253 61 0 dirt
execute in minecraft:overworld run setblock 253 62 0 gravel
execute in minecraft:overworld run fill 253 63 0 253 144 0 air
execute in minecraft:overworld run fill 253 63 0 253 64 0 water
execute in minecraft:overworld run fill 253 58 1 253 59 1 stone
execute in minecraft:overworld run fill 253 60 1 253 61 1 dirt
execute in minecraft:overworld run setblock 253 62 1 gravel
execute in minecraft:overworld run fill 253 63 1 253 144 1 air
execute in minecraft:overworld run fill 253 63 1 253 64 1 water
execute in minecraft:overworld run fill 253 58 2 253 59 2 stone
execute in minecraft:overworld run fill 253 60 2 253 61 2 dirt
execute in minecraft:overworld run setblock 253 62 2 gravel
execute in minecraft:overworld run fill 253 63 2 253 144 2 air
execute in minecraft:overworld run fill 253 63 2 253 64 2 water
execute in minecraft:overworld run fill 253 58 3 253 60 3 stone
execute in minecraft:overworld run fill 253 61 3 253 62 3 dirt
execute in minecraft:overworld run setblock 253 63 3 gravel
execute in minecraft:overworld run fill 253 64 3 253 144 3 air
execute in minecraft:overworld run fill 253 64 3 253 64 3 water
execute in minecraft:overworld run fill 253 58 4 253 60 4 stone
execute in minecraft:overworld run fill 253 61 4 253 62 4 dirt
execute in minecraft:overworld run setblock 253 63 4 gravel
execute in minecraft:overworld run fill 253 64 4 253 144 4 air
execute in minecraft:overworld run fill 253 64 4 253 64 4 water
execute in minecraft:overworld run fill 253 58 5 253 61 5 stone
execute in minecraft:overworld run fill 253 62 5 253 63 5 dirt
execute in minecraft:overworld run setblock 253 64 5 coarse_dirt
execute in minecraft:overworld run fill 253 65 5 253 144 5 air
execute in minecraft:overworld run fill 253 58 6 253 61 6 stone
execute in minecraft:overworld run fill 253 62 6 253 63 6 dirt
execute in minecraft:overworld run setblock 253 64 6 coarse_dirt
execute in minecraft:overworld run fill 253 65 6 253 144 6 air
execute in minecraft:overworld run fill 253 58 7 253 61 7 stone
execute in minecraft:overworld run fill 253 62 7 253 63 7 dirt
execute in minecraft:overworld run setblock 253 64 7 grass_block
execute in minecraft:overworld run fill 253 65 7 253 144 7 air
execute in minecraft:overworld run fill 253 58 8 253 62 8 stone
execute in minecraft:overworld run fill 253 63 8 253 64 8 dirt
execute in minecraft:overworld run setblock 253 65 8 coarse_dirt
execute in minecraft:overworld run fill 253 66 8 253 144 8 air
execute in minecraft:overworld run fill 253 58 9 253 62 9 stone
execute in minecraft:overworld run fill 253 63 9 253 64 9 dirt
execute in minecraft:overworld run setblock 253 65 9 coarse_dirt
execute in minecraft:overworld run fill 253 66 9 253 144 9 air
execute in minecraft:overworld run setblock 253 66 9 mossy_cobblestone
execute in minecraft:overworld run fill 253 58 10 253 62 10 stone
execute in minecraft:overworld run fill 253 63 10 253 64 10 dirt
execute in minecraft:overworld run setblock 253 65 10 coarse_dirt
execute in minecraft:overworld run fill 253 66 10 253 144 10 air
execute in minecraft:overworld run fill 253 58 11 253 62 11 stone
execute in minecraft:overworld run fill 253 63 11 253 64 11 dirt
execute in minecraft:overworld run setblock 253 65 11 coarse_dirt
execute in minecraft:overworld run fill 253 66 11 253 144 11 air
execute in minecraft:overworld run fill 253 58 12 253 63 12 stone
execute in minecraft:overworld run fill 253 64 12 253 65 12 dirt
execute in minecraft:overworld run setblock 253 66 12 grass_block
execute in minecraft:overworld run fill 253 67 12 253 144 12 air
execute in minecraft:overworld run fill 253 58 13 253 63 13 stone
execute in minecraft:overworld run fill 253 64 13 253 65 13 dirt
execute in minecraft:overworld run setblock 253 66 13 grass_block
execute in minecraft:overworld run fill 253 67 13 253 144 13 air
execute in minecraft:overworld run fill 253 58 14 253 63 14 stone
execute in minecraft:overworld run fill 253 64 14 253 65 14 dirt
execute in minecraft:overworld run setblock 253 66 14 coarse_dirt
execute in minecraft:overworld run fill 253 67 14 253 144 14 air
execute in minecraft:overworld run fill 253 58 15 253 64 15 stone
execute in minecraft:overworld run fill 253 65 15 253 66 15 dirt
execute in minecraft:overworld run setblock 253 67 15 coarse_dirt
execute in minecraft:overworld run fill 253 68 15 253 144 15 air
execute in minecraft:overworld run setblock 253 68 15 grass
execute in minecraft:overworld run fill 253 58 16 253 64 16 stone
execute in minecraft:overworld run fill 253 65 16 253 66 16 dirt
execute in minecraft:overworld run setblock 253 67 16 grass_block
execute in minecraft:overworld run fill 253 68 16 253 144 16 air
execute in minecraft:overworld run fill 253 58 17 253 64 17 stone
execute in minecraft:overworld run fill 253 65 17 253 66 17 dirt
execute in minecraft:overworld run setblock 253 67 17 coarse_dirt
execute in minecraft:overworld run fill 253 68 17 253 144 17 air
execute in minecraft:overworld run fill 253 58 18 253 64 18 stone
execute in minecraft:overworld run fill 253 65 18 253 66 18 dirt
execute in minecraft:overworld run setblock 253 67 18 coarse_dirt
execute in minecraft:overworld run fill 253 68 18 253 144 18 air
execute in minecraft:overworld run fill 253 58 19 253 64 19 stone
execute in minecraft:overworld run fill 253 65 19 253 66 19 dirt
execute in minecraft:overworld run setblock 253 67 19 coarse_dirt
execute in minecraft:overworld run fill 253 68 19 253 144 19 air
execute in minecraft:overworld run fill 253 58 20 253 65 20 stone
execute in minecraft:overworld run fill 253 66 20 253 67 20 dirt
execute in minecraft:overworld run setblock 253 68 20 coarse_dirt
execute in minecraft:overworld run fill 253 69 20 253 144 20 air
execute in minecraft:overworld run fill 253 58 21 253 65 21 stone
execute in minecraft:overworld run fill 253 66 21 253 67 21 dirt
execute in minecraft:overworld run setblock 253 68 21 coarse_dirt
execute in minecraft:overworld run fill 253 69 21 253 144 21 air
execute in minecraft:overworld run fill 253 58 22 253 65 22 stone
execute in minecraft:overworld run fill 253 66 22 253 67 22 dirt
execute in minecraft:overworld run setblock 253 68 22 coarse_dirt
execute in minecraft:overworld run fill 253 69 22 253 144 22 air
execute in minecraft:overworld run fill 253 58 23 253 65 23 stone
execute in minecraft:overworld run fill 253 66 23 253 67 23 dirt
execute in minecraft:overworld run setblock 253 68 23 grass_block
execute in minecraft:overworld run fill 253 69 23 253 144 23 air
execute in minecraft:overworld run setblock 253 69 23 grass
execute in minecraft:overworld run fill 253 58 24 253 65 24 stone
execute in minecraft:overworld run fill 253 66 24 253 67 24 dirt
execute in minecraft:overworld run setblock 253 68 24 coarse_dirt
execute in minecraft:overworld run fill 253 69 24 253 144 24 air
execute in minecraft:overworld run fill 253 58 25 253 65 25 stone
execute in minecraft:overworld run fill 253 66 25 253 67 25 dirt
execute in minecraft:overworld run setblock 253 68 25 grass_block
execute in minecraft:overworld run fill 253 69 25 253 144 25 air
execute in minecraft:overworld run fill 253 58 26 253 65 26 stone
execute in minecraft:overworld run fill 253 66 26 253 67 26 dirt
execute in minecraft:overworld run setblock 253 68 26 coarse_dirt
execute in minecraft:overworld run fill 253 69 26 253 144 26 air
execute in minecraft:overworld run fill 253 58 27 253 65 27 stone
execute in minecraft:overworld run fill 253 66 27 253 67 27 dirt
execute in minecraft:overworld run setblock 253 68 27 grass_block
execute in minecraft:overworld run fill 253 69 27 253 144 27 air
execute in minecraft:overworld run fill 253 58 28 253 65 28 stone
execute in minecraft:overworld run fill 253 66 28 253 67 28 dirt
execute in minecraft:overworld run setblock 253 68 28 coarse_dirt
execute in minecraft:overworld run fill 253 69 28 253 144 28 air
execute in minecraft:overworld run fill 253 58 29 253 64 29 stone
execute in minecraft:overworld run fill 253 65 29 253 66 29 dirt
execute in minecraft:overworld run setblock 253 67 29 grass_block
execute in minecraft:overworld run fill 253 68 29 253 144 29 air
execute in minecraft:overworld run fill 253 58 30 253 64 30 stone
execute in minecraft:overworld run fill 253 65 30 253 66 30 dirt
execute in minecraft:overworld run setblock 253 67 30 coarse_dirt
execute in minecraft:overworld run fill 253 68 30 253 144 30 air
execute in minecraft:overworld run fill 253 58 31 253 64 31 stone
execute in minecraft:overworld run fill 253 65 31 253 66 31 dirt
execute in minecraft:overworld run setblock 253 67 31 coarse_dirt
execute in minecraft:overworld run fill 253 68 31 253 144 31 air
execute in minecraft:overworld run fill 253 58 32 253 64 32 stone
execute in minecraft:overworld run fill 253 65 32 253 66 32 dirt
execute in minecraft:overworld run setblock 253 67 32 coarse_dirt
execute in minecraft:overworld run fill 253 68 32 253 144 32 air
execute in minecraft:overworld run fill 253 58 33 253 64 33 stone
execute in minecraft:overworld run fill 253 65 33 253 66 33 dirt
execute in minecraft:overworld run setblock 253 67 33 coarse_dirt
execute in minecraft:overworld run fill 253 68 33 253 144 33 air
execute in minecraft:overworld run fill 253 58 34 253 64 34 stone
execute in minecraft:overworld run fill 253 65 34 253 66 34 dirt
execute in minecraft:overworld run setblock 253 67 34 coarse_dirt
execute in minecraft:overworld run fill 253 68 34 253 144 34 air
execute in minecraft:overworld run fill 253 58 35 253 64 35 stone
execute in minecraft:overworld run fill 253 65 35 253 66 35 dirt
execute in minecraft:overworld run setblock 253 67 35 grass_block
execute in minecraft:overworld run fill 253 68 35 253 144 35 air
execute in minecraft:overworld run fill 253 58 36 253 63 36 stone
execute in minecraft:overworld run fill 253 64 36 253 65 36 dirt
execute in minecraft:overworld run setblock 253 66 36 coarse_dirt
execute in minecraft:overworld run fill 253 67 36 253 144 36 air
execute in minecraft:overworld run setblock 253 67 36 grass
execute in minecraft:overworld run fill 253 58 37 253 63 37 stone
execute in minecraft:overworld run fill 253 64 37 253 65 37 dirt
execute in minecraft:overworld run setblock 253 66 37 grass_block
execute in minecraft:overworld run fill 253 67 37 253 144 37 air
execute in minecraft:overworld run fill 253 58 38 253 62 38 stone
execute in minecraft:overworld run fill 253 63 38 253 64 38 dirt
execute in minecraft:overworld run setblock 253 65 38 coarse_dirt
execute in minecraft:overworld run fill 253 66 38 253 144 38 air
execute in minecraft:overworld run fill 253 58 39 253 61 39 stone
execute in minecraft:overworld run fill 253 62 39 253 63 39 dirt
execute in minecraft:overworld run setblock 253 64 39 coarse_dirt
execute in minecraft:overworld run fill 253 65 39 253 144 39 air
execute in minecraft:overworld run fill 253 58 40 253 61 40 stone
execute in minecraft:overworld run fill 253 62 40 253 63 40 dirt
execute in minecraft:overworld run setblock 253 64 40 coarse_dirt
execute in minecraft:overworld run fill 253 65 40 253 144 40 air
execute in minecraft:overworld run fill 253 58 41 253 60 41 stone
execute in minecraft:overworld run fill 253 61 41 253 62 41 dirt
execute in minecraft:overworld run setblock 253 63 41 gravel
execute in minecraft:overworld run fill 253 64 41 253 144 41 air
execute in minecraft:overworld run fill 253 64 41 253 64 41 water
execute in minecraft:overworld run fill 253 58 42 253 60 42 stone
execute in minecraft:overworld run fill 253 61 42 253 62 42 dirt
execute in minecraft:overworld run setblock 253 63 42 gravel
execute in minecraft:overworld run fill 253 64 42 253 144 42 air
execute in minecraft:overworld run fill 253 64 42 253 64 42 water
execute in minecraft:overworld run fill 253 58 43 253 60 43 stone
execute in minecraft:overworld run fill 253 61 43 253 62 43 dirt
execute in minecraft:overworld run setblock 253 63 43 gravel
execute in minecraft:overworld run fill 253 64 43 253 144 43 air
execute in minecraft:overworld run fill 253 64 43 253 64 43 water
execute in minecraft:overworld run fill 253 58 44 253 60 44 stone
execute in minecraft:overworld run fill 253 61 44 253 62 44 dirt
execute in minecraft:overworld run setblock 253 63 44 gravel
execute in minecraft:overworld run fill 253 64 44 253 144 44 air
execute in minecraft:overworld run fill 253 64 44 253 64 44 water
execute in minecraft:overworld run fill 253 58 45 253 60 45 stone
execute in minecraft:overworld run fill 253 61 45 253 62 45 dirt
execute in minecraft:overworld run setblock 253 63 45 gravel
execute in minecraft:overworld run fill 253 64 45 253 144 45 air
execute in minecraft:overworld run fill 253 64 45 253 64 45 water
execute in minecraft:overworld run fill 253 58 46 253 60 46 stone
execute in minecraft:overworld run fill 253 61 46 253 62 46 dirt
execute in minecraft:overworld run setblock 253 63 46 gravel
execute in minecraft:overworld run fill 253 64 46 253 144 46 air
execute in minecraft:overworld run fill 253 64 46 253 64 46 water
execute in minecraft:overworld run fill 253 58 47 253 61 47 stone
execute in minecraft:overworld run fill 253 62 47 253 63 47 dirt
execute in minecraft:overworld run setblock 253 64 47 coarse_dirt
execute in minecraft:overworld run fill 253 65 47 253 144 47 air
execute in minecraft:overworld run fill 254 58 -48 254 61 -48 stone
execute in minecraft:overworld run fill 254 62 -48 254 63 -48 dirt
execute in minecraft:overworld run setblock 254 64 -48 coarse_dirt
execute in minecraft:overworld run fill 254 65 -48 254 144 -48 air
execute in minecraft:overworld run fill 254 58 -47 254 62 -47 stone
execute in minecraft:overworld run fill 254 63 -47 254 64 -47 dirt
execute in minecraft:overworld run setblock 254 65 -47 coarse_dirt
execute in minecraft:overworld run fill 254 66 -47 254 144 -47 air
execute in minecraft:overworld run fill 254 58 -46 254 64 -46 stone
execute in minecraft:overworld run fill 254 65 -46 254 66 -46 dirt
execute in minecraft:overworld run setblock 254 67 -46 coarse_dirt
execute in minecraft:overworld run fill 254 68 -46 254 144 -46 air
execute in minecraft:overworld run fill 254 58 -45 254 65 -45 stone
execute in minecraft:overworld run fill 254 66 -45 254 67 -45 dirt
execute in minecraft:overworld run setblock 254 68 -45 coarse_dirt
execute in minecraft:overworld run fill 254 69 -45 254 144 -45 air
execute in minecraft:overworld run fill 254 58 -44 254 66 -44 stone
execute in minecraft:overworld run fill 254 67 -44 254 68 -44 dirt
execute in minecraft:overworld run setblock 254 69 -44 grass_block
execute in minecraft:overworld run fill 254 70 -44 254 144 -44 air
execute in minecraft:overworld run fill 254 58 -43 254 67 -43 stone
execute in minecraft:overworld run fill 254 68 -43 254 69 -43 dirt
execute in minecraft:overworld run setblock 254 70 -43 grass_block
execute in minecraft:overworld run fill 254 71 -43 254 144 -43 air
execute in minecraft:overworld run fill 254 58 -42 254 68 -42 stone
execute in minecraft:overworld run fill 254 69 -42 254 70 -42 dirt
execute in minecraft:overworld run setblock 254 71 -42 grass_block
execute in minecraft:overworld run fill 254 72 -42 254 144 -42 air
execute in minecraft:overworld run fill 254 58 -41 254 69 -41 stone
execute in minecraft:overworld run fill 254 70 -41 254 71 -41 dirt
execute in minecraft:overworld run setblock 254 72 -41 grass_block
execute in minecraft:overworld run fill 254 73 -41 254 144 -41 air
execute in minecraft:overworld run setblock 254 73 -41 grass
execute in minecraft:overworld run fill 254 58 -40 254 70 -40 stone
execute in minecraft:overworld run fill 254 71 -40 254 72 -40 dirt
execute in minecraft:overworld run setblock 254 73 -40 coarse_dirt
execute in minecraft:overworld run fill 254 74 -40 254 144 -40 air
execute in minecraft:overworld run fill 254 58 -39 254 71 -39 stone
execute in minecraft:overworld run fill 254 72 -39 254 73 -39 dirt
execute in minecraft:overworld run setblock 254 74 -39 grass_block
execute in minecraft:overworld run fill 254 75 -39 254 144 -39 air
schedule function blade_gallery:random/burned/part_71 1t replace
