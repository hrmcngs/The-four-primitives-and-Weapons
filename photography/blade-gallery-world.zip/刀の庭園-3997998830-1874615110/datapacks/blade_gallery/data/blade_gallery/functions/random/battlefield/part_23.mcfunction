execute in minecraft:overworld run fill 351 80 -38 351 144 -38 air
execute in minecraft:overworld run setblock 351 80 -38 grass
execute in minecraft:overworld run fill 351 58 -37 351 75 -37 stone
execute in minecraft:overworld run fill 351 76 -37 351 77 -37 dirt
execute in minecraft:overworld run setblock 351 78 -37 coarse_dirt
execute in minecraft:overworld run fill 351 79 -37 351 144 -37 air
execute in minecraft:overworld run fill 351 58 -36 351 75 -36 stone
execute in minecraft:overworld run fill 351 76 -36 351 77 -36 dirt
execute in minecraft:overworld run setblock 351 78 -36 coarse_dirt
execute in minecraft:overworld run fill 351 79 -36 351 144 -36 air
execute in minecraft:overworld run fill 351 58 -35 351 74 -35 stone
execute in minecraft:overworld run fill 351 75 -35 351 76 -35 dirt
execute in minecraft:overworld run setblock 351 77 -35 coarse_dirt
execute in minecraft:overworld run fill 351 78 -35 351 144 -35 air
execute in minecraft:overworld run fill 351 58 -34 351 74 -34 stone
execute in minecraft:overworld run fill 351 75 -34 351 76 -34 dirt
execute in minecraft:overworld run setblock 351 77 -34 grass_block
execute in minecraft:overworld run fill 351 78 -34 351 144 -34 air
execute in minecraft:overworld run setblock 351 78 -34 grass
execute in minecraft:overworld run fill 351 58 -33 351 74 -33 stone
execute in minecraft:overworld run fill 351 75 -33 351 76 -33 dirt
execute in minecraft:overworld run setblock 351 77 -33 coarse_dirt
execute in minecraft:overworld run fill 351 78 -33 351 144 -33 air
execute in minecraft:overworld run fill 351 58 -32 351 74 -32 stone
execute in minecraft:overworld run fill 351 75 -32 351 76 -32 dirt
execute in minecraft:overworld run setblock 351 77 -32 grass_block
execute in minecraft:overworld run fill 351 78 -32 351 144 -32 air
execute in minecraft:overworld run fill 351 58 -31 351 74 -31 stone
execute in minecraft:overworld run fill 351 75 -31 351 76 -31 dirt
execute in minecraft:overworld run setblock 351 77 -31 coarse_dirt
execute in minecraft:overworld run fill 351 78 -31 351 144 -31 air
execute in minecraft:overworld run fill 351 58 -30 351 74 -30 stone
execute in minecraft:overworld run fill 351 75 -30 351 76 -30 dirt
execute in minecraft:overworld run setblock 351 77 -30 grass_block
execute in minecraft:overworld run fill 351 78 -30 351 144 -30 air
execute in minecraft:overworld run fill 351 58 -29 351 73 -29 stone
execute in minecraft:overworld run fill 351 74 -29 351 75 -29 dirt
execute in minecraft:overworld run setblock 351 76 -29 coarse_dirt
execute in minecraft:overworld run fill 351 77 -29 351 144 -29 air
execute in minecraft:overworld run setblock 351 77 -29 grass
execute in minecraft:overworld run fill 351 58 -28 351 73 -28 stone
execute in minecraft:overworld run fill 351 74 -28 351 75 -28 dirt
execute in minecraft:overworld run setblock 351 76 -28 grass_block
execute in minecraft:overworld run fill 351 77 -28 351 144 -28 air
execute in minecraft:overworld run fill 351 58 -27 351 73 -27 stone
execute in minecraft:overworld run fill 351 74 -27 351 75 -27 dirt
execute in minecraft:overworld run setblock 351 76 -27 coarse_dirt
execute in minecraft:overworld run fill 351 77 -27 351 144 -27 air
execute in minecraft:overworld run setblock 351 77 -27 mossy_cobblestone
execute in minecraft:overworld run fill 351 58 -26 351 72 -26 stone
execute in minecraft:overworld run fill 351 73 -26 351 74 -26 dirt
execute in minecraft:overworld run setblock 351 75 -26 coarse_dirt
execute in minecraft:overworld run fill 351 76 -26 351 144 -26 air
execute in minecraft:overworld run setblock 351 76 -26 grass
execute in minecraft:overworld run fill 351 58 -25 351 72 -25 stone
execute in minecraft:overworld run fill 351 73 -25 351 74 -25 dirt
execute in minecraft:overworld run setblock 351 75 -25 coarse_dirt
execute in minecraft:overworld run fill 351 76 -25 351 144 -25 air
execute in minecraft:overworld run fill 351 58 -24 351 72 -24 stone
execute in minecraft:overworld run fill 351 73 -24 351 74 -24 dirt
execute in minecraft:overworld run setblock 351 75 -24 grass_block
execute in minecraft:overworld run fill 351 76 -24 351 144 -24 air
execute in minecraft:overworld run fill 351 58 -23 351 71 -23 stone
execute in minecraft:overworld run fill 351 72 -23 351 73 -23 dirt
execute in minecraft:overworld run setblock 351 74 -23 coarse_dirt
execute in minecraft:overworld run fill 351 75 -23 351 144 -23 air
execute in minecraft:overworld run fill 351 58 -22 351 71 -22 stone
execute in minecraft:overworld run fill 351 72 -22 351 73 -22 dirt
execute in minecraft:overworld run setblock 351 74 -22 grass_block
execute in minecraft:overworld run fill 351 75 -22 351 144 -22 air
execute in minecraft:overworld run fill 351 58 -21 351 71 -21 stone
execute in minecraft:overworld run fill 351 72 -21 351 73 -21 dirt
execute in minecraft:overworld run setblock 351 74 -21 coarse_dirt
execute in minecraft:overworld run fill 351 75 -21 351 144 -21 air
execute in minecraft:overworld run fill 351 58 -20 351 70 -20 stone
execute in minecraft:overworld run fill 351 71 -20 351 72 -20 dirt
execute in minecraft:overworld run setblock 351 73 -20 grass_block
execute in minecraft:overworld run fill 351 74 -20 351 144 -20 air
execute in minecraft:overworld run setblock 351 74 -20 grass
execute in minecraft:overworld run fill 351 58 -19 351 70 -19 stone
execute in minecraft:overworld run fill 351 71 -19 351 72 -19 dirt
execute in minecraft:overworld run setblock 351 73 -19 grass_block
execute in minecraft:overworld run fill 351 74 -19 351 144 -19 air
execute in minecraft:overworld run fill 351 58 -18 351 69 -18 stone
execute in minecraft:overworld run fill 351 70 -18 351 71 -18 dirt
execute in minecraft:overworld run setblock 351 72 -18 coarse_dirt
execute in minecraft:overworld run fill 351 73 -18 351 144 -18 air
execute in minecraft:overworld run fill 351 58 -17 351 69 -17 stone
execute in minecraft:overworld run fill 351 70 -17 351 71 -17 dirt
execute in minecraft:overworld run setblock 351 72 -17 coarse_dirt
execute in minecraft:overworld run fill 351 73 -17 351 144 -17 air
execute in minecraft:overworld run fill 351 58 -16 351 69 -16 stone
execute in minecraft:overworld run fill 351 70 -16 351 71 -16 dirt
execute in minecraft:overworld run setblock 351 72 -16 coarse_dirt
execute in minecraft:overworld run fill 351 73 -16 351 144 -16 air
execute in minecraft:overworld run fill 351 58 -15 351 68 -15 stone
execute in minecraft:overworld run fill 351 69 -15 351 70 -15 dirt
execute in minecraft:overworld run setblock 351 71 -15 grass_block
execute in minecraft:overworld run fill 351 72 -15 351 144 -15 air
execute in minecraft:overworld run fill 351 58 -14 351 68 -14 stone
execute in minecraft:overworld run fill 351 69 -14 351 70 -14 dirt
execute in minecraft:overworld run setblock 351 71 -14 grass_block
execute in minecraft:overworld run fill 351 72 -14 351 144 -14 air
execute in minecraft:overworld run fill 351 58 -13 351 67 -13 stone
execute in minecraft:overworld run fill 351 68 -13 351 69 -13 dirt
execute in minecraft:overworld run setblock 351 70 -13 grass_block
execute in minecraft:overworld run fill 351 71 -13 351 144 -13 air
execute in minecraft:overworld run fill 351 58 -12 351 67 -12 stone
execute in minecraft:overworld run fill 351 68 -12 351 69 -12 dirt
execute in minecraft:overworld run setblock 351 70 -12 coarse_dirt
execute in minecraft:overworld run fill 351 71 -12 351 144 -12 air
execute in minecraft:overworld run fill 351 58 -11 351 67 -11 stone
execute in minecraft:overworld run fill 351 68 -11 351 69 -11 dirt
execute in minecraft:overworld run setblock 351 70 -11 coarse_dirt
execute in minecraft:overworld run fill 351 71 -11 351 144 -11 air
execute in minecraft:overworld run fill 351 58 -10 351 67 -10 stone
execute in minecraft:overworld run fill 351 68 -10 351 69 -10 dirt
execute in minecraft:overworld run setblock 351 70 -10 coarse_dirt
execute in minecraft:overworld run fill 351 71 -10 351 144 -10 air
execute in minecraft:overworld run fill 351 58 -9 351 67 -9 stone
execute in minecraft:overworld run fill 351 68 -9 351 69 -9 dirt
execute in minecraft:overworld run setblock 351 70 -9 coarse_dirt
execute in minecraft:overworld run fill 351 71 -9 351 144 -9 air
execute in minecraft:overworld run fill 351 58 -8 351 67 -8 stone
execute in minecraft:overworld run fill 351 68 -8 351 69 -8 dirt
execute in minecraft:overworld run setblock 351 70 -8 coarse_dirt
execute in minecraft:overworld run fill 351 71 -8 351 144 -8 air
execute in minecraft:overworld run fill 351 58 -7 351 67 -7 stone
execute in minecraft:overworld run fill 351 68 -7 351 69 -7 dirt
execute in minecraft:overworld run setblock 351 70 -7 grass_block
execute in minecraft:overworld run fill 351 71 -7 351 144 -7 air
execute in minecraft:overworld run fill 351 58 -6 351 67 -6 stone
execute in minecraft:overworld run fill 351 68 -6 351 69 -6 dirt
execute in minecraft:overworld run setblock 351 70 -6 coarse_dirt
execute in minecraft:overworld run fill 351 71 -6 351 144 -6 air
execute in minecraft:overworld run fill 351 58 -5 351 67 -5 stone
execute in minecraft:overworld run fill 351 68 -5 351 69 -5 dirt
execute in minecraft:overworld run setblock 351 70 -5 coarse_dirt
execute in minecraft:overworld run fill 351 71 -5 351 144 -5 air
execute in minecraft:overworld run fill 351 58 -4 351 67 -4 stone
execute in minecraft:overworld run fill 351 68 -4 351 69 -4 dirt
execute in minecraft:overworld run setblock 351 70 -4 coarse_dirt
execute in minecraft:overworld run fill 351 71 -4 351 144 -4 air
execute in minecraft:overworld run fill 351 58 -3 351 66 -3 stone
execute in minecraft:overworld run fill 351 67 -3 351 68 -3 dirt
execute in minecraft:overworld run setblock 351 69 -3 coarse_dirt
execute in minecraft:overworld run fill 351 70 -3 351 144 -3 air
execute in minecraft:overworld run fill 351 58 -2 351 66 -2 stone
execute in minecraft:overworld run fill 351 67 -2 351 68 -2 dirt
execute in minecraft:overworld run setblock 351 69 -2 grass_block
execute in minecraft:overworld run fill 351 70 -2 351 144 -2 air
execute in minecraft:overworld run fill 351 58 -1 351 66 -1 stone
execute in minecraft:overworld run fill 351 67 -1 351 68 -1 dirt
execute in minecraft:overworld run setblock 351 69 -1 grass_block
execute in minecraft:overworld run fill 351 70 -1 351 144 -1 air
execute in minecraft:overworld run fill 351 58 0 351 66 0 stone
execute in minecraft:overworld run fill 351 67 0 351 68 0 dirt
execute in minecraft:overworld run setblock 351 69 0 coarse_dirt
execute in minecraft:overworld run fill 351 70 0 351 144 0 air
execute in minecraft:overworld run fill 351 58 1 351 66 1 stone
execute in minecraft:overworld run fill 351 67 1 351 68 1 dirt
execute in minecraft:overworld run setblock 351 69 1 grass_block
execute in minecraft:overworld run fill 351 70 1 351 144 1 air
execute in minecraft:overworld run fill 351 58 2 351 66 2 stone
execute in minecraft:overworld run fill 351 67 2 351 68 2 dirt
execute in minecraft:overworld run setblock 351 69 2 coarse_dirt
execute in minecraft:overworld run fill 351 70 2 351 144 2 air
execute in minecraft:overworld run fill 351 58 3 351 67 3 stone
execute in minecraft:overworld run fill 351 68 3 351 69 3 dirt
execute in minecraft:overworld run setblock 351 70 3 coarse_dirt
execute in minecraft:overworld run fill 351 71 3 351 144 3 air
execute in minecraft:overworld run fill 351 58 4 351 67 4 stone
execute in minecraft:overworld run fill 351 68 4 351 69 4 dirt
execute in minecraft:overworld run setblock 351 70 4 coarse_dirt
execute in minecraft:overworld run fill 351 71 4 351 144 4 air
execute in minecraft:overworld run fill 351 58 5 351 67 5 stone
execute in minecraft:overworld run fill 351 68 5 351 69 5 dirt
execute in minecraft:overworld run setblock 351 70 5 coarse_dirt
execute in minecraft:overworld run fill 351 71 5 351 144 5 air
execute in minecraft:overworld run fill 351 58 6 351 67 6 stone
execute in minecraft:overworld run fill 351 68 6 351 69 6 dirt
execute in minecraft:overworld run setblock 351 70 6 coarse_dirt
execute in minecraft:overworld run fill 351 71 6 351 144 6 air
execute in minecraft:overworld run fill 351 58 7 351 67 7 stone
execute in minecraft:overworld run fill 351 68 7 351 69 7 dirt
execute in minecraft:overworld run setblock 351 70 7 coarse_dirt
execute in minecraft:overworld run fill 351 71 7 351 144 7 air
execute in minecraft:overworld run fill 351 58 8 351 67 8 stone
execute in minecraft:overworld run fill 351 68 8 351 69 8 dirt
execute in minecraft:overworld run setblock 351 70 8 coarse_dirt
execute in minecraft:overworld run fill 351 71 8 351 144 8 air
execute in minecraft:overworld run setblock 351 71 8 mossy_cobblestone
execute in minecraft:overworld run fill 351 58 9 351 67 9 stone
execute in minecraft:overworld run fill 351 68 9 351 69 9 dirt
execute in minecraft:overworld run setblock 351 70 9 coarse_dirt
execute in minecraft:overworld run fill 351 71 9 351 144 9 air
execute in minecraft:overworld run fill 351 58 10 351 67 10 stone
execute in minecraft:overworld run fill 351 68 10 351 69 10 dirt
execute in minecraft:overworld run setblock 351 70 10 grass_block
execute in minecraft:overworld run fill 351 71 10 351 144 10 air
execute in minecraft:overworld run fill 351 58 11 351 67 11 stone
execute in minecraft:overworld run fill 351 68 11 351 69 11 dirt
execute in minecraft:overworld run setblock 351 70 11 grass_block
execute in minecraft:overworld run fill 351 71 11 351 144 11 air
execute in minecraft:overworld run fill 351 58 12 351 67 12 stone
execute in minecraft:overworld run fill 351 68 12 351 69 12 dirt
execute in minecraft:overworld run setblock 351 70 12 coarse_dirt
execute in minecraft:overworld run fill 351 71 12 351 144 12 air
execute in minecraft:overworld run fill 351 58 13 351 66 13 stone
execute in minecraft:overworld run fill 351 67 13 351 68 13 dirt
execute in minecraft:overworld run setblock 351 69 13 coarse_dirt
execute in minecraft:overworld run fill 351 70 13 351 144 13 air
execute in minecraft:overworld run fill 351 58 14 351 66 14 stone
execute in minecraft:overworld run fill 351 67 14 351 68 14 dirt
execute in minecraft:overworld run setblock 351 69 14 coarse_dirt
execute in minecraft:overworld run fill 351 70 14 351 144 14 air
execute in minecraft:overworld run fill 351 58 15 351 66 15 stone
execute in minecraft:overworld run fill 351 67 15 351 68 15 dirt
execute in minecraft:overworld run setblock 351 69 15 coarse_dirt
execute in minecraft:overworld run fill 351 70 15 351 144 15 air
execute in minecraft:overworld run fill 351 58 16 351 66 16 stone
execute in minecraft:overworld run fill 351 67 16 351 68 16 dirt
execute in minecraft:overworld run setblock 351 69 16 coarse_dirt
execute in minecraft:overworld run fill 351 70 16 351 144 16 air
execute in minecraft:overworld run fill 351 58 17 351 65 17 stone
execute in minecraft:overworld run fill 351 66 17 351 67 17 dirt
execute in minecraft:overworld run setblock 351 68 17 coarse_dirt
execute in minecraft:overworld run fill 351 69 17 351 144 17 air
execute in minecraft:overworld run fill 351 58 18 351 65 18 stone
execute in minecraft:overworld run fill 351 66 18 351 67 18 dirt
execute in minecraft:overworld run setblock 351 68 18 coarse_dirt
execute in minecraft:overworld run fill 351 69 18 351 144 18 air
execute in minecraft:overworld run fill 351 58 19 351 65 19 stone
execute in minecraft:overworld run fill 351 66 19 351 67 19 dirt
execute in minecraft:overworld run setblock 351 68 19 coarse_dirt
execute in minecraft:overworld run fill 351 69 19 351 144 19 air
execute in minecraft:overworld run fill 351 58 20 351 66 20 stone
execute in minecraft:overworld run fill 351 67 20 351 68 20 dirt
execute in minecraft:overworld run setblock 351 69 20 coarse_dirt
execute in minecraft:overworld run fill 351 70 20 351 144 20 air
execute in minecraft:overworld run fill 351 58 21 351 66 21 stone
execute in minecraft:overworld run fill 351 67 21 351 68 21 dirt
execute in minecraft:overworld run setblock 351 69 21 coarse_dirt
execute in minecraft:overworld run fill 351 70 21 351 144 21 air
execute in minecraft:overworld run fill 351 58 22 351 67 22 stone
execute in minecraft:overworld run fill 351 68 22 351 69 22 dirt
execute in minecraft:overworld run setblock 351 70 22 coarse_dirt
execute in minecraft:overworld run fill 351 71 22 351 144 22 air
execute in minecraft:overworld run fill 351 58 23 351 67 23 stone
execute in minecraft:overworld run fill 351 68 23 351 69 23 dirt
execute in minecraft:overworld run setblock 351 70 23 coarse_dirt
execute in minecraft:overworld run fill 351 71 23 351 144 23 air
execute in minecraft:overworld run fill 351 58 24 351 67 24 stone
execute in minecraft:overworld run fill 351 68 24 351 69 24 dirt
execute in minecraft:overworld run setblock 351 70 24 grass_block
execute in minecraft:overworld run fill 351 71 24 351 144 24 air
schedule function blade_gallery:random/battlefield/part_24 1t replace
