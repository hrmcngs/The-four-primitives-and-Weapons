execute in minecraft:overworld run fill 238 62 -48 238 63 -48 dirt
execute in minecraft:overworld run setblock 238 64 -48 coarse_dirt
execute in minecraft:overworld run fill 238 65 -48 238 144 -48 air
execute in minecraft:overworld run fill 238 58 -47 238 62 -47 stone
execute in minecraft:overworld run fill 238 63 -47 238 64 -47 dirt
execute in minecraft:overworld run setblock 238 65 -47 grass_block
execute in minecraft:overworld run fill 238 66 -47 238 144 -47 air
execute in minecraft:overworld run fill 238 58 -46 238 64 -46 stone
execute in minecraft:overworld run fill 238 65 -46 238 66 -46 dirt
execute in minecraft:overworld run setblock 238 67 -46 coarse_dirt
execute in minecraft:overworld run fill 238 68 -46 238 144 -46 air
execute in minecraft:overworld run fill 238 58 -45 238 65 -45 stone
execute in minecraft:overworld run fill 238 66 -45 238 67 -45 dirt
execute in minecraft:overworld run setblock 238 68 -45 coarse_dirt
execute in minecraft:overworld run fill 238 69 -45 238 144 -45 air
execute in minecraft:overworld run fill 238 58 -44 238 66 -44 stone
execute in minecraft:overworld run fill 238 67 -44 238 68 -44 dirt
execute in minecraft:overworld run setblock 238 69 -44 coarse_dirt
execute in minecraft:overworld run fill 238 70 -44 238 144 -44 air
execute in minecraft:overworld run fill 238 58 -43 238 67 -43 stone
execute in minecraft:overworld run fill 238 68 -43 238 69 -43 dirt
execute in minecraft:overworld run setblock 238 70 -43 coarse_dirt
execute in minecraft:overworld run fill 238 71 -43 238 144 -43 air
execute in minecraft:overworld run fill 238 58 -42 238 69 -42 stone
execute in minecraft:overworld run fill 238 70 -42 238 71 -42 dirt
execute in minecraft:overworld run setblock 238 72 -42 coarse_dirt
execute in minecraft:overworld run fill 238 73 -42 238 144 -42 air
execute in minecraft:overworld run fill 238 58 -41 238 70 -41 stone
execute in minecraft:overworld run fill 238 71 -41 238 72 -41 dirt
execute in minecraft:overworld run setblock 238 73 -41 grass_block
execute in minecraft:overworld run fill 238 74 -41 238 144 -41 air
execute in minecraft:overworld run fill 238 58 -40 238 71 -40 stone
execute in minecraft:overworld run fill 238 72 -40 238 73 -40 dirt
execute in minecraft:overworld run setblock 238 74 -40 coarse_dirt
execute in minecraft:overworld run fill 238 75 -40 238 144 -40 air
execute in minecraft:overworld run fill 238 58 -39 238 72 -39 stone
execute in minecraft:overworld run fill 238 73 -39 238 74 -39 dirt
execute in minecraft:overworld run setblock 238 75 -39 coarse_dirt
execute in minecraft:overworld run fill 238 76 -39 238 144 -39 air
execute in minecraft:overworld run fill 238 58 -38 238 73 -38 stone
execute in minecraft:overworld run fill 238 74 -38 238 75 -38 dirt
execute in minecraft:overworld run setblock 238 76 -38 grass_block
execute in minecraft:overworld run fill 238 77 -38 238 144 -38 air
execute in minecraft:overworld run fill 238 58 -37 238 73 -37 stone
execute in minecraft:overworld run fill 238 74 -37 238 75 -37 dirt
execute in minecraft:overworld run setblock 238 76 -37 coarse_dirt
execute in minecraft:overworld run fill 238 77 -37 238 144 -37 air
execute in minecraft:overworld run fill 238 58 -36 238 73 -36 stone
execute in minecraft:overworld run fill 238 74 -36 238 75 -36 dirt
execute in minecraft:overworld run setblock 238 76 -36 coarse_dirt
execute in minecraft:overworld run fill 238 77 -36 238 144 -36 air
execute in minecraft:overworld run fill 238 58 -35 238 73 -35 stone
execute in minecraft:overworld run fill 238 74 -35 238 75 -35 dirt
execute in minecraft:overworld run setblock 238 76 -35 coarse_dirt
execute in minecraft:overworld run fill 238 77 -35 238 144 -35 air
execute in minecraft:overworld run fill 238 58 -34 238 73 -34 stone
execute in minecraft:overworld run fill 238 74 -34 238 75 -34 dirt
execute in minecraft:overworld run setblock 238 76 -34 grass_block
execute in minecraft:overworld run fill 238 77 -34 238 144 -34 air
execute in minecraft:overworld run fill 238 58 -33 238 72 -33 stone
execute in minecraft:overworld run fill 238 73 -33 238 74 -33 dirt
execute in minecraft:overworld run setblock 238 75 -33 grass_block
execute in minecraft:overworld run fill 238 76 -33 238 144 -33 air
execute in minecraft:overworld run fill 238 58 -32 238 72 -32 stone
execute in minecraft:overworld run fill 238 73 -32 238 74 -32 dirt
execute in minecraft:overworld run setblock 238 75 -32 grass_block
execute in minecraft:overworld run fill 238 76 -32 238 144 -32 air
execute in minecraft:overworld run fill 238 58 -31 238 72 -31 stone
execute in minecraft:overworld run fill 238 73 -31 238 74 -31 dirt
execute in minecraft:overworld run setblock 238 75 -31 coarse_dirt
execute in minecraft:overworld run fill 238 76 -31 238 144 -31 air
execute in minecraft:overworld run setblock 238 76 -31 grass
execute in minecraft:overworld run fill 238 58 -30 238 72 -30 stone
execute in minecraft:overworld run fill 238 73 -30 238 74 -30 dirt
execute in minecraft:overworld run setblock 238 75 -30 coarse_dirt
execute in minecraft:overworld run fill 238 76 -30 238 144 -30 air
execute in minecraft:overworld run fill 238 58 -29 238 71 -29 stone
execute in minecraft:overworld run fill 238 72 -29 238 73 -29 dirt
execute in minecraft:overworld run setblock 238 74 -29 grass_block
execute in minecraft:overworld run fill 238 75 -29 238 144 -29 air
execute in minecraft:overworld run fill 238 58 -28 238 71 -28 stone
execute in minecraft:overworld run fill 238 72 -28 238 73 -28 dirt
execute in minecraft:overworld run setblock 238 74 -28 coarse_dirt
execute in minecraft:overworld run fill 238 75 -28 238 144 -28 air
execute in minecraft:overworld run fill 238 58 -27 238 71 -27 stone
execute in minecraft:overworld run fill 238 72 -27 238 73 -27 dirt
execute in minecraft:overworld run setblock 238 74 -27 grass_block
execute in minecraft:overworld run fill 238 75 -27 238 144 -27 air
execute in minecraft:overworld run fill 238 58 -26 238 70 -26 stone
execute in minecraft:overworld run fill 238 71 -26 238 72 -26 dirt
execute in minecraft:overworld run setblock 238 73 -26 coarse_dirt
execute in minecraft:overworld run fill 238 74 -26 238 144 -26 air
execute in minecraft:overworld run fill 238 58 -25 238 70 -25 stone
execute in minecraft:overworld run fill 238 71 -25 238 72 -25 dirt
execute in minecraft:overworld run setblock 238 73 -25 coarse_dirt
execute in minecraft:overworld run fill 238 74 -25 238 144 -25 air
execute in minecraft:overworld run fill 238 58 -24 238 70 -24 stone
execute in minecraft:overworld run fill 238 71 -24 238 72 -24 dirt
execute in minecraft:overworld run setblock 238 73 -24 coarse_dirt
execute in minecraft:overworld run fill 238 74 -24 238 144 -24 air
execute in minecraft:overworld run fill 238 58 -23 238 69 -23 stone
execute in minecraft:overworld run fill 238 70 -23 238 71 -23 dirt
execute in minecraft:overworld run setblock 238 72 -23 coarse_dirt
execute in minecraft:overworld run fill 238 73 -23 238 144 -23 air
execute in minecraft:overworld run fill 238 58 -22 238 69 -22 stone
execute in minecraft:overworld run fill 238 70 -22 238 71 -22 dirt
execute in minecraft:overworld run setblock 238 72 -22 coarse_dirt
execute in minecraft:overworld run fill 238 73 -22 238 144 -22 air
execute in minecraft:overworld run setblock 238 73 -22 mossy_cobblestone
execute in minecraft:overworld run fill 238 58 -21 238 68 -21 stone
execute in minecraft:overworld run fill 238 69 -21 238 70 -21 dirt
execute in minecraft:overworld run setblock 238 71 -21 grass_block
execute in minecraft:overworld run fill 238 72 -21 238 144 -21 air
execute in minecraft:overworld run fill 238 58 -20 238 68 -20 stone
execute in minecraft:overworld run fill 238 69 -20 238 70 -20 dirt
execute in minecraft:overworld run setblock 238 71 -20 coarse_dirt
execute in minecraft:overworld run fill 238 72 -20 238 144 -20 air
execute in minecraft:overworld run fill 238 58 -19 238 67 -19 stone
execute in minecraft:overworld run fill 238 68 -19 238 69 -19 dirt
execute in minecraft:overworld run setblock 238 70 -19 grass_block
execute in minecraft:overworld run fill 238 71 -19 238 144 -19 air
execute in minecraft:overworld run fill 238 58 -18 238 67 -18 stone
execute in minecraft:overworld run fill 238 68 -18 238 69 -18 dirt
execute in minecraft:overworld run setblock 238 70 -18 grass_block
execute in minecraft:overworld run fill 238 71 -18 238 144 -18 air
execute in minecraft:overworld run fill 238 58 -17 238 66 -17 stone
execute in minecraft:overworld run fill 238 67 -17 238 68 -17 dirt
execute in minecraft:overworld run setblock 238 69 -17 coarse_dirt
execute in minecraft:overworld run fill 238 70 -17 238 144 -17 air
execute in minecraft:overworld run fill 238 58 -16 238 66 -16 stone
execute in minecraft:overworld run fill 238 67 -16 238 68 -16 dirt
execute in minecraft:overworld run setblock 238 69 -16 coarse_dirt
execute in minecraft:overworld run fill 238 70 -16 238 144 -16 air
execute in minecraft:overworld run fill 238 58 -15 238 66 -15 stone
execute in minecraft:overworld run fill 238 67 -15 238 68 -15 dirt
execute in minecraft:overworld run setblock 238 69 -15 coarse_dirt
execute in minecraft:overworld run fill 238 70 -15 238 144 -15 air
execute in minecraft:overworld run fill 238 58 -14 238 65 -14 stone
execute in minecraft:overworld run fill 238 66 -14 238 67 -14 dirt
execute in minecraft:overworld run setblock 238 68 -14 coarse_dirt
execute in minecraft:overworld run fill 238 69 -14 238 144 -14 air
execute in minecraft:overworld run setblock 238 69 -14 grass
execute in minecraft:overworld run fill 238 58 -13 238 65 -13 stone
execute in minecraft:overworld run fill 238 66 -13 238 67 -13 dirt
execute in minecraft:overworld run setblock 238 68 -13 grass_block
execute in minecraft:overworld run fill 238 69 -13 238 144 -13 air
execute in minecraft:overworld run fill 238 58 -12 238 65 -12 stone
execute in minecraft:overworld run fill 238 66 -12 238 67 -12 dirt
execute in minecraft:overworld run setblock 238 68 -12 coarse_dirt
execute in minecraft:overworld run fill 238 69 -12 238 144 -12 air
execute in minecraft:overworld run fill 238 58 -11 238 64 -11 stone
execute in minecraft:overworld run fill 238 65 -11 238 66 -11 dirt
execute in minecraft:overworld run setblock 238 67 -11 coarse_dirt
execute in minecraft:overworld run fill 238 68 -11 238 144 -11 air
execute in minecraft:overworld run setblock 238 68 -11 grass
execute in minecraft:overworld run fill 238 58 -10 238 64 -10 stone
execute in minecraft:overworld run fill 238 65 -10 238 66 -10 dirt
execute in minecraft:overworld run setblock 238 67 -10 grass_block
execute in minecraft:overworld run fill 238 68 -10 238 144 -10 air
execute in minecraft:overworld run setblock 238 68 -10 grass
execute in minecraft:overworld run fill 238 58 -9 238 64 -9 stone
execute in minecraft:overworld run fill 238 65 -9 238 66 -9 dirt
execute in minecraft:overworld run setblock 238 67 -9 coarse_dirt
execute in minecraft:overworld run fill 238 68 -9 238 144 -9 air
execute in minecraft:overworld run fill 238 58 -8 238 64 -8 stone
execute in minecraft:overworld run fill 238 65 -8 238 66 -8 dirt
execute in minecraft:overworld run setblock 238 67 -8 coarse_dirt
execute in minecraft:overworld run fill 238 68 -8 238 144 -8 air
execute in minecraft:overworld run fill 238 58 -7 238 64 -7 stone
execute in minecraft:overworld run fill 238 65 -7 238 66 -7 dirt
execute in minecraft:overworld run setblock 238 67 -7 coarse_dirt
execute in minecraft:overworld run fill 238 68 -7 238 144 -7 air
execute in minecraft:overworld run fill 238 58 -6 238 64 -6 stone
execute in minecraft:overworld run fill 238 65 -6 238 66 -6 dirt
execute in minecraft:overworld run setblock 238 67 -6 coarse_dirt
execute in minecraft:overworld run fill 238 68 -6 238 144 -6 air
execute in minecraft:overworld run fill 238 58 -5 238 64 -5 stone
execute in minecraft:overworld run fill 238 65 -5 238 66 -5 dirt
execute in minecraft:overworld run setblock 238 67 -5 coarse_dirt
execute in minecraft:overworld run fill 238 68 -5 238 144 -5 air
execute in minecraft:overworld run fill 238 58 -4 238 63 -4 stone
execute in minecraft:overworld run fill 238 64 -4 238 65 -4 dirt
execute in minecraft:overworld run setblock 238 66 -4 coarse_dirt
execute in minecraft:overworld run fill 238 67 -4 238 144 -4 air
execute in minecraft:overworld run fill 238 58 -3 238 63 -3 stone
execute in minecraft:overworld run fill 238 64 -3 238 65 -3 dirt
execute in minecraft:overworld run setblock 238 66 -3 grass_block
execute in minecraft:overworld run fill 238 67 -3 238 144 -3 air
execute in minecraft:overworld run fill 238 58 -2 238 63 -2 stone
execute in minecraft:overworld run fill 238 64 -2 238 65 -2 dirt
execute in minecraft:overworld run setblock 238 66 -2 grass_block
execute in minecraft:overworld run fill 238 67 -2 238 144 -2 air
execute in minecraft:overworld run fill 238 58 -1 238 63 -1 stone
execute in minecraft:overworld run fill 238 64 -1 238 65 -1 dirt
execute in minecraft:overworld run setblock 238 66 -1 coarse_dirt
execute in minecraft:overworld run fill 238 67 -1 238 144 -1 air
execute in minecraft:overworld run fill 238 58 0 238 63 0 stone
execute in minecraft:overworld run fill 238 64 0 238 65 0 dirt
execute in minecraft:overworld run setblock 238 66 0 grass_block
execute in minecraft:overworld run fill 238 67 0 238 144 0 air
execute in minecraft:overworld run fill 238 58 1 238 63 1 stone
execute in minecraft:overworld run fill 238 64 1 238 65 1 dirt
execute in minecraft:overworld run setblock 238 66 1 coarse_dirt
execute in minecraft:overworld run fill 238 67 1 238 144 1 air
execute in minecraft:overworld run fill 238 58 2 238 63 2 stone
execute in minecraft:overworld run fill 238 64 2 238 65 2 dirt
execute in minecraft:overworld run setblock 238 66 2 grass_block
execute in minecraft:overworld run fill 238 67 2 238 144 2 air
execute in minecraft:overworld run fill 238 58 3 238 63 3 stone
execute in minecraft:overworld run fill 238 64 3 238 65 3 dirt
execute in minecraft:overworld run setblock 238 66 3 coarse_dirt
execute in minecraft:overworld run fill 238 67 3 238 144 3 air
execute in minecraft:overworld run fill 238 58 4 238 64 4 stone
execute in minecraft:overworld run fill 238 65 4 238 66 4 dirt
execute in minecraft:overworld run setblock 238 67 4 coarse_dirt
execute in minecraft:overworld run fill 238 68 4 238 144 4 air
execute in minecraft:overworld run fill 238 58 5 238 64 5 stone
execute in minecraft:overworld run fill 238 65 5 238 66 5 dirt
execute in minecraft:overworld run setblock 238 67 5 coarse_dirt
execute in minecraft:overworld run fill 238 68 5 238 144 5 air
execute in minecraft:overworld run fill 238 58 6 238 64 6 stone
execute in minecraft:overworld run fill 238 65 6 238 66 6 dirt
execute in minecraft:overworld run setblock 238 67 6 coarse_dirt
execute in minecraft:overworld run fill 238 68 6 238 144 6 air
execute in minecraft:overworld run fill 238 58 7 238 65 7 stone
execute in minecraft:overworld run fill 238 66 7 238 67 7 dirt
execute in minecraft:overworld run setblock 238 68 7 coarse_dirt
execute in minecraft:overworld run fill 238 69 7 238 144 7 air
execute in minecraft:overworld run fill 238 58 8 238 65 8 stone
execute in minecraft:overworld run fill 238 66 8 238 67 8 dirt
execute in minecraft:overworld run setblock 238 68 8 grass_block
execute in minecraft:overworld run fill 238 69 8 238 144 8 air
execute in minecraft:overworld run fill 238 58 9 238 65 9 stone
execute in minecraft:overworld run fill 238 66 9 238 67 9 dirt
execute in minecraft:overworld run setblock 238 68 9 grass_block
execute in minecraft:overworld run fill 238 69 9 238 144 9 air
execute in minecraft:overworld run fill 238 58 10 238 65 10 stone
execute in minecraft:overworld run fill 238 66 10 238 67 10 dirt
execute in minecraft:overworld run setblock 238 68 10 coarse_dirt
execute in minecraft:overworld run fill 238 69 10 238 144 10 air
execute in minecraft:overworld run fill 238 58 11 238 66 11 stone
execute in minecraft:overworld run fill 238 67 11 238 68 11 dirt
execute in minecraft:overworld run setblock 238 69 11 coarse_dirt
execute in minecraft:overworld run fill 238 70 11 238 144 11 air
execute in minecraft:overworld run fill 238 58 12 238 66 12 stone
execute in minecraft:overworld run fill 238 67 12 238 68 12 dirt
execute in minecraft:overworld run setblock 238 69 12 grass_block
execute in minecraft:overworld run fill 238 70 12 238 144 12 air
execute in minecraft:overworld run fill 238 58 13 238 66 13 stone
execute in minecraft:overworld run fill 238 67 13 238 68 13 dirt
execute in minecraft:overworld run setblock 238 69 13 grass_block
execute in minecraft:overworld run fill 238 70 13 238 144 13 air
execute in minecraft:overworld run fill 238 58 14 238 66 14 stone
execute in minecraft:overworld run fill 238 67 14 238 68 14 dirt
execute in minecraft:overworld run setblock 238 69 14 coarse_dirt
execute in minecraft:overworld run fill 238 70 14 238 144 14 air
schedule function blade_gallery:random/burned/part_47 1t replace
