execute in minecraft:overworld run fill 285 65 25 285 66 25 dirt
execute in minecraft:overworld run setblock 285 67 25 coarse_dirt
execute in minecraft:overworld run fill 285 68 25 285 144 25 air
execute in minecraft:overworld run fill 285 58 26 285 64 26 stone
execute in minecraft:overworld run fill 285 65 26 285 66 26 dirt
execute in minecraft:overworld run setblock 285 67 26 grass_block
execute in minecraft:overworld run fill 285 68 26 285 144 26 air
execute in minecraft:overworld run fill 285 58 27 285 64 27 stone
execute in minecraft:overworld run fill 285 65 27 285 66 27 dirt
execute in minecraft:overworld run setblock 285 67 27 grass_block
execute in minecraft:overworld run fill 285 68 27 285 144 27 air
execute in minecraft:overworld run fill 285 58 28 285 64 28 stone
execute in minecraft:overworld run fill 285 65 28 285 66 28 dirt
execute in minecraft:overworld run setblock 285 67 28 coarse_dirt
execute in minecraft:overworld run fill 285 68 28 285 144 28 air
execute in minecraft:overworld run fill 285 58 29 285 64 29 stone
execute in minecraft:overworld run fill 285 65 29 285 66 29 dirt
execute in minecraft:overworld run setblock 285 67 29 coarse_dirt
execute in minecraft:overworld run fill 285 68 29 285 144 29 air
execute in minecraft:overworld run fill 285 58 30 285 64 30 stone
execute in minecraft:overworld run fill 285 65 30 285 66 30 dirt
execute in minecraft:overworld run setblock 285 67 30 grass_block
execute in minecraft:overworld run fill 285 68 30 285 144 30 air
execute in minecraft:overworld run fill 285 58 31 285 63 31 stone
execute in minecraft:overworld run fill 285 64 31 285 65 31 dirt
execute in minecraft:overworld run setblock 285 66 31 coarse_dirt
execute in minecraft:overworld run fill 285 67 31 285 144 31 air
execute in minecraft:overworld run fill 285 58 32 285 63 32 stone
execute in minecraft:overworld run fill 285 64 32 285 65 32 dirt
execute in minecraft:overworld run setblock 285 66 32 grass_block
execute in minecraft:overworld run fill 285 67 32 285 144 32 air
execute in minecraft:overworld run fill 285 58 33 285 62 33 stone
execute in minecraft:overworld run fill 285 63 33 285 64 33 dirt
execute in minecraft:overworld run setblock 285 65 33 coarse_dirt
execute in minecraft:overworld run fill 285 66 33 285 144 33 air
execute in minecraft:overworld run fill 285 58 34 285 62 34 stone
execute in minecraft:overworld run fill 285 63 34 285 64 34 dirt
execute in minecraft:overworld run setblock 285 65 34 coarse_dirt
execute in minecraft:overworld run fill 285 66 34 285 144 34 air
execute in minecraft:overworld run fill 285 58 35 285 62 35 stone
execute in minecraft:overworld run fill 285 63 35 285 64 35 dirt
execute in minecraft:overworld run setblock 285 65 35 coarse_dirt
execute in minecraft:overworld run fill 285 66 35 285 144 35 air
execute in minecraft:overworld run fill 285 58 36 285 62 36 stone
execute in minecraft:overworld run fill 285 63 36 285 64 36 dirt
execute in minecraft:overworld run setblock 285 65 36 coarse_dirt
execute in minecraft:overworld run fill 285 66 36 285 144 36 air
execute in minecraft:overworld run fill 285 58 37 285 62 37 stone
execute in minecraft:overworld run fill 285 63 37 285 64 37 dirt
execute in minecraft:overworld run setblock 285 65 37 grass_block
execute in minecraft:overworld run fill 285 66 37 285 144 37 air
execute in minecraft:overworld run fill 285 58 38 285 62 38 stone
execute in minecraft:overworld run fill 285 63 38 285 64 38 dirt
execute in minecraft:overworld run setblock 285 65 38 coarse_dirt
execute in minecraft:overworld run fill 285 66 38 285 144 38 air
execute in minecraft:overworld run fill 285 58 39 285 62 39 stone
execute in minecraft:overworld run fill 285 63 39 285 64 39 dirt
execute in minecraft:overworld run setblock 285 65 39 coarse_dirt
execute in minecraft:overworld run fill 285 66 39 285 144 39 air
execute in minecraft:overworld run fill 285 58 40 285 62 40 stone
execute in minecraft:overworld run fill 285 63 40 285 64 40 dirt
execute in minecraft:overworld run setblock 285 65 40 coarse_dirt
execute in minecraft:overworld run fill 285 66 40 285 144 40 air
execute in minecraft:overworld run fill 285 58 41 285 62 41 stone
execute in minecraft:overworld run fill 285 63 41 285 64 41 dirt
execute in minecraft:overworld run setblock 285 65 41 grass_block
execute in minecraft:overworld run fill 285 66 41 285 144 41 air
execute in minecraft:overworld run setblock 285 66 41 grass
execute in minecraft:overworld run fill 285 58 42 285 62 42 stone
execute in minecraft:overworld run fill 285 63 42 285 64 42 dirt
execute in minecraft:overworld run setblock 285 65 42 coarse_dirt
execute in minecraft:overworld run fill 285 66 42 285 144 42 air
execute in minecraft:overworld run fill 285 58 43 285 62 43 stone
execute in minecraft:overworld run fill 285 63 43 285 64 43 dirt
execute in minecraft:overworld run setblock 285 65 43 coarse_dirt
execute in minecraft:overworld run fill 285 66 43 285 144 43 air
execute in minecraft:overworld run fill 285 58 44 285 62 44 stone
execute in minecraft:overworld run fill 285 63 44 285 64 44 dirt
execute in minecraft:overworld run setblock 285 65 44 grass_block
execute in minecraft:overworld run fill 285 66 44 285 144 44 air
execute in minecraft:overworld run fill 285 58 45 285 62 45 stone
execute in minecraft:overworld run fill 285 63 45 285 64 45 dirt
execute in minecraft:overworld run setblock 285 65 45 coarse_dirt
execute in minecraft:overworld run fill 285 66 45 285 144 45 air
execute in minecraft:overworld run fill 285 58 46 285 61 46 stone
execute in minecraft:overworld run fill 285 62 46 285 63 46 dirt
execute in minecraft:overworld run setblock 285 64 46 grass_block
execute in minecraft:overworld run fill 285 65 46 285 144 46 air
execute in minecraft:overworld run fill 285 58 47 285 61 47 stone
execute in minecraft:overworld run fill 285 62 47 285 63 47 dirt
execute in minecraft:overworld run setblock 285 64 47 coarse_dirt
execute in minecraft:overworld run fill 285 65 47 285 144 47 air
execute in minecraft:overworld run fill 286 58 -48 286 61 -48 stone
execute in minecraft:overworld run fill 286 62 -48 286 63 -48 dirt
execute in minecraft:overworld run setblock 286 64 -48 grass_block
execute in minecraft:overworld run fill 286 65 -48 286 144 -48 air
execute in minecraft:overworld run fill 286 58 -47 286 63 -47 stone
execute in minecraft:overworld run fill 286 64 -47 286 65 -47 dirt
execute in minecraft:overworld run setblock 286 66 -47 grass_block
execute in minecraft:overworld run fill 286 67 -47 286 144 -47 air
execute in minecraft:overworld run fill 286 58 -46 286 65 -46 stone
execute in minecraft:overworld run fill 286 66 -46 286 67 -46 dirt
execute in minecraft:overworld run setblock 286 68 -46 coarse_dirt
execute in minecraft:overworld run fill 286 69 -46 286 144 -46 air
execute in minecraft:overworld run fill 286 58 -45 286 67 -45 stone
execute in minecraft:overworld run fill 286 68 -45 286 69 -45 dirt
execute in minecraft:overworld run setblock 286 70 -45 coarse_dirt
execute in minecraft:overworld run fill 286 71 -45 286 144 -45 air
execute in minecraft:overworld run fill 286 58 -44 286 69 -44 stone
execute in minecraft:overworld run fill 286 70 -44 286 71 -44 dirt
execute in minecraft:overworld run setblock 286 72 -44 coarse_dirt
execute in minecraft:overworld run fill 286 73 -44 286 144 -44 air
execute in minecraft:overworld run fill 286 58 -43 286 71 -43 stone
execute in minecraft:overworld run fill 286 72 -43 286 73 -43 dirt
execute in minecraft:overworld run setblock 286 74 -43 coarse_dirt
execute in minecraft:overworld run fill 286 75 -43 286 144 -43 air
execute in minecraft:overworld run fill 286 58 -42 286 72 -42 stone
execute in minecraft:overworld run fill 286 73 -42 286 74 -42 dirt
execute in minecraft:overworld run setblock 286 75 -42 coarse_dirt
execute in minecraft:overworld run fill 286 76 -42 286 144 -42 air
execute in minecraft:overworld run fill 286 58 -41 286 74 -41 stone
execute in minecraft:overworld run fill 286 75 -41 286 76 -41 dirt
execute in minecraft:overworld run setblock 286 77 -41 coarse_dirt
execute in minecraft:overworld run fill 286 78 -41 286 144 -41 air
execute in minecraft:overworld run fill 286 58 -40 286 76 -40 stone
execute in minecraft:overworld run fill 286 77 -40 286 78 -40 dirt
execute in minecraft:overworld run setblock 286 79 -40 coarse_dirt
execute in minecraft:overworld run fill 286 80 -40 286 144 -40 air
execute in minecraft:overworld run fill 286 58 -39 286 78 -39 stone
execute in minecraft:overworld run fill 286 79 -39 286 80 -39 dirt
execute in minecraft:overworld run setblock 286 81 -39 coarse_dirt
execute in minecraft:overworld run fill 286 82 -39 286 144 -39 air
execute in minecraft:overworld run fill 286 58 -38 286 79 -38 stone
execute in minecraft:overworld run fill 286 80 -38 286 81 -38 dirt
execute in minecraft:overworld run setblock 286 82 -38 coarse_dirt
execute in minecraft:overworld run fill 286 83 -38 286 144 -38 air
execute in minecraft:overworld run fill 286 58 -37 286 79 -37 stone
execute in minecraft:overworld run fill 286 80 -37 286 81 -37 dirt
execute in minecraft:overworld run setblock 286 82 -37 grass_block
execute in minecraft:overworld run fill 286 83 -37 286 144 -37 air
execute in minecraft:overworld run fill 286 58 -36 286 78 -36 stone
execute in minecraft:overworld run fill 286 79 -36 286 80 -36 dirt
execute in minecraft:overworld run setblock 286 81 -36 grass_block
execute in minecraft:overworld run fill 286 82 -36 286 144 -36 air
execute in minecraft:overworld run fill 286 58 -35 286 78 -35 stone
execute in minecraft:overworld run fill 286 79 -35 286 80 -35 dirt
execute in minecraft:overworld run setblock 286 81 -35 grass_block
execute in minecraft:overworld run fill 286 82 -35 286 144 -35 air
execute in minecraft:overworld run fill 286 58 -34 286 78 -34 stone
execute in minecraft:overworld run fill 286 79 -34 286 80 -34 dirt
execute in minecraft:overworld run setblock 286 81 -34 grass_block
execute in minecraft:overworld run fill 286 82 -34 286 144 -34 air
execute in minecraft:overworld run setblock 286 82 -34 grass
execute in minecraft:overworld run fill 286 58 -33 286 77 -33 stone
execute in minecraft:overworld run fill 286 78 -33 286 79 -33 dirt
execute in minecraft:overworld run setblock 286 80 -33 coarse_dirt
execute in minecraft:overworld run fill 286 81 -33 286 144 -33 air
execute in minecraft:overworld run fill 286 58 -32 286 76 -32 stone
execute in minecraft:overworld run fill 286 77 -32 286 78 -32 dirt
execute in minecraft:overworld run setblock 286 79 -32 coarse_dirt
execute in minecraft:overworld run fill 286 80 -32 286 144 -32 air
execute in minecraft:overworld run fill 286 58 -31 286 76 -31 stone
execute in minecraft:overworld run fill 286 77 -31 286 78 -31 dirt
execute in minecraft:overworld run setblock 286 79 -31 coarse_dirt
execute in minecraft:overworld run fill 286 80 -31 286 144 -31 air
execute in minecraft:overworld run fill 286 58 -30 286 75 -30 stone
execute in minecraft:overworld run fill 286 76 -30 286 77 -30 dirt
execute in minecraft:overworld run setblock 286 78 -30 coarse_dirt
execute in minecraft:overworld run fill 286 79 -30 286 144 -30 air
execute in minecraft:overworld run fill 286 58 -29 286 75 -29 stone
execute in minecraft:overworld run fill 286 76 -29 286 77 -29 dirt
execute in minecraft:overworld run setblock 286 78 -29 coarse_dirt
execute in minecraft:overworld run fill 286 79 -29 286 144 -29 air
execute in minecraft:overworld run fill 286 58 -28 286 74 -28 stone
execute in minecraft:overworld run fill 286 75 -28 286 76 -28 dirt
execute in minecraft:overworld run setblock 286 77 -28 coarse_dirt
execute in minecraft:overworld run fill 286 78 -28 286 144 -28 air
execute in minecraft:overworld run fill 286 58 -27 286 74 -27 stone
execute in minecraft:overworld run fill 286 75 -27 286 76 -27 dirt
execute in minecraft:overworld run setblock 286 77 -27 grass_block
execute in minecraft:overworld run fill 286 78 -27 286 144 -27 air
execute in minecraft:overworld run setblock 286 78 -27 grass
execute in minecraft:overworld run fill 286 58 -26 286 73 -26 stone
execute in minecraft:overworld run fill 286 74 -26 286 75 -26 dirt
execute in minecraft:overworld run setblock 286 76 -26 coarse_dirt
execute in minecraft:overworld run fill 286 77 -26 286 144 -26 air
execute in minecraft:overworld run setblock 286 77 -26 mossy_cobblestone
execute in minecraft:overworld run fill 286 58 -25 286 73 -25 stone
execute in minecraft:overworld run fill 286 74 -25 286 75 -25 dirt
execute in minecraft:overworld run setblock 286 76 -25 coarse_dirt
execute in minecraft:overworld run fill 286 77 -25 286 144 -25 air
execute in minecraft:overworld run fill 286 58 -24 286 73 -24 stone
execute in minecraft:overworld run fill 286 74 -24 286 75 -24 dirt
execute in minecraft:overworld run setblock 286 76 -24 coarse_dirt
execute in minecraft:overworld run fill 286 77 -24 286 144 -24 air
execute in minecraft:overworld run fill 286 58 -23 286 72 -23 stone
execute in minecraft:overworld run fill 286 73 -23 286 74 -23 dirt
execute in minecraft:overworld run setblock 286 75 -23 coarse_dirt
execute in minecraft:overworld run fill 286 76 -23 286 144 -23 air
execute in minecraft:overworld run fill 286 58 -22 286 72 -22 stone
execute in minecraft:overworld run fill 286 73 -22 286 74 -22 dirt
execute in minecraft:overworld run setblock 286 75 -22 coarse_dirt
execute in minecraft:overworld run fill 286 76 -22 286 144 -22 air
execute in minecraft:overworld run fill 286 58 -21 286 72 -21 stone
execute in minecraft:overworld run fill 286 73 -21 286 74 -21 dirt
execute in minecraft:overworld run setblock 286 75 -21 grass_block
execute in minecraft:overworld run fill 286 76 -21 286 144 -21 air
execute in minecraft:overworld run fill 286 58 -20 286 72 -20 stone
execute in minecraft:overworld run fill 286 73 -20 286 74 -20 dirt
execute in minecraft:overworld run setblock 286 75 -20 grass_block
execute in minecraft:overworld run fill 286 76 -20 286 144 -20 air
execute in minecraft:overworld run fill 286 58 -19 286 71 -19 stone
execute in minecraft:overworld run fill 286 72 -19 286 73 -19 dirt
execute in minecraft:overworld run setblock 286 74 -19 grass_block
execute in minecraft:overworld run fill 286 75 -19 286 144 -19 air
execute in minecraft:overworld run setblock 286 75 -19 grass
execute in minecraft:overworld run fill 286 58 -18 286 71 -18 stone
execute in minecraft:overworld run fill 286 72 -18 286 73 -18 dirt
execute in minecraft:overworld run setblock 286 74 -18 grass_block
execute in minecraft:overworld run fill 286 75 -18 286 144 -18 air
execute in minecraft:overworld run fill 286 58 -17 286 71 -17 stone
execute in minecraft:overworld run fill 286 72 -17 286 73 -17 dirt
execute in minecraft:overworld run setblock 286 74 -17 grass_block
execute in minecraft:overworld run fill 286 75 -17 286 144 -17 air
execute in minecraft:overworld run fill 286 58 -16 286 70 -16 stone
execute in minecraft:overworld run fill 286 71 -16 286 72 -16 dirt
execute in minecraft:overworld run setblock 286 73 -16 coarse_dirt
execute in minecraft:overworld run fill 286 74 -16 286 144 -16 air
execute in minecraft:overworld run fill 286 58 -15 286 70 -15 stone
execute in minecraft:overworld run fill 286 71 -15 286 72 -15 dirt
execute in minecraft:overworld run setblock 286 73 -15 grass_block
execute in minecraft:overworld run fill 286 74 -15 286 144 -15 air
execute in minecraft:overworld run fill 286 58 -14 286 70 -14 stone
execute in minecraft:overworld run fill 286 71 -14 286 72 -14 dirt
execute in minecraft:overworld run setblock 286 73 -14 coarse_dirt
execute in minecraft:overworld run fill 286 74 -14 286 144 -14 air
execute in minecraft:overworld run fill 286 58 -13 286 70 -13 stone
execute in minecraft:overworld run fill 286 71 -13 286 72 -13 dirt
execute in minecraft:overworld run setblock 286 73 -13 coarse_dirt
execute in minecraft:overworld run fill 286 74 -13 286 144 -13 air
execute in minecraft:overworld run fill 286 58 -12 286 69 -12 stone
execute in minecraft:overworld run fill 286 70 -12 286 71 -12 dirt
execute in minecraft:overworld run setblock 286 72 -12 grass_block
execute in minecraft:overworld run fill 286 73 -12 286 144 -12 air
execute in minecraft:overworld run fill 286 58 -11 286 69 -11 stone
execute in minecraft:overworld run fill 286 70 -11 286 71 -11 dirt
execute in minecraft:overworld run setblock 286 72 -11 coarse_dirt
execute in minecraft:overworld run fill 286 73 -11 286 144 -11 air
execute in minecraft:overworld run fill 286 58 -10 286 70 -10 stone
execute in minecraft:overworld run fill 286 71 -10 286 72 -10 dirt
execute in minecraft:overworld run setblock 286 73 -10 coarse_dirt
execute in minecraft:overworld run fill 286 74 -10 286 144 -10 air
execute in minecraft:overworld run fill 286 58 -9 286 70 -9 stone
execute in minecraft:overworld run fill 286 71 -9 286 72 -9 dirt
execute in minecraft:overworld run setblock 286 73 -9 coarse_dirt
execute in minecraft:overworld run fill 286 74 -9 286 144 -9 air
schedule function blade_gallery:random/burned/part_124 1t replace
