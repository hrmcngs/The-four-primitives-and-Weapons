execute in minecraft:overworld run fill 400 75 -35 400 76 -35 dirt
execute in minecraft:overworld run setblock 400 77 -35 coarse_dirt
execute in minecraft:overworld run fill 400 78 -35 400 144 -35 air
execute in minecraft:overworld run fill 400 58 -34 400 74 -34 stone
execute in minecraft:overworld run fill 400 75 -34 400 76 -34 dirt
execute in minecraft:overworld run setblock 400 77 -34 coarse_dirt
execute in minecraft:overworld run fill 400 78 -34 400 144 -34 air
execute in minecraft:overworld run fill 400 58 -33 400 74 -33 stone
execute in minecraft:overworld run fill 400 75 -33 400 76 -33 dirt
execute in minecraft:overworld run setblock 400 77 -33 grass_block
execute in minecraft:overworld run fill 400 78 -33 400 144 -33 air
execute in minecraft:overworld run setblock 400 78 -33 mossy_cobblestone
execute in minecraft:overworld run fill 400 58 -32 400 73 -32 stone
execute in minecraft:overworld run fill 400 74 -32 400 75 -32 dirt
execute in minecraft:overworld run setblock 400 76 -32 coarse_dirt
execute in minecraft:overworld run fill 400 77 -32 400 144 -32 air
execute in minecraft:overworld run fill 400 58 -31 400 73 -31 stone
execute in minecraft:overworld run fill 400 74 -31 400 75 -31 dirt
execute in minecraft:overworld run setblock 400 76 -31 coarse_dirt
execute in minecraft:overworld run fill 400 77 -31 400 144 -31 air
execute in minecraft:overworld run fill 400 58 -30 400 73 -30 stone
execute in minecraft:overworld run fill 400 74 -30 400 75 -30 dirt
execute in minecraft:overworld run setblock 400 76 -30 coarse_dirt
execute in minecraft:overworld run fill 400 77 -30 400 144 -30 air
execute in minecraft:overworld run fill 400 58 -29 400 72 -29 stone
execute in minecraft:overworld run fill 400 73 -29 400 74 -29 dirt
execute in minecraft:overworld run setblock 400 75 -29 coarse_dirt
execute in minecraft:overworld run fill 400 76 -29 400 144 -29 air
execute in minecraft:overworld run fill 400 58 -28 400 72 -28 stone
execute in minecraft:overworld run fill 400 73 -28 400 74 -28 dirt
execute in minecraft:overworld run setblock 400 75 -28 grass_block
execute in minecraft:overworld run fill 400 76 -28 400 144 -28 air
execute in minecraft:overworld run fill 400 58 -27 400 71 -27 stone
execute in minecraft:overworld run fill 400 72 -27 400 73 -27 dirt
execute in minecraft:overworld run setblock 400 74 -27 coarse_dirt
execute in minecraft:overworld run fill 400 75 -27 400 144 -27 air
execute in minecraft:overworld run fill 400 58 -26 400 71 -26 stone
execute in minecraft:overworld run fill 400 72 -26 400 73 -26 dirt
execute in minecraft:overworld run setblock 400 74 -26 grass_block
execute in minecraft:overworld run fill 400 75 -26 400 144 -26 air
execute in minecraft:overworld run fill 400 58 -25 400 71 -25 stone
execute in minecraft:overworld run fill 400 72 -25 400 73 -25 dirt
execute in minecraft:overworld run setblock 400 74 -25 coarse_dirt
execute in minecraft:overworld run fill 400 75 -25 400 144 -25 air
execute in minecraft:overworld run fill 400 58 -24 400 70 -24 stone
execute in minecraft:overworld run fill 400 71 -24 400 72 -24 dirt
execute in minecraft:overworld run setblock 400 73 -24 coarse_dirt
execute in minecraft:overworld run fill 400 74 -24 400 144 -24 air
execute in minecraft:overworld run setblock 400 74 -24 grass
execute in minecraft:overworld run fill 400 58 -23 400 70 -23 stone
execute in minecraft:overworld run fill 400 71 -23 400 72 -23 dirt
execute in minecraft:overworld run setblock 400 73 -23 coarse_dirt
execute in minecraft:overworld run fill 400 74 -23 400 144 -23 air
execute in minecraft:overworld run fill 400 58 -22 400 70 -22 stone
execute in minecraft:overworld run fill 400 71 -22 400 72 -22 dirt
execute in minecraft:overworld run setblock 400 73 -22 coarse_dirt
execute in minecraft:overworld run fill 400 74 -22 400 144 -22 air
execute in minecraft:overworld run fill 400 58 -21 400 69 -21 stone
execute in minecraft:overworld run fill 400 70 -21 400 71 -21 dirt
execute in minecraft:overworld run setblock 400 72 -21 coarse_dirt
execute in minecraft:overworld run fill 400 73 -21 400 144 -21 air
execute in minecraft:overworld run fill 400 58 -20 400 69 -20 stone
execute in minecraft:overworld run fill 400 70 -20 400 71 -20 dirt
execute in minecraft:overworld run setblock 400 72 -20 grass_block
execute in minecraft:overworld run fill 400 73 -20 400 144 -20 air
execute in minecraft:overworld run fill 400 58 -19 400 69 -19 stone
execute in minecraft:overworld run fill 400 70 -19 400 71 -19 dirt
execute in minecraft:overworld run setblock 400 72 -19 coarse_dirt
execute in minecraft:overworld run fill 400 73 -19 400 144 -19 air
execute in minecraft:overworld run fill 400 58 -18 400 68 -18 stone
execute in minecraft:overworld run fill 400 69 -18 400 70 -18 dirt
execute in minecraft:overworld run setblock 400 71 -18 coarse_dirt
execute in minecraft:overworld run fill 400 72 -18 400 144 -18 air
execute in minecraft:overworld run setblock 400 72 -18 grass
execute in minecraft:overworld run fill 400 58 -17 400 67 -17 stone
execute in minecraft:overworld run fill 400 68 -17 400 69 -17 dirt
execute in minecraft:overworld run setblock 400 70 -17 coarse_dirt
execute in minecraft:overworld run fill 400 71 -17 400 144 -17 air
execute in minecraft:overworld run fill 400 58 -16 400 67 -16 stone
execute in minecraft:overworld run fill 400 68 -16 400 69 -16 dirt
execute in minecraft:overworld run setblock 400 70 -16 coarse_dirt
execute in minecraft:overworld run fill 400 71 -16 400 144 -16 air
execute in minecraft:overworld run fill 400 58 -15 400 66 -15 stone
execute in minecraft:overworld run fill 400 67 -15 400 68 -15 dirt
execute in minecraft:overworld run setblock 400 69 -15 coarse_dirt
execute in minecraft:overworld run fill 400 70 -15 400 144 -15 air
execute in minecraft:overworld run fill 400 58 -14 400 65 -14 stone
execute in minecraft:overworld run fill 400 66 -14 400 67 -14 dirt
execute in minecraft:overworld run setblock 400 68 -14 grass_block
execute in minecraft:overworld run fill 400 69 -14 400 144 -14 air
execute in minecraft:overworld run fill 400 58 -13 400 64 -13 stone
execute in minecraft:overworld run fill 400 65 -13 400 66 -13 dirt
execute in minecraft:overworld run setblock 400 67 -13 grass_block
execute in minecraft:overworld run fill 400 68 -13 400 144 -13 air
execute in minecraft:overworld run fill 400 58 -12 400 63 -12 stone
execute in minecraft:overworld run fill 400 64 -12 400 65 -12 dirt
execute in minecraft:overworld run setblock 400 66 -12 coarse_dirt
execute in minecraft:overworld run fill 400 67 -12 400 144 -12 air
execute in minecraft:overworld run fill 400 58 -11 400 62 -11 stone
execute in minecraft:overworld run fill 400 63 -11 400 64 -11 dirt
execute in minecraft:overworld run setblock 400 65 -11 grass_block
execute in minecraft:overworld run fill 400 66 -11 400 144 -11 air
execute in minecraft:overworld run fill 400 58 -10 400 62 -10 stone
execute in minecraft:overworld run fill 400 63 -10 400 64 -10 dirt
execute in minecraft:overworld run setblock 400 65 -10 coarse_dirt
execute in minecraft:overworld run fill 400 66 -10 400 144 -10 air
execute in minecraft:overworld run fill 400 58 -9 400 61 -9 stone
execute in minecraft:overworld run fill 400 62 -9 400 63 -9 dirt
execute in minecraft:overworld run setblock 400 64 -9 coarse_dirt
execute in minecraft:overworld run fill 400 65 -9 400 144 -9 air
execute in minecraft:overworld run fill 400 58 -8 400 61 -8 stone
execute in minecraft:overworld run fill 400 62 -8 400 63 -8 dirt
execute in minecraft:overworld run setblock 400 64 -8 coarse_dirt
execute in minecraft:overworld run fill 400 65 -8 400 144 -8 air
execute in minecraft:overworld run fill 400 58 -7 400 60 -7 stone
execute in minecraft:overworld run fill 400 61 -7 400 62 -7 dirt
execute in minecraft:overworld run setblock 400 63 -7 gravel
execute in minecraft:overworld run fill 400 64 -7 400 144 -7 air
execute in minecraft:overworld run fill 400 64 -7 400 64 -7 water
execute in minecraft:overworld run fill 400 58 -6 400 60 -6 stone
execute in minecraft:overworld run fill 400 61 -6 400 62 -6 dirt
execute in minecraft:overworld run setblock 400 63 -6 gravel
execute in minecraft:overworld run fill 400 64 -6 400 144 -6 air
execute in minecraft:overworld run fill 400 64 -6 400 64 -6 water
execute in minecraft:overworld run fill 400 58 -5 400 59 -5 stone
execute in minecraft:overworld run fill 400 60 -5 400 61 -5 dirt
execute in minecraft:overworld run setblock 400 62 -5 gravel
execute in minecraft:overworld run fill 400 63 -5 400 144 -5 air
execute in minecraft:overworld run fill 400 63 -5 400 64 -5 water
execute in minecraft:overworld run fill 400 58 -4 400 59 -4 stone
execute in minecraft:overworld run fill 400 60 -4 400 61 -4 dirt
execute in minecraft:overworld run setblock 400 62 -4 gravel
execute in minecraft:overworld run fill 400 63 -4 400 144 -4 air
execute in minecraft:overworld run fill 400 63 -4 400 64 -4 water
execute in minecraft:overworld run fill 400 58 -3 400 58 -3 stone
execute in minecraft:overworld run fill 400 59 -3 400 60 -3 dirt
execute in minecraft:overworld run setblock 400 61 -3 gravel
execute in minecraft:overworld run fill 400 62 -3 400 144 -3 air
execute in minecraft:overworld run fill 400 62 -3 400 64 -3 water
execute in minecraft:overworld run fill 400 58 -2 400 58 -2 stone
execute in minecraft:overworld run fill 400 59 -2 400 60 -2 dirt
execute in minecraft:overworld run setblock 400 61 -2 gravel
execute in minecraft:overworld run fill 400 62 -2 400 144 -2 air
execute in minecraft:overworld run fill 400 62 -2 400 64 -2 water
execute in minecraft:overworld run fill 400 58 -1 400 57 -1 stone
execute in minecraft:overworld run fill 400 58 -1 400 59 -1 dirt
execute in minecraft:overworld run setblock 400 60 -1 gravel
execute in minecraft:overworld run fill 400 61 -1 400 144 -1 air
execute in minecraft:overworld run fill 400 61 -1 400 64 -1 water
execute in minecraft:overworld run fill 400 58 0 400 57 0 stone
execute in minecraft:overworld run fill 400 58 0 400 59 0 dirt
execute in minecraft:overworld run setblock 400 60 0 gravel
execute in minecraft:overworld run fill 400 61 0 400 144 0 air
execute in minecraft:overworld run fill 400 61 0 400 64 0 water
execute in minecraft:overworld run fill 400 58 1 400 57 1 stone
execute in minecraft:overworld run fill 400 58 1 400 59 1 dirt
execute in minecraft:overworld run setblock 400 60 1 gravel
execute in minecraft:overworld run fill 400 61 1 400 144 1 air
execute in minecraft:overworld run fill 400 61 1 400 64 1 water
execute in minecraft:overworld run fill 400 58 2 400 57 2 stone
execute in minecraft:overworld run fill 400 58 2 400 59 2 dirt
execute in minecraft:overworld run setblock 400 60 2 gravel
execute in minecraft:overworld run fill 400 61 2 400 144 2 air
execute in minecraft:overworld run fill 400 61 2 400 64 2 water
execute in minecraft:overworld run fill 400 58 3 400 57 3 stone
execute in minecraft:overworld run fill 400 58 3 400 59 3 dirt
execute in minecraft:overworld run setblock 400 60 3 gravel
execute in minecraft:overworld run fill 400 61 3 400 144 3 air
execute in minecraft:overworld run fill 400 61 3 400 64 3 water
execute in minecraft:overworld run fill 400 58 4 400 56 4 stone
execute in minecraft:overworld run fill 400 57 4 400 58 4 dirt
execute in minecraft:overworld run setblock 400 59 4 gravel
execute in minecraft:overworld run fill 400 60 4 400 144 4 air
execute in minecraft:overworld run fill 400 60 4 400 64 4 water
execute in minecraft:overworld run fill 400 58 5 400 56 5 stone
execute in minecraft:overworld run fill 400 57 5 400 58 5 dirt
execute in minecraft:overworld run setblock 400 59 5 gravel
execute in minecraft:overworld run fill 400 60 5 400 144 5 air
execute in minecraft:overworld run fill 400 60 5 400 64 5 water
execute in minecraft:overworld run fill 400 58 6 400 56 6 stone
execute in minecraft:overworld run fill 400 57 6 400 58 6 dirt
execute in minecraft:overworld run setblock 400 59 6 gravel
execute in minecraft:overworld run fill 400 60 6 400 144 6 air
execute in minecraft:overworld run fill 400 60 6 400 64 6 water
execute in minecraft:overworld run fill 400 58 7 400 56 7 stone
execute in minecraft:overworld run fill 400 57 7 400 58 7 dirt
execute in minecraft:overworld run setblock 400 59 7 gravel
execute in minecraft:overworld run fill 400 60 7 400 144 7 air
execute in minecraft:overworld run fill 400 60 7 400 64 7 water
execute in minecraft:overworld run fill 400 58 8 400 56 8 stone
execute in minecraft:overworld run fill 400 57 8 400 58 8 dirt
execute in minecraft:overworld run setblock 400 59 8 gravel
execute in minecraft:overworld run fill 400 60 8 400 144 8 air
execute in minecraft:overworld run fill 400 60 8 400 64 8 water
execute in minecraft:overworld run fill 400 58 9 400 57 9 stone
execute in minecraft:overworld run fill 400 58 9 400 59 9 dirt
execute in minecraft:overworld run setblock 400 60 9 gravel
execute in minecraft:overworld run fill 400 61 9 400 144 9 air
execute in minecraft:overworld run fill 400 61 9 400 64 9 water
execute in minecraft:overworld run fill 400 58 10 400 57 10 stone
execute in minecraft:overworld run fill 400 58 10 400 59 10 dirt
execute in minecraft:overworld run setblock 400 60 10 gravel
execute in minecraft:overworld run fill 400 61 10 400 144 10 air
execute in minecraft:overworld run fill 400 61 10 400 64 10 water
execute in minecraft:overworld run fill 400 58 11 400 57 11 stone
execute in minecraft:overworld run fill 400 58 11 400 59 11 dirt
execute in minecraft:overworld run setblock 400 60 11 gravel
execute in minecraft:overworld run fill 400 61 11 400 144 11 air
execute in minecraft:overworld run fill 400 61 11 400 64 11 water
execute in minecraft:overworld run fill 400 58 12 400 57 12 stone
execute in minecraft:overworld run fill 400 58 12 400 59 12 dirt
execute in minecraft:overworld run setblock 400 60 12 gravel
execute in minecraft:overworld run fill 400 61 12 400 144 12 air
execute in minecraft:overworld run fill 400 61 12 400 64 12 water
execute in minecraft:overworld run fill 400 58 13 400 58 13 stone
execute in minecraft:overworld run fill 400 59 13 400 60 13 dirt
execute in minecraft:overworld run setblock 400 61 13 gravel
execute in minecraft:overworld run fill 400 62 13 400 144 13 air
execute in minecraft:overworld run fill 400 62 13 400 64 13 water
execute in minecraft:overworld run fill 400 58 14 400 58 14 stone
execute in minecraft:overworld run fill 400 59 14 400 60 14 dirt
execute in minecraft:overworld run setblock 400 61 14 gravel
execute in minecraft:overworld run fill 400 62 14 400 144 14 air
execute in minecraft:overworld run fill 400 62 14 400 64 14 water
execute in minecraft:overworld run fill 400 58 15 400 59 15 stone
execute in minecraft:overworld run fill 400 60 15 400 61 15 dirt
execute in minecraft:overworld run setblock 400 62 15 gravel
execute in minecraft:overworld run fill 400 63 15 400 144 15 air
execute in minecraft:overworld run fill 400 63 15 400 64 15 water
execute in minecraft:overworld run fill 400 58 16 400 59 16 stone
execute in minecraft:overworld run fill 400 60 16 400 61 16 dirt
execute in minecraft:overworld run setblock 400 62 16 gravel
execute in minecraft:overworld run fill 400 63 16 400 144 16 air
execute in minecraft:overworld run fill 400 63 16 400 64 16 water
execute in minecraft:overworld run fill 400 58 17 400 59 17 stone
execute in minecraft:overworld run fill 400 60 17 400 61 17 dirt
execute in minecraft:overworld run setblock 400 62 17 gravel
execute in minecraft:overworld run fill 400 63 17 400 144 17 air
execute in minecraft:overworld run fill 400 63 17 400 64 17 water
execute in minecraft:overworld run fill 400 58 18 400 60 18 stone
execute in minecraft:overworld run fill 400 61 18 400 62 18 dirt
execute in minecraft:overworld run setblock 400 63 18 gravel
execute in minecraft:overworld run fill 400 64 18 400 144 18 air
execute in minecraft:overworld run fill 400 64 18 400 64 18 water
execute in minecraft:overworld run fill 400 58 19 400 60 19 stone
execute in minecraft:overworld run fill 400 61 19 400 62 19 dirt
execute in minecraft:overworld run setblock 400 63 19 gravel
execute in minecraft:overworld run fill 400 64 19 400 144 19 air
execute in minecraft:overworld run fill 400 64 19 400 64 19 water
execute in minecraft:overworld run fill 400 58 20 400 60 20 stone
execute in minecraft:overworld run fill 400 61 20 400 62 20 dirt
execute in minecraft:overworld run setblock 400 63 20 gravel
execute in minecraft:overworld run fill 400 64 20 400 144 20 air
execute in minecraft:overworld run fill 400 64 20 400 64 20 water
execute in minecraft:overworld run fill 400 58 21 400 61 21 stone
execute in minecraft:overworld run fill 400 62 21 400 63 21 dirt
schedule function blade_gallery:random/battlefield/part_102 1t replace
