execute in minecraft:overworld run fill 296 69 27 296 144 27 air
execute in minecraft:overworld run fill 296 58 28 296 65 28 stone
execute in minecraft:overworld run fill 296 66 28 296 67 28 dirt
execute in minecraft:overworld run setblock 296 68 28 coarse_dirt
execute in minecraft:overworld run fill 296 69 28 296 144 28 air
execute in minecraft:overworld run fill 296 58 29 296 65 29 stone
execute in minecraft:overworld run fill 296 66 29 296 67 29 dirt
execute in minecraft:overworld run setblock 296 68 29 coarse_dirt
execute in minecraft:overworld run fill 296 69 29 296 144 29 air
execute in minecraft:overworld run fill 296 58 30 296 65 30 stone
execute in minecraft:overworld run fill 296 66 30 296 67 30 dirt
execute in minecraft:overworld run setblock 296 68 30 coarse_dirt
execute in minecraft:overworld run fill 296 69 30 296 144 30 air
execute in minecraft:overworld run fill 296 58 31 296 65 31 stone
execute in minecraft:overworld run fill 296 66 31 296 67 31 dirt
execute in minecraft:overworld run setblock 296 68 31 grass_block
execute in minecraft:overworld run fill 296 69 31 296 144 31 air
execute in minecraft:overworld run fill 296 58 32 296 64 32 stone
execute in minecraft:overworld run fill 296 65 32 296 66 32 dirt
execute in minecraft:overworld run setblock 296 67 32 coarse_dirt
execute in minecraft:overworld run fill 296 68 32 296 144 32 air
execute in minecraft:overworld run fill 296 58 33 296 64 33 stone
execute in minecraft:overworld run fill 296 65 33 296 66 33 dirt
execute in minecraft:overworld run setblock 296 67 33 grass_block
execute in minecraft:overworld run fill 296 68 33 296 144 33 air
execute in minecraft:overworld run fill 296 58 34 296 64 34 stone
execute in minecraft:overworld run fill 296 65 34 296 66 34 dirt
execute in minecraft:overworld run setblock 296 67 34 coarse_dirt
execute in minecraft:overworld run fill 296 68 34 296 144 34 air
execute in minecraft:overworld run setblock 296 68 34 grass
execute in minecraft:overworld run fill 296 58 35 296 64 35 stone
execute in minecraft:overworld run fill 296 65 35 296 66 35 dirt
execute in minecraft:overworld run setblock 296 67 35 grass_block
execute in minecraft:overworld run fill 296 68 35 296 144 35 air
execute in minecraft:overworld run fill 296 58 36 296 64 36 stone
execute in minecraft:overworld run fill 296 65 36 296 66 36 dirt
execute in minecraft:overworld run setblock 296 67 36 coarse_dirt
execute in minecraft:overworld run fill 296 68 36 296 144 36 air
execute in minecraft:overworld run fill 296 58 37 296 64 37 stone
execute in minecraft:overworld run fill 296 65 37 296 66 37 dirt
execute in minecraft:overworld run setblock 296 67 37 coarse_dirt
execute in minecraft:overworld run fill 296 68 37 296 144 37 air
execute in minecraft:overworld run fill 296 58 38 296 64 38 stone
execute in minecraft:overworld run fill 296 65 38 296 66 38 dirt
execute in minecraft:overworld run setblock 296 67 38 grass_block
execute in minecraft:overworld run fill 296 68 38 296 144 38 air
execute in minecraft:overworld run fill 296 58 39 296 64 39 stone
execute in minecraft:overworld run fill 296 65 39 296 66 39 dirt
execute in minecraft:overworld run setblock 296 67 39 coarse_dirt
execute in minecraft:overworld run fill 296 68 39 296 144 39 air
execute in minecraft:overworld run fill 296 58 40 296 64 40 stone
execute in minecraft:overworld run fill 296 65 40 296 66 40 dirt
execute in minecraft:overworld run setblock 296 67 40 coarse_dirt
execute in minecraft:overworld run fill 296 68 40 296 144 40 air
execute in minecraft:overworld run fill 296 58 41 296 63 41 stone
execute in minecraft:overworld run fill 296 64 41 296 65 41 dirt
execute in minecraft:overworld run setblock 296 66 41 coarse_dirt
execute in minecraft:overworld run fill 296 67 41 296 144 41 air
execute in minecraft:overworld run fill 296 58 42 296 63 42 stone
execute in minecraft:overworld run fill 296 64 42 296 65 42 dirt
execute in minecraft:overworld run setblock 296 66 42 coarse_dirt
execute in minecraft:overworld run fill 296 67 42 296 144 42 air
execute in minecraft:overworld run fill 296 58 43 296 62 43 stone
execute in minecraft:overworld run fill 296 63 43 296 64 43 dirt
execute in minecraft:overworld run setblock 296 65 43 coarse_dirt
execute in minecraft:overworld run fill 296 66 43 296 144 43 air
execute in minecraft:overworld run fill 296 58 44 296 62 44 stone
execute in minecraft:overworld run fill 296 63 44 296 64 44 dirt
execute in minecraft:overworld run setblock 296 65 44 coarse_dirt
execute in minecraft:overworld run fill 296 66 44 296 144 44 air
execute in minecraft:overworld run fill 296 58 45 296 62 45 stone
execute in minecraft:overworld run fill 296 63 45 296 64 45 dirt
execute in minecraft:overworld run setblock 296 65 45 grass_block
execute in minecraft:overworld run fill 296 66 45 296 144 45 air
execute in minecraft:overworld run fill 296 58 46 296 61 46 stone
execute in minecraft:overworld run fill 296 62 46 296 63 46 dirt
execute in minecraft:overworld run setblock 296 64 46 coarse_dirt
execute in minecraft:overworld run fill 296 65 46 296 144 46 air
execute in minecraft:overworld run fill 296 58 47 296 61 47 stone
execute in minecraft:overworld run fill 296 62 47 296 63 47 dirt
execute in minecraft:overworld run setblock 296 64 47 coarse_dirt
execute in minecraft:overworld run fill 296 65 47 296 144 47 air
execute in minecraft:overworld run fill 297 58 -48 297 61 -48 stone
execute in minecraft:overworld run fill 297 62 -48 297 63 -48 dirt
execute in minecraft:overworld run setblock 297 64 -48 coarse_dirt
execute in minecraft:overworld run fill 297 65 -48 297 144 -48 air
execute in minecraft:overworld run fill 297 58 -47 297 63 -47 stone
execute in minecraft:overworld run fill 297 64 -47 297 65 -47 dirt
execute in minecraft:overworld run setblock 297 66 -47 coarse_dirt
execute in minecraft:overworld run fill 297 67 -47 297 144 -47 air
execute in minecraft:overworld run fill 297 58 -46 297 65 -46 stone
execute in minecraft:overworld run fill 297 66 -46 297 67 -46 dirt
execute in minecraft:overworld run setblock 297 68 -46 grass_block
execute in minecraft:overworld run fill 297 69 -46 297 144 -46 air
execute in minecraft:overworld run fill 297 58 -45 297 67 -45 stone
execute in minecraft:overworld run fill 297 68 -45 297 69 -45 dirt
execute in minecraft:overworld run setblock 297 70 -45 coarse_dirt
execute in minecraft:overworld run fill 297 71 -45 297 144 -45 air
execute in minecraft:overworld run fill 297 58 -44 297 69 -44 stone
execute in minecraft:overworld run fill 297 70 -44 297 71 -44 dirt
execute in minecraft:overworld run setblock 297 72 -44 grass_block
execute in minecraft:overworld run fill 297 73 -44 297 144 -44 air
execute in minecraft:overworld run fill 297 58 -43 297 70 -43 stone
execute in minecraft:overworld run fill 297 71 -43 297 72 -43 dirt
execute in minecraft:overworld run setblock 297 73 -43 coarse_dirt
execute in minecraft:overworld run fill 297 74 -43 297 144 -43 air
execute in minecraft:overworld run fill 297 58 -42 297 72 -42 stone
execute in minecraft:overworld run fill 297 73 -42 297 74 -42 dirt
execute in minecraft:overworld run setblock 297 75 -42 coarse_dirt
execute in minecraft:overworld run fill 297 76 -42 297 144 -42 air
execute in minecraft:overworld run fill 297 58 -41 297 74 -41 stone
execute in minecraft:overworld run fill 297 75 -41 297 76 -41 dirt
execute in minecraft:overworld run setblock 297 77 -41 coarse_dirt
execute in minecraft:overworld run fill 297 78 -41 297 144 -41 air
execute in minecraft:overworld run fill 297 58 -40 297 74 -40 stone
execute in minecraft:overworld run fill 297 75 -40 297 76 -40 dirt
execute in minecraft:overworld run setblock 297 77 -40 grass_block
execute in minecraft:overworld run fill 297 78 -40 297 144 -40 air
execute in minecraft:overworld run fill 297 58 -39 297 74 -39 stone
execute in minecraft:overworld run fill 297 75 -39 297 76 -39 dirt
execute in minecraft:overworld run setblock 297 77 -39 coarse_dirt
execute in minecraft:overworld run fill 297 78 -39 297 144 -39 air
execute in minecraft:overworld run fill 297 58 -38 297 74 -38 stone
execute in minecraft:overworld run fill 297 75 -38 297 76 -38 dirt
execute in minecraft:overworld run setblock 297 77 -38 grass_block
execute in minecraft:overworld run fill 297 78 -38 297 144 -38 air
execute in minecraft:overworld run fill 297 58 -37 297 74 -37 stone
execute in minecraft:overworld run fill 297 75 -37 297 76 -37 dirt
execute in minecraft:overworld run setblock 297 77 -37 coarse_dirt
execute in minecraft:overworld run fill 297 78 -37 297 144 -37 air
execute in minecraft:overworld run fill 297 58 -36 297 73 -36 stone
execute in minecraft:overworld run fill 297 74 -36 297 75 -36 dirt
execute in minecraft:overworld run setblock 297 76 -36 coarse_dirt
execute in minecraft:overworld run fill 297 77 -36 297 144 -36 air
execute in minecraft:overworld run fill 297 58 -35 297 73 -35 stone
execute in minecraft:overworld run fill 297 74 -35 297 75 -35 dirt
execute in minecraft:overworld run setblock 297 76 -35 coarse_dirt
execute in minecraft:overworld run fill 297 77 -35 297 144 -35 air
execute in minecraft:overworld run fill 297 58 -34 297 73 -34 stone
execute in minecraft:overworld run fill 297 74 -34 297 75 -34 dirt
execute in minecraft:overworld run setblock 297 76 -34 coarse_dirt
execute in minecraft:overworld run fill 297 77 -34 297 144 -34 air
execute in minecraft:overworld run fill 297 58 -33 297 73 -33 stone
execute in minecraft:overworld run fill 297 74 -33 297 75 -33 dirt
execute in minecraft:overworld run setblock 297 76 -33 coarse_dirt
execute in minecraft:overworld run fill 297 77 -33 297 144 -33 air
execute in minecraft:overworld run fill 297 58 -32 297 72 -32 stone
execute in minecraft:overworld run fill 297 73 -32 297 74 -32 dirt
execute in minecraft:overworld run setblock 297 75 -32 coarse_dirt
execute in minecraft:overworld run fill 297 76 -32 297 144 -32 air
execute in minecraft:overworld run fill 297 58 -31 297 72 -31 stone
execute in minecraft:overworld run fill 297 73 -31 297 74 -31 dirt
execute in minecraft:overworld run setblock 297 75 -31 grass_block
execute in minecraft:overworld run fill 297 76 -31 297 144 -31 air
execute in minecraft:overworld run fill 297 58 -30 297 72 -30 stone
execute in minecraft:overworld run fill 297 73 -30 297 74 -30 dirt
execute in minecraft:overworld run setblock 297 75 -30 coarse_dirt
execute in minecraft:overworld run fill 297 76 -30 297 144 -30 air
execute in minecraft:overworld run fill 297 58 -29 297 72 -29 stone
execute in minecraft:overworld run fill 297 73 -29 297 74 -29 dirt
execute in minecraft:overworld run setblock 297 75 -29 coarse_dirt
execute in minecraft:overworld run fill 297 76 -29 297 144 -29 air
execute in minecraft:overworld run fill 297 58 -28 297 71 -28 stone
execute in minecraft:overworld run fill 297 72 -28 297 73 -28 dirt
execute in minecraft:overworld run setblock 297 74 -28 grass_block
execute in minecraft:overworld run fill 297 75 -28 297 144 -28 air
execute in minecraft:overworld run fill 297 58 -27 297 71 -27 stone
execute in minecraft:overworld run fill 297 72 -27 297 73 -27 dirt
execute in minecraft:overworld run setblock 297 74 -27 coarse_dirt
execute in minecraft:overworld run fill 297 75 -27 297 144 -27 air
execute in minecraft:overworld run setblock 297 75 -27 mossy_cobblestone
execute in minecraft:overworld run fill 297 58 -26 297 71 -26 stone
execute in minecraft:overworld run fill 297 72 -26 297 73 -26 dirt
execute in minecraft:overworld run setblock 297 74 -26 grass_block
execute in minecraft:overworld run fill 297 75 -26 297 144 -26 air
execute in minecraft:overworld run fill 297 58 -25 297 70 -25 stone
execute in minecraft:overworld run fill 297 71 -25 297 72 -25 dirt
execute in minecraft:overworld run setblock 297 73 -25 coarse_dirt
execute in minecraft:overworld run fill 297 74 -25 297 144 -25 air
execute in minecraft:overworld run fill 297 58 -24 297 70 -24 stone
execute in minecraft:overworld run fill 297 71 -24 297 72 -24 dirt
execute in minecraft:overworld run setblock 297 73 -24 grass_block
execute in minecraft:overworld run fill 297 74 -24 297 144 -24 air
execute in minecraft:overworld run fill 297 58 -23 297 70 -23 stone
execute in minecraft:overworld run fill 297 71 -23 297 72 -23 dirt
execute in minecraft:overworld run setblock 297 73 -23 coarse_dirt
execute in minecraft:overworld run fill 297 74 -23 297 144 -23 air
execute in minecraft:overworld run fill 297 58 -22 297 69 -22 stone
execute in minecraft:overworld run fill 297 70 -22 297 71 -22 dirt
execute in minecraft:overworld run setblock 297 72 -22 coarse_dirt
execute in minecraft:overworld run fill 297 73 -22 297 144 -22 air
execute in minecraft:overworld run fill 297 58 -21 297 69 -21 stone
execute in minecraft:overworld run fill 297 70 -21 297 71 -21 dirt
execute in minecraft:overworld run setblock 297 72 -21 coarse_dirt
execute in minecraft:overworld run fill 297 73 -21 297 144 -21 air
execute in minecraft:overworld run setblock 297 73 -21 grass
execute in minecraft:overworld run fill 297 58 -20 297 68 -20 stone
execute in minecraft:overworld run fill 297 69 -20 297 70 -20 dirt
execute in minecraft:overworld run setblock 297 71 -20 grass_block
execute in minecraft:overworld run fill 297 72 -20 297 144 -20 air
execute in minecraft:overworld run fill 297 58 -19 297 68 -19 stone
execute in minecraft:overworld run fill 297 69 -19 297 70 -19 dirt
execute in minecraft:overworld run setblock 297 71 -19 coarse_dirt
execute in minecraft:overworld run fill 297 72 -19 297 144 -19 air
execute in minecraft:overworld run setblock 297 72 -19 grass
execute in minecraft:overworld run fill 297 58 -18 297 68 -18 stone
execute in minecraft:overworld run fill 297 69 -18 297 70 -18 dirt
execute in minecraft:overworld run setblock 297 71 -18 grass_block
execute in minecraft:overworld run fill 297 72 -18 297 144 -18 air
execute in minecraft:overworld run setblock 297 72 -18 grass
execute in minecraft:overworld run fill 297 58 -17 297 67 -17 stone
execute in minecraft:overworld run fill 297 68 -17 297 69 -17 dirt
execute in minecraft:overworld run setblock 297 70 -17 grass_block
execute in minecraft:overworld run fill 297 71 -17 297 144 -17 air
execute in minecraft:overworld run fill 297 58 -16 297 67 -16 stone
execute in minecraft:overworld run fill 297 68 -16 297 69 -16 dirt
execute in minecraft:overworld run setblock 297 70 -16 coarse_dirt
execute in minecraft:overworld run fill 297 71 -16 297 144 -16 air
execute in minecraft:overworld run setblock 297 71 -16 grass
execute in minecraft:overworld run fill 297 58 -15 297 67 -15 stone
execute in minecraft:overworld run fill 297 68 -15 297 69 -15 dirt
execute in minecraft:overworld run setblock 297 70 -15 grass_block
execute in minecraft:overworld run fill 297 71 -15 297 144 -15 air
execute in minecraft:overworld run fill 297 58 -14 297 66 -14 stone
execute in minecraft:overworld run fill 297 67 -14 297 68 -14 dirt
execute in minecraft:overworld run setblock 297 69 -14 coarse_dirt
execute in minecraft:overworld run fill 297 70 -14 297 144 -14 air
execute in minecraft:overworld run fill 297 58 -13 297 66 -13 stone
execute in minecraft:overworld run fill 297 67 -13 297 68 -13 dirt
execute in minecraft:overworld run setblock 297 69 -13 coarse_dirt
execute in minecraft:overworld run fill 297 70 -13 297 144 -13 air
execute in minecraft:overworld run fill 297 58 -12 297 66 -12 stone
execute in minecraft:overworld run fill 297 67 -12 297 68 -12 dirt
execute in minecraft:overworld run setblock 297 69 -12 coarse_dirt
execute in minecraft:overworld run fill 297 70 -12 297 144 -12 air
execute in minecraft:overworld run fill 297 58 -11 297 66 -11 stone
execute in minecraft:overworld run fill 297 67 -11 297 68 -11 dirt
execute in minecraft:overworld run setblock 297 69 -11 coarse_dirt
execute in minecraft:overworld run fill 297 70 -11 297 144 -11 air
execute in minecraft:overworld run fill 297 58 -10 297 66 -10 stone
execute in minecraft:overworld run fill 297 67 -10 297 68 -10 dirt
execute in minecraft:overworld run setblock 297 69 -10 coarse_dirt
execute in minecraft:overworld run fill 297 70 -10 297 144 -10 air
execute in minecraft:overworld run fill 297 58 -9 297 66 -9 stone
execute in minecraft:overworld run fill 297 67 -9 297 68 -9 dirt
execute in minecraft:overworld run setblock 297 69 -9 grass_block
execute in minecraft:overworld run fill 297 70 -9 297 144 -9 air
execute in minecraft:overworld run fill 297 58 -8 297 66 -8 stone
execute in minecraft:overworld run fill 297 67 -8 297 68 -8 dirt
execute in minecraft:overworld run setblock 297 69 -8 grass_block
execute in minecraft:overworld run fill 297 70 -8 297 144 -8 air
execute in minecraft:overworld run fill 297 58 -7 297 66 -7 stone
execute in minecraft:overworld run fill 297 67 -7 297 68 -7 dirt
execute in minecraft:overworld run setblock 297 69 -7 coarse_dirt
execute in minecraft:overworld run fill 297 70 -7 297 144 -7 air
execute in minecraft:overworld run fill 297 58 -6 297 66 -6 stone
schedule function blade_gallery:random/burned/part_141 1t replace
