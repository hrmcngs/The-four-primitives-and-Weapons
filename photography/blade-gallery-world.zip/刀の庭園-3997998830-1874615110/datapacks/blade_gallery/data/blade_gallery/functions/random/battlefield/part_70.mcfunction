execute in minecraft:overworld run fill 381 66 11 381 67 11 dirt
execute in minecraft:overworld run setblock 381 68 11 coarse_dirt
execute in minecraft:overworld run fill 381 69 11 381 144 11 air
execute in minecraft:overworld run fill 381 58 12 381 65 12 stone
execute in minecraft:overworld run fill 381 66 12 381 67 12 dirt
execute in minecraft:overworld run setblock 381 68 12 grass_block
execute in minecraft:overworld run fill 381 69 12 381 144 12 air
execute in minecraft:overworld run fill 381 58 13 381 65 13 stone
execute in minecraft:overworld run fill 381 66 13 381 67 13 dirt
execute in minecraft:overworld run setblock 381 68 13 coarse_dirt
execute in minecraft:overworld run fill 381 69 13 381 144 13 air
execute in minecraft:overworld run fill 381 58 14 381 66 14 stone
execute in minecraft:overworld run fill 381 67 14 381 68 14 dirt
execute in minecraft:overworld run setblock 381 69 14 grass_block
execute in minecraft:overworld run fill 381 70 14 381 144 14 air
execute in minecraft:overworld run fill 381 58 15 381 66 15 stone
execute in minecraft:overworld run fill 381 67 15 381 68 15 dirt
execute in minecraft:overworld run setblock 381 69 15 coarse_dirt
execute in minecraft:overworld run fill 381 70 15 381 144 15 air
execute in minecraft:overworld run fill 381 58 16 381 66 16 stone
execute in minecraft:overworld run fill 381 67 16 381 68 16 dirt
execute in minecraft:overworld run setblock 381 69 16 coarse_dirt
execute in minecraft:overworld run fill 381 70 16 381 144 16 air
execute in minecraft:overworld run setblock 381 70 16 grass
execute in minecraft:overworld run fill 381 58 17 381 66 17 stone
execute in minecraft:overworld run fill 381 67 17 381 68 17 dirt
execute in minecraft:overworld run setblock 381 69 17 coarse_dirt
execute in minecraft:overworld run fill 381 70 17 381 144 17 air
execute in minecraft:overworld run fill 381 58 18 381 67 18 stone
execute in minecraft:overworld run fill 381 68 18 381 69 18 dirt
execute in minecraft:overworld run setblock 381 70 18 coarse_dirt
execute in minecraft:overworld run fill 381 71 18 381 144 18 air
execute in minecraft:overworld run fill 381 58 19 381 67 19 stone
execute in minecraft:overworld run fill 381 68 19 381 69 19 dirt
execute in minecraft:overworld run setblock 381 70 19 grass_block
execute in minecraft:overworld run fill 381 71 19 381 144 19 air
execute in minecraft:overworld run fill 381 58 20 381 67 20 stone
execute in minecraft:overworld run fill 381 68 20 381 69 20 dirt
execute in minecraft:overworld run setblock 381 70 20 grass_block
execute in minecraft:overworld run fill 381 71 20 381 144 20 air
execute in minecraft:overworld run fill 381 58 21 381 66 21 stone
execute in minecraft:overworld run fill 381 67 21 381 68 21 dirt
execute in minecraft:overworld run setblock 381 69 21 coarse_dirt
execute in minecraft:overworld run fill 381 70 21 381 144 21 air
execute in minecraft:overworld run fill 381 58 22 381 66 22 stone
execute in minecraft:overworld run fill 381 67 22 381 68 22 dirt
execute in minecraft:overworld run setblock 381 69 22 grass_block
execute in minecraft:overworld run fill 381 70 22 381 144 22 air
execute in minecraft:overworld run fill 381 58 23 381 66 23 stone
execute in minecraft:overworld run fill 381 67 23 381 68 23 dirt
execute in minecraft:overworld run setblock 381 69 23 grass_block
execute in minecraft:overworld run fill 381 70 23 381 144 23 air
execute in minecraft:overworld run fill 381 58 24 381 66 24 stone
execute in minecraft:overworld run fill 381 67 24 381 68 24 dirt
execute in minecraft:overworld run setblock 381 69 24 coarse_dirt
execute in minecraft:overworld run fill 381 70 24 381 144 24 air
execute in minecraft:overworld run fill 381 58 25 381 66 25 stone
execute in minecraft:overworld run fill 381 67 25 381 68 25 dirt
execute in minecraft:overworld run setblock 381 69 25 coarse_dirt
execute in minecraft:overworld run fill 381 70 25 381 144 25 air
execute in minecraft:overworld run fill 381 58 26 381 65 26 stone
execute in minecraft:overworld run fill 381 66 26 381 67 26 dirt
execute in minecraft:overworld run setblock 381 68 26 grass_block
execute in minecraft:overworld run fill 381 69 26 381 144 26 air
execute in minecraft:overworld run fill 381 58 27 381 65 27 stone
execute in minecraft:overworld run fill 381 66 27 381 67 27 dirt
execute in minecraft:overworld run setblock 381 68 27 grass_block
execute in minecraft:overworld run fill 381 69 27 381 144 27 air
execute in minecraft:overworld run fill 381 58 28 381 65 28 stone
execute in minecraft:overworld run fill 381 66 28 381 67 28 dirt
execute in minecraft:overworld run setblock 381 68 28 coarse_dirt
execute in minecraft:overworld run fill 381 69 28 381 144 28 air
execute in minecraft:overworld run fill 381 58 29 381 65 29 stone
execute in minecraft:overworld run fill 381 66 29 381 67 29 dirt
execute in minecraft:overworld run setblock 381 68 29 coarse_dirt
execute in minecraft:overworld run fill 381 69 29 381 144 29 air
execute in minecraft:overworld run setblock 381 69 29 grass
execute in minecraft:overworld run fill 381 58 30 381 65 30 stone
execute in minecraft:overworld run fill 381 66 30 381 67 30 dirt
execute in minecraft:overworld run setblock 381 68 30 coarse_dirt
execute in minecraft:overworld run fill 381 69 30 381 144 30 air
execute in minecraft:overworld run fill 381 58 31 381 65 31 stone
execute in minecraft:overworld run fill 381 66 31 381 67 31 dirt
execute in minecraft:overworld run setblock 381 68 31 grass_block
execute in minecraft:overworld run fill 381 69 31 381 144 31 air
execute in minecraft:overworld run fill 381 58 32 381 65 32 stone
execute in minecraft:overworld run fill 381 66 32 381 67 32 dirt
execute in minecraft:overworld run setblock 381 68 32 grass_block
execute in minecraft:overworld run fill 381 69 32 381 144 32 air
execute in minecraft:overworld run fill 381 58 33 381 65 33 stone
execute in minecraft:overworld run fill 381 66 33 381 67 33 dirt
execute in minecraft:overworld run setblock 381 68 33 coarse_dirt
execute in minecraft:overworld run fill 381 69 33 381 144 33 air
execute in minecraft:overworld run fill 381 58 34 381 65 34 stone
execute in minecraft:overworld run fill 381 66 34 381 67 34 dirt
execute in minecraft:overworld run setblock 381 68 34 coarse_dirt
execute in minecraft:overworld run fill 381 69 34 381 144 34 air
execute in minecraft:overworld run fill 381 58 35 381 65 35 stone
execute in minecraft:overworld run fill 381 66 35 381 67 35 dirt
execute in minecraft:overworld run setblock 381 68 35 coarse_dirt
execute in minecraft:overworld run fill 381 69 35 381 144 35 air
execute in minecraft:overworld run setblock 381 69 35 grass
execute in minecraft:overworld run fill 381 58 36 381 65 36 stone
execute in minecraft:overworld run fill 381 66 36 381 67 36 dirt
execute in minecraft:overworld run setblock 381 68 36 coarse_dirt
execute in minecraft:overworld run fill 381 69 36 381 144 36 air
execute in minecraft:overworld run fill 381 58 37 381 64 37 stone
execute in minecraft:overworld run fill 381 65 37 381 66 37 dirt
execute in minecraft:overworld run setblock 381 67 37 coarse_dirt
execute in minecraft:overworld run fill 381 68 37 381 144 37 air
execute in minecraft:overworld run fill 381 58 38 381 64 38 stone
execute in minecraft:overworld run fill 381 65 38 381 66 38 dirt
execute in minecraft:overworld run setblock 381 67 38 grass_block
execute in minecraft:overworld run fill 381 68 38 381 144 38 air
execute in minecraft:overworld run fill 381 58 39 381 64 39 stone
execute in minecraft:overworld run fill 381 65 39 381 66 39 dirt
execute in minecraft:overworld run setblock 381 67 39 coarse_dirt
execute in minecraft:overworld run fill 381 68 39 381 144 39 air
execute in minecraft:overworld run fill 381 58 40 381 63 40 stone
execute in minecraft:overworld run fill 381 64 40 381 65 40 dirt
execute in minecraft:overworld run setblock 381 66 40 coarse_dirt
execute in minecraft:overworld run fill 381 67 40 381 144 40 air
execute in minecraft:overworld run fill 381 58 41 381 62 41 stone
execute in minecraft:overworld run fill 381 63 41 381 64 41 dirt
execute in minecraft:overworld run setblock 381 65 41 coarse_dirt
execute in minecraft:overworld run fill 381 66 41 381 144 41 air
execute in minecraft:overworld run fill 381 58 42 381 62 42 stone
execute in minecraft:overworld run fill 381 63 42 381 64 42 dirt
execute in minecraft:overworld run setblock 381 65 42 grass_block
execute in minecraft:overworld run fill 381 66 42 381 144 42 air
execute in minecraft:overworld run fill 381 58 43 381 62 43 stone
execute in minecraft:overworld run fill 381 63 43 381 64 43 dirt
execute in minecraft:overworld run setblock 381 65 43 grass_block
execute in minecraft:overworld run fill 381 66 43 381 144 43 air
execute in minecraft:overworld run fill 381 58 44 381 61 44 stone
execute in minecraft:overworld run fill 381 62 44 381 63 44 dirt
execute in minecraft:overworld run setblock 381 64 44 coarse_dirt
execute in minecraft:overworld run fill 381 65 44 381 144 44 air
execute in minecraft:overworld run fill 381 58 45 381 61 45 stone
execute in minecraft:overworld run fill 381 62 45 381 63 45 dirt
execute in minecraft:overworld run setblock 381 64 45 grass_block
execute in minecraft:overworld run fill 381 65 45 381 144 45 air
execute in minecraft:overworld run fill 381 58 46 381 61 46 stone
execute in minecraft:overworld run fill 381 62 46 381 63 46 dirt
execute in minecraft:overworld run setblock 381 64 46 coarse_dirt
execute in minecraft:overworld run fill 381 65 46 381 144 46 air
execute in minecraft:overworld run fill 381 58 47 381 61 47 stone
execute in minecraft:overworld run fill 381 62 47 381 63 47 dirt
execute in minecraft:overworld run setblock 381 64 47 coarse_dirt
execute in minecraft:overworld run fill 381 65 47 381 144 47 air
execute in minecraft:overworld run fill 382 58 -48 382 61 -48 stone
execute in minecraft:overworld run fill 382 62 -48 382 63 -48 dirt
execute in minecraft:overworld run setblock 382 64 -48 coarse_dirt
execute in minecraft:overworld run fill 382 65 -48 382 144 -48 air
execute in minecraft:overworld run fill 382 58 -47 382 62 -47 stone
execute in minecraft:overworld run fill 382 63 -47 382 64 -47 dirt
execute in minecraft:overworld run setblock 382 65 -47 grass_block
execute in minecraft:overworld run fill 382 66 -47 382 144 -47 air
execute in minecraft:overworld run fill 382 58 -46 382 64 -46 stone
execute in minecraft:overworld run fill 382 65 -46 382 66 -46 dirt
execute in minecraft:overworld run setblock 382 67 -46 grass_block
execute in minecraft:overworld run fill 382 68 -46 382 144 -46 air
execute in minecraft:overworld run fill 382 58 -45 382 65 -45 stone
execute in minecraft:overworld run fill 382 66 -45 382 67 -45 dirt
execute in minecraft:overworld run setblock 382 68 -45 coarse_dirt
execute in minecraft:overworld run fill 382 69 -45 382 144 -45 air
execute in minecraft:overworld run fill 382 58 -44 382 66 -44 stone
execute in minecraft:overworld run fill 382 67 -44 382 68 -44 dirt
execute in minecraft:overworld run setblock 382 69 -44 coarse_dirt
execute in minecraft:overworld run fill 382 70 -44 382 144 -44 air
execute in minecraft:overworld run fill 382 58 -43 382 67 -43 stone
execute in minecraft:overworld run fill 382 68 -43 382 69 -43 dirt
execute in minecraft:overworld run setblock 382 70 -43 coarse_dirt
execute in minecraft:overworld run fill 382 71 -43 382 144 -43 air
execute in minecraft:overworld run fill 382 58 -42 382 68 -42 stone
execute in minecraft:overworld run fill 382 69 -42 382 70 -42 dirt
execute in minecraft:overworld run setblock 382 71 -42 coarse_dirt
execute in minecraft:overworld run fill 382 72 -42 382 144 -42 air
execute in minecraft:overworld run fill 382 58 -41 382 68 -41 stone
execute in minecraft:overworld run fill 382 69 -41 382 70 -41 dirt
execute in minecraft:overworld run setblock 382 71 -41 coarse_dirt
execute in minecraft:overworld run fill 382 72 -41 382 144 -41 air
execute in minecraft:overworld run fill 382 58 -40 382 69 -40 stone
execute in minecraft:overworld run fill 382 70 -40 382 71 -40 dirt
execute in minecraft:overworld run setblock 382 72 -40 coarse_dirt
execute in minecraft:overworld run fill 382 73 -40 382 144 -40 air
execute in minecraft:overworld run fill 382 58 -39 382 69 -39 stone
execute in minecraft:overworld run fill 382 70 -39 382 71 -39 dirt
execute in minecraft:overworld run setblock 382 72 -39 coarse_dirt
execute in minecraft:overworld run fill 382 73 -39 382 144 -39 air
execute in minecraft:overworld run fill 382 58 -38 382 69 -38 stone
execute in minecraft:overworld run fill 382 70 -38 382 71 -38 dirt
execute in minecraft:overworld run setblock 382 72 -38 coarse_dirt
execute in minecraft:overworld run fill 382 73 -38 382 144 -38 air
execute in minecraft:overworld run fill 382 58 -37 382 68 -37 stone
execute in minecraft:overworld run fill 382 69 -37 382 70 -37 dirt
execute in minecraft:overworld run setblock 382 71 -37 coarse_dirt
execute in minecraft:overworld run fill 382 72 -37 382 144 -37 air
execute in minecraft:overworld run setblock 382 72 -37 grass
execute in minecraft:overworld run fill 382 58 -36 382 68 -36 stone
execute in minecraft:overworld run fill 382 69 -36 382 70 -36 dirt
execute in minecraft:overworld run setblock 382 71 -36 grass_block
execute in minecraft:overworld run fill 382 72 -36 382 144 -36 air
execute in minecraft:overworld run fill 382 58 -35 382 67 -35 stone
execute in minecraft:overworld run fill 382 68 -35 382 69 -35 dirt
execute in minecraft:overworld run setblock 382 70 -35 coarse_dirt
execute in minecraft:overworld run fill 382 71 -35 382 144 -35 air
execute in minecraft:overworld run fill 382 58 -34 382 67 -34 stone
execute in minecraft:overworld run fill 382 68 -34 382 69 -34 dirt
execute in minecraft:overworld run setblock 382 70 -34 grass_block
execute in minecraft:overworld run fill 382 71 -34 382 144 -34 air
execute in minecraft:overworld run fill 382 58 -33 382 66 -33 stone
execute in minecraft:overworld run fill 382 67 -33 382 68 -33 dirt
execute in minecraft:overworld run setblock 382 69 -33 coarse_dirt
execute in minecraft:overworld run fill 382 70 -33 382 144 -33 air
execute in minecraft:overworld run fill 382 58 -32 382 66 -32 stone
execute in minecraft:overworld run fill 382 67 -32 382 68 -32 dirt
execute in minecraft:overworld run setblock 382 69 -32 grass_block
execute in minecraft:overworld run fill 382 70 -32 382 144 -32 air
execute in minecraft:overworld run fill 382 58 -31 382 65 -31 stone
execute in minecraft:overworld run fill 382 66 -31 382 67 -31 dirt
execute in minecraft:overworld run setblock 382 68 -31 coarse_dirt
execute in minecraft:overworld run fill 382 69 -31 382 144 -31 air
execute in minecraft:overworld run fill 382 58 -30 382 65 -30 stone
execute in minecraft:overworld run fill 382 66 -30 382 67 -30 dirt
execute in minecraft:overworld run setblock 382 68 -30 coarse_dirt
execute in minecraft:overworld run fill 382 69 -30 382 144 -30 air
execute in minecraft:overworld run fill 382 58 -29 382 65 -29 stone
execute in minecraft:overworld run fill 382 66 -29 382 67 -29 dirt
execute in minecraft:overworld run setblock 382 68 -29 coarse_dirt
execute in minecraft:overworld run fill 382 69 -29 382 144 -29 air
execute in minecraft:overworld run fill 382 58 -28 382 64 -28 stone
execute in minecraft:overworld run fill 382 65 -28 382 66 -28 dirt
execute in minecraft:overworld run setblock 382 67 -28 coarse_dirt
execute in minecraft:overworld run fill 382 68 -28 382 144 -28 air
execute in minecraft:overworld run fill 382 58 -27 382 64 -27 stone
execute in minecraft:overworld run fill 382 65 -27 382 66 -27 dirt
execute in minecraft:overworld run setblock 382 67 -27 coarse_dirt
execute in minecraft:overworld run fill 382 68 -27 382 144 -27 air
execute in minecraft:overworld run fill 382 58 -26 382 63 -26 stone
execute in minecraft:overworld run fill 382 64 -26 382 65 -26 dirt
execute in minecraft:overworld run setblock 382 66 -26 coarse_dirt
execute in minecraft:overworld run fill 382 67 -26 382 144 -26 air
execute in minecraft:overworld run fill 382 58 -25 382 63 -25 stone
execute in minecraft:overworld run fill 382 64 -25 382 65 -25 dirt
execute in minecraft:overworld run setblock 382 66 -25 coarse_dirt
execute in minecraft:overworld run fill 382 67 -25 382 144 -25 air
execute in minecraft:overworld run fill 382 58 -24 382 62 -24 stone
execute in minecraft:overworld run fill 382 63 -24 382 64 -24 dirt
execute in minecraft:overworld run setblock 382 65 -24 grass_block
execute in minecraft:overworld run fill 382 66 -24 382 144 -24 air
execute in minecraft:overworld run fill 382 58 -23 382 62 -23 stone
execute in minecraft:overworld run fill 382 63 -23 382 64 -23 dirt
execute in minecraft:overworld run setblock 382 65 -23 grass_block
execute in minecraft:overworld run fill 382 66 -23 382 144 -23 air
execute in minecraft:overworld run fill 382 58 -22 382 61 -22 stone
schedule function blade_gallery:random/battlefield/part_71 1t replace
