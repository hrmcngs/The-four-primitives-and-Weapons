execute in minecraft:overworld run fill 416 58 32 416 70 32 stone
execute in minecraft:overworld run fill 416 71 32 416 72 32 dirt
execute in minecraft:overworld run setblock 416 73 32 grass_block
execute in minecraft:overworld run fill 416 74 32 416 144 32 air
execute in minecraft:overworld run fill 416 58 33 416 70 33 stone
execute in minecraft:overworld run fill 416 71 33 416 72 33 dirt
execute in minecraft:overworld run setblock 416 73 33 coarse_dirt
execute in minecraft:overworld run fill 416 74 33 416 144 33 air
execute in minecraft:overworld run fill 416 58 34 416 70 34 stone
execute in minecraft:overworld run fill 416 71 34 416 72 34 dirt
execute in minecraft:overworld run setblock 416 73 34 coarse_dirt
execute in minecraft:overworld run fill 416 74 34 416 144 34 air
execute in minecraft:overworld run fill 416 58 35 416 69 35 stone
execute in minecraft:overworld run fill 416 70 35 416 71 35 dirt
execute in minecraft:overworld run setblock 416 72 35 coarse_dirt
execute in minecraft:overworld run fill 416 73 35 416 144 35 air
execute in minecraft:overworld run setblock 416 73 35 grass
execute in minecraft:overworld run fill 416 58 36 416 69 36 stone
execute in minecraft:overworld run fill 416 70 36 416 71 36 dirt
execute in minecraft:overworld run setblock 416 72 36 grass_block
execute in minecraft:overworld run fill 416 73 36 416 144 36 air
execute in minecraft:overworld run fill 416 58 37 416 69 37 stone
execute in minecraft:overworld run fill 416 70 37 416 71 37 dirt
execute in minecraft:overworld run setblock 416 72 37 grass_block
execute in minecraft:overworld run fill 416 73 37 416 144 37 air
execute in minecraft:overworld run fill 416 58 38 416 68 38 stone
execute in minecraft:overworld run fill 416 69 38 416 70 38 dirt
execute in minecraft:overworld run setblock 416 71 38 coarse_dirt
execute in minecraft:overworld run fill 416 72 38 416 144 38 air
execute in minecraft:overworld run fill 416 58 39 416 67 39 stone
execute in minecraft:overworld run fill 416 68 39 416 69 39 dirt
execute in minecraft:overworld run setblock 416 70 39 coarse_dirt
execute in minecraft:overworld run fill 416 71 39 416 144 39 air
execute in minecraft:overworld run fill 416 58 40 416 66 40 stone
execute in minecraft:overworld run fill 416 67 40 416 68 40 dirt
execute in minecraft:overworld run setblock 416 69 40 grass_block
execute in minecraft:overworld run fill 416 70 40 416 144 40 air
execute in minecraft:overworld run fill 416 58 41 416 65 41 stone
execute in minecraft:overworld run fill 416 66 41 416 67 41 dirt
execute in minecraft:overworld run setblock 416 68 41 coarse_dirt
execute in minecraft:overworld run fill 416 69 41 416 144 41 air
execute in minecraft:overworld run fill 416 58 42 416 64 42 stone
execute in minecraft:overworld run fill 416 65 42 416 66 42 dirt
execute in minecraft:overworld run setblock 416 67 42 coarse_dirt
execute in minecraft:overworld run fill 416 68 42 416 144 42 air
execute in minecraft:overworld run fill 416 58 43 416 63 43 stone
execute in minecraft:overworld run fill 416 64 43 416 65 43 dirt
execute in minecraft:overworld run setblock 416 66 43 grass_block
execute in minecraft:overworld run fill 416 67 43 416 144 43 air
execute in minecraft:overworld run fill 416 58 44 416 63 44 stone
execute in minecraft:overworld run fill 416 64 44 416 65 44 dirt
execute in minecraft:overworld run setblock 416 66 44 grass_block
execute in minecraft:overworld run fill 416 67 44 416 144 44 air
execute in minecraft:overworld run fill 416 58 45 416 62 45 stone
execute in minecraft:overworld run fill 416 63 45 416 64 45 dirt
execute in minecraft:overworld run setblock 416 65 45 grass_block
execute in minecraft:overworld run fill 416 66 45 416 144 45 air
execute in minecraft:overworld run fill 416 58 46 416 62 46 stone
execute in minecraft:overworld run fill 416 63 46 416 64 46 dirt
execute in minecraft:overworld run setblock 416 65 46 coarse_dirt
execute in minecraft:overworld run fill 416 66 46 416 144 46 air
execute in minecraft:overworld run fill 416 58 47 416 61 47 stone
execute in minecraft:overworld run fill 416 62 47 416 63 47 dirt
execute in minecraft:overworld run setblock 416 64 47 grass_block
execute in minecraft:overworld run fill 416 65 47 416 144 47 air
execute in minecraft:overworld run fill 417 58 -48 417 61 -48 stone
execute in minecraft:overworld run fill 417 62 -48 417 63 -48 dirt
execute in minecraft:overworld run setblock 417 64 -48 grass_block
execute in minecraft:overworld run fill 417 65 -48 417 144 -48 air
execute in minecraft:overworld run fill 417 58 -47 417 63 -47 stone
execute in minecraft:overworld run fill 417 64 -47 417 65 -47 dirt
execute in minecraft:overworld run setblock 417 66 -47 coarse_dirt
execute in minecraft:overworld run fill 417 67 -47 417 144 -47 air
execute in minecraft:overworld run fill 417 58 -46 417 64 -46 stone
execute in minecraft:overworld run fill 417 65 -46 417 66 -46 dirt
execute in minecraft:overworld run setblock 417 67 -46 coarse_dirt
execute in minecraft:overworld run fill 417 68 -46 417 144 -46 air
execute in minecraft:overworld run fill 417 58 -45 417 66 -45 stone
execute in minecraft:overworld run fill 417 67 -45 417 68 -45 dirt
execute in minecraft:overworld run setblock 417 69 -45 grass_block
execute in minecraft:overworld run fill 417 70 -45 417 144 -45 air
execute in minecraft:overworld run fill 417 58 -44 417 67 -44 stone
execute in minecraft:overworld run fill 417 68 -44 417 69 -44 dirt
execute in minecraft:overworld run setblock 417 70 -44 grass_block
execute in minecraft:overworld run fill 417 71 -44 417 144 -44 air
execute in minecraft:overworld run fill 417 58 -43 417 69 -43 stone
execute in minecraft:overworld run fill 417 70 -43 417 71 -43 dirt
execute in minecraft:overworld run setblock 417 72 -43 coarse_dirt
execute in minecraft:overworld run fill 417 73 -43 417 144 -43 air
execute in minecraft:overworld run fill 417 58 -42 417 70 -42 stone
execute in minecraft:overworld run fill 417 71 -42 417 72 -42 dirt
execute in minecraft:overworld run setblock 417 73 -42 coarse_dirt
execute in minecraft:overworld run fill 417 74 -42 417 144 -42 air
execute in minecraft:overworld run fill 417 58 -41 417 72 -41 stone
execute in minecraft:overworld run fill 417 73 -41 417 74 -41 dirt
execute in minecraft:overworld run setblock 417 75 -41 coarse_dirt
execute in minecraft:overworld run fill 417 76 -41 417 144 -41 air
execute in minecraft:overworld run setblock 417 76 -41 mossy_cobblestone
execute in minecraft:overworld run fill 417 58 -40 417 73 -40 stone
execute in minecraft:overworld run fill 417 74 -40 417 75 -40 dirt
execute in minecraft:overworld run setblock 417 76 -40 coarse_dirt
execute in minecraft:overworld run fill 417 77 -40 417 144 -40 air
execute in minecraft:overworld run fill 417 58 -39 417 74 -39 stone
execute in minecraft:overworld run fill 417 75 -39 417 76 -39 dirt
execute in minecraft:overworld run setblock 417 77 -39 coarse_dirt
execute in minecraft:overworld run fill 417 78 -39 417 144 -39 air
execute in minecraft:overworld run setblock 417 78 -39 grass
execute in minecraft:overworld run fill 417 58 -38 417 75 -38 stone
execute in minecraft:overworld run fill 417 76 -38 417 77 -38 dirt
execute in minecraft:overworld run setblock 417 78 -38 grass_block
execute in minecraft:overworld run fill 417 79 -38 417 144 -38 air
execute in minecraft:overworld run fill 417 58 -37 417 75 -37 stone
execute in minecraft:overworld run fill 417 76 -37 417 77 -37 dirt
execute in minecraft:overworld run setblock 417 78 -37 coarse_dirt
execute in minecraft:overworld run fill 417 79 -37 417 144 -37 air
execute in minecraft:overworld run fill 417 58 -36 417 74 -36 stone
execute in minecraft:overworld run fill 417 75 -36 417 76 -36 dirt
execute in minecraft:overworld run setblock 417 77 -36 grass_block
execute in minecraft:overworld run fill 417 78 -36 417 144 -36 air
execute in minecraft:overworld run fill 417 58 -35 417 74 -35 stone
execute in minecraft:overworld run fill 417 75 -35 417 76 -35 dirt
execute in minecraft:overworld run setblock 417 77 -35 grass_block
execute in minecraft:overworld run fill 417 78 -35 417 144 -35 air
execute in minecraft:overworld run fill 417 58 -34 417 74 -34 stone
execute in minecraft:overworld run fill 417 75 -34 417 76 -34 dirt
execute in minecraft:overworld run setblock 417 77 -34 coarse_dirt
execute in minecraft:overworld run fill 417 78 -34 417 144 -34 air
execute in minecraft:overworld run fill 417 58 -33 417 73 -33 stone
execute in minecraft:overworld run fill 417 74 -33 417 75 -33 dirt
execute in minecraft:overworld run setblock 417 76 -33 coarse_dirt
execute in minecraft:overworld run fill 417 77 -33 417 144 -33 air
execute in minecraft:overworld run fill 417 58 -32 417 73 -32 stone
execute in minecraft:overworld run fill 417 74 -32 417 75 -32 dirt
execute in minecraft:overworld run setblock 417 76 -32 coarse_dirt
execute in minecraft:overworld run fill 417 77 -32 417 144 -32 air
execute in minecraft:overworld run fill 417 58 -31 417 72 -31 stone
execute in minecraft:overworld run fill 417 73 -31 417 74 -31 dirt
execute in minecraft:overworld run setblock 417 75 -31 grass_block
execute in minecraft:overworld run fill 417 76 -31 417 144 -31 air
execute in minecraft:overworld run setblock 417 76 -31 grass
execute in minecraft:overworld run fill 417 58 -30 417 72 -30 stone
execute in minecraft:overworld run fill 417 73 -30 417 74 -30 dirt
execute in minecraft:overworld run setblock 417 75 -30 grass_block
execute in minecraft:overworld run fill 417 76 -30 417 144 -30 air
execute in minecraft:overworld run fill 417 58 -29 417 71 -29 stone
execute in minecraft:overworld run fill 417 72 -29 417 73 -29 dirt
execute in minecraft:overworld run setblock 417 74 -29 grass_block
execute in minecraft:overworld run fill 417 75 -29 417 144 -29 air
execute in minecraft:overworld run fill 417 58 -28 417 71 -28 stone
execute in minecraft:overworld run fill 417 72 -28 417 73 -28 dirt
execute in minecraft:overworld run setblock 417 74 -28 coarse_dirt
execute in minecraft:overworld run fill 417 75 -28 417 144 -28 air
execute in minecraft:overworld run fill 417 58 -27 417 71 -27 stone
execute in minecraft:overworld run fill 417 72 -27 417 73 -27 dirt
execute in minecraft:overworld run setblock 417 74 -27 coarse_dirt
execute in minecraft:overworld run fill 417 75 -27 417 144 -27 air
execute in minecraft:overworld run fill 417 58 -26 417 70 -26 stone
execute in minecraft:overworld run fill 417 71 -26 417 72 -26 dirt
execute in minecraft:overworld run setblock 417 73 -26 coarse_dirt
execute in minecraft:overworld run fill 417 74 -26 417 144 -26 air
execute in minecraft:overworld run fill 417 58 -25 417 70 -25 stone
execute in minecraft:overworld run fill 417 71 -25 417 72 -25 dirt
execute in minecraft:overworld run setblock 417 73 -25 coarse_dirt
execute in minecraft:overworld run fill 417 74 -25 417 144 -25 air
execute in minecraft:overworld run fill 417 58 -24 417 70 -24 stone
execute in minecraft:overworld run fill 417 71 -24 417 72 -24 dirt
execute in minecraft:overworld run setblock 417 73 -24 coarse_dirt
execute in minecraft:overworld run fill 417 74 -24 417 144 -24 air
execute in minecraft:overworld run fill 417 58 -23 417 69 -23 stone
execute in minecraft:overworld run fill 417 70 -23 417 71 -23 dirt
execute in minecraft:overworld run setblock 417 72 -23 grass_block
execute in minecraft:overworld run fill 417 73 -23 417 144 -23 air
execute in minecraft:overworld run fill 417 58 -22 417 69 -22 stone
execute in minecraft:overworld run fill 417 70 -22 417 71 -22 dirt
execute in minecraft:overworld run setblock 417 72 -22 coarse_dirt
execute in minecraft:overworld run fill 417 73 -22 417 144 -22 air
execute in minecraft:overworld run fill 417 58 -21 417 69 -21 stone
execute in minecraft:overworld run fill 417 70 -21 417 71 -21 dirt
execute in minecraft:overworld run setblock 417 72 -21 coarse_dirt
execute in minecraft:overworld run fill 417 73 -21 417 144 -21 air
execute in minecraft:overworld run setblock 417 73 -21 grass
execute in minecraft:overworld run fill 417 58 -20 417 69 -20 stone
execute in minecraft:overworld run fill 417 70 -20 417 71 -20 dirt
execute in minecraft:overworld run setblock 417 72 -20 grass_block
execute in minecraft:overworld run fill 417 73 -20 417 144 -20 air
execute in minecraft:overworld run fill 417 58 -19 417 68 -19 stone
execute in minecraft:overworld run fill 417 69 -19 417 70 -19 dirt
execute in minecraft:overworld run setblock 417 71 -19 coarse_dirt
execute in minecraft:overworld run fill 417 72 -19 417 144 -19 air
execute in minecraft:overworld run fill 417 58 -18 417 68 -18 stone
execute in minecraft:overworld run fill 417 69 -18 417 70 -18 dirt
execute in minecraft:overworld run setblock 417 71 -18 grass_block
execute in minecraft:overworld run fill 417 72 -18 417 144 -18 air
execute in minecraft:overworld run fill 417 58 -17 417 67 -17 stone
execute in minecraft:overworld run fill 417 68 -17 417 69 -17 dirt
execute in minecraft:overworld run setblock 417 70 -17 coarse_dirt
execute in minecraft:overworld run fill 417 71 -17 417 144 -17 air
execute in minecraft:overworld run fill 417 58 -16 417 67 -16 stone
execute in minecraft:overworld run fill 417 68 -16 417 69 -16 dirt
execute in minecraft:overworld run setblock 417 70 -16 coarse_dirt
execute in minecraft:overworld run fill 417 71 -16 417 144 -16 air
execute in minecraft:overworld run fill 417 58 -15 417 67 -15 stone
execute in minecraft:overworld run fill 417 68 -15 417 69 -15 dirt
execute in minecraft:overworld run setblock 417 70 -15 grass_block
execute in minecraft:overworld run fill 417 71 -15 417 144 -15 air
execute in minecraft:overworld run setblock 417 71 -15 grass
execute in minecraft:overworld run fill 417 58 -14 417 66 -14 stone
execute in minecraft:overworld run fill 417 67 -14 417 68 -14 dirt
execute in minecraft:overworld run setblock 417 69 -14 coarse_dirt
execute in minecraft:overworld run fill 417 70 -14 417 144 -14 air
execute in minecraft:overworld run fill 417 58 -13 417 66 -13 stone
execute in minecraft:overworld run fill 417 67 -13 417 68 -13 dirt
execute in minecraft:overworld run setblock 417 69 -13 coarse_dirt
execute in minecraft:overworld run fill 417 70 -13 417 144 -13 air
execute in minecraft:overworld run fill 417 58 -12 417 65 -12 stone
execute in minecraft:overworld run fill 417 66 -12 417 67 -12 dirt
execute in minecraft:overworld run setblock 417 68 -12 coarse_dirt
execute in minecraft:overworld run fill 417 69 -12 417 144 -12 air
execute in minecraft:overworld run setblock 417 69 -12 grass
execute in minecraft:overworld run fill 417 58 -11 417 65 -11 stone
execute in minecraft:overworld run fill 417 66 -11 417 67 -11 dirt
execute in minecraft:overworld run setblock 417 68 -11 grass_block
execute in minecraft:overworld run fill 417 69 -11 417 144 -11 air
execute in minecraft:overworld run fill 417 58 -10 417 65 -10 stone
execute in minecraft:overworld run fill 417 66 -10 417 67 -10 dirt
execute in minecraft:overworld run setblock 417 68 -10 grass_block
execute in minecraft:overworld run fill 417 69 -10 417 144 -10 air
execute in minecraft:overworld run fill 417 58 -9 417 65 -9 stone
execute in minecraft:overworld run fill 417 66 -9 417 67 -9 dirt
execute in minecraft:overworld run setblock 417 68 -9 coarse_dirt
execute in minecraft:overworld run fill 417 69 -9 417 144 -9 air
execute in minecraft:overworld run fill 417 58 -8 417 65 -8 stone
execute in minecraft:overworld run fill 417 66 -8 417 67 -8 dirt
execute in minecraft:overworld run setblock 417 68 -8 grass_block
execute in minecraft:overworld run fill 417 69 -8 417 144 -8 air
execute in minecraft:overworld run fill 417 58 -7 417 65 -7 stone
execute in minecraft:overworld run fill 417 66 -7 417 67 -7 dirt
execute in minecraft:overworld run setblock 417 68 -7 grass_block
execute in minecraft:overworld run fill 417 69 -7 417 144 -7 air
execute in minecraft:overworld run fill 417 58 -6 417 64 -6 stone
execute in minecraft:overworld run fill 417 65 -6 417 66 -6 dirt
execute in minecraft:overworld run setblock 417 67 -6 coarse_dirt
execute in minecraft:overworld run fill 417 68 -6 417 144 -6 air
execute in minecraft:overworld run fill 417 58 -5 417 64 -5 stone
execute in minecraft:overworld run fill 417 65 -5 417 66 -5 dirt
execute in minecraft:overworld run setblock 417 67 -5 coarse_dirt
execute in minecraft:overworld run fill 417 68 -5 417 144 -5 air
execute in minecraft:overworld run fill 417 58 -4 417 64 -4 stone
execute in minecraft:overworld run fill 417 65 -4 417 66 -4 dirt
execute in minecraft:overworld run setblock 417 67 -4 coarse_dirt
execute in minecraft:overworld run fill 417 68 -4 417 144 -4 air
execute in minecraft:overworld run fill 417 58 -3 417 63 -3 stone
execute in minecraft:overworld run fill 417 64 -3 417 65 -3 dirt
execute in minecraft:overworld run setblock 417 66 -3 grass_block
execute in minecraft:overworld run fill 417 67 -3 417 144 -3 air
execute in minecraft:overworld run fill 417 58 -2 417 63 -2 stone
schedule function blade_gallery:random/battlefield/part_128 1t replace
