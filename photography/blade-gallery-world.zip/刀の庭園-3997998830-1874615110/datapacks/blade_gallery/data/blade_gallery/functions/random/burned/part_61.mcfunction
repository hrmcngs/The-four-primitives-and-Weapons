execute in minecraft:overworld run setblock 247 68 24 coarse_dirt
execute in minecraft:overworld run fill 247 69 24 247 144 24 air
execute in minecraft:overworld run fill 247 58 25 247 65 25 stone
execute in minecraft:overworld run fill 247 66 25 247 67 25 dirt
execute in minecraft:overworld run setblock 247 68 25 coarse_dirt
execute in minecraft:overworld run fill 247 69 25 247 144 25 air
execute in minecraft:overworld run setblock 247 69 25 grass
execute in minecraft:overworld run fill 247 58 26 247 65 26 stone
execute in minecraft:overworld run fill 247 66 26 247 67 26 dirt
execute in minecraft:overworld run setblock 247 68 26 coarse_dirt
execute in minecraft:overworld run fill 247 69 26 247 144 26 air
execute in minecraft:overworld run fill 247 58 27 247 65 27 stone
execute in minecraft:overworld run fill 247 66 27 247 67 27 dirt
execute in minecraft:overworld run setblock 247 68 27 coarse_dirt
execute in minecraft:overworld run fill 247 69 27 247 144 27 air
execute in minecraft:overworld run fill 247 58 28 247 65 28 stone
execute in minecraft:overworld run fill 247 66 28 247 67 28 dirt
execute in minecraft:overworld run setblock 247 68 28 coarse_dirt
execute in minecraft:overworld run fill 247 69 28 247 144 28 air
execute in minecraft:overworld run fill 247 58 29 247 65 29 stone
execute in minecraft:overworld run fill 247 66 29 247 67 29 dirt
execute in minecraft:overworld run setblock 247 68 29 grass_block
execute in minecraft:overworld run fill 247 69 29 247 144 29 air
execute in minecraft:overworld run fill 247 58 30 247 65 30 stone
execute in minecraft:overworld run fill 247 66 30 247 67 30 dirt
execute in minecraft:overworld run setblock 247 68 30 coarse_dirt
execute in minecraft:overworld run fill 247 69 30 247 144 30 air
execute in minecraft:overworld run fill 247 58 31 247 65 31 stone
execute in minecraft:overworld run fill 247 66 31 247 67 31 dirt
execute in minecraft:overworld run setblock 247 68 31 coarse_dirt
execute in minecraft:overworld run fill 247 69 31 247 144 31 air
execute in minecraft:overworld run fill 247 58 32 247 65 32 stone
execute in minecraft:overworld run fill 247 66 32 247 67 32 dirt
execute in minecraft:overworld run setblock 247 68 32 coarse_dirt
execute in minecraft:overworld run fill 247 69 32 247 144 32 air
execute in minecraft:overworld run fill 247 58 33 247 65 33 stone
execute in minecraft:overworld run fill 247 66 33 247 67 33 dirt
execute in minecraft:overworld run setblock 247 68 33 coarse_dirt
execute in minecraft:overworld run fill 247 69 33 247 144 33 air
execute in minecraft:overworld run setblock 247 69 33 grass
execute in minecraft:overworld run fill 247 58 34 247 65 34 stone
execute in minecraft:overworld run fill 247 66 34 247 67 34 dirt
execute in minecraft:overworld run setblock 247 68 34 grass_block
execute in minecraft:overworld run fill 247 69 34 247 144 34 air
execute in minecraft:overworld run fill 247 58 35 247 65 35 stone
execute in minecraft:overworld run fill 247 66 35 247 67 35 dirt
execute in minecraft:overworld run setblock 247 68 35 coarse_dirt
execute in minecraft:overworld run fill 247 69 35 247 144 35 air
execute in minecraft:overworld run fill 247 58 36 247 65 36 stone
execute in minecraft:overworld run fill 247 66 36 247 67 36 dirt
execute in minecraft:overworld run setblock 247 68 36 coarse_dirt
execute in minecraft:overworld run fill 247 69 36 247 144 36 air
execute in minecraft:overworld run fill 247 58 37 247 64 37 stone
execute in minecraft:overworld run fill 247 65 37 247 66 37 dirt
execute in minecraft:overworld run setblock 247 67 37 grass_block
execute in minecraft:overworld run fill 247 68 37 247 144 37 air
execute in minecraft:overworld run fill 247 58 38 247 64 38 stone
execute in minecraft:overworld run fill 247 65 38 247 66 38 dirt
execute in minecraft:overworld run setblock 247 67 38 coarse_dirt
execute in minecraft:overworld run fill 247 68 38 247 144 38 air
execute in minecraft:overworld run fill 247 58 39 247 64 39 stone
execute in minecraft:overworld run fill 247 65 39 247 66 39 dirt
execute in minecraft:overworld run setblock 247 67 39 coarse_dirt
execute in minecraft:overworld run fill 247 68 39 247 144 39 air
execute in minecraft:overworld run fill 247 58 40 247 63 40 stone
execute in minecraft:overworld run fill 247 64 40 247 65 40 dirt
execute in minecraft:overworld run setblock 247 66 40 grass_block
execute in minecraft:overworld run fill 247 67 40 247 144 40 air
execute in minecraft:overworld run fill 247 58 41 247 63 41 stone
execute in minecraft:overworld run fill 247 64 41 247 65 41 dirt
execute in minecraft:overworld run setblock 247 66 41 grass_block
execute in minecraft:overworld run fill 247 67 41 247 144 41 air
execute in minecraft:overworld run fill 247 58 42 247 62 42 stone
execute in minecraft:overworld run fill 247 63 42 247 64 42 dirt
execute in minecraft:overworld run setblock 247 65 42 grass_block
execute in minecraft:overworld run fill 247 66 42 247 144 42 air
execute in minecraft:overworld run fill 247 58 43 247 62 43 stone
execute in minecraft:overworld run fill 247 63 43 247 64 43 dirt
execute in minecraft:overworld run setblock 247 65 43 coarse_dirt
execute in minecraft:overworld run fill 247 66 43 247 144 43 air
execute in minecraft:overworld run fill 247 58 44 247 62 44 stone
execute in minecraft:overworld run fill 247 63 44 247 64 44 dirt
execute in minecraft:overworld run setblock 247 65 44 coarse_dirt
execute in minecraft:overworld run fill 247 66 44 247 144 44 air
execute in minecraft:overworld run fill 247 58 45 247 61 45 stone
execute in minecraft:overworld run fill 247 62 45 247 63 45 dirt
execute in minecraft:overworld run setblock 247 64 45 coarse_dirt
execute in minecraft:overworld run fill 247 65 45 247 144 45 air
execute in minecraft:overworld run fill 247 58 46 247 61 46 stone
execute in minecraft:overworld run fill 247 62 46 247 63 46 dirt
execute in minecraft:overworld run setblock 247 64 46 coarse_dirt
execute in minecraft:overworld run fill 247 65 46 247 144 46 air
execute in minecraft:overworld run fill 247 58 47 247 61 47 stone
execute in minecraft:overworld run fill 247 62 47 247 63 47 dirt
execute in minecraft:overworld run setblock 247 64 47 coarse_dirt
execute in minecraft:overworld run fill 247 65 47 247 144 47 air
execute in minecraft:overworld run fill 248 58 -48 248 61 -48 stone
execute in minecraft:overworld run fill 248 62 -48 248 63 -48 dirt
execute in minecraft:overworld run setblock 248 64 -48 grass_block
execute in minecraft:overworld run fill 248 65 -48 248 144 -48 air
execute in minecraft:overworld run fill 248 58 -47 248 62 -47 stone
execute in minecraft:overworld run fill 248 63 -47 248 64 -47 dirt
execute in minecraft:overworld run setblock 248 65 -47 grass_block
execute in minecraft:overworld run fill 248 66 -47 248 144 -47 air
execute in minecraft:overworld run fill 248 58 -46 248 63 -46 stone
execute in minecraft:overworld run fill 248 64 -46 248 65 -46 dirt
execute in minecraft:overworld run setblock 248 66 -46 coarse_dirt
execute in minecraft:overworld run fill 248 67 -46 248 144 -46 air
execute in minecraft:overworld run fill 248 58 -45 248 63 -45 stone
execute in minecraft:overworld run fill 248 64 -45 248 65 -45 dirt
execute in minecraft:overworld run setblock 248 66 -45 grass_block
execute in minecraft:overworld run fill 248 67 -45 248 144 -45 air
execute in minecraft:overworld run fill 248 58 -44 248 64 -44 stone
execute in minecraft:overworld run fill 248 65 -44 248 66 -44 dirt
execute in minecraft:overworld run setblock 248 67 -44 grass_block
execute in minecraft:overworld run fill 248 68 -44 248 144 -44 air
execute in minecraft:overworld run fill 248 58 -43 248 65 -43 stone
execute in minecraft:overworld run fill 248 66 -43 248 67 -43 dirt
execute in minecraft:overworld run setblock 248 68 -43 grass_block
execute in minecraft:overworld run fill 248 69 -43 248 144 -43 air
execute in minecraft:overworld run fill 248 58 -42 248 65 -42 stone
execute in minecraft:overworld run fill 248 66 -42 248 67 -42 dirt
execute in minecraft:overworld run setblock 248 68 -42 coarse_dirt
execute in minecraft:overworld run fill 248 69 -42 248 144 -42 air
execute in minecraft:overworld run fill 248 58 -41 248 66 -41 stone
execute in minecraft:overworld run fill 248 67 -41 248 68 -41 dirt
execute in minecraft:overworld run setblock 248 69 -41 coarse_dirt
execute in minecraft:overworld run fill 248 70 -41 248 144 -41 air
execute in minecraft:overworld run setblock 248 70 -41 mossy_cobblestone
execute in minecraft:overworld run fill 248 58 -40 248 67 -40 stone
execute in minecraft:overworld run fill 248 68 -40 248 69 -40 dirt
execute in minecraft:overworld run setblock 248 70 -40 coarse_dirt
execute in minecraft:overworld run fill 248 71 -40 248 144 -40 air
execute in minecraft:overworld run setblock 248 71 -40 grass
execute in minecraft:overworld run fill 248 58 -39 248 67 -39 stone
execute in minecraft:overworld run fill 248 68 -39 248 69 -39 dirt
execute in minecraft:overworld run setblock 248 70 -39 coarse_dirt
execute in minecraft:overworld run fill 248 71 -39 248 144 -39 air
execute in minecraft:overworld run fill 248 58 -38 248 68 -38 stone
execute in minecraft:overworld run fill 248 69 -38 248 70 -38 dirt
execute in minecraft:overworld run setblock 248 71 -38 coarse_dirt
execute in minecraft:overworld run fill 248 72 -38 248 144 -38 air
execute in minecraft:overworld run fill 248 58 -37 248 68 -37 stone
execute in minecraft:overworld run fill 248 69 -37 248 70 -37 dirt
execute in minecraft:overworld run setblock 248 71 -37 grass_block
execute in minecraft:overworld run fill 248 72 -37 248 144 -37 air
execute in minecraft:overworld run fill 248 58 -36 248 68 -36 stone
execute in minecraft:overworld run fill 248 69 -36 248 70 -36 dirt
execute in minecraft:overworld run setblock 248 71 -36 coarse_dirt
execute in minecraft:overworld run fill 248 72 -36 248 144 -36 air
execute in minecraft:overworld run fill 248 58 -35 248 68 -35 stone
execute in minecraft:overworld run fill 248 69 -35 248 70 -35 dirt
execute in minecraft:overworld run setblock 248 71 -35 coarse_dirt
execute in minecraft:overworld run fill 248 72 -35 248 144 -35 air
execute in minecraft:overworld run fill 248 58 -34 248 68 -34 stone
execute in minecraft:overworld run fill 248 69 -34 248 70 -34 dirt
execute in minecraft:overworld run setblock 248 71 -34 coarse_dirt
execute in minecraft:overworld run fill 248 72 -34 248 144 -34 air
execute in minecraft:overworld run fill 248 58 -33 248 68 -33 stone
execute in minecraft:overworld run fill 248 69 -33 248 70 -33 dirt
execute in minecraft:overworld run setblock 248 71 -33 coarse_dirt
execute in minecraft:overworld run fill 248 72 -33 248 144 -33 air
execute in minecraft:overworld run setblock 248 72 -33 grass
execute in minecraft:overworld run fill 248 58 -32 248 68 -32 stone
execute in minecraft:overworld run fill 248 69 -32 248 70 -32 dirt
execute in minecraft:overworld run setblock 248 71 -32 coarse_dirt
execute in minecraft:overworld run fill 248 72 -32 248 144 -32 air
execute in minecraft:overworld run fill 248 58 -31 248 68 -31 stone
execute in minecraft:overworld run fill 248 69 -31 248 70 -31 dirt
execute in minecraft:overworld run setblock 248 71 -31 coarse_dirt
execute in minecraft:overworld run fill 248 72 -31 248 144 -31 air
execute in minecraft:overworld run fill 248 58 -30 248 69 -30 stone
execute in minecraft:overworld run fill 248 70 -30 248 71 -30 dirt
execute in minecraft:overworld run setblock 248 72 -30 grass_block
execute in minecraft:overworld run fill 248 73 -30 248 144 -30 air
execute in minecraft:overworld run fill 248 58 -29 248 69 -29 stone
execute in minecraft:overworld run fill 248 70 -29 248 71 -29 dirt
execute in minecraft:overworld run setblock 248 72 -29 grass_block
execute in minecraft:overworld run fill 248 73 -29 248 144 -29 air
execute in minecraft:overworld run fill 248 58 -28 248 69 -28 stone
execute in minecraft:overworld run fill 248 70 -28 248 71 -28 dirt
execute in minecraft:overworld run setblock 248 72 -28 coarse_dirt
execute in minecraft:overworld run fill 248 73 -28 248 144 -28 air
execute in minecraft:overworld run fill 248 58 -27 248 69 -27 stone
execute in minecraft:overworld run fill 248 70 -27 248 71 -27 dirt
execute in minecraft:overworld run setblock 248 72 -27 coarse_dirt
execute in minecraft:overworld run fill 248 73 -27 248 144 -27 air
execute in minecraft:overworld run setblock 248 73 -27 grass
execute in minecraft:overworld run fill 248 58 -26 248 69 -26 stone
execute in minecraft:overworld run fill 248 70 -26 248 71 -26 dirt
execute in minecraft:overworld run setblock 248 72 -26 coarse_dirt
execute in minecraft:overworld run fill 248 73 -26 248 144 -26 air
execute in minecraft:overworld run fill 248 58 -25 248 69 -25 stone
execute in minecraft:overworld run fill 248 70 -25 248 71 -25 dirt
execute in minecraft:overworld run setblock 248 72 -25 coarse_dirt
execute in minecraft:overworld run fill 248 73 -25 248 144 -25 air
execute in minecraft:overworld run setblock 248 73 -25 mossy_cobblestone
execute in minecraft:overworld run fill 248 58 -24 248 69 -24 stone
execute in minecraft:overworld run fill 248 70 -24 248 71 -24 dirt
execute in minecraft:overworld run setblock 248 72 -24 grass_block
execute in minecraft:overworld run fill 248 73 -24 248 144 -24 air
execute in minecraft:overworld run fill 248 58 -23 248 69 -23 stone
execute in minecraft:overworld run fill 248 70 -23 248 71 -23 dirt
execute in minecraft:overworld run setblock 248 72 -23 coarse_dirt
execute in minecraft:overworld run fill 248 73 -23 248 144 -23 air
execute in minecraft:overworld run fill 248 58 -22 248 68 -22 stone
execute in minecraft:overworld run fill 248 69 -22 248 70 -22 dirt
execute in minecraft:overworld run setblock 248 71 -22 coarse_dirt
execute in minecraft:overworld run fill 248 72 -22 248 144 -22 air
execute in minecraft:overworld run fill 248 58 -21 248 68 -21 stone
execute in minecraft:overworld run fill 248 69 -21 248 70 -21 dirt
execute in minecraft:overworld run setblock 248 71 -21 grass_block
execute in minecraft:overworld run fill 248 72 -21 248 144 -21 air
execute in minecraft:overworld run setblock 248 72 -21 grass
execute in minecraft:overworld run fill 248 58 -20 248 67 -20 stone
execute in minecraft:overworld run fill 248 68 -20 248 69 -20 dirt
execute in minecraft:overworld run setblock 248 70 -20 coarse_dirt
execute in minecraft:overworld run fill 248 71 -20 248 144 -20 air
execute in minecraft:overworld run fill 248 58 -19 248 67 -19 stone
execute in minecraft:overworld run fill 248 68 -19 248 69 -19 dirt
execute in minecraft:overworld run setblock 248 70 -19 coarse_dirt
execute in minecraft:overworld run fill 248 71 -19 248 144 -19 air
execute in minecraft:overworld run fill 248 58 -18 248 67 -18 stone
execute in minecraft:overworld run fill 248 68 -18 248 69 -18 dirt
execute in minecraft:overworld run setblock 248 70 -18 coarse_dirt
execute in minecraft:overworld run fill 248 71 -18 248 144 -18 air
execute in minecraft:overworld run setblock 248 71 -18 grass
execute in minecraft:overworld run fill 248 58 -17 248 66 -17 stone
execute in minecraft:overworld run fill 248 67 -17 248 68 -17 dirt
execute in minecraft:overworld run setblock 248 69 -17 coarse_dirt
execute in minecraft:overworld run fill 248 70 -17 248 144 -17 air
execute in minecraft:overworld run fill 248 58 -16 248 66 -16 stone
execute in minecraft:overworld run fill 248 67 -16 248 68 -16 dirt
execute in minecraft:overworld run setblock 248 69 -16 coarse_dirt
execute in minecraft:overworld run fill 248 70 -16 248 144 -16 air
execute in minecraft:overworld run fill 248 58 -15 248 65 -15 stone
execute in minecraft:overworld run fill 248 66 -15 248 67 -15 dirt
execute in minecraft:overworld run setblock 248 68 -15 coarse_dirt
execute in minecraft:overworld run fill 248 69 -15 248 144 -15 air
execute in minecraft:overworld run fill 248 58 -14 248 65 -14 stone
execute in minecraft:overworld run fill 248 66 -14 248 67 -14 dirt
execute in minecraft:overworld run setblock 248 68 -14 coarse_dirt
execute in minecraft:overworld run fill 248 69 -14 248 144 -14 air
execute in minecraft:overworld run fill 248 58 -13 248 64 -13 stone
execute in minecraft:overworld run fill 248 65 -13 248 66 -13 dirt
execute in minecraft:overworld run setblock 248 67 -13 grass_block
execute in minecraft:overworld run fill 248 68 -13 248 144 -13 air
execute in minecraft:overworld run setblock 248 68 -13 grass
execute in minecraft:overworld run fill 248 58 -12 248 64 -12 stone
execute in minecraft:overworld run fill 248 65 -12 248 66 -12 dirt
execute in minecraft:overworld run setblock 248 67 -12 coarse_dirt
execute in minecraft:overworld run fill 248 68 -12 248 144 -12 air
execute in minecraft:overworld run fill 248 58 -11 248 64 -11 stone
execute in minecraft:overworld run fill 248 65 -11 248 66 -11 dirt
execute in minecraft:overworld run setblock 248 67 -11 coarse_dirt
execute in minecraft:overworld run fill 248 68 -11 248 144 -11 air
schedule function blade_gallery:random/burned/part_62 1t replace
