execute in minecraft:overworld run setblock 277 64 45 grass_block
execute in minecraft:overworld run fill 277 65 45 277 144 45 air
execute in minecraft:overworld run fill 277 58 46 277 61 46 stone
execute in minecraft:overworld run fill 277 62 46 277 63 46 dirt
execute in minecraft:overworld run setblock 277 64 46 coarse_dirt
execute in minecraft:overworld run fill 277 65 46 277 144 46 air
execute in minecraft:overworld run fill 277 58 47 277 61 47 stone
execute in minecraft:overworld run fill 277 62 47 277 63 47 dirt
execute in minecraft:overworld run setblock 277 64 47 coarse_dirt
execute in minecraft:overworld run fill 277 65 47 277 144 47 air
execute in minecraft:overworld run fill 278 58 -48 278 61 -48 stone
execute in minecraft:overworld run fill 278 62 -48 278 63 -48 dirt
execute in minecraft:overworld run setblock 278 64 -48 coarse_dirt
execute in minecraft:overworld run fill 278 65 -48 278 144 -48 air
execute in minecraft:overworld run fill 278 58 -47 278 63 -47 stone
execute in minecraft:overworld run fill 278 64 -47 278 65 -47 dirt
execute in minecraft:overworld run setblock 278 66 -47 grass_block
execute in minecraft:overworld run fill 278 67 -47 278 144 -47 air
execute in minecraft:overworld run fill 278 58 -46 278 66 -46 stone
execute in minecraft:overworld run fill 278 67 -46 278 68 -46 dirt
execute in minecraft:overworld run setblock 278 69 -46 coarse_dirt
execute in minecraft:overworld run fill 278 70 -46 278 144 -46 air
execute in minecraft:overworld run fill 278 58 -45 278 68 -45 stone
execute in minecraft:overworld run fill 278 69 -45 278 70 -45 dirt
execute in minecraft:overworld run setblock 278 71 -45 coarse_dirt
execute in minecraft:overworld run fill 278 72 -45 278 144 -45 air
execute in minecraft:overworld run fill 278 58 -44 278 70 -44 stone
execute in minecraft:overworld run fill 278 71 -44 278 72 -44 dirt
execute in minecraft:overworld run setblock 278 73 -44 grass_block
execute in minecraft:overworld run fill 278 74 -44 278 144 -44 air
execute in minecraft:overworld run fill 278 58 -43 278 72 -43 stone
execute in minecraft:overworld run fill 278 73 -43 278 74 -43 dirt
execute in minecraft:overworld run setblock 278 75 -43 grass_block
execute in minecraft:overworld run fill 278 76 -43 278 144 -43 air
execute in minecraft:overworld run fill 278 58 -42 278 73 -42 stone
execute in minecraft:overworld run fill 278 74 -42 278 75 -42 dirt
execute in minecraft:overworld run setblock 278 76 -42 coarse_dirt
execute in minecraft:overworld run fill 278 77 -42 278 144 -42 air
execute in minecraft:overworld run fill 278 58 -41 278 75 -41 stone
execute in minecraft:overworld run fill 278 76 -41 278 77 -41 dirt
execute in minecraft:overworld run setblock 278 78 -41 coarse_dirt
execute in minecraft:overworld run fill 278 79 -41 278 144 -41 air
execute in minecraft:overworld run setblock 278 79 -41 grass
execute in minecraft:overworld run fill 278 58 -40 278 77 -40 stone
execute in minecraft:overworld run fill 278 78 -40 278 79 -40 dirt
execute in minecraft:overworld run setblock 278 80 -40 coarse_dirt
execute in minecraft:overworld run fill 278 81 -40 278 144 -40 air
execute in minecraft:overworld run setblock 278 81 -40 grass
execute in minecraft:overworld run fill 278 58 -39 278 78 -39 stone
execute in minecraft:overworld run fill 278 79 -39 278 80 -39 dirt
execute in minecraft:overworld run setblock 278 81 -39 coarse_dirt
execute in minecraft:overworld run fill 278 82 -39 278 144 -39 air
execute in minecraft:overworld run fill 278 58 -38 278 79 -38 stone
execute in minecraft:overworld run fill 278 80 -38 278 81 -38 dirt
execute in minecraft:overworld run setblock 278 82 -38 coarse_dirt
execute in minecraft:overworld run fill 278 83 -38 278 144 -38 air
execute in minecraft:overworld run setblock 278 83 -38 grass
execute in minecraft:overworld run fill 278 58 -37 278 79 -37 stone
execute in minecraft:overworld run fill 278 80 -37 278 81 -37 dirt
execute in minecraft:overworld run setblock 278 82 -37 grass_block
execute in minecraft:overworld run fill 278 83 -37 278 144 -37 air
execute in minecraft:overworld run fill 278 58 -36 278 78 -36 stone
execute in minecraft:overworld run fill 278 79 -36 278 80 -36 dirt
execute in minecraft:overworld run setblock 278 81 -36 coarse_dirt
execute in minecraft:overworld run fill 278 82 -36 278 144 -36 air
execute in minecraft:overworld run fill 278 58 -35 278 78 -35 stone
execute in minecraft:overworld run fill 278 79 -35 278 80 -35 dirt
execute in minecraft:overworld run setblock 278 81 -35 coarse_dirt
execute in minecraft:overworld run fill 278 82 -35 278 144 -35 air
execute in minecraft:overworld run setblock 278 82 -35 grass
execute in minecraft:overworld run fill 278 58 -34 278 78 -34 stone
execute in minecraft:overworld run fill 278 79 -34 278 80 -34 dirt
execute in minecraft:overworld run setblock 278 81 -34 grass_block
execute in minecraft:overworld run fill 278 82 -34 278 144 -34 air
execute in minecraft:overworld run fill 278 58 -33 278 77 -33 stone
execute in minecraft:overworld run fill 278 78 -33 278 79 -33 dirt
execute in minecraft:overworld run setblock 278 80 -33 coarse_dirt
execute in minecraft:overworld run fill 278 81 -33 278 144 -33 air
execute in minecraft:overworld run fill 278 58 -32 278 77 -32 stone
execute in minecraft:overworld run fill 278 78 -32 278 79 -32 dirt
execute in minecraft:overworld run setblock 278 80 -32 grass_block
execute in minecraft:overworld run fill 278 81 -32 278 144 -32 air
execute in minecraft:overworld run setblock 278 81 -32 mossy_cobblestone
execute in minecraft:overworld run fill 278 58 -31 278 77 -31 stone
execute in minecraft:overworld run fill 278 78 -31 278 79 -31 dirt
execute in minecraft:overworld run setblock 278 80 -31 coarse_dirt
execute in minecraft:overworld run fill 278 81 -31 278 144 -31 air
execute in minecraft:overworld run fill 278 58 -30 278 76 -30 stone
execute in minecraft:overworld run fill 278 77 -30 278 78 -30 dirt
execute in minecraft:overworld run setblock 278 79 -30 grass_block
execute in minecraft:overworld run fill 278 80 -30 278 144 -30 air
execute in minecraft:overworld run fill 278 58 -29 278 76 -29 stone
execute in minecraft:overworld run fill 278 77 -29 278 78 -29 dirt
execute in minecraft:overworld run setblock 278 79 -29 grass_block
execute in minecraft:overworld run fill 278 80 -29 278 144 -29 air
execute in minecraft:overworld run fill 278 58 -28 278 76 -28 stone
execute in minecraft:overworld run fill 278 77 -28 278 78 -28 dirt
execute in minecraft:overworld run setblock 278 79 -28 coarse_dirt
execute in minecraft:overworld run fill 278 80 -28 278 144 -28 air
execute in minecraft:overworld run fill 278 58 -27 278 75 -27 stone
execute in minecraft:overworld run fill 278 76 -27 278 77 -27 dirt
execute in minecraft:overworld run setblock 278 78 -27 grass_block
execute in minecraft:overworld run fill 278 79 -27 278 144 -27 air
execute in minecraft:overworld run setblock 278 79 -27 grass
execute in minecraft:overworld run fill 278 58 -26 278 75 -26 stone
execute in minecraft:overworld run fill 278 76 -26 278 77 -26 dirt
execute in minecraft:overworld run setblock 278 78 -26 coarse_dirt
execute in minecraft:overworld run fill 278 79 -26 278 144 -26 air
execute in minecraft:overworld run fill 278 58 -25 278 75 -25 stone
execute in minecraft:overworld run fill 278 76 -25 278 77 -25 dirt
execute in minecraft:overworld run setblock 278 78 -25 grass_block
execute in minecraft:overworld run fill 278 79 -25 278 144 -25 air
execute in minecraft:overworld run fill 278 58 -24 278 74 -24 stone
execute in minecraft:overworld run fill 278 75 -24 278 76 -24 dirt
execute in minecraft:overworld run setblock 278 77 -24 coarse_dirt
execute in minecraft:overworld run fill 278 78 -24 278 144 -24 air
execute in minecraft:overworld run fill 278 58 -23 278 74 -23 stone
execute in minecraft:overworld run fill 278 75 -23 278 76 -23 dirt
execute in minecraft:overworld run setblock 278 77 -23 coarse_dirt
execute in minecraft:overworld run fill 278 78 -23 278 144 -23 air
execute in minecraft:overworld run setblock 278 78 -23 grass
execute in minecraft:overworld run fill 278 58 -22 278 74 -22 stone
execute in minecraft:overworld run fill 278 75 -22 278 76 -22 dirt
execute in minecraft:overworld run setblock 278 77 -22 grass_block
execute in minecraft:overworld run fill 278 78 -22 278 144 -22 air
execute in minecraft:overworld run fill 278 58 -21 278 74 -21 stone
execute in minecraft:overworld run fill 278 75 -21 278 76 -21 dirt
execute in minecraft:overworld run setblock 278 77 -21 coarse_dirt
execute in minecraft:overworld run fill 278 78 -21 278 144 -21 air
execute in minecraft:overworld run setblock 278 78 -21 mossy_cobblestone
execute in minecraft:overworld run fill 278 58 -20 278 73 -20 stone
execute in minecraft:overworld run fill 278 74 -20 278 75 -20 dirt
execute in minecraft:overworld run setblock 278 76 -20 grass_block
execute in minecraft:overworld run fill 278 77 -20 278 144 -20 air
execute in minecraft:overworld run fill 278 58 -19 278 73 -19 stone
execute in minecraft:overworld run fill 278 74 -19 278 75 -19 dirt
execute in minecraft:overworld run setblock 278 76 -19 coarse_dirt
execute in minecraft:overworld run fill 278 77 -19 278 144 -19 air
execute in minecraft:overworld run fill 278 58 -18 278 72 -18 stone
execute in minecraft:overworld run fill 278 73 -18 278 74 -18 dirt
execute in minecraft:overworld run setblock 278 75 -18 grass_block
execute in minecraft:overworld run fill 278 76 -18 278 144 -18 air
execute in minecraft:overworld run fill 278 58 -17 278 72 -17 stone
execute in minecraft:overworld run fill 278 73 -17 278 74 -17 dirt
execute in minecraft:overworld run setblock 278 75 -17 coarse_dirt
execute in minecraft:overworld run fill 278 76 -17 278 144 -17 air
execute in minecraft:overworld run fill 278 58 -16 278 71 -16 stone
execute in minecraft:overworld run fill 278 72 -16 278 73 -16 dirt
execute in minecraft:overworld run setblock 278 74 -16 grass_block
execute in minecraft:overworld run fill 278 75 -16 278 144 -16 air
execute in minecraft:overworld run setblock 278 75 -16 grass
execute in minecraft:overworld run fill 278 58 -15 278 71 -15 stone
execute in minecraft:overworld run fill 278 72 -15 278 73 -15 dirt
execute in minecraft:overworld run setblock 278 74 -15 coarse_dirt
execute in minecraft:overworld run fill 278 75 -15 278 144 -15 air
execute in minecraft:overworld run fill 278 58 -14 278 70 -14 stone
execute in minecraft:overworld run fill 278 71 -14 278 72 -14 dirt
execute in minecraft:overworld run setblock 278 73 -14 coarse_dirt
execute in minecraft:overworld run fill 278 74 -14 278 144 -14 air
execute in minecraft:overworld run fill 278 58 -13 278 69 -13 stone
execute in minecraft:overworld run fill 278 70 -13 278 71 -13 dirt
execute in minecraft:overworld run setblock 278 72 -13 coarse_dirt
execute in minecraft:overworld run fill 278 73 -13 278 144 -13 air
execute in minecraft:overworld run fill 278 58 -12 278 68 -12 stone
execute in minecraft:overworld run fill 278 69 -12 278 70 -12 dirt
execute in minecraft:overworld run setblock 278 71 -12 coarse_dirt
execute in minecraft:overworld run fill 278 72 -12 278 144 -12 air
execute in minecraft:overworld run fill 278 58 -11 278 68 -11 stone
execute in minecraft:overworld run fill 278 69 -11 278 70 -11 dirt
execute in minecraft:overworld run setblock 278 71 -11 coarse_dirt
execute in minecraft:overworld run fill 278 72 -11 278 144 -11 air
execute in minecraft:overworld run fill 278 58 -10 278 68 -10 stone
execute in minecraft:overworld run fill 278 69 -10 278 70 -10 dirt
execute in minecraft:overworld run setblock 278 71 -10 coarse_dirt
execute in minecraft:overworld run fill 278 72 -10 278 144 -10 air
execute in minecraft:overworld run fill 278 58 -9 278 67 -9 stone
execute in minecraft:overworld run fill 278 68 -9 278 69 -9 dirt
execute in minecraft:overworld run setblock 278 70 -9 coarse_dirt
execute in minecraft:overworld run fill 278 71 -9 278 144 -9 air
execute in minecraft:overworld run fill 278 58 -8 278 67 -8 stone
execute in minecraft:overworld run fill 278 68 -8 278 69 -8 dirt
execute in minecraft:overworld run setblock 278 70 -8 grass_block
execute in minecraft:overworld run fill 278 71 -8 278 144 -8 air
execute in minecraft:overworld run fill 278 58 -7 278 67 -7 stone
execute in minecraft:overworld run fill 278 68 -7 278 69 -7 dirt
execute in minecraft:overworld run setblock 278 70 -7 grass_block
execute in minecraft:overworld run fill 278 71 -7 278 144 -7 air
execute in minecraft:overworld run fill 278 58 -6 278 67 -6 stone
execute in minecraft:overworld run fill 278 68 -6 278 69 -6 dirt
execute in minecraft:overworld run setblock 278 70 -6 coarse_dirt
execute in minecraft:overworld run fill 278 71 -6 278 144 -6 air
execute in minecraft:overworld run fill 278 58 -5 278 67 -5 stone
execute in minecraft:overworld run fill 278 68 -5 278 69 -5 dirt
execute in minecraft:overworld run setblock 278 70 -5 coarse_dirt
execute in minecraft:overworld run fill 278 71 -5 278 144 -5 air
execute in minecraft:overworld run setblock 278 71 -5 mossy_cobblestone
execute in minecraft:overworld run fill 278 58 -4 278 67 -4 stone
execute in minecraft:overworld run fill 278 68 -4 278 69 -4 dirt
execute in minecraft:overworld run setblock 278 70 -4 grass_block
execute in minecraft:overworld run fill 278 71 -4 278 144 -4 air
execute in minecraft:overworld run fill 278 58 -3 278 67 -3 stone
execute in minecraft:overworld run fill 278 68 -3 278 69 -3 dirt
execute in minecraft:overworld run setblock 278 70 -3 coarse_dirt
execute in minecraft:overworld run fill 278 71 -3 278 144 -3 air
execute in minecraft:overworld run fill 278 58 -2 278 67 -2 stone
execute in minecraft:overworld run fill 278 68 -2 278 69 -2 dirt
execute in minecraft:overworld run setblock 278 70 -2 coarse_dirt
execute in minecraft:overworld run fill 278 71 -2 278 144 -2 air
execute in minecraft:overworld run fill 278 58 -1 278 67 -1 stone
execute in minecraft:overworld run fill 278 68 -1 278 69 -1 dirt
execute in minecraft:overworld run setblock 278 70 -1 grass_block
execute in minecraft:overworld run fill 278 71 -1 278 144 -1 air
execute in minecraft:overworld run fill 278 58 0 278 67 0 stone
execute in minecraft:overworld run fill 278 68 0 278 69 0 dirt
execute in minecraft:overworld run setblock 278 70 0 grass_block
execute in minecraft:overworld run fill 278 71 0 278 144 0 air
execute in minecraft:overworld run fill 278 58 1 278 66 1 stone
execute in minecraft:overworld run fill 278 67 1 278 68 1 dirt
execute in minecraft:overworld run setblock 278 69 1 coarse_dirt
execute in minecraft:overworld run fill 278 70 1 278 144 1 air
execute in minecraft:overworld run fill 278 58 2 278 66 2 stone
execute in minecraft:overworld run fill 278 67 2 278 68 2 dirt
execute in minecraft:overworld run setblock 278 69 2 grass_block
execute in minecraft:overworld run fill 278 70 2 278 144 2 air
execute in minecraft:overworld run fill 278 58 3 278 66 3 stone
execute in minecraft:overworld run fill 278 67 3 278 68 3 dirt
execute in minecraft:overworld run setblock 278 69 3 coarse_dirt
execute in minecraft:overworld run fill 278 70 3 278 144 3 air
execute in minecraft:overworld run fill 278 58 4 278 66 4 stone
execute in minecraft:overworld run fill 278 67 4 278 68 4 dirt
execute in minecraft:overworld run setblock 278 69 4 coarse_dirt
execute in minecraft:overworld run fill 278 70 4 278 144 4 air
execute in minecraft:overworld run fill 278 58 5 278 65 5 stone
execute in minecraft:overworld run fill 278 66 5 278 67 5 dirt
execute in minecraft:overworld run setblock 278 68 5 coarse_dirt
execute in minecraft:overworld run fill 278 69 5 278 144 5 air
execute in minecraft:overworld run setblock 278 69 5 mossy_cobblestone
execute in minecraft:overworld run fill 278 58 6 278 65 6 stone
execute in minecraft:overworld run fill 278 66 6 278 67 6 dirt
execute in minecraft:overworld run setblock 278 68 6 coarse_dirt
execute in minecraft:overworld run fill 278 69 6 278 144 6 air
execute in minecraft:overworld run fill 278 58 7 278 65 7 stone
execute in minecraft:overworld run fill 278 66 7 278 67 7 dirt
execute in minecraft:overworld run setblock 278 68 7 grass_block
execute in minecraft:overworld run fill 278 69 7 278 144 7 air
execute in minecraft:overworld run fill 278 58 8 278 65 8 stone
execute in minecraft:overworld run fill 278 66 8 278 67 8 dirt
execute in minecraft:overworld run setblock 278 68 8 coarse_dirt
execute in minecraft:overworld run fill 278 69 8 278 144 8 air
execute in minecraft:overworld run fill 278 58 9 278 64 9 stone
execute in minecraft:overworld run fill 278 65 9 278 66 9 dirt
execute in minecraft:overworld run setblock 278 67 9 grass_block
execute in minecraft:overworld run fill 278 68 9 278 144 9 air
execute in minecraft:overworld run fill 278 58 10 278 64 10 stone
execute in minecraft:overworld run fill 278 65 10 278 66 10 dirt
execute in minecraft:overworld run setblock 278 67 10 grass_block
schedule function blade_gallery:random/burned/part_112 1t replace
