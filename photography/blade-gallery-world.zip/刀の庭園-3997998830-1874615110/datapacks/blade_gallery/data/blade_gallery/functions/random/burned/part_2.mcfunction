execute in minecraft:overworld run setblock 209 64 -17 coarse_dirt
execute in minecraft:overworld run fill 209 65 -17 209 144 -17 air
execute in minecraft:overworld run fill 209 58 -16 209 61 -16 stone
execute in minecraft:overworld run fill 209 62 -16 209 63 -16 dirt
execute in minecraft:overworld run setblock 209 64 -16 coarse_dirt
execute in minecraft:overworld run fill 209 65 -16 209 144 -16 air
execute in minecraft:overworld run fill 209 58 -15 209 61 -15 stone
execute in minecraft:overworld run fill 209 62 -15 209 63 -15 dirt
execute in minecraft:overworld run setblock 209 64 -15 grass_block
execute in minecraft:overworld run fill 209 65 -15 209 144 -15 air
execute in minecraft:overworld run fill 209 58 -14 209 61 -14 stone
execute in minecraft:overworld run fill 209 62 -14 209 63 -14 dirt
execute in minecraft:overworld run setblock 209 64 -14 coarse_dirt
execute in minecraft:overworld run fill 209 65 -14 209 144 -14 air
execute in minecraft:overworld run fill 209 58 -13 209 61 -13 stone
execute in minecraft:overworld run fill 209 62 -13 209 63 -13 dirt
execute in minecraft:overworld run setblock 209 64 -13 grass_block
execute in minecraft:overworld run fill 209 65 -13 209 144 -13 air
execute in minecraft:overworld run fill 209 58 -12 209 61 -12 stone
execute in minecraft:overworld run fill 209 62 -12 209 63 -12 dirt
execute in minecraft:overworld run setblock 209 64 -12 grass_block
execute in minecraft:overworld run fill 209 65 -12 209 144 -12 air
execute in minecraft:overworld run fill 209 58 -11 209 62 -11 stone
execute in minecraft:overworld run fill 209 63 -11 209 64 -11 dirt
execute in minecraft:overworld run setblock 209 65 -11 grass_block
execute in minecraft:overworld run fill 209 66 -11 209 144 -11 air
execute in minecraft:overworld run fill 209 58 -10 209 62 -10 stone
execute in minecraft:overworld run fill 209 63 -10 209 64 -10 dirt
execute in minecraft:overworld run setblock 209 65 -10 coarse_dirt
execute in minecraft:overworld run fill 209 66 -10 209 144 -10 air
execute in minecraft:overworld run fill 209 58 -9 209 62 -9 stone
execute in minecraft:overworld run fill 209 63 -9 209 64 -9 dirt
execute in minecraft:overworld run setblock 209 65 -9 grass_block
execute in minecraft:overworld run fill 209 66 -9 209 144 -9 air
execute in minecraft:overworld run fill 209 58 -8 209 62 -8 stone
execute in minecraft:overworld run fill 209 63 -8 209 64 -8 dirt
execute in minecraft:overworld run setblock 209 65 -8 coarse_dirt
execute in minecraft:overworld run fill 209 66 -8 209 144 -8 air
execute in minecraft:overworld run fill 209 58 -7 209 62 -7 stone
execute in minecraft:overworld run fill 209 63 -7 209 64 -7 dirt
execute in minecraft:overworld run setblock 209 65 -7 coarse_dirt
execute in minecraft:overworld run fill 209 66 -7 209 144 -7 air
execute in minecraft:overworld run fill 209 58 -6 209 62 -6 stone
execute in minecraft:overworld run fill 209 63 -6 209 64 -6 dirt
execute in minecraft:overworld run setblock 209 65 -6 coarse_dirt
execute in minecraft:overworld run fill 209 66 -6 209 144 -6 air
execute in minecraft:overworld run fill 209 58 -5 209 62 -5 stone
execute in minecraft:overworld run fill 209 63 -5 209 64 -5 dirt
execute in minecraft:overworld run setblock 209 65 -5 grass_block
execute in minecraft:overworld run fill 209 66 -5 209 144 -5 air
execute in minecraft:overworld run fill 209 58 -4 209 62 -4 stone
execute in minecraft:overworld run fill 209 63 -4 209 64 -4 dirt
execute in minecraft:overworld run setblock 209 65 -4 coarse_dirt
execute in minecraft:overworld run fill 209 66 -4 209 144 -4 air
execute in minecraft:overworld run fill 209 58 -3 209 62 -3 stone
execute in minecraft:overworld run fill 209 63 -3 209 64 -3 dirt
execute in minecraft:overworld run setblock 209 65 -3 coarse_dirt
execute in minecraft:overworld run fill 209 66 -3 209 144 -3 air
execute in minecraft:overworld run fill 209 58 -2 209 62 -2 stone
execute in minecraft:overworld run fill 209 63 -2 209 64 -2 dirt
execute in minecraft:overworld run setblock 209 65 -2 coarse_dirt
execute in minecraft:overworld run fill 209 66 -2 209 144 -2 air
execute in minecraft:overworld run fill 209 58 -1 209 62 -1 stone
execute in minecraft:overworld run fill 209 63 -1 209 64 -1 dirt
execute in minecraft:overworld run setblock 209 65 -1 coarse_dirt
execute in minecraft:overworld run fill 209 66 -1 209 144 -1 air
execute in minecraft:overworld run fill 209 58 0 209 62 0 stone
execute in minecraft:overworld run fill 209 63 0 209 64 0 dirt
execute in minecraft:overworld run setblock 209 65 0 grass_block
execute in minecraft:overworld run fill 209 66 0 209 144 0 air
execute in minecraft:overworld run fill 209 58 1 209 62 1 stone
execute in minecraft:overworld run fill 209 63 1 209 64 1 dirt
execute in minecraft:overworld run setblock 209 65 1 coarse_dirt
execute in minecraft:overworld run fill 209 66 1 209 144 1 air
execute in minecraft:overworld run fill 209 58 2 209 62 2 stone
execute in minecraft:overworld run fill 209 63 2 209 64 2 dirt
execute in minecraft:overworld run setblock 209 65 2 grass_block
execute in minecraft:overworld run fill 209 66 2 209 144 2 air
execute in minecraft:overworld run fill 209 58 3 209 62 3 stone
execute in minecraft:overworld run fill 209 63 3 209 64 3 dirt
execute in minecraft:overworld run setblock 209 65 3 coarse_dirt
execute in minecraft:overworld run fill 209 66 3 209 144 3 air
execute in minecraft:overworld run fill 209 58 4 209 62 4 stone
execute in minecraft:overworld run fill 209 63 4 209 64 4 dirt
execute in minecraft:overworld run setblock 209 65 4 grass_block
execute in minecraft:overworld run fill 209 66 4 209 144 4 air
execute in minecraft:overworld run fill 209 58 5 209 62 5 stone
execute in minecraft:overworld run fill 209 63 5 209 64 5 dirt
execute in minecraft:overworld run setblock 209 65 5 grass_block
execute in minecraft:overworld run fill 209 66 5 209 144 5 air
execute in minecraft:overworld run fill 209 58 6 209 62 6 stone
execute in minecraft:overworld run fill 209 63 6 209 64 6 dirt
execute in minecraft:overworld run setblock 209 65 6 grass_block
execute in minecraft:overworld run fill 209 66 6 209 144 6 air
execute in minecraft:overworld run fill 209 58 7 209 62 7 stone
execute in minecraft:overworld run fill 209 63 7 209 64 7 dirt
execute in minecraft:overworld run setblock 209 65 7 grass_block
execute in minecraft:overworld run fill 209 66 7 209 144 7 air
execute in minecraft:overworld run fill 209 58 8 209 62 8 stone
execute in minecraft:overworld run fill 209 63 8 209 64 8 dirt
execute in minecraft:overworld run setblock 209 65 8 grass_block
execute in minecraft:overworld run fill 209 66 8 209 144 8 air
execute in minecraft:overworld run fill 209 58 9 209 62 9 stone
execute in minecraft:overworld run fill 209 63 9 209 64 9 dirt
execute in minecraft:overworld run setblock 209 65 9 coarse_dirt
execute in minecraft:overworld run fill 209 66 9 209 144 9 air
execute in minecraft:overworld run fill 209 58 10 209 62 10 stone
execute in minecraft:overworld run fill 209 63 10 209 64 10 dirt
execute in minecraft:overworld run setblock 209 65 10 coarse_dirt
execute in minecraft:overworld run fill 209 66 10 209 144 10 air
execute in minecraft:overworld run fill 209 58 11 209 62 11 stone
execute in minecraft:overworld run fill 209 63 11 209 64 11 dirt
execute in minecraft:overworld run setblock 209 65 11 grass_block
execute in minecraft:overworld run fill 209 66 11 209 144 11 air
execute in minecraft:overworld run fill 209 58 12 209 62 12 stone
execute in minecraft:overworld run fill 209 63 12 209 64 12 dirt
execute in minecraft:overworld run setblock 209 65 12 grass_block
execute in minecraft:overworld run fill 209 66 12 209 144 12 air
execute in minecraft:overworld run fill 209 58 13 209 62 13 stone
execute in minecraft:overworld run fill 209 63 13 209 64 13 dirt
execute in minecraft:overworld run setblock 209 65 13 coarse_dirt
execute in minecraft:overworld run fill 209 66 13 209 144 13 air
execute in minecraft:overworld run fill 209 58 14 209 62 14 stone
execute in minecraft:overworld run fill 209 63 14 209 64 14 dirt
execute in minecraft:overworld run setblock 209 65 14 grass_block
execute in minecraft:overworld run fill 209 66 14 209 144 14 air
execute in minecraft:overworld run fill 209 58 15 209 62 15 stone
execute in minecraft:overworld run fill 209 63 15 209 64 15 dirt
execute in minecraft:overworld run setblock 209 65 15 coarse_dirt
execute in minecraft:overworld run fill 209 66 15 209 144 15 air
execute in minecraft:overworld run fill 209 58 16 209 62 16 stone
execute in minecraft:overworld run fill 209 63 16 209 64 16 dirt
execute in minecraft:overworld run setblock 209 65 16 coarse_dirt
execute in minecraft:overworld run fill 209 66 16 209 144 16 air
execute in minecraft:overworld run fill 209 58 17 209 62 17 stone
execute in minecraft:overworld run fill 209 63 17 209 64 17 dirt
execute in minecraft:overworld run setblock 209 65 17 grass_block
execute in minecraft:overworld run fill 209 66 17 209 144 17 air
execute in minecraft:overworld run fill 209 58 18 209 62 18 stone
execute in minecraft:overworld run fill 209 63 18 209 64 18 dirt
execute in minecraft:overworld run setblock 209 65 18 coarse_dirt
execute in minecraft:overworld run fill 209 66 18 209 144 18 air
execute in minecraft:overworld run fill 209 58 19 209 62 19 stone
execute in minecraft:overworld run fill 209 63 19 209 64 19 dirt
execute in minecraft:overworld run setblock 209 65 19 grass_block
execute in minecraft:overworld run fill 209 66 19 209 144 19 air
execute in minecraft:overworld run fill 209 58 20 209 62 20 stone
execute in minecraft:overworld run fill 209 63 20 209 64 20 dirt
execute in minecraft:overworld run setblock 209 65 20 coarse_dirt
execute in minecraft:overworld run fill 209 66 20 209 144 20 air
execute in minecraft:overworld run fill 209 58 21 209 62 21 stone
execute in minecraft:overworld run fill 209 63 21 209 64 21 dirt
execute in minecraft:overworld run setblock 209 65 21 coarse_dirt
execute in minecraft:overworld run fill 209 66 21 209 144 21 air
execute in minecraft:overworld run fill 209 58 22 209 62 22 stone
execute in minecraft:overworld run fill 209 63 22 209 64 22 dirt
execute in minecraft:overworld run setblock 209 65 22 coarse_dirt
execute in minecraft:overworld run fill 209 66 22 209 144 22 air
execute in minecraft:overworld run fill 209 58 23 209 62 23 stone
execute in minecraft:overworld run fill 209 63 23 209 64 23 dirt
execute in minecraft:overworld run setblock 209 65 23 coarse_dirt
execute in minecraft:overworld run fill 209 66 23 209 144 23 air
execute in minecraft:overworld run fill 209 58 24 209 62 24 stone
execute in minecraft:overworld run fill 209 63 24 209 64 24 dirt
execute in minecraft:overworld run setblock 209 65 24 coarse_dirt
execute in minecraft:overworld run fill 209 66 24 209 144 24 air
execute in minecraft:overworld run fill 209 58 25 209 62 25 stone
execute in minecraft:overworld run fill 209 63 25 209 64 25 dirt
execute in minecraft:overworld run setblock 209 65 25 grass_block
execute in minecraft:overworld run fill 209 66 25 209 144 25 air
execute in minecraft:overworld run fill 209 58 26 209 62 26 stone
execute in minecraft:overworld run fill 209 63 26 209 64 26 dirt
execute in minecraft:overworld run setblock 209 65 26 coarse_dirt
execute in minecraft:overworld run fill 209 66 26 209 144 26 air
execute in minecraft:overworld run fill 209 58 27 209 62 27 stone
execute in minecraft:overworld run fill 209 63 27 209 64 27 dirt
execute in minecraft:overworld run setblock 209 65 27 coarse_dirt
execute in minecraft:overworld run fill 209 66 27 209 144 27 air
execute in minecraft:overworld run fill 209 58 28 209 62 28 stone
execute in minecraft:overworld run fill 209 63 28 209 64 28 dirt
execute in minecraft:overworld run setblock 209 65 28 coarse_dirt
execute in minecraft:overworld run fill 209 66 28 209 144 28 air
execute in minecraft:overworld run fill 209 58 29 209 62 29 stone
execute in minecraft:overworld run fill 209 63 29 209 64 29 dirt
execute in minecraft:overworld run setblock 209 65 29 coarse_dirt
execute in minecraft:overworld run fill 209 66 29 209 144 29 air
execute in minecraft:overworld run fill 209 58 30 209 62 30 stone
execute in minecraft:overworld run fill 209 63 30 209 64 30 dirt
execute in minecraft:overworld run setblock 209 65 30 grass_block
execute in minecraft:overworld run fill 209 66 30 209 144 30 air
execute in minecraft:overworld run fill 209 58 31 209 62 31 stone
execute in minecraft:overworld run fill 209 63 31 209 64 31 dirt
execute in minecraft:overworld run setblock 209 65 31 coarse_dirt
execute in minecraft:overworld run fill 209 66 31 209 144 31 air
execute in minecraft:overworld run fill 209 58 32 209 62 32 stone
execute in minecraft:overworld run fill 209 63 32 209 64 32 dirt
execute in minecraft:overworld run setblock 209 65 32 coarse_dirt
execute in minecraft:overworld run fill 209 66 32 209 144 32 air
execute in minecraft:overworld run fill 209 58 33 209 62 33 stone
execute in minecraft:overworld run fill 209 63 33 209 64 33 dirt
execute in minecraft:overworld run setblock 209 65 33 grass_block
execute in minecraft:overworld run fill 209 66 33 209 144 33 air
execute in minecraft:overworld run fill 209 58 34 209 62 34 stone
execute in minecraft:overworld run fill 209 63 34 209 64 34 dirt
execute in minecraft:overworld run setblock 209 65 34 coarse_dirt
execute in minecraft:overworld run fill 209 66 34 209 144 34 air
execute in minecraft:overworld run fill 209 58 35 209 62 35 stone
execute in minecraft:overworld run fill 209 63 35 209 64 35 dirt
execute in minecraft:overworld run setblock 209 65 35 coarse_dirt
execute in minecraft:overworld run fill 209 66 35 209 144 35 air
execute in minecraft:overworld run fill 209 58 36 209 62 36 stone
execute in minecraft:overworld run fill 209 63 36 209 64 36 dirt
execute in minecraft:overworld run setblock 209 65 36 coarse_dirt
execute in minecraft:overworld run fill 209 66 36 209 144 36 air
execute in minecraft:overworld run fill 209 58 37 209 62 37 stone
execute in minecraft:overworld run fill 209 63 37 209 64 37 dirt
execute in minecraft:overworld run setblock 209 65 37 coarse_dirt
execute in minecraft:overworld run fill 209 66 37 209 144 37 air
execute in minecraft:overworld run fill 209 58 38 209 62 38 stone
execute in minecraft:overworld run fill 209 63 38 209 64 38 dirt
execute in minecraft:overworld run setblock 209 65 38 coarse_dirt
execute in minecraft:overworld run fill 209 66 38 209 144 38 air
execute in minecraft:overworld run fill 209 58 39 209 62 39 stone
execute in minecraft:overworld run fill 209 63 39 209 64 39 dirt
execute in minecraft:overworld run setblock 209 65 39 coarse_dirt
execute in minecraft:overworld run fill 209 66 39 209 144 39 air
execute in minecraft:overworld run fill 209 58 40 209 62 40 stone
execute in minecraft:overworld run fill 209 63 40 209 64 40 dirt
execute in minecraft:overworld run setblock 209 65 40 coarse_dirt
execute in minecraft:overworld run fill 209 66 40 209 144 40 air
execute in minecraft:overworld run fill 209 58 41 209 62 41 stone
execute in minecraft:overworld run fill 209 63 41 209 64 41 dirt
execute in minecraft:overworld run setblock 209 65 41 grass_block
execute in minecraft:overworld run fill 209 66 41 209 144 41 air
execute in minecraft:overworld run fill 209 58 42 209 61 42 stone
execute in minecraft:overworld run fill 209 62 42 209 63 42 dirt
execute in minecraft:overworld run setblock 209 64 42 coarse_dirt
execute in minecraft:overworld run fill 209 65 42 209 144 42 air
execute in minecraft:overworld run fill 209 58 43 209 61 43 stone
execute in minecraft:overworld run fill 209 62 43 209 63 43 dirt
execute in minecraft:overworld run setblock 209 64 43 coarse_dirt
execute in minecraft:overworld run fill 209 65 43 209 144 43 air
execute in minecraft:overworld run fill 209 58 44 209 61 44 stone
execute in minecraft:overworld run fill 209 62 44 209 63 44 dirt
execute in minecraft:overworld run setblock 209 64 44 coarse_dirt
execute in minecraft:overworld run fill 209 65 44 209 144 44 air
execute in minecraft:overworld run fill 209 58 45 209 61 45 stone
execute in minecraft:overworld run fill 209 62 45 209 63 45 dirt
execute in minecraft:overworld run setblock 209 64 45 coarse_dirt
execute in minecraft:overworld run fill 209 65 45 209 144 45 air
execute in minecraft:overworld run fill 209 58 46 209 61 46 stone
execute in minecraft:overworld run fill 209 62 46 209 63 46 dirt
execute in minecraft:overworld run setblock 209 64 46 grass_block
execute in minecraft:overworld run fill 209 65 46 209 144 46 air
execute in minecraft:overworld run fill 209 58 47 209 61 47 stone
execute in minecraft:overworld run fill 209 62 47 209 63 47 dirt
schedule function blade_gallery:random/burned/part_3 1t replace
