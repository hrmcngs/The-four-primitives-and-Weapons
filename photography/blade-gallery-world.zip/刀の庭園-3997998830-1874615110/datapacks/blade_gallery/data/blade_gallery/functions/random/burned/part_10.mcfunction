execute in minecraft:overworld run setblock 214 68 15 grass_block
execute in minecraft:overworld run fill 214 69 15 214 144 15 air
execute in minecraft:overworld run fill 214 58 16 214 66 16 stone
execute in minecraft:overworld run fill 214 67 16 214 68 16 dirt
execute in minecraft:overworld run setblock 214 69 16 coarse_dirt
execute in minecraft:overworld run fill 214 70 16 214 144 16 air
execute in minecraft:overworld run fill 214 58 17 214 66 17 stone
execute in minecraft:overworld run fill 214 67 17 214 68 17 dirt
execute in minecraft:overworld run setblock 214 69 17 coarse_dirt
execute in minecraft:overworld run fill 214 70 17 214 144 17 air
execute in minecraft:overworld run fill 214 58 18 214 66 18 stone
execute in minecraft:overworld run fill 214 67 18 214 68 18 dirt
execute in minecraft:overworld run setblock 214 69 18 coarse_dirt
execute in minecraft:overworld run fill 214 70 18 214 144 18 air
execute in minecraft:overworld run fill 214 58 19 214 66 19 stone
execute in minecraft:overworld run fill 214 67 19 214 68 19 dirt
execute in minecraft:overworld run setblock 214 69 19 grass_block
execute in minecraft:overworld run fill 214 70 19 214 144 19 air
execute in minecraft:overworld run fill 214 58 20 214 66 20 stone
execute in minecraft:overworld run fill 214 67 20 214 68 20 dirt
execute in minecraft:overworld run setblock 214 69 20 grass_block
execute in minecraft:overworld run fill 214 70 20 214 144 20 air
execute in minecraft:overworld run fill 214 58 21 214 66 21 stone
execute in minecraft:overworld run fill 214 67 21 214 68 21 dirt
execute in minecraft:overworld run setblock 214 69 21 grass_block
execute in minecraft:overworld run fill 214 70 21 214 144 21 air
execute in minecraft:overworld run fill 214 58 22 214 66 22 stone
execute in minecraft:overworld run fill 214 67 22 214 68 22 dirt
execute in minecraft:overworld run setblock 214 69 22 grass_block
execute in minecraft:overworld run fill 214 70 22 214 144 22 air
execute in minecraft:overworld run fill 214 58 23 214 66 23 stone
execute in minecraft:overworld run fill 214 67 23 214 68 23 dirt
execute in minecraft:overworld run setblock 214 69 23 coarse_dirt
execute in minecraft:overworld run fill 214 70 23 214 144 23 air
execute in minecraft:overworld run fill 214 58 24 214 66 24 stone
execute in minecraft:overworld run fill 214 67 24 214 68 24 dirt
execute in minecraft:overworld run setblock 214 69 24 coarse_dirt
execute in minecraft:overworld run fill 214 70 24 214 144 24 air
execute in minecraft:overworld run fill 214 58 25 214 66 25 stone
execute in minecraft:overworld run fill 214 67 25 214 68 25 dirt
execute in minecraft:overworld run setblock 214 69 25 grass_block
execute in minecraft:overworld run fill 214 70 25 214 144 25 air
execute in minecraft:overworld run fill 214 58 26 214 66 26 stone
execute in minecraft:overworld run fill 214 67 26 214 68 26 dirt
execute in minecraft:overworld run setblock 214 69 26 coarse_dirt
execute in minecraft:overworld run fill 214 70 26 214 144 26 air
execute in minecraft:overworld run fill 214 58 27 214 66 27 stone
execute in minecraft:overworld run fill 214 67 27 214 68 27 dirt
execute in minecraft:overworld run setblock 214 69 27 coarse_dirt
execute in minecraft:overworld run fill 214 70 27 214 144 27 air
execute in minecraft:overworld run fill 214 58 28 214 66 28 stone
execute in minecraft:overworld run fill 214 67 28 214 68 28 dirt
execute in minecraft:overworld run setblock 214 69 28 coarse_dirt
execute in minecraft:overworld run fill 214 70 28 214 144 28 air
execute in minecraft:overworld run fill 214 58 29 214 66 29 stone
execute in minecraft:overworld run fill 214 67 29 214 68 29 dirt
execute in minecraft:overworld run setblock 214 69 29 coarse_dirt
execute in minecraft:overworld run fill 214 70 29 214 144 29 air
execute in minecraft:overworld run fill 214 58 30 214 66 30 stone
execute in minecraft:overworld run fill 214 67 30 214 68 30 dirt
execute in minecraft:overworld run setblock 214 69 30 coarse_dirt
execute in minecraft:overworld run fill 214 70 30 214 144 30 air
execute in minecraft:overworld run fill 214 58 31 214 66 31 stone
execute in minecraft:overworld run fill 214 67 31 214 68 31 dirt
execute in minecraft:overworld run setblock 214 69 31 grass_block
execute in minecraft:overworld run fill 214 70 31 214 144 31 air
execute in minecraft:overworld run fill 214 58 32 214 66 32 stone
execute in minecraft:overworld run fill 214 67 32 214 68 32 dirt
execute in minecraft:overworld run setblock 214 69 32 coarse_dirt
execute in minecraft:overworld run fill 214 70 32 214 144 32 air
execute in minecraft:overworld run fill 214 58 33 214 66 33 stone
execute in minecraft:overworld run fill 214 67 33 214 68 33 dirt
execute in minecraft:overworld run setblock 214 69 33 grass_block
execute in minecraft:overworld run fill 214 70 33 214 144 33 air
execute in minecraft:overworld run fill 214 58 34 214 66 34 stone
execute in minecraft:overworld run fill 214 67 34 214 68 34 dirt
execute in minecraft:overworld run setblock 214 69 34 coarse_dirt
execute in minecraft:overworld run fill 214 70 34 214 144 34 air
execute in minecraft:overworld run fill 214 58 35 214 66 35 stone
execute in minecraft:overworld run fill 214 67 35 214 68 35 dirt
execute in minecraft:overworld run setblock 214 69 35 grass_block
execute in minecraft:overworld run fill 214 70 35 214 144 35 air
execute in minecraft:overworld run fill 214 58 36 214 65 36 stone
execute in minecraft:overworld run fill 214 66 36 214 67 36 dirt
execute in minecraft:overworld run setblock 214 68 36 coarse_dirt
execute in minecraft:overworld run fill 214 69 36 214 144 36 air
execute in minecraft:overworld run fill 214 58 37 214 65 37 stone
execute in minecraft:overworld run fill 214 66 37 214 67 37 dirt
execute in minecraft:overworld run setblock 214 68 37 coarse_dirt
execute in minecraft:overworld run fill 214 69 37 214 144 37 air
execute in minecraft:overworld run fill 214 58 38 214 65 38 stone
execute in minecraft:overworld run fill 214 66 38 214 67 38 dirt
execute in minecraft:overworld run setblock 214 68 38 grass_block
execute in minecraft:overworld run fill 214 69 38 214 144 38 air
execute in minecraft:overworld run fill 214 58 39 214 65 39 stone
execute in minecraft:overworld run fill 214 66 39 214 67 39 dirt
execute in minecraft:overworld run setblock 214 68 39 coarse_dirt
execute in minecraft:overworld run fill 214 69 39 214 144 39 air
execute in minecraft:overworld run fill 214 58 40 214 65 40 stone
execute in minecraft:overworld run fill 214 66 40 214 67 40 dirt
execute in minecraft:overworld run setblock 214 68 40 coarse_dirt
execute in minecraft:overworld run fill 214 69 40 214 144 40 air
execute in minecraft:overworld run fill 214 58 41 214 65 41 stone
execute in minecraft:overworld run fill 214 66 41 214 67 41 dirt
execute in minecraft:overworld run setblock 214 68 41 coarse_dirt
execute in minecraft:overworld run fill 214 69 41 214 144 41 air
execute in minecraft:overworld run fill 214 58 42 214 64 42 stone
execute in minecraft:overworld run fill 214 65 42 214 66 42 dirt
execute in minecraft:overworld run setblock 214 67 42 grass_block
execute in minecraft:overworld run fill 214 68 42 214 144 42 air
execute in minecraft:overworld run fill 214 58 43 214 64 43 stone
execute in minecraft:overworld run fill 214 65 43 214 66 43 dirt
execute in minecraft:overworld run setblock 214 67 43 coarse_dirt
execute in minecraft:overworld run fill 214 68 43 214 144 43 air
execute in minecraft:overworld run fill 214 58 44 214 63 44 stone
execute in minecraft:overworld run fill 214 64 44 214 65 44 dirt
execute in minecraft:overworld run setblock 214 66 44 coarse_dirt
execute in minecraft:overworld run fill 214 67 44 214 144 44 air
execute in minecraft:overworld run fill 214 58 45 214 62 45 stone
execute in minecraft:overworld run fill 214 63 45 214 64 45 dirt
execute in minecraft:overworld run setblock 214 65 45 grass_block
execute in minecraft:overworld run fill 214 66 45 214 144 45 air
execute in minecraft:overworld run fill 214 58 46 214 62 46 stone
execute in minecraft:overworld run fill 214 63 46 214 64 46 dirt
execute in minecraft:overworld run setblock 214 65 46 grass_block
execute in minecraft:overworld run fill 214 66 46 214 144 46 air
execute in minecraft:overworld run fill 214 58 47 214 61 47 stone
execute in minecraft:overworld run fill 214 62 47 214 63 47 dirt
execute in minecraft:overworld run setblock 214 64 47 coarse_dirt
execute in minecraft:overworld run fill 214 65 47 214 144 47 air
execute in minecraft:overworld run fill 215 58 -48 215 61 -48 stone
execute in minecraft:overworld run fill 215 62 -48 215 63 -48 dirt
execute in minecraft:overworld run setblock 215 64 -48 coarse_dirt
execute in minecraft:overworld run fill 215 65 -48 215 144 -48 air
execute in minecraft:overworld run fill 215 58 -47 215 63 -47 stone
execute in minecraft:overworld run fill 215 64 -47 215 65 -47 dirt
execute in minecraft:overworld run setblock 215 66 -47 coarse_dirt
execute in minecraft:overworld run fill 215 67 -47 215 144 -47 air
execute in minecraft:overworld run fill 215 58 -46 215 64 -46 stone
execute in minecraft:overworld run fill 215 65 -46 215 66 -46 dirt
execute in minecraft:overworld run setblock 215 67 -46 coarse_dirt
execute in minecraft:overworld run fill 215 68 -46 215 144 -46 air
execute in minecraft:overworld run fill 215 58 -45 215 66 -45 stone
execute in minecraft:overworld run fill 215 67 -45 215 68 -45 dirt
execute in minecraft:overworld run setblock 215 69 -45 coarse_dirt
execute in minecraft:overworld run fill 215 70 -45 215 144 -45 air
execute in minecraft:overworld run fill 215 58 -44 215 67 -44 stone
execute in minecraft:overworld run fill 215 68 -44 215 69 -44 dirt
execute in minecraft:overworld run setblock 215 70 -44 coarse_dirt
execute in minecraft:overworld run fill 215 71 -44 215 144 -44 air
execute in minecraft:overworld run fill 215 58 -43 215 68 -43 stone
execute in minecraft:overworld run fill 215 69 -43 215 70 -43 dirt
execute in minecraft:overworld run setblock 215 71 -43 coarse_dirt
execute in minecraft:overworld run fill 215 72 -43 215 144 -43 air
execute in minecraft:overworld run fill 215 58 -42 215 69 -42 stone
execute in minecraft:overworld run fill 215 70 -42 215 71 -42 dirt
execute in minecraft:overworld run setblock 215 72 -42 coarse_dirt
execute in minecraft:overworld run fill 215 73 -42 215 144 -42 air
execute in minecraft:overworld run fill 215 58 -41 215 70 -41 stone
execute in minecraft:overworld run fill 215 71 -41 215 72 -41 dirt
execute in minecraft:overworld run setblock 215 73 -41 coarse_dirt
execute in minecraft:overworld run fill 215 74 -41 215 144 -41 air
execute in minecraft:overworld run fill 215 58 -40 215 70 -40 stone
execute in minecraft:overworld run fill 215 71 -40 215 72 -40 dirt
execute in minecraft:overworld run setblock 215 73 -40 coarse_dirt
execute in minecraft:overworld run fill 215 74 -40 215 144 -40 air
execute in minecraft:overworld run fill 215 58 -39 215 69 -39 stone
execute in minecraft:overworld run fill 215 70 -39 215 71 -39 dirt
execute in minecraft:overworld run setblock 215 72 -39 coarse_dirt
execute in minecraft:overworld run fill 215 73 -39 215 144 -39 air
execute in minecraft:overworld run fill 215 58 -38 215 69 -38 stone
execute in minecraft:overworld run fill 215 70 -38 215 71 -38 dirt
execute in minecraft:overworld run setblock 215 72 -38 coarse_dirt
execute in minecraft:overworld run fill 215 73 -38 215 144 -38 air
execute in minecraft:overworld run fill 215 58 -37 215 68 -37 stone
execute in minecraft:overworld run fill 215 69 -37 215 70 -37 dirt
execute in minecraft:overworld run setblock 215 71 -37 coarse_dirt
execute in minecraft:overworld run fill 215 72 -37 215 144 -37 air
execute in minecraft:overworld run fill 215 58 -36 215 67 -36 stone
execute in minecraft:overworld run fill 215 68 -36 215 69 -36 dirt
execute in minecraft:overworld run setblock 215 70 -36 coarse_dirt
execute in minecraft:overworld run fill 215 71 -36 215 144 -36 air
execute in minecraft:overworld run fill 215 58 -35 215 67 -35 stone
execute in minecraft:overworld run fill 215 68 -35 215 69 -35 dirt
execute in minecraft:overworld run setblock 215 70 -35 coarse_dirt
execute in minecraft:overworld run fill 215 71 -35 215 144 -35 air
execute in minecraft:overworld run fill 215 58 -34 215 67 -34 stone
execute in minecraft:overworld run fill 215 68 -34 215 69 -34 dirt
execute in minecraft:overworld run setblock 215 70 -34 coarse_dirt
execute in minecraft:overworld run fill 215 71 -34 215 144 -34 air
execute in minecraft:overworld run fill 215 58 -33 215 66 -33 stone
execute in minecraft:overworld run fill 215 67 -33 215 68 -33 dirt
execute in minecraft:overworld run setblock 215 69 -33 coarse_dirt
execute in minecraft:overworld run fill 215 70 -33 215 144 -33 air
execute in minecraft:overworld run fill 215 58 -32 215 66 -32 stone
execute in minecraft:overworld run fill 215 67 -32 215 68 -32 dirt
execute in minecraft:overworld run setblock 215 69 -32 coarse_dirt
execute in minecraft:overworld run fill 215 70 -32 215 144 -32 air
execute in minecraft:overworld run fill 215 58 -31 215 65 -31 stone
execute in minecraft:overworld run fill 215 66 -31 215 67 -31 dirt
execute in minecraft:overworld run setblock 215 68 -31 coarse_dirt
execute in minecraft:overworld run fill 215 69 -31 215 144 -31 air
execute in minecraft:overworld run fill 215 58 -30 215 65 -30 stone
execute in minecraft:overworld run fill 215 66 -30 215 67 -30 dirt
execute in minecraft:overworld run setblock 215 68 -30 coarse_dirt
execute in minecraft:overworld run fill 215 69 -30 215 144 -30 air
execute in minecraft:overworld run fill 215 58 -29 215 65 -29 stone
execute in minecraft:overworld run fill 215 66 -29 215 67 -29 dirt
execute in minecraft:overworld run setblock 215 68 -29 grass_block
execute in minecraft:overworld run fill 215 69 -29 215 144 -29 air
execute in minecraft:overworld run fill 215 58 -28 215 64 -28 stone
execute in minecraft:overworld run fill 215 65 -28 215 66 -28 dirt
execute in minecraft:overworld run setblock 215 67 -28 coarse_dirt
execute in minecraft:overworld run fill 215 68 -28 215 144 -28 air
execute in minecraft:overworld run fill 215 58 -27 215 64 -27 stone
execute in minecraft:overworld run fill 215 65 -27 215 66 -27 dirt
execute in minecraft:overworld run setblock 215 67 -27 coarse_dirt
execute in minecraft:overworld run fill 215 68 -27 215 144 -27 air
execute in minecraft:overworld run fill 215 58 -26 215 64 -26 stone
execute in minecraft:overworld run fill 215 65 -26 215 66 -26 dirt
execute in minecraft:overworld run setblock 215 67 -26 coarse_dirt
execute in minecraft:overworld run fill 215 68 -26 215 144 -26 air
execute in minecraft:overworld run fill 215 58 -25 215 64 -25 stone
execute in minecraft:overworld run fill 215 65 -25 215 66 -25 dirt
execute in minecraft:overworld run setblock 215 67 -25 grass_block
execute in minecraft:overworld run fill 215 68 -25 215 144 -25 air
execute in minecraft:overworld run setblock 215 68 -25 grass
execute in minecraft:overworld run fill 215 58 -24 215 64 -24 stone
execute in minecraft:overworld run fill 215 65 -24 215 66 -24 dirt
execute in minecraft:overworld run setblock 215 67 -24 coarse_dirt
execute in minecraft:overworld run fill 215 68 -24 215 144 -24 air
execute in minecraft:overworld run fill 215 58 -23 215 64 -23 stone
execute in minecraft:overworld run fill 215 65 -23 215 66 -23 dirt
execute in minecraft:overworld run setblock 215 67 -23 coarse_dirt
execute in minecraft:overworld run fill 215 68 -23 215 144 -23 air
execute in minecraft:overworld run fill 215 58 -22 215 64 -22 stone
execute in minecraft:overworld run fill 215 65 -22 215 66 -22 dirt
execute in minecraft:overworld run setblock 215 67 -22 coarse_dirt
execute in minecraft:overworld run fill 215 68 -22 215 144 -22 air
execute in minecraft:overworld run fill 215 58 -21 215 65 -21 stone
execute in minecraft:overworld run fill 215 66 -21 215 67 -21 dirt
execute in minecraft:overworld run setblock 215 68 -21 grass_block
execute in minecraft:overworld run fill 215 69 -21 215 144 -21 air
execute in minecraft:overworld run fill 215 58 -20 215 65 -20 stone
execute in minecraft:overworld run fill 215 66 -20 215 67 -20 dirt
execute in minecraft:overworld run setblock 215 68 -20 coarse_dirt
execute in minecraft:overworld run fill 215 69 -20 215 144 -20 air
execute in minecraft:overworld run fill 215 58 -19 215 65 -19 stone
execute in minecraft:overworld run fill 215 66 -19 215 67 -19 dirt
execute in minecraft:overworld run setblock 215 68 -19 coarse_dirt
execute in minecraft:overworld run fill 215 69 -19 215 144 -19 air
execute in minecraft:overworld run fill 215 58 -18 215 65 -18 stone
execute in minecraft:overworld run fill 215 66 -18 215 67 -18 dirt
execute in minecraft:overworld run setblock 215 68 -18 grass_block
execute in minecraft:overworld run fill 215 69 -18 215 144 -18 air
execute in minecraft:overworld run fill 215 58 -17 215 65 -17 stone
schedule function blade_gallery:random/burned/part_11 1t replace
