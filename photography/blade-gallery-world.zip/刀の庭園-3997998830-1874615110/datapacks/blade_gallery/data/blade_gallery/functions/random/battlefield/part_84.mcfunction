execute in minecraft:overworld run setblock 390 76 -34 coarse_dirt
execute in minecraft:overworld run fill 390 77 -34 390 144 -34 air
execute in minecraft:overworld run fill 390 58 -33 390 72 -33 stone
execute in minecraft:overworld run fill 390 73 -33 390 74 -33 dirt
execute in minecraft:overworld run setblock 390 75 -33 coarse_dirt
execute in minecraft:overworld run fill 390 76 -33 390 144 -33 air
execute in minecraft:overworld run fill 390 58 -32 390 72 -32 stone
execute in minecraft:overworld run fill 390 73 -32 390 74 -32 dirt
execute in minecraft:overworld run setblock 390 75 -32 grass_block
execute in minecraft:overworld run fill 390 76 -32 390 144 -32 air
execute in minecraft:overworld run fill 390 58 -31 390 72 -31 stone
execute in minecraft:overworld run fill 390 73 -31 390 74 -31 dirt
execute in minecraft:overworld run setblock 390 75 -31 grass_block
execute in minecraft:overworld run fill 390 76 -31 390 144 -31 air
execute in minecraft:overworld run fill 390 58 -30 390 71 -30 stone
execute in minecraft:overworld run fill 390 72 -30 390 73 -30 dirt
execute in minecraft:overworld run setblock 390 74 -30 grass_block
execute in minecraft:overworld run fill 390 75 -30 390 144 -30 air
execute in minecraft:overworld run fill 390 58 -29 390 71 -29 stone
execute in minecraft:overworld run fill 390 72 -29 390 73 -29 dirt
execute in minecraft:overworld run setblock 390 74 -29 coarse_dirt
execute in minecraft:overworld run fill 390 75 -29 390 144 -29 air
execute in minecraft:overworld run fill 390 58 -28 390 70 -28 stone
execute in minecraft:overworld run fill 390 71 -28 390 72 -28 dirt
execute in minecraft:overworld run setblock 390 73 -28 coarse_dirt
execute in minecraft:overworld run fill 390 74 -28 390 144 -28 air
execute in minecraft:overworld run fill 390 58 -27 390 69 -27 stone
execute in minecraft:overworld run fill 390 70 -27 390 71 -27 dirt
execute in minecraft:overworld run setblock 390 72 -27 grass_block
execute in minecraft:overworld run fill 390 73 -27 390 144 -27 air
execute in minecraft:overworld run fill 390 58 -26 390 69 -26 stone
execute in minecraft:overworld run fill 390 70 -26 390 71 -26 dirt
execute in minecraft:overworld run setblock 390 72 -26 grass_block
execute in minecraft:overworld run fill 390 73 -26 390 144 -26 air
execute in minecraft:overworld run fill 390 58 -25 390 68 -25 stone
execute in minecraft:overworld run fill 390 69 -25 390 70 -25 dirt
execute in minecraft:overworld run setblock 390 71 -25 grass_block
execute in minecraft:overworld run fill 390 72 -25 390 144 -25 air
execute in minecraft:overworld run fill 390 58 -24 390 67 -24 stone
execute in minecraft:overworld run fill 390 68 -24 390 69 -24 dirt
execute in minecraft:overworld run setblock 390 70 -24 coarse_dirt
execute in minecraft:overworld run fill 390 71 -24 390 144 -24 air
execute in minecraft:overworld run fill 390 58 -23 390 66 -23 stone
execute in minecraft:overworld run fill 390 67 -23 390 68 -23 dirt
execute in minecraft:overworld run setblock 390 69 -23 coarse_dirt
execute in minecraft:overworld run fill 390 70 -23 390 144 -23 air
execute in minecraft:overworld run fill 390 58 -22 390 64 -22 stone
execute in minecraft:overworld run fill 390 65 -22 390 66 -22 dirt
execute in minecraft:overworld run setblock 390 67 -22 coarse_dirt
execute in minecraft:overworld run fill 390 68 -22 390 144 -22 air
execute in minecraft:overworld run setblock 390 68 -22 grass
execute in minecraft:overworld run fill 390 58 -21 390 63 -21 stone
execute in minecraft:overworld run fill 390 64 -21 390 65 -21 dirt
execute in minecraft:overworld run setblock 390 66 -21 grass_block
execute in minecraft:overworld run fill 390 67 -21 390 144 -21 air
execute in minecraft:overworld run fill 390 58 -20 390 62 -20 stone
execute in minecraft:overworld run fill 390 63 -20 390 64 -20 dirt
execute in minecraft:overworld run setblock 390 65 -20 grass_block
execute in minecraft:overworld run fill 390 66 -20 390 144 -20 air
execute in minecraft:overworld run fill 390 58 -19 390 61 -19 stone
execute in minecraft:overworld run fill 390 62 -19 390 63 -19 dirt
execute in minecraft:overworld run setblock 390 64 -19 coarse_dirt
execute in minecraft:overworld run fill 390 65 -19 390 144 -19 air
execute in minecraft:overworld run fill 390 58 -18 390 60 -18 stone
execute in minecraft:overworld run fill 390 61 -18 390 62 -18 dirt
execute in minecraft:overworld run setblock 390 63 -18 gravel
execute in minecraft:overworld run fill 390 64 -18 390 144 -18 air
execute in minecraft:overworld run fill 390 64 -18 390 64 -18 water
execute in minecraft:overworld run fill 390 58 -17 390 59 -17 stone
execute in minecraft:overworld run fill 390 60 -17 390 61 -17 dirt
execute in minecraft:overworld run setblock 390 62 -17 gravel
execute in minecraft:overworld run fill 390 63 -17 390 144 -17 air
execute in minecraft:overworld run fill 390 63 -17 390 64 -17 water
execute in minecraft:overworld run fill 390 58 -16 390 58 -16 stone
execute in minecraft:overworld run fill 390 59 -16 390 60 -16 dirt
execute in minecraft:overworld run setblock 390 61 -16 gravel
execute in minecraft:overworld run fill 390 62 -16 390 144 -16 air
execute in minecraft:overworld run fill 390 62 -16 390 64 -16 water
execute in minecraft:overworld run fill 390 58 -15 390 58 -15 stone
execute in minecraft:overworld run fill 390 59 -15 390 60 -15 dirt
execute in minecraft:overworld run setblock 390 61 -15 gravel
execute in minecraft:overworld run fill 390 62 -15 390 144 -15 air
execute in minecraft:overworld run fill 390 62 -15 390 64 -15 water
execute in minecraft:overworld run fill 390 58 -14 390 57 -14 stone
execute in minecraft:overworld run fill 390 58 -14 390 59 -14 dirt
execute in minecraft:overworld run setblock 390 60 -14 gravel
execute in minecraft:overworld run fill 390 61 -14 390 144 -14 air
execute in minecraft:overworld run fill 390 61 -14 390 64 -14 water
execute in minecraft:overworld run fill 390 58 -13 390 56 -13 stone
execute in minecraft:overworld run fill 390 57 -13 390 58 -13 dirt
execute in minecraft:overworld run setblock 390 59 -13 gravel
execute in minecraft:overworld run fill 390 60 -13 390 144 -13 air
execute in minecraft:overworld run fill 390 60 -13 390 64 -13 water
execute in minecraft:overworld run fill 390 58 -12 390 55 -12 stone
execute in minecraft:overworld run fill 390 56 -12 390 57 -12 dirt
execute in minecraft:overworld run setblock 390 58 -12 gravel
execute in minecraft:overworld run fill 390 59 -12 390 144 -12 air
execute in minecraft:overworld run fill 390 59 -12 390 64 -12 water
execute in minecraft:overworld run fill 390 58 -11 390 55 -11 stone
execute in minecraft:overworld run fill 390 56 -11 390 57 -11 dirt
execute in minecraft:overworld run setblock 390 58 -11 gravel
execute in minecraft:overworld run fill 390 59 -11 390 144 -11 air
execute in minecraft:overworld run fill 390 59 -11 390 64 -11 water
execute in minecraft:overworld run fill 390 58 -10 390 55 -10 stone
execute in minecraft:overworld run fill 390 56 -10 390 57 -10 dirt
execute in minecraft:overworld run setblock 390 58 -10 gravel
execute in minecraft:overworld run fill 390 59 -10 390 144 -10 air
execute in minecraft:overworld run fill 390 59 -10 390 64 -10 water
execute in minecraft:overworld run fill 390 58 -9 390 55 -9 stone
execute in minecraft:overworld run fill 390 56 -9 390 57 -9 dirt
execute in minecraft:overworld run setblock 390 58 -9 gravel
execute in minecraft:overworld run fill 390 59 -9 390 144 -9 air
execute in minecraft:overworld run fill 390 59 -9 390 64 -9 water
execute in minecraft:overworld run fill 390 58 -8 390 55 -8 stone
execute in minecraft:overworld run fill 390 56 -8 390 57 -8 dirt
execute in minecraft:overworld run setblock 390 58 -8 gravel
execute in minecraft:overworld run fill 390 59 -8 390 144 -8 air
execute in minecraft:overworld run fill 390 59 -8 390 64 -8 water
execute in minecraft:overworld run fill 390 58 -7 390 55 -7 stone
execute in minecraft:overworld run fill 390 56 -7 390 57 -7 dirt
execute in minecraft:overworld run setblock 390 58 -7 gravel
execute in minecraft:overworld run fill 390 59 -7 390 144 -7 air
execute in minecraft:overworld run fill 390 59 -7 390 64 -7 water
execute in minecraft:overworld run fill 390 58 -6 390 55 -6 stone
execute in minecraft:overworld run fill 390 56 -6 390 57 -6 dirt
execute in minecraft:overworld run setblock 390 58 -6 gravel
execute in minecraft:overworld run fill 390 59 -6 390 144 -6 air
execute in minecraft:overworld run fill 390 59 -6 390 64 -6 water
execute in minecraft:overworld run fill 390 58 -5 390 55 -5 stone
execute in minecraft:overworld run fill 390 56 -5 390 57 -5 dirt
execute in minecraft:overworld run setblock 390 58 -5 gravel
execute in minecraft:overworld run fill 390 59 -5 390 144 -5 air
execute in minecraft:overworld run fill 390 59 -5 390 64 -5 water
execute in minecraft:overworld run fill 390 58 -4 390 55 -4 stone
execute in minecraft:overworld run fill 390 56 -4 390 57 -4 dirt
execute in minecraft:overworld run setblock 390 58 -4 gravel
execute in minecraft:overworld run fill 390 59 -4 390 144 -4 air
execute in minecraft:overworld run fill 390 59 -4 390 64 -4 water
execute in minecraft:overworld run fill 390 58 -3 390 55 -3 stone
execute in minecraft:overworld run fill 390 56 -3 390 57 -3 dirt
execute in minecraft:overworld run setblock 390 58 -3 gravel
execute in minecraft:overworld run fill 390 59 -3 390 144 -3 air
execute in minecraft:overworld run fill 390 59 -3 390 64 -3 water
execute in minecraft:overworld run fill 390 58 -2 390 55 -2 stone
execute in minecraft:overworld run fill 390 56 -2 390 57 -2 dirt
execute in minecraft:overworld run setblock 390 58 -2 gravel
execute in minecraft:overworld run fill 390 59 -2 390 144 -2 air
execute in minecraft:overworld run fill 390 59 -2 390 64 -2 water
execute in minecraft:overworld run fill 390 58 -1 390 56 -1 stone
execute in minecraft:overworld run fill 390 57 -1 390 58 -1 dirt
execute in minecraft:overworld run setblock 390 59 -1 gravel
execute in minecraft:overworld run fill 390 60 -1 390 144 -1 air
execute in minecraft:overworld run fill 390 60 -1 390 64 -1 water
execute in minecraft:overworld run fill 390 58 0 390 56 0 stone
execute in minecraft:overworld run fill 390 57 0 390 58 0 dirt
execute in minecraft:overworld run setblock 390 59 0 gravel
execute in minecraft:overworld run fill 390 60 0 390 144 0 air
execute in minecraft:overworld run fill 390 60 0 390 64 0 water
execute in minecraft:overworld run fill 390 58 1 390 56 1 stone
execute in minecraft:overworld run fill 390 57 1 390 58 1 dirt
execute in minecraft:overworld run setblock 390 59 1 gravel
execute in minecraft:overworld run fill 390 60 1 390 144 1 air
execute in minecraft:overworld run fill 390 60 1 390 64 1 water
execute in minecraft:overworld run fill 390 58 2 390 56 2 stone
execute in minecraft:overworld run fill 390 57 2 390 58 2 dirt
execute in minecraft:overworld run setblock 390 59 2 gravel
execute in minecraft:overworld run fill 390 60 2 390 144 2 air
execute in minecraft:overworld run fill 390 60 2 390 64 2 water
execute in minecraft:overworld run fill 390 58 3 390 56 3 stone
execute in minecraft:overworld run fill 390 57 3 390 58 3 dirt
execute in minecraft:overworld run setblock 390 59 3 gravel
execute in minecraft:overworld run fill 390 60 3 390 144 3 air
execute in minecraft:overworld run fill 390 60 3 390 64 3 water
execute in minecraft:overworld run fill 390 58 4 390 57 4 stone
execute in minecraft:overworld run fill 390 58 4 390 59 4 dirt
execute in minecraft:overworld run setblock 390 60 4 gravel
execute in minecraft:overworld run fill 390 61 4 390 144 4 air
execute in minecraft:overworld run fill 390 61 4 390 64 4 water
execute in minecraft:overworld run fill 390 58 5 390 57 5 stone
execute in minecraft:overworld run fill 390 58 5 390 59 5 dirt
execute in minecraft:overworld run setblock 390 60 5 gravel
execute in minecraft:overworld run fill 390 61 5 390 144 5 air
execute in minecraft:overworld run fill 390 61 5 390 64 5 water
execute in minecraft:overworld run fill 390 58 6 390 57 6 stone
execute in minecraft:overworld run fill 390 58 6 390 59 6 dirt
execute in minecraft:overworld run setblock 390 60 6 gravel
execute in minecraft:overworld run fill 390 61 6 390 144 6 air
execute in minecraft:overworld run fill 390 61 6 390 64 6 water
execute in minecraft:overworld run fill 390 58 7 390 57 7 stone
execute in minecraft:overworld run fill 390 58 7 390 59 7 dirt
execute in minecraft:overworld run setblock 390 60 7 gravel
execute in minecraft:overworld run fill 390 61 7 390 144 7 air
execute in minecraft:overworld run fill 390 61 7 390 64 7 water
execute in minecraft:overworld run fill 390 58 8 390 57 8 stone
execute in minecraft:overworld run fill 390 58 8 390 59 8 dirt
execute in minecraft:overworld run setblock 390 60 8 gravel
execute in minecraft:overworld run fill 390 61 8 390 144 8 air
execute in minecraft:overworld run fill 390 61 8 390 64 8 water
execute in minecraft:overworld run fill 390 58 9 390 57 9 stone
execute in minecraft:overworld run fill 390 58 9 390 59 9 dirt
execute in minecraft:overworld run setblock 390 60 9 gravel
execute in minecraft:overworld run fill 390 61 9 390 144 9 air
execute in minecraft:overworld run fill 390 61 9 390 64 9 water
execute in minecraft:overworld run fill 390 58 10 390 58 10 stone
execute in minecraft:overworld run fill 390 59 10 390 60 10 dirt
execute in minecraft:overworld run setblock 390 61 10 gravel
execute in minecraft:overworld run fill 390 62 10 390 144 10 air
execute in minecraft:overworld run fill 390 62 10 390 64 10 water
execute in minecraft:overworld run fill 390 58 11 390 58 11 stone
execute in minecraft:overworld run fill 390 59 11 390 60 11 dirt
execute in minecraft:overworld run setblock 390 61 11 gravel
execute in minecraft:overworld run fill 390 62 11 390 144 11 air
execute in minecraft:overworld run fill 390 62 11 390 64 11 water
execute in minecraft:overworld run fill 390 58 12 390 58 12 stone
execute in minecraft:overworld run fill 390 59 12 390 60 12 dirt
execute in minecraft:overworld run setblock 390 61 12 gravel
execute in minecraft:overworld run fill 390 62 12 390 144 12 air
execute in minecraft:overworld run fill 390 62 12 390 64 12 water
execute in minecraft:overworld run fill 390 58 13 390 58 13 stone
execute in minecraft:overworld run fill 390 59 13 390 60 13 dirt
execute in minecraft:overworld run setblock 390 61 13 gravel
execute in minecraft:overworld run fill 390 62 13 390 144 13 air
execute in minecraft:overworld run fill 390 62 13 390 64 13 water
execute in minecraft:overworld run fill 390 58 14 390 59 14 stone
execute in minecraft:overworld run fill 390 60 14 390 61 14 dirt
execute in minecraft:overworld run setblock 390 62 14 gravel
execute in minecraft:overworld run fill 390 63 14 390 144 14 air
execute in minecraft:overworld run fill 390 63 14 390 64 14 water
execute in minecraft:overworld run fill 390 58 15 390 59 15 stone
execute in minecraft:overworld run fill 390 60 15 390 61 15 dirt
execute in minecraft:overworld run setblock 390 62 15 gravel
execute in minecraft:overworld run fill 390 63 15 390 144 15 air
execute in minecraft:overworld run fill 390 63 15 390 64 15 water
execute in minecraft:overworld run fill 390 58 16 390 59 16 stone
execute in minecraft:overworld run fill 390 60 16 390 61 16 dirt
execute in minecraft:overworld run setblock 390 62 16 gravel
execute in minecraft:overworld run fill 390 63 16 390 144 16 air
execute in minecraft:overworld run fill 390 63 16 390 64 16 water
execute in minecraft:overworld run fill 390 58 17 390 59 17 stone
execute in minecraft:overworld run fill 390 60 17 390 61 17 dirt
execute in minecraft:overworld run setblock 390 62 17 gravel
execute in minecraft:overworld run fill 390 63 17 390 144 17 air
execute in minecraft:overworld run fill 390 63 17 390 64 17 water
execute in minecraft:overworld run fill 390 58 18 390 59 18 stone
execute in minecraft:overworld run fill 390 60 18 390 61 18 dirt
execute in minecraft:overworld run setblock 390 62 18 gravel
execute in minecraft:overworld run fill 390 63 18 390 144 18 air
execute in minecraft:overworld run fill 390 63 18 390 64 18 water
execute in minecraft:overworld run fill 390 58 19 390 59 19 stone
execute in minecraft:overworld run fill 390 60 19 390 61 19 dirt
execute in minecraft:overworld run setblock 390 62 19 gravel
execute in minecraft:overworld run fill 390 63 19 390 144 19 air
execute in minecraft:overworld run fill 390 63 19 390 64 19 water
execute in minecraft:overworld run fill 390 58 20 390 59 20 stone
execute in minecraft:overworld run fill 390 60 20 390 61 20 dirt
execute in minecraft:overworld run setblock 390 62 20 gravel
schedule function blade_gallery:random/battlefield/part_85 1t replace
