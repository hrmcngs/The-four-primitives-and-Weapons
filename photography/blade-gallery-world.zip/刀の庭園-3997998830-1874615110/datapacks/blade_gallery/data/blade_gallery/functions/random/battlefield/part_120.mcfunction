execute in minecraft:overworld run fill 412 70 -22 412 71 -22 dirt
execute in minecraft:overworld run setblock 412 72 -22 grass_block
execute in minecraft:overworld run fill 412 73 -22 412 144 -22 air
execute in minecraft:overworld run fill 412 58 -21 412 69 -21 stone
execute in minecraft:overworld run fill 412 70 -21 412 71 -21 dirt
execute in minecraft:overworld run setblock 412 72 -21 coarse_dirt
execute in minecraft:overworld run fill 412 73 -21 412 144 -21 air
execute in minecraft:overworld run fill 412 58 -20 412 69 -20 stone
execute in minecraft:overworld run fill 412 70 -20 412 71 -20 dirt
execute in minecraft:overworld run setblock 412 72 -20 grass_block
execute in minecraft:overworld run fill 412 73 -20 412 144 -20 air
execute in minecraft:overworld run fill 412 58 -19 412 68 -19 stone
execute in minecraft:overworld run fill 412 69 -19 412 70 -19 dirt
execute in minecraft:overworld run setblock 412 71 -19 grass_block
execute in minecraft:overworld run fill 412 72 -19 412 144 -19 air
execute in minecraft:overworld run fill 412 58 -18 412 68 -18 stone
execute in minecraft:overworld run fill 412 69 -18 412 70 -18 dirt
execute in minecraft:overworld run setblock 412 71 -18 coarse_dirt
execute in minecraft:overworld run fill 412 72 -18 412 144 -18 air
execute in minecraft:overworld run fill 412 58 -17 412 67 -17 stone
execute in minecraft:overworld run fill 412 68 -17 412 69 -17 dirt
execute in minecraft:overworld run setblock 412 70 -17 grass_block
execute in minecraft:overworld run fill 412 71 -17 412 144 -17 air
execute in minecraft:overworld run fill 412 58 -16 412 67 -16 stone
execute in minecraft:overworld run fill 412 68 -16 412 69 -16 dirt
execute in minecraft:overworld run setblock 412 70 -16 coarse_dirt
execute in minecraft:overworld run fill 412 71 -16 412 144 -16 air
execute in minecraft:overworld run fill 412 58 -15 412 66 -15 stone
execute in minecraft:overworld run fill 412 67 -15 412 68 -15 dirt
execute in minecraft:overworld run setblock 412 69 -15 grass_block
execute in minecraft:overworld run fill 412 70 -15 412 144 -15 air
execute in minecraft:overworld run fill 412 58 -14 412 66 -14 stone
execute in minecraft:overworld run fill 412 67 -14 412 68 -14 dirt
execute in minecraft:overworld run setblock 412 69 -14 coarse_dirt
execute in minecraft:overworld run fill 412 70 -14 412 144 -14 air
execute in minecraft:overworld run fill 412 58 -13 412 65 -13 stone
execute in minecraft:overworld run fill 412 66 -13 412 67 -13 dirt
execute in minecraft:overworld run setblock 412 68 -13 coarse_dirt
execute in minecraft:overworld run fill 412 69 -13 412 144 -13 air
execute in minecraft:overworld run fill 412 58 -12 412 65 -12 stone
execute in minecraft:overworld run fill 412 66 -12 412 67 -12 dirt
execute in minecraft:overworld run setblock 412 68 -12 coarse_dirt
execute in minecraft:overworld run fill 412 69 -12 412 144 -12 air
execute in minecraft:overworld run setblock 412 69 -12 grass
execute in minecraft:overworld run fill 412 58 -11 412 65 -11 stone
execute in minecraft:overworld run fill 412 66 -11 412 67 -11 dirt
execute in minecraft:overworld run setblock 412 68 -11 grass_block
execute in minecraft:overworld run fill 412 69 -11 412 144 -11 air
execute in minecraft:overworld run fill 412 58 -10 412 64 -10 stone
execute in minecraft:overworld run fill 412 65 -10 412 66 -10 dirt
execute in minecraft:overworld run setblock 412 67 -10 coarse_dirt
execute in minecraft:overworld run fill 412 68 -10 412 144 -10 air
execute in minecraft:overworld run fill 412 58 -9 412 64 -9 stone
execute in minecraft:overworld run fill 412 65 -9 412 66 -9 dirt
execute in minecraft:overworld run setblock 412 67 -9 grass_block
execute in minecraft:overworld run fill 412 68 -9 412 144 -9 air
execute in minecraft:overworld run fill 412 58 -8 412 64 -8 stone
execute in minecraft:overworld run fill 412 65 -8 412 66 -8 dirt
execute in minecraft:overworld run setblock 412 67 -8 coarse_dirt
execute in minecraft:overworld run fill 412 68 -8 412 144 -8 air
execute in minecraft:overworld run fill 412 58 -7 412 64 -7 stone
execute in minecraft:overworld run fill 412 65 -7 412 66 -7 dirt
execute in minecraft:overworld run setblock 412 67 -7 coarse_dirt
execute in minecraft:overworld run fill 412 68 -7 412 144 -7 air
execute in minecraft:overworld run fill 412 58 -6 412 64 -6 stone
execute in minecraft:overworld run fill 412 65 -6 412 66 -6 dirt
execute in minecraft:overworld run setblock 412 67 -6 coarse_dirt
execute in minecraft:overworld run fill 412 68 -6 412 144 -6 air
execute in minecraft:overworld run fill 412 58 -5 412 64 -5 stone
execute in minecraft:overworld run fill 412 65 -5 412 66 -5 dirt
execute in minecraft:overworld run setblock 412 67 -5 grass_block
execute in minecraft:overworld run fill 412 68 -5 412 144 -5 air
execute in minecraft:overworld run fill 412 58 -4 412 63 -4 stone
execute in minecraft:overworld run fill 412 64 -4 412 65 -4 dirt
execute in minecraft:overworld run setblock 412 66 -4 coarse_dirt
execute in minecraft:overworld run fill 412 67 -4 412 144 -4 air
execute in minecraft:overworld run setblock 412 67 -4 grass
execute in minecraft:overworld run fill 412 58 -3 412 63 -3 stone
execute in minecraft:overworld run fill 412 64 -3 412 65 -3 dirt
execute in minecraft:overworld run setblock 412 66 -3 grass_block
execute in minecraft:overworld run fill 412 67 -3 412 144 -3 air
execute in minecraft:overworld run fill 412 58 -2 412 63 -2 stone
execute in minecraft:overworld run fill 412 64 -2 412 65 -2 dirt
execute in minecraft:overworld run setblock 412 66 -2 coarse_dirt
execute in minecraft:overworld run fill 412 67 -2 412 144 -2 air
execute in minecraft:overworld run fill 412 58 -1 412 63 -1 stone
execute in minecraft:overworld run fill 412 64 -1 412 65 -1 dirt
execute in minecraft:overworld run setblock 412 66 -1 coarse_dirt
execute in minecraft:overworld run fill 412 67 -1 412 144 -1 air
execute in minecraft:overworld run fill 412 58 0 412 63 0 stone
execute in minecraft:overworld run fill 412 64 0 412 65 0 dirt
execute in minecraft:overworld run setblock 412 66 0 grass_block
execute in minecraft:overworld run fill 412 67 0 412 144 0 air
execute in minecraft:overworld run fill 412 58 1 412 63 1 stone
execute in minecraft:overworld run fill 412 64 1 412 65 1 dirt
execute in minecraft:overworld run setblock 412 66 1 coarse_dirt
execute in minecraft:overworld run fill 412 67 1 412 144 1 air
execute in minecraft:overworld run fill 412 58 2 412 63 2 stone
execute in minecraft:overworld run fill 412 64 2 412 65 2 dirt
execute in minecraft:overworld run setblock 412 66 2 grass_block
execute in minecraft:overworld run fill 412 67 2 412 144 2 air
execute in minecraft:overworld run fill 412 58 3 412 63 3 stone
execute in minecraft:overworld run fill 412 64 3 412 65 3 dirt
execute in minecraft:overworld run setblock 412 66 3 grass_block
execute in minecraft:overworld run fill 412 67 3 412 144 3 air
execute in minecraft:overworld run fill 412 58 4 412 63 4 stone
execute in minecraft:overworld run fill 412 64 4 412 65 4 dirt
execute in minecraft:overworld run setblock 412 66 4 coarse_dirt
execute in minecraft:overworld run fill 412 67 4 412 144 4 air
execute in minecraft:overworld run fill 412 58 5 412 64 5 stone
execute in minecraft:overworld run fill 412 65 5 412 66 5 dirt
execute in minecraft:overworld run setblock 412 67 5 grass_block
execute in minecraft:overworld run fill 412 68 5 412 144 5 air
execute in minecraft:overworld run fill 412 58 6 412 64 6 stone
execute in minecraft:overworld run fill 412 65 6 412 66 6 dirt
execute in minecraft:overworld run setblock 412 67 6 coarse_dirt
execute in minecraft:overworld run fill 412 68 6 412 144 6 air
execute in minecraft:overworld run fill 412 58 7 412 64 7 stone
execute in minecraft:overworld run fill 412 65 7 412 66 7 dirt
execute in minecraft:overworld run setblock 412 67 7 coarse_dirt
execute in minecraft:overworld run fill 412 68 7 412 144 7 air
execute in minecraft:overworld run fill 412 58 8 412 64 8 stone
execute in minecraft:overworld run fill 412 65 8 412 66 8 dirt
execute in minecraft:overworld run setblock 412 67 8 coarse_dirt
execute in minecraft:overworld run fill 412 68 8 412 144 8 air
execute in minecraft:overworld run fill 412 58 9 412 65 9 stone
execute in minecraft:overworld run fill 412 66 9 412 67 9 dirt
execute in minecraft:overworld run setblock 412 68 9 coarse_dirt
execute in minecraft:overworld run fill 412 69 9 412 144 9 air
execute in minecraft:overworld run setblock 412 69 9 mossy_cobblestone
execute in minecraft:overworld run fill 412 58 10 412 65 10 stone
execute in minecraft:overworld run fill 412 66 10 412 67 10 dirt
execute in minecraft:overworld run setblock 412 68 10 grass_block
execute in minecraft:overworld run fill 412 69 10 412 144 10 air
execute in minecraft:overworld run setblock 412 69 10 mossy_cobblestone
execute in minecraft:overworld run fill 412 58 11 412 65 11 stone
execute in minecraft:overworld run fill 412 66 11 412 67 11 dirt
execute in minecraft:overworld run setblock 412 68 11 coarse_dirt
execute in minecraft:overworld run fill 412 69 11 412 144 11 air
execute in minecraft:overworld run setblock 412 69 11 grass
execute in minecraft:overworld run fill 412 58 12 412 66 12 stone
execute in minecraft:overworld run fill 412 67 12 412 68 12 dirt
execute in minecraft:overworld run setblock 412 69 12 coarse_dirt
execute in minecraft:overworld run fill 412 70 12 412 144 12 air
execute in minecraft:overworld run fill 412 58 13 412 66 13 stone
execute in minecraft:overworld run fill 412 67 13 412 68 13 dirt
execute in minecraft:overworld run setblock 412 69 13 coarse_dirt
execute in minecraft:overworld run fill 412 70 13 412 144 13 air
execute in minecraft:overworld run setblock 412 70 13 grass
execute in minecraft:overworld run fill 412 58 14 412 66 14 stone
execute in minecraft:overworld run fill 412 67 14 412 68 14 dirt
execute in minecraft:overworld run setblock 412 69 14 coarse_dirt
execute in minecraft:overworld run fill 412 70 14 412 144 14 air
execute in minecraft:overworld run fill 412 58 15 412 66 15 stone
execute in minecraft:overworld run fill 412 67 15 412 68 15 dirt
execute in minecraft:overworld run setblock 412 69 15 coarse_dirt
execute in minecraft:overworld run fill 412 70 15 412 144 15 air
execute in minecraft:overworld run fill 412 58 16 412 67 16 stone
execute in minecraft:overworld run fill 412 68 16 412 69 16 dirt
execute in minecraft:overworld run setblock 412 70 16 coarse_dirt
execute in minecraft:overworld run fill 412 71 16 412 144 16 air
execute in minecraft:overworld run fill 412 58 17 412 67 17 stone
execute in minecraft:overworld run fill 412 68 17 412 69 17 dirt
execute in minecraft:overworld run setblock 412 70 17 coarse_dirt
execute in minecraft:overworld run fill 412 71 17 412 144 17 air
execute in minecraft:overworld run fill 412 58 18 412 67 18 stone
execute in minecraft:overworld run fill 412 68 18 412 69 18 dirt
execute in minecraft:overworld run setblock 412 70 18 coarse_dirt
execute in minecraft:overworld run fill 412 71 18 412 144 18 air
execute in minecraft:overworld run fill 412 58 19 412 68 19 stone
execute in minecraft:overworld run fill 412 69 19 412 70 19 dirt
execute in minecraft:overworld run setblock 412 71 19 coarse_dirt
execute in minecraft:overworld run fill 412 72 19 412 144 19 air
execute in minecraft:overworld run fill 412 58 20 412 68 20 stone
execute in minecraft:overworld run fill 412 69 20 412 70 20 dirt
execute in minecraft:overworld run setblock 412 71 20 coarse_dirt
execute in minecraft:overworld run fill 412 72 20 412 144 20 air
execute in minecraft:overworld run fill 412 58 21 412 68 21 stone
execute in minecraft:overworld run fill 412 69 21 412 70 21 dirt
execute in minecraft:overworld run setblock 412 71 21 coarse_dirt
execute in minecraft:overworld run fill 412 72 21 412 144 21 air
execute in minecraft:overworld run fill 412 58 22 412 69 22 stone
execute in minecraft:overworld run fill 412 70 22 412 71 22 dirt
execute in minecraft:overworld run setblock 412 72 22 coarse_dirt
execute in minecraft:overworld run fill 412 73 22 412 144 22 air
execute in minecraft:overworld run fill 412 58 23 412 69 23 stone
execute in minecraft:overworld run fill 412 70 23 412 71 23 dirt
execute in minecraft:overworld run setblock 412 72 23 grass_block
execute in minecraft:overworld run fill 412 73 23 412 144 23 air
execute in minecraft:overworld run fill 412 58 24 412 70 24 stone
execute in minecraft:overworld run fill 412 71 24 412 72 24 dirt
execute in minecraft:overworld run setblock 412 73 24 grass_block
execute in minecraft:overworld run fill 412 74 24 412 144 24 air
execute in minecraft:overworld run fill 412 58 25 412 70 25 stone
execute in minecraft:overworld run fill 412 71 25 412 72 25 dirt
execute in minecraft:overworld run setblock 412 73 25 coarse_dirt
execute in minecraft:overworld run fill 412 74 25 412 144 25 air
execute in minecraft:overworld run fill 412 58 26 412 70 26 stone
execute in minecraft:overworld run fill 412 71 26 412 72 26 dirt
execute in minecraft:overworld run setblock 412 73 26 grass_block
execute in minecraft:overworld run fill 412 74 26 412 144 26 air
execute in minecraft:overworld run setblock 412 74 26 grass
execute in minecraft:overworld run fill 412 58 27 412 70 27 stone
execute in minecraft:overworld run fill 412 71 27 412 72 27 dirt
execute in minecraft:overworld run setblock 412 73 27 grass_block
execute in minecraft:overworld run fill 412 74 27 412 144 27 air
execute in minecraft:overworld run fill 412 58 28 412 70 28 stone
execute in minecraft:overworld run fill 412 71 28 412 72 28 dirt
execute in minecraft:overworld run setblock 412 73 28 grass_block
execute in minecraft:overworld run fill 412 74 28 412 144 28 air
execute in minecraft:overworld run fill 412 58 29 412 70 29 stone
execute in minecraft:overworld run fill 412 71 29 412 72 29 dirt
execute in minecraft:overworld run setblock 412 73 29 grass_block
execute in minecraft:overworld run fill 412 74 29 412 144 29 air
execute in minecraft:overworld run fill 412 58 30 412 70 30 stone
execute in minecraft:overworld run fill 412 71 30 412 72 30 dirt
execute in minecraft:overworld run setblock 412 73 30 grass_block
execute in minecraft:overworld run fill 412 74 30 412 144 30 air
execute in minecraft:overworld run fill 412 58 31 412 70 31 stone
execute in minecraft:overworld run fill 412 71 31 412 72 31 dirt
execute in minecraft:overworld run setblock 412 73 31 grass_block
execute in minecraft:overworld run fill 412 74 31 412 144 31 air
execute in minecraft:overworld run fill 412 58 32 412 70 32 stone
execute in minecraft:overworld run fill 412 71 32 412 72 32 dirt
execute in minecraft:overworld run setblock 412 73 32 grass_block
execute in minecraft:overworld run fill 412 74 32 412 144 32 air
execute in minecraft:overworld run setblock 412 74 32 grass
execute in minecraft:overworld run fill 412 58 33 412 69 33 stone
execute in minecraft:overworld run fill 412 70 33 412 71 33 dirt
execute in minecraft:overworld run setblock 412 72 33 grass_block
execute in minecraft:overworld run fill 412 73 33 412 144 33 air
execute in minecraft:overworld run fill 412 58 34 412 69 34 stone
execute in minecraft:overworld run fill 412 70 34 412 71 34 dirt
execute in minecraft:overworld run setblock 412 72 34 coarse_dirt
execute in minecraft:overworld run fill 412 73 34 412 144 34 air
execute in minecraft:overworld run fill 412 58 35 412 69 35 stone
execute in minecraft:overworld run fill 412 70 35 412 71 35 dirt
execute in minecraft:overworld run setblock 412 72 35 coarse_dirt
execute in minecraft:overworld run fill 412 73 35 412 144 35 air
execute in minecraft:overworld run fill 412 58 36 412 68 36 stone
execute in minecraft:overworld run fill 412 69 36 412 70 36 dirt
execute in minecraft:overworld run setblock 412 71 36 coarse_dirt
execute in minecraft:overworld run fill 412 72 36 412 144 36 air
execute in minecraft:overworld run fill 412 58 37 412 68 37 stone
execute in minecraft:overworld run fill 412 69 37 412 70 37 dirt
execute in minecraft:overworld run setblock 412 71 37 grass_block
execute in minecraft:overworld run fill 412 72 37 412 144 37 air
execute in minecraft:overworld run fill 412 58 38 412 68 38 stone
execute in minecraft:overworld run fill 412 69 38 412 70 38 dirt
execute in minecraft:overworld run setblock 412 71 38 grass_block
execute in minecraft:overworld run fill 412 72 38 412 144 38 air
execute in minecraft:overworld run fill 412 58 39 412 67 39 stone
execute in minecraft:overworld run fill 412 68 39 412 69 39 dirt
execute in minecraft:overworld run setblock 412 70 39 coarse_dirt
execute in minecraft:overworld run fill 412 71 39 412 144 39 air
execute in minecraft:overworld run setblock 412 71 39 mossy_cobblestone
schedule function blade_gallery:random/battlefield/part_121 1t replace
