execute in minecraft:overworld run fill 217 58 39 217 67 39 stone
execute in minecraft:overworld run fill 217 68 39 217 69 39 dirt
execute in minecraft:overworld run setblock 217 70 39 coarse_dirt
execute in minecraft:overworld run fill 217 71 39 217 144 39 air
execute in minecraft:overworld run fill 217 58 40 217 66 40 stone
execute in minecraft:overworld run fill 217 67 40 217 68 40 dirt
execute in minecraft:overworld run setblock 217 69 40 coarse_dirt
execute in minecraft:overworld run fill 217 70 40 217 144 40 air
execute in minecraft:overworld run fill 217 58 41 217 65 41 stone
execute in minecraft:overworld run fill 217 66 41 217 67 41 dirt
execute in minecraft:overworld run setblock 217 68 41 coarse_dirt
execute in minecraft:overworld run fill 217 69 41 217 144 41 air
execute in minecraft:overworld run setblock 217 69 41 grass
execute in minecraft:overworld run fill 217 58 42 217 64 42 stone
execute in minecraft:overworld run fill 217 65 42 217 66 42 dirt
execute in minecraft:overworld run setblock 217 67 42 coarse_dirt
execute in minecraft:overworld run fill 217 68 42 217 144 42 air
execute in minecraft:overworld run fill 217 58 43 217 64 43 stone
execute in minecraft:overworld run fill 217 65 43 217 66 43 dirt
execute in minecraft:overworld run setblock 217 67 43 grass_block
execute in minecraft:overworld run fill 217 68 43 217 144 43 air
execute in minecraft:overworld run fill 217 58 44 217 63 44 stone
execute in minecraft:overworld run fill 217 64 44 217 65 44 dirt
execute in minecraft:overworld run setblock 217 66 44 coarse_dirt
execute in minecraft:overworld run fill 217 67 44 217 144 44 air
execute in minecraft:overworld run fill 217 58 45 217 62 45 stone
execute in minecraft:overworld run fill 217 63 45 217 64 45 dirt
execute in minecraft:overworld run setblock 217 65 45 grass_block
execute in minecraft:overworld run fill 217 66 45 217 144 45 air
execute in minecraft:overworld run fill 217 58 46 217 62 46 stone
execute in minecraft:overworld run fill 217 63 46 217 64 46 dirt
execute in minecraft:overworld run setblock 217 65 46 coarse_dirt
execute in minecraft:overworld run fill 217 66 46 217 144 46 air
execute in minecraft:overworld run fill 217 58 47 217 61 47 stone
execute in minecraft:overworld run fill 217 62 47 217 63 47 dirt
execute in minecraft:overworld run setblock 217 64 47 coarse_dirt
execute in minecraft:overworld run fill 217 65 47 217 144 47 air
execute in minecraft:overworld run fill 218 58 -48 218 61 -48 stone
execute in minecraft:overworld run fill 218 62 -48 218 63 -48 dirt
execute in minecraft:overworld run setblock 218 64 -48 grass_block
execute in minecraft:overworld run fill 218 65 -48 218 144 -48 air
execute in minecraft:overworld run fill 218 58 -47 218 63 -47 stone
execute in minecraft:overworld run fill 218 64 -47 218 65 -47 dirt
execute in minecraft:overworld run setblock 218 66 -47 coarse_dirt
execute in minecraft:overworld run fill 218 67 -47 218 144 -47 air
execute in minecraft:overworld run fill 218 58 -46 218 64 -46 stone
execute in minecraft:overworld run fill 218 65 -46 218 66 -46 dirt
execute in minecraft:overworld run setblock 218 67 -46 grass_block
execute in minecraft:overworld run fill 218 68 -46 218 144 -46 air
execute in minecraft:overworld run fill 218 58 -45 218 66 -45 stone
execute in minecraft:overworld run fill 218 67 -45 218 68 -45 dirt
execute in minecraft:overworld run setblock 218 69 -45 coarse_dirt
execute in minecraft:overworld run fill 218 70 -45 218 144 -45 air
execute in minecraft:overworld run fill 218 58 -44 218 67 -44 stone
execute in minecraft:overworld run fill 218 68 -44 218 69 -44 dirt
execute in minecraft:overworld run setblock 218 70 -44 coarse_dirt
execute in minecraft:overworld run fill 218 71 -44 218 144 -44 air
execute in minecraft:overworld run fill 218 58 -43 218 68 -43 stone
execute in minecraft:overworld run fill 218 69 -43 218 70 -43 dirt
execute in minecraft:overworld run setblock 218 71 -43 coarse_dirt
execute in minecraft:overworld run fill 218 72 -43 218 144 -43 air
execute in minecraft:overworld run fill 218 58 -42 218 69 -42 stone
execute in minecraft:overworld run fill 218 70 -42 218 71 -42 dirt
execute in minecraft:overworld run setblock 218 72 -42 coarse_dirt
execute in minecraft:overworld run fill 218 73 -42 218 144 -42 air
execute in minecraft:overworld run fill 218 58 -41 218 70 -41 stone
execute in minecraft:overworld run fill 218 71 -41 218 72 -41 dirt
execute in minecraft:overworld run setblock 218 73 -41 grass_block
execute in minecraft:overworld run fill 218 74 -41 218 144 -41 air
execute in minecraft:overworld run fill 218 58 -40 218 71 -40 stone
execute in minecraft:overworld run fill 218 72 -40 218 73 -40 dirt
execute in minecraft:overworld run setblock 218 74 -40 grass_block
execute in minecraft:overworld run fill 218 75 -40 218 144 -40 air
execute in minecraft:overworld run setblock 218 75 -40 mossy_cobblestone
execute in minecraft:overworld run fill 218 58 -39 218 71 -39 stone
execute in minecraft:overworld run fill 218 72 -39 218 73 -39 dirt
execute in minecraft:overworld run setblock 218 74 -39 coarse_dirt
execute in minecraft:overworld run fill 218 75 -39 218 144 -39 air
execute in minecraft:overworld run fill 218 58 -38 218 72 -38 stone
execute in minecraft:overworld run fill 218 73 -38 218 74 -38 dirt
execute in minecraft:overworld run setblock 218 75 -38 coarse_dirt
execute in minecraft:overworld run fill 218 76 -38 218 144 -38 air
execute in minecraft:overworld run fill 218 58 -37 218 71 -37 stone
execute in minecraft:overworld run fill 218 72 -37 218 73 -37 dirt
execute in minecraft:overworld run setblock 218 74 -37 coarse_dirt
execute in minecraft:overworld run fill 218 75 -37 218 144 -37 air
execute in minecraft:overworld run fill 218 58 -36 218 70 -36 stone
execute in minecraft:overworld run fill 218 71 -36 218 72 -36 dirt
execute in minecraft:overworld run setblock 218 73 -36 grass_block
execute in minecraft:overworld run fill 218 74 -36 218 144 -36 air
execute in minecraft:overworld run setblock 218 74 -36 grass
execute in minecraft:overworld run fill 218 58 -35 218 69 -35 stone
execute in minecraft:overworld run fill 218 70 -35 218 71 -35 dirt
execute in minecraft:overworld run setblock 218 72 -35 grass_block
execute in minecraft:overworld run fill 218 73 -35 218 144 -35 air
execute in minecraft:overworld run fill 218 58 -34 218 69 -34 stone
execute in minecraft:overworld run fill 218 70 -34 218 71 -34 dirt
execute in minecraft:overworld run setblock 218 72 -34 grass_block
execute in minecraft:overworld run fill 218 73 -34 218 144 -34 air
execute in minecraft:overworld run setblock 218 73 -34 mossy_cobblestone
execute in minecraft:overworld run fill 218 58 -33 218 68 -33 stone
execute in minecraft:overworld run fill 218 69 -33 218 70 -33 dirt
execute in minecraft:overworld run setblock 218 71 -33 grass_block
execute in minecraft:overworld run fill 218 72 -33 218 144 -33 air
execute in minecraft:overworld run fill 218 58 -32 218 68 -32 stone
execute in minecraft:overworld run fill 218 69 -32 218 70 -32 dirt
execute in minecraft:overworld run setblock 218 71 -32 coarse_dirt
execute in minecraft:overworld run fill 218 72 -32 218 144 -32 air
execute in minecraft:overworld run setblock 218 72 -32 grass
execute in minecraft:overworld run fill 218 58 -31 218 67 -31 stone
execute in minecraft:overworld run fill 218 68 -31 218 69 -31 dirt
execute in minecraft:overworld run setblock 218 70 -31 coarse_dirt
execute in minecraft:overworld run fill 218 71 -31 218 144 -31 air
execute in minecraft:overworld run setblock 218 71 -31 grass
execute in minecraft:overworld run fill 218 58 -30 218 67 -30 stone
execute in minecraft:overworld run fill 218 68 -30 218 69 -30 dirt
execute in minecraft:overworld run setblock 218 70 -30 coarse_dirt
execute in minecraft:overworld run fill 218 71 -30 218 144 -30 air
execute in minecraft:overworld run fill 218 58 -29 218 66 -29 stone
execute in minecraft:overworld run fill 218 67 -29 218 68 -29 dirt
execute in minecraft:overworld run setblock 218 69 -29 coarse_dirt
execute in minecraft:overworld run fill 218 70 -29 218 144 -29 air
execute in minecraft:overworld run fill 218 58 -28 218 66 -28 stone
execute in minecraft:overworld run fill 218 67 -28 218 68 -28 dirt
execute in minecraft:overworld run setblock 218 69 -28 coarse_dirt
execute in minecraft:overworld run fill 218 70 -28 218 144 -28 air
execute in minecraft:overworld run fill 218 58 -27 218 65 -27 stone
execute in minecraft:overworld run fill 218 66 -27 218 67 -27 dirt
execute in minecraft:overworld run setblock 218 68 -27 grass_block
execute in minecraft:overworld run fill 218 69 -27 218 144 -27 air
execute in minecraft:overworld run fill 218 58 -26 218 65 -26 stone
execute in minecraft:overworld run fill 218 66 -26 218 67 -26 dirt
execute in minecraft:overworld run setblock 218 68 -26 coarse_dirt
execute in minecraft:overworld run fill 218 69 -26 218 144 -26 air
execute in minecraft:overworld run fill 218 58 -25 218 65 -25 stone
execute in minecraft:overworld run fill 218 66 -25 218 67 -25 dirt
execute in minecraft:overworld run setblock 218 68 -25 coarse_dirt
execute in minecraft:overworld run fill 218 69 -25 218 144 -25 air
execute in minecraft:overworld run setblock 218 69 -25 grass
execute in minecraft:overworld run fill 218 58 -24 218 65 -24 stone
execute in minecraft:overworld run fill 218 66 -24 218 67 -24 dirt
execute in minecraft:overworld run setblock 218 68 -24 coarse_dirt
execute in minecraft:overworld run fill 218 69 -24 218 144 -24 air
execute in minecraft:overworld run fill 218 58 -23 218 65 -23 stone
execute in minecraft:overworld run fill 218 66 -23 218 67 -23 dirt
execute in minecraft:overworld run setblock 218 68 -23 coarse_dirt
execute in minecraft:overworld run fill 218 69 -23 218 144 -23 air
execute in minecraft:overworld run fill 218 58 -22 218 66 -22 stone
execute in minecraft:overworld run fill 218 67 -22 218 68 -22 dirt
execute in minecraft:overworld run setblock 218 69 -22 coarse_dirt
execute in minecraft:overworld run fill 218 70 -22 218 144 -22 air
execute in minecraft:overworld run fill 218 58 -21 218 66 -21 stone
execute in minecraft:overworld run fill 218 67 -21 218 68 -21 dirt
execute in minecraft:overworld run setblock 218 69 -21 grass_block
execute in minecraft:overworld run fill 218 70 -21 218 144 -21 air
execute in minecraft:overworld run setblock 218 70 -21 grass
execute in minecraft:overworld run fill 218 58 -20 218 66 -20 stone
execute in minecraft:overworld run fill 218 67 -20 218 68 -20 dirt
execute in minecraft:overworld run setblock 218 69 -20 grass_block
execute in minecraft:overworld run fill 218 70 -20 218 144 -20 air
execute in minecraft:overworld run setblock 218 70 -20 grass
execute in minecraft:overworld run fill 218 58 -19 218 66 -19 stone
execute in minecraft:overworld run fill 218 67 -19 218 68 -19 dirt
execute in minecraft:overworld run setblock 218 69 -19 coarse_dirt
execute in minecraft:overworld run fill 218 70 -19 218 144 -19 air
execute in minecraft:overworld run setblock 218 70 -19 grass
execute in minecraft:overworld run fill 218 58 -18 218 66 -18 stone
execute in minecraft:overworld run fill 218 67 -18 218 68 -18 dirt
execute in minecraft:overworld run setblock 218 69 -18 coarse_dirt
execute in minecraft:overworld run fill 218 70 -18 218 144 -18 air
execute in minecraft:overworld run fill 218 58 -17 218 66 -17 stone
execute in minecraft:overworld run fill 218 67 -17 218 68 -17 dirt
execute in minecraft:overworld run setblock 218 69 -17 coarse_dirt
execute in minecraft:overworld run fill 218 70 -17 218 144 -17 air
execute in minecraft:overworld run setblock 218 70 -17 grass
execute in minecraft:overworld run fill 218 58 -16 218 66 -16 stone
execute in minecraft:overworld run fill 218 67 -16 218 68 -16 dirt
execute in minecraft:overworld run setblock 218 69 -16 coarse_dirt
execute in minecraft:overworld run fill 218 70 -16 218 144 -16 air
execute in minecraft:overworld run setblock 218 70 -16 grass
execute in minecraft:overworld run fill 218 58 -15 218 66 -15 stone
execute in minecraft:overworld run fill 218 67 -15 218 68 -15 dirt
execute in minecraft:overworld run setblock 218 69 -15 coarse_dirt
execute in minecraft:overworld run fill 218 70 -15 218 144 -15 air
execute in minecraft:overworld run fill 218 58 -14 218 66 -14 stone
execute in minecraft:overworld run fill 218 67 -14 218 68 -14 dirt
execute in minecraft:overworld run setblock 218 69 -14 grass_block
execute in minecraft:overworld run fill 218 70 -14 218 144 -14 air
execute in minecraft:overworld run fill 218 58 -13 218 66 -13 stone
execute in minecraft:overworld run fill 218 67 -13 218 68 -13 dirt
execute in minecraft:overworld run setblock 218 69 -13 coarse_dirt
execute in minecraft:overworld run fill 218 70 -13 218 144 -13 air
execute in minecraft:overworld run fill 218 58 -12 218 65 -12 stone
execute in minecraft:overworld run fill 218 66 -12 218 67 -12 dirt
execute in minecraft:overworld run setblock 218 68 -12 coarse_dirt
execute in minecraft:overworld run fill 218 69 -12 218 144 -12 air
execute in minecraft:overworld run fill 218 58 -11 218 66 -11 stone
execute in minecraft:overworld run fill 218 67 -11 218 68 -11 dirt
execute in minecraft:overworld run setblock 218 69 -11 coarse_dirt
execute in minecraft:overworld run fill 218 70 -11 218 144 -11 air
execute in minecraft:overworld run fill 218 58 -10 218 66 -10 stone
execute in minecraft:overworld run fill 218 67 -10 218 68 -10 dirt
execute in minecraft:overworld run setblock 218 69 -10 coarse_dirt
execute in minecraft:overworld run fill 218 70 -10 218 144 -10 air
execute in minecraft:overworld run fill 218 58 -9 218 66 -9 stone
execute in minecraft:overworld run fill 218 67 -9 218 68 -9 dirt
execute in minecraft:overworld run setblock 218 69 -9 coarse_dirt
execute in minecraft:overworld run fill 218 70 -9 218 144 -9 air
execute in minecraft:overworld run fill 218 58 -8 218 66 -8 stone
execute in minecraft:overworld run fill 218 67 -8 218 68 -8 dirt
execute in minecraft:overworld run setblock 218 69 -8 coarse_dirt
execute in minecraft:overworld run fill 218 70 -8 218 144 -8 air
execute in minecraft:overworld run fill 218 58 -7 218 67 -7 stone
execute in minecraft:overworld run fill 218 68 -7 218 69 -7 dirt
execute in minecraft:overworld run setblock 218 70 -7 grass_block
execute in minecraft:overworld run fill 218 71 -7 218 144 -7 air
execute in minecraft:overworld run setblock 218 71 -7 grass
execute in minecraft:overworld run fill 218 58 -6 218 67 -6 stone
execute in minecraft:overworld run fill 218 68 -6 218 69 -6 dirt
execute in minecraft:overworld run setblock 218 70 -6 coarse_dirt
execute in minecraft:overworld run fill 218 71 -6 218 144 -6 air
execute in minecraft:overworld run fill 218 58 -5 218 67 -5 stone
execute in minecraft:overworld run fill 218 68 -5 218 69 -5 dirt
execute in minecraft:overworld run setblock 218 70 -5 grass_block
execute in minecraft:overworld run fill 218 71 -5 218 144 -5 air
execute in minecraft:overworld run fill 218 58 -4 218 67 -4 stone
execute in minecraft:overworld run fill 218 68 -4 218 69 -4 dirt
execute in minecraft:overworld run setblock 218 70 -4 coarse_dirt
execute in minecraft:overworld run fill 218 71 -4 218 144 -4 air
execute in minecraft:overworld run fill 218 58 -3 218 67 -3 stone
execute in minecraft:overworld run fill 218 68 -3 218 69 -3 dirt
execute in minecraft:overworld run setblock 218 70 -3 coarse_dirt
execute in minecraft:overworld run fill 218 71 -3 218 144 -3 air
execute in minecraft:overworld run fill 218 58 -2 218 67 -2 stone
execute in minecraft:overworld run fill 218 68 -2 218 69 -2 dirt
execute in minecraft:overworld run setblock 218 70 -2 grass_block
execute in minecraft:overworld run fill 218 71 -2 218 144 -2 air
execute in minecraft:overworld run fill 218 58 -1 218 67 -1 stone
execute in minecraft:overworld run fill 218 68 -1 218 69 -1 dirt
execute in minecraft:overworld run setblock 218 70 -1 coarse_dirt
execute in minecraft:overworld run fill 218 71 -1 218 144 -1 air
execute in minecraft:overworld run fill 218 58 0 218 67 0 stone
execute in minecraft:overworld run fill 218 68 0 218 69 0 dirt
execute in minecraft:overworld run setblock 218 70 0 coarse_dirt
execute in minecraft:overworld run fill 218 71 0 218 144 0 air
execute in minecraft:overworld run fill 218 58 1 218 67 1 stone
execute in minecraft:overworld run fill 218 68 1 218 69 1 dirt
execute in minecraft:overworld run setblock 218 70 1 coarse_dirt
execute in minecraft:overworld run fill 218 71 1 218 144 1 air
execute in minecraft:overworld run setblock 218 71 1 grass
execute in minecraft:overworld run fill 218 58 2 218 67 2 stone
execute in minecraft:overworld run fill 218 68 2 218 69 2 dirt
execute in minecraft:overworld run setblock 218 70 2 coarse_dirt
execute in minecraft:overworld run fill 218 71 2 218 144 2 air
execute in minecraft:overworld run fill 218 58 3 218 67 3 stone
execute in minecraft:overworld run fill 218 68 3 218 69 3 dirt
schedule function blade_gallery:random/burned/part_16 1t replace
