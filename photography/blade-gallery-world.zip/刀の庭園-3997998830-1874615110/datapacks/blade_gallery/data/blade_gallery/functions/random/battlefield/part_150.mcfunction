execute in minecraft:overworld run fill 431 66 38 431 144 38 air
execute in minecraft:overworld run fill 431 58 39 431 62 39 stone
execute in minecraft:overworld run fill 431 63 39 431 64 39 dirt
execute in minecraft:overworld run setblock 431 65 39 grass_block
execute in minecraft:overworld run fill 431 66 39 431 144 39 air
execute in minecraft:overworld run fill 431 58 40 431 62 40 stone
execute in minecraft:overworld run fill 431 63 40 431 64 40 dirt
execute in minecraft:overworld run setblock 431 65 40 grass_block
execute in minecraft:overworld run fill 431 66 40 431 144 40 air
execute in minecraft:overworld run fill 431 58 41 431 62 41 stone
execute in minecraft:overworld run fill 431 63 41 431 64 41 dirt
execute in minecraft:overworld run setblock 431 65 41 coarse_dirt
execute in minecraft:overworld run fill 431 66 41 431 144 41 air
execute in minecraft:overworld run fill 431 58 42 431 61 42 stone
execute in minecraft:overworld run fill 431 62 42 431 63 42 dirt
execute in minecraft:overworld run setblock 431 64 42 grass_block
execute in minecraft:overworld run fill 431 65 42 431 144 42 air
execute in minecraft:overworld run fill 431 58 43 431 61 43 stone
execute in minecraft:overworld run fill 431 62 43 431 63 43 dirt
execute in minecraft:overworld run setblock 431 64 43 grass_block
execute in minecraft:overworld run fill 431 65 43 431 144 43 air
execute in minecraft:overworld run fill 431 58 44 431 61 44 stone
execute in minecraft:overworld run fill 431 62 44 431 63 44 dirt
execute in minecraft:overworld run setblock 431 64 44 coarse_dirt
execute in minecraft:overworld run fill 431 65 44 431 144 44 air
execute in minecraft:overworld run fill 431 58 45 431 61 45 stone
execute in minecraft:overworld run fill 431 62 45 431 63 45 dirt
execute in minecraft:overworld run setblock 431 64 45 coarse_dirt
execute in minecraft:overworld run fill 431 65 45 431 144 45 air
execute in minecraft:overworld run fill 431 58 46 431 61 46 stone
execute in minecraft:overworld run fill 431 62 46 431 63 46 dirt
execute in minecraft:overworld run setblock 431 64 46 grass_block
execute in minecraft:overworld run fill 431 65 46 431 144 46 air
execute in minecraft:overworld run fill 431 58 47 431 61 47 stone
execute in minecraft:overworld run fill 431 62 47 431 63 47 dirt
execute in minecraft:overworld run setblock 431 64 47 coarse_dirt
execute in minecraft:overworld run fill 431 65 47 431 144 47 air
execute in minecraft:overworld run setblock 414 75 30 mossy_cobblestone
execute in minecraft:overworld run setblock 362 69 -3 mossy_cobblestone
execute in minecraft:overworld run setblock 417 68 4 mossy_cobblestone
execute in minecraft:overworld run setblock 415 67 -2 mossy_cobblestone
execute in minecraft:overworld run setblock 377 72 17 mossy_cobblestone
execute in minecraft:overworld run setblock 382 67 -2 mossy_cobblestone
execute in minecraft:overworld run setblock 406 72 30 mossy_cobblestone
execute in minecraft:overworld run setblock 357 72 16 mossy_cobblestone
execute in minecraft:overworld run setblock 376 72 16 mossy_cobblestone
execute in minecraft:overworld run setblock 405 68 18 mossy_cobblestone
execute in minecraft:overworld run setblock 364 76 -25 mossy_cobblestone
execute in minecraft:overworld run setblock 354 70 1 mossy_cobblestone
execute in minecraft:overworld run setblock 346 80 -34 mossy_cobblestone
execute in minecraft:overworld run setblock 359 77 -28 mossy_cobblestone
execute in minecraft:overworld run setblock 412 69 -12 mossy_cobblestone
execute in minecraft:overworld run setblock 377 69 7 mossy_cobblestone
execute in minecraft:overworld run setblock 409 69 13 mossy_cobblestone
execute in minecraft:overworld run setblock 348 76 -25 mossy_cobblestone
execute in minecraft:overworld run setblock 370 70 -13 mossy_cobblestone
execute in minecraft:overworld run setblock 378 69 2 mossy_cobblestone
execute in minecraft:overworld run setblock 350 71 2 mossy_cobblestone
execute in minecraft:overworld run setblock 422 68 4 mossy_cobblestone
execute in minecraft:overworld run setblock 356 70 -2 mossy_cobblestone
execute in minecraft:overworld run setblock 370 72 30 mossy_cobblestone
execute in minecraft:overworld run setblock 409 66 -1 mossy_cobblestone
execute in minecraft:overworld run setblock 392 76 -31 mossy_cobblestone
execute in minecraft:overworld run setblock 356 73 -17 mossy_cobblestone
execute in minecraft:overworld run setblock 368 70 -9 mossy_cobblestone
execute in minecraft:overworld run setblock 369 76 -35 mossy_cobblestone
execute in minecraft:overworld run setblock 422 75 -27 mossy_cobblestone
execute in minecraft:overworld run setblock 383 66 -23 mossy_cobblestone
execute in minecraft:overworld run setblock 390 71 -24 mossy_cobblestone
execute in minecraft:overworld run setblock 364 70 4 mossy_cobblestone
execute in minecraft:overworld run setblock 365 69 1 mossy_cobblestone
execute in minecraft:overworld run setblock 410 69 13 mossy_cobblestone
execute in minecraft:overworld run setblock 407 73 -19 mossy_cobblestone
execute in minecraft:overworld run setblock 412 68 -10 mossy_cobblestone
execute in minecraft:overworld run setblock 365 73 30 mossy_cobblestone
execute in minecraft:overworld run setblock 406 78 -33 mossy_cobblestone
execute in minecraft:overworld run setblock 402 78 -32 mossy_cobblestone
execute in minecraft:overworld run setblock 401 67 -11 mossy_cobblestone
execute in minecraft:overworld run setblock 359 73 -16 mossy_cobblestone
execute in minecraft:overworld run setblock 377 69 -34 mossy_cobblestone
execute in minecraft:overworld run setblock 416 69 -10 mossy_cobblestone
execute in minecraft:overworld run setblock 411 67 0 mossy_cobblestone
execute in minecraft:overworld run setblock 376 69 -3 mossy_cobblestone
execute in minecraft:overworld run setblock 417 68 6 mossy_cobblestone
execute in minecraft:overworld run setblock 345 68 17 mossy_cobblestone
execute in minecraft:overworld run setblock 375 72 24 mossy_cobblestone
execute in minecraft:overworld run setblock 370 75 -34 mossy_cobblestone
execute in minecraft:overworld run setblock 370 72 -19 mossy_cobblestone
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 357.5 70.1 -8.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:35f,StabYaw:77f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 380.5 70.1 12.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:55f,StabYaw:196f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 376.5 71.1 -24.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:12f,StabYaw:41f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 382.5 68.1 3.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:11f,StabYaw:15f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 372.5 69.1 8.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:52f,StabYaw:86f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 374.5 71.1 16.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:24f,StabYaw:234f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 407.5 72.1 26.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:35f,StabYaw:141f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 354.5 76.1 -23.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:17f,StabYaw:32f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 415.5 73.1 -22.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:29f,StabYaw:225f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 375.5 70.1 -17.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:12f,StabYaw:111f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 413.5 71.1 17.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:16f,StabYaw:89f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 369.5 69.1 8.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:31f,StabYaw:45f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 408.5 69.1 -12.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:66f,StabYaw:265f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 415.5 71.1 14.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:28f,StabYaw:343f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 378.5 69.1 -23.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:55f,StabYaw:271f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 362.5 72.1 10.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:45f,StabYaw:175f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 389.5 68.1 -21.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:57f,StabYaw:142f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 401.5 74.1 -22.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:57f,StabYaw:15f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 409.5 69.1 -12.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:16f,StabYaw:17f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 407.5 68.1 13.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_katana",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:46f,StabYaw:125f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 406.5 68.1 17.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:49f,StabYaw:17f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 367.5 72.1 18.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:70f,StabYaw:113f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 404.5 74.1 -19.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:34f,StabYaw:275f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 385.5 66.1 8.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:22f,StabYaw:142f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 382.5 68.1 6.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:63f,StabYaw:88f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 411.5 67.1 0.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:65f,StabYaw:179f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 375.5 69.1 -6.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:54f,StabYaw:335f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 406.5 74.1 -19.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"minecraft:iron_sword",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:38f,StabYaw:134f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run summon the_four_primitives_and_weapons:stabbed_weapon 414.5 69.1 -11.5 {Tags:["blade_gallery.battlefield"],StabItem:{id:"the_four_primitives_and_weapons:iron_tyokuto",Count:1b,tag:{TsukaColor:8484469,TsubaColor:7501688,KashiraColor:7632245,HabakiColor:9079168}},StabTilt:62f,StabYaw:340f,StabScale:1f,DisappearOnPickup:1b}
execute in minecraft:overworld run forceload remove 336 -48 431 47
tellraw @a {"text":"撮影エリア battlefield の生成が完了しました","color":"green"}
data remove storage blade_gallery:state random_busy
execute if data storage blade_gallery:state random_all run function blade_gallery:random/flowers/start
# Next scene continues only during full generation.
