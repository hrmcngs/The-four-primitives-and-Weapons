execute in minecraft:overworld run fill 418 58 -36 418 75 -36 stone
execute in minecraft:overworld run fill 418 76 -36 418 77 -36 dirt
execute in minecraft:overworld run setblock 418 78 -36 grass_block
execute in minecraft:overworld run fill 418 79 -36 418 144 -36 air
execute in minecraft:overworld run fill 418 58 -35 418 74 -35 stone
execute in minecraft:overworld run fill 418 75 -35 418 76 -35 dirt
execute in minecraft:overworld run setblock 418 77 -35 grass_block
execute in minecraft:overworld run fill 418 78 -35 418 144 -35 air
execute in minecraft:overworld run fill 418 58 -34 418 74 -34 stone
execute in minecraft:overworld run fill 418 75 -34 418 76 -34 dirt
execute in minecraft:overworld run setblock 418 77 -34 coarse_dirt
execute in minecraft:overworld run fill 418 78 -34 418 144 -34 air
execute in minecraft:overworld run fill 418 58 -33 418 73 -33 stone
execute in minecraft:overworld run fill 418 74 -33 418 75 -33 dirt
execute in minecraft:overworld run setblock 418 76 -33 coarse_dirt
execute in minecraft:overworld run fill 418 77 -33 418 144 -33 air
execute in minecraft:overworld run fill 418 58 -32 418 73 -32 stone
execute in minecraft:overworld run fill 418 74 -32 418 75 -32 dirt
execute in minecraft:overworld run setblock 418 76 -32 coarse_dirt
execute in minecraft:overworld run fill 418 77 -32 418 144 -32 air
execute in minecraft:overworld run fill 418 58 -31 418 72 -31 stone
execute in minecraft:overworld run fill 418 73 -31 418 74 -31 dirt
execute in minecraft:overworld run setblock 418 75 -31 grass_block
execute in minecraft:overworld run fill 418 76 -31 418 144 -31 air
execute in minecraft:overworld run fill 418 58 -30 418 72 -30 stone
execute in minecraft:overworld run fill 418 73 -30 418 74 -30 dirt
execute in minecraft:overworld run setblock 418 75 -30 coarse_dirt
execute in minecraft:overworld run fill 418 76 -30 418 144 -30 air
execute in minecraft:overworld run fill 418 58 -29 418 71 -29 stone
execute in minecraft:overworld run fill 418 72 -29 418 73 -29 dirt
execute in minecraft:overworld run setblock 418 74 -29 coarse_dirt
execute in minecraft:overworld run fill 418 75 -29 418 144 -29 air
execute in minecraft:overworld run fill 418 58 -28 418 71 -28 stone
execute in minecraft:overworld run fill 418 72 -28 418 73 -28 dirt
execute in minecraft:overworld run setblock 418 74 -28 coarse_dirt
execute in minecraft:overworld run fill 418 75 -28 418 144 -28 air
execute in minecraft:overworld run fill 418 58 -27 418 71 -27 stone
execute in minecraft:overworld run fill 418 72 -27 418 73 -27 dirt
execute in minecraft:overworld run setblock 418 74 -27 coarse_dirt
execute in minecraft:overworld run fill 418 75 -27 418 144 -27 air
execute in minecraft:overworld run fill 418 58 -26 418 70 -26 stone
execute in minecraft:overworld run fill 418 71 -26 418 72 -26 dirt
execute in minecraft:overworld run setblock 418 73 -26 coarse_dirt
execute in minecraft:overworld run fill 418 74 -26 418 144 -26 air
execute in minecraft:overworld run fill 418 58 -25 418 70 -25 stone
execute in minecraft:overworld run fill 418 71 -25 418 72 -25 dirt
execute in minecraft:overworld run setblock 418 73 -25 grass_block
execute in minecraft:overworld run fill 418 74 -25 418 144 -25 air
execute in minecraft:overworld run fill 418 58 -24 418 70 -24 stone
execute in minecraft:overworld run fill 418 71 -24 418 72 -24 dirt
execute in minecraft:overworld run setblock 418 73 -24 coarse_dirt
execute in minecraft:overworld run fill 418 74 -24 418 144 -24 air
execute in minecraft:overworld run setblock 418 74 -24 grass
execute in minecraft:overworld run fill 418 58 -23 418 70 -23 stone
execute in minecraft:overworld run fill 418 71 -23 418 72 -23 dirt
execute in minecraft:overworld run setblock 418 73 -23 coarse_dirt
execute in minecraft:overworld run fill 418 74 -23 418 144 -23 air
execute in minecraft:overworld run fill 418 58 -22 418 69 -22 stone
execute in minecraft:overworld run fill 418 70 -22 418 71 -22 dirt
execute in minecraft:overworld run setblock 418 72 -22 grass_block
execute in minecraft:overworld run fill 418 73 -22 418 144 -22 air
execute in minecraft:overworld run fill 418 58 -21 418 69 -21 stone
execute in minecraft:overworld run fill 418 70 -21 418 71 -21 dirt
execute in minecraft:overworld run setblock 418 72 -21 grass_block
execute in minecraft:overworld run fill 418 73 -21 418 144 -21 air
execute in minecraft:overworld run fill 418 58 -20 418 69 -20 stone
execute in minecraft:overworld run fill 418 70 -20 418 71 -20 dirt
execute in minecraft:overworld run setblock 418 72 -20 grass_block
execute in minecraft:overworld run fill 418 73 -20 418 144 -20 air
execute in minecraft:overworld run fill 418 58 -19 418 68 -19 stone
execute in minecraft:overworld run fill 418 69 -19 418 70 -19 dirt
execute in minecraft:overworld run setblock 418 71 -19 coarse_dirt
execute in minecraft:overworld run fill 418 72 -19 418 144 -19 air
execute in minecraft:overworld run fill 418 58 -18 418 68 -18 stone
execute in minecraft:overworld run fill 418 69 -18 418 70 -18 dirt
execute in minecraft:overworld run setblock 418 71 -18 coarse_dirt
execute in minecraft:overworld run fill 418 72 -18 418 144 -18 air
execute in minecraft:overworld run fill 418 58 -17 418 67 -17 stone
execute in minecraft:overworld run fill 418 68 -17 418 69 -17 dirt
execute in minecraft:overworld run setblock 418 70 -17 grass_block
execute in minecraft:overworld run fill 418 71 -17 418 144 -17 air
execute in minecraft:overworld run fill 418 58 -16 418 67 -16 stone
execute in minecraft:overworld run fill 418 68 -16 418 69 -16 dirt
execute in minecraft:overworld run setblock 418 70 -16 coarse_dirt
execute in minecraft:overworld run fill 418 71 -16 418 144 -16 air
execute in minecraft:overworld run setblock 418 71 -16 grass
execute in minecraft:overworld run fill 418 58 -15 418 67 -15 stone
execute in minecraft:overworld run fill 418 68 -15 418 69 -15 dirt
execute in minecraft:overworld run setblock 418 70 -15 coarse_dirt
execute in minecraft:overworld run fill 418 71 -15 418 144 -15 air
execute in minecraft:overworld run fill 418 58 -14 418 66 -14 stone
execute in minecraft:overworld run fill 418 67 -14 418 68 -14 dirt
execute in minecraft:overworld run setblock 418 69 -14 grass_block
execute in minecraft:overworld run fill 418 70 -14 418 144 -14 air
execute in minecraft:overworld run fill 418 58 -13 418 66 -13 stone
execute in minecraft:overworld run fill 418 67 -13 418 68 -13 dirt
execute in minecraft:overworld run setblock 418 69 -13 coarse_dirt
execute in minecraft:overworld run fill 418 70 -13 418 144 -13 air
execute in minecraft:overworld run fill 418 58 -12 418 65 -12 stone
execute in minecraft:overworld run fill 418 66 -12 418 67 -12 dirt
execute in minecraft:overworld run setblock 418 68 -12 coarse_dirt
execute in minecraft:overworld run fill 418 69 -12 418 144 -12 air
execute in minecraft:overworld run fill 418 58 -11 418 65 -11 stone
execute in minecraft:overworld run fill 418 66 -11 418 67 -11 dirt
execute in minecraft:overworld run setblock 418 68 -11 grass_block
execute in minecraft:overworld run fill 418 69 -11 418 144 -11 air
execute in minecraft:overworld run fill 418 58 -10 418 65 -10 stone
execute in minecraft:overworld run fill 418 66 -10 418 67 -10 dirt
execute in minecraft:overworld run setblock 418 68 -10 coarse_dirt
execute in minecraft:overworld run fill 418 69 -10 418 144 -10 air
execute in minecraft:overworld run fill 418 58 -9 418 65 -9 stone
execute in minecraft:overworld run fill 418 66 -9 418 67 -9 dirt
execute in minecraft:overworld run setblock 418 68 -9 coarse_dirt
execute in minecraft:overworld run fill 418 69 -9 418 144 -9 air
execute in minecraft:overworld run fill 418 58 -8 418 65 -8 stone
execute in minecraft:overworld run fill 418 66 -8 418 67 -8 dirt
execute in minecraft:overworld run setblock 418 68 -8 coarse_dirt
execute in minecraft:overworld run fill 418 69 -8 418 144 -8 air
execute in minecraft:overworld run setblock 418 69 -8 grass
execute in minecraft:overworld run fill 418 58 -7 418 65 -7 stone
execute in minecraft:overworld run fill 418 66 -7 418 67 -7 dirt
execute in minecraft:overworld run setblock 418 68 -7 coarse_dirt
execute in minecraft:overworld run fill 418 69 -7 418 144 -7 air
execute in minecraft:overworld run fill 418 58 -6 418 64 -6 stone
execute in minecraft:overworld run fill 418 65 -6 418 66 -6 dirt
execute in minecraft:overworld run setblock 418 67 -6 coarse_dirt
execute in minecraft:overworld run fill 418 68 -6 418 144 -6 air
execute in minecraft:overworld run fill 418 58 -5 418 64 -5 stone
execute in minecraft:overworld run fill 418 65 -5 418 66 -5 dirt
execute in minecraft:overworld run setblock 418 67 -5 coarse_dirt
execute in minecraft:overworld run fill 418 68 -5 418 144 -5 air
execute in minecraft:overworld run setblock 418 68 -5 grass
execute in minecraft:overworld run fill 418 58 -4 418 64 -4 stone
execute in minecraft:overworld run fill 418 65 -4 418 66 -4 dirt
execute in minecraft:overworld run setblock 418 67 -4 coarse_dirt
execute in minecraft:overworld run fill 418 68 -4 418 144 -4 air
execute in minecraft:overworld run fill 418 58 -3 418 64 -3 stone
execute in minecraft:overworld run fill 418 65 -3 418 66 -3 dirt
execute in minecraft:overworld run setblock 418 67 -3 grass_block
execute in minecraft:overworld run fill 418 68 -3 418 144 -3 air
execute in minecraft:overworld run fill 418 58 -2 418 63 -2 stone
execute in minecraft:overworld run fill 418 64 -2 418 65 -2 dirt
execute in minecraft:overworld run setblock 418 66 -2 coarse_dirt
execute in minecraft:overworld run fill 418 67 -2 418 144 -2 air
execute in minecraft:overworld run fill 418 58 -1 418 63 -1 stone
execute in minecraft:overworld run fill 418 64 -1 418 65 -1 dirt
execute in minecraft:overworld run setblock 418 66 -1 grass_block
execute in minecraft:overworld run fill 418 67 -1 418 144 -1 air
execute in minecraft:overworld run fill 418 58 0 418 63 0 stone
execute in minecraft:overworld run fill 418 64 0 418 65 0 dirt
execute in minecraft:overworld run setblock 418 66 0 coarse_dirt
execute in minecraft:overworld run fill 418 67 0 418 144 0 air
execute in minecraft:overworld run setblock 418 67 0 grass
execute in minecraft:overworld run fill 418 58 1 418 63 1 stone
execute in minecraft:overworld run fill 418 64 1 418 65 1 dirt
execute in minecraft:overworld run setblock 418 66 1 coarse_dirt
execute in minecraft:overworld run fill 418 67 1 418 144 1 air
execute in minecraft:overworld run fill 418 58 2 418 63 2 stone
execute in minecraft:overworld run fill 418 64 2 418 65 2 dirt
execute in minecraft:overworld run setblock 418 66 2 coarse_dirt
execute in minecraft:overworld run fill 418 67 2 418 144 2 air
execute in minecraft:overworld run setblock 418 67 2 grass
execute in minecraft:overworld run fill 418 58 3 418 64 3 stone
execute in minecraft:overworld run fill 418 65 3 418 66 3 dirt
execute in minecraft:overworld run setblock 418 67 3 coarse_dirt
execute in minecraft:overworld run fill 418 68 3 418 144 3 air
execute in minecraft:overworld run setblock 418 68 3 grass
execute in minecraft:overworld run fill 418 58 4 418 64 4 stone
execute in minecraft:overworld run fill 418 65 4 418 66 4 dirt
execute in minecraft:overworld run setblock 418 67 4 grass_block
execute in minecraft:overworld run fill 418 68 4 418 144 4 air
execute in minecraft:overworld run fill 418 58 5 418 64 5 stone
execute in minecraft:overworld run fill 418 65 5 418 66 5 dirt
execute in minecraft:overworld run setblock 418 67 5 coarse_dirt
execute in minecraft:overworld run fill 418 68 5 418 144 5 air
execute in minecraft:overworld run fill 418 58 6 418 64 6 stone
execute in minecraft:overworld run fill 418 65 6 418 66 6 dirt
execute in minecraft:overworld run setblock 418 67 6 coarse_dirt
execute in minecraft:overworld run fill 418 68 6 418 144 6 air
execute in minecraft:overworld run fill 418 58 7 418 65 7 stone
execute in minecraft:overworld run fill 418 66 7 418 67 7 dirt
execute in minecraft:overworld run setblock 418 68 7 grass_block
execute in minecraft:overworld run fill 418 69 7 418 144 7 air
execute in minecraft:overworld run fill 418 58 8 418 65 8 stone
execute in minecraft:overworld run fill 418 66 8 418 67 8 dirt
execute in minecraft:overworld run setblock 418 68 8 coarse_dirt
execute in minecraft:overworld run fill 418 69 8 418 144 8 air
execute in minecraft:overworld run fill 418 58 9 418 65 9 stone
execute in minecraft:overworld run fill 418 66 9 418 67 9 dirt
execute in minecraft:overworld run setblock 418 68 9 coarse_dirt
execute in minecraft:overworld run fill 418 69 9 418 144 9 air
execute in minecraft:overworld run fill 418 58 10 418 66 10 stone
execute in minecraft:overworld run fill 418 67 10 418 68 10 dirt
execute in minecraft:overworld run setblock 418 69 10 coarse_dirt
execute in minecraft:overworld run fill 418 70 10 418 144 10 air
execute in minecraft:overworld run fill 418 58 11 418 66 11 stone
execute in minecraft:overworld run fill 418 67 11 418 68 11 dirt
execute in minecraft:overworld run setblock 418 69 11 grass_block
execute in minecraft:overworld run fill 418 70 11 418 144 11 air
execute in minecraft:overworld run fill 418 58 12 418 67 12 stone
execute in minecraft:overworld run fill 418 68 12 418 69 12 dirt
execute in minecraft:overworld run setblock 418 70 12 coarse_dirt
execute in minecraft:overworld run fill 418 71 12 418 144 12 air
execute in minecraft:overworld run fill 418 58 13 418 67 13 stone
execute in minecraft:overworld run fill 418 68 13 418 69 13 dirt
execute in minecraft:overworld run setblock 418 70 13 grass_block
execute in minecraft:overworld run fill 418 71 13 418 144 13 air
execute in minecraft:overworld run fill 418 58 14 418 67 14 stone
execute in minecraft:overworld run fill 418 68 14 418 69 14 dirt
execute in minecraft:overworld run setblock 418 70 14 coarse_dirt
execute in minecraft:overworld run fill 418 71 14 418 144 14 air
execute in minecraft:overworld run fill 418 58 15 418 68 15 stone
execute in minecraft:overworld run fill 418 69 15 418 70 15 dirt
execute in minecraft:overworld run setblock 418 71 15 coarse_dirt
execute in minecraft:overworld run fill 418 72 15 418 144 15 air
execute in minecraft:overworld run fill 418 58 16 418 68 16 stone
execute in minecraft:overworld run fill 418 69 16 418 70 16 dirt
execute in minecraft:overworld run setblock 418 71 16 coarse_dirt
execute in minecraft:overworld run fill 418 72 16 418 144 16 air
execute in minecraft:overworld run fill 418 58 17 418 68 17 stone
execute in minecraft:overworld run fill 418 69 17 418 70 17 dirt
execute in minecraft:overworld run setblock 418 71 17 grass_block
execute in minecraft:overworld run fill 418 72 17 418 144 17 air
execute in minecraft:overworld run fill 418 58 18 418 69 18 stone
execute in minecraft:overworld run fill 418 70 18 418 71 18 dirt
execute in minecraft:overworld run setblock 418 72 18 coarse_dirt
execute in minecraft:overworld run fill 418 73 18 418 144 18 air
execute in minecraft:overworld run fill 418 58 19 418 69 19 stone
execute in minecraft:overworld run fill 418 70 19 418 71 19 dirt
execute in minecraft:overworld run setblock 418 72 19 grass_block
execute in minecraft:overworld run fill 418 73 19 418 144 19 air
execute in minecraft:overworld run fill 418 58 20 418 69 20 stone
execute in minecraft:overworld run fill 418 70 20 418 71 20 dirt
execute in minecraft:overworld run setblock 418 72 20 coarse_dirt
execute in minecraft:overworld run fill 418 73 20 418 144 20 air
execute in minecraft:overworld run fill 418 58 21 418 70 21 stone
execute in minecraft:overworld run fill 418 71 21 418 72 21 dirt
execute in minecraft:overworld run setblock 418 73 21 coarse_dirt
execute in minecraft:overworld run fill 418 74 21 418 144 21 air
execute in minecraft:overworld run fill 418 58 22 418 70 22 stone
execute in minecraft:overworld run fill 418 71 22 418 72 22 dirt
execute in minecraft:overworld run setblock 418 73 22 coarse_dirt
execute in minecraft:overworld run fill 418 74 22 418 144 22 air
execute in minecraft:overworld run fill 418 58 23 418 71 23 stone
execute in minecraft:overworld run fill 418 72 23 418 73 23 dirt
execute in minecraft:overworld run setblock 418 74 23 coarse_dirt
execute in minecraft:overworld run fill 418 75 23 418 144 23 air
execute in minecraft:overworld run fill 418 58 24 418 71 24 stone
execute in minecraft:overworld run fill 418 72 24 418 73 24 dirt
execute in minecraft:overworld run setblock 418 74 24 grass_block
execute in minecraft:overworld run fill 418 75 24 418 144 24 air
execute in minecraft:overworld run fill 418 58 25 418 71 25 stone
execute in minecraft:overworld run fill 418 72 25 418 73 25 dirt
execute in minecraft:overworld run setblock 418 74 25 grass_block
execute in minecraft:overworld run fill 418 75 25 418 144 25 air
execute in minecraft:overworld run fill 418 58 26 418 71 26 stone
schedule function blade_gallery:random/battlefield/part_130 1t replace
