execute in minecraft:overworld run fill 290 72 -20 290 73 -20 dirt
execute in minecraft:overworld run setblock 290 74 -20 coarse_dirt
execute in minecraft:overworld run fill 290 75 -20 290 144 -20 air
execute in minecraft:overworld run fill 290 58 -19 290 71 -19 stone
execute in minecraft:overworld run fill 290 72 -19 290 73 -19 dirt
execute in minecraft:overworld run setblock 290 74 -19 grass_block
execute in minecraft:overworld run fill 290 75 -19 290 144 -19 air
execute in minecraft:overworld run fill 290 58 -18 290 71 -18 stone
execute in minecraft:overworld run fill 290 72 -18 290 73 -18 dirt
execute in minecraft:overworld run setblock 290 74 -18 coarse_dirt
execute in minecraft:overworld run fill 290 75 -18 290 144 -18 air
execute in minecraft:overworld run fill 290 58 -17 290 70 -17 stone
execute in minecraft:overworld run fill 290 71 -17 290 72 -17 dirt
execute in minecraft:overworld run setblock 290 73 -17 coarse_dirt
execute in minecraft:overworld run fill 290 74 -17 290 144 -17 air
execute in minecraft:overworld run fill 290 58 -16 290 70 -16 stone
execute in minecraft:overworld run fill 290 71 -16 290 72 -16 dirt
execute in minecraft:overworld run setblock 290 73 -16 coarse_dirt
execute in minecraft:overworld run fill 290 74 -16 290 144 -16 air
execute in minecraft:overworld run fill 290 58 -15 290 70 -15 stone
execute in minecraft:overworld run fill 290 71 -15 290 72 -15 dirt
execute in minecraft:overworld run setblock 290 73 -15 coarse_dirt
execute in minecraft:overworld run fill 290 74 -15 290 144 -15 air
execute in minecraft:overworld run fill 290 58 -14 290 70 -14 stone
execute in minecraft:overworld run fill 290 71 -14 290 72 -14 dirt
execute in minecraft:overworld run setblock 290 73 -14 coarse_dirt
execute in minecraft:overworld run fill 290 74 -14 290 144 -14 air
execute in minecraft:overworld run fill 290 58 -13 290 69 -13 stone
execute in minecraft:overworld run fill 290 70 -13 290 71 -13 dirt
execute in minecraft:overworld run setblock 290 72 -13 coarse_dirt
execute in minecraft:overworld run fill 290 73 -13 290 144 -13 air
execute in minecraft:overworld run fill 290 58 -12 290 69 -12 stone
execute in minecraft:overworld run fill 290 70 -12 290 71 -12 dirt
execute in minecraft:overworld run setblock 290 72 -12 coarse_dirt
execute in minecraft:overworld run fill 290 73 -12 290 144 -12 air
execute in minecraft:overworld run fill 290 58 -11 290 69 -11 stone
execute in minecraft:overworld run fill 290 70 -11 290 71 -11 dirt
execute in minecraft:overworld run setblock 290 72 -11 coarse_dirt
execute in minecraft:overworld run fill 290 73 -11 290 144 -11 air
execute in minecraft:overworld run fill 290 58 -10 290 69 -10 stone
execute in minecraft:overworld run fill 290 70 -10 290 71 -10 dirt
execute in minecraft:overworld run setblock 290 72 -10 coarse_dirt
execute in minecraft:overworld run fill 290 73 -10 290 144 -10 air
execute in minecraft:overworld run fill 290 58 -9 290 69 -9 stone
execute in minecraft:overworld run fill 290 70 -9 290 71 -9 dirt
execute in minecraft:overworld run setblock 290 72 -9 coarse_dirt
execute in minecraft:overworld run fill 290 73 -9 290 144 -9 air
execute in minecraft:overworld run setblock 290 73 -9 grass
execute in minecraft:overworld run fill 290 58 -8 290 69 -8 stone
execute in minecraft:overworld run fill 290 70 -8 290 71 -8 dirt
execute in minecraft:overworld run setblock 290 72 -8 grass_block
execute in minecraft:overworld run fill 290 73 -8 290 144 -8 air
execute in minecraft:overworld run fill 290 58 -7 290 69 -7 stone
execute in minecraft:overworld run fill 290 70 -7 290 71 -7 dirt
execute in minecraft:overworld run setblock 290 72 -7 grass_block
execute in minecraft:overworld run fill 290 73 -7 290 144 -7 air
execute in minecraft:overworld run fill 290 58 -6 290 69 -6 stone
execute in minecraft:overworld run fill 290 70 -6 290 71 -6 dirt
execute in minecraft:overworld run setblock 290 72 -6 coarse_dirt
execute in minecraft:overworld run fill 290 73 -6 290 144 -6 air
execute in minecraft:overworld run fill 290 58 -5 290 70 -5 stone
execute in minecraft:overworld run fill 290 71 -5 290 72 -5 dirt
execute in minecraft:overworld run setblock 290 73 -5 grass_block
execute in minecraft:overworld run fill 290 74 -5 290 144 -5 air
execute in minecraft:overworld run fill 290 58 -4 290 70 -4 stone
execute in minecraft:overworld run fill 290 71 -4 290 72 -4 dirt
execute in minecraft:overworld run setblock 290 73 -4 grass_block
execute in minecraft:overworld run fill 290 74 -4 290 144 -4 air
execute in minecraft:overworld run fill 290 58 -3 290 70 -3 stone
execute in minecraft:overworld run fill 290 71 -3 290 72 -3 dirt
execute in minecraft:overworld run setblock 290 73 -3 grass_block
execute in minecraft:overworld run fill 290 74 -3 290 144 -3 air
execute in minecraft:overworld run fill 290 58 -2 290 70 -2 stone
execute in minecraft:overworld run fill 290 71 -2 290 72 -2 dirt
execute in minecraft:overworld run setblock 290 73 -2 grass_block
execute in minecraft:overworld run fill 290 74 -2 290 144 -2 air
execute in minecraft:overworld run fill 290 58 -1 290 70 -1 stone
execute in minecraft:overworld run fill 290 71 -1 290 72 -1 dirt
execute in minecraft:overworld run setblock 290 73 -1 coarse_dirt
execute in minecraft:overworld run fill 290 74 -1 290 144 -1 air
execute in minecraft:overworld run fill 290 58 0 290 70 0 stone
execute in minecraft:overworld run fill 290 71 0 290 72 0 dirt
execute in minecraft:overworld run setblock 290 73 0 grass_block
execute in minecraft:overworld run fill 290 74 0 290 144 0 air
execute in minecraft:overworld run fill 290 58 1 290 70 1 stone
execute in minecraft:overworld run fill 290 71 1 290 72 1 dirt
execute in minecraft:overworld run setblock 290 73 1 grass_block
execute in minecraft:overworld run fill 290 74 1 290 144 1 air
execute in minecraft:overworld run fill 290 58 2 290 69 2 stone
execute in minecraft:overworld run fill 290 70 2 290 71 2 dirt
execute in minecraft:overworld run setblock 290 72 2 coarse_dirt
execute in minecraft:overworld run fill 290 73 2 290 144 2 air
execute in minecraft:overworld run setblock 290 73 2 mossy_cobblestone
execute in minecraft:overworld run fill 290 58 3 290 69 3 stone
execute in minecraft:overworld run fill 290 70 3 290 71 3 dirt
execute in minecraft:overworld run setblock 290 72 3 coarse_dirt
execute in minecraft:overworld run fill 290 73 3 290 144 3 air
execute in minecraft:overworld run fill 290 58 4 290 69 4 stone
execute in minecraft:overworld run fill 290 70 4 290 71 4 dirt
execute in minecraft:overworld run setblock 290 72 4 coarse_dirt
execute in minecraft:overworld run fill 290 73 4 290 144 4 air
execute in minecraft:overworld run fill 290 58 5 290 68 5 stone
execute in minecraft:overworld run fill 290 69 5 290 70 5 dirt
execute in minecraft:overworld run setblock 290 71 5 coarse_dirt
execute in minecraft:overworld run fill 290 72 5 290 144 5 air
execute in minecraft:overworld run fill 290 58 6 290 68 6 stone
execute in minecraft:overworld run fill 290 69 6 290 70 6 dirt
execute in minecraft:overworld run setblock 290 71 6 coarse_dirt
execute in minecraft:overworld run fill 290 72 6 290 144 6 air
execute in minecraft:overworld run fill 290 58 7 290 67 7 stone
execute in minecraft:overworld run fill 290 68 7 290 69 7 dirt
execute in minecraft:overworld run setblock 290 70 7 coarse_dirt
execute in minecraft:overworld run fill 290 71 7 290 144 7 air
execute in minecraft:overworld run setblock 290 71 7 grass
execute in minecraft:overworld run fill 290 58 8 290 67 8 stone
execute in minecraft:overworld run fill 290 68 8 290 69 8 dirt
execute in minecraft:overworld run setblock 290 70 8 coarse_dirt
execute in minecraft:overworld run fill 290 71 8 290 144 8 air
execute in minecraft:overworld run fill 290 58 9 290 66 9 stone
execute in minecraft:overworld run fill 290 67 9 290 68 9 dirt
execute in minecraft:overworld run setblock 290 69 9 coarse_dirt
execute in minecraft:overworld run fill 290 70 9 290 144 9 air
execute in minecraft:overworld run setblock 290 70 9 grass
execute in minecraft:overworld run fill 290 58 10 290 66 10 stone
execute in minecraft:overworld run fill 290 67 10 290 68 10 dirt
execute in minecraft:overworld run setblock 290 69 10 coarse_dirt
execute in minecraft:overworld run fill 290 70 10 290 144 10 air
execute in minecraft:overworld run fill 290 58 11 290 66 11 stone
execute in minecraft:overworld run fill 290 67 11 290 68 11 dirt
execute in minecraft:overworld run setblock 290 69 11 coarse_dirt
execute in minecraft:overworld run fill 290 70 11 290 144 11 air
execute in minecraft:overworld run fill 290 58 12 290 66 12 stone
execute in minecraft:overworld run fill 290 67 12 290 68 12 dirt
execute in minecraft:overworld run setblock 290 69 12 coarse_dirt
execute in minecraft:overworld run fill 290 70 12 290 144 12 air
execute in minecraft:overworld run setblock 290 70 12 grass
execute in minecraft:overworld run fill 290 58 13 290 66 13 stone
execute in minecraft:overworld run fill 290 67 13 290 68 13 dirt
execute in minecraft:overworld run setblock 290 69 13 coarse_dirt
execute in minecraft:overworld run fill 290 70 13 290 144 13 air
execute in minecraft:overworld run fill 290 58 14 290 66 14 stone
execute in minecraft:overworld run fill 290 67 14 290 68 14 dirt
execute in minecraft:overworld run setblock 290 69 14 coarse_dirt
execute in minecraft:overworld run fill 290 70 14 290 144 14 air
execute in minecraft:overworld run fill 290 58 15 290 66 15 stone
execute in minecraft:overworld run fill 290 67 15 290 68 15 dirt
execute in minecraft:overworld run setblock 290 69 15 grass_block
execute in minecraft:overworld run fill 290 70 15 290 144 15 air
execute in minecraft:overworld run fill 290 58 16 290 65 16 stone
execute in minecraft:overworld run fill 290 66 16 290 67 16 dirt
execute in minecraft:overworld run setblock 290 68 16 coarse_dirt
execute in minecraft:overworld run fill 290 69 16 290 144 16 air
execute in minecraft:overworld run fill 290 58 17 290 65 17 stone
execute in minecraft:overworld run fill 290 66 17 290 67 17 dirt
execute in minecraft:overworld run setblock 290 68 17 coarse_dirt
execute in minecraft:overworld run fill 290 69 17 290 144 17 air
execute in minecraft:overworld run fill 290 58 18 290 65 18 stone
execute in minecraft:overworld run fill 290 66 18 290 67 18 dirt
execute in minecraft:overworld run setblock 290 68 18 grass_block
execute in minecraft:overworld run fill 290 69 18 290 144 18 air
execute in minecraft:overworld run setblock 290 69 18 grass
execute in minecraft:overworld run fill 290 58 19 290 65 19 stone
execute in minecraft:overworld run fill 290 66 19 290 67 19 dirt
execute in minecraft:overworld run setblock 290 68 19 grass_block
execute in minecraft:overworld run fill 290 69 19 290 144 19 air
execute in minecraft:overworld run fill 290 58 20 290 65 20 stone
execute in minecraft:overworld run fill 290 66 20 290 67 20 dirt
execute in minecraft:overworld run setblock 290 68 20 coarse_dirt
execute in minecraft:overworld run fill 290 69 20 290 144 20 air
execute in minecraft:overworld run fill 290 58 21 290 65 21 stone
execute in minecraft:overworld run fill 290 66 21 290 67 21 dirt
execute in minecraft:overworld run setblock 290 68 21 grass_block
execute in minecraft:overworld run fill 290 69 21 290 144 21 air
execute in minecraft:overworld run fill 290 58 22 290 65 22 stone
execute in minecraft:overworld run fill 290 66 22 290 67 22 dirt
execute in minecraft:overworld run setblock 290 68 22 grass_block
execute in minecraft:overworld run fill 290 69 22 290 144 22 air
execute in minecraft:overworld run fill 290 58 23 290 65 23 stone
execute in minecraft:overworld run fill 290 66 23 290 67 23 dirt
execute in minecraft:overworld run setblock 290 68 23 grass_block
execute in minecraft:overworld run fill 290 69 23 290 144 23 air
execute in minecraft:overworld run fill 290 58 24 290 65 24 stone
execute in minecraft:overworld run fill 290 66 24 290 67 24 dirt
execute in minecraft:overworld run setblock 290 68 24 grass_block
execute in minecraft:overworld run fill 290 69 24 290 144 24 air
execute in minecraft:overworld run fill 290 58 25 290 65 25 stone
execute in minecraft:overworld run fill 290 66 25 290 67 25 dirt
execute in minecraft:overworld run setblock 290 68 25 coarse_dirt
execute in minecraft:overworld run fill 290 69 25 290 144 25 air
execute in minecraft:overworld run fill 290 58 26 290 65 26 stone
execute in minecraft:overworld run fill 290 66 26 290 67 26 dirt
execute in minecraft:overworld run setblock 290 68 26 coarse_dirt
execute in minecraft:overworld run fill 290 69 26 290 144 26 air
execute in minecraft:overworld run fill 290 58 27 290 65 27 stone
execute in minecraft:overworld run fill 290 66 27 290 67 27 dirt
execute in minecraft:overworld run setblock 290 68 27 coarse_dirt
execute in minecraft:overworld run fill 290 69 27 290 144 27 air
execute in minecraft:overworld run fill 290 58 28 290 65 28 stone
execute in minecraft:overworld run fill 290 66 28 290 67 28 dirt
execute in minecraft:overworld run setblock 290 68 28 grass_block
execute in minecraft:overworld run fill 290 69 28 290 144 28 air
execute in minecraft:overworld run fill 290 58 29 290 65 29 stone
execute in minecraft:overworld run fill 290 66 29 290 67 29 dirt
execute in minecraft:overworld run setblock 290 68 29 coarse_dirt
execute in minecraft:overworld run fill 290 69 29 290 144 29 air
execute in minecraft:overworld run setblock 290 69 29 grass
execute in minecraft:overworld run fill 290 58 30 290 65 30 stone
execute in minecraft:overworld run fill 290 66 30 290 67 30 dirt
execute in minecraft:overworld run setblock 290 68 30 grass_block
execute in minecraft:overworld run fill 290 69 30 290 144 30 air
execute in minecraft:overworld run fill 290 58 31 290 64 31 stone
execute in minecraft:overworld run fill 290 65 31 290 66 31 dirt
execute in minecraft:overworld run setblock 290 67 31 coarse_dirt
execute in minecraft:overworld run fill 290 68 31 290 144 31 air
execute in minecraft:overworld run fill 290 58 32 290 64 32 stone
execute in minecraft:overworld run fill 290 65 32 290 66 32 dirt
execute in minecraft:overworld run setblock 290 67 32 coarse_dirt
execute in minecraft:overworld run fill 290 68 32 290 144 32 air
execute in minecraft:overworld run fill 290 58 33 290 63 33 stone
execute in minecraft:overworld run fill 290 64 33 290 65 33 dirt
execute in minecraft:overworld run setblock 290 66 33 coarse_dirt
execute in minecraft:overworld run fill 290 67 33 290 144 33 air
execute in minecraft:overworld run fill 290 58 34 290 63 34 stone
execute in minecraft:overworld run fill 290 64 34 290 65 34 dirt
execute in minecraft:overworld run setblock 290 66 34 coarse_dirt
execute in minecraft:overworld run fill 290 67 34 290 144 34 air
execute in minecraft:overworld run fill 290 58 35 290 63 35 stone
execute in minecraft:overworld run fill 290 64 35 290 65 35 dirt
execute in minecraft:overworld run setblock 290 66 35 coarse_dirt
execute in minecraft:overworld run fill 290 67 35 290 144 35 air
execute in minecraft:overworld run fill 290 58 36 290 63 36 stone
execute in minecraft:overworld run fill 290 64 36 290 65 36 dirt
execute in minecraft:overworld run setblock 290 66 36 grass_block
execute in minecraft:overworld run fill 290 67 36 290 144 36 air
execute in minecraft:overworld run fill 290 58 37 290 63 37 stone
execute in minecraft:overworld run fill 290 64 37 290 65 37 dirt
execute in minecraft:overworld run setblock 290 66 37 grass_block
execute in minecraft:overworld run fill 290 67 37 290 144 37 air
execute in minecraft:overworld run setblock 290 67 37 grass
execute in minecraft:overworld run fill 290 58 38 290 63 38 stone
execute in minecraft:overworld run fill 290 64 38 290 65 38 dirt
execute in minecraft:overworld run setblock 290 66 38 grass_block
execute in minecraft:overworld run fill 290 67 38 290 144 38 air
execute in minecraft:overworld run fill 290 58 39 290 63 39 stone
execute in minecraft:overworld run fill 290 64 39 290 65 39 dirt
execute in minecraft:overworld run setblock 290 66 39 grass_block
execute in minecraft:overworld run fill 290 67 39 290 144 39 air
execute in minecraft:overworld run setblock 290 67 39 grass
execute in minecraft:overworld run fill 290 58 40 290 63 40 stone
execute in minecraft:overworld run fill 290 64 40 290 65 40 dirt
execute in minecraft:overworld run setblock 290 66 40 coarse_dirt
execute in minecraft:overworld run fill 290 67 40 290 144 40 air
execute in minecraft:overworld run fill 290 58 41 290 62 41 stone
execute in minecraft:overworld run fill 290 63 41 290 64 41 dirt
execute in minecraft:overworld run setblock 290 65 41 coarse_dirt
execute in minecraft:overworld run fill 290 66 41 290 144 41 air
schedule function blade_gallery:random/burned/part_131 1t replace
