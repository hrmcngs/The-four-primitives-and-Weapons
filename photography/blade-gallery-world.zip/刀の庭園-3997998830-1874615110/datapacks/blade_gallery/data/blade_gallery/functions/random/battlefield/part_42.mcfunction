execute in minecraft:overworld run setblock 363 68 -5 coarse_dirt
execute in minecraft:overworld run fill 363 69 -5 363 144 -5 air
execute in minecraft:overworld run fill 363 58 -4 363 65 -4 stone
execute in minecraft:overworld run fill 363 66 -4 363 67 -4 dirt
execute in minecraft:overworld run setblock 363 68 -4 grass_block
execute in minecraft:overworld run fill 363 69 -4 363 144 -4 air
execute in minecraft:overworld run fill 363 58 -3 363 65 -3 stone
execute in minecraft:overworld run fill 363 66 -3 363 67 -3 dirt
execute in minecraft:overworld run setblock 363 68 -3 coarse_dirt
execute in minecraft:overworld run fill 363 69 -3 363 144 -3 air
execute in minecraft:overworld run fill 363 58 -2 363 65 -2 stone
execute in minecraft:overworld run fill 363 66 -2 363 67 -2 dirt
execute in minecraft:overworld run setblock 363 68 -2 grass_block
execute in minecraft:overworld run fill 363 69 -2 363 144 -2 air
execute in minecraft:overworld run fill 363 58 -1 363 65 -1 stone
execute in minecraft:overworld run fill 363 66 -1 363 67 -1 dirt
execute in minecraft:overworld run setblock 363 68 -1 grass_block
execute in minecraft:overworld run fill 363 69 -1 363 144 -1 air
execute in minecraft:overworld run fill 363 58 0 363 65 0 stone
execute in minecraft:overworld run fill 363 66 0 363 67 0 dirt
execute in minecraft:overworld run setblock 363 68 0 coarse_dirt
execute in minecraft:overworld run fill 363 69 0 363 144 0 air
execute in minecraft:overworld run setblock 363 69 0 grass
execute in minecraft:overworld run fill 363 58 1 363 65 1 stone
execute in minecraft:overworld run fill 363 66 1 363 67 1 dirt
execute in minecraft:overworld run setblock 363 68 1 coarse_dirt
execute in minecraft:overworld run fill 363 69 1 363 144 1 air
execute in minecraft:overworld run fill 363 58 2 363 65 2 stone
execute in minecraft:overworld run fill 363 66 2 363 67 2 dirt
execute in minecraft:overworld run setblock 363 68 2 coarse_dirt
execute in minecraft:overworld run fill 363 69 2 363 144 2 air
execute in minecraft:overworld run setblock 363 69 2 grass
execute in minecraft:overworld run fill 363 58 3 363 66 3 stone
execute in minecraft:overworld run fill 363 67 3 363 68 3 dirt
execute in minecraft:overworld run setblock 363 69 3 coarse_dirt
execute in minecraft:overworld run fill 363 70 3 363 144 3 air
execute in minecraft:overworld run fill 363 58 4 363 66 4 stone
execute in minecraft:overworld run fill 363 67 4 363 68 4 dirt
execute in minecraft:overworld run setblock 363 69 4 grass_block
execute in minecraft:overworld run fill 363 70 4 363 144 4 air
execute in minecraft:overworld run fill 363 58 5 363 66 5 stone
execute in minecraft:overworld run fill 363 67 5 363 68 5 dirt
execute in minecraft:overworld run setblock 363 69 5 coarse_dirt
execute in minecraft:overworld run fill 363 70 5 363 144 5 air
execute in minecraft:overworld run fill 363 58 6 363 67 6 stone
execute in minecraft:overworld run fill 363 68 6 363 69 6 dirt
execute in minecraft:overworld run setblock 363 70 6 grass_block
execute in minecraft:overworld run fill 363 71 6 363 144 6 air
execute in minecraft:overworld run fill 363 58 7 363 67 7 stone
execute in minecraft:overworld run fill 363 68 7 363 69 7 dirt
execute in minecraft:overworld run setblock 363 70 7 coarse_dirt
execute in minecraft:overworld run fill 363 71 7 363 144 7 air
execute in minecraft:overworld run fill 363 58 8 363 67 8 stone
execute in minecraft:overworld run fill 363 68 8 363 69 8 dirt
execute in minecraft:overworld run setblock 363 70 8 grass_block
execute in minecraft:overworld run fill 363 71 8 363 144 8 air
execute in minecraft:overworld run fill 363 58 9 363 67 9 stone
execute in minecraft:overworld run fill 363 68 9 363 69 9 dirt
execute in minecraft:overworld run setblock 363 70 9 coarse_dirt
execute in minecraft:overworld run fill 363 71 9 363 144 9 air
execute in minecraft:overworld run setblock 363 71 9 grass
execute in minecraft:overworld run fill 363 58 10 363 68 10 stone
execute in minecraft:overworld run fill 363 69 10 363 70 10 dirt
execute in minecraft:overworld run setblock 363 71 10 grass_block
execute in minecraft:overworld run fill 363 72 10 363 144 10 air
execute in minecraft:overworld run fill 363 58 11 363 68 11 stone
execute in minecraft:overworld run fill 363 69 11 363 70 11 dirt
execute in minecraft:overworld run setblock 363 71 11 grass_block
execute in minecraft:overworld run fill 363 72 11 363 144 11 air
execute in minecraft:overworld run fill 363 58 12 363 68 12 stone
execute in minecraft:overworld run fill 363 69 12 363 70 12 dirt
execute in minecraft:overworld run setblock 363 71 12 grass_block
execute in minecraft:overworld run fill 363 72 12 363 144 12 air
execute in minecraft:overworld run fill 363 58 13 363 68 13 stone
execute in minecraft:overworld run fill 363 69 13 363 70 13 dirt
execute in minecraft:overworld run setblock 363 71 13 grass_block
execute in minecraft:overworld run fill 363 72 13 363 144 13 air
execute in minecraft:overworld run fill 363 58 14 363 68 14 stone
execute in minecraft:overworld run fill 363 69 14 363 70 14 dirt
execute in minecraft:overworld run setblock 363 71 14 coarse_dirt
execute in minecraft:overworld run fill 363 72 14 363 144 14 air
execute in minecraft:overworld run fill 363 58 15 363 68 15 stone
execute in minecraft:overworld run fill 363 69 15 363 70 15 dirt
execute in minecraft:overworld run setblock 363 71 15 grass_block
execute in minecraft:overworld run fill 363 72 15 363 144 15 air
execute in minecraft:overworld run fill 363 58 16 363 69 16 stone
execute in minecraft:overworld run fill 363 70 16 363 71 16 dirt
execute in minecraft:overworld run setblock 363 72 16 coarse_dirt
execute in minecraft:overworld run fill 363 73 16 363 144 16 air
execute in minecraft:overworld run setblock 363 73 16 grass
execute in minecraft:overworld run fill 363 58 17 363 69 17 stone
execute in minecraft:overworld run fill 363 70 17 363 71 17 dirt
execute in minecraft:overworld run setblock 363 72 17 grass_block
execute in minecraft:overworld run fill 363 73 17 363 144 17 air
execute in minecraft:overworld run setblock 363 73 17 grass
execute in minecraft:overworld run fill 363 58 18 363 69 18 stone
execute in minecraft:overworld run fill 363 70 18 363 71 18 dirt
execute in minecraft:overworld run setblock 363 72 18 coarse_dirt
execute in minecraft:overworld run fill 363 73 18 363 144 18 air
execute in minecraft:overworld run fill 363 58 19 363 69 19 stone
execute in minecraft:overworld run fill 363 70 19 363 71 19 dirt
execute in minecraft:overworld run setblock 363 72 19 coarse_dirt
execute in minecraft:overworld run fill 363 73 19 363 144 19 air
execute in minecraft:overworld run setblock 363 73 19 grass
execute in minecraft:overworld run fill 363 58 20 363 69 20 stone
execute in minecraft:overworld run fill 363 70 20 363 71 20 dirt
execute in minecraft:overworld run setblock 363 72 20 coarse_dirt
execute in minecraft:overworld run fill 363 73 20 363 144 20 air
execute in minecraft:overworld run fill 363 58 21 363 69 21 stone
execute in minecraft:overworld run fill 363 70 21 363 71 21 dirt
execute in minecraft:overworld run setblock 363 72 21 grass_block
execute in minecraft:overworld run fill 363 73 21 363 144 21 air
execute in minecraft:overworld run fill 363 58 22 363 69 22 stone
execute in minecraft:overworld run fill 363 70 22 363 71 22 dirt
execute in minecraft:overworld run setblock 363 72 22 grass_block
execute in minecraft:overworld run fill 363 73 22 363 144 22 air
execute in minecraft:overworld run fill 363 58 23 363 69 23 stone
execute in minecraft:overworld run fill 363 70 23 363 71 23 dirt
execute in minecraft:overworld run setblock 363 72 23 coarse_dirt
execute in minecraft:overworld run fill 363 73 23 363 144 23 air
execute in minecraft:overworld run setblock 363 73 23 grass
execute in minecraft:overworld run fill 363 58 24 363 69 24 stone
execute in minecraft:overworld run fill 363 70 24 363 71 24 dirt
execute in minecraft:overworld run setblock 363 72 24 grass_block
execute in minecraft:overworld run fill 363 73 24 363 144 24 air
execute in minecraft:overworld run fill 363 58 25 363 69 25 stone
execute in minecraft:overworld run fill 363 70 25 363 71 25 dirt
execute in minecraft:overworld run setblock 363 72 25 grass_block
execute in minecraft:overworld run fill 363 73 25 363 144 25 air
execute in minecraft:overworld run fill 363 58 26 363 69 26 stone
execute in minecraft:overworld run fill 363 70 26 363 71 26 dirt
execute in minecraft:overworld run setblock 363 72 26 coarse_dirt
execute in minecraft:overworld run fill 363 73 26 363 144 26 air
execute in minecraft:overworld run fill 363 58 27 363 69 27 stone
execute in minecraft:overworld run fill 363 70 27 363 71 27 dirt
execute in minecraft:overworld run setblock 363 72 27 coarse_dirt
execute in minecraft:overworld run fill 363 73 27 363 144 27 air
execute in minecraft:overworld run fill 363 58 28 363 69 28 stone
execute in minecraft:overworld run fill 363 70 28 363 71 28 dirt
execute in minecraft:overworld run setblock 363 72 28 coarse_dirt
execute in minecraft:overworld run fill 363 73 28 363 144 28 air
execute in minecraft:overworld run fill 363 58 29 363 69 29 stone
execute in minecraft:overworld run fill 363 70 29 363 71 29 dirt
execute in minecraft:overworld run setblock 363 72 29 coarse_dirt
execute in minecraft:overworld run fill 363 73 29 363 144 29 air
execute in minecraft:overworld run setblock 363 73 29 grass
execute in minecraft:overworld run fill 363 58 30 363 69 30 stone
execute in minecraft:overworld run fill 363 70 30 363 71 30 dirt
execute in minecraft:overworld run setblock 363 72 30 coarse_dirt
execute in minecraft:overworld run fill 363 73 30 363 144 30 air
execute in minecraft:overworld run fill 363 58 31 363 69 31 stone
execute in minecraft:overworld run fill 363 70 31 363 71 31 dirt
execute in minecraft:overworld run setblock 363 72 31 grass_block
execute in minecraft:overworld run fill 363 73 31 363 144 31 air
execute in minecraft:overworld run fill 363 58 32 363 69 32 stone
execute in minecraft:overworld run fill 363 70 32 363 71 32 dirt
execute in minecraft:overworld run setblock 363 72 32 grass_block
execute in minecraft:overworld run fill 363 73 32 363 144 32 air
execute in minecraft:overworld run fill 363 58 33 363 70 33 stone
execute in minecraft:overworld run fill 363 71 33 363 72 33 dirt
execute in minecraft:overworld run setblock 363 73 33 grass_block
execute in minecraft:overworld run fill 363 74 33 363 144 33 air
execute in minecraft:overworld run fill 363 58 34 363 70 34 stone
execute in minecraft:overworld run fill 363 71 34 363 72 34 dirt
execute in minecraft:overworld run setblock 363 73 34 coarse_dirt
execute in minecraft:overworld run fill 363 74 34 363 144 34 air
execute in minecraft:overworld run fill 363 58 35 363 70 35 stone
execute in minecraft:overworld run fill 363 71 35 363 72 35 dirt
execute in minecraft:overworld run setblock 363 73 35 coarse_dirt
execute in minecraft:overworld run fill 363 74 35 363 144 35 air
execute in minecraft:overworld run fill 363 58 36 363 70 36 stone
execute in minecraft:overworld run fill 363 71 36 363 72 36 dirt
execute in minecraft:overworld run setblock 363 73 36 grass_block
execute in minecraft:overworld run fill 363 74 36 363 144 36 air
execute in minecraft:overworld run fill 363 58 37 363 70 37 stone
execute in minecraft:overworld run fill 363 71 37 363 72 37 dirt
execute in minecraft:overworld run setblock 363 73 37 grass_block
execute in minecraft:overworld run fill 363 74 37 363 144 37 air
execute in minecraft:overworld run fill 363 58 38 363 70 38 stone
execute in minecraft:overworld run fill 363 71 38 363 72 38 dirt
execute in minecraft:overworld run setblock 363 73 38 grass_block
execute in minecraft:overworld run fill 363 74 38 363 144 38 air
execute in minecraft:overworld run fill 363 58 39 363 69 39 stone
execute in minecraft:overworld run fill 363 70 39 363 71 39 dirt
execute in minecraft:overworld run setblock 363 72 39 coarse_dirt
execute in minecraft:overworld run fill 363 73 39 363 144 39 air
execute in minecraft:overworld run fill 363 58 40 363 68 40 stone
execute in minecraft:overworld run fill 363 69 40 363 70 40 dirt
execute in minecraft:overworld run setblock 363 71 40 grass_block
execute in minecraft:overworld run fill 363 72 40 363 144 40 air
execute in minecraft:overworld run fill 363 58 41 363 67 41 stone
execute in minecraft:overworld run fill 363 68 41 363 69 41 dirt
execute in minecraft:overworld run setblock 363 70 41 coarse_dirt
execute in minecraft:overworld run fill 363 71 41 363 144 41 air
execute in minecraft:overworld run fill 363 58 42 363 66 42 stone
execute in minecraft:overworld run fill 363 67 42 363 68 42 dirt
execute in minecraft:overworld run setblock 363 69 42 grass_block
execute in minecraft:overworld run fill 363 70 42 363 144 42 air
execute in minecraft:overworld run fill 363 58 43 363 65 43 stone
execute in minecraft:overworld run fill 363 66 43 363 67 43 dirt
execute in minecraft:overworld run setblock 363 68 43 grass_block
execute in minecraft:overworld run fill 363 69 43 363 144 43 air
execute in minecraft:overworld run fill 363 58 44 363 64 44 stone
execute in minecraft:overworld run fill 363 65 44 363 66 44 dirt
execute in minecraft:overworld run setblock 363 67 44 coarse_dirt
execute in minecraft:overworld run fill 363 68 44 363 144 44 air
execute in minecraft:overworld run fill 363 58 45 363 63 45 stone
execute in minecraft:overworld run fill 363 64 45 363 65 45 dirt
execute in minecraft:overworld run setblock 363 66 45 coarse_dirt
execute in minecraft:overworld run fill 363 67 45 363 144 45 air
execute in minecraft:overworld run fill 363 58 46 363 63 46 stone
execute in minecraft:overworld run fill 363 64 46 363 65 46 dirt
execute in minecraft:overworld run setblock 363 66 46 coarse_dirt
execute in minecraft:overworld run fill 363 67 46 363 144 46 air
execute in minecraft:overworld run fill 363 58 47 363 62 47 stone
execute in minecraft:overworld run fill 363 63 47 363 64 47 dirt
execute in minecraft:overworld run setblock 363 65 47 coarse_dirt
execute in minecraft:overworld run fill 363 66 47 363 144 47 air
execute in minecraft:overworld run fill 364 58 -48 364 61 -48 stone
execute in minecraft:overworld run fill 364 62 -48 364 63 -48 dirt
execute in minecraft:overworld run setblock 364 64 -48 coarse_dirt
execute in minecraft:overworld run fill 364 65 -48 364 144 -48 air
execute in minecraft:overworld run fill 364 58 -47 364 63 -47 stone
execute in minecraft:overworld run fill 364 64 -47 364 65 -47 dirt
execute in minecraft:overworld run setblock 364 66 -47 coarse_dirt
execute in minecraft:overworld run fill 364 67 -47 364 144 -47 air
execute in minecraft:overworld run fill 364 58 -46 364 64 -46 stone
execute in minecraft:overworld run fill 364 65 -46 364 66 -46 dirt
execute in minecraft:overworld run setblock 364 67 -46 grass_block
execute in minecraft:overworld run fill 364 68 -46 364 144 -46 air
execute in minecraft:overworld run fill 364 58 -45 364 66 -45 stone
execute in minecraft:overworld run fill 364 67 -45 364 68 -45 dirt
execute in minecraft:overworld run setblock 364 69 -45 grass_block
execute in minecraft:overworld run fill 364 70 -45 364 144 -45 air
execute in minecraft:overworld run fill 364 58 -44 364 67 -44 stone
execute in minecraft:overworld run fill 364 68 -44 364 69 -44 dirt
execute in minecraft:overworld run setblock 364 70 -44 grass_block
execute in minecraft:overworld run fill 364 71 -44 364 144 -44 air
execute in minecraft:overworld run fill 364 58 -43 364 69 -43 stone
execute in minecraft:overworld run fill 364 70 -43 364 71 -43 dirt
execute in minecraft:overworld run setblock 364 72 -43 coarse_dirt
execute in minecraft:overworld run fill 364 73 -43 364 144 -43 air
execute in minecraft:overworld run fill 364 58 -42 364 70 -42 stone
execute in minecraft:overworld run fill 364 71 -42 364 72 -42 dirt
execute in minecraft:overworld run setblock 364 73 -42 coarse_dirt
execute in minecraft:overworld run fill 364 74 -42 364 144 -42 air
execute in minecraft:overworld run fill 364 58 -41 364 71 -41 stone
execute in minecraft:overworld run fill 364 72 -41 364 73 -41 dirt
execute in minecraft:overworld run setblock 364 74 -41 coarse_dirt
execute in minecraft:overworld run fill 364 75 -41 364 144 -41 air
execute in minecraft:overworld run fill 364 58 -40 364 72 -40 stone
execute in minecraft:overworld run fill 364 73 -40 364 74 -40 dirt
execute in minecraft:overworld run setblock 364 75 -40 coarse_dirt
execute in minecraft:overworld run fill 364 76 -40 364 144 -40 air
execute in minecraft:overworld run fill 364 58 -39 364 74 -39 stone
execute in minecraft:overworld run fill 364 75 -39 364 76 -39 dirt
schedule function blade_gallery:random/battlefield/part_43 1t replace
