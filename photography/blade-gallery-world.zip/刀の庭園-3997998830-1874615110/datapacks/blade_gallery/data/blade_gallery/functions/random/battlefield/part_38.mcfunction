execute in minecraft:overworld run fill 360 58 34 360 69 34 stone
execute in minecraft:overworld run fill 360 70 34 360 71 34 dirt
execute in minecraft:overworld run setblock 360 72 34 grass_block
execute in minecraft:overworld run fill 360 73 34 360 144 34 air
execute in minecraft:overworld run setblock 360 73 34 mossy_cobblestone
execute in minecraft:overworld run fill 360 58 35 360 69 35 stone
execute in minecraft:overworld run fill 360 70 35 360 71 35 dirt
execute in minecraft:overworld run setblock 360 72 35 grass_block
execute in minecraft:overworld run fill 360 73 35 360 144 35 air
execute in minecraft:overworld run fill 360 58 36 360 69 36 stone
execute in minecraft:overworld run fill 360 70 36 360 71 36 dirt
execute in minecraft:overworld run setblock 360 72 36 coarse_dirt
execute in minecraft:overworld run fill 360 73 36 360 144 36 air
execute in minecraft:overworld run fill 360 58 37 360 69 37 stone
execute in minecraft:overworld run fill 360 70 37 360 71 37 dirt
execute in minecraft:overworld run setblock 360 72 37 grass_block
execute in minecraft:overworld run fill 360 73 37 360 144 37 air
execute in minecraft:overworld run fill 360 58 38 360 69 38 stone
execute in minecraft:overworld run fill 360 70 38 360 71 38 dirt
execute in minecraft:overworld run setblock 360 72 38 grass_block
execute in minecraft:overworld run fill 360 73 38 360 144 38 air
execute in minecraft:overworld run fill 360 58 39 360 68 39 stone
execute in minecraft:overworld run fill 360 69 39 360 70 39 dirt
execute in minecraft:overworld run setblock 360 71 39 coarse_dirt
execute in minecraft:overworld run fill 360 72 39 360 144 39 air
execute in minecraft:overworld run fill 360 58 40 360 67 40 stone
execute in minecraft:overworld run fill 360 68 40 360 69 40 dirt
execute in minecraft:overworld run setblock 360 70 40 grass_block
execute in minecraft:overworld run fill 360 71 40 360 144 40 air
execute in minecraft:overworld run fill 360 58 41 360 66 41 stone
execute in minecraft:overworld run fill 360 67 41 360 68 41 dirt
execute in minecraft:overworld run setblock 360 69 41 grass_block
execute in minecraft:overworld run fill 360 70 41 360 144 41 air
execute in minecraft:overworld run fill 360 58 42 360 66 42 stone
execute in minecraft:overworld run fill 360 67 42 360 68 42 dirt
execute in minecraft:overworld run setblock 360 69 42 coarse_dirt
execute in minecraft:overworld run fill 360 70 42 360 144 42 air
execute in minecraft:overworld run fill 360 58 43 360 65 43 stone
execute in minecraft:overworld run fill 360 66 43 360 67 43 dirt
execute in minecraft:overworld run setblock 360 68 43 coarse_dirt
execute in minecraft:overworld run fill 360 69 43 360 144 43 air
execute in minecraft:overworld run fill 360 58 44 360 64 44 stone
execute in minecraft:overworld run fill 360 65 44 360 66 44 dirt
execute in minecraft:overworld run setblock 360 67 44 coarse_dirt
execute in minecraft:overworld run fill 360 68 44 360 144 44 air
execute in minecraft:overworld run fill 360 58 45 360 63 45 stone
execute in minecraft:overworld run fill 360 64 45 360 65 45 dirt
execute in minecraft:overworld run setblock 360 66 45 coarse_dirt
execute in minecraft:overworld run fill 360 67 45 360 144 45 air
execute in minecraft:overworld run fill 360 58 46 360 62 46 stone
execute in minecraft:overworld run fill 360 63 46 360 64 46 dirt
execute in minecraft:overworld run setblock 360 65 46 coarse_dirt
execute in minecraft:overworld run fill 360 66 46 360 144 46 air
execute in minecraft:overworld run fill 360 58 47 360 62 47 stone
execute in minecraft:overworld run fill 360 63 47 360 64 47 dirt
execute in minecraft:overworld run setblock 360 65 47 grass_block
execute in minecraft:overworld run fill 360 66 47 360 144 47 air
execute in minecraft:overworld run fill 361 58 -48 361 61 -48 stone
execute in minecraft:overworld run fill 361 62 -48 361 63 -48 dirt
execute in minecraft:overworld run setblock 361 64 -48 coarse_dirt
execute in minecraft:overworld run fill 361 65 -48 361 144 -48 air
execute in minecraft:overworld run fill 361 58 -47 361 63 -47 stone
execute in minecraft:overworld run fill 361 64 -47 361 65 -47 dirt
execute in minecraft:overworld run setblock 361 66 -47 coarse_dirt
execute in minecraft:overworld run fill 361 67 -47 361 144 -47 air
execute in minecraft:overworld run fill 361 58 -46 361 65 -46 stone
execute in minecraft:overworld run fill 361 66 -46 361 67 -46 dirt
execute in minecraft:overworld run setblock 361 68 -46 coarse_dirt
execute in minecraft:overworld run fill 361 69 -46 361 144 -46 air
execute in minecraft:overworld run fill 361 58 -45 361 66 -45 stone
execute in minecraft:overworld run fill 361 67 -45 361 68 -45 dirt
execute in minecraft:overworld run setblock 361 69 -45 grass_block
execute in minecraft:overworld run fill 361 70 -45 361 144 -45 air
execute in minecraft:overworld run fill 361 58 -44 361 68 -44 stone
execute in minecraft:overworld run fill 361 69 -44 361 70 -44 dirt
execute in minecraft:overworld run setblock 361 71 -44 grass_block
execute in minecraft:overworld run fill 361 72 -44 361 144 -44 air
execute in minecraft:overworld run fill 361 58 -43 361 69 -43 stone
execute in minecraft:overworld run fill 361 70 -43 361 71 -43 dirt
execute in minecraft:overworld run setblock 361 72 -43 coarse_dirt
execute in minecraft:overworld run fill 361 73 -43 361 144 -43 air
execute in minecraft:overworld run fill 361 58 -42 361 71 -42 stone
execute in minecraft:overworld run fill 361 72 -42 361 73 -42 dirt
execute in minecraft:overworld run setblock 361 74 -42 grass_block
execute in minecraft:overworld run fill 361 75 -42 361 144 -42 air
execute in minecraft:overworld run fill 361 58 -41 361 72 -41 stone
execute in minecraft:overworld run fill 361 73 -41 361 74 -41 dirt
execute in minecraft:overworld run setblock 361 75 -41 coarse_dirt
execute in minecraft:overworld run fill 361 76 -41 361 144 -41 air
execute in minecraft:overworld run fill 361 58 -40 361 73 -40 stone
execute in minecraft:overworld run fill 361 74 -40 361 75 -40 dirt
execute in minecraft:overworld run setblock 361 76 -40 grass_block
execute in minecraft:overworld run fill 361 77 -40 361 144 -40 air
execute in minecraft:overworld run fill 361 58 -39 361 74 -39 stone
execute in minecraft:overworld run fill 361 75 -39 361 76 -39 dirt
execute in minecraft:overworld run setblock 361 77 -39 grass_block
execute in minecraft:overworld run fill 361 78 -39 361 144 -39 air
execute in minecraft:overworld run setblock 361 78 -39 grass
execute in minecraft:overworld run fill 361 58 -38 361 75 -38 stone
execute in minecraft:overworld run fill 361 76 -38 361 77 -38 dirt
execute in minecraft:overworld run setblock 361 78 -38 coarse_dirt
execute in minecraft:overworld run fill 361 79 -38 361 144 -38 air
execute in minecraft:overworld run fill 361 58 -37 361 75 -37 stone
execute in minecraft:overworld run fill 361 76 -37 361 77 -37 dirt
execute in minecraft:overworld run setblock 361 78 -37 grass_block
execute in minecraft:overworld run fill 361 79 -37 361 144 -37 air
execute in minecraft:overworld run fill 361 58 -36 361 74 -36 stone
execute in minecraft:overworld run fill 361 75 -36 361 76 -36 dirt
execute in minecraft:overworld run setblock 361 77 -36 coarse_dirt
execute in minecraft:overworld run fill 361 78 -36 361 144 -36 air
execute in minecraft:overworld run fill 361 58 -35 361 74 -35 stone
execute in minecraft:overworld run fill 361 75 -35 361 76 -35 dirt
execute in minecraft:overworld run setblock 361 77 -35 coarse_dirt
execute in minecraft:overworld run fill 361 78 -35 361 144 -35 air
execute in minecraft:overworld run fill 361 58 -34 361 74 -34 stone
execute in minecraft:overworld run fill 361 75 -34 361 76 -34 dirt
execute in minecraft:overworld run setblock 361 77 -34 coarse_dirt
execute in minecraft:overworld run fill 361 78 -34 361 144 -34 air
execute in minecraft:overworld run fill 361 58 -33 361 74 -33 stone
execute in minecraft:overworld run fill 361 75 -33 361 76 -33 dirt
execute in minecraft:overworld run setblock 361 77 -33 coarse_dirt
execute in minecraft:overworld run fill 361 78 -33 361 144 -33 air
execute in minecraft:overworld run fill 361 58 -32 361 74 -32 stone
execute in minecraft:overworld run fill 361 75 -32 361 76 -32 dirt
execute in minecraft:overworld run setblock 361 77 -32 grass_block
execute in minecraft:overworld run fill 361 78 -32 361 144 -32 air
execute in minecraft:overworld run fill 361 58 -31 361 74 -31 stone
execute in minecraft:overworld run fill 361 75 -31 361 76 -31 dirt
execute in minecraft:overworld run setblock 361 77 -31 coarse_dirt
execute in minecraft:overworld run fill 361 78 -31 361 144 -31 air
execute in minecraft:overworld run fill 361 58 -30 361 74 -30 stone
execute in minecraft:overworld run fill 361 75 -30 361 76 -30 dirt
execute in minecraft:overworld run setblock 361 77 -30 coarse_dirt
execute in minecraft:overworld run fill 361 78 -30 361 144 -30 air
execute in minecraft:overworld run fill 361 58 -29 361 73 -29 stone
execute in minecraft:overworld run fill 361 74 -29 361 75 -29 dirt
execute in minecraft:overworld run setblock 361 76 -29 grass_block
execute in minecraft:overworld run fill 361 77 -29 361 144 -29 air
execute in minecraft:overworld run fill 361 58 -28 361 73 -28 stone
execute in minecraft:overworld run fill 361 74 -28 361 75 -28 dirt
execute in minecraft:overworld run setblock 361 76 -28 grass_block
execute in minecraft:overworld run fill 361 77 -28 361 144 -28 air
execute in minecraft:overworld run fill 361 58 -27 361 73 -27 stone
execute in minecraft:overworld run fill 361 74 -27 361 75 -27 dirt
execute in minecraft:overworld run setblock 361 76 -27 coarse_dirt
execute in minecraft:overworld run fill 361 77 -27 361 144 -27 air
execute in minecraft:overworld run fill 361 58 -26 361 73 -26 stone
execute in minecraft:overworld run fill 361 74 -26 361 75 -26 dirt
execute in minecraft:overworld run setblock 361 76 -26 coarse_dirt
execute in minecraft:overworld run fill 361 77 -26 361 144 -26 air
execute in minecraft:overworld run fill 361 58 -25 361 72 -25 stone
execute in minecraft:overworld run fill 361 73 -25 361 74 -25 dirt
execute in minecraft:overworld run setblock 361 75 -25 grass_block
execute in minecraft:overworld run fill 361 76 -25 361 144 -25 air
execute in minecraft:overworld run fill 361 58 -24 361 72 -24 stone
execute in minecraft:overworld run fill 361 73 -24 361 74 -24 dirt
execute in minecraft:overworld run setblock 361 75 -24 coarse_dirt
execute in minecraft:overworld run fill 361 76 -24 361 144 -24 air
execute in minecraft:overworld run fill 361 58 -23 361 72 -23 stone
execute in minecraft:overworld run fill 361 73 -23 361 74 -23 dirt
execute in minecraft:overworld run setblock 361 75 -23 coarse_dirt
execute in minecraft:overworld run fill 361 76 -23 361 144 -23 air
execute in minecraft:overworld run fill 361 58 -22 361 71 -22 stone
execute in minecraft:overworld run fill 361 72 -22 361 73 -22 dirt
execute in minecraft:overworld run setblock 361 74 -22 coarse_dirt
execute in minecraft:overworld run fill 361 75 -22 361 144 -22 air
execute in minecraft:overworld run fill 361 58 -21 361 71 -21 stone
execute in minecraft:overworld run fill 361 72 -21 361 73 -21 dirt
execute in minecraft:overworld run setblock 361 74 -21 coarse_dirt
execute in minecraft:overworld run fill 361 75 -21 361 144 -21 air
execute in minecraft:overworld run fill 361 58 -20 361 71 -20 stone
execute in minecraft:overworld run fill 361 72 -20 361 73 -20 dirt
execute in minecraft:overworld run setblock 361 74 -20 grass_block
execute in minecraft:overworld run fill 361 75 -20 361 144 -20 air
execute in minecraft:overworld run fill 361 58 -19 361 71 -19 stone
execute in minecraft:overworld run fill 361 72 -19 361 73 -19 dirt
execute in minecraft:overworld run setblock 361 74 -19 coarse_dirt
execute in minecraft:overworld run fill 361 75 -19 361 144 -19 air
execute in minecraft:overworld run fill 361 58 -18 361 70 -18 stone
execute in minecraft:overworld run fill 361 71 -18 361 72 -18 dirt
execute in minecraft:overworld run setblock 361 73 -18 coarse_dirt
execute in minecraft:overworld run fill 361 74 -18 361 144 -18 air
execute in minecraft:overworld run fill 361 58 -17 361 70 -17 stone
execute in minecraft:overworld run fill 361 71 -17 361 72 -17 dirt
execute in minecraft:overworld run setblock 361 73 -17 coarse_dirt
execute in minecraft:overworld run fill 361 74 -17 361 144 -17 air
execute in minecraft:overworld run fill 361 58 -16 361 69 -16 stone
execute in minecraft:overworld run fill 361 70 -16 361 71 -16 dirt
execute in minecraft:overworld run setblock 361 72 -16 grass_block
execute in minecraft:overworld run fill 361 73 -16 361 144 -16 air
execute in minecraft:overworld run fill 361 58 -15 361 68 -15 stone
execute in minecraft:overworld run fill 361 69 -15 361 70 -15 dirt
execute in minecraft:overworld run setblock 361 71 -15 coarse_dirt
execute in minecraft:overworld run fill 361 72 -15 361 144 -15 air
execute in minecraft:overworld run fill 361 58 -14 361 67 -14 stone
execute in minecraft:overworld run fill 361 68 -14 361 69 -14 dirt
execute in minecraft:overworld run setblock 361 70 -14 coarse_dirt
execute in minecraft:overworld run fill 361 71 -14 361 144 -14 air
execute in minecraft:overworld run fill 361 58 -13 361 67 -13 stone
execute in minecraft:overworld run fill 361 68 -13 361 69 -13 dirt
execute in minecraft:overworld run setblock 361 70 -13 coarse_dirt
execute in minecraft:overworld run fill 361 71 -13 361 144 -13 air
execute in minecraft:overworld run setblock 361 71 -13 grass
execute in minecraft:overworld run fill 361 58 -12 361 66 -12 stone
execute in minecraft:overworld run fill 361 67 -12 361 68 -12 dirt
execute in minecraft:overworld run setblock 361 69 -12 coarse_dirt
execute in minecraft:overworld run fill 361 70 -12 361 144 -12 air
execute in minecraft:overworld run fill 361 58 -11 361 66 -11 stone
execute in minecraft:overworld run fill 361 67 -11 361 68 -11 dirt
execute in minecraft:overworld run setblock 361 69 -11 coarse_dirt
execute in minecraft:overworld run fill 361 70 -11 361 144 -11 air
execute in minecraft:overworld run fill 361 58 -10 361 65 -10 stone
execute in minecraft:overworld run fill 361 66 -10 361 67 -10 dirt
execute in minecraft:overworld run setblock 361 68 -10 coarse_dirt
execute in minecraft:overworld run fill 361 69 -10 361 144 -10 air
execute in minecraft:overworld run fill 361 58 -9 361 65 -9 stone
execute in minecraft:overworld run fill 361 66 -9 361 67 -9 dirt
execute in minecraft:overworld run setblock 361 68 -9 grass_block
execute in minecraft:overworld run fill 361 69 -9 361 144 -9 air
execute in minecraft:overworld run fill 361 58 -8 361 65 -8 stone
execute in minecraft:overworld run fill 361 66 -8 361 67 -8 dirt
execute in minecraft:overworld run setblock 361 68 -8 coarse_dirt
execute in minecraft:overworld run fill 361 69 -8 361 144 -8 air
execute in minecraft:overworld run fill 361 58 -7 361 65 -7 stone
execute in minecraft:overworld run fill 361 66 -7 361 67 -7 dirt
execute in minecraft:overworld run setblock 361 68 -7 coarse_dirt
execute in minecraft:overworld run fill 361 69 -7 361 144 -7 air
execute in minecraft:overworld run fill 361 58 -6 361 65 -6 stone
execute in minecraft:overworld run fill 361 66 -6 361 67 -6 dirt
execute in minecraft:overworld run setblock 361 68 -6 grass_block
execute in minecraft:overworld run fill 361 69 -6 361 144 -6 air
execute in minecraft:overworld run fill 361 58 -5 361 65 -5 stone
execute in minecraft:overworld run fill 361 66 -5 361 67 -5 dirt
execute in minecraft:overworld run setblock 361 68 -5 coarse_dirt
execute in minecraft:overworld run fill 361 69 -5 361 144 -5 air
execute in minecraft:overworld run fill 361 58 -4 361 65 -4 stone
execute in minecraft:overworld run fill 361 66 -4 361 67 -4 dirt
execute in minecraft:overworld run setblock 361 68 -4 grass_block
execute in minecraft:overworld run fill 361 69 -4 361 144 -4 air
execute in minecraft:overworld run fill 361 58 -3 361 65 -3 stone
execute in minecraft:overworld run fill 361 66 -3 361 67 -3 dirt
execute in minecraft:overworld run setblock 361 68 -3 coarse_dirt
execute in minecraft:overworld run fill 361 69 -3 361 144 -3 air
execute in minecraft:overworld run fill 361 58 -2 361 65 -2 stone
execute in minecraft:overworld run fill 361 66 -2 361 67 -2 dirt
execute in minecraft:overworld run setblock 361 68 -2 grass_block
execute in minecraft:overworld run fill 361 69 -2 361 144 -2 air
execute in minecraft:overworld run fill 361 58 -1 361 65 -1 stone
execute in minecraft:overworld run fill 361 66 -1 361 67 -1 dirt
execute in minecraft:overworld run setblock 361 68 -1 coarse_dirt
execute in minecraft:overworld run fill 361 69 -1 361 144 -1 air
execute in minecraft:overworld run setblock 361 69 -1 grass
execute in minecraft:overworld run fill 361 58 0 361 65 0 stone
execute in minecraft:overworld run fill 361 66 0 361 67 0 dirt
execute in minecraft:overworld run setblock 361 68 0 coarse_dirt
execute in minecraft:overworld run fill 361 69 0 361 144 0 air
schedule function blade_gallery:random/battlefield/part_39 1t replace
