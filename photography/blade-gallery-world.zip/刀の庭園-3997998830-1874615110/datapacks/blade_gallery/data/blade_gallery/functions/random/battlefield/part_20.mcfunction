execute in minecraft:overworld run fill 349 78 -33 349 144 -33 air
execute in minecraft:overworld run fill 349 58 -32 349 74 -32 stone
execute in minecraft:overworld run fill 349 75 -32 349 76 -32 dirt
execute in minecraft:overworld run setblock 349 77 -32 coarse_dirt
execute in minecraft:overworld run fill 349 78 -32 349 144 -32 air
execute in minecraft:overworld run fill 349 58 -31 349 74 -31 stone
execute in minecraft:overworld run fill 349 75 -31 349 76 -31 dirt
execute in minecraft:overworld run setblock 349 77 -31 coarse_dirt
execute in minecraft:overworld run fill 349 78 -31 349 144 -31 air
execute in minecraft:overworld run setblock 349 78 -31 mossy_cobblestone
execute in minecraft:overworld run fill 349 58 -30 349 74 -30 stone
execute in minecraft:overworld run fill 349 75 -30 349 76 -30 dirt
execute in minecraft:overworld run setblock 349 77 -30 coarse_dirt
execute in minecraft:overworld run fill 349 78 -30 349 144 -30 air
execute in minecraft:overworld run fill 349 58 -29 349 74 -29 stone
execute in minecraft:overworld run fill 349 75 -29 349 76 -29 dirt
execute in minecraft:overworld run setblock 349 77 -29 coarse_dirt
execute in minecraft:overworld run fill 349 78 -29 349 144 -29 air
execute in minecraft:overworld run fill 349 58 -28 349 73 -28 stone
execute in minecraft:overworld run fill 349 74 -28 349 75 -28 dirt
execute in minecraft:overworld run setblock 349 76 -28 coarse_dirt
execute in minecraft:overworld run fill 349 77 -28 349 144 -28 air
execute in minecraft:overworld run fill 349 58 -27 349 73 -27 stone
execute in minecraft:overworld run fill 349 74 -27 349 75 -27 dirt
execute in minecraft:overworld run setblock 349 76 -27 coarse_dirt
execute in minecraft:overworld run fill 349 77 -27 349 144 -27 air
execute in minecraft:overworld run fill 349 58 -26 349 73 -26 stone
execute in minecraft:overworld run fill 349 74 -26 349 75 -26 dirt
execute in minecraft:overworld run setblock 349 76 -26 grass_block
execute in minecraft:overworld run fill 349 77 -26 349 144 -26 air
execute in minecraft:overworld run fill 349 58 -25 349 72 -25 stone
execute in minecraft:overworld run fill 349 73 -25 349 74 -25 dirt
execute in minecraft:overworld run setblock 349 75 -25 coarse_dirt
execute in minecraft:overworld run fill 349 76 -25 349 144 -25 air
execute in minecraft:overworld run fill 349 58 -24 349 72 -24 stone
execute in minecraft:overworld run fill 349 73 -24 349 74 -24 dirt
execute in minecraft:overworld run setblock 349 75 -24 coarse_dirt
execute in minecraft:overworld run fill 349 76 -24 349 144 -24 air
execute in minecraft:overworld run setblock 349 76 -24 grass
execute in minecraft:overworld run fill 349 58 -23 349 72 -23 stone
execute in minecraft:overworld run fill 349 73 -23 349 74 -23 dirt
execute in minecraft:overworld run setblock 349 75 -23 grass_block
execute in minecraft:overworld run fill 349 76 -23 349 144 -23 air
execute in minecraft:overworld run setblock 349 76 -23 grass
execute in minecraft:overworld run fill 349 58 -22 349 71 -22 stone
execute in minecraft:overworld run fill 349 72 -22 349 73 -22 dirt
execute in minecraft:overworld run setblock 349 74 -22 grass_block
execute in minecraft:overworld run fill 349 75 -22 349 144 -22 air
execute in minecraft:overworld run fill 349 58 -21 349 71 -21 stone
execute in minecraft:overworld run fill 349 72 -21 349 73 -21 dirt
execute in minecraft:overworld run setblock 349 74 -21 grass_block
execute in minecraft:overworld run fill 349 75 -21 349 144 -21 air
execute in minecraft:overworld run fill 349 58 -20 349 71 -20 stone
execute in minecraft:overworld run fill 349 72 -20 349 73 -20 dirt
execute in minecraft:overworld run setblock 349 74 -20 coarse_dirt
execute in minecraft:overworld run fill 349 75 -20 349 144 -20 air
execute in minecraft:overworld run fill 349 58 -19 349 70 -19 stone
execute in minecraft:overworld run fill 349 71 -19 349 72 -19 dirt
execute in minecraft:overworld run setblock 349 73 -19 grass_block
execute in minecraft:overworld run fill 349 74 -19 349 144 -19 air
execute in minecraft:overworld run fill 349 58 -18 349 70 -18 stone
execute in minecraft:overworld run fill 349 71 -18 349 72 -18 dirt
execute in minecraft:overworld run setblock 349 73 -18 coarse_dirt
execute in minecraft:overworld run fill 349 74 -18 349 144 -18 air
execute in minecraft:overworld run fill 349 58 -17 349 69 -17 stone
execute in minecraft:overworld run fill 349 70 -17 349 71 -17 dirt
execute in minecraft:overworld run setblock 349 72 -17 coarse_dirt
execute in minecraft:overworld run fill 349 73 -17 349 144 -17 air
execute in minecraft:overworld run fill 349 58 -16 349 69 -16 stone
execute in minecraft:overworld run fill 349 70 -16 349 71 -16 dirt
execute in minecraft:overworld run setblock 349 72 -16 grass_block
execute in minecraft:overworld run fill 349 73 -16 349 144 -16 air
execute in minecraft:overworld run setblock 349 73 -16 grass
execute in minecraft:overworld run fill 349 58 -15 349 68 -15 stone
execute in minecraft:overworld run fill 349 69 -15 349 70 -15 dirt
execute in minecraft:overworld run setblock 349 71 -15 coarse_dirt
execute in minecraft:overworld run fill 349 72 -15 349 144 -15 air
execute in minecraft:overworld run fill 349 58 -14 349 68 -14 stone
execute in minecraft:overworld run fill 349 69 -14 349 70 -14 dirt
execute in minecraft:overworld run setblock 349 71 -14 coarse_dirt
execute in minecraft:overworld run fill 349 72 -14 349 144 -14 air
execute in minecraft:overworld run fill 349 58 -13 349 68 -13 stone
execute in minecraft:overworld run fill 349 69 -13 349 70 -13 dirt
execute in minecraft:overworld run setblock 349 71 -13 grass_block
execute in minecraft:overworld run fill 349 72 -13 349 144 -13 air
execute in minecraft:overworld run fill 349 58 -12 349 67 -12 stone
execute in minecraft:overworld run fill 349 68 -12 349 69 -12 dirt
execute in minecraft:overworld run setblock 349 70 -12 coarse_dirt
execute in minecraft:overworld run fill 349 71 -12 349 144 -12 air
execute in minecraft:overworld run setblock 349 71 -12 grass
execute in minecraft:overworld run fill 349 58 -11 349 67 -11 stone
execute in minecraft:overworld run fill 349 68 -11 349 69 -11 dirt
execute in minecraft:overworld run setblock 349 70 -11 coarse_dirt
execute in minecraft:overworld run fill 349 71 -11 349 144 -11 air
execute in minecraft:overworld run fill 349 58 -10 349 67 -10 stone
execute in minecraft:overworld run fill 349 68 -10 349 69 -10 dirt
execute in minecraft:overworld run setblock 349 70 -10 grass_block
execute in minecraft:overworld run fill 349 71 -10 349 144 -10 air
execute in minecraft:overworld run setblock 349 71 -10 grass
execute in minecraft:overworld run fill 349 58 -9 349 67 -9 stone
execute in minecraft:overworld run fill 349 68 -9 349 69 -9 dirt
execute in minecraft:overworld run setblock 349 70 -9 coarse_dirt
execute in minecraft:overworld run fill 349 71 -9 349 144 -9 air
execute in minecraft:overworld run fill 349 58 -8 349 67 -8 stone
execute in minecraft:overworld run fill 349 68 -8 349 69 -8 dirt
execute in minecraft:overworld run setblock 349 70 -8 coarse_dirt
execute in minecraft:overworld run fill 349 71 -8 349 144 -8 air
execute in minecraft:overworld run fill 349 58 -7 349 67 -7 stone
execute in minecraft:overworld run fill 349 68 -7 349 69 -7 dirt
execute in minecraft:overworld run setblock 349 70 -7 coarse_dirt
execute in minecraft:overworld run fill 349 71 -7 349 144 -7 air
execute in minecraft:overworld run fill 349 58 -6 349 67 -6 stone
execute in minecraft:overworld run fill 349 68 -6 349 69 -6 dirt
execute in minecraft:overworld run setblock 349 70 -6 coarse_dirt
execute in minecraft:overworld run fill 349 71 -6 349 144 -6 air
execute in minecraft:overworld run fill 349 58 -5 349 67 -5 stone
execute in minecraft:overworld run fill 349 68 -5 349 69 -5 dirt
execute in minecraft:overworld run setblock 349 70 -5 grass_block
execute in minecraft:overworld run fill 349 71 -5 349 144 -5 air
execute in minecraft:overworld run fill 349 58 -4 349 67 -4 stone
execute in minecraft:overworld run fill 349 68 -4 349 69 -4 dirt
execute in minecraft:overworld run setblock 349 70 -4 grass_block
execute in minecraft:overworld run fill 349 71 -4 349 144 -4 air
execute in minecraft:overworld run fill 349 58 -3 349 67 -3 stone
execute in minecraft:overworld run fill 349 68 -3 349 69 -3 dirt
execute in minecraft:overworld run setblock 349 70 -3 coarse_dirt
execute in minecraft:overworld run fill 349 71 -3 349 144 -3 air
execute in minecraft:overworld run fill 349 58 -2 349 67 -2 stone
execute in minecraft:overworld run fill 349 68 -2 349 69 -2 dirt
execute in minecraft:overworld run setblock 349 70 -2 coarse_dirt
execute in minecraft:overworld run fill 349 71 -2 349 144 -2 air
execute in minecraft:overworld run fill 349 58 -1 349 67 -1 stone
execute in minecraft:overworld run fill 349 68 -1 349 69 -1 dirt
execute in minecraft:overworld run setblock 349 70 -1 coarse_dirt
execute in minecraft:overworld run fill 349 71 -1 349 144 -1 air
execute in minecraft:overworld run setblock 349 71 -1 grass
execute in minecraft:overworld run fill 349 58 0 349 67 0 stone
execute in minecraft:overworld run fill 349 68 0 349 69 0 dirt
execute in minecraft:overworld run setblock 349 70 0 grass_block
execute in minecraft:overworld run fill 349 71 0 349 144 0 air
execute in minecraft:overworld run fill 349 58 1 349 67 1 stone
execute in minecraft:overworld run fill 349 68 1 349 69 1 dirt
execute in minecraft:overworld run setblock 349 70 1 coarse_dirt
execute in minecraft:overworld run fill 349 71 1 349 144 1 air
execute in minecraft:overworld run fill 349 58 2 349 67 2 stone
execute in minecraft:overworld run fill 349 68 2 349 69 2 dirt
execute in minecraft:overworld run setblock 349 70 2 coarse_dirt
execute in minecraft:overworld run fill 349 71 2 349 144 2 air
execute in minecraft:overworld run setblock 349 71 2 grass
execute in minecraft:overworld run fill 349 58 3 349 67 3 stone
execute in minecraft:overworld run fill 349 68 3 349 69 3 dirt
execute in minecraft:overworld run setblock 349 70 3 grass_block
execute in minecraft:overworld run fill 349 71 3 349 144 3 air
execute in minecraft:overworld run fill 349 58 4 349 67 4 stone
execute in minecraft:overworld run fill 349 68 4 349 69 4 dirt
execute in minecraft:overworld run setblock 349 70 4 coarse_dirt
execute in minecraft:overworld run fill 349 71 4 349 144 4 air
execute in minecraft:overworld run fill 349 58 5 349 67 5 stone
execute in minecraft:overworld run fill 349 68 5 349 69 5 dirt
execute in minecraft:overworld run setblock 349 70 5 coarse_dirt
execute in minecraft:overworld run fill 349 71 5 349 144 5 air
execute in minecraft:overworld run fill 349 58 6 349 67 6 stone
execute in minecraft:overworld run fill 349 68 6 349 69 6 dirt
execute in minecraft:overworld run setblock 349 70 6 grass_block
execute in minecraft:overworld run fill 349 71 6 349 144 6 air
execute in minecraft:overworld run fill 349 58 7 349 67 7 stone
execute in minecraft:overworld run fill 349 68 7 349 69 7 dirt
execute in minecraft:overworld run setblock 349 70 7 coarse_dirt
execute in minecraft:overworld run fill 349 71 7 349 144 7 air
execute in minecraft:overworld run fill 349 58 8 349 67 8 stone
execute in minecraft:overworld run fill 349 68 8 349 69 8 dirt
execute in minecraft:overworld run setblock 349 70 8 coarse_dirt
execute in minecraft:overworld run fill 349 71 8 349 144 8 air
execute in minecraft:overworld run fill 349 58 9 349 67 9 stone
execute in minecraft:overworld run fill 349 68 9 349 69 9 dirt
execute in minecraft:overworld run setblock 349 70 9 coarse_dirt
execute in minecraft:overworld run fill 349 71 9 349 144 9 air
execute in minecraft:overworld run fill 349 58 10 349 67 10 stone
execute in minecraft:overworld run fill 349 68 10 349 69 10 dirt
execute in minecraft:overworld run setblock 349 70 10 coarse_dirt
execute in minecraft:overworld run fill 349 71 10 349 144 10 air
execute in minecraft:overworld run fill 349 58 11 349 67 11 stone
execute in minecraft:overworld run fill 349 68 11 349 69 11 dirt
execute in minecraft:overworld run setblock 349 70 11 grass_block
execute in minecraft:overworld run fill 349 71 11 349 144 11 air
execute in minecraft:overworld run fill 349 58 12 349 67 12 stone
execute in minecraft:overworld run fill 349 68 12 349 69 12 dirt
execute in minecraft:overworld run setblock 349 70 12 grass_block
execute in minecraft:overworld run fill 349 71 12 349 144 12 air
execute in minecraft:overworld run fill 349 58 13 349 66 13 stone
execute in minecraft:overworld run fill 349 67 13 349 68 13 dirt
execute in minecraft:overworld run setblock 349 69 13 grass_block
execute in minecraft:overworld run fill 349 70 13 349 144 13 air
execute in minecraft:overworld run setblock 349 70 13 grass
execute in minecraft:overworld run fill 349 58 14 349 66 14 stone
execute in minecraft:overworld run fill 349 67 14 349 68 14 dirt
execute in minecraft:overworld run setblock 349 69 14 coarse_dirt
execute in minecraft:overworld run fill 349 70 14 349 144 14 air
execute in minecraft:overworld run fill 349 58 15 349 65 15 stone
execute in minecraft:overworld run fill 349 66 15 349 67 15 dirt
execute in minecraft:overworld run setblock 349 68 15 coarse_dirt
execute in minecraft:overworld run fill 349 69 15 349 144 15 air
execute in minecraft:overworld run fill 349 58 16 349 65 16 stone
execute in minecraft:overworld run fill 349 66 16 349 67 16 dirt
execute in minecraft:overworld run setblock 349 68 16 coarse_dirt
execute in minecraft:overworld run fill 349 69 16 349 144 16 air
execute in minecraft:overworld run fill 349 58 17 349 65 17 stone
execute in minecraft:overworld run fill 349 66 17 349 67 17 dirt
execute in minecraft:overworld run setblock 349 68 17 grass_block
execute in minecraft:overworld run fill 349 69 17 349 144 17 air
execute in minecraft:overworld run fill 349 58 18 349 65 18 stone
execute in minecraft:overworld run fill 349 66 18 349 67 18 dirt
execute in minecraft:overworld run setblock 349 68 18 coarse_dirt
execute in minecraft:overworld run fill 349 69 18 349 144 18 air
execute in minecraft:overworld run fill 349 58 19 349 65 19 stone
execute in minecraft:overworld run fill 349 66 19 349 67 19 dirt
execute in minecraft:overworld run setblock 349 68 19 coarse_dirt
execute in minecraft:overworld run fill 349 69 19 349 144 19 air
execute in minecraft:overworld run fill 349 58 20 349 65 20 stone
execute in minecraft:overworld run fill 349 66 20 349 67 20 dirt
execute in minecraft:overworld run setblock 349 68 20 coarse_dirt
execute in minecraft:overworld run fill 349 69 20 349 144 20 air
execute in minecraft:overworld run setblock 349 69 20 grass
execute in minecraft:overworld run fill 349 58 21 349 66 21 stone
execute in minecraft:overworld run fill 349 67 21 349 68 21 dirt
execute in minecraft:overworld run setblock 349 69 21 coarse_dirt
execute in minecraft:overworld run fill 349 70 21 349 144 21 air
execute in minecraft:overworld run setblock 349 70 21 grass
execute in minecraft:overworld run fill 349 58 22 349 66 22 stone
execute in minecraft:overworld run fill 349 67 22 349 68 22 dirt
execute in minecraft:overworld run setblock 349 69 22 coarse_dirt
execute in minecraft:overworld run fill 349 70 22 349 144 22 air
execute in minecraft:overworld run fill 349 58 23 349 66 23 stone
execute in minecraft:overworld run fill 349 67 23 349 68 23 dirt
execute in minecraft:overworld run setblock 349 69 23 grass_block
execute in minecraft:overworld run fill 349 70 23 349 144 23 air
execute in minecraft:overworld run fill 349 58 24 349 67 24 stone
execute in minecraft:overworld run fill 349 68 24 349 69 24 dirt
execute in minecraft:overworld run setblock 349 70 24 grass_block
execute in minecraft:overworld run fill 349 71 24 349 144 24 air
execute in minecraft:overworld run setblock 349 71 24 grass
execute in minecraft:overworld run fill 349 58 25 349 67 25 stone
execute in minecraft:overworld run fill 349 68 25 349 69 25 dirt
execute in minecraft:overworld run setblock 349 70 25 coarse_dirt
execute in minecraft:overworld run fill 349 71 25 349 144 25 air
execute in minecraft:overworld run fill 349 58 26 349 67 26 stone
execute in minecraft:overworld run fill 349 68 26 349 69 26 dirt
execute in minecraft:overworld run setblock 349 70 26 grass_block
execute in minecraft:overworld run fill 349 71 26 349 144 26 air
execute in minecraft:overworld run fill 349 58 27 349 67 27 stone
execute in minecraft:overworld run fill 349 68 27 349 69 27 dirt
execute in minecraft:overworld run setblock 349 70 27 grass_block
execute in minecraft:overworld run fill 349 71 27 349 144 27 air
execute in minecraft:overworld run fill 349 58 28 349 67 28 stone
execute in minecraft:overworld run fill 349 68 28 349 69 28 dirt
execute in minecraft:overworld run setblock 349 70 28 coarse_dirt
schedule function blade_gallery:random/battlefield/part_21 1t replace
