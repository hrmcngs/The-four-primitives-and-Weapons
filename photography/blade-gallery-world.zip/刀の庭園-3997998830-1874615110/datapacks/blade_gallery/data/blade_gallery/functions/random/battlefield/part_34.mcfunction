execute in minecraft:overworld run fill 358 72 -22 358 73 -22 dirt
execute in minecraft:overworld run setblock 358 74 -22 grass_block
execute in minecraft:overworld run fill 358 75 -22 358 144 -22 air
execute in minecraft:overworld run fill 358 58 -21 358 71 -21 stone
execute in minecraft:overworld run fill 358 72 -21 358 73 -21 dirt
execute in minecraft:overworld run setblock 358 74 -21 grass_block
execute in minecraft:overworld run fill 358 75 -21 358 144 -21 air
execute in minecraft:overworld run fill 358 58 -20 358 71 -20 stone
execute in minecraft:overworld run fill 358 72 -20 358 73 -20 dirt
execute in minecraft:overworld run setblock 358 74 -20 grass_block
execute in minecraft:overworld run fill 358 75 -20 358 144 -20 air
execute in minecraft:overworld run fill 358 58 -19 358 71 -19 stone
execute in minecraft:overworld run fill 358 72 -19 358 73 -19 dirt
execute in minecraft:overworld run setblock 358 74 -19 coarse_dirt
execute in minecraft:overworld run fill 358 75 -19 358 144 -19 air
execute in minecraft:overworld run setblock 358 75 -19 grass
execute in minecraft:overworld run fill 358 58 -18 358 70 -18 stone
execute in minecraft:overworld run fill 358 71 -18 358 72 -18 dirt
execute in minecraft:overworld run setblock 358 73 -18 grass_block
execute in minecraft:overworld run fill 358 74 -18 358 144 -18 air
execute in minecraft:overworld run fill 358 58 -17 358 70 -17 stone
execute in minecraft:overworld run fill 358 71 -17 358 72 -17 dirt
execute in minecraft:overworld run setblock 358 73 -17 grass_block
execute in minecraft:overworld run fill 358 74 -17 358 144 -17 air
execute in minecraft:overworld run fill 358 58 -16 358 69 -16 stone
execute in minecraft:overworld run fill 358 70 -16 358 71 -16 dirt
execute in minecraft:overworld run setblock 358 72 -16 coarse_dirt
execute in minecraft:overworld run fill 358 73 -16 358 144 -16 air
execute in minecraft:overworld run fill 358 58 -15 358 68 -15 stone
execute in minecraft:overworld run fill 358 69 -15 358 70 -15 dirt
execute in minecraft:overworld run setblock 358 71 -15 coarse_dirt
execute in minecraft:overworld run fill 358 72 -15 358 144 -15 air
execute in minecraft:overworld run fill 358 58 -14 358 68 -14 stone
execute in minecraft:overworld run fill 358 69 -14 358 70 -14 dirt
execute in minecraft:overworld run setblock 358 71 -14 coarse_dirt
execute in minecraft:overworld run fill 358 72 -14 358 144 -14 air
execute in minecraft:overworld run fill 358 58 -13 358 67 -13 stone
execute in minecraft:overworld run fill 358 68 -13 358 69 -13 dirt
execute in minecraft:overworld run setblock 358 70 -13 coarse_dirt
execute in minecraft:overworld run fill 358 71 -13 358 144 -13 air
execute in minecraft:overworld run fill 358 58 -12 358 66 -12 stone
execute in minecraft:overworld run fill 358 67 -12 358 68 -12 dirt
execute in minecraft:overworld run setblock 358 69 -12 grass_block
execute in minecraft:overworld run fill 358 70 -12 358 144 -12 air
execute in minecraft:overworld run fill 358 58 -11 358 66 -11 stone
execute in minecraft:overworld run fill 358 67 -11 358 68 -11 dirt
execute in minecraft:overworld run setblock 358 69 -11 grass_block
execute in minecraft:overworld run fill 358 70 -11 358 144 -11 air
execute in minecraft:overworld run fill 358 58 -10 358 65 -10 stone
execute in minecraft:overworld run fill 358 66 -10 358 67 -10 dirt
execute in minecraft:overworld run setblock 358 68 -10 coarse_dirt
execute in minecraft:overworld run fill 358 69 -10 358 144 -10 air
execute in minecraft:overworld run setblock 358 69 -10 grass
execute in minecraft:overworld run fill 358 58 -9 358 65 -9 stone
execute in minecraft:overworld run fill 358 66 -9 358 67 -9 dirt
execute in minecraft:overworld run setblock 358 68 -9 grass_block
execute in minecraft:overworld run fill 358 69 -9 358 144 -9 air
execute in minecraft:overworld run fill 358 58 -8 358 65 -8 stone
execute in minecraft:overworld run fill 358 66 -8 358 67 -8 dirt
execute in minecraft:overworld run setblock 358 68 -8 coarse_dirt
execute in minecraft:overworld run fill 358 69 -8 358 144 -8 air
execute in minecraft:overworld run fill 358 58 -7 358 65 -7 stone
execute in minecraft:overworld run fill 358 66 -7 358 67 -7 dirt
execute in minecraft:overworld run setblock 358 68 -7 grass_block
execute in minecraft:overworld run fill 358 69 -7 358 144 -7 air
execute in minecraft:overworld run setblock 358 69 -7 mossy_cobblestone
execute in minecraft:overworld run fill 358 58 -6 358 65 -6 stone
execute in minecraft:overworld run fill 358 66 -6 358 67 -6 dirt
execute in minecraft:overworld run setblock 358 68 -6 coarse_dirt
execute in minecraft:overworld run fill 358 69 -6 358 144 -6 air
execute in minecraft:overworld run setblock 358 69 -6 grass
execute in minecraft:overworld run fill 358 58 -5 358 65 -5 stone
execute in minecraft:overworld run fill 358 66 -5 358 67 -5 dirt
execute in minecraft:overworld run setblock 358 68 -5 coarse_dirt
execute in minecraft:overworld run fill 358 69 -5 358 144 -5 air
execute in minecraft:overworld run fill 358 58 -4 358 65 -4 stone
execute in minecraft:overworld run fill 358 66 -4 358 67 -4 dirt
execute in minecraft:overworld run setblock 358 68 -4 coarse_dirt
execute in minecraft:overworld run fill 358 69 -4 358 144 -4 air
execute in minecraft:overworld run fill 358 58 -3 358 65 -3 stone
execute in minecraft:overworld run fill 358 66 -3 358 67 -3 dirt
execute in minecraft:overworld run setblock 358 68 -3 grass_block
execute in minecraft:overworld run fill 358 69 -3 358 144 -3 air
execute in minecraft:overworld run fill 358 58 -2 358 65 -2 stone
execute in minecraft:overworld run fill 358 66 -2 358 67 -2 dirt
execute in minecraft:overworld run setblock 358 68 -2 coarse_dirt
execute in minecraft:overworld run fill 358 69 -2 358 144 -2 air
execute in minecraft:overworld run fill 358 58 -1 358 65 -1 stone
execute in minecraft:overworld run fill 358 66 -1 358 67 -1 dirt
execute in minecraft:overworld run setblock 358 68 -1 coarse_dirt
execute in minecraft:overworld run fill 358 69 -1 358 144 -1 air
execute in minecraft:overworld run fill 358 58 0 358 65 0 stone
execute in minecraft:overworld run fill 358 66 0 358 67 0 dirt
execute in minecraft:overworld run setblock 358 68 0 coarse_dirt
execute in minecraft:overworld run fill 358 69 0 358 144 0 air
execute in minecraft:overworld run fill 358 58 1 358 65 1 stone
execute in minecraft:overworld run fill 358 66 1 358 67 1 dirt
execute in minecraft:overworld run setblock 358 68 1 coarse_dirt
execute in minecraft:overworld run fill 358 69 1 358 144 1 air
execute in minecraft:overworld run setblock 358 69 1 grass
execute in minecraft:overworld run fill 358 58 2 358 66 2 stone
execute in minecraft:overworld run fill 358 67 2 358 68 2 dirt
execute in minecraft:overworld run setblock 358 69 2 coarse_dirt
execute in minecraft:overworld run fill 358 70 2 358 144 2 air
execute in minecraft:overworld run fill 358 58 3 358 66 3 stone
execute in minecraft:overworld run fill 358 67 3 358 68 3 dirt
execute in minecraft:overworld run setblock 358 69 3 coarse_dirt
execute in minecraft:overworld run fill 358 70 3 358 144 3 air
execute in minecraft:overworld run fill 358 58 4 358 66 4 stone
execute in minecraft:overworld run fill 358 67 4 358 68 4 dirt
execute in minecraft:overworld run setblock 358 69 4 coarse_dirt
execute in minecraft:overworld run fill 358 70 4 358 144 4 air
execute in minecraft:overworld run fill 358 58 5 358 67 5 stone
execute in minecraft:overworld run fill 358 68 5 358 69 5 dirt
execute in minecraft:overworld run setblock 358 70 5 grass_block
execute in minecraft:overworld run fill 358 71 5 358 144 5 air
execute in minecraft:overworld run fill 358 58 6 358 67 6 stone
execute in minecraft:overworld run fill 358 68 6 358 69 6 dirt
execute in minecraft:overworld run setblock 358 70 6 grass_block
execute in minecraft:overworld run fill 358 71 6 358 144 6 air
execute in minecraft:overworld run fill 358 58 7 358 67 7 stone
execute in minecraft:overworld run fill 358 68 7 358 69 7 dirt
execute in minecraft:overworld run setblock 358 70 7 coarse_dirt
execute in minecraft:overworld run fill 358 71 7 358 144 7 air
execute in minecraft:overworld run fill 358 58 8 358 68 8 stone
execute in minecraft:overworld run fill 358 69 8 358 70 8 dirt
execute in minecraft:overworld run setblock 358 71 8 coarse_dirt
execute in minecraft:overworld run fill 358 72 8 358 144 8 air
execute in minecraft:overworld run fill 358 58 9 358 68 9 stone
execute in minecraft:overworld run fill 358 69 9 358 70 9 dirt
execute in minecraft:overworld run setblock 358 71 9 coarse_dirt
execute in minecraft:overworld run fill 358 72 9 358 144 9 air
execute in minecraft:overworld run fill 358 58 10 358 68 10 stone
execute in minecraft:overworld run fill 358 69 10 358 70 10 dirt
execute in minecraft:overworld run setblock 358 71 10 grass_block
execute in minecraft:overworld run fill 358 72 10 358 144 10 air
execute in minecraft:overworld run fill 358 58 11 358 68 11 stone
execute in minecraft:overworld run fill 358 69 11 358 70 11 dirt
execute in minecraft:overworld run setblock 358 71 11 grass_block
execute in minecraft:overworld run fill 358 72 11 358 144 11 air
execute in minecraft:overworld run setblock 358 72 11 grass
execute in minecraft:overworld run fill 358 58 12 358 68 12 stone
execute in minecraft:overworld run fill 358 69 12 358 70 12 dirt
execute in minecraft:overworld run setblock 358 71 12 grass_block
execute in minecraft:overworld run fill 358 72 12 358 144 12 air
execute in minecraft:overworld run setblock 358 72 12 grass
execute in minecraft:overworld run fill 358 58 13 358 68 13 stone
execute in minecraft:overworld run fill 358 69 13 358 70 13 dirt
execute in minecraft:overworld run setblock 358 71 13 coarse_dirt
execute in minecraft:overworld run fill 358 72 13 358 144 13 air
execute in minecraft:overworld run setblock 358 72 13 grass
execute in minecraft:overworld run fill 358 58 14 358 68 14 stone
execute in minecraft:overworld run fill 358 69 14 358 70 14 dirt
execute in minecraft:overworld run setblock 358 71 14 coarse_dirt
execute in minecraft:overworld run fill 358 72 14 358 144 14 air
execute in minecraft:overworld run fill 358 58 15 358 68 15 stone
execute in minecraft:overworld run fill 358 69 15 358 70 15 dirt
execute in minecraft:overworld run setblock 358 71 15 coarse_dirt
execute in minecraft:overworld run fill 358 72 15 358 144 15 air
execute in minecraft:overworld run fill 358 58 16 358 68 16 stone
execute in minecraft:overworld run fill 358 69 16 358 70 16 dirt
execute in minecraft:overworld run setblock 358 71 16 coarse_dirt
execute in minecraft:overworld run fill 358 72 16 358 144 16 air
execute in minecraft:overworld run fill 358 58 17 358 68 17 stone
execute in minecraft:overworld run fill 358 69 17 358 70 17 dirt
execute in minecraft:overworld run setblock 358 71 17 grass_block
execute in minecraft:overworld run fill 358 72 17 358 144 17 air
execute in minecraft:overworld run fill 358 58 18 358 69 18 stone
execute in minecraft:overworld run fill 358 70 18 358 71 18 dirt
execute in minecraft:overworld run setblock 358 72 18 grass_block
execute in minecraft:overworld run fill 358 73 18 358 144 18 air
execute in minecraft:overworld run fill 358 58 19 358 69 19 stone
execute in minecraft:overworld run fill 358 70 19 358 71 19 dirt
execute in minecraft:overworld run setblock 358 72 19 coarse_dirt
execute in minecraft:overworld run fill 358 73 19 358 144 19 air
execute in minecraft:overworld run fill 358 58 20 358 69 20 stone
execute in minecraft:overworld run fill 358 70 20 358 71 20 dirt
execute in minecraft:overworld run setblock 358 72 20 coarse_dirt
execute in minecraft:overworld run fill 358 73 20 358 144 20 air
execute in minecraft:overworld run fill 358 58 21 358 69 21 stone
execute in minecraft:overworld run fill 358 70 21 358 71 21 dirt
execute in minecraft:overworld run setblock 358 72 21 grass_block
execute in minecraft:overworld run fill 358 73 21 358 144 21 air
execute in minecraft:overworld run fill 358 58 22 358 69 22 stone
execute in minecraft:overworld run fill 358 70 22 358 71 22 dirt
execute in minecraft:overworld run setblock 358 72 22 grass_block
execute in minecraft:overworld run fill 358 73 22 358 144 22 air
execute in minecraft:overworld run setblock 358 73 22 grass
execute in minecraft:overworld run fill 358 58 23 358 69 23 stone
execute in minecraft:overworld run fill 358 70 23 358 71 23 dirt
execute in minecraft:overworld run setblock 358 72 23 grass_block
execute in minecraft:overworld run fill 358 73 23 358 144 23 air
execute in minecraft:overworld run setblock 358 73 23 grass
execute in minecraft:overworld run fill 358 58 24 358 68 24 stone
execute in minecraft:overworld run fill 358 69 24 358 70 24 dirt
execute in minecraft:overworld run setblock 358 71 24 coarse_dirt
execute in minecraft:overworld run fill 358 72 24 358 144 24 air
execute in minecraft:overworld run setblock 358 72 24 grass
execute in minecraft:overworld run fill 358 58 25 358 68 25 stone
execute in minecraft:overworld run fill 358 69 25 358 70 25 dirt
execute in minecraft:overworld run setblock 358 71 25 coarse_dirt
execute in minecraft:overworld run fill 358 72 25 358 144 25 air
execute in minecraft:overworld run fill 358 58 26 358 68 26 stone
execute in minecraft:overworld run fill 358 69 26 358 70 26 dirt
execute in minecraft:overworld run setblock 358 71 26 grass_block
execute in minecraft:overworld run fill 358 72 26 358 144 26 air
execute in minecraft:overworld run fill 358 58 27 358 68 27 stone
execute in minecraft:overworld run fill 358 69 27 358 70 27 dirt
execute in minecraft:overworld run setblock 358 71 27 coarse_dirt
execute in minecraft:overworld run fill 358 72 27 358 144 27 air
execute in minecraft:overworld run fill 358 58 28 358 68 28 stone
execute in minecraft:overworld run fill 358 69 28 358 70 28 dirt
execute in minecraft:overworld run setblock 358 71 28 coarse_dirt
execute in minecraft:overworld run fill 358 72 28 358 144 28 air
execute in minecraft:overworld run fill 358 58 29 358 68 29 stone
execute in minecraft:overworld run fill 358 69 29 358 70 29 dirt
execute in minecraft:overworld run setblock 358 71 29 coarse_dirt
execute in minecraft:overworld run fill 358 72 29 358 144 29 air
execute in minecraft:overworld run fill 358 58 30 358 68 30 stone
execute in minecraft:overworld run fill 358 69 30 358 70 30 dirt
execute in minecraft:overworld run setblock 358 71 30 coarse_dirt
execute in minecraft:overworld run fill 358 72 30 358 144 30 air
execute in minecraft:overworld run fill 358 58 31 358 69 31 stone
execute in minecraft:overworld run fill 358 70 31 358 71 31 dirt
execute in minecraft:overworld run setblock 358 72 31 coarse_dirt
execute in minecraft:overworld run fill 358 73 31 358 144 31 air
execute in minecraft:overworld run fill 358 58 32 358 69 32 stone
execute in minecraft:overworld run fill 358 70 32 358 71 32 dirt
execute in minecraft:overworld run setblock 358 72 32 grass_block
execute in minecraft:overworld run fill 358 73 32 358 144 32 air
execute in minecraft:overworld run fill 358 58 33 358 69 33 stone
execute in minecraft:overworld run fill 358 70 33 358 71 33 dirt
execute in minecraft:overworld run setblock 358 72 33 coarse_dirt
execute in minecraft:overworld run fill 358 73 33 358 144 33 air
execute in minecraft:overworld run fill 358 58 34 358 69 34 stone
execute in minecraft:overworld run fill 358 70 34 358 71 34 dirt
execute in minecraft:overworld run setblock 358 72 34 coarse_dirt
execute in minecraft:overworld run fill 358 73 34 358 144 34 air
execute in minecraft:overworld run fill 358 58 35 358 69 35 stone
execute in minecraft:overworld run fill 358 70 35 358 71 35 dirt
execute in minecraft:overworld run setblock 358 72 35 coarse_dirt
execute in minecraft:overworld run fill 358 73 35 358 144 35 air
execute in minecraft:overworld run setblock 358 73 35 mossy_cobblestone
execute in minecraft:overworld run fill 358 58 36 358 69 36 stone
execute in minecraft:overworld run fill 358 70 36 358 71 36 dirt
execute in minecraft:overworld run setblock 358 72 36 coarse_dirt
execute in minecraft:overworld run fill 358 73 36 358 144 36 air
execute in minecraft:overworld run fill 358 58 37 358 69 37 stone
execute in minecraft:overworld run fill 358 70 37 358 71 37 dirt
execute in minecraft:overworld run setblock 358 72 37 coarse_dirt
execute in minecraft:overworld run fill 358 73 37 358 144 37 air
execute in minecraft:overworld run setblock 358 73 37 grass
execute in minecraft:overworld run fill 358 58 38 358 69 38 stone
execute in minecraft:overworld run fill 358 70 38 358 71 38 dirt
execute in minecraft:overworld run setblock 358 72 38 coarse_dirt
execute in minecraft:overworld run fill 358 73 38 358 144 38 air
schedule function blade_gallery:random/battlefield/part_35 1t replace
