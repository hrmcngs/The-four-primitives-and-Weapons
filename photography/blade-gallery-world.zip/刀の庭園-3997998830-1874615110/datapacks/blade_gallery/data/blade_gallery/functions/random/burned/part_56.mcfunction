execute in minecraft:overworld run setblock 244 64 0 coarse_dirt
execute in minecraft:overworld run fill 244 65 0 244 144 0 air
execute in minecraft:overworld run fill 244 58 1 244 61 1 stone
execute in minecraft:overworld run fill 244 62 1 244 63 1 dirt
execute in minecraft:overworld run setblock 244 64 1 grass_block
execute in minecraft:overworld run fill 244 65 1 244 144 1 air
execute in minecraft:overworld run fill 244 58 2 244 62 2 stone
execute in minecraft:overworld run fill 244 63 2 244 64 2 dirt
execute in minecraft:overworld run setblock 244 65 2 coarse_dirt
execute in minecraft:overworld run fill 244 66 2 244 144 2 air
execute in minecraft:overworld run fill 244 58 3 244 62 3 stone
execute in minecraft:overworld run fill 244 63 3 244 64 3 dirt
execute in minecraft:overworld run setblock 244 65 3 grass_block
execute in minecraft:overworld run fill 244 66 3 244 144 3 air
execute in minecraft:overworld run fill 244 58 4 244 62 4 stone
execute in minecraft:overworld run fill 244 63 4 244 64 4 dirt
execute in minecraft:overworld run setblock 244 65 4 coarse_dirt
execute in minecraft:overworld run fill 244 66 4 244 144 4 air
execute in minecraft:overworld run fill 244 58 5 244 63 5 stone
execute in minecraft:overworld run fill 244 64 5 244 65 5 dirt
execute in minecraft:overworld run setblock 244 66 5 coarse_dirt
execute in minecraft:overworld run fill 244 67 5 244 144 5 air
execute in minecraft:overworld run fill 244 58 6 244 63 6 stone
execute in minecraft:overworld run fill 244 64 6 244 65 6 dirt
execute in minecraft:overworld run setblock 244 66 6 coarse_dirt
execute in minecraft:overworld run fill 244 67 6 244 144 6 air
execute in minecraft:overworld run fill 244 58 7 244 64 7 stone
execute in minecraft:overworld run fill 244 65 7 244 66 7 dirt
execute in minecraft:overworld run setblock 244 67 7 coarse_dirt
execute in minecraft:overworld run fill 244 68 7 244 144 7 air
execute in minecraft:overworld run fill 244 58 8 244 64 8 stone
execute in minecraft:overworld run fill 244 65 8 244 66 8 dirt
execute in minecraft:overworld run setblock 244 67 8 coarse_dirt
execute in minecraft:overworld run fill 244 68 8 244 144 8 air
execute in minecraft:overworld run fill 244 58 9 244 64 9 stone
execute in minecraft:overworld run fill 244 65 9 244 66 9 dirt
execute in minecraft:overworld run setblock 244 67 9 grass_block
execute in minecraft:overworld run fill 244 68 9 244 144 9 air
execute in minecraft:overworld run setblock 244 68 9 grass
execute in minecraft:overworld run fill 244 58 10 244 65 10 stone
execute in minecraft:overworld run fill 244 66 10 244 67 10 dirt
execute in minecraft:overworld run setblock 244 68 10 grass_block
execute in minecraft:overworld run fill 244 69 10 244 144 10 air
execute in minecraft:overworld run fill 244 58 11 244 65 11 stone
execute in minecraft:overworld run fill 244 66 11 244 67 11 dirt
execute in minecraft:overworld run setblock 244 68 11 coarse_dirt
execute in minecraft:overworld run fill 244 69 11 244 144 11 air
execute in minecraft:overworld run fill 244 58 12 244 65 12 stone
execute in minecraft:overworld run fill 244 66 12 244 67 12 dirt
execute in minecraft:overworld run setblock 244 68 12 grass_block
execute in minecraft:overworld run fill 244 69 12 244 144 12 air
execute in minecraft:overworld run fill 244 58 13 244 65 13 stone
execute in minecraft:overworld run fill 244 66 13 244 67 13 dirt
execute in minecraft:overworld run setblock 244 68 13 coarse_dirt
execute in minecraft:overworld run fill 244 69 13 244 144 13 air
execute in minecraft:overworld run fill 244 58 14 244 65 14 stone
execute in minecraft:overworld run fill 244 66 14 244 67 14 dirt
execute in minecraft:overworld run setblock 244 68 14 coarse_dirt
execute in minecraft:overworld run fill 244 69 14 244 144 14 air
execute in minecraft:overworld run fill 244 58 15 244 65 15 stone
execute in minecraft:overworld run fill 244 66 15 244 67 15 dirt
execute in minecraft:overworld run setblock 244 68 15 coarse_dirt
execute in minecraft:overworld run fill 244 69 15 244 144 15 air
execute in minecraft:overworld run fill 244 58 16 244 65 16 stone
execute in minecraft:overworld run fill 244 66 16 244 67 16 dirt
execute in minecraft:overworld run setblock 244 68 16 coarse_dirt
execute in minecraft:overworld run fill 244 69 16 244 144 16 air
execute in minecraft:overworld run fill 244 58 17 244 65 17 stone
execute in minecraft:overworld run fill 244 66 17 244 67 17 dirt
execute in minecraft:overworld run setblock 244 68 17 grass_block
execute in minecraft:overworld run fill 244 69 17 244 144 17 air
execute in minecraft:overworld run fill 244 58 18 244 65 18 stone
execute in minecraft:overworld run fill 244 66 18 244 67 18 dirt
execute in minecraft:overworld run setblock 244 68 18 coarse_dirt
execute in minecraft:overworld run fill 244 69 18 244 144 18 air
execute in minecraft:overworld run fill 244 58 19 244 66 19 stone
execute in minecraft:overworld run fill 244 67 19 244 68 19 dirt
execute in minecraft:overworld run setblock 244 69 19 grass_block
execute in minecraft:overworld run fill 244 70 19 244 144 19 air
execute in minecraft:overworld run fill 244 58 20 244 66 20 stone
execute in minecraft:overworld run fill 244 67 20 244 68 20 dirt
execute in minecraft:overworld run setblock 244 69 20 grass_block
execute in minecraft:overworld run fill 244 70 20 244 144 20 air
execute in minecraft:overworld run fill 244 58 21 244 66 21 stone
execute in minecraft:overworld run fill 244 67 21 244 68 21 dirt
execute in minecraft:overworld run setblock 244 69 21 coarse_dirt
execute in minecraft:overworld run fill 244 70 21 244 144 21 air
execute in minecraft:overworld run fill 244 58 22 244 66 22 stone
execute in minecraft:overworld run fill 244 67 22 244 68 22 dirt
execute in minecraft:overworld run setblock 244 69 22 coarse_dirt
execute in minecraft:overworld run fill 244 70 22 244 144 22 air
execute in minecraft:overworld run fill 244 58 23 244 66 23 stone
execute in minecraft:overworld run fill 244 67 23 244 68 23 dirt
execute in minecraft:overworld run setblock 244 69 23 grass_block
execute in minecraft:overworld run fill 244 70 23 244 144 23 air
execute in minecraft:overworld run fill 244 58 24 244 66 24 stone
execute in minecraft:overworld run fill 244 67 24 244 68 24 dirt
execute in minecraft:overworld run setblock 244 69 24 grass_block
execute in minecraft:overworld run fill 244 70 24 244 144 24 air
execute in minecraft:overworld run fill 244 58 25 244 66 25 stone
execute in minecraft:overworld run fill 244 67 25 244 68 25 dirt
execute in minecraft:overworld run setblock 244 69 25 coarse_dirt
execute in minecraft:overworld run fill 244 70 25 244 144 25 air
execute in minecraft:overworld run fill 244 58 26 244 66 26 stone
execute in minecraft:overworld run fill 244 67 26 244 68 26 dirt
execute in minecraft:overworld run setblock 244 69 26 coarse_dirt
execute in minecraft:overworld run fill 244 70 26 244 144 26 air
execute in minecraft:overworld run fill 244 58 27 244 66 27 stone
execute in minecraft:overworld run fill 244 67 27 244 68 27 dirt
execute in minecraft:overworld run setblock 244 69 27 grass_block
execute in minecraft:overworld run fill 244 70 27 244 144 27 air
execute in minecraft:overworld run fill 244 58 28 244 66 28 stone
execute in minecraft:overworld run fill 244 67 28 244 68 28 dirt
execute in minecraft:overworld run setblock 244 69 28 coarse_dirt
execute in minecraft:overworld run fill 244 70 28 244 144 28 air
execute in minecraft:overworld run fill 244 58 29 244 66 29 stone
execute in minecraft:overworld run fill 244 67 29 244 68 29 dirt
execute in minecraft:overworld run setblock 244 69 29 coarse_dirt
execute in minecraft:overworld run fill 244 70 29 244 144 29 air
execute in minecraft:overworld run fill 244 58 30 244 66 30 stone
execute in minecraft:overworld run fill 244 67 30 244 68 30 dirt
execute in minecraft:overworld run setblock 244 69 30 coarse_dirt
execute in minecraft:overworld run fill 244 70 30 244 144 30 air
execute in minecraft:overworld run fill 244 58 31 244 65 31 stone
execute in minecraft:overworld run fill 244 66 31 244 67 31 dirt
execute in minecraft:overworld run setblock 244 68 31 grass_block
execute in minecraft:overworld run fill 244 69 31 244 144 31 air
execute in minecraft:overworld run fill 244 58 32 244 65 32 stone
execute in minecraft:overworld run fill 244 66 32 244 67 32 dirt
execute in minecraft:overworld run setblock 244 68 32 coarse_dirt
execute in minecraft:overworld run fill 244 69 32 244 144 32 air
execute in minecraft:overworld run fill 244 58 33 244 65 33 stone
execute in minecraft:overworld run fill 244 66 33 244 67 33 dirt
execute in minecraft:overworld run setblock 244 68 33 coarse_dirt
execute in minecraft:overworld run fill 244 69 33 244 144 33 air
execute in minecraft:overworld run fill 244 58 34 244 65 34 stone
execute in minecraft:overworld run fill 244 66 34 244 67 34 dirt
execute in minecraft:overworld run setblock 244 68 34 coarse_dirt
execute in minecraft:overworld run fill 244 69 34 244 144 34 air
execute in minecraft:overworld run fill 244 58 35 244 64 35 stone
execute in minecraft:overworld run fill 244 65 35 244 66 35 dirt
execute in minecraft:overworld run setblock 244 67 35 grass_block
execute in minecraft:overworld run fill 244 68 35 244 144 35 air
execute in minecraft:overworld run fill 244 58 36 244 64 36 stone
execute in minecraft:overworld run fill 244 65 36 244 66 36 dirt
execute in minecraft:overworld run setblock 244 67 36 grass_block
execute in minecraft:overworld run fill 244 68 36 244 144 36 air
execute in minecraft:overworld run fill 244 58 37 244 64 37 stone
execute in minecraft:overworld run fill 244 65 37 244 66 37 dirt
execute in minecraft:overworld run setblock 244 67 37 grass_block
execute in minecraft:overworld run fill 244 68 37 244 144 37 air
execute in minecraft:overworld run fill 244 58 38 244 64 38 stone
execute in minecraft:overworld run fill 244 65 38 244 66 38 dirt
execute in minecraft:overworld run setblock 244 67 38 grass_block
execute in minecraft:overworld run fill 244 68 38 244 144 38 air
execute in minecraft:overworld run fill 244 58 39 244 64 39 stone
execute in minecraft:overworld run fill 244 65 39 244 66 39 dirt
execute in minecraft:overworld run setblock 244 67 39 grass_block
execute in minecraft:overworld run fill 244 68 39 244 144 39 air
execute in minecraft:overworld run fill 244 58 40 244 63 40 stone
execute in minecraft:overworld run fill 244 64 40 244 65 40 dirt
execute in minecraft:overworld run setblock 244 66 40 grass_block
execute in minecraft:overworld run fill 244 67 40 244 144 40 air
execute in minecraft:overworld run fill 244 58 41 244 63 41 stone
execute in minecraft:overworld run fill 244 64 41 244 65 41 dirt
execute in minecraft:overworld run setblock 244 66 41 coarse_dirt
execute in minecraft:overworld run fill 244 67 41 244 144 41 air
execute in minecraft:overworld run fill 244 58 42 244 63 42 stone
execute in minecraft:overworld run fill 244 64 42 244 65 42 dirt
execute in minecraft:overworld run setblock 244 66 42 grass_block
execute in minecraft:overworld run fill 244 67 42 244 144 42 air
execute in minecraft:overworld run fill 244 58 43 244 62 43 stone
execute in minecraft:overworld run fill 244 63 43 244 64 43 dirt
execute in minecraft:overworld run setblock 244 65 43 coarse_dirt
execute in minecraft:overworld run fill 244 66 43 244 144 43 air
execute in minecraft:overworld run fill 244 58 44 244 62 44 stone
execute in minecraft:overworld run fill 244 63 44 244 64 44 dirt
execute in minecraft:overworld run setblock 244 65 44 grass_block
execute in minecraft:overworld run fill 244 66 44 244 144 44 air
execute in minecraft:overworld run fill 244 58 45 244 62 45 stone
execute in minecraft:overworld run fill 244 63 45 244 64 45 dirt
execute in minecraft:overworld run setblock 244 65 45 coarse_dirt
execute in minecraft:overworld run fill 244 66 45 244 144 45 air
execute in minecraft:overworld run fill 244 58 46 244 61 46 stone
execute in minecraft:overworld run fill 244 62 46 244 63 46 dirt
execute in minecraft:overworld run setblock 244 64 46 grass_block
execute in minecraft:overworld run fill 244 65 46 244 144 46 air
execute in minecraft:overworld run fill 244 58 47 244 61 47 stone
execute in minecraft:overworld run fill 244 62 47 244 63 47 dirt
execute in minecraft:overworld run setblock 244 64 47 grass_block
execute in minecraft:overworld run fill 244 65 47 244 144 47 air
execute in minecraft:overworld run fill 245 58 -48 245 61 -48 stone
execute in minecraft:overworld run fill 245 62 -48 245 63 -48 dirt
execute in minecraft:overworld run setblock 245 64 -48 coarse_dirt
execute in minecraft:overworld run fill 245 65 -48 245 144 -48 air
execute in minecraft:overworld run fill 245 58 -47 245 62 -47 stone
execute in minecraft:overworld run fill 245 63 -47 245 64 -47 dirt
execute in minecraft:overworld run setblock 245 65 -47 coarse_dirt
execute in minecraft:overworld run fill 245 66 -47 245 144 -47 air
execute in minecraft:overworld run fill 245 58 -46 245 63 -46 stone
execute in minecraft:overworld run fill 245 64 -46 245 65 -46 dirt
execute in minecraft:overworld run setblock 245 66 -46 coarse_dirt
execute in minecraft:overworld run fill 245 67 -46 245 144 -46 air
execute in minecraft:overworld run fill 245 58 -45 245 63 -45 stone
execute in minecraft:overworld run fill 245 64 -45 245 65 -45 dirt
execute in minecraft:overworld run setblock 245 66 -45 coarse_dirt
execute in minecraft:overworld run fill 245 67 -45 245 144 -45 air
execute in minecraft:overworld run fill 245 58 -44 245 64 -44 stone
execute in minecraft:overworld run fill 245 65 -44 245 66 -44 dirt
execute in minecraft:overworld run setblock 245 67 -44 coarse_dirt
execute in minecraft:overworld run fill 245 68 -44 245 144 -44 air
execute in minecraft:overworld run fill 245 58 -43 245 65 -43 stone
execute in minecraft:overworld run fill 245 66 -43 245 67 -43 dirt
execute in minecraft:overworld run setblock 245 68 -43 coarse_dirt
execute in minecraft:overworld run fill 245 69 -43 245 144 -43 air
execute in minecraft:overworld run fill 245 58 -42 245 66 -42 stone
execute in minecraft:overworld run fill 245 67 -42 245 68 -42 dirt
execute in minecraft:overworld run setblock 245 69 -42 grass_block
execute in minecraft:overworld run fill 245 70 -42 245 144 -42 air
execute in minecraft:overworld run fill 245 58 -41 245 66 -41 stone
execute in minecraft:overworld run fill 245 67 -41 245 68 -41 dirt
execute in minecraft:overworld run setblock 245 69 -41 grass_block
execute in minecraft:overworld run fill 245 70 -41 245 144 -41 air
execute in minecraft:overworld run fill 245 58 -40 245 67 -40 stone
execute in minecraft:overworld run fill 245 68 -40 245 69 -40 dirt
execute in minecraft:overworld run setblock 245 70 -40 grass_block
execute in minecraft:overworld run fill 245 71 -40 245 144 -40 air
execute in minecraft:overworld run setblock 245 71 -40 grass
execute in minecraft:overworld run fill 245 58 -39 245 68 -39 stone
execute in minecraft:overworld run fill 245 69 -39 245 70 -39 dirt
execute in minecraft:overworld run setblock 245 71 -39 coarse_dirt
execute in minecraft:overworld run fill 245 72 -39 245 144 -39 air
execute in minecraft:overworld run fill 245 58 -38 245 68 -38 stone
execute in minecraft:overworld run fill 245 69 -38 245 70 -38 dirt
execute in minecraft:overworld run setblock 245 71 -38 coarse_dirt
execute in minecraft:overworld run fill 245 72 -38 245 144 -38 air
execute in minecraft:overworld run setblock 245 72 -38 grass
execute in minecraft:overworld run fill 245 58 -37 245 68 -37 stone
execute in minecraft:overworld run fill 245 69 -37 245 70 -37 dirt
execute in minecraft:overworld run setblock 245 71 -37 coarse_dirt
execute in minecraft:overworld run fill 245 72 -37 245 144 -37 air
execute in minecraft:overworld run fill 245 58 -36 245 69 -36 stone
execute in minecraft:overworld run fill 245 70 -36 245 71 -36 dirt
execute in minecraft:overworld run setblock 245 72 -36 grass_block
execute in minecraft:overworld run fill 245 73 -36 245 144 -36 air
execute in minecraft:overworld run fill 245 58 -35 245 69 -35 stone
execute in minecraft:overworld run fill 245 70 -35 245 71 -35 dirt
execute in minecraft:overworld run setblock 245 72 -35 grass_block
execute in minecraft:overworld run fill 245 73 -35 245 144 -35 air
execute in minecraft:overworld run fill 245 58 -34 245 69 -34 stone
execute in minecraft:overworld run fill 245 70 -34 245 71 -34 dirt
execute in minecraft:overworld run setblock 245 72 -34 coarse_dirt
execute in minecraft:overworld run fill 245 73 -34 245 144 -34 air
execute in minecraft:overworld run fill 245 58 -33 245 69 -33 stone
execute in minecraft:overworld run fill 245 70 -33 245 71 -33 dirt
execute in minecraft:overworld run setblock 245 72 -33 coarse_dirt
schedule function blade_gallery:random/burned/part_57 1t replace
