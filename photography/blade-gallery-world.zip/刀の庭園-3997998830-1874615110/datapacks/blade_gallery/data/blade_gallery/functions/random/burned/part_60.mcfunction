execute in minecraft:overworld run fill 247 71 -39 247 144 -39 air
execute in minecraft:overworld run fill 247 58 -38 247 68 -38 stone
execute in minecraft:overworld run fill 247 69 -38 247 70 -38 dirt
execute in minecraft:overworld run setblock 247 71 -38 coarse_dirt
execute in minecraft:overworld run fill 247 72 -38 247 144 -38 air
execute in minecraft:overworld run fill 247 58 -37 247 68 -37 stone
execute in minecraft:overworld run fill 247 69 -37 247 70 -37 dirt
execute in minecraft:overworld run setblock 247 71 -37 grass_block
execute in minecraft:overworld run fill 247 72 -37 247 144 -37 air
execute in minecraft:overworld run fill 247 58 -36 247 68 -36 stone
execute in minecraft:overworld run fill 247 69 -36 247 70 -36 dirt
execute in minecraft:overworld run setblock 247 71 -36 grass_block
execute in minecraft:overworld run fill 247 72 -36 247 144 -36 air
execute in minecraft:overworld run fill 247 58 -35 247 68 -35 stone
execute in minecraft:overworld run fill 247 69 -35 247 70 -35 dirt
execute in minecraft:overworld run setblock 247 71 -35 coarse_dirt
execute in minecraft:overworld run fill 247 72 -35 247 144 -35 air
execute in minecraft:overworld run fill 247 58 -34 247 68 -34 stone
execute in minecraft:overworld run fill 247 69 -34 247 70 -34 dirt
execute in minecraft:overworld run setblock 247 71 -34 coarse_dirt
execute in minecraft:overworld run fill 247 72 -34 247 144 -34 air
execute in minecraft:overworld run fill 247 58 -33 247 68 -33 stone
execute in minecraft:overworld run fill 247 69 -33 247 70 -33 dirt
execute in minecraft:overworld run setblock 247 71 -33 coarse_dirt
execute in minecraft:overworld run fill 247 72 -33 247 144 -33 air
execute in minecraft:overworld run fill 247 58 -32 247 69 -32 stone
execute in minecraft:overworld run fill 247 70 -32 247 71 -32 dirt
execute in minecraft:overworld run setblock 247 72 -32 grass_block
execute in minecraft:overworld run fill 247 73 -32 247 144 -32 air
execute in minecraft:overworld run fill 247 58 -31 247 69 -31 stone
execute in minecraft:overworld run fill 247 70 -31 247 71 -31 dirt
execute in minecraft:overworld run setblock 247 72 -31 coarse_dirt
execute in minecraft:overworld run fill 247 73 -31 247 144 -31 air
execute in minecraft:overworld run fill 247 58 -30 247 69 -30 stone
execute in minecraft:overworld run fill 247 70 -30 247 71 -30 dirt
execute in minecraft:overworld run setblock 247 72 -30 coarse_dirt
execute in minecraft:overworld run fill 247 73 -30 247 144 -30 air
execute in minecraft:overworld run fill 247 58 -29 247 69 -29 stone
execute in minecraft:overworld run fill 247 70 -29 247 71 -29 dirt
execute in minecraft:overworld run setblock 247 72 -29 coarse_dirt
execute in minecraft:overworld run fill 247 73 -29 247 144 -29 air
execute in minecraft:overworld run fill 247 58 -28 247 70 -28 stone
execute in minecraft:overworld run fill 247 71 -28 247 72 -28 dirt
execute in minecraft:overworld run setblock 247 73 -28 coarse_dirt
execute in minecraft:overworld run fill 247 74 -28 247 144 -28 air
execute in minecraft:overworld run setblock 247 74 -28 grass
execute in minecraft:overworld run fill 247 58 -27 247 70 -27 stone
execute in minecraft:overworld run fill 247 71 -27 247 72 -27 dirt
execute in minecraft:overworld run setblock 247 73 -27 grass_block
execute in minecraft:overworld run fill 247 74 -27 247 144 -27 air
execute in minecraft:overworld run fill 247 58 -26 247 70 -26 stone
execute in minecraft:overworld run fill 247 71 -26 247 72 -26 dirt
execute in minecraft:overworld run setblock 247 73 -26 grass_block
execute in minecraft:overworld run fill 247 74 -26 247 144 -26 air
execute in minecraft:overworld run fill 247 58 -25 247 70 -25 stone
execute in minecraft:overworld run fill 247 71 -25 247 72 -25 dirt
execute in minecraft:overworld run setblock 247 73 -25 coarse_dirt
execute in minecraft:overworld run fill 247 74 -25 247 144 -25 air
execute in minecraft:overworld run setblock 247 74 -25 grass
execute in minecraft:overworld run fill 247 58 -24 247 69 -24 stone
execute in minecraft:overworld run fill 247 70 -24 247 71 -24 dirt
execute in minecraft:overworld run setblock 247 72 -24 grass_block
execute in minecraft:overworld run fill 247 73 -24 247 144 -24 air
execute in minecraft:overworld run setblock 247 73 -24 mossy_cobblestone
execute in minecraft:overworld run fill 247 58 -23 247 69 -23 stone
execute in minecraft:overworld run fill 247 70 -23 247 71 -23 dirt
execute in minecraft:overworld run setblock 247 72 -23 coarse_dirt
execute in minecraft:overworld run fill 247 73 -23 247 144 -23 air
execute in minecraft:overworld run fill 247 58 -22 247 69 -22 stone
execute in minecraft:overworld run fill 247 70 -22 247 71 -22 dirt
execute in minecraft:overworld run setblock 247 72 -22 coarse_dirt
execute in minecraft:overworld run fill 247 73 -22 247 144 -22 air
execute in minecraft:overworld run fill 247 58 -21 247 68 -21 stone
execute in minecraft:overworld run fill 247 69 -21 247 70 -21 dirt
execute in minecraft:overworld run setblock 247 71 -21 coarse_dirt
execute in minecraft:overworld run fill 247 72 -21 247 144 -21 air
execute in minecraft:overworld run fill 247 58 -20 247 68 -20 stone
execute in minecraft:overworld run fill 247 69 -20 247 70 -20 dirt
execute in minecraft:overworld run setblock 247 71 -20 coarse_dirt
execute in minecraft:overworld run fill 247 72 -20 247 144 -20 air
execute in minecraft:overworld run fill 247 58 -19 247 67 -19 stone
execute in minecraft:overworld run fill 247 68 -19 247 69 -19 dirt
execute in minecraft:overworld run setblock 247 70 -19 grass_block
execute in minecraft:overworld run fill 247 71 -19 247 144 -19 air
execute in minecraft:overworld run fill 247 58 -18 247 67 -18 stone
execute in minecraft:overworld run fill 247 68 -18 247 69 -18 dirt
execute in minecraft:overworld run setblock 247 70 -18 coarse_dirt
execute in minecraft:overworld run fill 247 71 -18 247 144 -18 air
execute in minecraft:overworld run fill 247 58 -17 247 66 -17 stone
execute in minecraft:overworld run fill 247 67 -17 247 68 -17 dirt
execute in minecraft:overworld run setblock 247 69 -17 coarse_dirt
execute in minecraft:overworld run fill 247 70 -17 247 144 -17 air
execute in minecraft:overworld run fill 247 58 -16 247 66 -16 stone
execute in minecraft:overworld run fill 247 67 -16 247 68 -16 dirt
execute in minecraft:overworld run setblock 247 69 -16 coarse_dirt
execute in minecraft:overworld run fill 247 70 -16 247 144 -16 air
execute in minecraft:overworld run fill 247 58 -15 247 65 -15 stone
execute in minecraft:overworld run fill 247 66 -15 247 67 -15 dirt
execute in minecraft:overworld run setblock 247 68 -15 grass_block
execute in minecraft:overworld run fill 247 69 -15 247 144 -15 air
execute in minecraft:overworld run fill 247 58 -14 247 65 -14 stone
execute in minecraft:overworld run fill 247 66 -14 247 67 -14 dirt
execute in minecraft:overworld run setblock 247 68 -14 coarse_dirt
execute in minecraft:overworld run fill 247 69 -14 247 144 -14 air
execute in minecraft:overworld run fill 247 58 -13 247 64 -13 stone
execute in minecraft:overworld run fill 247 65 -13 247 66 -13 dirt
execute in minecraft:overworld run setblock 247 67 -13 grass_block
execute in minecraft:overworld run fill 247 68 -13 247 144 -13 air
execute in minecraft:overworld run fill 247 58 -12 247 64 -12 stone
execute in minecraft:overworld run fill 247 65 -12 247 66 -12 dirt
execute in minecraft:overworld run setblock 247 67 -12 coarse_dirt
execute in minecraft:overworld run fill 247 68 -12 247 144 -12 air
execute in minecraft:overworld run fill 247 58 -11 247 64 -11 stone
execute in minecraft:overworld run fill 247 65 -11 247 66 -11 dirt
execute in minecraft:overworld run setblock 247 67 -11 coarse_dirt
execute in minecraft:overworld run fill 247 68 -11 247 144 -11 air
execute in minecraft:overworld run fill 247 58 -10 247 64 -10 stone
execute in minecraft:overworld run fill 247 65 -10 247 66 -10 dirt
execute in minecraft:overworld run setblock 247 67 -10 coarse_dirt
execute in minecraft:overworld run fill 247 68 -10 247 144 -10 air
execute in minecraft:overworld run fill 247 58 -9 247 63 -9 stone
execute in minecraft:overworld run fill 247 64 -9 247 65 -9 dirt
execute in minecraft:overworld run setblock 247 66 -9 coarse_dirt
execute in minecraft:overworld run fill 247 67 -9 247 144 -9 air
execute in minecraft:overworld run fill 247 58 -8 247 63 -8 stone
execute in minecraft:overworld run fill 247 64 -8 247 65 -8 dirt
execute in minecraft:overworld run setblock 247 66 -8 coarse_dirt
execute in minecraft:overworld run fill 247 67 -8 247 144 -8 air
execute in minecraft:overworld run fill 247 58 -7 247 62 -7 stone
execute in minecraft:overworld run fill 247 63 -7 247 64 -7 dirt
execute in minecraft:overworld run setblock 247 65 -7 grass_block
execute in minecraft:overworld run fill 247 66 -7 247 144 -7 air
execute in minecraft:overworld run fill 247 58 -6 247 62 -6 stone
execute in minecraft:overworld run fill 247 63 -6 247 64 -6 dirt
execute in minecraft:overworld run setblock 247 65 -6 coarse_dirt
execute in minecraft:overworld run fill 247 66 -6 247 144 -6 air
execute in minecraft:overworld run fill 247 58 -5 247 62 -5 stone
execute in minecraft:overworld run fill 247 63 -5 247 64 -5 dirt
execute in minecraft:overworld run setblock 247 65 -5 grass_block
execute in minecraft:overworld run fill 247 66 -5 247 144 -5 air
execute in minecraft:overworld run fill 247 58 -4 247 61 -4 stone
execute in minecraft:overworld run fill 247 62 -4 247 63 -4 dirt
execute in minecraft:overworld run setblock 247 64 -4 coarse_dirt
execute in minecraft:overworld run fill 247 65 -4 247 144 -4 air
execute in minecraft:overworld run fill 247 58 -3 247 61 -3 stone
execute in minecraft:overworld run fill 247 62 -3 247 63 -3 dirt
execute in minecraft:overworld run setblock 247 64 -3 coarse_dirt
execute in minecraft:overworld run fill 247 65 -3 247 144 -3 air
execute in minecraft:overworld run fill 247 58 -2 247 61 -2 stone
execute in minecraft:overworld run fill 247 62 -2 247 63 -2 dirt
execute in minecraft:overworld run setblock 247 64 -2 coarse_dirt
execute in minecraft:overworld run fill 247 65 -2 247 144 -2 air
execute in minecraft:overworld run fill 247 58 -1 247 61 -1 stone
execute in minecraft:overworld run fill 247 62 -1 247 63 -1 dirt
execute in minecraft:overworld run setblock 247 64 -1 coarse_dirt
execute in minecraft:overworld run fill 247 65 -1 247 144 -1 air
execute in minecraft:overworld run fill 247 58 0 247 61 0 stone
execute in minecraft:overworld run fill 247 62 0 247 63 0 dirt
execute in minecraft:overworld run setblock 247 64 0 coarse_dirt
execute in minecraft:overworld run fill 247 65 0 247 144 0 air
execute in minecraft:overworld run fill 247 58 1 247 61 1 stone
execute in minecraft:overworld run fill 247 62 1 247 63 1 dirt
execute in minecraft:overworld run setblock 247 64 1 coarse_dirt
execute in minecraft:overworld run fill 247 65 1 247 144 1 air
execute in minecraft:overworld run fill 247 58 2 247 61 2 stone
execute in minecraft:overworld run fill 247 62 2 247 63 2 dirt
execute in minecraft:overworld run setblock 247 64 2 coarse_dirt
execute in minecraft:overworld run fill 247 65 2 247 144 2 air
execute in minecraft:overworld run fill 247 58 3 247 61 3 stone
execute in minecraft:overworld run fill 247 62 3 247 63 3 dirt
execute in minecraft:overworld run setblock 247 64 3 grass_block
execute in minecraft:overworld run fill 247 65 3 247 144 3 air
execute in minecraft:overworld run fill 247 58 4 247 62 4 stone
execute in minecraft:overworld run fill 247 63 4 247 64 4 dirt
execute in minecraft:overworld run setblock 247 65 4 coarse_dirt
execute in minecraft:overworld run fill 247 66 4 247 144 4 air
execute in minecraft:overworld run fill 247 58 5 247 62 5 stone
execute in minecraft:overworld run fill 247 63 5 247 64 5 dirt
execute in minecraft:overworld run setblock 247 65 5 coarse_dirt
execute in minecraft:overworld run fill 247 66 5 247 144 5 air
execute in minecraft:overworld run fill 247 58 6 247 62 6 stone
execute in minecraft:overworld run fill 247 63 6 247 64 6 dirt
execute in minecraft:overworld run setblock 247 65 6 grass_block
execute in minecraft:overworld run fill 247 66 6 247 144 6 air
execute in minecraft:overworld run fill 247 58 7 247 63 7 stone
execute in minecraft:overworld run fill 247 64 7 247 65 7 dirt
execute in minecraft:overworld run setblock 247 66 7 coarse_dirt
execute in minecraft:overworld run fill 247 67 7 247 144 7 air
execute in minecraft:overworld run fill 247 58 8 247 63 8 stone
execute in minecraft:overworld run fill 247 64 8 247 65 8 dirt
execute in minecraft:overworld run setblock 247 66 8 coarse_dirt
execute in minecraft:overworld run fill 247 67 8 247 144 8 air
execute in minecraft:overworld run fill 247 58 9 247 63 9 stone
execute in minecraft:overworld run fill 247 64 9 247 65 9 dirt
execute in minecraft:overworld run setblock 247 66 9 coarse_dirt
execute in minecraft:overworld run fill 247 67 9 247 144 9 air
execute in minecraft:overworld run fill 247 58 10 247 64 10 stone
execute in minecraft:overworld run fill 247 65 10 247 66 10 dirt
execute in minecraft:overworld run setblock 247 67 10 coarse_dirt
execute in minecraft:overworld run fill 247 68 10 247 144 10 air
execute in minecraft:overworld run fill 247 58 11 247 64 11 stone
execute in minecraft:overworld run fill 247 65 11 247 66 11 dirt
execute in minecraft:overworld run setblock 247 67 11 grass_block
execute in minecraft:overworld run fill 247 68 11 247 144 11 air
execute in minecraft:overworld run fill 247 58 12 247 64 12 stone
execute in minecraft:overworld run fill 247 65 12 247 66 12 dirt
execute in minecraft:overworld run setblock 247 67 12 coarse_dirt
execute in minecraft:overworld run fill 247 68 12 247 144 12 air
execute in minecraft:overworld run fill 247 58 13 247 64 13 stone
execute in minecraft:overworld run fill 247 65 13 247 66 13 dirt
execute in minecraft:overworld run setblock 247 67 13 grass_block
execute in minecraft:overworld run fill 247 68 13 247 144 13 air
execute in minecraft:overworld run fill 247 58 14 247 64 14 stone
execute in minecraft:overworld run fill 247 65 14 247 66 14 dirt
execute in minecraft:overworld run setblock 247 67 14 grass_block
execute in minecraft:overworld run fill 247 68 14 247 144 14 air
execute in minecraft:overworld run fill 247 58 15 247 64 15 stone
execute in minecraft:overworld run fill 247 65 15 247 66 15 dirt
execute in minecraft:overworld run setblock 247 67 15 coarse_dirt
execute in minecraft:overworld run fill 247 68 15 247 144 15 air
execute in minecraft:overworld run fill 247 58 16 247 65 16 stone
execute in minecraft:overworld run fill 247 66 16 247 67 16 dirt
execute in minecraft:overworld run setblock 247 68 16 coarse_dirt
execute in minecraft:overworld run fill 247 69 16 247 144 16 air
execute in minecraft:overworld run fill 247 58 17 247 65 17 stone
execute in minecraft:overworld run fill 247 66 17 247 67 17 dirt
execute in minecraft:overworld run setblock 247 68 17 coarse_dirt
execute in minecraft:overworld run fill 247 69 17 247 144 17 air
execute in minecraft:overworld run fill 247 58 18 247 65 18 stone
execute in minecraft:overworld run fill 247 66 18 247 67 18 dirt
execute in minecraft:overworld run setblock 247 68 18 grass_block
execute in minecraft:overworld run fill 247 69 18 247 144 18 air
execute in minecraft:overworld run fill 247 58 19 247 65 19 stone
execute in minecraft:overworld run fill 247 66 19 247 67 19 dirt
execute in minecraft:overworld run setblock 247 68 19 grass_block
execute in minecraft:overworld run fill 247 69 19 247 144 19 air
execute in minecraft:overworld run fill 247 58 20 247 65 20 stone
execute in minecraft:overworld run fill 247 66 20 247 67 20 dirt
execute in minecraft:overworld run setblock 247 68 20 coarse_dirt
execute in minecraft:overworld run fill 247 69 20 247 144 20 air
execute in minecraft:overworld run fill 247 58 21 247 65 21 stone
execute in minecraft:overworld run fill 247 66 21 247 67 21 dirt
execute in minecraft:overworld run setblock 247 68 21 coarse_dirt
execute in minecraft:overworld run fill 247 69 21 247 144 21 air
execute in minecraft:overworld run setblock 247 69 21 grass
execute in minecraft:overworld run fill 247 58 22 247 65 22 stone
execute in minecraft:overworld run fill 247 66 22 247 67 22 dirt
execute in minecraft:overworld run setblock 247 68 22 coarse_dirt
execute in minecraft:overworld run fill 247 69 22 247 144 22 air
execute in minecraft:overworld run setblock 247 69 22 grass
execute in minecraft:overworld run fill 247 58 23 247 65 23 stone
execute in minecraft:overworld run fill 247 66 23 247 67 23 dirt
execute in minecraft:overworld run setblock 247 68 23 coarse_dirt
execute in minecraft:overworld run fill 247 69 23 247 144 23 air
execute in minecraft:overworld run fill 247 58 24 247 65 24 stone
execute in minecraft:overworld run fill 247 66 24 247 67 24 dirt
schedule function blade_gallery:random/burned/part_61 1t replace
