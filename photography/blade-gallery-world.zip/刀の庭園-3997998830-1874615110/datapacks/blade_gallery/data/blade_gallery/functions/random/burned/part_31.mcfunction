execute in minecraft:overworld run fill 228 67 -22 228 68 -22 dirt
execute in minecraft:overworld run setblock 228 69 -22 grass_block
execute in minecraft:overworld run fill 228 70 -22 228 144 -22 air
execute in minecraft:overworld run fill 228 58 -21 228 66 -21 stone
execute in minecraft:overworld run fill 228 67 -21 228 68 -21 dirt
execute in minecraft:overworld run setblock 228 69 -21 grass_block
execute in minecraft:overworld run fill 228 70 -21 228 144 -21 air
execute in minecraft:overworld run fill 228 58 -20 228 66 -20 stone
execute in minecraft:overworld run fill 228 67 -20 228 68 -20 dirt
execute in minecraft:overworld run setblock 228 69 -20 grass_block
execute in minecraft:overworld run fill 228 70 -20 228 144 -20 air
execute in minecraft:overworld run fill 228 58 -19 228 66 -19 stone
execute in minecraft:overworld run fill 228 67 -19 228 68 -19 dirt
execute in minecraft:overworld run setblock 228 69 -19 coarse_dirt
execute in minecraft:overworld run fill 228 70 -19 228 144 -19 air
execute in minecraft:overworld run fill 228 58 -18 228 66 -18 stone
execute in minecraft:overworld run fill 228 67 -18 228 68 -18 dirt
execute in minecraft:overworld run setblock 228 69 -18 grass_block
execute in minecraft:overworld run fill 228 70 -18 228 144 -18 air
execute in minecraft:overworld run fill 228 58 -17 228 66 -17 stone
execute in minecraft:overworld run fill 228 67 -17 228 68 -17 dirt
execute in minecraft:overworld run setblock 228 69 -17 grass_block
execute in minecraft:overworld run fill 228 70 -17 228 144 -17 air
execute in minecraft:overworld run setblock 228 70 -17 grass
execute in minecraft:overworld run fill 228 58 -16 228 65 -16 stone
execute in minecraft:overworld run fill 228 66 -16 228 67 -16 dirt
execute in minecraft:overworld run setblock 228 68 -16 coarse_dirt
execute in minecraft:overworld run fill 228 69 -16 228 144 -16 air
execute in minecraft:overworld run setblock 228 69 -16 grass
execute in minecraft:overworld run fill 228 58 -15 228 65 -15 stone
execute in minecraft:overworld run fill 228 66 -15 228 67 -15 dirt
execute in minecraft:overworld run setblock 228 68 -15 coarse_dirt
execute in minecraft:overworld run fill 228 69 -15 228 144 -15 air
execute in minecraft:overworld run fill 228 58 -14 228 65 -14 stone
execute in minecraft:overworld run fill 228 66 -14 228 67 -14 dirt
execute in minecraft:overworld run setblock 228 68 -14 coarse_dirt
execute in minecraft:overworld run fill 228 69 -14 228 144 -14 air
execute in minecraft:overworld run fill 228 58 -13 228 65 -13 stone
execute in minecraft:overworld run fill 228 66 -13 228 67 -13 dirt
execute in minecraft:overworld run setblock 228 68 -13 coarse_dirt
execute in minecraft:overworld run fill 228 69 -13 228 144 -13 air
execute in minecraft:overworld run fill 228 58 -12 228 64 -12 stone
execute in minecraft:overworld run fill 228 65 -12 228 66 -12 dirt
execute in minecraft:overworld run setblock 228 67 -12 coarse_dirt
execute in minecraft:overworld run fill 228 68 -12 228 144 -12 air
execute in minecraft:overworld run fill 228 58 -11 228 64 -11 stone
execute in minecraft:overworld run fill 228 65 -11 228 66 -11 dirt
execute in minecraft:overworld run setblock 228 67 -11 coarse_dirt
execute in minecraft:overworld run fill 228 68 -11 228 144 -11 air
execute in minecraft:overworld run fill 228 58 -10 228 64 -10 stone
execute in minecraft:overworld run fill 228 65 -10 228 66 -10 dirt
execute in minecraft:overworld run setblock 228 67 -10 coarse_dirt
execute in minecraft:overworld run fill 228 68 -10 228 144 -10 air
execute in minecraft:overworld run fill 228 58 -9 228 65 -9 stone
execute in minecraft:overworld run fill 228 66 -9 228 67 -9 dirt
execute in minecraft:overworld run setblock 228 68 -9 coarse_dirt
execute in minecraft:overworld run fill 228 69 -9 228 144 -9 air
execute in minecraft:overworld run fill 228 58 -8 228 65 -8 stone
execute in minecraft:overworld run fill 228 66 -8 228 67 -8 dirt
execute in minecraft:overworld run setblock 228 68 -8 grass_block
execute in minecraft:overworld run fill 228 69 -8 228 144 -8 air
execute in minecraft:overworld run fill 228 58 -7 228 65 -7 stone
execute in minecraft:overworld run fill 228 66 -7 228 67 -7 dirt
execute in minecraft:overworld run setblock 228 68 -7 grass_block
execute in minecraft:overworld run fill 228 69 -7 228 144 -7 air
execute in minecraft:overworld run fill 228 58 -6 228 65 -6 stone
execute in minecraft:overworld run fill 228 66 -6 228 67 -6 dirt
execute in minecraft:overworld run setblock 228 68 -6 grass_block
execute in minecraft:overworld run fill 228 69 -6 228 144 -6 air
execute in minecraft:overworld run fill 228 58 -5 228 66 -5 stone
execute in minecraft:overworld run fill 228 67 -5 228 68 -5 dirt
execute in minecraft:overworld run setblock 228 69 -5 grass_block
execute in minecraft:overworld run fill 228 70 -5 228 144 -5 air
execute in minecraft:overworld run fill 228 58 -4 228 66 -4 stone
execute in minecraft:overworld run fill 228 67 -4 228 68 -4 dirt
execute in minecraft:overworld run setblock 228 69 -4 coarse_dirt
execute in minecraft:overworld run fill 228 70 -4 228 144 -4 air
execute in minecraft:overworld run fill 228 58 -3 228 66 -3 stone
execute in minecraft:overworld run fill 228 67 -3 228 68 -3 dirt
execute in minecraft:overworld run setblock 228 69 -3 grass_block
execute in minecraft:overworld run fill 228 70 -3 228 144 -3 air
execute in minecraft:overworld run fill 228 58 -2 228 67 -2 stone
execute in minecraft:overworld run fill 228 68 -2 228 69 -2 dirt
execute in minecraft:overworld run setblock 228 70 -2 grass_block
execute in minecraft:overworld run fill 228 71 -2 228 144 -2 air
execute in minecraft:overworld run fill 228 58 -1 228 67 -1 stone
execute in minecraft:overworld run fill 228 68 -1 228 69 -1 dirt
execute in minecraft:overworld run setblock 228 70 -1 grass_block
execute in minecraft:overworld run fill 228 71 -1 228 144 -1 air
execute in minecraft:overworld run setblock 228 71 -1 grass
execute in minecraft:overworld run fill 228 58 0 228 67 0 stone
execute in minecraft:overworld run fill 228 68 0 228 69 0 dirt
execute in minecraft:overworld run setblock 228 70 0 coarse_dirt
execute in minecraft:overworld run fill 228 71 0 228 144 0 air
execute in minecraft:overworld run fill 228 58 1 228 67 1 stone
execute in minecraft:overworld run fill 228 68 1 228 69 1 dirt
execute in minecraft:overworld run setblock 228 70 1 coarse_dirt
execute in minecraft:overworld run fill 228 71 1 228 144 1 air
execute in minecraft:overworld run fill 228 58 2 228 67 2 stone
execute in minecraft:overworld run fill 228 68 2 228 69 2 dirt
execute in minecraft:overworld run setblock 228 70 2 grass_block
execute in minecraft:overworld run fill 228 71 2 228 144 2 air
execute in minecraft:overworld run fill 228 58 3 228 67 3 stone
execute in minecraft:overworld run fill 228 68 3 228 69 3 dirt
execute in minecraft:overworld run setblock 228 70 3 coarse_dirt
execute in minecraft:overworld run fill 228 71 3 228 144 3 air
execute in minecraft:overworld run fill 228 58 4 228 67 4 stone
execute in minecraft:overworld run fill 228 68 4 228 69 4 dirt
execute in minecraft:overworld run setblock 228 70 4 grass_block
execute in minecraft:overworld run fill 228 71 4 228 144 4 air
execute in minecraft:overworld run fill 228 58 5 228 66 5 stone
execute in minecraft:overworld run fill 228 67 5 228 68 5 dirt
execute in minecraft:overworld run setblock 228 69 5 grass_block
execute in minecraft:overworld run fill 228 70 5 228 144 5 air
execute in minecraft:overworld run fill 228 58 6 228 66 6 stone
execute in minecraft:overworld run fill 228 67 6 228 68 6 dirt
execute in minecraft:overworld run setblock 228 69 6 grass_block
execute in minecraft:overworld run fill 228 70 6 228 144 6 air
execute in minecraft:overworld run setblock 228 70 6 grass
execute in minecraft:overworld run fill 228 58 7 228 66 7 stone
execute in minecraft:overworld run fill 228 67 7 228 68 7 dirt
execute in minecraft:overworld run setblock 228 69 7 coarse_dirt
execute in minecraft:overworld run fill 228 70 7 228 144 7 air
execute in minecraft:overworld run fill 228 58 8 228 66 8 stone
execute in minecraft:overworld run fill 228 67 8 228 68 8 dirt
execute in minecraft:overworld run setblock 228 69 8 coarse_dirt
execute in minecraft:overworld run fill 228 70 8 228 144 8 air
execute in minecraft:overworld run fill 228 58 9 228 66 9 stone
execute in minecraft:overworld run fill 228 67 9 228 68 9 dirt
execute in minecraft:overworld run setblock 228 69 9 grass_block
execute in minecraft:overworld run fill 228 70 9 228 144 9 air
execute in minecraft:overworld run fill 228 58 10 228 67 10 stone
execute in minecraft:overworld run fill 228 68 10 228 69 10 dirt
execute in minecraft:overworld run setblock 228 70 10 coarse_dirt
execute in minecraft:overworld run fill 228 71 10 228 144 10 air
execute in minecraft:overworld run fill 228 58 11 228 67 11 stone
execute in minecraft:overworld run fill 228 68 11 228 69 11 dirt
execute in minecraft:overworld run setblock 228 70 11 coarse_dirt
execute in minecraft:overworld run fill 228 71 11 228 144 11 air
execute in minecraft:overworld run fill 228 58 12 228 67 12 stone
execute in minecraft:overworld run fill 228 68 12 228 69 12 dirt
execute in minecraft:overworld run setblock 228 70 12 coarse_dirt
execute in minecraft:overworld run fill 228 71 12 228 144 12 air
execute in minecraft:overworld run fill 228 58 13 228 68 13 stone
execute in minecraft:overworld run fill 228 69 13 228 70 13 dirt
execute in minecraft:overworld run setblock 228 71 13 grass_block
execute in minecraft:overworld run fill 228 72 13 228 144 13 air
execute in minecraft:overworld run fill 228 58 14 228 68 14 stone
execute in minecraft:overworld run fill 228 69 14 228 70 14 dirt
execute in minecraft:overworld run setblock 228 71 14 grass_block
execute in minecraft:overworld run fill 228 72 14 228 144 14 air
execute in minecraft:overworld run fill 228 58 15 228 68 15 stone
execute in minecraft:overworld run fill 228 69 15 228 70 15 dirt
execute in minecraft:overworld run setblock 228 71 15 grass_block
execute in minecraft:overworld run fill 228 72 15 228 144 15 air
execute in minecraft:overworld run fill 228 58 16 228 69 16 stone
execute in minecraft:overworld run fill 228 70 16 228 71 16 dirt
execute in minecraft:overworld run setblock 228 72 16 coarse_dirt
execute in minecraft:overworld run fill 228 73 16 228 144 16 air
execute in minecraft:overworld run fill 228 58 17 228 69 17 stone
execute in minecraft:overworld run fill 228 70 17 228 71 17 dirt
execute in minecraft:overworld run setblock 228 72 17 grass_block
execute in minecraft:overworld run fill 228 73 17 228 144 17 air
execute in minecraft:overworld run setblock 228 73 17 grass
execute in minecraft:overworld run fill 228 58 18 228 69 18 stone
execute in minecraft:overworld run fill 228 70 18 228 71 18 dirt
execute in minecraft:overworld run setblock 228 72 18 coarse_dirt
execute in minecraft:overworld run fill 228 73 18 228 144 18 air
execute in minecraft:overworld run fill 228 58 19 228 70 19 stone
execute in minecraft:overworld run fill 228 71 19 228 72 19 dirt
execute in minecraft:overworld run setblock 228 73 19 coarse_dirt
execute in minecraft:overworld run fill 228 74 19 228 144 19 air
execute in minecraft:overworld run fill 228 58 20 228 70 20 stone
execute in minecraft:overworld run fill 228 71 20 228 72 20 dirt
execute in minecraft:overworld run setblock 228 73 20 coarse_dirt
execute in minecraft:overworld run fill 228 74 20 228 144 20 air
execute in minecraft:overworld run fill 228 58 21 228 70 21 stone
execute in minecraft:overworld run fill 228 71 21 228 72 21 dirt
execute in minecraft:overworld run setblock 228 73 21 coarse_dirt
execute in minecraft:overworld run fill 228 74 21 228 144 21 air
execute in minecraft:overworld run fill 228 58 22 228 70 22 stone
execute in minecraft:overworld run fill 228 71 22 228 72 22 dirt
execute in minecraft:overworld run setblock 228 73 22 grass_block
execute in minecraft:overworld run fill 228 74 22 228 144 22 air
execute in minecraft:overworld run setblock 228 74 22 grass
execute in minecraft:overworld run fill 228 58 23 228 70 23 stone
execute in minecraft:overworld run fill 228 71 23 228 72 23 dirt
execute in minecraft:overworld run setblock 228 73 23 coarse_dirt
execute in minecraft:overworld run fill 228 74 23 228 144 23 air
execute in minecraft:overworld run setblock 228 74 23 grass
execute in minecraft:overworld run fill 228 58 24 228 70 24 stone
execute in minecraft:overworld run fill 228 71 24 228 72 24 dirt
execute in minecraft:overworld run setblock 228 73 24 coarse_dirt
execute in minecraft:overworld run fill 228 74 24 228 144 24 air
execute in minecraft:overworld run fill 228 58 25 228 70 25 stone
execute in minecraft:overworld run fill 228 71 25 228 72 25 dirt
execute in minecraft:overworld run setblock 228 73 25 coarse_dirt
execute in minecraft:overworld run fill 228 74 25 228 144 25 air
execute in minecraft:overworld run fill 228 58 26 228 70 26 stone
execute in minecraft:overworld run fill 228 71 26 228 72 26 dirt
execute in minecraft:overworld run setblock 228 73 26 coarse_dirt
execute in minecraft:overworld run fill 228 74 26 228 144 26 air
execute in minecraft:overworld run fill 228 58 27 228 70 27 stone
execute in minecraft:overworld run fill 228 71 27 228 72 27 dirt
execute in minecraft:overworld run setblock 228 73 27 coarse_dirt
execute in minecraft:overworld run fill 228 74 27 228 144 27 air
execute in minecraft:overworld run setblock 228 74 27 grass
execute in minecraft:overworld run fill 228 58 28 228 70 28 stone
execute in minecraft:overworld run fill 228 71 28 228 72 28 dirt
execute in minecraft:overworld run setblock 228 73 28 coarse_dirt
execute in minecraft:overworld run fill 228 74 28 228 144 28 air
execute in minecraft:overworld run fill 228 58 29 228 70 29 stone
execute in minecraft:overworld run fill 228 71 29 228 72 29 dirt
execute in minecraft:overworld run setblock 228 73 29 coarse_dirt
execute in minecraft:overworld run fill 228 74 29 228 144 29 air
execute in minecraft:overworld run fill 228 58 30 228 70 30 stone
execute in minecraft:overworld run fill 228 71 30 228 72 30 dirt
execute in minecraft:overworld run setblock 228 73 30 coarse_dirt
execute in minecraft:overworld run fill 228 74 30 228 144 30 air
execute in minecraft:overworld run setblock 228 74 30 mossy_cobblestone
execute in minecraft:overworld run fill 228 58 31 228 70 31 stone
execute in minecraft:overworld run fill 228 71 31 228 72 31 dirt
execute in minecraft:overworld run setblock 228 73 31 grass_block
execute in minecraft:overworld run fill 228 74 31 228 144 31 air
execute in minecraft:overworld run fill 228 58 32 228 70 32 stone
execute in minecraft:overworld run fill 228 71 32 228 72 32 dirt
execute in minecraft:overworld run setblock 228 73 32 grass_block
execute in minecraft:overworld run fill 228 74 32 228 144 32 air
execute in minecraft:overworld run fill 228 58 33 228 70 33 stone
execute in minecraft:overworld run fill 228 71 33 228 72 33 dirt
execute in minecraft:overworld run setblock 228 73 33 coarse_dirt
execute in minecraft:overworld run fill 228 74 33 228 144 33 air
execute in minecraft:overworld run fill 228 58 34 228 69 34 stone
execute in minecraft:overworld run fill 228 70 34 228 71 34 dirt
execute in minecraft:overworld run setblock 228 72 34 coarse_dirt
execute in minecraft:overworld run fill 228 73 34 228 144 34 air
execute in minecraft:overworld run fill 228 58 35 228 69 35 stone
execute in minecraft:overworld run fill 228 70 35 228 71 35 dirt
execute in minecraft:overworld run setblock 228 72 35 coarse_dirt
execute in minecraft:overworld run fill 228 73 35 228 144 35 air
execute in minecraft:overworld run fill 228 58 36 228 69 36 stone
execute in minecraft:overworld run fill 228 70 36 228 71 36 dirt
execute in minecraft:overworld run setblock 228 72 36 coarse_dirt
execute in minecraft:overworld run fill 228 73 36 228 144 36 air
execute in minecraft:overworld run fill 228 58 37 228 68 37 stone
execute in minecraft:overworld run fill 228 69 37 228 70 37 dirt
execute in minecraft:overworld run setblock 228 71 37 coarse_dirt
execute in minecraft:overworld run fill 228 72 37 228 144 37 air
execute in minecraft:overworld run fill 228 58 38 228 68 38 stone
execute in minecraft:overworld run fill 228 69 38 228 70 38 dirt
execute in minecraft:overworld run setblock 228 71 38 grass_block
execute in minecraft:overworld run fill 228 72 38 228 144 38 air
execute in minecraft:overworld run fill 228 58 39 228 67 39 stone
execute in minecraft:overworld run fill 228 68 39 228 69 39 dirt
execute in minecraft:overworld run setblock 228 70 39 coarse_dirt
execute in minecraft:overworld run fill 228 71 39 228 144 39 air
schedule function blade_gallery:random/burned/part_32 1t replace
