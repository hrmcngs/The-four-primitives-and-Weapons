execute in minecraft:overworld run setblock 339 64 47 coarse_dirt
execute in minecraft:overworld run fill 339 65 47 339 144 47 air
execute in minecraft:overworld run fill 340 58 -48 340 61 -48 stone
execute in minecraft:overworld run fill 340 62 -48 340 63 -48 dirt
execute in minecraft:overworld run setblock 340 64 -48 coarse_dirt
execute in minecraft:overworld run fill 340 65 -48 340 144 -48 air
execute in minecraft:overworld run fill 340 58 -47 340 63 -47 stone
execute in minecraft:overworld run fill 340 64 -47 340 65 -47 dirt
execute in minecraft:overworld run setblock 340 66 -47 coarse_dirt
execute in minecraft:overworld run fill 340 67 -47 340 144 -47 air
execute in minecraft:overworld run fill 340 58 -46 340 65 -46 stone
execute in minecraft:overworld run fill 340 66 -46 340 67 -46 dirt
execute in minecraft:overworld run setblock 340 68 -46 grass_block
execute in minecraft:overworld run fill 340 69 -46 340 144 -46 air
execute in minecraft:overworld run fill 340 58 -45 340 66 -45 stone
execute in minecraft:overworld run fill 340 67 -45 340 68 -45 dirt
execute in minecraft:overworld run setblock 340 69 -45 coarse_dirt
execute in minecraft:overworld run fill 340 70 -45 340 144 -45 air
execute in minecraft:overworld run fill 340 58 -44 340 68 -44 stone
execute in minecraft:overworld run fill 340 69 -44 340 70 -44 dirt
execute in minecraft:overworld run setblock 340 71 -44 grass_block
execute in minecraft:overworld run fill 340 72 -44 340 144 -44 air
execute in minecraft:overworld run fill 340 58 -43 340 68 -43 stone
execute in minecraft:overworld run fill 340 69 -43 340 70 -43 dirt
execute in minecraft:overworld run setblock 340 71 -43 coarse_dirt
execute in minecraft:overworld run fill 340 72 -43 340 144 -43 air
execute in minecraft:overworld run fill 340 58 -42 340 68 -42 stone
execute in minecraft:overworld run fill 340 69 -42 340 70 -42 dirt
execute in minecraft:overworld run setblock 340 71 -42 coarse_dirt
execute in minecraft:overworld run fill 340 72 -42 340 144 -42 air
execute in minecraft:overworld run fill 340 58 -41 340 68 -41 stone
execute in minecraft:overworld run fill 340 69 -41 340 70 -41 dirt
execute in minecraft:overworld run setblock 340 71 -41 coarse_dirt
execute in minecraft:overworld run fill 340 72 -41 340 144 -41 air
execute in minecraft:overworld run fill 340 58 -40 340 68 -40 stone
execute in minecraft:overworld run fill 340 69 -40 340 70 -40 dirt
execute in minecraft:overworld run setblock 340 71 -40 coarse_dirt
execute in minecraft:overworld run fill 340 72 -40 340 144 -40 air
execute in minecraft:overworld run fill 340 58 -39 340 68 -39 stone
execute in minecraft:overworld run fill 340 69 -39 340 70 -39 dirt
execute in minecraft:overworld run setblock 340 71 -39 coarse_dirt
execute in minecraft:overworld run fill 340 72 -39 340 144 -39 air
execute in minecraft:overworld run fill 340 58 -38 340 68 -38 stone
execute in minecraft:overworld run fill 340 69 -38 340 70 -38 dirt
execute in minecraft:overworld run setblock 340 71 -38 coarse_dirt
execute in minecraft:overworld run fill 340 72 -38 340 144 -38 air
execute in minecraft:overworld run fill 340 58 -37 340 68 -37 stone
execute in minecraft:overworld run fill 340 69 -37 340 70 -37 dirt
execute in minecraft:overworld run setblock 340 71 -37 grass_block
execute in minecraft:overworld run fill 340 72 -37 340 144 -37 air
execute in minecraft:overworld run fill 340 58 -36 340 67 -36 stone
execute in minecraft:overworld run fill 340 68 -36 340 69 -36 dirt
execute in minecraft:overworld run setblock 340 70 -36 coarse_dirt
execute in minecraft:overworld run fill 340 71 -36 340 144 -36 air
execute in minecraft:overworld run fill 340 58 -35 340 67 -35 stone
execute in minecraft:overworld run fill 340 68 -35 340 69 -35 dirt
execute in minecraft:overworld run setblock 340 70 -35 coarse_dirt
execute in minecraft:overworld run fill 340 71 -35 340 144 -35 air
execute in minecraft:overworld run fill 340 58 -34 340 67 -34 stone
execute in minecraft:overworld run fill 340 68 -34 340 69 -34 dirt
execute in minecraft:overworld run setblock 340 70 -34 grass_block
execute in minecraft:overworld run fill 340 71 -34 340 144 -34 air
execute in minecraft:overworld run fill 340 58 -33 340 67 -33 stone
execute in minecraft:overworld run fill 340 68 -33 340 69 -33 dirt
execute in minecraft:overworld run setblock 340 70 -33 coarse_dirt
execute in minecraft:overworld run fill 340 71 -33 340 144 -33 air
execute in minecraft:overworld run fill 340 58 -32 340 67 -32 stone
execute in minecraft:overworld run fill 340 68 -32 340 69 -32 dirt
execute in minecraft:overworld run setblock 340 70 -32 coarse_dirt
execute in minecraft:overworld run fill 340 71 -32 340 144 -32 air
execute in minecraft:overworld run fill 340 58 -31 340 67 -31 stone
execute in minecraft:overworld run fill 340 68 -31 340 69 -31 dirt
execute in minecraft:overworld run setblock 340 70 -31 grass_block
execute in minecraft:overworld run fill 340 71 -31 340 144 -31 air
execute in minecraft:overworld run fill 340 58 -30 340 67 -30 stone
execute in minecraft:overworld run fill 340 68 -30 340 69 -30 dirt
execute in minecraft:overworld run setblock 340 70 -30 grass_block
execute in minecraft:overworld run fill 340 71 -30 340 144 -30 air
execute in minecraft:overworld run fill 340 58 -29 340 66 -29 stone
execute in minecraft:overworld run fill 340 67 -29 340 68 -29 dirt
execute in minecraft:overworld run setblock 340 69 -29 coarse_dirt
execute in minecraft:overworld run fill 340 70 -29 340 144 -29 air
execute in minecraft:overworld run fill 340 58 -28 340 66 -28 stone
execute in minecraft:overworld run fill 340 67 -28 340 68 -28 dirt
execute in minecraft:overworld run setblock 340 69 -28 coarse_dirt
execute in minecraft:overworld run fill 340 70 -28 340 144 -28 air
execute in minecraft:overworld run fill 340 58 -27 340 66 -27 stone
execute in minecraft:overworld run fill 340 67 -27 340 68 -27 dirt
execute in minecraft:overworld run setblock 340 69 -27 grass_block
execute in minecraft:overworld run fill 340 70 -27 340 144 -27 air
execute in minecraft:overworld run fill 340 58 -26 340 66 -26 stone
execute in minecraft:overworld run fill 340 67 -26 340 68 -26 dirt
execute in minecraft:overworld run setblock 340 69 -26 coarse_dirt
execute in minecraft:overworld run fill 340 70 -26 340 144 -26 air
execute in minecraft:overworld run fill 340 58 -25 340 66 -25 stone
execute in minecraft:overworld run fill 340 67 -25 340 68 -25 dirt
execute in minecraft:overworld run setblock 340 69 -25 coarse_dirt
execute in minecraft:overworld run fill 340 70 -25 340 144 -25 air
execute in minecraft:overworld run fill 340 58 -24 340 66 -24 stone
execute in minecraft:overworld run fill 340 67 -24 340 68 -24 dirt
execute in minecraft:overworld run setblock 340 69 -24 coarse_dirt
execute in minecraft:overworld run fill 340 70 -24 340 144 -24 air
execute in minecraft:overworld run fill 340 58 -23 340 66 -23 stone
execute in minecraft:overworld run fill 340 67 -23 340 68 -23 dirt
execute in minecraft:overworld run setblock 340 69 -23 coarse_dirt
execute in minecraft:overworld run fill 340 70 -23 340 144 -23 air
execute in minecraft:overworld run fill 340 58 -22 340 65 -22 stone
execute in minecraft:overworld run fill 340 66 -22 340 67 -22 dirt
execute in minecraft:overworld run setblock 340 68 -22 coarse_dirt
execute in minecraft:overworld run fill 340 69 -22 340 144 -22 air
execute in minecraft:overworld run fill 340 58 -21 340 65 -21 stone
execute in minecraft:overworld run fill 340 66 -21 340 67 -21 dirt
execute in minecraft:overworld run setblock 340 68 -21 grass_block
execute in minecraft:overworld run fill 340 69 -21 340 144 -21 air
execute in minecraft:overworld run fill 340 58 -20 340 65 -20 stone
execute in minecraft:overworld run fill 340 66 -20 340 67 -20 dirt
execute in minecraft:overworld run setblock 340 68 -20 grass_block
execute in minecraft:overworld run fill 340 69 -20 340 144 -20 air
execute in minecraft:overworld run fill 340 58 -19 340 65 -19 stone
execute in minecraft:overworld run fill 340 66 -19 340 67 -19 dirt
execute in minecraft:overworld run setblock 340 68 -19 coarse_dirt
execute in minecraft:overworld run fill 340 69 -19 340 144 -19 air
execute in minecraft:overworld run fill 340 58 -18 340 65 -18 stone
execute in minecraft:overworld run fill 340 66 -18 340 67 -18 dirt
execute in minecraft:overworld run setblock 340 68 -18 grass_block
execute in minecraft:overworld run fill 340 69 -18 340 144 -18 air
execute in minecraft:overworld run fill 340 58 -17 340 65 -17 stone
execute in minecraft:overworld run fill 340 66 -17 340 67 -17 dirt
execute in minecraft:overworld run setblock 340 68 -17 coarse_dirt
execute in minecraft:overworld run fill 340 69 -17 340 144 -17 air
execute in minecraft:overworld run fill 340 58 -16 340 65 -16 stone
execute in minecraft:overworld run fill 340 66 -16 340 67 -16 dirt
execute in minecraft:overworld run setblock 340 68 -16 grass_block
execute in minecraft:overworld run fill 340 69 -16 340 144 -16 air
execute in minecraft:overworld run fill 340 58 -15 340 64 -15 stone
execute in minecraft:overworld run fill 340 65 -15 340 66 -15 dirt
execute in minecraft:overworld run setblock 340 67 -15 coarse_dirt
execute in minecraft:overworld run fill 340 68 -15 340 144 -15 air
execute in minecraft:overworld run fill 340 58 -14 340 64 -14 stone
execute in minecraft:overworld run fill 340 65 -14 340 66 -14 dirt
execute in minecraft:overworld run setblock 340 67 -14 coarse_dirt
execute in minecraft:overworld run fill 340 68 -14 340 144 -14 air
execute in minecraft:overworld run fill 340 58 -13 340 64 -13 stone
execute in minecraft:overworld run fill 340 65 -13 340 66 -13 dirt
execute in minecraft:overworld run setblock 340 67 -13 coarse_dirt
execute in minecraft:overworld run fill 340 68 -13 340 144 -13 air
execute in minecraft:overworld run fill 340 58 -12 340 63 -12 stone
execute in minecraft:overworld run fill 340 64 -12 340 65 -12 dirt
execute in minecraft:overworld run setblock 340 66 -12 coarse_dirt
execute in minecraft:overworld run fill 340 67 -12 340 144 -12 air
execute in minecraft:overworld run fill 340 58 -11 340 63 -11 stone
execute in minecraft:overworld run fill 340 64 -11 340 65 -11 dirt
execute in minecraft:overworld run setblock 340 66 -11 coarse_dirt
execute in minecraft:overworld run fill 340 67 -11 340 144 -11 air
execute in minecraft:overworld run fill 340 58 -10 340 63 -10 stone
execute in minecraft:overworld run fill 340 64 -10 340 65 -10 dirt
execute in minecraft:overworld run setblock 340 66 -10 coarse_dirt
execute in minecraft:overworld run fill 340 67 -10 340 144 -10 air
execute in minecraft:overworld run fill 340 58 -9 340 63 -9 stone
execute in minecraft:overworld run fill 340 64 -9 340 65 -9 dirt
execute in minecraft:overworld run setblock 340 66 -9 grass_block
execute in minecraft:overworld run fill 340 67 -9 340 144 -9 air
execute in minecraft:overworld run fill 340 58 -8 340 63 -8 stone
execute in minecraft:overworld run fill 340 64 -8 340 65 -8 dirt
execute in minecraft:overworld run setblock 340 66 -8 grass_block
execute in minecraft:overworld run fill 340 67 -8 340 144 -8 air
execute in minecraft:overworld run fill 340 58 -7 340 63 -7 stone
execute in minecraft:overworld run fill 340 64 -7 340 65 -7 dirt
execute in minecraft:overworld run setblock 340 66 -7 coarse_dirt
execute in minecraft:overworld run fill 340 67 -7 340 144 -7 air
execute in minecraft:overworld run fill 340 58 -6 340 63 -6 stone
execute in minecraft:overworld run fill 340 64 -6 340 65 -6 dirt
execute in minecraft:overworld run setblock 340 66 -6 grass_block
execute in minecraft:overworld run fill 340 67 -6 340 144 -6 air
execute in minecraft:overworld run fill 340 58 -5 340 63 -5 stone
execute in minecraft:overworld run fill 340 64 -5 340 65 -5 dirt
execute in minecraft:overworld run setblock 340 66 -5 grass_block
execute in minecraft:overworld run fill 340 67 -5 340 144 -5 air
execute in minecraft:overworld run fill 340 58 -4 340 63 -4 stone
execute in minecraft:overworld run fill 340 64 -4 340 65 -4 dirt
execute in minecraft:overworld run setblock 340 66 -4 coarse_dirt
execute in minecraft:overworld run fill 340 67 -4 340 144 -4 air
execute in minecraft:overworld run fill 340 58 -3 340 63 -3 stone
execute in minecraft:overworld run fill 340 64 -3 340 65 -3 dirt
execute in minecraft:overworld run setblock 340 66 -3 grass_block
execute in minecraft:overworld run fill 340 67 -3 340 144 -3 air
execute in minecraft:overworld run fill 340 58 -2 340 64 -2 stone
execute in minecraft:overworld run fill 340 65 -2 340 66 -2 dirt
execute in minecraft:overworld run setblock 340 67 -2 coarse_dirt
execute in minecraft:overworld run fill 340 68 -2 340 144 -2 air
execute in minecraft:overworld run fill 340 58 -1 340 64 -1 stone
execute in minecraft:overworld run fill 340 65 -1 340 66 -1 dirt
execute in minecraft:overworld run setblock 340 67 -1 grass_block
execute in minecraft:overworld run fill 340 68 -1 340 144 -1 air
execute in minecraft:overworld run fill 340 58 0 340 64 0 stone
execute in minecraft:overworld run fill 340 65 0 340 66 0 dirt
execute in minecraft:overworld run setblock 340 67 0 coarse_dirt
execute in minecraft:overworld run fill 340 68 0 340 144 0 air
execute in minecraft:overworld run fill 340 58 1 340 64 1 stone
execute in minecraft:overworld run fill 340 65 1 340 66 1 dirt
execute in minecraft:overworld run setblock 340 67 1 grass_block
execute in minecraft:overworld run fill 340 68 1 340 144 1 air
execute in minecraft:overworld run fill 340 58 2 340 64 2 stone
execute in minecraft:overworld run fill 340 65 2 340 66 2 dirt
execute in minecraft:overworld run setblock 340 67 2 coarse_dirt
execute in minecraft:overworld run fill 340 68 2 340 144 2 air
execute in minecraft:overworld run fill 340 58 3 340 63 3 stone
execute in minecraft:overworld run fill 340 64 3 340 65 3 dirt
execute in minecraft:overworld run setblock 340 66 3 coarse_dirt
execute in minecraft:overworld run fill 340 67 3 340 144 3 air
execute in minecraft:overworld run fill 340 58 4 340 63 4 stone
execute in minecraft:overworld run fill 340 64 4 340 65 4 dirt
execute in minecraft:overworld run setblock 340 66 4 grass_block
execute in minecraft:overworld run fill 340 67 4 340 144 4 air
execute in minecraft:overworld run fill 340 58 5 340 63 5 stone
execute in minecraft:overworld run fill 340 64 5 340 65 5 dirt
execute in minecraft:overworld run setblock 340 66 5 coarse_dirt
execute in minecraft:overworld run fill 340 67 5 340 144 5 air
execute in minecraft:overworld run fill 340 58 6 340 63 6 stone
execute in minecraft:overworld run fill 340 64 6 340 65 6 dirt
execute in minecraft:overworld run setblock 340 66 6 coarse_dirt
execute in minecraft:overworld run fill 340 67 6 340 144 6 air
execute in minecraft:overworld run fill 340 58 7 340 63 7 stone
execute in minecraft:overworld run fill 340 64 7 340 65 7 dirt
execute in minecraft:overworld run setblock 340 66 7 coarse_dirt
execute in minecraft:overworld run fill 340 67 7 340 144 7 air
execute in minecraft:overworld run fill 340 58 8 340 63 8 stone
execute in minecraft:overworld run fill 340 64 8 340 65 8 dirt
execute in minecraft:overworld run setblock 340 66 8 coarse_dirt
execute in minecraft:overworld run fill 340 67 8 340 144 8 air
execute in minecraft:overworld run fill 340 58 9 340 63 9 stone
execute in minecraft:overworld run fill 340 64 9 340 65 9 dirt
execute in minecraft:overworld run setblock 340 66 9 coarse_dirt
execute in minecraft:overworld run fill 340 67 9 340 144 9 air
execute in minecraft:overworld run fill 340 58 10 340 63 10 stone
execute in minecraft:overworld run fill 340 64 10 340 65 10 dirt
execute in minecraft:overworld run setblock 340 66 10 coarse_dirt
execute in minecraft:overworld run fill 340 67 10 340 144 10 air
execute in minecraft:overworld run fill 340 58 11 340 63 11 stone
execute in minecraft:overworld run fill 340 64 11 340 65 11 dirt
execute in minecraft:overworld run setblock 340 66 11 coarse_dirt
execute in minecraft:overworld run fill 340 67 11 340 144 11 air
execute in minecraft:overworld run fill 340 58 12 340 63 12 stone
execute in minecraft:overworld run fill 340 64 12 340 65 12 dirt
execute in minecraft:overworld run setblock 340 66 12 coarse_dirt
execute in minecraft:overworld run fill 340 67 12 340 144 12 air
execute in minecraft:overworld run fill 340 58 13 340 63 13 stone
execute in minecraft:overworld run fill 340 64 13 340 65 13 dirt
execute in minecraft:overworld run setblock 340 66 13 coarse_dirt
execute in minecraft:overworld run fill 340 67 13 340 144 13 air
execute in minecraft:overworld run fill 340 58 14 340 63 14 stone
execute in minecraft:overworld run fill 340 64 14 340 65 14 dirt
execute in minecraft:overworld run setblock 340 66 14 coarse_dirt
execute in minecraft:overworld run fill 340 67 14 340 144 14 air
execute in minecraft:overworld run fill 340 58 15 340 62 15 stone
execute in minecraft:overworld run fill 340 63 15 340 64 15 dirt
schedule function blade_gallery:random/battlefield/part_7 1t replace
