execute in minecraft:overworld run fill 355 58 -46 355 65 -46 stone
execute in minecraft:overworld run fill 355 66 -46 355 67 -46 dirt
execute in minecraft:overworld run setblock 355 68 -46 coarse_dirt
execute in minecraft:overworld run fill 355 69 -46 355 144 -46 air
execute in minecraft:overworld run fill 355 58 -45 355 67 -45 stone
execute in minecraft:overworld run fill 355 68 -45 355 69 -45 dirt
execute in minecraft:overworld run setblock 355 70 -45 coarse_dirt
execute in minecraft:overworld run fill 355 71 -45 355 144 -45 air
execute in minecraft:overworld run fill 355 58 -44 355 68 -44 stone
execute in minecraft:overworld run fill 355 69 -44 355 70 -44 dirt
execute in minecraft:overworld run setblock 355 71 -44 grass_block
execute in minecraft:overworld run fill 355 72 -44 355 144 -44 air
execute in minecraft:overworld run fill 355 58 -43 355 70 -43 stone
execute in minecraft:overworld run fill 355 71 -43 355 72 -43 dirt
execute in minecraft:overworld run setblock 355 73 -43 coarse_dirt
execute in minecraft:overworld run fill 355 74 -43 355 144 -43 air
execute in minecraft:overworld run fill 355 58 -42 355 71 -42 stone
execute in minecraft:overworld run fill 355 72 -42 355 73 -42 dirt
execute in minecraft:overworld run setblock 355 74 -42 coarse_dirt
execute in minecraft:overworld run fill 355 75 -42 355 144 -42 air
execute in minecraft:overworld run fill 355 58 -41 355 72 -41 stone
execute in minecraft:overworld run fill 355 73 -41 355 74 -41 dirt
execute in minecraft:overworld run setblock 355 75 -41 coarse_dirt
execute in minecraft:overworld run fill 355 76 -41 355 144 -41 air
execute in minecraft:overworld run fill 355 58 -40 355 74 -40 stone
execute in minecraft:overworld run fill 355 75 -40 355 76 -40 dirt
execute in minecraft:overworld run setblock 355 77 -40 coarse_dirt
execute in minecraft:overworld run fill 355 78 -40 355 144 -40 air
execute in minecraft:overworld run fill 355 58 -39 355 75 -39 stone
execute in minecraft:overworld run fill 355 76 -39 355 77 -39 dirt
execute in minecraft:overworld run setblock 355 78 -39 coarse_dirt
execute in minecraft:overworld run fill 355 79 -39 355 144 -39 air
execute in minecraft:overworld run fill 355 58 -38 355 75 -38 stone
execute in minecraft:overworld run fill 355 76 -38 355 77 -38 dirt
execute in minecraft:overworld run setblock 355 78 -38 coarse_dirt
execute in minecraft:overworld run fill 355 79 -38 355 144 -38 air
execute in minecraft:overworld run fill 355 58 -37 355 75 -37 stone
execute in minecraft:overworld run fill 355 76 -37 355 77 -37 dirt
execute in minecraft:overworld run setblock 355 78 -37 grass_block
execute in minecraft:overworld run fill 355 79 -37 355 144 -37 air
execute in minecraft:overworld run fill 355 58 -36 355 75 -36 stone
execute in minecraft:overworld run fill 355 76 -36 355 77 -36 dirt
execute in minecraft:overworld run setblock 355 78 -36 grass_block
execute in minecraft:overworld run fill 355 79 -36 355 144 -36 air
execute in minecraft:overworld run fill 355 58 -35 355 74 -35 stone
execute in minecraft:overworld run fill 355 75 -35 355 76 -35 dirt
execute in minecraft:overworld run setblock 355 77 -35 coarse_dirt
execute in minecraft:overworld run fill 355 78 -35 355 144 -35 air
execute in minecraft:overworld run fill 355 58 -34 355 74 -34 stone
execute in minecraft:overworld run fill 355 75 -34 355 76 -34 dirt
execute in minecraft:overworld run setblock 355 77 -34 coarse_dirt
execute in minecraft:overworld run fill 355 78 -34 355 144 -34 air
execute in minecraft:overworld run fill 355 58 -33 355 74 -33 stone
execute in minecraft:overworld run fill 355 75 -33 355 76 -33 dirt
execute in minecraft:overworld run setblock 355 77 -33 coarse_dirt
execute in minecraft:overworld run fill 355 78 -33 355 144 -33 air
execute in minecraft:overworld run fill 355 58 -32 355 74 -32 stone
execute in minecraft:overworld run fill 355 75 -32 355 76 -32 dirt
execute in minecraft:overworld run setblock 355 77 -32 coarse_dirt
execute in minecraft:overworld run fill 355 78 -32 355 144 -32 air
execute in minecraft:overworld run fill 355 58 -31 355 74 -31 stone
execute in minecraft:overworld run fill 355 75 -31 355 76 -31 dirt
execute in minecraft:overworld run setblock 355 77 -31 coarse_dirt
execute in minecraft:overworld run fill 355 78 -31 355 144 -31 air
execute in minecraft:overworld run fill 355 58 -30 355 74 -30 stone
execute in minecraft:overworld run fill 355 75 -30 355 76 -30 dirt
execute in minecraft:overworld run setblock 355 77 -30 grass_block
execute in minecraft:overworld run fill 355 78 -30 355 144 -30 air
execute in minecraft:overworld run fill 355 58 -29 355 73 -29 stone
execute in minecraft:overworld run fill 355 74 -29 355 75 -29 dirt
execute in minecraft:overworld run setblock 355 76 -29 grass_block
execute in minecraft:overworld run fill 355 77 -29 355 144 -29 air
execute in minecraft:overworld run fill 355 58 -28 355 73 -28 stone
execute in minecraft:overworld run fill 355 74 -28 355 75 -28 dirt
execute in minecraft:overworld run setblock 355 76 -28 coarse_dirt
execute in minecraft:overworld run fill 355 77 -28 355 144 -28 air
execute in minecraft:overworld run setblock 355 77 -28 grass
execute in minecraft:overworld run fill 355 58 -27 355 73 -27 stone
execute in minecraft:overworld run fill 355 74 -27 355 75 -27 dirt
execute in minecraft:overworld run setblock 355 76 -27 coarse_dirt
execute in minecraft:overworld run fill 355 77 -27 355 144 -27 air
execute in minecraft:overworld run setblock 355 77 -27 mossy_cobblestone
execute in minecraft:overworld run fill 355 58 -26 355 73 -26 stone
execute in minecraft:overworld run fill 355 74 -26 355 75 -26 dirt
execute in minecraft:overworld run setblock 355 76 -26 coarse_dirt
execute in minecraft:overworld run fill 355 77 -26 355 144 -26 air
execute in minecraft:overworld run fill 355 58 -25 355 72 -25 stone
execute in minecraft:overworld run fill 355 73 -25 355 74 -25 dirt
execute in minecraft:overworld run setblock 355 75 -25 coarse_dirt
execute in minecraft:overworld run fill 355 76 -25 355 144 -25 air
execute in minecraft:overworld run fill 355 58 -24 355 72 -24 stone
execute in minecraft:overworld run fill 355 73 -24 355 74 -24 dirt
execute in minecraft:overworld run setblock 355 75 -24 coarse_dirt
execute in minecraft:overworld run fill 355 76 -24 355 144 -24 air
execute in minecraft:overworld run fill 355 58 -23 355 72 -23 stone
execute in minecraft:overworld run fill 355 73 -23 355 74 -23 dirt
execute in minecraft:overworld run setblock 355 75 -23 coarse_dirt
execute in minecraft:overworld run fill 355 76 -23 355 144 -23 air
execute in minecraft:overworld run fill 355 58 -22 355 71 -22 stone
execute in minecraft:overworld run fill 355 72 -22 355 73 -22 dirt
execute in minecraft:overworld run setblock 355 74 -22 grass_block
execute in minecraft:overworld run fill 355 75 -22 355 144 -22 air
execute in minecraft:overworld run setblock 355 75 -22 grass
execute in minecraft:overworld run fill 355 58 -21 355 71 -21 stone
execute in minecraft:overworld run fill 355 72 -21 355 73 -21 dirt
execute in minecraft:overworld run setblock 355 74 -21 grass_block
execute in minecraft:overworld run fill 355 75 -21 355 144 -21 air
execute in minecraft:overworld run fill 355 58 -20 355 71 -20 stone
execute in minecraft:overworld run fill 355 72 -20 355 73 -20 dirt
execute in minecraft:overworld run setblock 355 74 -20 coarse_dirt
execute in minecraft:overworld run fill 355 75 -20 355 144 -20 air
execute in minecraft:overworld run fill 355 58 -19 355 70 -19 stone
execute in minecraft:overworld run fill 355 71 -19 355 72 -19 dirt
execute in minecraft:overworld run setblock 355 73 -19 coarse_dirt
execute in minecraft:overworld run fill 355 74 -19 355 144 -19 air
execute in minecraft:overworld run fill 355 58 -18 355 70 -18 stone
execute in minecraft:overworld run fill 355 71 -18 355 72 -18 dirt
execute in minecraft:overworld run setblock 355 73 -18 coarse_dirt
execute in minecraft:overworld run fill 355 74 -18 355 144 -18 air
execute in minecraft:overworld run fill 355 58 -17 355 69 -17 stone
execute in minecraft:overworld run fill 355 70 -17 355 71 -17 dirt
execute in minecraft:overworld run setblock 355 72 -17 grass_block
execute in minecraft:overworld run fill 355 73 -17 355 144 -17 air
execute in minecraft:overworld run fill 355 58 -16 355 69 -16 stone
execute in minecraft:overworld run fill 355 70 -16 355 71 -16 dirt
execute in minecraft:overworld run setblock 355 72 -16 coarse_dirt
execute in minecraft:overworld run fill 355 73 -16 355 144 -16 air
execute in minecraft:overworld run fill 355 58 -15 355 68 -15 stone
execute in minecraft:overworld run fill 355 69 -15 355 70 -15 dirt
execute in minecraft:overworld run setblock 355 71 -15 coarse_dirt
execute in minecraft:overworld run fill 355 72 -15 355 144 -15 air
execute in minecraft:overworld run fill 355 58 -14 355 68 -14 stone
execute in minecraft:overworld run fill 355 69 -14 355 70 -14 dirt
execute in minecraft:overworld run setblock 355 71 -14 coarse_dirt
execute in minecraft:overworld run fill 355 72 -14 355 144 -14 air
execute in minecraft:overworld run fill 355 58 -13 355 67 -13 stone
execute in minecraft:overworld run fill 355 68 -13 355 69 -13 dirt
execute in minecraft:overworld run setblock 355 70 -13 coarse_dirt
execute in minecraft:overworld run fill 355 71 -13 355 144 -13 air
execute in minecraft:overworld run fill 355 58 -12 355 67 -12 stone
execute in minecraft:overworld run fill 355 68 -12 355 69 -12 dirt
execute in minecraft:overworld run setblock 355 70 -12 grass_block
execute in minecraft:overworld run fill 355 71 -12 355 144 -12 air
execute in minecraft:overworld run fill 355 58 -11 355 66 -11 stone
execute in minecraft:overworld run fill 355 67 -11 355 68 -11 dirt
execute in minecraft:overworld run setblock 355 69 -11 coarse_dirt
execute in minecraft:overworld run fill 355 70 -11 355 144 -11 air
execute in minecraft:overworld run fill 355 58 -10 355 66 -10 stone
execute in minecraft:overworld run fill 355 67 -10 355 68 -10 dirt
execute in minecraft:overworld run setblock 355 69 -10 coarse_dirt
execute in minecraft:overworld run fill 355 70 -10 355 144 -10 air
execute in minecraft:overworld run fill 355 58 -9 355 66 -9 stone
execute in minecraft:overworld run fill 355 67 -9 355 68 -9 dirt
execute in minecraft:overworld run setblock 355 69 -9 coarse_dirt
execute in minecraft:overworld run fill 355 70 -9 355 144 -9 air
execute in minecraft:overworld run fill 355 58 -8 355 66 -8 stone
execute in minecraft:overworld run fill 355 67 -8 355 68 -8 dirt
execute in minecraft:overworld run setblock 355 69 -8 coarse_dirt
execute in minecraft:overworld run fill 355 70 -8 355 144 -8 air
execute in minecraft:overworld run fill 355 58 -7 355 66 -7 stone
execute in minecraft:overworld run fill 355 67 -7 355 68 -7 dirt
execute in minecraft:overworld run setblock 355 69 -7 coarse_dirt
execute in minecraft:overworld run fill 355 70 -7 355 144 -7 air
execute in minecraft:overworld run fill 355 58 -6 355 66 -6 stone
execute in minecraft:overworld run fill 355 67 -6 355 68 -6 dirt
execute in minecraft:overworld run setblock 355 69 -6 coarse_dirt
execute in minecraft:overworld run fill 355 70 -6 355 144 -6 air
execute in minecraft:overworld run fill 355 58 -5 355 66 -5 stone
execute in minecraft:overworld run fill 355 67 -5 355 68 -5 dirt
execute in minecraft:overworld run setblock 355 69 -5 coarse_dirt
execute in minecraft:overworld run fill 355 70 -5 355 144 -5 air
execute in minecraft:overworld run fill 355 58 -4 355 66 -4 stone
execute in minecraft:overworld run fill 355 67 -4 355 68 -4 dirt
execute in minecraft:overworld run setblock 355 69 -4 coarse_dirt
execute in minecraft:overworld run fill 355 70 -4 355 144 -4 air
execute in minecraft:overworld run fill 355 58 -3 355 66 -3 stone
execute in minecraft:overworld run fill 355 67 -3 355 68 -3 dirt
execute in minecraft:overworld run setblock 355 69 -3 coarse_dirt
execute in minecraft:overworld run fill 355 70 -3 355 144 -3 air
execute in minecraft:overworld run fill 355 58 -2 355 66 -2 stone
execute in minecraft:overworld run fill 355 67 -2 355 68 -2 dirt
execute in minecraft:overworld run setblock 355 69 -2 grass_block
execute in minecraft:overworld run fill 355 70 -2 355 144 -2 air
execute in minecraft:overworld run fill 355 58 -1 355 66 -1 stone
execute in minecraft:overworld run fill 355 67 -1 355 68 -1 dirt
execute in minecraft:overworld run setblock 355 69 -1 grass_block
execute in minecraft:overworld run fill 355 70 -1 355 144 -1 air
execute in minecraft:overworld run fill 355 58 0 355 66 0 stone
execute in minecraft:overworld run fill 355 67 0 355 68 0 dirt
execute in minecraft:overworld run setblock 355 69 0 grass_block
execute in minecraft:overworld run fill 355 70 0 355 144 0 air
execute in minecraft:overworld run setblock 355 70 0 mossy_cobblestone
execute in minecraft:overworld run fill 355 58 1 355 66 1 stone
execute in minecraft:overworld run fill 355 67 1 355 68 1 dirt
execute in minecraft:overworld run setblock 355 69 1 grass_block
execute in minecraft:overworld run fill 355 70 1 355 144 1 air
execute in minecraft:overworld run fill 355 58 2 355 66 2 stone
execute in minecraft:overworld run fill 355 67 2 355 68 2 dirt
execute in minecraft:overworld run setblock 355 69 2 coarse_dirt
execute in minecraft:overworld run fill 355 70 2 355 144 2 air
execute in minecraft:overworld run fill 355 58 3 355 66 3 stone
execute in minecraft:overworld run fill 355 67 3 355 68 3 dirt
execute in minecraft:overworld run setblock 355 69 3 coarse_dirt
execute in minecraft:overworld run fill 355 70 3 355 144 3 air
execute in minecraft:overworld run fill 355 58 4 355 66 4 stone
execute in minecraft:overworld run fill 355 67 4 355 68 4 dirt
execute in minecraft:overworld run setblock 355 69 4 coarse_dirt
execute in minecraft:overworld run fill 355 70 4 355 144 4 air
execute in minecraft:overworld run fill 355 58 5 355 67 5 stone
execute in minecraft:overworld run fill 355 68 5 355 69 5 dirt
execute in minecraft:overworld run setblock 355 70 5 coarse_dirt
execute in minecraft:overworld run fill 355 71 5 355 144 5 air
execute in minecraft:overworld run fill 355 58 6 355 67 6 stone
execute in minecraft:overworld run fill 355 68 6 355 69 6 dirt
execute in minecraft:overworld run setblock 355 70 6 grass_block
execute in minecraft:overworld run fill 355 71 6 355 144 6 air
execute in minecraft:overworld run setblock 355 71 6 grass
execute in minecraft:overworld run fill 355 58 7 355 67 7 stone
execute in minecraft:overworld run fill 355 68 7 355 69 7 dirt
execute in minecraft:overworld run setblock 355 70 7 grass_block
execute in minecraft:overworld run fill 355 71 7 355 144 7 air
execute in minecraft:overworld run fill 355 58 8 355 67 8 stone
execute in minecraft:overworld run fill 355 68 8 355 69 8 dirt
execute in minecraft:overworld run setblock 355 70 8 grass_block
execute in minecraft:overworld run fill 355 71 8 355 144 8 air
execute in minecraft:overworld run fill 355 58 9 355 68 9 stone
execute in minecraft:overworld run fill 355 69 9 355 70 9 dirt
execute in minecraft:overworld run setblock 355 71 9 coarse_dirt
execute in minecraft:overworld run fill 355 72 9 355 144 9 air
execute in minecraft:overworld run fill 355 58 10 355 68 10 stone
execute in minecraft:overworld run fill 355 69 10 355 70 10 dirt
execute in minecraft:overworld run setblock 355 71 10 grass_block
execute in minecraft:overworld run fill 355 72 10 355 144 10 air
execute in minecraft:overworld run fill 355 58 11 355 68 11 stone
execute in minecraft:overworld run fill 355 69 11 355 70 11 dirt
execute in minecraft:overworld run setblock 355 71 11 coarse_dirt
execute in minecraft:overworld run fill 355 72 11 355 144 11 air
execute in minecraft:overworld run fill 355 58 12 355 68 12 stone
execute in minecraft:overworld run fill 355 69 12 355 70 12 dirt
execute in minecraft:overworld run setblock 355 71 12 coarse_dirt
execute in minecraft:overworld run fill 355 72 12 355 144 12 air
execute in minecraft:overworld run setblock 355 72 12 grass
execute in minecraft:overworld run fill 355 58 13 355 67 13 stone
execute in minecraft:overworld run fill 355 68 13 355 69 13 dirt
execute in minecraft:overworld run setblock 355 70 13 coarse_dirt
execute in minecraft:overworld run fill 355 71 13 355 144 13 air
execute in minecraft:overworld run fill 355 58 14 355 67 14 stone
execute in minecraft:overworld run fill 355 68 14 355 69 14 dirt
execute in minecraft:overworld run setblock 355 70 14 grass_block
execute in minecraft:overworld run fill 355 71 14 355 144 14 air
execute in minecraft:overworld run fill 355 58 15 355 67 15 stone
execute in minecraft:overworld run fill 355 68 15 355 69 15 dirt
execute in minecraft:overworld run setblock 355 70 15 coarse_dirt
execute in minecraft:overworld run fill 355 71 15 355 144 15 air
execute in minecraft:overworld run fill 355 58 16 355 67 16 stone
execute in minecraft:overworld run fill 355 68 16 355 69 16 dirt
schedule function blade_gallery:random/battlefield/part_30 1t replace
