execute in minecraft:overworld run setblock 378 67 -13 coarse_dirt
execute in minecraft:overworld run fill 378 68 -13 378 144 -13 air
execute in minecraft:overworld run fill 378 58 -12 378 64 -12 stone
execute in minecraft:overworld run fill 378 65 -12 378 66 -12 dirt
execute in minecraft:overworld run setblock 378 67 -12 grass_block
execute in minecraft:overworld run fill 378 68 -12 378 144 -12 air
execute in minecraft:overworld run fill 378 58 -11 378 64 -11 stone
execute in minecraft:overworld run fill 378 65 -11 378 66 -11 dirt
execute in minecraft:overworld run setblock 378 67 -11 coarse_dirt
execute in minecraft:overworld run fill 378 68 -11 378 144 -11 air
execute in minecraft:overworld run setblock 378 68 -11 grass
execute in minecraft:overworld run fill 378 58 -10 378 64 -10 stone
execute in minecraft:overworld run fill 378 65 -10 378 66 -10 dirt
execute in minecraft:overworld run setblock 378 67 -10 coarse_dirt
execute in minecraft:overworld run fill 378 68 -10 378 144 -10 air
execute in minecraft:overworld run fill 378 58 -9 378 64 -9 stone
execute in minecraft:overworld run fill 378 65 -9 378 66 -9 dirt
execute in minecraft:overworld run setblock 378 67 -9 coarse_dirt
execute in minecraft:overworld run fill 378 68 -9 378 144 -9 air
execute in minecraft:overworld run setblock 378 68 -9 grass
execute in minecraft:overworld run fill 378 58 -8 378 64 -8 stone
execute in minecraft:overworld run fill 378 65 -8 378 66 -8 dirt
execute in minecraft:overworld run setblock 378 67 -8 coarse_dirt
execute in minecraft:overworld run fill 378 68 -8 378 144 -8 air
execute in minecraft:overworld run fill 378 58 -7 378 64 -7 stone
execute in minecraft:overworld run fill 378 65 -7 378 66 -7 dirt
execute in minecraft:overworld run setblock 378 67 -7 coarse_dirt
execute in minecraft:overworld run fill 378 68 -7 378 144 -7 air
execute in minecraft:overworld run fill 378 58 -6 378 64 -6 stone
execute in minecraft:overworld run fill 378 65 -6 378 66 -6 dirt
execute in minecraft:overworld run setblock 378 67 -6 coarse_dirt
execute in minecraft:overworld run fill 378 68 -6 378 144 -6 air
execute in minecraft:overworld run fill 378 58 -5 378 65 -5 stone
execute in minecraft:overworld run fill 378 66 -5 378 67 -5 dirt
execute in minecraft:overworld run setblock 378 68 -5 coarse_dirt
execute in minecraft:overworld run fill 378 69 -5 378 144 -5 air
execute in minecraft:overworld run setblock 378 69 -5 grass
execute in minecraft:overworld run fill 378 58 -4 378 65 -4 stone
execute in minecraft:overworld run fill 378 66 -4 378 67 -4 dirt
execute in minecraft:overworld run setblock 378 68 -4 coarse_dirt
execute in minecraft:overworld run fill 378 69 -4 378 144 -4 air
execute in minecraft:overworld run fill 378 58 -3 378 65 -3 stone
execute in minecraft:overworld run fill 378 66 -3 378 67 -3 dirt
execute in minecraft:overworld run setblock 378 68 -3 coarse_dirt
execute in minecraft:overworld run fill 378 69 -3 378 144 -3 air
execute in minecraft:overworld run fill 378 58 -2 378 65 -2 stone
execute in minecraft:overworld run fill 378 66 -2 378 67 -2 dirt
execute in minecraft:overworld run setblock 378 68 -2 grass_block
execute in minecraft:overworld run fill 378 69 -2 378 144 -2 air
execute in minecraft:overworld run fill 378 58 -1 378 65 -1 stone
execute in minecraft:overworld run fill 378 66 -1 378 67 -1 dirt
execute in minecraft:overworld run setblock 378 68 -1 coarse_dirt
execute in minecraft:overworld run fill 378 69 -1 378 144 -1 air
execute in minecraft:overworld run fill 378 58 0 378 65 0 stone
execute in minecraft:overworld run fill 378 66 0 378 67 0 dirt
execute in minecraft:overworld run setblock 378 68 0 coarse_dirt
execute in minecraft:overworld run fill 378 69 0 378 144 0 air
execute in minecraft:overworld run fill 378 58 1 378 65 1 stone
execute in minecraft:overworld run fill 378 66 1 378 67 1 dirt
execute in minecraft:overworld run setblock 378 68 1 coarse_dirt
execute in minecraft:overworld run fill 378 69 1 378 144 1 air
execute in minecraft:overworld run fill 378 58 2 378 65 2 stone
execute in minecraft:overworld run fill 378 66 2 378 67 2 dirt
execute in minecraft:overworld run setblock 378 68 2 grass_block
execute in minecraft:overworld run fill 378 69 2 378 144 2 air
execute in minecraft:overworld run fill 378 58 3 378 65 3 stone
execute in minecraft:overworld run fill 378 66 3 378 67 3 dirt
execute in minecraft:overworld run setblock 378 68 3 grass_block
execute in minecraft:overworld run fill 378 69 3 378 144 3 air
execute in minecraft:overworld run fill 378 58 4 378 65 4 stone
execute in minecraft:overworld run fill 378 66 4 378 67 4 dirt
execute in minecraft:overworld run setblock 378 68 4 coarse_dirt
execute in minecraft:overworld run fill 378 69 4 378 144 4 air
execute in minecraft:overworld run fill 378 58 5 378 65 5 stone
execute in minecraft:overworld run fill 378 66 5 378 67 5 dirt
execute in minecraft:overworld run setblock 378 68 5 coarse_dirt
execute in minecraft:overworld run fill 378 69 5 378 144 5 air
execute in minecraft:overworld run fill 378 58 6 378 65 6 stone
execute in minecraft:overworld run fill 378 66 6 378 67 6 dirt
execute in minecraft:overworld run setblock 378 68 6 grass_block
execute in minecraft:overworld run fill 378 69 6 378 144 6 air
execute in minecraft:overworld run fill 378 58 7 378 65 7 stone
execute in minecraft:overworld run fill 378 66 7 378 67 7 dirt
execute in minecraft:overworld run setblock 378 68 7 coarse_dirt
execute in minecraft:overworld run fill 378 69 7 378 144 7 air
execute in minecraft:overworld run setblock 378 69 7 grass
execute in minecraft:overworld run fill 378 58 8 378 65 8 stone
execute in minecraft:overworld run fill 378 66 8 378 67 8 dirt
execute in minecraft:overworld run setblock 378 68 8 grass_block
execute in minecraft:overworld run fill 378 69 8 378 144 8 air
execute in minecraft:overworld run fill 378 58 9 378 65 9 stone
execute in minecraft:overworld run fill 378 66 9 378 67 9 dirt
execute in minecraft:overworld run setblock 378 68 9 coarse_dirt
execute in minecraft:overworld run fill 378 69 9 378 144 9 air
execute in minecraft:overworld run fill 378 58 10 378 66 10 stone
execute in minecraft:overworld run fill 378 67 10 378 68 10 dirt
execute in minecraft:overworld run setblock 378 69 10 coarse_dirt
execute in minecraft:overworld run fill 378 70 10 378 144 10 air
execute in minecraft:overworld run fill 378 58 11 378 66 11 stone
execute in minecraft:overworld run fill 378 67 11 378 68 11 dirt
execute in minecraft:overworld run setblock 378 69 11 coarse_dirt
execute in minecraft:overworld run fill 378 70 11 378 144 11 air
execute in minecraft:overworld run fill 378 58 12 378 66 12 stone
execute in minecraft:overworld run fill 378 67 12 378 68 12 dirt
execute in minecraft:overworld run setblock 378 69 12 grass_block
execute in minecraft:overworld run fill 378 70 12 378 144 12 air
execute in minecraft:overworld run fill 378 58 13 378 67 13 stone
execute in minecraft:overworld run fill 378 68 13 378 69 13 dirt
execute in minecraft:overworld run setblock 378 70 13 grass_block
execute in minecraft:overworld run fill 378 71 13 378 144 13 air
execute in minecraft:overworld run fill 378 58 14 378 67 14 stone
execute in minecraft:overworld run fill 378 68 14 378 69 14 dirt
execute in minecraft:overworld run setblock 378 70 14 grass_block
execute in minecraft:overworld run fill 378 71 14 378 144 14 air
execute in minecraft:overworld run fill 378 58 15 378 67 15 stone
execute in minecraft:overworld run fill 378 68 15 378 69 15 dirt
execute in minecraft:overworld run setblock 378 70 15 coarse_dirt
execute in minecraft:overworld run fill 378 71 15 378 144 15 air
execute in minecraft:overworld run fill 378 58 16 378 68 16 stone
execute in minecraft:overworld run fill 378 69 16 378 70 16 dirt
execute in minecraft:overworld run setblock 378 71 16 coarse_dirt
execute in minecraft:overworld run fill 378 72 16 378 144 16 air
execute in minecraft:overworld run fill 378 58 17 378 68 17 stone
execute in minecraft:overworld run fill 378 69 17 378 70 17 dirt
execute in minecraft:overworld run setblock 378 71 17 coarse_dirt
execute in minecraft:overworld run fill 378 72 17 378 144 17 air
execute in minecraft:overworld run fill 378 58 18 378 68 18 stone
execute in minecraft:overworld run fill 378 69 18 378 70 18 dirt
execute in minecraft:overworld run setblock 378 71 18 grass_block
execute in minecraft:overworld run fill 378 72 18 378 144 18 air
execute in minecraft:overworld run fill 378 58 19 378 68 19 stone
execute in minecraft:overworld run fill 378 69 19 378 70 19 dirt
execute in minecraft:overworld run setblock 378 71 19 grass_block
execute in minecraft:overworld run fill 378 72 19 378 144 19 air
execute in minecraft:overworld run fill 378 58 20 378 68 20 stone
execute in minecraft:overworld run fill 378 69 20 378 70 20 dirt
execute in minecraft:overworld run setblock 378 71 20 coarse_dirt
execute in minecraft:overworld run fill 378 72 20 378 144 20 air
execute in minecraft:overworld run fill 378 58 21 378 68 21 stone
execute in minecraft:overworld run fill 378 69 21 378 70 21 dirt
execute in minecraft:overworld run setblock 378 71 21 grass_block
execute in minecraft:overworld run fill 378 72 21 378 144 21 air
execute in minecraft:overworld run fill 378 58 22 378 68 22 stone
execute in minecraft:overworld run fill 378 69 22 378 70 22 dirt
execute in minecraft:overworld run setblock 378 71 22 grass_block
execute in minecraft:overworld run fill 378 72 22 378 144 22 air
execute in minecraft:overworld run fill 378 58 23 378 67 23 stone
execute in minecraft:overworld run fill 378 68 23 378 69 23 dirt
execute in minecraft:overworld run setblock 378 70 23 coarse_dirt
execute in minecraft:overworld run fill 378 71 23 378 144 23 air
execute in minecraft:overworld run fill 378 58 24 378 67 24 stone
execute in minecraft:overworld run fill 378 68 24 378 69 24 dirt
execute in minecraft:overworld run setblock 378 70 24 grass_block
execute in minecraft:overworld run fill 378 71 24 378 144 24 air
execute in minecraft:overworld run setblock 378 71 24 mossy_cobblestone
execute in minecraft:overworld run fill 378 58 25 378 67 25 stone
execute in minecraft:overworld run fill 378 68 25 378 69 25 dirt
execute in minecraft:overworld run setblock 378 70 25 grass_block
execute in minecraft:overworld run fill 378 71 25 378 144 25 air
execute in minecraft:overworld run fill 378 58 26 378 67 26 stone
execute in minecraft:overworld run fill 378 68 26 378 69 26 dirt
execute in minecraft:overworld run setblock 378 70 26 coarse_dirt
execute in minecraft:overworld run fill 378 71 26 378 144 26 air
execute in minecraft:overworld run fill 378 58 27 378 66 27 stone
execute in minecraft:overworld run fill 378 67 27 378 68 27 dirt
execute in minecraft:overworld run setblock 378 69 27 coarse_dirt
execute in minecraft:overworld run fill 378 70 27 378 144 27 air
execute in minecraft:overworld run fill 378 58 28 378 66 28 stone
execute in minecraft:overworld run fill 378 67 28 378 68 28 dirt
execute in minecraft:overworld run setblock 378 69 28 grass_block
execute in minecraft:overworld run fill 378 70 28 378 144 28 air
execute in minecraft:overworld run fill 378 58 29 378 66 29 stone
execute in minecraft:overworld run fill 378 67 29 378 68 29 dirt
execute in minecraft:overworld run setblock 378 69 29 coarse_dirt
execute in minecraft:overworld run fill 378 70 29 378 144 29 air
execute in minecraft:overworld run fill 378 58 30 378 66 30 stone
execute in minecraft:overworld run fill 378 67 30 378 68 30 dirt
execute in minecraft:overworld run setblock 378 69 30 grass_block
execute in minecraft:overworld run fill 378 70 30 378 144 30 air
execute in minecraft:overworld run fill 378 58 31 378 66 31 stone
execute in minecraft:overworld run fill 378 67 31 378 68 31 dirt
execute in minecraft:overworld run setblock 378 69 31 coarse_dirt
execute in minecraft:overworld run fill 378 70 31 378 144 31 air
execute in minecraft:overworld run fill 378 58 32 378 67 32 stone
execute in minecraft:overworld run fill 378 68 32 378 69 32 dirt
execute in minecraft:overworld run setblock 378 70 32 coarse_dirt
execute in minecraft:overworld run fill 378 71 32 378 144 32 air
execute in minecraft:overworld run setblock 378 71 32 grass
execute in minecraft:overworld run fill 378 58 33 378 67 33 stone
execute in minecraft:overworld run fill 378 68 33 378 69 33 dirt
execute in minecraft:overworld run setblock 378 70 33 grass_block
execute in minecraft:overworld run fill 378 71 33 378 144 33 air
execute in minecraft:overworld run setblock 378 71 33 grass
execute in minecraft:overworld run fill 378 58 34 378 67 34 stone
execute in minecraft:overworld run fill 378 68 34 378 69 34 dirt
execute in minecraft:overworld run setblock 378 70 34 coarse_dirt
execute in minecraft:overworld run fill 378 71 34 378 144 34 air
execute in minecraft:overworld run fill 378 58 35 378 67 35 stone
execute in minecraft:overworld run fill 378 68 35 378 69 35 dirt
execute in minecraft:overworld run setblock 378 70 35 coarse_dirt
execute in minecraft:overworld run fill 378 71 35 378 144 35 air
execute in minecraft:overworld run setblock 378 71 35 grass
execute in minecraft:overworld run fill 378 58 36 378 67 36 stone
execute in minecraft:overworld run fill 378 68 36 378 69 36 dirt
execute in minecraft:overworld run setblock 378 70 36 coarse_dirt
execute in minecraft:overworld run fill 378 71 36 378 144 36 air
execute in minecraft:overworld run setblock 378 71 36 grass
execute in minecraft:overworld run fill 378 58 37 378 66 37 stone
execute in minecraft:overworld run fill 378 67 37 378 68 37 dirt
execute in minecraft:overworld run setblock 378 69 37 grass_block
execute in minecraft:overworld run fill 378 70 37 378 144 37 air
execute in minecraft:overworld run fill 378 58 38 378 66 38 stone
execute in minecraft:overworld run fill 378 67 38 378 68 38 dirt
execute in minecraft:overworld run setblock 378 69 38 coarse_dirt
execute in minecraft:overworld run fill 378 70 38 378 144 38 air
execute in minecraft:overworld run fill 378 58 39 378 66 39 stone
execute in minecraft:overworld run fill 378 67 39 378 68 39 dirt
execute in minecraft:overworld run setblock 378 69 39 coarse_dirt
execute in minecraft:overworld run fill 378 70 39 378 144 39 air
execute in minecraft:overworld run fill 378 58 40 378 65 40 stone
execute in minecraft:overworld run fill 378 66 40 378 67 40 dirt
execute in minecraft:overworld run setblock 378 68 40 grass_block
execute in minecraft:overworld run fill 378 69 40 378 144 40 air
execute in minecraft:overworld run fill 378 58 41 378 64 41 stone
execute in minecraft:overworld run fill 378 65 41 378 66 41 dirt
execute in minecraft:overworld run setblock 378 67 41 coarse_dirt
execute in minecraft:overworld run fill 378 68 41 378 144 41 air
execute in minecraft:overworld run fill 378 58 42 378 64 42 stone
execute in minecraft:overworld run fill 378 65 42 378 66 42 dirt
execute in minecraft:overworld run setblock 378 67 42 grass_block
execute in minecraft:overworld run fill 378 68 42 378 144 42 air
execute in minecraft:overworld run fill 378 58 43 378 63 43 stone
execute in minecraft:overworld run fill 378 64 43 378 65 43 dirt
execute in minecraft:overworld run setblock 378 66 43 coarse_dirt
execute in minecraft:overworld run fill 378 67 43 378 144 43 air
execute in minecraft:overworld run fill 378 58 44 378 63 44 stone
execute in minecraft:overworld run fill 378 64 44 378 65 44 dirt
execute in minecraft:overworld run setblock 378 66 44 coarse_dirt
execute in minecraft:overworld run fill 378 67 44 378 144 44 air
execute in minecraft:overworld run fill 378 58 45 378 62 45 stone
execute in minecraft:overworld run fill 378 63 45 378 64 45 dirt
execute in minecraft:overworld run setblock 378 65 45 coarse_dirt
execute in minecraft:overworld run fill 378 66 45 378 144 45 air
execute in minecraft:overworld run fill 378 58 46 378 62 46 stone
execute in minecraft:overworld run fill 378 63 46 378 64 46 dirt
execute in minecraft:overworld run setblock 378 65 46 coarse_dirt
execute in minecraft:overworld run fill 378 66 46 378 144 46 air
execute in minecraft:overworld run fill 378 58 47 378 61 47 stone
execute in minecraft:overworld run fill 378 62 47 378 63 47 dirt
execute in minecraft:overworld run setblock 378 64 47 grass_block
execute in minecraft:overworld run fill 378 65 47 378 144 47 air
execute in minecraft:overworld run fill 379 58 -48 379 61 -48 stone
execute in minecraft:overworld run fill 379 62 -48 379 63 -48 dirt
execute in minecraft:overworld run setblock 379 64 -48 coarse_dirt
execute in minecraft:overworld run fill 379 65 -48 379 144 -48 air
execute in minecraft:overworld run fill 379 58 -47 379 62 -47 stone
schedule function blade_gallery:random/battlefield/part_66 1t replace
