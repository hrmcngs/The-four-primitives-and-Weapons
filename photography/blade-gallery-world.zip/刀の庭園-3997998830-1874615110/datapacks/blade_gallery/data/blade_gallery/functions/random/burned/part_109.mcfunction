execute in minecraft:overworld run fill 276 66 15 276 144 15 air
execute in minecraft:overworld run fill 276 58 16 276 62 16 stone
execute in minecraft:overworld run fill 276 63 16 276 64 16 dirt
execute in minecraft:overworld run setblock 276 65 16 coarse_dirt
execute in minecraft:overworld run fill 276 66 16 276 144 16 air
execute in minecraft:overworld run fill 276 58 17 276 62 17 stone
execute in minecraft:overworld run fill 276 63 17 276 64 17 dirt
execute in minecraft:overworld run setblock 276 65 17 grass_block
execute in minecraft:overworld run fill 276 66 17 276 144 17 air
execute in minecraft:overworld run fill 276 58 18 276 62 18 stone
execute in minecraft:overworld run fill 276 63 18 276 64 18 dirt
execute in minecraft:overworld run setblock 276 65 18 coarse_dirt
execute in minecraft:overworld run fill 276 66 18 276 144 18 air
execute in minecraft:overworld run fill 276 58 19 276 61 19 stone
execute in minecraft:overworld run fill 276 62 19 276 63 19 dirt
execute in minecraft:overworld run setblock 276 64 19 grass_block
execute in minecraft:overworld run fill 276 65 19 276 144 19 air
execute in minecraft:overworld run fill 276 58 20 276 61 20 stone
execute in minecraft:overworld run fill 276 62 20 276 63 20 dirt
execute in minecraft:overworld run setblock 276 64 20 grass_block
execute in minecraft:overworld run fill 276 65 20 276 144 20 air
execute in minecraft:overworld run fill 276 58 21 276 61 21 stone
execute in minecraft:overworld run fill 276 62 21 276 63 21 dirt
execute in minecraft:overworld run setblock 276 64 21 coarse_dirt
execute in minecraft:overworld run fill 276 65 21 276 144 21 air
execute in minecraft:overworld run fill 276 58 22 276 61 22 stone
execute in minecraft:overworld run fill 276 62 22 276 63 22 dirt
execute in minecraft:overworld run setblock 276 64 22 coarse_dirt
execute in minecraft:overworld run fill 276 65 22 276 144 22 air
execute in minecraft:overworld run fill 276 58 23 276 61 23 stone
execute in minecraft:overworld run fill 276 62 23 276 63 23 dirt
execute in minecraft:overworld run setblock 276 64 23 coarse_dirt
execute in minecraft:overworld run fill 276 65 23 276 144 23 air
execute in minecraft:overworld run fill 276 58 24 276 61 24 stone
execute in minecraft:overworld run fill 276 62 24 276 63 24 dirt
execute in minecraft:overworld run setblock 276 64 24 grass_block
execute in minecraft:overworld run fill 276 65 24 276 144 24 air
execute in minecraft:overworld run fill 276 58 25 276 61 25 stone
execute in minecraft:overworld run fill 276 62 25 276 63 25 dirt
execute in minecraft:overworld run setblock 276 64 25 coarse_dirt
execute in minecraft:overworld run fill 276 65 25 276 144 25 air
execute in minecraft:overworld run fill 276 58 26 276 62 26 stone
execute in minecraft:overworld run fill 276 63 26 276 64 26 dirt
execute in minecraft:overworld run setblock 276 65 26 grass_block
execute in minecraft:overworld run fill 276 66 26 276 144 26 air
execute in minecraft:overworld run fill 276 58 27 276 62 27 stone
execute in minecraft:overworld run fill 276 63 27 276 64 27 dirt
execute in minecraft:overworld run setblock 276 65 27 grass_block
execute in minecraft:overworld run fill 276 66 27 276 144 27 air
execute in minecraft:overworld run setblock 276 66 27 grass
execute in minecraft:overworld run fill 276 58 28 276 62 28 stone
execute in minecraft:overworld run fill 276 63 28 276 64 28 dirt
execute in minecraft:overworld run setblock 276 65 28 grass_block
execute in minecraft:overworld run fill 276 66 28 276 144 28 air
execute in minecraft:overworld run fill 276 58 29 276 62 29 stone
execute in minecraft:overworld run fill 276 63 29 276 64 29 dirt
execute in minecraft:overworld run setblock 276 65 29 coarse_dirt
execute in minecraft:overworld run fill 276 66 29 276 144 29 air
execute in minecraft:overworld run fill 276 58 30 276 62 30 stone
execute in minecraft:overworld run fill 276 63 30 276 64 30 dirt
execute in minecraft:overworld run setblock 276 65 30 coarse_dirt
execute in minecraft:overworld run fill 276 66 30 276 144 30 air
execute in minecraft:overworld run fill 276 58 31 276 62 31 stone
execute in minecraft:overworld run fill 276 63 31 276 64 31 dirt
execute in minecraft:overworld run setblock 276 65 31 grass_block
execute in minecraft:overworld run fill 276 66 31 276 144 31 air
execute in minecraft:overworld run fill 276 58 32 276 62 32 stone
execute in minecraft:overworld run fill 276 63 32 276 64 32 dirt
execute in minecraft:overworld run setblock 276 65 32 coarse_dirt
execute in minecraft:overworld run fill 276 66 32 276 144 32 air
execute in minecraft:overworld run fill 276 58 33 276 62 33 stone
execute in minecraft:overworld run fill 276 63 33 276 64 33 dirt
execute in minecraft:overworld run setblock 276 65 33 coarse_dirt
execute in minecraft:overworld run fill 276 66 33 276 144 33 air
execute in minecraft:overworld run fill 276 58 34 276 61 34 stone
execute in minecraft:overworld run fill 276 62 34 276 63 34 dirt
execute in minecraft:overworld run setblock 276 64 34 coarse_dirt
execute in minecraft:overworld run fill 276 65 34 276 144 34 air
execute in minecraft:overworld run fill 276 58 35 276 61 35 stone
execute in minecraft:overworld run fill 276 62 35 276 63 35 dirt
execute in minecraft:overworld run setblock 276 64 35 coarse_dirt
execute in minecraft:overworld run fill 276 65 35 276 144 35 air
execute in minecraft:overworld run fill 276 58 36 276 61 36 stone
execute in minecraft:overworld run fill 276 62 36 276 63 36 dirt
execute in minecraft:overworld run setblock 276 64 36 grass_block
execute in minecraft:overworld run fill 276 65 36 276 144 36 air
execute in minecraft:overworld run fill 276 58 37 276 61 37 stone
execute in minecraft:overworld run fill 276 62 37 276 63 37 dirt
execute in minecraft:overworld run setblock 276 64 37 coarse_dirt
execute in minecraft:overworld run fill 276 65 37 276 144 37 air
execute in minecraft:overworld run fill 276 58 38 276 61 38 stone
execute in minecraft:overworld run fill 276 62 38 276 63 38 dirt
execute in minecraft:overworld run setblock 276 64 38 grass_block
execute in minecraft:overworld run fill 276 65 38 276 144 38 air
execute in minecraft:overworld run fill 276 58 39 276 61 39 stone
execute in minecraft:overworld run fill 276 62 39 276 63 39 dirt
execute in minecraft:overworld run setblock 276 64 39 coarse_dirt
execute in minecraft:overworld run fill 276 65 39 276 144 39 air
execute in minecraft:overworld run fill 276 58 40 276 61 40 stone
execute in minecraft:overworld run fill 276 62 40 276 63 40 dirt
execute in minecraft:overworld run setblock 276 64 40 grass_block
execute in minecraft:overworld run fill 276 65 40 276 144 40 air
execute in minecraft:overworld run fill 276 58 41 276 61 41 stone
execute in minecraft:overworld run fill 276 62 41 276 63 41 dirt
execute in minecraft:overworld run setblock 276 64 41 coarse_dirt
execute in minecraft:overworld run fill 276 65 41 276 144 41 air
execute in minecraft:overworld run fill 276 58 42 276 61 42 stone
execute in minecraft:overworld run fill 276 62 42 276 63 42 dirt
execute in minecraft:overworld run setblock 276 64 42 coarse_dirt
execute in minecraft:overworld run fill 276 65 42 276 144 42 air
execute in minecraft:overworld run fill 276 58 43 276 61 43 stone
execute in minecraft:overworld run fill 276 62 43 276 63 43 dirt
execute in minecraft:overworld run setblock 276 64 43 grass_block
execute in minecraft:overworld run fill 276 65 43 276 144 43 air
execute in minecraft:overworld run fill 276 58 44 276 61 44 stone
execute in minecraft:overworld run fill 276 62 44 276 63 44 dirt
execute in minecraft:overworld run setblock 276 64 44 grass_block
execute in minecraft:overworld run fill 276 65 44 276 144 44 air
execute in minecraft:overworld run fill 276 58 45 276 61 45 stone
execute in minecraft:overworld run fill 276 62 45 276 63 45 dirt
execute in minecraft:overworld run setblock 276 64 45 coarse_dirt
execute in minecraft:overworld run fill 276 65 45 276 144 45 air
execute in minecraft:overworld run fill 276 58 46 276 61 46 stone
execute in minecraft:overworld run fill 276 62 46 276 63 46 dirt
execute in minecraft:overworld run setblock 276 64 46 coarse_dirt
execute in minecraft:overworld run fill 276 65 46 276 144 46 air
execute in minecraft:overworld run fill 276 58 47 276 61 47 stone
execute in minecraft:overworld run fill 276 62 47 276 63 47 dirt
execute in minecraft:overworld run setblock 276 64 47 coarse_dirt
execute in minecraft:overworld run fill 276 65 47 276 144 47 air
execute in minecraft:overworld run fill 277 58 -48 277 61 -48 stone
execute in minecraft:overworld run fill 277 62 -48 277 63 -48 dirt
execute in minecraft:overworld run setblock 277 64 -48 coarse_dirt
execute in minecraft:overworld run fill 277 65 -48 277 144 -48 air
execute in minecraft:overworld run fill 277 58 -47 277 63 -47 stone
execute in minecraft:overworld run fill 277 64 -47 277 65 -47 dirt
execute in minecraft:overworld run setblock 277 66 -47 coarse_dirt
execute in minecraft:overworld run fill 277 67 -47 277 144 -47 air
execute in minecraft:overworld run fill 277 58 -46 277 65 -46 stone
execute in minecraft:overworld run fill 277 66 -46 277 67 -46 dirt
execute in minecraft:overworld run setblock 277 68 -46 grass_block
execute in minecraft:overworld run fill 277 69 -46 277 144 -46 air
execute in minecraft:overworld run fill 277 58 -45 277 68 -45 stone
execute in minecraft:overworld run fill 277 69 -45 277 70 -45 dirt
execute in minecraft:overworld run setblock 277 71 -45 coarse_dirt
execute in minecraft:overworld run fill 277 72 -45 277 144 -45 air
execute in minecraft:overworld run fill 277 58 -44 277 70 -44 stone
execute in minecraft:overworld run fill 277 71 -44 277 72 -44 dirt
execute in minecraft:overworld run setblock 277 73 -44 coarse_dirt
execute in minecraft:overworld run fill 277 74 -44 277 144 -44 air
execute in minecraft:overworld run fill 277 58 -43 277 72 -43 stone
execute in minecraft:overworld run fill 277 73 -43 277 74 -43 dirt
execute in minecraft:overworld run setblock 277 75 -43 coarse_dirt
execute in minecraft:overworld run fill 277 76 -43 277 144 -43 air
execute in minecraft:overworld run fill 277 58 -42 277 73 -42 stone
execute in minecraft:overworld run fill 277 74 -42 277 75 -42 dirt
execute in minecraft:overworld run setblock 277 76 -42 grass_block
execute in minecraft:overworld run fill 277 77 -42 277 144 -42 air
execute in minecraft:overworld run fill 277 58 -41 277 75 -41 stone
execute in minecraft:overworld run fill 277 76 -41 277 77 -41 dirt
execute in minecraft:overworld run setblock 277 78 -41 grass_block
execute in minecraft:overworld run fill 277 79 -41 277 144 -41 air
execute in minecraft:overworld run fill 277 58 -40 277 76 -40 stone
execute in minecraft:overworld run fill 277 77 -40 277 78 -40 dirt
execute in minecraft:overworld run setblock 277 79 -40 grass_block
execute in minecraft:overworld run fill 277 80 -40 277 144 -40 air
execute in minecraft:overworld run setblock 277 80 -40 grass
execute in minecraft:overworld run fill 277 58 -39 277 78 -39 stone
execute in minecraft:overworld run fill 277 79 -39 277 80 -39 dirt
execute in minecraft:overworld run setblock 277 81 -39 coarse_dirt
execute in minecraft:overworld run fill 277 82 -39 277 144 -39 air
execute in minecraft:overworld run fill 277 58 -38 277 79 -38 stone
execute in minecraft:overworld run fill 277 80 -38 277 81 -38 dirt
execute in minecraft:overworld run setblock 277 82 -38 coarse_dirt
execute in minecraft:overworld run fill 277 83 -38 277 144 -38 air
execute in minecraft:overworld run fill 277 58 -37 277 79 -37 stone
execute in minecraft:overworld run fill 277 80 -37 277 81 -37 dirt
execute in minecraft:overworld run setblock 277 82 -37 coarse_dirt
execute in minecraft:overworld run fill 277 83 -37 277 144 -37 air
execute in minecraft:overworld run fill 277 58 -36 277 78 -36 stone
execute in minecraft:overworld run fill 277 79 -36 277 80 -36 dirt
execute in minecraft:overworld run setblock 277 81 -36 coarse_dirt
execute in minecraft:overworld run fill 277 82 -36 277 144 -36 air
execute in minecraft:overworld run fill 277 58 -35 277 78 -35 stone
execute in minecraft:overworld run fill 277 79 -35 277 80 -35 dirt
execute in minecraft:overworld run setblock 277 81 -35 coarse_dirt
execute in minecraft:overworld run fill 277 82 -35 277 144 -35 air
execute in minecraft:overworld run fill 277 58 -34 277 77 -34 stone
execute in minecraft:overworld run fill 277 78 -34 277 79 -34 dirt
execute in minecraft:overworld run setblock 277 80 -34 grass_block
execute in minecraft:overworld run fill 277 81 -34 277 144 -34 air
execute in minecraft:overworld run fill 277 58 -33 277 77 -33 stone
execute in minecraft:overworld run fill 277 78 -33 277 79 -33 dirt
execute in minecraft:overworld run setblock 277 80 -33 grass_block
execute in minecraft:overworld run fill 277 81 -33 277 144 -33 air
execute in minecraft:overworld run fill 277 58 -32 277 77 -32 stone
execute in minecraft:overworld run fill 277 78 -32 277 79 -32 dirt
execute in minecraft:overworld run setblock 277 80 -32 coarse_dirt
execute in minecraft:overworld run fill 277 81 -32 277 144 -32 air
execute in minecraft:overworld run fill 277 58 -31 277 76 -31 stone
execute in minecraft:overworld run fill 277 77 -31 277 78 -31 dirt
execute in minecraft:overworld run setblock 277 79 -31 coarse_dirt
execute in minecraft:overworld run fill 277 80 -31 277 144 -31 air
execute in minecraft:overworld run fill 277 58 -30 277 76 -30 stone
execute in minecraft:overworld run fill 277 77 -30 277 78 -30 dirt
execute in minecraft:overworld run setblock 277 79 -30 coarse_dirt
execute in minecraft:overworld run fill 277 80 -30 277 144 -30 air
execute in minecraft:overworld run fill 277 58 -29 277 76 -29 stone
execute in minecraft:overworld run fill 277 77 -29 277 78 -29 dirt
execute in minecraft:overworld run setblock 277 79 -29 coarse_dirt
execute in minecraft:overworld run fill 277 80 -29 277 144 -29 air
execute in minecraft:overworld run fill 277 58 -28 277 76 -28 stone
execute in minecraft:overworld run fill 277 77 -28 277 78 -28 dirt
execute in minecraft:overworld run setblock 277 79 -28 coarse_dirt
execute in minecraft:overworld run fill 277 80 -28 277 144 -28 air
execute in minecraft:overworld run fill 277 58 -27 277 75 -27 stone
execute in minecraft:overworld run fill 277 76 -27 277 77 -27 dirt
execute in minecraft:overworld run setblock 277 78 -27 coarse_dirt
execute in minecraft:overworld run fill 277 79 -27 277 144 -27 air
execute in minecraft:overworld run setblock 277 79 -27 grass
execute in minecraft:overworld run fill 277 58 -26 277 75 -26 stone
execute in minecraft:overworld run fill 277 76 -26 277 77 -26 dirt
execute in minecraft:overworld run setblock 277 78 -26 coarse_dirt
execute in minecraft:overworld run fill 277 79 -26 277 144 -26 air
execute in minecraft:overworld run fill 277 58 -25 277 75 -25 stone
execute in minecraft:overworld run fill 277 76 -25 277 77 -25 dirt
execute in minecraft:overworld run setblock 277 78 -25 coarse_dirt
execute in minecraft:overworld run fill 277 79 -25 277 144 -25 air
execute in minecraft:overworld run fill 277 58 -24 277 74 -24 stone
execute in minecraft:overworld run fill 277 75 -24 277 76 -24 dirt
execute in minecraft:overworld run setblock 277 77 -24 grass_block
execute in minecraft:overworld run fill 277 78 -24 277 144 -24 air
execute in minecraft:overworld run fill 277 58 -23 277 74 -23 stone
execute in minecraft:overworld run fill 277 75 -23 277 76 -23 dirt
execute in minecraft:overworld run setblock 277 77 -23 coarse_dirt
execute in minecraft:overworld run fill 277 78 -23 277 144 -23 air
execute in minecraft:overworld run fill 277 58 -22 277 74 -22 stone
execute in minecraft:overworld run fill 277 75 -22 277 76 -22 dirt
execute in minecraft:overworld run setblock 277 77 -22 grass_block
execute in minecraft:overworld run fill 277 78 -22 277 144 -22 air
execute in minecraft:overworld run fill 277 58 -21 277 73 -21 stone
execute in minecraft:overworld run fill 277 74 -21 277 75 -21 dirt
execute in minecraft:overworld run setblock 277 76 -21 grass_block
execute in minecraft:overworld run fill 277 77 -21 277 144 -21 air
execute in minecraft:overworld run fill 277 58 -20 277 73 -20 stone
execute in minecraft:overworld run fill 277 74 -20 277 75 -20 dirt
execute in minecraft:overworld run setblock 277 76 -20 coarse_dirt
execute in minecraft:overworld run fill 277 77 -20 277 144 -20 air
execute in minecraft:overworld run fill 277 58 -19 277 73 -19 stone
execute in minecraft:overworld run fill 277 74 -19 277 75 -19 dirt
execute in minecraft:overworld run setblock 277 76 -19 coarse_dirt
execute in minecraft:overworld run fill 277 77 -19 277 144 -19 air
execute in minecraft:overworld run fill 277 58 -18 277 72 -18 stone
execute in minecraft:overworld run fill 277 73 -18 277 74 -18 dirt
execute in minecraft:overworld run setblock 277 75 -18 coarse_dirt
execute in minecraft:overworld run fill 277 76 -18 277 144 -18 air
schedule function blade_gallery:random/burned/part_110 1t replace
