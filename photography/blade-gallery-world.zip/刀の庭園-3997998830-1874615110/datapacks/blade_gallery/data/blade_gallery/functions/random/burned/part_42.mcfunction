execute in minecraft:overworld run setblock 235 68 -10 coarse_dirt
execute in minecraft:overworld run fill 235 69 -10 235 144 -10 air
execute in minecraft:overworld run setblock 235 69 -10 grass
execute in minecraft:overworld run fill 235 58 -9 235 65 -9 stone
execute in minecraft:overworld run fill 235 66 -9 235 67 -9 dirt
execute in minecraft:overworld run setblock 235 68 -9 coarse_dirt
execute in minecraft:overworld run fill 235 69 -9 235 144 -9 air
execute in minecraft:overworld run fill 235 58 -8 235 65 -8 stone
execute in minecraft:overworld run fill 235 66 -8 235 67 -8 dirt
execute in minecraft:overworld run setblock 235 68 -8 grass_block
execute in minecraft:overworld run fill 235 69 -8 235 144 -8 air
execute in minecraft:overworld run fill 235 58 -7 235 65 -7 stone
execute in minecraft:overworld run fill 235 66 -7 235 67 -7 dirt
execute in minecraft:overworld run setblock 235 68 -7 grass_block
execute in minecraft:overworld run fill 235 69 -7 235 144 -7 air
execute in minecraft:overworld run setblock 235 69 -7 grass
execute in minecraft:overworld run fill 235 58 -6 235 64 -6 stone
execute in minecraft:overworld run fill 235 65 -6 235 66 -6 dirt
execute in minecraft:overworld run setblock 235 67 -6 coarse_dirt
execute in minecraft:overworld run fill 235 68 -6 235 144 -6 air
execute in minecraft:overworld run fill 235 58 -5 235 64 -5 stone
execute in minecraft:overworld run fill 235 65 -5 235 66 -5 dirt
execute in minecraft:overworld run setblock 235 67 -5 coarse_dirt
execute in minecraft:overworld run fill 235 68 -5 235 144 -5 air
execute in minecraft:overworld run fill 235 58 -4 235 64 -4 stone
execute in minecraft:overworld run fill 235 65 -4 235 66 -4 dirt
execute in minecraft:overworld run setblock 235 67 -4 grass_block
execute in minecraft:overworld run fill 235 68 -4 235 144 -4 air
execute in minecraft:overworld run setblock 235 68 -4 grass
execute in minecraft:overworld run fill 235 58 -3 235 64 -3 stone
execute in minecraft:overworld run fill 235 65 -3 235 66 -3 dirt
execute in minecraft:overworld run setblock 235 67 -3 grass_block
execute in minecraft:overworld run fill 235 68 -3 235 144 -3 air
execute in minecraft:overworld run fill 235 58 -2 235 64 -2 stone
execute in minecraft:overworld run fill 235 65 -2 235 66 -2 dirt
execute in minecraft:overworld run setblock 235 67 -2 grass_block
execute in minecraft:overworld run fill 235 68 -2 235 144 -2 air
execute in minecraft:overworld run fill 235 58 -1 235 64 -1 stone
execute in minecraft:overworld run fill 235 65 -1 235 66 -1 dirt
execute in minecraft:overworld run setblock 235 67 -1 coarse_dirt
execute in minecraft:overworld run fill 235 68 -1 235 144 -1 air
execute in minecraft:overworld run fill 235 58 0 235 64 0 stone
execute in minecraft:overworld run fill 235 65 0 235 66 0 dirt
execute in minecraft:overworld run setblock 235 67 0 coarse_dirt
execute in minecraft:overworld run fill 235 68 0 235 144 0 air
execute in minecraft:overworld run fill 235 58 1 235 64 1 stone
execute in minecraft:overworld run fill 235 65 1 235 66 1 dirt
execute in minecraft:overworld run setblock 235 67 1 coarse_dirt
execute in minecraft:overworld run fill 235 68 1 235 144 1 air
execute in minecraft:overworld run fill 235 58 2 235 64 2 stone
execute in minecraft:overworld run fill 235 65 2 235 66 2 dirt
execute in minecraft:overworld run setblock 235 67 2 coarse_dirt
execute in minecraft:overworld run fill 235 68 2 235 144 2 air
execute in minecraft:overworld run fill 235 58 3 235 64 3 stone
execute in minecraft:overworld run fill 235 65 3 235 66 3 dirt
execute in minecraft:overworld run setblock 235 67 3 grass_block
execute in minecraft:overworld run fill 235 68 3 235 144 3 air
execute in minecraft:overworld run fill 235 58 4 235 64 4 stone
execute in minecraft:overworld run fill 235 65 4 235 66 4 dirt
execute in minecraft:overworld run setblock 235 67 4 grass_block
execute in minecraft:overworld run fill 235 68 4 235 144 4 air
execute in minecraft:overworld run fill 235 58 5 235 65 5 stone
execute in minecraft:overworld run fill 235 66 5 235 67 5 dirt
execute in minecraft:overworld run setblock 235 68 5 coarse_dirt
execute in minecraft:overworld run fill 235 69 5 235 144 5 air
execute in minecraft:overworld run fill 235 58 6 235 65 6 stone
execute in minecraft:overworld run fill 235 66 6 235 67 6 dirt
execute in minecraft:overworld run setblock 235 68 6 grass_block
execute in minecraft:overworld run fill 235 69 6 235 144 6 air
execute in minecraft:overworld run fill 235 58 7 235 65 7 stone
execute in minecraft:overworld run fill 235 66 7 235 67 7 dirt
execute in minecraft:overworld run setblock 235 68 7 coarse_dirt
execute in minecraft:overworld run fill 235 69 7 235 144 7 air
execute in minecraft:overworld run fill 235 58 8 235 65 8 stone
execute in minecraft:overworld run fill 235 66 8 235 67 8 dirt
execute in minecraft:overworld run setblock 235 68 8 grass_block
execute in minecraft:overworld run fill 235 69 8 235 144 8 air
execute in minecraft:overworld run fill 235 58 9 235 66 9 stone
execute in minecraft:overworld run fill 235 67 9 235 68 9 dirt
execute in minecraft:overworld run setblock 235 69 9 coarse_dirt
execute in minecraft:overworld run fill 235 70 9 235 144 9 air
execute in minecraft:overworld run fill 235 58 10 235 66 10 stone
execute in minecraft:overworld run fill 235 67 10 235 68 10 dirt
execute in minecraft:overworld run setblock 235 69 10 coarse_dirt
execute in minecraft:overworld run fill 235 70 10 235 144 10 air
execute in minecraft:overworld run fill 235 58 11 235 66 11 stone
execute in minecraft:overworld run fill 235 67 11 235 68 11 dirt
execute in minecraft:overworld run setblock 235 69 11 coarse_dirt
execute in minecraft:overworld run fill 235 70 11 235 144 11 air
execute in minecraft:overworld run fill 235 58 12 235 66 12 stone
execute in minecraft:overworld run fill 235 67 12 235 68 12 dirt
execute in minecraft:overworld run setblock 235 69 12 grass_block
execute in minecraft:overworld run fill 235 70 12 235 144 12 air
execute in minecraft:overworld run fill 235 58 13 235 67 13 stone
execute in minecraft:overworld run fill 235 68 13 235 69 13 dirt
execute in minecraft:overworld run setblock 235 70 13 coarse_dirt
execute in minecraft:overworld run fill 235 71 13 235 144 13 air
execute in minecraft:overworld run fill 235 58 14 235 67 14 stone
execute in minecraft:overworld run fill 235 68 14 235 69 14 dirt
execute in minecraft:overworld run setblock 235 70 14 grass_block
execute in minecraft:overworld run fill 235 71 14 235 144 14 air
execute in minecraft:overworld run fill 235 58 15 235 67 15 stone
execute in minecraft:overworld run fill 235 68 15 235 69 15 dirt
execute in minecraft:overworld run setblock 235 70 15 grass_block
execute in minecraft:overworld run fill 235 71 15 235 144 15 air
execute in minecraft:overworld run fill 235 58 16 235 67 16 stone
execute in minecraft:overworld run fill 235 68 16 235 69 16 dirt
execute in minecraft:overworld run setblock 235 70 16 coarse_dirt
execute in minecraft:overworld run fill 235 71 16 235 144 16 air
execute in minecraft:overworld run fill 235 58 17 235 68 17 stone
execute in minecraft:overworld run fill 235 69 17 235 70 17 dirt
execute in minecraft:overworld run setblock 235 71 17 coarse_dirt
execute in minecraft:overworld run fill 235 72 17 235 144 17 air
execute in minecraft:overworld run fill 235 58 18 235 68 18 stone
execute in minecraft:overworld run fill 235 69 18 235 70 18 dirt
execute in minecraft:overworld run setblock 235 71 18 coarse_dirt
execute in minecraft:overworld run fill 235 72 18 235 144 18 air
execute in minecraft:overworld run fill 235 58 19 235 68 19 stone
execute in minecraft:overworld run fill 235 69 19 235 70 19 dirt
execute in minecraft:overworld run setblock 235 71 19 grass_block
execute in minecraft:overworld run fill 235 72 19 235 144 19 air
execute in minecraft:overworld run fill 235 58 20 235 68 20 stone
execute in minecraft:overworld run fill 235 69 20 235 70 20 dirt
execute in minecraft:overworld run setblock 235 71 20 coarse_dirt
execute in minecraft:overworld run fill 235 72 20 235 144 20 air
execute in minecraft:overworld run fill 235 58 21 235 68 21 stone
execute in minecraft:overworld run fill 235 69 21 235 70 21 dirt
execute in minecraft:overworld run setblock 235 71 21 coarse_dirt
execute in minecraft:overworld run fill 235 72 21 235 144 21 air
execute in minecraft:overworld run fill 235 58 22 235 68 22 stone
execute in minecraft:overworld run fill 235 69 22 235 70 22 dirt
execute in minecraft:overworld run setblock 235 71 22 coarse_dirt
execute in minecraft:overworld run fill 235 72 22 235 144 22 air
execute in minecraft:overworld run fill 235 58 23 235 69 23 stone
execute in minecraft:overworld run fill 235 70 23 235 71 23 dirt
execute in minecraft:overworld run setblock 235 72 23 grass_block
execute in minecraft:overworld run fill 235 73 23 235 144 23 air
execute in minecraft:overworld run fill 235 58 24 235 69 24 stone
execute in minecraft:overworld run fill 235 70 24 235 71 24 dirt
execute in minecraft:overworld run setblock 235 72 24 coarse_dirt
execute in minecraft:overworld run fill 235 73 24 235 144 24 air
execute in minecraft:overworld run fill 235 58 25 235 69 25 stone
execute in minecraft:overworld run fill 235 70 25 235 71 25 dirt
execute in minecraft:overworld run setblock 235 72 25 coarse_dirt
execute in minecraft:overworld run fill 235 73 25 235 144 25 air
execute in minecraft:overworld run fill 235 58 26 235 69 26 stone
execute in minecraft:overworld run fill 235 70 26 235 71 26 dirt
execute in minecraft:overworld run setblock 235 72 26 coarse_dirt
execute in minecraft:overworld run fill 235 73 26 235 144 26 air
execute in minecraft:overworld run fill 235 58 27 235 69 27 stone
execute in minecraft:overworld run fill 235 70 27 235 71 27 dirt
execute in minecraft:overworld run setblock 235 72 27 coarse_dirt
execute in minecraft:overworld run fill 235 73 27 235 144 27 air
execute in minecraft:overworld run fill 235 58 28 235 69 28 stone
execute in minecraft:overworld run fill 235 70 28 235 71 28 dirt
execute in minecraft:overworld run setblock 235 72 28 coarse_dirt
execute in minecraft:overworld run fill 235 73 28 235 144 28 air
execute in minecraft:overworld run fill 235 58 29 235 69 29 stone
execute in minecraft:overworld run fill 235 70 29 235 71 29 dirt
execute in minecraft:overworld run setblock 235 72 29 coarse_dirt
execute in minecraft:overworld run fill 235 73 29 235 144 29 air
execute in minecraft:overworld run fill 235 58 30 235 69 30 stone
execute in minecraft:overworld run fill 235 70 30 235 71 30 dirt
execute in minecraft:overworld run setblock 235 72 30 grass_block
execute in minecraft:overworld run fill 235 73 30 235 144 30 air
execute in minecraft:overworld run fill 235 58 31 235 69 31 stone
execute in minecraft:overworld run fill 235 70 31 235 71 31 dirt
execute in minecraft:overworld run setblock 235 72 31 coarse_dirt
execute in minecraft:overworld run fill 235 73 31 235 144 31 air
execute in minecraft:overworld run fill 235 58 32 235 69 32 stone
execute in minecraft:overworld run fill 235 70 32 235 71 32 dirt
execute in minecraft:overworld run setblock 235 72 32 coarse_dirt
execute in minecraft:overworld run fill 235 73 32 235 144 32 air
execute in minecraft:overworld run fill 235 58 33 235 69 33 stone
execute in minecraft:overworld run fill 235 70 33 235 71 33 dirt
execute in minecraft:overworld run setblock 235 72 33 coarse_dirt
execute in minecraft:overworld run fill 235 73 33 235 144 33 air
execute in minecraft:overworld run setblock 235 73 33 grass
execute in minecraft:overworld run fill 235 58 34 235 69 34 stone
execute in minecraft:overworld run fill 235 70 34 235 71 34 dirt
execute in minecraft:overworld run setblock 235 72 34 grass_block
execute in minecraft:overworld run fill 235 73 34 235 144 34 air
execute in minecraft:overworld run fill 235 58 35 235 68 35 stone
execute in minecraft:overworld run fill 235 69 35 235 70 35 dirt
execute in minecraft:overworld run setblock 235 71 35 coarse_dirt
execute in minecraft:overworld run fill 235 72 35 235 144 35 air
execute in minecraft:overworld run fill 235 58 36 235 68 36 stone
execute in minecraft:overworld run fill 235 69 36 235 70 36 dirt
execute in minecraft:overworld run setblock 235 71 36 coarse_dirt
execute in minecraft:overworld run fill 235 72 36 235 144 36 air
execute in minecraft:overworld run setblock 235 72 36 grass
execute in minecraft:overworld run fill 235 58 37 235 68 37 stone
execute in minecraft:overworld run fill 235 69 37 235 70 37 dirt
execute in minecraft:overworld run setblock 235 71 37 grass_block
execute in minecraft:overworld run fill 235 72 37 235 144 37 air
execute in minecraft:overworld run fill 235 58 38 235 67 38 stone
execute in minecraft:overworld run fill 235 68 38 235 69 38 dirt
execute in minecraft:overworld run setblock 235 70 38 grass_block
execute in minecraft:overworld run fill 235 71 38 235 144 38 air
execute in minecraft:overworld run fill 235 58 39 235 66 39 stone
execute in minecraft:overworld run fill 235 67 39 235 68 39 dirt
execute in minecraft:overworld run setblock 235 69 39 coarse_dirt
execute in minecraft:overworld run fill 235 70 39 235 144 39 air
execute in minecraft:overworld run fill 235 58 40 235 65 40 stone
execute in minecraft:overworld run fill 235 66 40 235 67 40 dirt
execute in minecraft:overworld run setblock 235 68 40 coarse_dirt
execute in minecraft:overworld run fill 235 69 40 235 144 40 air
execute in minecraft:overworld run fill 235 58 41 235 65 41 stone
execute in minecraft:overworld run fill 235 66 41 235 67 41 dirt
execute in minecraft:overworld run setblock 235 68 41 coarse_dirt
execute in minecraft:overworld run fill 235 69 41 235 144 41 air
execute in minecraft:overworld run fill 235 58 42 235 64 42 stone
execute in minecraft:overworld run fill 235 65 42 235 66 42 dirt
execute in minecraft:overworld run setblock 235 67 42 coarse_dirt
execute in minecraft:overworld run fill 235 68 42 235 144 42 air
execute in minecraft:overworld run fill 235 58 43 235 63 43 stone
execute in minecraft:overworld run fill 235 64 43 235 65 43 dirt
execute in minecraft:overworld run setblock 235 66 43 coarse_dirt
execute in minecraft:overworld run fill 235 67 43 235 144 43 air
execute in minecraft:overworld run fill 235 58 44 235 62 44 stone
execute in minecraft:overworld run fill 235 63 44 235 64 44 dirt
execute in minecraft:overworld run setblock 235 65 44 grass_block
execute in minecraft:overworld run fill 235 66 44 235 144 44 air
execute in minecraft:overworld run fill 235 58 45 235 62 45 stone
execute in minecraft:overworld run fill 235 63 45 235 64 45 dirt
execute in minecraft:overworld run setblock 235 65 45 grass_block
execute in minecraft:overworld run fill 235 66 45 235 144 45 air
execute in minecraft:overworld run fill 235 58 46 235 62 46 stone
execute in minecraft:overworld run fill 235 63 46 235 64 46 dirt
execute in minecraft:overworld run setblock 235 65 46 grass_block
execute in minecraft:overworld run fill 235 66 46 235 144 46 air
execute in minecraft:overworld run fill 235 58 47 235 61 47 stone
execute in minecraft:overworld run fill 235 62 47 235 63 47 dirt
execute in minecraft:overworld run setblock 235 64 47 coarse_dirt
execute in minecraft:overworld run fill 235 65 47 235 144 47 air
execute in minecraft:overworld run fill 236 58 -48 236 61 -48 stone
execute in minecraft:overworld run fill 236 62 -48 236 63 -48 dirt
execute in minecraft:overworld run setblock 236 64 -48 coarse_dirt
execute in minecraft:overworld run fill 236 65 -48 236 144 -48 air
execute in minecraft:overworld run fill 236 58 -47 236 62 -47 stone
execute in minecraft:overworld run fill 236 63 -47 236 64 -47 dirt
execute in minecraft:overworld run setblock 236 65 -47 coarse_dirt
execute in minecraft:overworld run fill 236 66 -47 236 144 -47 air
execute in minecraft:overworld run fill 236 58 -46 236 64 -46 stone
execute in minecraft:overworld run fill 236 65 -46 236 66 -46 dirt
execute in minecraft:overworld run setblock 236 67 -46 coarse_dirt
execute in minecraft:overworld run fill 236 68 -46 236 144 -46 air
execute in minecraft:overworld run fill 236 58 -45 236 65 -45 stone
execute in minecraft:overworld run fill 236 66 -45 236 67 -45 dirt
execute in minecraft:overworld run setblock 236 68 -45 coarse_dirt
execute in minecraft:overworld run fill 236 69 -45 236 144 -45 air
execute in minecraft:overworld run fill 236 58 -44 236 67 -44 stone
execute in minecraft:overworld run fill 236 68 -44 236 69 -44 dirt
execute in minecraft:overworld run setblock 236 70 -44 coarse_dirt
execute in minecraft:overworld run fill 236 71 -44 236 144 -44 air
execute in minecraft:overworld run fill 236 58 -43 236 68 -43 stone
schedule function blade_gallery:random/burned/part_43 1t replace
