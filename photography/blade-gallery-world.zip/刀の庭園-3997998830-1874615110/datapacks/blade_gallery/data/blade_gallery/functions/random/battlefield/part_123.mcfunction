execute in minecraft:overworld run fill 414 71 -26 414 72 -26 dirt
execute in minecraft:overworld run setblock 414 73 -26 coarse_dirt
execute in minecraft:overworld run fill 414 74 -26 414 144 -26 air
execute in minecraft:overworld run fill 414 58 -25 414 70 -25 stone
execute in minecraft:overworld run fill 414 71 -25 414 72 -25 dirt
execute in minecraft:overworld run setblock 414 73 -25 coarse_dirt
execute in minecraft:overworld run fill 414 74 -25 414 144 -25 air
execute in minecraft:overworld run fill 414 58 -24 414 70 -24 stone
execute in minecraft:overworld run fill 414 71 -24 414 72 -24 dirt
execute in minecraft:overworld run setblock 414 73 -24 coarse_dirt
execute in minecraft:overworld run fill 414 74 -24 414 144 -24 air
execute in minecraft:overworld run fill 414 58 -23 414 69 -23 stone
execute in minecraft:overworld run fill 414 70 -23 414 71 -23 dirt
execute in minecraft:overworld run setblock 414 72 -23 grass_block
execute in minecraft:overworld run fill 414 73 -23 414 144 -23 air
execute in minecraft:overworld run fill 414 58 -22 414 69 -22 stone
execute in minecraft:overworld run fill 414 70 -22 414 71 -22 dirt
execute in minecraft:overworld run setblock 414 72 -22 coarse_dirt
execute in minecraft:overworld run fill 414 73 -22 414 144 -22 air
execute in minecraft:overworld run fill 414 58 -21 414 69 -21 stone
execute in minecraft:overworld run fill 414 70 -21 414 71 -21 dirt
execute in minecraft:overworld run setblock 414 72 -21 coarse_dirt
execute in minecraft:overworld run fill 414 73 -21 414 144 -21 air
execute in minecraft:overworld run setblock 414 73 -21 grass
execute in minecraft:overworld run fill 414 58 -20 414 69 -20 stone
execute in minecraft:overworld run fill 414 70 -20 414 71 -20 dirt
execute in minecraft:overworld run setblock 414 72 -20 coarse_dirt
execute in minecraft:overworld run fill 414 73 -20 414 144 -20 air
execute in minecraft:overworld run fill 414 58 -19 414 68 -19 stone
execute in minecraft:overworld run fill 414 69 -19 414 70 -19 dirt
execute in minecraft:overworld run setblock 414 71 -19 coarse_dirt
execute in minecraft:overworld run fill 414 72 -19 414 144 -19 air
execute in minecraft:overworld run setblock 414 72 -19 grass
execute in minecraft:overworld run fill 414 58 -18 414 68 -18 stone
execute in minecraft:overworld run fill 414 69 -18 414 70 -18 dirt
execute in minecraft:overworld run setblock 414 71 -18 grass_block
execute in minecraft:overworld run fill 414 72 -18 414 144 -18 air
execute in minecraft:overworld run setblock 414 72 -18 grass
execute in minecraft:overworld run fill 414 58 -17 414 67 -17 stone
execute in minecraft:overworld run fill 414 68 -17 414 69 -17 dirt
execute in minecraft:overworld run setblock 414 70 -17 coarse_dirt
execute in minecraft:overworld run fill 414 71 -17 414 144 -17 air
execute in minecraft:overworld run setblock 414 71 -17 grass
execute in minecraft:overworld run fill 414 58 -16 414 67 -16 stone
execute in minecraft:overworld run fill 414 68 -16 414 69 -16 dirt
execute in minecraft:overworld run setblock 414 70 -16 grass_block
execute in minecraft:overworld run fill 414 71 -16 414 144 -16 air
execute in minecraft:overworld run fill 414 58 -15 414 66 -15 stone
execute in minecraft:overworld run fill 414 67 -15 414 68 -15 dirt
execute in minecraft:overworld run setblock 414 69 -15 coarse_dirt
execute in minecraft:overworld run fill 414 70 -15 414 144 -15 air
execute in minecraft:overworld run fill 414 58 -14 414 66 -14 stone
execute in minecraft:overworld run fill 414 67 -14 414 68 -14 dirt
execute in minecraft:overworld run setblock 414 69 -14 coarse_dirt
execute in minecraft:overworld run fill 414 70 -14 414 144 -14 air
execute in minecraft:overworld run fill 414 58 -13 414 65 -13 stone
execute in minecraft:overworld run fill 414 66 -13 414 67 -13 dirt
execute in minecraft:overworld run setblock 414 68 -13 grass_block
execute in minecraft:overworld run fill 414 69 -13 414 144 -13 air
execute in minecraft:overworld run fill 414 58 -12 414 65 -12 stone
execute in minecraft:overworld run fill 414 66 -12 414 67 -12 dirt
execute in minecraft:overworld run setblock 414 68 -12 coarse_dirt
execute in minecraft:overworld run fill 414 69 -12 414 144 -12 air
execute in minecraft:overworld run fill 414 58 -11 414 65 -11 stone
execute in minecraft:overworld run fill 414 66 -11 414 67 -11 dirt
execute in minecraft:overworld run setblock 414 68 -11 grass_block
execute in minecraft:overworld run fill 414 69 -11 414 144 -11 air
execute in minecraft:overworld run fill 414 58 -10 414 65 -10 stone
execute in minecraft:overworld run fill 414 66 -10 414 67 -10 dirt
execute in minecraft:overworld run setblock 414 68 -10 grass_block
execute in minecraft:overworld run fill 414 69 -10 414 144 -10 air
execute in minecraft:overworld run fill 414 58 -9 414 65 -9 stone
execute in minecraft:overworld run fill 414 66 -9 414 67 -9 dirt
execute in minecraft:overworld run setblock 414 68 -9 coarse_dirt
execute in minecraft:overworld run fill 414 69 -9 414 144 -9 air
execute in minecraft:overworld run fill 414 58 -8 414 64 -8 stone
execute in minecraft:overworld run fill 414 65 -8 414 66 -8 dirt
execute in minecraft:overworld run setblock 414 67 -8 coarse_dirt
execute in minecraft:overworld run fill 414 68 -8 414 144 -8 air
execute in minecraft:overworld run fill 414 58 -7 414 64 -7 stone
execute in minecraft:overworld run fill 414 65 -7 414 66 -7 dirt
execute in minecraft:overworld run setblock 414 67 -7 grass_block
execute in minecraft:overworld run fill 414 68 -7 414 144 -7 air
execute in minecraft:overworld run fill 414 58 -6 414 64 -6 stone
execute in minecraft:overworld run fill 414 65 -6 414 66 -6 dirt
execute in minecraft:overworld run setblock 414 67 -6 coarse_dirt
execute in minecraft:overworld run fill 414 68 -6 414 144 -6 air
execute in minecraft:overworld run fill 414 58 -5 414 64 -5 stone
execute in minecraft:overworld run fill 414 65 -5 414 66 -5 dirt
execute in minecraft:overworld run setblock 414 67 -5 grass_block
execute in minecraft:overworld run fill 414 68 -5 414 144 -5 air
execute in minecraft:overworld run fill 414 58 -4 414 63 -4 stone
execute in minecraft:overworld run fill 414 64 -4 414 65 -4 dirt
execute in minecraft:overworld run setblock 414 66 -4 coarse_dirt
execute in minecraft:overworld run fill 414 67 -4 414 144 -4 air
execute in minecraft:overworld run fill 414 58 -3 414 63 -3 stone
execute in minecraft:overworld run fill 414 64 -3 414 65 -3 dirt
execute in minecraft:overworld run setblock 414 66 -3 grass_block
execute in minecraft:overworld run fill 414 67 -3 414 144 -3 air
execute in minecraft:overworld run setblock 414 67 -3 grass
execute in minecraft:overworld run fill 414 58 -2 414 63 -2 stone
execute in minecraft:overworld run fill 414 64 -2 414 65 -2 dirt
execute in minecraft:overworld run setblock 414 66 -2 coarse_dirt
execute in minecraft:overworld run fill 414 67 -2 414 144 -2 air
execute in minecraft:overworld run fill 414 58 -1 414 63 -1 stone
execute in minecraft:overworld run fill 414 64 -1 414 65 -1 dirt
execute in minecraft:overworld run setblock 414 66 -1 coarse_dirt
execute in minecraft:overworld run fill 414 67 -1 414 144 -1 air
execute in minecraft:overworld run fill 414 58 0 414 63 0 stone
execute in minecraft:overworld run fill 414 64 0 414 65 0 dirt
execute in minecraft:overworld run setblock 414 66 0 grass_block
execute in minecraft:overworld run fill 414 67 0 414 144 0 air
execute in minecraft:overworld run fill 414 58 1 414 63 1 stone
execute in minecraft:overworld run fill 414 64 1 414 65 1 dirt
execute in minecraft:overworld run setblock 414 66 1 coarse_dirt
execute in minecraft:overworld run fill 414 67 1 414 144 1 air
execute in minecraft:overworld run fill 414 58 2 414 63 2 stone
execute in minecraft:overworld run fill 414 64 2 414 65 2 dirt
execute in minecraft:overworld run setblock 414 66 2 coarse_dirt
execute in minecraft:overworld run fill 414 67 2 414 144 2 air
execute in minecraft:overworld run fill 414 58 3 414 63 3 stone
execute in minecraft:overworld run fill 414 64 3 414 65 3 dirt
execute in minecraft:overworld run setblock 414 66 3 coarse_dirt
execute in minecraft:overworld run fill 414 67 3 414 144 3 air
execute in minecraft:overworld run fill 414 58 4 414 63 4 stone
execute in minecraft:overworld run fill 414 64 4 414 65 4 dirt
execute in minecraft:overworld run setblock 414 66 4 coarse_dirt
execute in minecraft:overworld run fill 414 67 4 414 144 4 air
execute in minecraft:overworld run fill 414 58 5 414 64 5 stone
execute in minecraft:overworld run fill 414 65 5 414 66 5 dirt
execute in minecraft:overworld run setblock 414 67 5 coarse_dirt
execute in minecraft:overworld run fill 414 68 5 414 144 5 air
execute in minecraft:overworld run fill 414 58 6 414 64 6 stone
execute in minecraft:overworld run fill 414 65 6 414 66 6 dirt
execute in minecraft:overworld run setblock 414 67 6 grass_block
execute in minecraft:overworld run fill 414 68 6 414 144 6 air
execute in minecraft:overworld run fill 414 58 7 414 64 7 stone
execute in minecraft:overworld run fill 414 65 7 414 66 7 dirt
execute in minecraft:overworld run setblock 414 67 7 grass_block
execute in minecraft:overworld run fill 414 68 7 414 144 7 air
execute in minecraft:overworld run fill 414 58 8 414 65 8 stone
execute in minecraft:overworld run fill 414 66 8 414 67 8 dirt
execute in minecraft:overworld run setblock 414 68 8 coarse_dirt
execute in minecraft:overworld run fill 414 69 8 414 144 8 air
execute in minecraft:overworld run fill 414 58 9 414 65 9 stone
execute in minecraft:overworld run fill 414 66 9 414 67 9 dirt
execute in minecraft:overworld run setblock 414 68 9 coarse_dirt
execute in minecraft:overworld run fill 414 69 9 414 144 9 air
execute in minecraft:overworld run fill 414 58 10 414 65 10 stone
execute in minecraft:overworld run fill 414 66 10 414 67 10 dirt
execute in minecraft:overworld run setblock 414 68 10 grass_block
execute in minecraft:overworld run fill 414 69 10 414 144 10 air
execute in minecraft:overworld run setblock 414 69 10 grass
execute in minecraft:overworld run fill 414 58 11 414 66 11 stone
execute in minecraft:overworld run fill 414 67 11 414 68 11 dirt
execute in minecraft:overworld run setblock 414 69 11 coarse_dirt
execute in minecraft:overworld run fill 414 70 11 414 144 11 air
execute in minecraft:overworld run fill 414 58 12 414 66 12 stone
execute in minecraft:overworld run fill 414 67 12 414 68 12 dirt
execute in minecraft:overworld run setblock 414 69 12 coarse_dirt
execute in minecraft:overworld run fill 414 70 12 414 144 12 air
execute in minecraft:overworld run fill 414 58 13 414 66 13 stone
execute in minecraft:overworld run fill 414 67 13 414 68 13 dirt
execute in minecraft:overworld run setblock 414 69 13 coarse_dirt
execute in minecraft:overworld run fill 414 70 13 414 144 13 air
execute in minecraft:overworld run fill 414 58 14 414 67 14 stone
execute in minecraft:overworld run fill 414 68 14 414 69 14 dirt
execute in minecraft:overworld run setblock 414 70 14 coarse_dirt
execute in minecraft:overworld run fill 414 71 14 414 144 14 air
execute in minecraft:overworld run fill 414 58 15 414 67 15 stone
execute in minecraft:overworld run fill 414 68 15 414 69 15 dirt
execute in minecraft:overworld run setblock 414 70 15 grass_block
execute in minecraft:overworld run fill 414 71 15 414 144 15 air
execute in minecraft:overworld run fill 414 58 16 414 67 16 stone
execute in minecraft:overworld run fill 414 68 16 414 69 16 dirt
execute in minecraft:overworld run setblock 414 70 16 coarse_dirt
execute in minecraft:overworld run fill 414 71 16 414 144 16 air
execute in minecraft:overworld run fill 414 58 17 414 67 17 stone
execute in minecraft:overworld run fill 414 68 17 414 69 17 dirt
execute in minecraft:overworld run setblock 414 70 17 coarse_dirt
execute in minecraft:overworld run fill 414 71 17 414 144 17 air
execute in minecraft:overworld run fill 414 58 18 414 68 18 stone
execute in minecraft:overworld run fill 414 69 18 414 70 18 dirt
execute in minecraft:overworld run setblock 414 71 18 coarse_dirt
execute in minecraft:overworld run fill 414 72 18 414 144 18 air
execute in minecraft:overworld run fill 414 58 19 414 68 19 stone
execute in minecraft:overworld run fill 414 69 19 414 70 19 dirt
execute in minecraft:overworld run setblock 414 71 19 coarse_dirt
execute in minecraft:overworld run fill 414 72 19 414 144 19 air
execute in minecraft:overworld run fill 414 58 20 414 68 20 stone
execute in minecraft:overworld run fill 414 69 20 414 70 20 dirt
execute in minecraft:overworld run setblock 414 71 20 coarse_dirt
execute in minecraft:overworld run fill 414 72 20 414 144 20 air
execute in minecraft:overworld run setblock 414 72 20 grass
execute in minecraft:overworld run fill 414 58 21 414 69 21 stone
execute in minecraft:overworld run fill 414 70 21 414 71 21 dirt
execute in minecraft:overworld run setblock 414 72 21 coarse_dirt
execute in minecraft:overworld run fill 414 73 21 414 144 21 air
execute in minecraft:overworld run fill 414 58 22 414 69 22 stone
execute in minecraft:overworld run fill 414 70 22 414 71 22 dirt
execute in minecraft:overworld run setblock 414 72 22 coarse_dirt
execute in minecraft:overworld run fill 414 73 22 414 144 22 air
execute in minecraft:overworld run setblock 414 73 22 mossy_cobblestone
execute in minecraft:overworld run fill 414 58 23 414 70 23 stone
execute in minecraft:overworld run fill 414 71 23 414 72 23 dirt
execute in minecraft:overworld run setblock 414 73 23 coarse_dirt
execute in minecraft:overworld run fill 414 74 23 414 144 23 air
execute in minecraft:overworld run fill 414 58 24 414 70 24 stone
execute in minecraft:overworld run fill 414 71 24 414 72 24 dirt
execute in minecraft:overworld run setblock 414 73 24 coarse_dirt
execute in minecraft:overworld run fill 414 74 24 414 144 24 air
execute in minecraft:overworld run fill 414 58 25 414 70 25 stone
execute in minecraft:overworld run fill 414 71 25 414 72 25 dirt
execute in minecraft:overworld run setblock 414 73 25 coarse_dirt
execute in minecraft:overworld run fill 414 74 25 414 144 25 air
execute in minecraft:overworld run fill 414 58 26 414 71 26 stone
execute in minecraft:overworld run fill 414 72 26 414 73 26 dirt
execute in minecraft:overworld run setblock 414 74 26 coarse_dirt
execute in minecraft:overworld run fill 414 75 26 414 144 26 air
execute in minecraft:overworld run fill 414 58 27 414 71 27 stone
execute in minecraft:overworld run fill 414 72 27 414 73 27 dirt
execute in minecraft:overworld run setblock 414 74 27 coarse_dirt
execute in minecraft:overworld run fill 414 75 27 414 144 27 air
execute in minecraft:overworld run fill 414 58 28 414 71 28 stone
execute in minecraft:overworld run fill 414 72 28 414 73 28 dirt
execute in minecraft:overworld run setblock 414 74 28 coarse_dirt
execute in minecraft:overworld run fill 414 75 28 414 144 28 air
execute in minecraft:overworld run fill 414 58 29 414 71 29 stone
execute in minecraft:overworld run fill 414 72 29 414 73 29 dirt
execute in minecraft:overworld run setblock 414 74 29 coarse_dirt
execute in minecraft:overworld run fill 414 75 29 414 144 29 air
execute in minecraft:overworld run fill 414 58 30 414 71 30 stone
execute in minecraft:overworld run fill 414 72 30 414 73 30 dirt
execute in minecraft:overworld run setblock 414 74 30 coarse_dirt
execute in minecraft:overworld run fill 414 75 30 414 144 30 air
execute in minecraft:overworld run setblock 414 75 30 grass
execute in minecraft:overworld run fill 414 58 31 414 70 31 stone
execute in minecraft:overworld run fill 414 71 31 414 72 31 dirt
execute in minecraft:overworld run setblock 414 73 31 coarse_dirt
execute in minecraft:overworld run fill 414 74 31 414 144 31 air
execute in minecraft:overworld run setblock 414 74 31 grass
execute in minecraft:overworld run fill 414 58 32 414 70 32 stone
execute in minecraft:overworld run fill 414 71 32 414 72 32 dirt
execute in minecraft:overworld run setblock 414 73 32 grass_block
execute in minecraft:overworld run fill 414 74 32 414 144 32 air
execute in minecraft:overworld run fill 414 58 33 414 70 33 stone
execute in minecraft:overworld run fill 414 71 33 414 72 33 dirt
execute in minecraft:overworld run setblock 414 73 33 coarse_dirt
execute in minecraft:overworld run fill 414 74 33 414 144 33 air
execute in minecraft:overworld run fill 414 58 34 414 69 34 stone
execute in minecraft:overworld run fill 414 70 34 414 71 34 dirt
execute in minecraft:overworld run setblock 414 72 34 coarse_dirt
execute in minecraft:overworld run fill 414 73 34 414 144 34 air
execute in minecraft:overworld run fill 414 58 35 414 69 35 stone
execute in minecraft:overworld run fill 414 70 35 414 71 35 dirt
execute in minecraft:overworld run setblock 414 72 35 grass_block
schedule function blade_gallery:random/battlefield/part_124 1t replace
