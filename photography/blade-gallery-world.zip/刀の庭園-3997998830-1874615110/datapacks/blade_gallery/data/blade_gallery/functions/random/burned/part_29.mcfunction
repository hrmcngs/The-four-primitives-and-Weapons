execute in minecraft:overworld run fill 226 58 45 226 62 45 stone
execute in minecraft:overworld run fill 226 63 45 226 64 45 dirt
execute in minecraft:overworld run setblock 226 65 45 coarse_dirt
execute in minecraft:overworld run fill 226 66 45 226 144 45 air
execute in minecraft:overworld run fill 226 58 46 226 61 46 stone
execute in minecraft:overworld run fill 226 62 46 226 63 46 dirt
execute in minecraft:overworld run setblock 226 64 46 grass_block
execute in minecraft:overworld run fill 226 65 46 226 144 46 air
execute in minecraft:overworld run fill 226 58 47 226 61 47 stone
execute in minecraft:overworld run fill 226 62 47 226 63 47 dirt
execute in minecraft:overworld run setblock 226 64 47 coarse_dirt
execute in minecraft:overworld run fill 226 65 47 226 144 47 air
execute in minecraft:overworld run fill 227 58 -48 227 61 -48 stone
execute in minecraft:overworld run fill 227 62 -48 227 63 -48 dirt
execute in minecraft:overworld run setblock 227 64 -48 coarse_dirt
execute in minecraft:overworld run fill 227 65 -48 227 144 -48 air
execute in minecraft:overworld run fill 227 58 -47 227 63 -47 stone
execute in minecraft:overworld run fill 227 64 -47 227 65 -47 dirt
execute in minecraft:overworld run setblock 227 66 -47 coarse_dirt
execute in minecraft:overworld run fill 227 67 -47 227 144 -47 air
execute in minecraft:overworld run fill 227 58 -46 227 64 -46 stone
execute in minecraft:overworld run fill 227 65 -46 227 66 -46 dirt
execute in minecraft:overworld run setblock 227 67 -46 grass_block
execute in minecraft:overworld run fill 227 68 -46 227 144 -46 air
execute in minecraft:overworld run fill 227 58 -45 227 66 -45 stone
execute in minecraft:overworld run fill 227 67 -45 227 68 -45 dirt
execute in minecraft:overworld run setblock 227 69 -45 grass_block
execute in minecraft:overworld run fill 227 70 -45 227 144 -45 air
execute in minecraft:overworld run fill 227 58 -44 227 67 -44 stone
execute in minecraft:overworld run fill 227 68 -44 227 69 -44 dirt
execute in minecraft:overworld run setblock 227 70 -44 coarse_dirt
execute in minecraft:overworld run fill 227 71 -44 227 144 -44 air
execute in minecraft:overworld run fill 227 58 -43 227 68 -43 stone
execute in minecraft:overworld run fill 227 69 -43 227 70 -43 dirt
execute in minecraft:overworld run setblock 227 71 -43 coarse_dirt
execute in minecraft:overworld run fill 227 72 -43 227 144 -43 air
execute in minecraft:overworld run fill 227 58 -42 227 69 -42 stone
execute in minecraft:overworld run fill 227 70 -42 227 71 -42 dirt
execute in minecraft:overworld run setblock 227 72 -42 grass_block
execute in minecraft:overworld run fill 227 73 -42 227 144 -42 air
execute in minecraft:overworld run fill 227 58 -41 227 70 -41 stone
execute in minecraft:overworld run fill 227 71 -41 227 72 -41 dirt
execute in minecraft:overworld run setblock 227 73 -41 coarse_dirt
execute in minecraft:overworld run fill 227 74 -41 227 144 -41 air
execute in minecraft:overworld run fill 227 58 -40 227 71 -40 stone
execute in minecraft:overworld run fill 227 72 -40 227 73 -40 dirt
execute in minecraft:overworld run setblock 227 74 -40 grass_block
execute in minecraft:overworld run fill 227 75 -40 227 144 -40 air
execute in minecraft:overworld run fill 227 58 -39 227 71 -39 stone
execute in minecraft:overworld run fill 227 72 -39 227 73 -39 dirt
execute in minecraft:overworld run setblock 227 74 -39 coarse_dirt
execute in minecraft:overworld run fill 227 75 -39 227 144 -39 air
execute in minecraft:overworld run fill 227 58 -38 227 71 -38 stone
execute in minecraft:overworld run fill 227 72 -38 227 73 -38 dirt
execute in minecraft:overworld run setblock 227 74 -38 grass_block
execute in minecraft:overworld run fill 227 75 -38 227 144 -38 air
execute in minecraft:overworld run setblock 227 75 -38 grass
execute in minecraft:overworld run fill 227 58 -37 227 71 -37 stone
execute in minecraft:overworld run fill 227 72 -37 227 73 -37 dirt
execute in minecraft:overworld run setblock 227 74 -37 coarse_dirt
execute in minecraft:overworld run fill 227 75 -37 227 144 -37 air
execute in minecraft:overworld run fill 227 58 -36 227 70 -36 stone
execute in minecraft:overworld run fill 227 71 -36 227 72 -36 dirt
execute in minecraft:overworld run setblock 227 73 -36 grass_block
execute in minecraft:overworld run fill 227 74 -36 227 144 -36 air
execute in minecraft:overworld run fill 227 58 -35 227 69 -35 stone
execute in minecraft:overworld run fill 227 70 -35 227 71 -35 dirt
execute in minecraft:overworld run setblock 227 72 -35 coarse_dirt
execute in minecraft:overworld run fill 227 73 -35 227 144 -35 air
execute in minecraft:overworld run fill 227 58 -34 227 69 -34 stone
execute in minecraft:overworld run fill 227 70 -34 227 71 -34 dirt
execute in minecraft:overworld run setblock 227 72 -34 coarse_dirt
execute in minecraft:overworld run fill 227 73 -34 227 144 -34 air
execute in minecraft:overworld run fill 227 58 -33 227 68 -33 stone
execute in minecraft:overworld run fill 227 69 -33 227 70 -33 dirt
execute in minecraft:overworld run setblock 227 71 -33 coarse_dirt
execute in minecraft:overworld run fill 227 72 -33 227 144 -33 air
execute in minecraft:overworld run fill 227 58 -32 227 68 -32 stone
execute in minecraft:overworld run fill 227 69 -32 227 70 -32 dirt
execute in minecraft:overworld run setblock 227 71 -32 grass_block
execute in minecraft:overworld run fill 227 72 -32 227 144 -32 air
execute in minecraft:overworld run fill 227 58 -31 227 68 -31 stone
execute in minecraft:overworld run fill 227 69 -31 227 70 -31 dirt
execute in minecraft:overworld run setblock 227 71 -31 coarse_dirt
execute in minecraft:overworld run fill 227 72 -31 227 144 -31 air
execute in minecraft:overworld run fill 227 58 -30 227 67 -30 stone
execute in minecraft:overworld run fill 227 68 -30 227 69 -30 dirt
execute in minecraft:overworld run setblock 227 70 -30 coarse_dirt
execute in minecraft:overworld run fill 227 71 -30 227 144 -30 air
execute in minecraft:overworld run setblock 227 71 -30 grass
execute in minecraft:overworld run fill 227 58 -29 227 67 -29 stone
execute in minecraft:overworld run fill 227 68 -29 227 69 -29 dirt
execute in minecraft:overworld run setblock 227 70 -29 coarse_dirt
execute in minecraft:overworld run fill 227 71 -29 227 144 -29 air
execute in minecraft:overworld run fill 227 58 -28 227 67 -28 stone
execute in minecraft:overworld run fill 227 68 -28 227 69 -28 dirt
execute in minecraft:overworld run setblock 227 70 -28 coarse_dirt
execute in minecraft:overworld run fill 227 71 -28 227 144 -28 air
execute in minecraft:overworld run fill 227 58 -27 227 66 -27 stone
execute in minecraft:overworld run fill 227 67 -27 227 68 -27 dirt
execute in minecraft:overworld run setblock 227 69 -27 coarse_dirt
execute in minecraft:overworld run fill 227 70 -27 227 144 -27 air
execute in minecraft:overworld run fill 227 58 -26 227 66 -26 stone
execute in minecraft:overworld run fill 227 67 -26 227 68 -26 dirt
execute in minecraft:overworld run setblock 227 69 -26 grass_block
execute in minecraft:overworld run fill 227 70 -26 227 144 -26 air
execute in minecraft:overworld run fill 227 58 -25 227 66 -25 stone
execute in minecraft:overworld run fill 227 67 -25 227 68 -25 dirt
execute in minecraft:overworld run setblock 227 69 -25 coarse_dirt
execute in minecraft:overworld run fill 227 70 -25 227 144 -25 air
execute in minecraft:overworld run fill 227 58 -24 227 66 -24 stone
execute in minecraft:overworld run fill 227 67 -24 227 68 -24 dirt
execute in minecraft:overworld run setblock 227 69 -24 coarse_dirt
execute in minecraft:overworld run fill 227 70 -24 227 144 -24 air
execute in minecraft:overworld run fill 227 58 -23 227 66 -23 stone
execute in minecraft:overworld run fill 227 67 -23 227 68 -23 dirt
execute in minecraft:overworld run setblock 227 69 -23 coarse_dirt
execute in minecraft:overworld run fill 227 70 -23 227 144 -23 air
execute in minecraft:overworld run fill 227 58 -22 227 66 -22 stone
execute in minecraft:overworld run fill 227 67 -22 227 68 -22 dirt
execute in minecraft:overworld run setblock 227 69 -22 coarse_dirt
execute in minecraft:overworld run fill 227 70 -22 227 144 -22 air
execute in minecraft:overworld run fill 227 58 -21 227 66 -21 stone
execute in minecraft:overworld run fill 227 67 -21 227 68 -21 dirt
execute in minecraft:overworld run setblock 227 69 -21 coarse_dirt
execute in minecraft:overworld run fill 227 70 -21 227 144 -21 air
execute in minecraft:overworld run setblock 227 70 -21 grass
execute in minecraft:overworld run fill 227 58 -20 227 66 -20 stone
execute in minecraft:overworld run fill 227 67 -20 227 68 -20 dirt
execute in minecraft:overworld run setblock 227 69 -20 coarse_dirt
execute in minecraft:overworld run fill 227 70 -20 227 144 -20 air
execute in minecraft:overworld run fill 227 58 -19 227 66 -19 stone
execute in minecraft:overworld run fill 227 67 -19 227 68 -19 dirt
execute in minecraft:overworld run setblock 227 69 -19 coarse_dirt
execute in minecraft:overworld run fill 227 70 -19 227 144 -19 air
execute in minecraft:overworld run fill 227 58 -18 227 66 -18 stone
execute in minecraft:overworld run fill 227 67 -18 227 68 -18 dirt
execute in minecraft:overworld run setblock 227 69 -18 coarse_dirt
execute in minecraft:overworld run fill 227 70 -18 227 144 -18 air
execute in minecraft:overworld run fill 227 58 -17 227 66 -17 stone
execute in minecraft:overworld run fill 227 67 -17 227 68 -17 dirt
execute in minecraft:overworld run setblock 227 69 -17 coarse_dirt
execute in minecraft:overworld run fill 227 70 -17 227 144 -17 air
execute in minecraft:overworld run fill 227 58 -16 227 66 -16 stone
execute in minecraft:overworld run fill 227 67 -16 227 68 -16 dirt
execute in minecraft:overworld run setblock 227 69 -16 coarse_dirt
execute in minecraft:overworld run fill 227 70 -16 227 144 -16 air
execute in minecraft:overworld run fill 227 58 -15 227 65 -15 stone
execute in minecraft:overworld run fill 227 66 -15 227 67 -15 dirt
execute in minecraft:overworld run setblock 227 68 -15 coarse_dirt
execute in minecraft:overworld run fill 227 69 -15 227 144 -15 air
execute in minecraft:overworld run fill 227 58 -14 227 65 -14 stone
execute in minecraft:overworld run fill 227 66 -14 227 67 -14 dirt
execute in minecraft:overworld run setblock 227 68 -14 grass_block
execute in minecraft:overworld run fill 227 69 -14 227 144 -14 air
execute in minecraft:overworld run fill 227 58 -13 227 64 -13 stone
execute in minecraft:overworld run fill 227 65 -13 227 66 -13 dirt
execute in minecraft:overworld run setblock 227 67 -13 coarse_dirt
execute in minecraft:overworld run fill 227 68 -13 227 144 -13 air
execute in minecraft:overworld run fill 227 58 -12 227 64 -12 stone
execute in minecraft:overworld run fill 227 65 -12 227 66 -12 dirt
execute in minecraft:overworld run setblock 227 67 -12 coarse_dirt
execute in minecraft:overworld run fill 227 68 -12 227 144 -12 air
execute in minecraft:overworld run fill 227 58 -11 227 64 -11 stone
execute in minecraft:overworld run fill 227 65 -11 227 66 -11 dirt
execute in minecraft:overworld run setblock 227 67 -11 coarse_dirt
execute in minecraft:overworld run fill 227 68 -11 227 144 -11 air
execute in minecraft:overworld run fill 227 58 -10 227 64 -10 stone
execute in minecraft:overworld run fill 227 65 -10 227 66 -10 dirt
execute in minecraft:overworld run setblock 227 67 -10 coarse_dirt
execute in minecraft:overworld run fill 227 68 -10 227 144 -10 air
execute in minecraft:overworld run fill 227 58 -9 227 64 -9 stone
execute in minecraft:overworld run fill 227 65 -9 227 66 -9 dirt
execute in minecraft:overworld run setblock 227 67 -9 coarse_dirt
execute in minecraft:overworld run fill 227 68 -9 227 144 -9 air
execute in minecraft:overworld run fill 227 58 -8 227 65 -8 stone
execute in minecraft:overworld run fill 227 66 -8 227 67 -8 dirt
execute in minecraft:overworld run setblock 227 68 -8 coarse_dirt
execute in minecraft:overworld run fill 227 69 -8 227 144 -8 air
execute in minecraft:overworld run fill 227 58 -7 227 65 -7 stone
execute in minecraft:overworld run fill 227 66 -7 227 67 -7 dirt
execute in minecraft:overworld run setblock 227 68 -7 coarse_dirt
execute in minecraft:overworld run fill 227 69 -7 227 144 -7 air
execute in minecraft:overworld run fill 227 58 -6 227 66 -6 stone
execute in minecraft:overworld run fill 227 67 -6 227 68 -6 dirt
execute in minecraft:overworld run setblock 227 69 -6 coarse_dirt
execute in minecraft:overworld run fill 227 70 -6 227 144 -6 air
execute in minecraft:overworld run fill 227 58 -5 227 66 -5 stone
execute in minecraft:overworld run fill 227 67 -5 227 68 -5 dirt
execute in minecraft:overworld run setblock 227 69 -5 grass_block
execute in minecraft:overworld run fill 227 70 -5 227 144 -5 air
execute in minecraft:overworld run fill 227 58 -4 227 66 -4 stone
execute in minecraft:overworld run fill 227 67 -4 227 68 -4 dirt
execute in minecraft:overworld run setblock 227 69 -4 coarse_dirt
execute in minecraft:overworld run fill 227 70 -4 227 144 -4 air
execute in minecraft:overworld run setblock 227 70 -4 grass
execute in minecraft:overworld run fill 227 58 -3 227 67 -3 stone
execute in minecraft:overworld run fill 227 68 -3 227 69 -3 dirt
execute in minecraft:overworld run setblock 227 70 -3 coarse_dirt
execute in minecraft:overworld run fill 227 71 -3 227 144 -3 air
execute in minecraft:overworld run fill 227 58 -2 227 67 -2 stone
execute in minecraft:overworld run fill 227 68 -2 227 69 -2 dirt
execute in minecraft:overworld run setblock 227 70 -2 coarse_dirt
execute in minecraft:overworld run fill 227 71 -2 227 144 -2 air
execute in minecraft:overworld run fill 227 58 -1 227 67 -1 stone
execute in minecraft:overworld run fill 227 68 -1 227 69 -1 dirt
execute in minecraft:overworld run setblock 227 70 -1 coarse_dirt
execute in minecraft:overworld run fill 227 71 -1 227 144 -1 air
execute in minecraft:overworld run setblock 227 71 -1 grass
execute in minecraft:overworld run fill 227 58 0 227 67 0 stone
execute in minecraft:overworld run fill 227 68 0 227 69 0 dirt
execute in minecraft:overworld run setblock 227 70 0 coarse_dirt
execute in minecraft:overworld run fill 227 71 0 227 144 0 air
execute in minecraft:overworld run setblock 227 71 0 grass
execute in minecraft:overworld run fill 227 58 1 227 67 1 stone
execute in minecraft:overworld run fill 227 68 1 227 69 1 dirt
execute in minecraft:overworld run setblock 227 70 1 coarse_dirt
execute in minecraft:overworld run fill 227 71 1 227 144 1 air
execute in minecraft:overworld run fill 227 58 2 227 67 2 stone
execute in minecraft:overworld run fill 227 68 2 227 69 2 dirt
execute in minecraft:overworld run setblock 227 70 2 coarse_dirt
execute in minecraft:overworld run fill 227 71 2 227 144 2 air
execute in minecraft:overworld run fill 227 58 3 227 67 3 stone
execute in minecraft:overworld run fill 227 68 3 227 69 3 dirt
execute in minecraft:overworld run setblock 227 70 3 coarse_dirt
execute in minecraft:overworld run fill 227 71 3 227 144 3 air
execute in minecraft:overworld run fill 227 58 4 227 67 4 stone
execute in minecraft:overworld run fill 227 68 4 227 69 4 dirt
execute in minecraft:overworld run setblock 227 70 4 coarse_dirt
execute in minecraft:overworld run fill 227 71 4 227 144 4 air
execute in minecraft:overworld run fill 227 58 5 227 67 5 stone
execute in minecraft:overworld run fill 227 68 5 227 69 5 dirt
execute in minecraft:overworld run setblock 227 70 5 grass_block
execute in minecraft:overworld run fill 227 71 5 227 144 5 air
execute in minecraft:overworld run fill 227 58 6 227 66 6 stone
execute in minecraft:overworld run fill 227 67 6 227 68 6 dirt
execute in minecraft:overworld run setblock 227 69 6 coarse_dirt
execute in minecraft:overworld run fill 227 70 6 227 144 6 air
execute in minecraft:overworld run fill 227 58 7 227 66 7 stone
execute in minecraft:overworld run fill 227 67 7 227 68 7 dirt
execute in minecraft:overworld run setblock 227 69 7 grass_block
execute in minecraft:overworld run fill 227 70 7 227 144 7 air
execute in minecraft:overworld run fill 227 58 8 227 66 8 stone
execute in minecraft:overworld run fill 227 67 8 227 68 8 dirt
execute in minecraft:overworld run setblock 227 69 8 coarse_dirt
execute in minecraft:overworld run fill 227 70 8 227 144 8 air
execute in minecraft:overworld run fill 227 58 9 227 66 9 stone
execute in minecraft:overworld run fill 227 67 9 227 68 9 dirt
execute in minecraft:overworld run setblock 227 69 9 coarse_dirt
execute in minecraft:overworld run fill 227 70 9 227 144 9 air
execute in minecraft:overworld run setblock 227 70 9 grass
execute in minecraft:overworld run fill 227 58 10 227 67 10 stone
execute in minecraft:overworld run fill 227 68 10 227 69 10 dirt
execute in minecraft:overworld run setblock 227 70 10 coarse_dirt
execute in minecraft:overworld run fill 227 71 10 227 144 10 air
execute in minecraft:overworld run fill 227 58 11 227 67 11 stone
schedule function blade_gallery:random/burned/part_30 1t replace
