execute in minecraft:overworld run setblock 208 64 15 coarse_dirt
execute in minecraft:overworld run fill 208 65 15 208 144 15 air
execute in minecraft:overworld run fill 208 58 16 208 61 16 stone
execute in minecraft:overworld run fill 208 62 16 208 63 16 dirt
execute in minecraft:overworld run setblock 208 64 16 coarse_dirt
execute in minecraft:overworld run fill 208 65 16 208 144 16 air
execute in minecraft:overworld run fill 208 58 17 208 61 17 stone
execute in minecraft:overworld run fill 208 62 17 208 63 17 dirt
execute in minecraft:overworld run setblock 208 64 17 coarse_dirt
execute in minecraft:overworld run fill 208 65 17 208 144 17 air
execute in minecraft:overworld run fill 208 58 18 208 61 18 stone
execute in minecraft:overworld run fill 208 62 18 208 63 18 dirt
execute in minecraft:overworld run setblock 208 64 18 coarse_dirt
execute in minecraft:overworld run fill 208 65 18 208 144 18 air
execute in minecraft:overworld run fill 208 58 19 208 61 19 stone
execute in minecraft:overworld run fill 208 62 19 208 63 19 dirt
execute in minecraft:overworld run setblock 208 64 19 coarse_dirt
execute in minecraft:overworld run fill 208 65 19 208 144 19 air
execute in minecraft:overworld run fill 208 58 20 208 61 20 stone
execute in minecraft:overworld run fill 208 62 20 208 63 20 dirt
execute in minecraft:overworld run setblock 208 64 20 coarse_dirt
execute in minecraft:overworld run fill 208 65 20 208 144 20 air
execute in minecraft:overworld run fill 208 58 21 208 61 21 stone
execute in minecraft:overworld run fill 208 62 21 208 63 21 dirt
execute in minecraft:overworld run setblock 208 64 21 coarse_dirt
execute in minecraft:overworld run fill 208 65 21 208 144 21 air
execute in minecraft:overworld run fill 208 58 22 208 61 22 stone
execute in minecraft:overworld run fill 208 62 22 208 63 22 dirt
execute in minecraft:overworld run setblock 208 64 22 coarse_dirt
execute in minecraft:overworld run fill 208 65 22 208 144 22 air
execute in minecraft:overworld run fill 208 58 23 208 61 23 stone
execute in minecraft:overworld run fill 208 62 23 208 63 23 dirt
execute in minecraft:overworld run setblock 208 64 23 grass_block
execute in minecraft:overworld run fill 208 65 23 208 144 23 air
execute in minecraft:overworld run fill 208 58 24 208 61 24 stone
execute in minecraft:overworld run fill 208 62 24 208 63 24 dirt
execute in minecraft:overworld run setblock 208 64 24 coarse_dirt
execute in minecraft:overworld run fill 208 65 24 208 144 24 air
execute in minecraft:overworld run fill 208 58 25 208 61 25 stone
execute in minecraft:overworld run fill 208 62 25 208 63 25 dirt
execute in minecraft:overworld run setblock 208 64 25 coarse_dirt
execute in minecraft:overworld run fill 208 65 25 208 144 25 air
execute in minecraft:overworld run fill 208 58 26 208 61 26 stone
execute in minecraft:overworld run fill 208 62 26 208 63 26 dirt
execute in minecraft:overworld run setblock 208 64 26 coarse_dirt
execute in minecraft:overworld run fill 208 65 26 208 144 26 air
execute in minecraft:overworld run fill 208 58 27 208 61 27 stone
execute in minecraft:overworld run fill 208 62 27 208 63 27 dirt
execute in minecraft:overworld run setblock 208 64 27 grass_block
execute in minecraft:overworld run fill 208 65 27 208 144 27 air
execute in minecraft:overworld run fill 208 58 28 208 61 28 stone
execute in minecraft:overworld run fill 208 62 28 208 63 28 dirt
execute in minecraft:overworld run setblock 208 64 28 coarse_dirt
execute in minecraft:overworld run fill 208 65 28 208 144 28 air
execute in minecraft:overworld run fill 208 58 29 208 61 29 stone
execute in minecraft:overworld run fill 208 62 29 208 63 29 dirt
execute in minecraft:overworld run setblock 208 64 29 grass_block
execute in minecraft:overworld run fill 208 65 29 208 144 29 air
execute in minecraft:overworld run fill 208 58 30 208 61 30 stone
execute in minecraft:overworld run fill 208 62 30 208 63 30 dirt
execute in minecraft:overworld run setblock 208 64 30 coarse_dirt
execute in minecraft:overworld run fill 208 65 30 208 144 30 air
execute in minecraft:overworld run fill 208 58 31 208 61 31 stone
execute in minecraft:overworld run fill 208 62 31 208 63 31 dirt
execute in minecraft:overworld run setblock 208 64 31 grass_block
execute in minecraft:overworld run fill 208 65 31 208 144 31 air
execute in minecraft:overworld run fill 208 58 32 208 61 32 stone
execute in minecraft:overworld run fill 208 62 32 208 63 32 dirt
execute in minecraft:overworld run setblock 208 64 32 coarse_dirt
execute in minecraft:overworld run fill 208 65 32 208 144 32 air
execute in minecraft:overworld run fill 208 58 33 208 61 33 stone
execute in minecraft:overworld run fill 208 62 33 208 63 33 dirt
execute in minecraft:overworld run setblock 208 64 33 coarse_dirt
execute in minecraft:overworld run fill 208 65 33 208 144 33 air
execute in minecraft:overworld run fill 208 58 34 208 61 34 stone
execute in minecraft:overworld run fill 208 62 34 208 63 34 dirt
execute in minecraft:overworld run setblock 208 64 34 coarse_dirt
execute in minecraft:overworld run fill 208 65 34 208 144 34 air
execute in minecraft:overworld run fill 208 58 35 208 61 35 stone
execute in minecraft:overworld run fill 208 62 35 208 63 35 dirt
execute in minecraft:overworld run setblock 208 64 35 coarse_dirt
execute in minecraft:overworld run fill 208 65 35 208 144 35 air
execute in minecraft:overworld run fill 208 58 36 208 61 36 stone
execute in minecraft:overworld run fill 208 62 36 208 63 36 dirt
execute in minecraft:overworld run setblock 208 64 36 grass_block
execute in minecraft:overworld run fill 208 65 36 208 144 36 air
execute in minecraft:overworld run fill 208 58 37 208 61 37 stone
execute in minecraft:overworld run fill 208 62 37 208 63 37 dirt
execute in minecraft:overworld run setblock 208 64 37 coarse_dirt
execute in minecraft:overworld run fill 208 65 37 208 144 37 air
execute in minecraft:overworld run fill 208 58 38 208 61 38 stone
execute in minecraft:overworld run fill 208 62 38 208 63 38 dirt
execute in minecraft:overworld run setblock 208 64 38 grass_block
execute in minecraft:overworld run fill 208 65 38 208 144 38 air
execute in minecraft:overworld run fill 208 58 39 208 61 39 stone
execute in minecraft:overworld run fill 208 62 39 208 63 39 dirt
execute in minecraft:overworld run setblock 208 64 39 grass_block
execute in minecraft:overworld run fill 208 65 39 208 144 39 air
execute in minecraft:overworld run fill 208 58 40 208 61 40 stone
execute in minecraft:overworld run fill 208 62 40 208 63 40 dirt
execute in minecraft:overworld run setblock 208 64 40 grass_block
execute in minecraft:overworld run fill 208 65 40 208 144 40 air
execute in minecraft:overworld run fill 208 58 41 208 61 41 stone
execute in minecraft:overworld run fill 208 62 41 208 63 41 dirt
execute in minecraft:overworld run setblock 208 64 41 coarse_dirt
execute in minecraft:overworld run fill 208 65 41 208 144 41 air
execute in minecraft:overworld run fill 208 58 42 208 61 42 stone
execute in minecraft:overworld run fill 208 62 42 208 63 42 dirt
execute in minecraft:overworld run setblock 208 64 42 coarse_dirt
execute in minecraft:overworld run fill 208 65 42 208 144 42 air
execute in minecraft:overworld run fill 208 58 43 208 61 43 stone
execute in minecraft:overworld run fill 208 62 43 208 63 43 dirt
execute in minecraft:overworld run setblock 208 64 43 coarse_dirt
execute in minecraft:overworld run fill 208 65 43 208 144 43 air
execute in minecraft:overworld run fill 208 58 44 208 61 44 stone
execute in minecraft:overworld run fill 208 62 44 208 63 44 dirt
execute in minecraft:overworld run setblock 208 64 44 coarse_dirt
execute in minecraft:overworld run fill 208 65 44 208 144 44 air
execute in minecraft:overworld run fill 208 58 45 208 61 45 stone
execute in minecraft:overworld run fill 208 62 45 208 63 45 dirt
execute in minecraft:overworld run setblock 208 64 45 grass_block
execute in minecraft:overworld run fill 208 65 45 208 144 45 air
execute in minecraft:overworld run fill 208 58 46 208 61 46 stone
execute in minecraft:overworld run fill 208 62 46 208 63 46 dirt
execute in minecraft:overworld run setblock 208 64 46 coarse_dirt
execute in minecraft:overworld run fill 208 65 46 208 144 46 air
execute in minecraft:overworld run fill 208 58 47 208 61 47 stone
execute in minecraft:overworld run fill 208 62 47 208 63 47 dirt
execute in minecraft:overworld run setblock 208 64 47 coarse_dirt
execute in minecraft:overworld run fill 208 65 47 208 144 47 air
execute in minecraft:overworld run fill 209 58 -48 209 61 -48 stone
execute in minecraft:overworld run fill 209 62 -48 209 63 -48 dirt
execute in minecraft:overworld run setblock 209 64 -48 coarse_dirt
execute in minecraft:overworld run fill 209 65 -48 209 144 -48 air
execute in minecraft:overworld run fill 209 58 -47 209 63 -47 stone
execute in minecraft:overworld run fill 209 64 -47 209 65 -47 dirt
execute in minecraft:overworld run setblock 209 66 -47 grass_block
execute in minecraft:overworld run fill 209 67 -47 209 144 -47 air
execute in minecraft:overworld run fill 209 58 -46 209 63 -46 stone
execute in minecraft:overworld run fill 209 64 -46 209 65 -46 dirt
execute in minecraft:overworld run setblock 209 66 -46 grass_block
execute in minecraft:overworld run fill 209 67 -46 209 144 -46 air
execute in minecraft:overworld run fill 209 58 -45 209 63 -45 stone
execute in minecraft:overworld run fill 209 64 -45 209 65 -45 dirt
execute in minecraft:overworld run setblock 209 66 -45 coarse_dirt
execute in minecraft:overworld run fill 209 67 -45 209 144 -45 air
execute in minecraft:overworld run fill 209 58 -44 209 63 -44 stone
execute in minecraft:overworld run fill 209 64 -44 209 65 -44 dirt
execute in minecraft:overworld run setblock 209 66 -44 coarse_dirt
execute in minecraft:overworld run fill 209 67 -44 209 144 -44 air
execute in minecraft:overworld run fill 209 58 -43 209 63 -43 stone
execute in minecraft:overworld run fill 209 64 -43 209 65 -43 dirt
execute in minecraft:overworld run setblock 209 66 -43 grass_block
execute in minecraft:overworld run fill 209 67 -43 209 144 -43 air
execute in minecraft:overworld run fill 209 58 -42 209 62 -42 stone
execute in minecraft:overworld run fill 209 63 -42 209 64 -42 dirt
execute in minecraft:overworld run setblock 209 65 -42 grass_block
execute in minecraft:overworld run fill 209 66 -42 209 144 -42 air
execute in minecraft:overworld run fill 209 58 -41 209 62 -41 stone
execute in minecraft:overworld run fill 209 63 -41 209 64 -41 dirt
execute in minecraft:overworld run setblock 209 65 -41 grass_block
execute in minecraft:overworld run fill 209 66 -41 209 144 -41 air
execute in minecraft:overworld run fill 209 58 -40 209 62 -40 stone
execute in minecraft:overworld run fill 209 63 -40 209 64 -40 dirt
execute in minecraft:overworld run setblock 209 65 -40 grass_block
execute in minecraft:overworld run fill 209 66 -40 209 144 -40 air
execute in minecraft:overworld run fill 209 58 -39 209 62 -39 stone
execute in minecraft:overworld run fill 209 63 -39 209 64 -39 dirt
execute in minecraft:overworld run setblock 209 65 -39 coarse_dirt
execute in minecraft:overworld run fill 209 66 -39 209 144 -39 air
execute in minecraft:overworld run fill 209 58 -38 209 62 -38 stone
execute in minecraft:overworld run fill 209 63 -38 209 64 -38 dirt
execute in minecraft:overworld run setblock 209 65 -38 coarse_dirt
execute in minecraft:overworld run fill 209 66 -38 209 144 -38 air
execute in minecraft:overworld run fill 209 58 -37 209 62 -37 stone
execute in minecraft:overworld run fill 209 63 -37 209 64 -37 dirt
execute in minecraft:overworld run setblock 209 65 -37 grass_block
execute in minecraft:overworld run fill 209 66 -37 209 144 -37 air
execute in minecraft:overworld run fill 209 58 -36 209 62 -36 stone
execute in minecraft:overworld run fill 209 63 -36 209 64 -36 dirt
execute in minecraft:overworld run setblock 209 65 -36 coarse_dirt
execute in minecraft:overworld run fill 209 66 -36 209 144 -36 air
execute in minecraft:overworld run fill 209 58 -35 209 62 -35 stone
execute in minecraft:overworld run fill 209 63 -35 209 64 -35 dirt
execute in minecraft:overworld run setblock 209 65 -35 grass_block
execute in minecraft:overworld run fill 209 66 -35 209 144 -35 air
execute in minecraft:overworld run fill 209 58 -34 209 62 -34 stone
execute in minecraft:overworld run fill 209 63 -34 209 64 -34 dirt
execute in minecraft:overworld run setblock 209 65 -34 coarse_dirt
execute in minecraft:overworld run fill 209 66 -34 209 144 -34 air
execute in minecraft:overworld run fill 209 58 -33 209 62 -33 stone
execute in minecraft:overworld run fill 209 63 -33 209 64 -33 dirt
execute in minecraft:overworld run setblock 209 65 -33 coarse_dirt
execute in minecraft:overworld run fill 209 66 -33 209 144 -33 air
execute in minecraft:overworld run fill 209 58 -32 209 62 -32 stone
execute in minecraft:overworld run fill 209 63 -32 209 64 -32 dirt
execute in minecraft:overworld run setblock 209 65 -32 coarse_dirt
execute in minecraft:overworld run fill 209 66 -32 209 144 -32 air
execute in minecraft:overworld run fill 209 58 -31 209 62 -31 stone
execute in minecraft:overworld run fill 209 63 -31 209 64 -31 dirt
execute in minecraft:overworld run setblock 209 65 -31 coarse_dirt
execute in minecraft:overworld run fill 209 66 -31 209 144 -31 air
execute in minecraft:overworld run fill 209 58 -30 209 62 -30 stone
execute in minecraft:overworld run fill 209 63 -30 209 64 -30 dirt
execute in minecraft:overworld run setblock 209 65 -30 grass_block
execute in minecraft:overworld run fill 209 66 -30 209 144 -30 air
execute in minecraft:overworld run fill 209 58 -29 209 62 -29 stone
execute in minecraft:overworld run fill 209 63 -29 209 64 -29 dirt
execute in minecraft:overworld run setblock 209 65 -29 grass_block
execute in minecraft:overworld run fill 209 66 -29 209 144 -29 air
execute in minecraft:overworld run fill 209 58 -28 209 62 -28 stone
execute in minecraft:overworld run fill 209 63 -28 209 64 -28 dirt
execute in minecraft:overworld run setblock 209 65 -28 coarse_dirt
execute in minecraft:overworld run fill 209 66 -28 209 144 -28 air
execute in minecraft:overworld run fill 209 58 -27 209 62 -27 stone
execute in minecraft:overworld run fill 209 63 -27 209 64 -27 dirt
execute in minecraft:overworld run setblock 209 65 -27 coarse_dirt
execute in minecraft:overworld run fill 209 66 -27 209 144 -27 air
execute in minecraft:overworld run fill 209 58 -26 209 62 -26 stone
execute in minecraft:overworld run fill 209 63 -26 209 64 -26 dirt
execute in minecraft:overworld run setblock 209 65 -26 coarse_dirt
execute in minecraft:overworld run fill 209 66 -26 209 144 -26 air
execute in minecraft:overworld run fill 209 58 -25 209 62 -25 stone
execute in minecraft:overworld run fill 209 63 -25 209 64 -25 dirt
execute in minecraft:overworld run setblock 209 65 -25 coarse_dirt
execute in minecraft:overworld run fill 209 66 -25 209 144 -25 air
execute in minecraft:overworld run fill 209 58 -24 209 62 -24 stone
execute in minecraft:overworld run fill 209 63 -24 209 64 -24 dirt
execute in minecraft:overworld run setblock 209 65 -24 grass_block
execute in minecraft:overworld run fill 209 66 -24 209 144 -24 air
execute in minecraft:overworld run fill 209 58 -23 209 62 -23 stone
execute in minecraft:overworld run fill 209 63 -23 209 64 -23 dirt
execute in minecraft:overworld run setblock 209 65 -23 coarse_dirt
execute in minecraft:overworld run fill 209 66 -23 209 144 -23 air
execute in minecraft:overworld run fill 209 58 -22 209 62 -22 stone
execute in minecraft:overworld run fill 209 63 -22 209 64 -22 dirt
execute in minecraft:overworld run setblock 209 65 -22 grass_block
execute in minecraft:overworld run fill 209 66 -22 209 144 -22 air
execute in minecraft:overworld run fill 209 58 -21 209 62 -21 stone
execute in minecraft:overworld run fill 209 63 -21 209 64 -21 dirt
execute in minecraft:overworld run setblock 209 65 -21 coarse_dirt
execute in minecraft:overworld run fill 209 66 -21 209 144 -21 air
execute in minecraft:overworld run fill 209 58 -20 209 62 -20 stone
execute in minecraft:overworld run fill 209 63 -20 209 64 -20 dirt
execute in minecraft:overworld run setblock 209 65 -20 grass_block
execute in minecraft:overworld run fill 209 66 -20 209 144 -20 air
execute in minecraft:overworld run fill 209 58 -19 209 61 -19 stone
execute in minecraft:overworld run fill 209 62 -19 209 63 -19 dirt
execute in minecraft:overworld run setblock 209 64 -19 coarse_dirt
execute in minecraft:overworld run fill 209 65 -19 209 144 -19 air
execute in minecraft:overworld run fill 209 58 -18 209 61 -18 stone
execute in minecraft:overworld run fill 209 62 -18 209 63 -18 dirt
execute in minecraft:overworld run setblock 209 64 -18 coarse_dirt
execute in minecraft:overworld run fill 209 65 -18 209 144 -18 air
execute in minecraft:overworld run fill 209 58 -17 209 61 -17 stone
execute in minecraft:overworld run fill 209 62 -17 209 63 -17 dirt
schedule function blade_gallery:random/burned/part_2 1t replace
