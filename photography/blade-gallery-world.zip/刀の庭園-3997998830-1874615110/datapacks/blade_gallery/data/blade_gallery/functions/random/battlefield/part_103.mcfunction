execute in minecraft:overworld run setblock 401 66 -12 grass_block
execute in minecraft:overworld run fill 401 67 -12 401 144 -12 air
execute in minecraft:overworld run fill 401 58 -11 401 63 -11 stone
execute in minecraft:overworld run fill 401 64 -11 401 65 -11 dirt
execute in minecraft:overworld run setblock 401 66 -11 grass_block
execute in minecraft:overworld run fill 401 67 -11 401 144 -11 air
execute in minecraft:overworld run setblock 401 67 -11 mossy_cobblestone
execute in minecraft:overworld run fill 401 58 -10 401 62 -10 stone
execute in minecraft:overworld run fill 401 63 -10 401 64 -10 dirt
execute in minecraft:overworld run setblock 401 65 -10 coarse_dirt
execute in minecraft:overworld run fill 401 66 -10 401 144 -10 air
execute in minecraft:overworld run setblock 401 66 -10 grass
execute in minecraft:overworld run fill 401 58 -9 401 62 -9 stone
execute in minecraft:overworld run fill 401 63 -9 401 64 -9 dirt
execute in minecraft:overworld run setblock 401 65 -9 grass_block
execute in minecraft:overworld run fill 401 66 -9 401 144 -9 air
execute in minecraft:overworld run fill 401 58 -8 401 61 -8 stone
execute in minecraft:overworld run fill 401 62 -8 401 63 -8 dirt
execute in minecraft:overworld run setblock 401 64 -8 coarse_dirt
execute in minecraft:overworld run fill 401 65 -8 401 144 -8 air
execute in minecraft:overworld run fill 401 58 -7 401 61 -7 stone
execute in minecraft:overworld run fill 401 62 -7 401 63 -7 dirt
execute in minecraft:overworld run setblock 401 64 -7 coarse_dirt
execute in minecraft:overworld run fill 401 65 -7 401 144 -7 air
execute in minecraft:overworld run fill 401 58 -6 401 60 -6 stone
execute in minecraft:overworld run fill 401 61 -6 401 62 -6 dirt
execute in minecraft:overworld run setblock 401 63 -6 gravel
execute in minecraft:overworld run fill 401 64 -6 401 144 -6 air
execute in minecraft:overworld run fill 401 64 -6 401 64 -6 water
execute in minecraft:overworld run fill 401 58 -5 401 60 -5 stone
execute in minecraft:overworld run fill 401 61 -5 401 62 -5 dirt
execute in minecraft:overworld run setblock 401 63 -5 gravel
execute in minecraft:overworld run fill 401 64 -5 401 144 -5 air
execute in minecraft:overworld run fill 401 64 -5 401 64 -5 water
execute in minecraft:overworld run fill 401 58 -4 401 60 -4 stone
execute in minecraft:overworld run fill 401 61 -4 401 62 -4 dirt
execute in minecraft:overworld run setblock 401 63 -4 gravel
execute in minecraft:overworld run fill 401 64 -4 401 144 -4 air
execute in minecraft:overworld run fill 401 64 -4 401 64 -4 water
execute in minecraft:overworld run fill 401 58 -3 401 59 -3 stone
execute in minecraft:overworld run fill 401 60 -3 401 61 -3 dirt
execute in minecraft:overworld run setblock 401 62 -3 gravel
execute in minecraft:overworld run fill 401 63 -3 401 144 -3 air
execute in minecraft:overworld run fill 401 63 -3 401 64 -3 water
execute in minecraft:overworld run fill 401 58 -2 401 59 -2 stone
execute in minecraft:overworld run fill 401 60 -2 401 61 -2 dirt
execute in minecraft:overworld run setblock 401 62 -2 gravel
execute in minecraft:overworld run fill 401 63 -2 401 144 -2 air
execute in minecraft:overworld run fill 401 63 -2 401 64 -2 water
execute in minecraft:overworld run fill 401 58 -1 401 58 -1 stone
execute in minecraft:overworld run fill 401 59 -1 401 60 -1 dirt
execute in minecraft:overworld run setblock 401 61 -1 gravel
execute in minecraft:overworld run fill 401 62 -1 401 144 -1 air
execute in minecraft:overworld run fill 401 62 -1 401 64 -1 water
execute in minecraft:overworld run fill 401 58 0 401 58 0 stone
execute in minecraft:overworld run fill 401 59 0 401 60 0 dirt
execute in minecraft:overworld run setblock 401 61 0 gravel
execute in minecraft:overworld run fill 401 62 0 401 144 0 air
execute in minecraft:overworld run fill 401 62 0 401 64 0 water
execute in minecraft:overworld run fill 401 58 1 401 58 1 stone
execute in minecraft:overworld run fill 401 59 1 401 60 1 dirt
execute in minecraft:overworld run setblock 401 61 1 gravel
execute in minecraft:overworld run fill 401 62 1 401 144 1 air
execute in minecraft:overworld run fill 401 62 1 401 64 1 water
execute in minecraft:overworld run fill 401 58 2 401 58 2 stone
execute in minecraft:overworld run fill 401 59 2 401 60 2 dirt
execute in minecraft:overworld run setblock 401 61 2 gravel
execute in minecraft:overworld run fill 401 62 2 401 144 2 air
execute in minecraft:overworld run fill 401 62 2 401 64 2 water
execute in minecraft:overworld run fill 401 58 3 401 57 3 stone
execute in minecraft:overworld run fill 401 58 3 401 59 3 dirt
execute in minecraft:overworld run setblock 401 60 3 gravel
execute in minecraft:overworld run fill 401 61 3 401 144 3 air
execute in minecraft:overworld run fill 401 61 3 401 64 3 water
execute in minecraft:overworld run fill 401 58 4 401 57 4 stone
execute in minecraft:overworld run fill 401 58 4 401 59 4 dirt
execute in minecraft:overworld run setblock 401 60 4 gravel
execute in minecraft:overworld run fill 401 61 4 401 144 4 air
execute in minecraft:overworld run fill 401 61 4 401 64 4 water
execute in minecraft:overworld run fill 401 58 5 401 57 5 stone
execute in minecraft:overworld run fill 401 58 5 401 59 5 dirt
execute in minecraft:overworld run setblock 401 60 5 gravel
execute in minecraft:overworld run fill 401 61 5 401 144 5 air
execute in minecraft:overworld run fill 401 61 5 401 64 5 water
execute in minecraft:overworld run fill 401 58 6 401 57 6 stone
execute in minecraft:overworld run fill 401 58 6 401 59 6 dirt
execute in minecraft:overworld run setblock 401 60 6 gravel
execute in minecraft:overworld run fill 401 61 6 401 144 6 air
execute in minecraft:overworld run fill 401 61 6 401 64 6 water
execute in minecraft:overworld run fill 401 58 7 401 57 7 stone
execute in minecraft:overworld run fill 401 58 7 401 59 7 dirt
execute in minecraft:overworld run setblock 401 60 7 gravel
execute in minecraft:overworld run fill 401 61 7 401 144 7 air
execute in minecraft:overworld run fill 401 61 7 401 64 7 water
execute in minecraft:overworld run fill 401 58 8 401 57 8 stone
execute in minecraft:overworld run fill 401 58 8 401 59 8 dirt
execute in minecraft:overworld run setblock 401 60 8 gravel
execute in minecraft:overworld run fill 401 61 8 401 144 8 air
execute in minecraft:overworld run fill 401 61 8 401 64 8 water
execute in minecraft:overworld run fill 401 58 9 401 58 9 stone
execute in minecraft:overworld run fill 401 59 9 401 60 9 dirt
execute in minecraft:overworld run setblock 401 61 9 gravel
execute in minecraft:overworld run fill 401 62 9 401 144 9 air
execute in minecraft:overworld run fill 401 62 9 401 64 9 water
execute in minecraft:overworld run fill 401 58 10 401 58 10 stone
execute in minecraft:overworld run fill 401 59 10 401 60 10 dirt
execute in minecraft:overworld run setblock 401 61 10 gravel
execute in minecraft:overworld run fill 401 62 10 401 144 10 air
execute in minecraft:overworld run fill 401 62 10 401 64 10 water
execute in minecraft:overworld run fill 401 58 11 401 58 11 stone
execute in minecraft:overworld run fill 401 59 11 401 60 11 dirt
execute in minecraft:overworld run setblock 401 61 11 gravel
execute in minecraft:overworld run fill 401 62 11 401 144 11 air
execute in minecraft:overworld run fill 401 62 11 401 64 11 water
execute in minecraft:overworld run fill 401 58 12 401 58 12 stone
execute in minecraft:overworld run fill 401 59 12 401 60 12 dirt
execute in minecraft:overworld run setblock 401 61 12 gravel
execute in minecraft:overworld run fill 401 62 12 401 144 12 air
execute in minecraft:overworld run fill 401 62 12 401 64 12 water
execute in minecraft:overworld run fill 401 58 13 401 59 13 stone
execute in minecraft:overworld run fill 401 60 13 401 61 13 dirt
execute in minecraft:overworld run setblock 401 62 13 gravel
execute in minecraft:overworld run fill 401 63 13 401 144 13 air
execute in minecraft:overworld run fill 401 63 13 401 64 13 water
execute in minecraft:overworld run fill 401 58 14 401 59 14 stone
execute in minecraft:overworld run fill 401 60 14 401 61 14 dirt
execute in minecraft:overworld run setblock 401 62 14 gravel
execute in minecraft:overworld run fill 401 63 14 401 144 14 air
execute in minecraft:overworld run fill 401 63 14 401 64 14 water
execute in minecraft:overworld run fill 401 58 15 401 59 15 stone
execute in minecraft:overworld run fill 401 60 15 401 61 15 dirt
execute in minecraft:overworld run setblock 401 62 15 gravel
execute in minecraft:overworld run fill 401 63 15 401 144 15 air
execute in minecraft:overworld run fill 401 63 15 401 64 15 water
execute in minecraft:overworld run fill 401 58 16 401 60 16 stone
execute in minecraft:overworld run fill 401 61 16 401 62 16 dirt
execute in minecraft:overworld run setblock 401 63 16 gravel
execute in minecraft:overworld run fill 401 64 16 401 144 16 air
execute in minecraft:overworld run fill 401 64 16 401 64 16 water
execute in minecraft:overworld run fill 401 58 17 401 60 17 stone
execute in minecraft:overworld run fill 401 61 17 401 62 17 dirt
execute in minecraft:overworld run setblock 401 63 17 gravel
execute in minecraft:overworld run fill 401 64 17 401 144 17 air
execute in minecraft:overworld run fill 401 64 17 401 64 17 water
execute in minecraft:overworld run fill 401 58 18 401 60 18 stone
execute in minecraft:overworld run fill 401 61 18 401 62 18 dirt
execute in minecraft:overworld run setblock 401 63 18 gravel
execute in minecraft:overworld run fill 401 64 18 401 144 18 air
execute in minecraft:overworld run fill 401 64 18 401 64 18 water
execute in minecraft:overworld run fill 401 58 19 401 61 19 stone
execute in minecraft:overworld run fill 401 62 19 401 63 19 dirt
execute in minecraft:overworld run setblock 401 64 19 coarse_dirt
execute in minecraft:overworld run fill 401 65 19 401 144 19 air
execute in minecraft:overworld run fill 401 58 20 401 61 20 stone
execute in minecraft:overworld run fill 401 62 20 401 63 20 dirt
execute in minecraft:overworld run setblock 401 64 20 coarse_dirt
execute in minecraft:overworld run fill 401 65 20 401 144 20 air
execute in minecraft:overworld run fill 401 58 21 401 61 21 stone
execute in minecraft:overworld run fill 401 62 21 401 63 21 dirt
execute in minecraft:overworld run setblock 401 64 21 grass_block
execute in minecraft:overworld run fill 401 65 21 401 144 21 air
execute in minecraft:overworld run fill 401 58 22 401 62 22 stone
execute in minecraft:overworld run fill 401 63 22 401 64 22 dirt
execute in minecraft:overworld run setblock 401 65 22 grass_block
execute in minecraft:overworld run fill 401 66 22 401 144 22 air
execute in minecraft:overworld run setblock 401 66 22 grass
execute in minecraft:overworld run fill 401 58 23 401 62 23 stone
execute in minecraft:overworld run fill 401 63 23 401 64 23 dirt
execute in minecraft:overworld run setblock 401 65 23 coarse_dirt
execute in minecraft:overworld run fill 401 66 23 401 144 23 air
execute in minecraft:overworld run fill 401 58 24 401 62 24 stone
execute in minecraft:overworld run fill 401 63 24 401 64 24 dirt
execute in minecraft:overworld run setblock 401 65 24 coarse_dirt
execute in minecraft:overworld run fill 401 66 24 401 144 24 air
execute in minecraft:overworld run fill 401 58 25 401 63 25 stone
execute in minecraft:overworld run fill 401 64 25 401 65 25 dirt
execute in minecraft:overworld run setblock 401 66 25 coarse_dirt
execute in minecraft:overworld run fill 401 67 25 401 144 25 air
execute in minecraft:overworld run fill 401 58 26 401 63 26 stone
execute in minecraft:overworld run fill 401 64 26 401 65 26 dirt
execute in minecraft:overworld run setblock 401 66 26 coarse_dirt
execute in minecraft:overworld run fill 401 67 26 401 144 26 air
execute in minecraft:overworld run setblock 401 67 26 grass
execute in minecraft:overworld run fill 401 58 27 401 64 27 stone
execute in minecraft:overworld run fill 401 65 27 401 66 27 dirt
execute in minecraft:overworld run setblock 401 67 27 coarse_dirt
execute in minecraft:overworld run fill 401 68 27 401 144 27 air
execute in minecraft:overworld run fill 401 58 28 401 64 28 stone
execute in minecraft:overworld run fill 401 65 28 401 66 28 dirt
execute in minecraft:overworld run setblock 401 67 28 grass_block
execute in minecraft:overworld run fill 401 68 28 401 144 28 air
execute in minecraft:overworld run fill 401 58 29 401 64 29 stone
execute in minecraft:overworld run fill 401 65 29 401 66 29 dirt
execute in minecraft:overworld run setblock 401 67 29 coarse_dirt
execute in minecraft:overworld run fill 401 68 29 401 144 29 air
execute in minecraft:overworld run fill 401 58 30 401 64 30 stone
execute in minecraft:overworld run fill 401 65 30 401 66 30 dirt
execute in minecraft:overworld run setblock 401 67 30 coarse_dirt
execute in minecraft:overworld run fill 401 68 30 401 144 30 air
execute in minecraft:overworld run fill 401 58 31 401 64 31 stone
execute in minecraft:overworld run fill 401 65 31 401 66 31 dirt
execute in minecraft:overworld run setblock 401 67 31 grass_block
execute in minecraft:overworld run fill 401 68 31 401 144 31 air
execute in minecraft:overworld run fill 401 58 32 401 64 32 stone
execute in minecraft:overworld run fill 401 65 32 401 66 32 dirt
execute in minecraft:overworld run setblock 401 67 32 coarse_dirt
execute in minecraft:overworld run fill 401 68 32 401 144 32 air
execute in minecraft:overworld run setblock 401 68 32 grass
execute in minecraft:overworld run fill 401 58 33 401 65 33 stone
execute in minecraft:overworld run fill 401 66 33 401 67 33 dirt
execute in minecraft:overworld run setblock 401 68 33 coarse_dirt
execute in minecraft:overworld run fill 401 69 33 401 144 33 air
execute in minecraft:overworld run fill 401 58 34 401 65 34 stone
execute in minecraft:overworld run fill 401 66 34 401 67 34 dirt
execute in minecraft:overworld run setblock 401 68 34 grass_block
execute in minecraft:overworld run fill 401 69 34 401 144 34 air
execute in minecraft:overworld run fill 401 58 35 401 65 35 stone
execute in minecraft:overworld run fill 401 66 35 401 67 35 dirt
execute in minecraft:overworld run setblock 401 68 35 coarse_dirt
execute in minecraft:overworld run fill 401 69 35 401 144 35 air
execute in minecraft:overworld run fill 401 58 36 401 65 36 stone
execute in minecraft:overworld run fill 401 66 36 401 67 36 dirt
execute in minecraft:overworld run setblock 401 68 36 coarse_dirt
execute in minecraft:overworld run fill 401 69 36 401 144 36 air
execute in minecraft:overworld run fill 401 58 37 401 65 37 stone
execute in minecraft:overworld run fill 401 66 37 401 67 37 dirt
execute in minecraft:overworld run setblock 401 68 37 coarse_dirt
execute in minecraft:overworld run fill 401 69 37 401 144 37 air
execute in minecraft:overworld run fill 401 58 38 401 66 38 stone
execute in minecraft:overworld run fill 401 67 38 401 68 38 dirt
execute in minecraft:overworld run setblock 401 69 38 grass_block
execute in minecraft:overworld run fill 401 70 38 401 144 38 air
execute in minecraft:overworld run fill 401 58 39 401 66 39 stone
execute in minecraft:overworld run fill 401 67 39 401 68 39 dirt
execute in minecraft:overworld run setblock 401 69 39 coarse_dirt
execute in minecraft:overworld run fill 401 70 39 401 144 39 air
execute in minecraft:overworld run fill 401 58 40 401 66 40 stone
execute in minecraft:overworld run fill 401 67 40 401 68 40 dirt
execute in minecraft:overworld run setblock 401 69 40 coarse_dirt
execute in minecraft:overworld run fill 401 70 40 401 144 40 air
execute in minecraft:overworld run fill 401 58 41 401 65 41 stone
execute in minecraft:overworld run fill 401 66 41 401 67 41 dirt
execute in minecraft:overworld run setblock 401 68 41 coarse_dirt
execute in minecraft:overworld run fill 401 69 41 401 144 41 air
execute in minecraft:overworld run fill 401 58 42 401 65 42 stone
execute in minecraft:overworld run fill 401 66 42 401 67 42 dirt
execute in minecraft:overworld run setblock 401 68 42 grass_block
execute in minecraft:overworld run fill 401 69 42 401 144 42 air
execute in minecraft:overworld run fill 401 58 43 401 64 43 stone
execute in minecraft:overworld run fill 401 65 43 401 66 43 dirt
execute in minecraft:overworld run setblock 401 67 43 grass_block
execute in minecraft:overworld run fill 401 68 43 401 144 43 air
execute in minecraft:overworld run fill 401 58 44 401 64 44 stone
execute in minecraft:overworld run fill 401 65 44 401 66 44 dirt
execute in minecraft:overworld run setblock 401 67 44 coarse_dirt
execute in minecraft:overworld run fill 401 68 44 401 144 44 air
schedule function blade_gallery:random/battlefield/part_104 1t replace
