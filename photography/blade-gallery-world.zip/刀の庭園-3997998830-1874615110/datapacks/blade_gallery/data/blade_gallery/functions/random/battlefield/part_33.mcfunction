execute in minecraft:overworld run setblock 357 72 11 grass
execute in minecraft:overworld run fill 357 58 12 357 68 12 stone
execute in minecraft:overworld run fill 357 69 12 357 70 12 dirt
execute in minecraft:overworld run setblock 357 71 12 coarse_dirt
execute in minecraft:overworld run fill 357 72 12 357 144 12 air
execute in minecraft:overworld run fill 357 58 13 357 68 13 stone
execute in minecraft:overworld run fill 357 69 13 357 70 13 dirt
execute in minecraft:overworld run setblock 357 71 13 grass_block
execute in minecraft:overworld run fill 357 72 13 357 144 13 air
execute in minecraft:overworld run fill 357 58 14 357 68 14 stone
execute in minecraft:overworld run fill 357 69 14 357 70 14 dirt
execute in minecraft:overworld run setblock 357 71 14 coarse_dirt
execute in minecraft:overworld run fill 357 72 14 357 144 14 air
execute in minecraft:overworld run fill 357 58 15 357 68 15 stone
execute in minecraft:overworld run fill 357 69 15 357 70 15 dirt
execute in minecraft:overworld run setblock 357 71 15 coarse_dirt
execute in minecraft:overworld run fill 357 72 15 357 144 15 air
execute in minecraft:overworld run fill 357 58 16 357 68 16 stone
execute in minecraft:overworld run fill 357 69 16 357 70 16 dirt
execute in minecraft:overworld run setblock 357 71 16 coarse_dirt
execute in minecraft:overworld run fill 357 72 16 357 144 16 air
execute in minecraft:overworld run fill 357 58 17 357 68 17 stone
execute in minecraft:overworld run fill 357 69 17 357 70 17 dirt
execute in minecraft:overworld run setblock 357 71 17 coarse_dirt
execute in minecraft:overworld run fill 357 72 17 357 144 17 air
execute in minecraft:overworld run fill 357 58 18 357 68 18 stone
execute in minecraft:overworld run fill 357 69 18 357 70 18 dirt
execute in minecraft:overworld run setblock 357 71 18 coarse_dirt
execute in minecraft:overworld run fill 357 72 18 357 144 18 air
execute in minecraft:overworld run fill 357 58 19 357 68 19 stone
execute in minecraft:overworld run fill 357 69 19 357 70 19 dirt
execute in minecraft:overworld run setblock 357 71 19 coarse_dirt
execute in minecraft:overworld run fill 357 72 19 357 144 19 air
execute in minecraft:overworld run fill 357 58 20 357 68 20 stone
execute in minecraft:overworld run fill 357 69 20 357 70 20 dirt
execute in minecraft:overworld run setblock 357 71 20 coarse_dirt
execute in minecraft:overworld run fill 357 72 20 357 144 20 air
execute in minecraft:overworld run setblock 357 72 20 grass
execute in minecraft:overworld run fill 357 58 21 357 68 21 stone
execute in minecraft:overworld run fill 357 69 21 357 70 21 dirt
execute in minecraft:overworld run setblock 357 71 21 coarse_dirt
execute in minecraft:overworld run fill 357 72 21 357 144 21 air
execute in minecraft:overworld run fill 357 58 22 357 68 22 stone
execute in minecraft:overworld run fill 357 69 22 357 70 22 dirt
execute in minecraft:overworld run setblock 357 71 22 coarse_dirt
execute in minecraft:overworld run fill 357 72 22 357 144 22 air
execute in minecraft:overworld run setblock 357 72 22 grass
execute in minecraft:overworld run fill 357 58 23 357 68 23 stone
execute in minecraft:overworld run fill 357 69 23 357 70 23 dirt
execute in minecraft:overworld run setblock 357 71 23 coarse_dirt
execute in minecraft:overworld run fill 357 72 23 357 144 23 air
execute in minecraft:overworld run fill 357 58 24 357 68 24 stone
execute in minecraft:overworld run fill 357 69 24 357 70 24 dirt
execute in minecraft:overworld run setblock 357 71 24 coarse_dirt
execute in minecraft:overworld run fill 357 72 24 357 144 24 air
execute in minecraft:overworld run fill 357 58 25 357 68 25 stone
execute in minecraft:overworld run fill 357 69 25 357 70 25 dirt
execute in minecraft:overworld run setblock 357 71 25 grass_block
execute in minecraft:overworld run fill 357 72 25 357 144 25 air
execute in minecraft:overworld run fill 357 58 26 357 68 26 stone
execute in minecraft:overworld run fill 357 69 26 357 70 26 dirt
execute in minecraft:overworld run setblock 357 71 26 grass_block
execute in minecraft:overworld run fill 357 72 26 357 144 26 air
execute in minecraft:overworld run fill 357 58 27 357 68 27 stone
execute in minecraft:overworld run fill 357 69 27 357 70 27 dirt
execute in minecraft:overworld run setblock 357 71 27 coarse_dirt
execute in minecraft:overworld run fill 357 72 27 357 144 27 air
execute in minecraft:overworld run fill 357 58 28 357 68 28 stone
execute in minecraft:overworld run fill 357 69 28 357 70 28 dirt
execute in minecraft:overworld run setblock 357 71 28 coarse_dirt
execute in minecraft:overworld run fill 357 72 28 357 144 28 air
execute in minecraft:overworld run fill 357 58 29 357 68 29 stone
execute in minecraft:overworld run fill 357 69 29 357 70 29 dirt
execute in minecraft:overworld run setblock 357 71 29 coarse_dirt
execute in minecraft:overworld run fill 357 72 29 357 144 29 air
execute in minecraft:overworld run setblock 357 72 29 mossy_cobblestone
execute in minecraft:overworld run fill 357 58 30 357 68 30 stone
execute in minecraft:overworld run fill 357 69 30 357 70 30 dirt
execute in minecraft:overworld run setblock 357 71 30 coarse_dirt
execute in minecraft:overworld run fill 357 72 30 357 144 30 air
execute in minecraft:overworld run setblock 357 72 30 grass
execute in minecraft:overworld run fill 357 58 31 357 68 31 stone
execute in minecraft:overworld run fill 357 69 31 357 70 31 dirt
execute in minecraft:overworld run setblock 357 71 31 grass_block
execute in minecraft:overworld run fill 357 72 31 357 144 31 air
execute in minecraft:overworld run fill 357 58 32 357 69 32 stone
execute in minecraft:overworld run fill 357 70 32 357 71 32 dirt
execute in minecraft:overworld run setblock 357 72 32 grass_block
execute in minecraft:overworld run fill 357 73 32 357 144 32 air
execute in minecraft:overworld run fill 357 58 33 357 69 33 stone
execute in minecraft:overworld run fill 357 70 33 357 71 33 dirt
execute in minecraft:overworld run setblock 357 72 33 grass_block
execute in minecraft:overworld run fill 357 73 33 357 144 33 air
execute in minecraft:overworld run setblock 357 73 33 grass
execute in minecraft:overworld run fill 357 58 34 357 69 34 stone
execute in minecraft:overworld run fill 357 70 34 357 71 34 dirt
execute in minecraft:overworld run setblock 357 72 34 coarse_dirt
execute in minecraft:overworld run fill 357 73 34 357 144 34 air
execute in minecraft:overworld run fill 357 58 35 357 69 35 stone
execute in minecraft:overworld run fill 357 70 35 357 71 35 dirt
execute in minecraft:overworld run setblock 357 72 35 grass_block
execute in minecraft:overworld run fill 357 73 35 357 144 35 air
execute in minecraft:overworld run fill 357 58 36 357 69 36 stone
execute in minecraft:overworld run fill 357 70 36 357 71 36 dirt
execute in minecraft:overworld run setblock 357 72 36 coarse_dirt
execute in minecraft:overworld run fill 357 73 36 357 144 36 air
execute in minecraft:overworld run fill 357 58 37 357 69 37 stone
execute in minecraft:overworld run fill 357 70 37 357 71 37 dirt
execute in minecraft:overworld run setblock 357 72 37 grass_block
execute in minecraft:overworld run fill 357 73 37 357 144 37 air
execute in minecraft:overworld run fill 357 58 38 357 69 38 stone
execute in minecraft:overworld run fill 357 70 38 357 71 38 dirt
execute in minecraft:overworld run setblock 357 72 38 coarse_dirt
execute in minecraft:overworld run fill 357 73 38 357 144 38 air
execute in minecraft:overworld run fill 357 58 39 357 68 39 stone
execute in minecraft:overworld run fill 357 69 39 357 70 39 dirt
execute in minecraft:overworld run setblock 357 71 39 coarse_dirt
execute in minecraft:overworld run fill 357 72 39 357 144 39 air
execute in minecraft:overworld run fill 357 58 40 357 67 40 stone
execute in minecraft:overworld run fill 357 68 40 357 69 40 dirt
execute in minecraft:overworld run setblock 357 70 40 coarse_dirt
execute in minecraft:overworld run fill 357 71 40 357 144 40 air
execute in minecraft:overworld run fill 357 58 41 357 66 41 stone
execute in minecraft:overworld run fill 357 67 41 357 68 41 dirt
execute in minecraft:overworld run setblock 357 69 41 grass_block
execute in minecraft:overworld run fill 357 70 41 357 144 41 air
execute in minecraft:overworld run fill 357 58 42 357 65 42 stone
execute in minecraft:overworld run fill 357 66 42 357 67 42 dirt
execute in minecraft:overworld run setblock 357 68 42 coarse_dirt
execute in minecraft:overworld run fill 357 69 42 357 144 42 air
execute in minecraft:overworld run fill 357 58 43 357 65 43 stone
execute in minecraft:overworld run fill 357 66 43 357 67 43 dirt
execute in minecraft:overworld run setblock 357 68 43 coarse_dirt
execute in minecraft:overworld run fill 357 69 43 357 144 43 air
execute in minecraft:overworld run fill 357 58 44 357 64 44 stone
execute in minecraft:overworld run fill 357 65 44 357 66 44 dirt
execute in minecraft:overworld run setblock 357 67 44 coarse_dirt
execute in minecraft:overworld run fill 357 68 44 357 144 44 air
execute in minecraft:overworld run fill 357 58 45 357 63 45 stone
execute in minecraft:overworld run fill 357 64 45 357 65 45 dirt
execute in minecraft:overworld run setblock 357 66 45 coarse_dirt
execute in minecraft:overworld run fill 357 67 45 357 144 45 air
execute in minecraft:overworld run fill 357 58 46 357 62 46 stone
execute in minecraft:overworld run fill 357 63 46 357 64 46 dirt
execute in minecraft:overworld run setblock 357 65 46 coarse_dirt
execute in minecraft:overworld run fill 357 66 46 357 144 46 air
execute in minecraft:overworld run fill 357 58 47 357 62 47 stone
execute in minecraft:overworld run fill 357 63 47 357 64 47 dirt
execute in minecraft:overworld run setblock 357 65 47 coarse_dirt
execute in minecraft:overworld run fill 357 66 47 357 144 47 air
execute in minecraft:overworld run fill 358 58 -48 358 61 -48 stone
execute in minecraft:overworld run fill 358 62 -48 358 63 -48 dirt
execute in minecraft:overworld run setblock 358 64 -48 coarse_dirt
execute in minecraft:overworld run fill 358 65 -48 358 144 -48 air
execute in minecraft:overworld run fill 358 58 -47 358 63 -47 stone
execute in minecraft:overworld run fill 358 64 -47 358 65 -47 dirt
execute in minecraft:overworld run setblock 358 66 -47 coarse_dirt
execute in minecraft:overworld run fill 358 67 -47 358 144 -47 air
execute in minecraft:overworld run fill 358 58 -46 358 65 -46 stone
execute in minecraft:overworld run fill 358 66 -46 358 67 -46 dirt
execute in minecraft:overworld run setblock 358 68 -46 coarse_dirt
execute in minecraft:overworld run fill 358 69 -46 358 144 -46 air
execute in minecraft:overworld run fill 358 58 -45 358 67 -45 stone
execute in minecraft:overworld run fill 358 68 -45 358 69 -45 dirt
execute in minecraft:overworld run setblock 358 70 -45 grass_block
execute in minecraft:overworld run fill 358 71 -45 358 144 -45 air
execute in minecraft:overworld run fill 358 58 -44 358 68 -44 stone
execute in minecraft:overworld run fill 358 69 -44 358 70 -44 dirt
execute in minecraft:overworld run setblock 358 71 -44 coarse_dirt
execute in minecraft:overworld run fill 358 72 -44 358 144 -44 air
execute in minecraft:overworld run fill 358 58 -43 358 70 -43 stone
execute in minecraft:overworld run fill 358 71 -43 358 72 -43 dirt
execute in minecraft:overworld run setblock 358 73 -43 coarse_dirt
execute in minecraft:overworld run fill 358 74 -43 358 144 -43 air
execute in minecraft:overworld run fill 358 58 -42 358 71 -42 stone
execute in minecraft:overworld run fill 358 72 -42 358 73 -42 dirt
execute in minecraft:overworld run setblock 358 74 -42 grass_block
execute in minecraft:overworld run fill 358 75 -42 358 144 -42 air
execute in minecraft:overworld run fill 358 58 -41 358 72 -41 stone
execute in minecraft:overworld run fill 358 73 -41 358 74 -41 dirt
execute in minecraft:overworld run setblock 358 75 -41 coarse_dirt
execute in minecraft:overworld run fill 358 76 -41 358 144 -41 air
execute in minecraft:overworld run fill 358 58 -40 358 74 -40 stone
execute in minecraft:overworld run fill 358 75 -40 358 76 -40 dirt
execute in minecraft:overworld run setblock 358 77 -40 coarse_dirt
execute in minecraft:overworld run fill 358 78 -40 358 144 -40 air
execute in minecraft:overworld run fill 358 58 -39 358 75 -39 stone
execute in minecraft:overworld run fill 358 76 -39 358 77 -39 dirt
execute in minecraft:overworld run setblock 358 78 -39 grass_block
execute in minecraft:overworld run fill 358 79 -39 358 144 -39 air
execute in minecraft:overworld run fill 358 58 -38 358 75 -38 stone
execute in minecraft:overworld run fill 358 76 -38 358 77 -38 dirt
execute in minecraft:overworld run setblock 358 78 -38 coarse_dirt
execute in minecraft:overworld run fill 358 79 -38 358 144 -38 air
execute in minecraft:overworld run fill 358 58 -37 358 75 -37 stone
execute in minecraft:overworld run fill 358 76 -37 358 77 -37 dirt
execute in minecraft:overworld run setblock 358 78 -37 grass_block
execute in minecraft:overworld run fill 358 79 -37 358 144 -37 air
execute in minecraft:overworld run fill 358 58 -36 358 75 -36 stone
execute in minecraft:overworld run fill 358 76 -36 358 77 -36 dirt
execute in minecraft:overworld run setblock 358 78 -36 grass_block
execute in minecraft:overworld run fill 358 79 -36 358 144 -36 air
execute in minecraft:overworld run fill 358 58 -35 358 74 -35 stone
execute in minecraft:overworld run fill 358 75 -35 358 76 -35 dirt
execute in minecraft:overworld run setblock 358 77 -35 coarse_dirt
execute in minecraft:overworld run fill 358 78 -35 358 144 -35 air
execute in minecraft:overworld run fill 358 58 -34 358 74 -34 stone
execute in minecraft:overworld run fill 358 75 -34 358 76 -34 dirt
execute in minecraft:overworld run setblock 358 77 -34 grass_block
execute in minecraft:overworld run fill 358 78 -34 358 144 -34 air
execute in minecraft:overworld run fill 358 58 -33 358 74 -33 stone
execute in minecraft:overworld run fill 358 75 -33 358 76 -33 dirt
execute in minecraft:overworld run setblock 358 77 -33 grass_block
execute in minecraft:overworld run fill 358 78 -33 358 144 -33 air
execute in minecraft:overworld run fill 358 58 -32 358 74 -32 stone
execute in minecraft:overworld run fill 358 75 -32 358 76 -32 dirt
execute in minecraft:overworld run setblock 358 77 -32 coarse_dirt
execute in minecraft:overworld run fill 358 78 -32 358 144 -32 air
execute in minecraft:overworld run fill 358 58 -31 358 74 -31 stone
execute in minecraft:overworld run fill 358 75 -31 358 76 -31 dirt
execute in minecraft:overworld run setblock 358 77 -31 coarse_dirt
execute in minecraft:overworld run fill 358 78 -31 358 144 -31 air
execute in minecraft:overworld run fill 358 58 -30 358 74 -30 stone
execute in minecraft:overworld run fill 358 75 -30 358 76 -30 dirt
execute in minecraft:overworld run setblock 358 77 -30 grass_block
execute in minecraft:overworld run fill 358 78 -30 358 144 -30 air
execute in minecraft:overworld run fill 358 58 -29 358 74 -29 stone
execute in minecraft:overworld run fill 358 75 -29 358 76 -29 dirt
execute in minecraft:overworld run setblock 358 77 -29 coarse_dirt
execute in minecraft:overworld run fill 358 78 -29 358 144 -29 air
execute in minecraft:overworld run fill 358 58 -28 358 73 -28 stone
execute in minecraft:overworld run fill 358 74 -28 358 75 -28 dirt
execute in minecraft:overworld run setblock 358 76 -28 coarse_dirt
execute in minecraft:overworld run fill 358 77 -28 358 144 -28 air
execute in minecraft:overworld run setblock 358 77 -28 grass
execute in minecraft:overworld run fill 358 58 -27 358 73 -27 stone
execute in minecraft:overworld run fill 358 74 -27 358 75 -27 dirt
execute in minecraft:overworld run setblock 358 76 -27 coarse_dirt
execute in minecraft:overworld run fill 358 77 -27 358 144 -27 air
execute in minecraft:overworld run fill 358 58 -26 358 73 -26 stone
execute in minecraft:overworld run fill 358 74 -26 358 75 -26 dirt
execute in minecraft:overworld run setblock 358 76 -26 grass_block
execute in minecraft:overworld run fill 358 77 -26 358 144 -26 air
execute in minecraft:overworld run fill 358 58 -25 358 72 -25 stone
execute in minecraft:overworld run fill 358 73 -25 358 74 -25 dirt
execute in minecraft:overworld run setblock 358 75 -25 grass_block
execute in minecraft:overworld run fill 358 76 -25 358 144 -25 air
execute in minecraft:overworld run fill 358 58 -24 358 72 -24 stone
execute in minecraft:overworld run fill 358 73 -24 358 74 -24 dirt
execute in minecraft:overworld run setblock 358 75 -24 coarse_dirt
execute in minecraft:overworld run fill 358 76 -24 358 144 -24 air
execute in minecraft:overworld run fill 358 58 -23 358 72 -23 stone
execute in minecraft:overworld run fill 358 73 -23 358 74 -23 dirt
execute in minecraft:overworld run setblock 358 75 -23 grass_block
execute in minecraft:overworld run fill 358 76 -23 358 144 -23 air
execute in minecraft:overworld run fill 358 58 -22 358 71 -22 stone
schedule function blade_gallery:random/battlefield/part_34 1t replace
