execute in minecraft:overworld run setblock 364 77 -39 coarse_dirt
execute in minecraft:overworld run fill 364 78 -39 364 144 -39 air
execute in minecraft:overworld run fill 364 58 -38 364 75 -38 stone
execute in minecraft:overworld run fill 364 76 -38 364 77 -38 dirt
execute in minecraft:overworld run setblock 364 78 -38 coarse_dirt
execute in minecraft:overworld run fill 364 79 -38 364 144 -38 air
execute in minecraft:overworld run fill 364 58 -37 364 74 -37 stone
execute in minecraft:overworld run fill 364 75 -37 364 76 -37 dirt
execute in minecraft:overworld run setblock 364 77 -37 grass_block
execute in minecraft:overworld run fill 364 78 -37 364 144 -37 air
execute in minecraft:overworld run fill 364 58 -36 364 74 -36 stone
execute in minecraft:overworld run fill 364 75 -36 364 76 -36 dirt
execute in minecraft:overworld run setblock 364 77 -36 grass_block
execute in minecraft:overworld run fill 364 78 -36 364 144 -36 air
execute in minecraft:overworld run fill 364 58 -35 364 74 -35 stone
execute in minecraft:overworld run fill 364 75 -35 364 76 -35 dirt
execute in minecraft:overworld run setblock 364 77 -35 coarse_dirt
execute in minecraft:overworld run fill 364 78 -35 364 144 -35 air
execute in minecraft:overworld run fill 364 58 -34 364 74 -34 stone
execute in minecraft:overworld run fill 364 75 -34 364 76 -34 dirt
execute in minecraft:overworld run setblock 364 77 -34 coarse_dirt
execute in minecraft:overworld run fill 364 78 -34 364 144 -34 air
execute in minecraft:overworld run fill 364 58 -33 364 74 -33 stone
execute in minecraft:overworld run fill 364 75 -33 364 76 -33 dirt
execute in minecraft:overworld run setblock 364 77 -33 grass_block
execute in minecraft:overworld run fill 364 78 -33 364 144 -33 air
execute in minecraft:overworld run fill 364 58 -32 364 73 -32 stone
execute in minecraft:overworld run fill 364 74 -32 364 75 -32 dirt
execute in minecraft:overworld run setblock 364 76 -32 coarse_dirt
execute in minecraft:overworld run fill 364 77 -32 364 144 -32 air
execute in minecraft:overworld run fill 364 58 -31 364 73 -31 stone
execute in minecraft:overworld run fill 364 74 -31 364 75 -31 dirt
execute in minecraft:overworld run setblock 364 76 -31 coarse_dirt
execute in minecraft:overworld run fill 364 77 -31 364 144 -31 air
execute in minecraft:overworld run fill 364 58 -30 364 73 -30 stone
execute in minecraft:overworld run fill 364 74 -30 364 75 -30 dirt
execute in minecraft:overworld run setblock 364 76 -30 grass_block
execute in minecraft:overworld run fill 364 77 -30 364 144 -30 air
execute in minecraft:overworld run fill 364 58 -29 364 73 -29 stone
execute in minecraft:overworld run fill 364 74 -29 364 75 -29 dirt
execute in minecraft:overworld run setblock 364 76 -29 coarse_dirt
execute in minecraft:overworld run fill 364 77 -29 364 144 -29 air
execute in minecraft:overworld run fill 364 58 -28 364 73 -28 stone
execute in minecraft:overworld run fill 364 74 -28 364 75 -28 dirt
execute in minecraft:overworld run setblock 364 76 -28 grass_block
execute in minecraft:overworld run fill 364 77 -28 364 144 -28 air
execute in minecraft:overworld run fill 364 58 -27 364 72 -27 stone
execute in minecraft:overworld run fill 364 73 -27 364 74 -27 dirt
execute in minecraft:overworld run setblock 364 75 -27 coarse_dirt
execute in minecraft:overworld run fill 364 76 -27 364 144 -27 air
execute in minecraft:overworld run fill 364 58 -26 364 72 -26 stone
execute in minecraft:overworld run fill 364 73 -26 364 74 -26 dirt
execute in minecraft:overworld run setblock 364 75 -26 grass_block
execute in minecraft:overworld run fill 364 76 -26 364 144 -26 air
execute in minecraft:overworld run fill 364 58 -25 364 72 -25 stone
execute in minecraft:overworld run fill 364 73 -25 364 74 -25 dirt
execute in minecraft:overworld run setblock 364 75 -25 coarse_dirt
execute in minecraft:overworld run fill 364 76 -25 364 144 -25 air
execute in minecraft:overworld run fill 364 58 -24 364 71 -24 stone
execute in minecraft:overworld run fill 364 72 -24 364 73 -24 dirt
execute in minecraft:overworld run setblock 364 74 -24 grass_block
execute in minecraft:overworld run fill 364 75 -24 364 144 -24 air
execute in minecraft:overworld run fill 364 58 -23 364 71 -23 stone
execute in minecraft:overworld run fill 364 72 -23 364 73 -23 dirt
execute in minecraft:overworld run setblock 364 74 -23 grass_block
execute in minecraft:overworld run fill 364 75 -23 364 144 -23 air
execute in minecraft:overworld run fill 364 58 -22 364 71 -22 stone
execute in minecraft:overworld run fill 364 72 -22 364 73 -22 dirt
execute in minecraft:overworld run setblock 364 74 -22 grass_block
execute in minecraft:overworld run fill 364 75 -22 364 144 -22 air
execute in minecraft:overworld run fill 364 58 -21 364 70 -21 stone
execute in minecraft:overworld run fill 364 71 -21 364 72 -21 dirt
execute in minecraft:overworld run setblock 364 73 -21 grass_block
execute in minecraft:overworld run fill 364 74 -21 364 144 -21 air
execute in minecraft:overworld run fill 364 58 -20 364 70 -20 stone
execute in minecraft:overworld run fill 364 71 -20 364 72 -20 dirt
execute in minecraft:overworld run setblock 364 73 -20 coarse_dirt
execute in minecraft:overworld run fill 364 74 -20 364 144 -20 air
execute in minecraft:overworld run fill 364 58 -19 364 70 -19 stone
execute in minecraft:overworld run fill 364 71 -19 364 72 -19 dirt
execute in minecraft:overworld run setblock 364 73 -19 grass_block
execute in minecraft:overworld run fill 364 74 -19 364 144 -19 air
execute in minecraft:overworld run fill 364 58 -18 364 69 -18 stone
execute in minecraft:overworld run fill 364 70 -18 364 71 -18 dirt
execute in minecraft:overworld run setblock 364 72 -18 coarse_dirt
execute in minecraft:overworld run fill 364 73 -18 364 144 -18 air
execute in minecraft:overworld run setblock 364 73 -18 grass
execute in minecraft:overworld run fill 364 58 -17 364 69 -17 stone
execute in minecraft:overworld run fill 364 70 -17 364 71 -17 dirt
execute in minecraft:overworld run setblock 364 72 -17 grass_block
execute in minecraft:overworld run fill 364 73 -17 364 144 -17 air
execute in minecraft:overworld run fill 364 58 -16 364 68 -16 stone
execute in minecraft:overworld run fill 364 69 -16 364 70 -16 dirt
execute in minecraft:overworld run setblock 364 71 -16 coarse_dirt
execute in minecraft:overworld run fill 364 72 -16 364 144 -16 air
execute in minecraft:overworld run fill 364 58 -15 364 68 -15 stone
execute in minecraft:overworld run fill 364 69 -15 364 70 -15 dirt
execute in minecraft:overworld run setblock 364 71 -15 coarse_dirt
execute in minecraft:overworld run fill 364 72 -15 364 144 -15 air
execute in minecraft:overworld run fill 364 58 -14 364 67 -14 stone
execute in minecraft:overworld run fill 364 68 -14 364 69 -14 dirt
execute in minecraft:overworld run setblock 364 70 -14 coarse_dirt
execute in minecraft:overworld run fill 364 71 -14 364 144 -14 air
execute in minecraft:overworld run fill 364 58 -13 364 66 -13 stone
execute in minecraft:overworld run fill 364 67 -13 364 68 -13 dirt
execute in minecraft:overworld run setblock 364 69 -13 coarse_dirt
execute in minecraft:overworld run fill 364 70 -13 364 144 -13 air
execute in minecraft:overworld run fill 364 58 -12 364 66 -12 stone
execute in minecraft:overworld run fill 364 67 -12 364 68 -12 dirt
execute in minecraft:overworld run setblock 364 69 -12 grass_block
execute in minecraft:overworld run fill 364 70 -12 364 144 -12 air
execute in minecraft:overworld run fill 364 58 -11 364 66 -11 stone
execute in minecraft:overworld run fill 364 67 -11 364 68 -11 dirt
execute in minecraft:overworld run setblock 364 69 -11 grass_block
execute in minecraft:overworld run fill 364 70 -11 364 144 -11 air
execute in minecraft:overworld run fill 364 58 -10 364 65 -10 stone
execute in minecraft:overworld run fill 364 66 -10 364 67 -10 dirt
execute in minecraft:overworld run setblock 364 68 -10 coarse_dirt
execute in minecraft:overworld run fill 364 69 -10 364 144 -10 air
execute in minecraft:overworld run fill 364 58 -9 364 65 -9 stone
execute in minecraft:overworld run fill 364 66 -9 364 67 -9 dirt
execute in minecraft:overworld run setblock 364 68 -9 grass_block
execute in minecraft:overworld run fill 364 69 -9 364 144 -9 air
execute in minecraft:overworld run fill 364 58 -8 364 65 -8 stone
execute in minecraft:overworld run fill 364 66 -8 364 67 -8 dirt
execute in minecraft:overworld run setblock 364 68 -8 coarse_dirt
execute in minecraft:overworld run fill 364 69 -8 364 144 -8 air
execute in minecraft:overworld run fill 364 58 -7 364 65 -7 stone
execute in minecraft:overworld run fill 364 66 -7 364 67 -7 dirt
execute in minecraft:overworld run setblock 364 68 -7 grass_block
execute in minecraft:overworld run fill 364 69 -7 364 144 -7 air
execute in minecraft:overworld run fill 364 58 -6 364 65 -6 stone
execute in minecraft:overworld run fill 364 66 -6 364 67 -6 dirt
execute in minecraft:overworld run setblock 364 68 -6 coarse_dirt
execute in minecraft:overworld run fill 364 69 -6 364 144 -6 air
execute in minecraft:overworld run fill 364 58 -5 364 65 -5 stone
execute in minecraft:overworld run fill 364 66 -5 364 67 -5 dirt
execute in minecraft:overworld run setblock 364 68 -5 grass_block
execute in minecraft:overworld run fill 364 69 -5 364 144 -5 air
execute in minecraft:overworld run fill 364 58 -4 364 65 -4 stone
execute in minecraft:overworld run fill 364 66 -4 364 67 -4 dirt
execute in minecraft:overworld run setblock 364 68 -4 grass_block
execute in minecraft:overworld run fill 364 69 -4 364 144 -4 air
execute in minecraft:overworld run setblock 364 69 -4 grass
execute in minecraft:overworld run fill 364 58 -3 364 65 -3 stone
execute in minecraft:overworld run fill 364 66 -3 364 67 -3 dirt
execute in minecraft:overworld run setblock 364 68 -3 grass_block
execute in minecraft:overworld run fill 364 69 -3 364 144 -3 air
execute in minecraft:overworld run fill 364 58 -2 364 65 -2 stone
execute in minecraft:overworld run fill 364 66 -2 364 67 -2 dirt
execute in minecraft:overworld run setblock 364 68 -2 coarse_dirt
execute in minecraft:overworld run fill 364 69 -2 364 144 -2 air
execute in minecraft:overworld run fill 364 58 -1 364 65 -1 stone
execute in minecraft:overworld run fill 364 66 -1 364 67 -1 dirt
execute in minecraft:overworld run setblock 364 68 -1 coarse_dirt
execute in minecraft:overworld run fill 364 69 -1 364 144 -1 air
execute in minecraft:overworld run fill 364 58 0 364 65 0 stone
execute in minecraft:overworld run fill 364 66 0 364 67 0 dirt
execute in minecraft:overworld run setblock 364 68 0 coarse_dirt
execute in minecraft:overworld run fill 364 69 0 364 144 0 air
execute in minecraft:overworld run fill 364 58 1 364 65 1 stone
execute in minecraft:overworld run fill 364 66 1 364 67 1 dirt
execute in minecraft:overworld run setblock 364 68 1 grass_block
execute in minecraft:overworld run fill 364 69 1 364 144 1 air
execute in minecraft:overworld run fill 364 58 2 364 65 2 stone
execute in minecraft:overworld run fill 364 66 2 364 67 2 dirt
execute in minecraft:overworld run setblock 364 68 2 coarse_dirt
execute in minecraft:overworld run fill 364 69 2 364 144 2 air
execute in minecraft:overworld run fill 364 58 3 364 66 3 stone
execute in minecraft:overworld run fill 364 67 3 364 68 3 dirt
execute in minecraft:overworld run setblock 364 69 3 coarse_dirt
execute in minecraft:overworld run fill 364 70 3 364 144 3 air
execute in minecraft:overworld run fill 364 58 4 364 66 4 stone
execute in minecraft:overworld run fill 364 67 4 364 68 4 dirt
execute in minecraft:overworld run setblock 364 69 4 grass_block
execute in minecraft:overworld run fill 364 70 4 364 144 4 air
execute in minecraft:overworld run fill 364 58 5 364 66 5 stone
execute in minecraft:overworld run fill 364 67 5 364 68 5 dirt
execute in minecraft:overworld run setblock 364 69 5 coarse_dirt
execute in minecraft:overworld run fill 364 70 5 364 144 5 air
execute in minecraft:overworld run fill 364 58 6 364 66 6 stone
execute in minecraft:overworld run fill 364 67 6 364 68 6 dirt
execute in minecraft:overworld run setblock 364 69 6 coarse_dirt
execute in minecraft:overworld run fill 364 70 6 364 144 6 air
execute in minecraft:overworld run fill 364 58 7 364 67 7 stone
execute in minecraft:overworld run fill 364 68 7 364 69 7 dirt
execute in minecraft:overworld run setblock 364 70 7 coarse_dirt
execute in minecraft:overworld run fill 364 71 7 364 144 7 air
execute in minecraft:overworld run fill 364 58 8 364 67 8 stone
execute in minecraft:overworld run fill 364 68 8 364 69 8 dirt
execute in minecraft:overworld run setblock 364 70 8 coarse_dirt
execute in minecraft:overworld run fill 364 71 8 364 144 8 air
execute in minecraft:overworld run fill 364 58 9 364 67 9 stone
execute in minecraft:overworld run fill 364 68 9 364 69 9 dirt
execute in minecraft:overworld run setblock 364 70 9 coarse_dirt
execute in minecraft:overworld run fill 364 71 9 364 144 9 air
execute in minecraft:overworld run fill 364 58 10 364 67 10 stone
execute in minecraft:overworld run fill 364 68 10 364 69 10 dirt
execute in minecraft:overworld run setblock 364 70 10 coarse_dirt
execute in minecraft:overworld run fill 364 71 10 364 144 10 air
execute in minecraft:overworld run fill 364 58 11 364 67 11 stone
execute in minecraft:overworld run fill 364 68 11 364 69 11 dirt
execute in minecraft:overworld run setblock 364 70 11 grass_block
execute in minecraft:overworld run fill 364 71 11 364 144 11 air
execute in minecraft:overworld run fill 364 58 12 364 68 12 stone
execute in minecraft:overworld run fill 364 69 12 364 70 12 dirt
execute in minecraft:overworld run setblock 364 71 12 coarse_dirt
execute in minecraft:overworld run fill 364 72 12 364 144 12 air
execute in minecraft:overworld run fill 364 58 13 364 68 13 stone
execute in minecraft:overworld run fill 364 69 13 364 70 13 dirt
execute in minecraft:overworld run setblock 364 71 13 grass_block
execute in minecraft:overworld run fill 364 72 13 364 144 13 air
execute in minecraft:overworld run fill 364 58 14 364 68 14 stone
execute in minecraft:overworld run fill 364 69 14 364 70 14 dirt
execute in minecraft:overworld run setblock 364 71 14 coarse_dirt
execute in minecraft:overworld run fill 364 72 14 364 144 14 air
execute in minecraft:overworld run fill 364 58 15 364 68 15 stone
execute in minecraft:overworld run fill 364 69 15 364 70 15 dirt
execute in minecraft:overworld run setblock 364 71 15 coarse_dirt
execute in minecraft:overworld run fill 364 72 15 364 144 15 air
execute in minecraft:overworld run fill 364 58 16 364 68 16 stone
execute in minecraft:overworld run fill 364 69 16 364 70 16 dirt
execute in minecraft:overworld run setblock 364 71 16 grass_block
execute in minecraft:overworld run fill 364 72 16 364 144 16 air
execute in minecraft:overworld run fill 364 58 17 364 69 17 stone
execute in minecraft:overworld run fill 364 70 17 364 71 17 dirt
execute in minecraft:overworld run setblock 364 72 17 coarse_dirt
execute in minecraft:overworld run fill 364 73 17 364 144 17 air
execute in minecraft:overworld run setblock 364 73 17 grass
execute in minecraft:overworld run fill 364 58 18 364 69 18 stone
execute in minecraft:overworld run fill 364 70 18 364 71 18 dirt
execute in minecraft:overworld run setblock 364 72 18 coarse_dirt
execute in minecraft:overworld run fill 364 73 18 364 144 18 air
execute in minecraft:overworld run setblock 364 73 18 grass
execute in minecraft:overworld run fill 364 58 19 364 69 19 stone
execute in minecraft:overworld run fill 364 70 19 364 71 19 dirt
execute in minecraft:overworld run setblock 364 72 19 coarse_dirt
execute in minecraft:overworld run fill 364 73 19 364 144 19 air
execute in minecraft:overworld run fill 364 58 20 364 69 20 stone
execute in minecraft:overworld run fill 364 70 20 364 71 20 dirt
execute in minecraft:overworld run setblock 364 72 20 grass_block
execute in minecraft:overworld run fill 364 73 20 364 144 20 air
execute in minecraft:overworld run fill 364 58 21 364 69 21 stone
execute in minecraft:overworld run fill 364 70 21 364 71 21 dirt
execute in minecraft:overworld run setblock 364 72 21 grass_block
execute in minecraft:overworld run fill 364 73 21 364 144 21 air
execute in minecraft:overworld run fill 364 58 22 364 69 22 stone
execute in minecraft:overworld run fill 364 70 22 364 71 22 dirt
execute in minecraft:overworld run setblock 364 72 22 coarse_dirt
execute in minecraft:overworld run fill 364 73 22 364 144 22 air
execute in minecraft:overworld run fill 364 58 23 364 69 23 stone
execute in minecraft:overworld run fill 364 70 23 364 71 23 dirt
execute in minecraft:overworld run setblock 364 72 23 coarse_dirt
execute in minecraft:overworld run fill 364 73 23 364 144 23 air
execute in minecraft:overworld run fill 364 58 24 364 69 24 stone
execute in minecraft:overworld run fill 364 70 24 364 71 24 dirt
schedule function blade_gallery:random/battlefield/part_44 1t replace
