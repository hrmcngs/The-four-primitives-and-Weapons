execute in minecraft:overworld run setblock 406 66 -9 grass_block
execute in minecraft:overworld run fill 406 67 -9 406 144 -9 air
execute in minecraft:overworld run fill 406 58 -8 406 63 -8 stone
execute in minecraft:overworld run fill 406 64 -8 406 65 -8 dirt
execute in minecraft:overworld run setblock 406 66 -8 grass_block
execute in minecraft:overworld run fill 406 67 -8 406 144 -8 air
execute in minecraft:overworld run fill 406 58 -7 406 62 -7 stone
execute in minecraft:overworld run fill 406 63 -7 406 64 -7 dirt
execute in minecraft:overworld run setblock 406 65 -7 coarse_dirt
execute in minecraft:overworld run fill 406 66 -7 406 144 -7 air
execute in minecraft:overworld run fill 406 58 -6 406 62 -6 stone
execute in minecraft:overworld run fill 406 63 -6 406 64 -6 dirt
execute in minecraft:overworld run setblock 406 65 -6 grass_block
execute in minecraft:overworld run fill 406 66 -6 406 144 -6 air
execute in minecraft:overworld run fill 406 58 -5 406 62 -5 stone
execute in minecraft:overworld run fill 406 63 -5 406 64 -5 dirt
execute in minecraft:overworld run setblock 406 65 -5 coarse_dirt
execute in minecraft:overworld run fill 406 66 -5 406 144 -5 air
execute in minecraft:overworld run fill 406 58 -4 406 62 -4 stone
execute in minecraft:overworld run fill 406 63 -4 406 64 -4 dirt
execute in minecraft:overworld run setblock 406 65 -4 grass_block
execute in minecraft:overworld run fill 406 66 -4 406 144 -4 air
execute in minecraft:overworld run fill 406 58 -3 406 62 -3 stone
execute in minecraft:overworld run fill 406 63 -3 406 64 -3 dirt
execute in minecraft:overworld run setblock 406 65 -3 grass_block
execute in minecraft:overworld run fill 406 66 -3 406 144 -3 air
execute in minecraft:overworld run fill 406 58 -2 406 62 -2 stone
execute in minecraft:overworld run fill 406 63 -2 406 64 -2 dirt
execute in minecraft:overworld run setblock 406 65 -2 coarse_dirt
execute in minecraft:overworld run fill 406 66 -2 406 144 -2 air
execute in minecraft:overworld run fill 406 58 -1 406 62 -1 stone
execute in minecraft:overworld run fill 406 63 -1 406 64 -1 dirt
execute in minecraft:overworld run setblock 406 65 -1 coarse_dirt
execute in minecraft:overworld run fill 406 66 -1 406 144 -1 air
execute in minecraft:overworld run fill 406 58 0 406 62 0 stone
execute in minecraft:overworld run fill 406 63 0 406 64 0 dirt
execute in minecraft:overworld run setblock 406 65 0 grass_block
execute in minecraft:overworld run fill 406 66 0 406 144 0 air
execute in minecraft:overworld run fill 406 58 1 406 61 1 stone
execute in minecraft:overworld run fill 406 62 1 406 63 1 dirt
execute in minecraft:overworld run setblock 406 64 1 coarse_dirt
execute in minecraft:overworld run fill 406 65 1 406 144 1 air
execute in minecraft:overworld run fill 406 58 2 406 61 2 stone
execute in minecraft:overworld run fill 406 62 2 406 63 2 dirt
execute in minecraft:overworld run setblock 406 64 2 grass_block
execute in minecraft:overworld run fill 406 65 2 406 144 2 air
execute in minecraft:overworld run fill 406 58 3 406 61 3 stone
execute in minecraft:overworld run fill 406 62 3 406 63 3 dirt
execute in minecraft:overworld run setblock 406 64 3 grass_block
execute in minecraft:overworld run fill 406 65 3 406 144 3 air
execute in minecraft:overworld run fill 406 58 4 406 61 4 stone
execute in minecraft:overworld run fill 406 62 4 406 63 4 dirt
execute in minecraft:overworld run setblock 406 64 4 coarse_dirt
execute in minecraft:overworld run fill 406 65 4 406 144 4 air
execute in minecraft:overworld run fill 406 58 5 406 62 5 stone
execute in minecraft:overworld run fill 406 63 5 406 64 5 dirt
execute in minecraft:overworld run setblock 406 65 5 grass_block
execute in minecraft:overworld run fill 406 66 5 406 144 5 air
execute in minecraft:overworld run fill 406 58 6 406 62 6 stone
execute in minecraft:overworld run fill 406 63 6 406 64 6 dirt
execute in minecraft:overworld run setblock 406 65 6 coarse_dirt
execute in minecraft:overworld run fill 406 66 6 406 144 6 air
execute in minecraft:overworld run fill 406 58 7 406 62 7 stone
execute in minecraft:overworld run fill 406 63 7 406 64 7 dirt
execute in minecraft:overworld run setblock 406 65 7 coarse_dirt
execute in minecraft:overworld run fill 406 66 7 406 144 7 air
execute in minecraft:overworld run fill 406 58 8 406 62 8 stone
execute in minecraft:overworld run fill 406 63 8 406 64 8 dirt
execute in minecraft:overworld run setblock 406 65 8 coarse_dirt
execute in minecraft:overworld run fill 406 66 8 406 144 8 air
execute in minecraft:overworld run fill 406 58 9 406 62 9 stone
execute in minecraft:overworld run fill 406 63 9 406 64 9 dirt
execute in minecraft:overworld run setblock 406 65 9 grass_block
execute in minecraft:overworld run fill 406 66 9 406 144 9 air
execute in minecraft:overworld run fill 406 58 10 406 62 10 stone
execute in minecraft:overworld run fill 406 63 10 406 64 10 dirt
execute in minecraft:overworld run setblock 406 65 10 coarse_dirt
execute in minecraft:overworld run fill 406 66 10 406 144 10 air
execute in minecraft:overworld run fill 406 58 11 406 63 11 stone
execute in minecraft:overworld run fill 406 64 11 406 65 11 dirt
execute in minecraft:overworld run setblock 406 66 11 grass_block
execute in minecraft:overworld run fill 406 67 11 406 144 11 air
execute in minecraft:overworld run fill 406 58 12 406 63 12 stone
execute in minecraft:overworld run fill 406 64 12 406 65 12 dirt
execute in minecraft:overworld run setblock 406 66 12 grass_block
execute in minecraft:overworld run fill 406 67 12 406 144 12 air
execute in minecraft:overworld run fill 406 58 13 406 63 13 stone
execute in minecraft:overworld run fill 406 64 13 406 65 13 dirt
execute in minecraft:overworld run setblock 406 66 13 coarse_dirt
execute in minecraft:overworld run fill 406 67 13 406 144 13 air
execute in minecraft:overworld run setblock 406 67 13 grass
execute in minecraft:overworld run fill 406 58 14 406 63 14 stone
execute in minecraft:overworld run fill 406 64 14 406 65 14 dirt
execute in minecraft:overworld run setblock 406 66 14 grass_block
execute in minecraft:overworld run fill 406 67 14 406 144 14 air
execute in minecraft:overworld run fill 406 58 15 406 64 15 stone
execute in minecraft:overworld run fill 406 65 15 406 66 15 dirt
execute in minecraft:overworld run setblock 406 67 15 grass_block
execute in minecraft:overworld run fill 406 68 15 406 144 15 air
execute in minecraft:overworld run fill 406 58 16 406 64 16 stone
execute in minecraft:overworld run fill 406 65 16 406 66 16 dirt
execute in minecraft:overworld run setblock 406 67 16 coarse_dirt
execute in minecraft:overworld run fill 406 68 16 406 144 16 air
execute in minecraft:overworld run fill 406 58 17 406 64 17 stone
execute in minecraft:overworld run fill 406 65 17 406 66 17 dirt
execute in minecraft:overworld run setblock 406 67 17 grass_block
execute in minecraft:overworld run fill 406 68 17 406 144 17 air
execute in minecraft:overworld run fill 406 58 18 406 65 18 stone
execute in minecraft:overworld run fill 406 66 18 406 67 18 dirt
execute in minecraft:overworld run setblock 406 68 18 grass_block
execute in minecraft:overworld run fill 406 69 18 406 144 18 air
execute in minecraft:overworld run fill 406 58 19 406 65 19 stone
execute in minecraft:overworld run fill 406 66 19 406 67 19 dirt
execute in minecraft:overworld run setblock 406 68 19 grass_block
execute in minecraft:overworld run fill 406 69 19 406 144 19 air
execute in minecraft:overworld run fill 406 58 20 406 65 20 stone
execute in minecraft:overworld run fill 406 66 20 406 67 20 dirt
execute in minecraft:overworld run setblock 406 68 20 coarse_dirt
execute in minecraft:overworld run fill 406 69 20 406 144 20 air
execute in minecraft:overworld run fill 406 58 21 406 66 21 stone
execute in minecraft:overworld run fill 406 67 21 406 68 21 dirt
execute in minecraft:overworld run setblock 406 69 21 grass_block
execute in minecraft:overworld run fill 406 70 21 406 144 21 air
execute in minecraft:overworld run fill 406 58 22 406 66 22 stone
execute in minecraft:overworld run fill 406 67 22 406 68 22 dirt
execute in minecraft:overworld run setblock 406 69 22 coarse_dirt
execute in minecraft:overworld run fill 406 70 22 406 144 22 air
execute in minecraft:overworld run fill 406 58 23 406 67 23 stone
execute in minecraft:overworld run fill 406 68 23 406 69 23 dirt
execute in minecraft:overworld run setblock 406 70 23 grass_block
execute in minecraft:overworld run fill 406 71 23 406 144 23 air
execute in minecraft:overworld run fill 406 58 24 406 67 24 stone
execute in minecraft:overworld run fill 406 68 24 406 69 24 dirt
execute in minecraft:overworld run setblock 406 70 24 grass_block
execute in minecraft:overworld run fill 406 71 24 406 144 24 air
execute in minecraft:overworld run fill 406 58 25 406 67 25 stone
execute in minecraft:overworld run fill 406 68 25 406 69 25 dirt
execute in minecraft:overworld run setblock 406 70 25 grass_block
execute in minecraft:overworld run fill 406 71 25 406 144 25 air
execute in minecraft:overworld run fill 406 58 26 406 68 26 stone
execute in minecraft:overworld run fill 406 69 26 406 70 26 dirt
execute in minecraft:overworld run setblock 406 71 26 grass_block
execute in minecraft:overworld run fill 406 72 26 406 144 26 air
execute in minecraft:overworld run fill 406 58 27 406 68 27 stone
execute in minecraft:overworld run fill 406 69 27 406 70 27 dirt
execute in minecraft:overworld run setblock 406 71 27 grass_block
execute in minecraft:overworld run fill 406 72 27 406 144 27 air
execute in minecraft:overworld run fill 406 58 28 406 68 28 stone
execute in minecraft:overworld run fill 406 69 28 406 70 28 dirt
execute in minecraft:overworld run setblock 406 71 28 coarse_dirt
execute in minecraft:overworld run fill 406 72 28 406 144 28 air
execute in minecraft:overworld run fill 406 58 29 406 68 29 stone
execute in minecraft:overworld run fill 406 69 29 406 70 29 dirt
execute in minecraft:overworld run setblock 406 71 29 coarse_dirt
execute in minecraft:overworld run fill 406 72 29 406 144 29 air
execute in minecraft:overworld run fill 406 58 30 406 68 30 stone
execute in minecraft:overworld run fill 406 69 30 406 70 30 dirt
execute in minecraft:overworld run setblock 406 71 30 coarse_dirt
execute in minecraft:overworld run fill 406 72 30 406 144 30 air
execute in minecraft:overworld run fill 406 58 31 406 67 31 stone
execute in minecraft:overworld run fill 406 68 31 406 69 31 dirt
execute in minecraft:overworld run setblock 406 70 31 grass_block
execute in minecraft:overworld run fill 406 71 31 406 144 31 air
execute in minecraft:overworld run fill 406 58 32 406 67 32 stone
execute in minecraft:overworld run fill 406 68 32 406 69 32 dirt
execute in minecraft:overworld run setblock 406 70 32 coarse_dirt
execute in minecraft:overworld run fill 406 71 32 406 144 32 air
execute in minecraft:overworld run fill 406 58 33 406 67 33 stone
execute in minecraft:overworld run fill 406 68 33 406 69 33 dirt
execute in minecraft:overworld run setblock 406 70 33 grass_block
execute in minecraft:overworld run fill 406 71 33 406 144 33 air
execute in minecraft:overworld run fill 406 58 34 406 67 34 stone
execute in minecraft:overworld run fill 406 68 34 406 69 34 dirt
execute in minecraft:overworld run setblock 406 70 34 coarse_dirt
execute in minecraft:overworld run fill 406 71 34 406 144 34 air
execute in minecraft:overworld run fill 406 58 35 406 66 35 stone
execute in minecraft:overworld run fill 406 67 35 406 68 35 dirt
execute in minecraft:overworld run setblock 406 69 35 grass_block
execute in minecraft:overworld run fill 406 70 35 406 144 35 air
execute in minecraft:overworld run fill 406 58 36 406 66 36 stone
execute in minecraft:overworld run fill 406 67 36 406 68 36 dirt
execute in minecraft:overworld run setblock 406 69 36 coarse_dirt
execute in minecraft:overworld run fill 406 70 36 406 144 36 air
execute in minecraft:overworld run setblock 406 70 36 mossy_cobblestone
execute in minecraft:overworld run fill 406 58 37 406 66 37 stone
execute in minecraft:overworld run fill 406 67 37 406 68 37 dirt
execute in minecraft:overworld run setblock 406 69 37 coarse_dirt
execute in minecraft:overworld run fill 406 70 37 406 144 37 air
execute in minecraft:overworld run setblock 406 70 37 mossy_cobblestone
execute in minecraft:overworld run fill 406 58 38 406 66 38 stone
execute in minecraft:overworld run fill 406 67 38 406 68 38 dirt
execute in minecraft:overworld run setblock 406 69 38 coarse_dirt
execute in minecraft:overworld run fill 406 70 38 406 144 38 air
execute in minecraft:overworld run fill 406 58 39 406 66 39 stone
execute in minecraft:overworld run fill 406 67 39 406 68 39 dirt
execute in minecraft:overworld run setblock 406 69 39 coarse_dirt
execute in minecraft:overworld run fill 406 70 39 406 144 39 air
execute in minecraft:overworld run fill 406 58 40 406 66 40 stone
execute in minecraft:overworld run fill 406 67 40 406 68 40 dirt
execute in minecraft:overworld run setblock 406 69 40 coarse_dirt
execute in minecraft:overworld run fill 406 70 40 406 144 40 air
execute in minecraft:overworld run fill 406 58 41 406 65 41 stone
execute in minecraft:overworld run fill 406 66 41 406 67 41 dirt
execute in minecraft:overworld run setblock 406 68 41 coarse_dirt
execute in minecraft:overworld run fill 406 69 41 406 144 41 air
execute in minecraft:overworld run fill 406 58 42 406 65 42 stone
execute in minecraft:overworld run fill 406 66 42 406 67 42 dirt
execute in minecraft:overworld run setblock 406 68 42 coarse_dirt
execute in minecraft:overworld run fill 406 69 42 406 144 42 air
execute in minecraft:overworld run fill 406 58 43 406 64 43 stone
execute in minecraft:overworld run fill 406 65 43 406 66 43 dirt
execute in minecraft:overworld run setblock 406 67 43 coarse_dirt
execute in minecraft:overworld run fill 406 68 43 406 144 43 air
execute in minecraft:overworld run fill 406 58 44 406 63 44 stone
execute in minecraft:overworld run fill 406 64 44 406 65 44 dirt
execute in minecraft:overworld run setblock 406 66 44 coarse_dirt
execute in minecraft:overworld run fill 406 67 44 406 144 44 air
execute in minecraft:overworld run fill 406 58 45 406 63 45 stone
execute in minecraft:overworld run fill 406 64 45 406 65 45 dirt
execute in minecraft:overworld run setblock 406 66 45 coarse_dirt
execute in minecraft:overworld run fill 406 67 45 406 144 45 air
execute in minecraft:overworld run fill 406 58 46 406 62 46 stone
execute in minecraft:overworld run fill 406 63 46 406 64 46 dirt
execute in minecraft:overworld run setblock 406 65 46 coarse_dirt
execute in minecraft:overworld run fill 406 66 46 406 144 46 air
execute in minecraft:overworld run fill 406 58 47 406 62 47 stone
execute in minecraft:overworld run fill 406 63 47 406 64 47 dirt
execute in minecraft:overworld run setblock 406 65 47 coarse_dirt
execute in minecraft:overworld run fill 406 66 47 406 144 47 air
execute in minecraft:overworld run fill 407 58 -48 407 61 -48 stone
execute in minecraft:overworld run fill 407 62 -48 407 63 -48 dirt
execute in minecraft:overworld run setblock 407 64 -48 coarse_dirt
execute in minecraft:overworld run fill 407 65 -48 407 144 -48 air
execute in minecraft:overworld run fill 407 58 -47 407 63 -47 stone
execute in minecraft:overworld run fill 407 64 -47 407 65 -47 dirt
execute in minecraft:overworld run setblock 407 66 -47 coarse_dirt
execute in minecraft:overworld run fill 407 67 -47 407 144 -47 air
execute in minecraft:overworld run fill 407 58 -46 407 64 -46 stone
execute in minecraft:overworld run fill 407 65 -46 407 66 -46 dirt
execute in minecraft:overworld run setblock 407 67 -46 coarse_dirt
execute in minecraft:overworld run fill 407 68 -46 407 144 -46 air
execute in minecraft:overworld run fill 407 58 -45 407 66 -45 stone
execute in minecraft:overworld run fill 407 67 -45 407 68 -45 dirt
execute in minecraft:overworld run setblock 407 69 -45 coarse_dirt
execute in minecraft:overworld run fill 407 70 -45 407 144 -45 air
execute in minecraft:overworld run fill 407 58 -44 407 67 -44 stone
execute in minecraft:overworld run fill 407 68 -44 407 69 -44 dirt
execute in minecraft:overworld run setblock 407 70 -44 coarse_dirt
execute in minecraft:overworld run fill 407 71 -44 407 144 -44 air
execute in minecraft:overworld run fill 407 58 -43 407 69 -43 stone
execute in minecraft:overworld run fill 407 70 -43 407 71 -43 dirt
execute in minecraft:overworld run setblock 407 72 -43 coarse_dirt
execute in minecraft:overworld run fill 407 73 -43 407 144 -43 air
execute in minecraft:overworld run fill 407 58 -42 407 70 -42 stone
execute in minecraft:overworld run fill 407 71 -42 407 72 -42 dirt
execute in minecraft:overworld run setblock 407 73 -42 coarse_dirt
schedule function blade_gallery:random/battlefield/part_112 1t replace
