execute in minecraft:overworld run fill 269 73 -22 269 74 -22 dirt
execute in minecraft:overworld run setblock 269 75 -22 coarse_dirt
execute in minecraft:overworld run fill 269 76 -22 269 144 -22 air
execute in minecraft:overworld run fill 269 58 -21 269 71 -21 stone
execute in minecraft:overworld run fill 269 72 -21 269 73 -21 dirt
execute in minecraft:overworld run setblock 269 74 -21 coarse_dirt
execute in minecraft:overworld run fill 269 75 -21 269 144 -21 air
execute in minecraft:overworld run setblock 269 75 -21 grass
execute in minecraft:overworld run fill 269 58 -20 269 70 -20 stone
execute in minecraft:overworld run fill 269 71 -20 269 72 -20 dirt
execute in minecraft:overworld run setblock 269 73 -20 coarse_dirt
execute in minecraft:overworld run fill 269 74 -20 269 144 -20 air
execute in minecraft:overworld run fill 269 58 -19 269 70 -19 stone
execute in minecraft:overworld run fill 269 71 -19 269 72 -19 dirt
execute in minecraft:overworld run setblock 269 73 -19 coarse_dirt
execute in minecraft:overworld run fill 269 74 -19 269 144 -19 air
execute in minecraft:overworld run fill 269 58 -18 269 69 -18 stone
execute in minecraft:overworld run fill 269 70 -18 269 71 -18 dirt
execute in minecraft:overworld run setblock 269 72 -18 coarse_dirt
execute in minecraft:overworld run fill 269 73 -18 269 144 -18 air
execute in minecraft:overworld run setblock 269 73 -18 grass
execute in minecraft:overworld run fill 269 58 -17 269 68 -17 stone
execute in minecraft:overworld run fill 269 69 -17 269 70 -17 dirt
execute in minecraft:overworld run setblock 269 71 -17 coarse_dirt
execute in minecraft:overworld run fill 269 72 -17 269 144 -17 air
execute in minecraft:overworld run fill 269 58 -16 269 67 -16 stone
execute in minecraft:overworld run fill 269 68 -16 269 69 -16 dirt
execute in minecraft:overworld run setblock 269 70 -16 grass_block
execute in minecraft:overworld run fill 269 71 -16 269 144 -16 air
execute in minecraft:overworld run fill 269 58 -15 269 66 -15 stone
execute in minecraft:overworld run fill 269 67 -15 269 68 -15 dirt
execute in minecraft:overworld run setblock 269 69 -15 grass_block
execute in minecraft:overworld run fill 269 70 -15 269 144 -15 air
execute in minecraft:overworld run fill 269 58 -14 269 65 -14 stone
execute in minecraft:overworld run fill 269 66 -14 269 67 -14 dirt
execute in minecraft:overworld run setblock 269 68 -14 coarse_dirt
execute in minecraft:overworld run fill 269 69 -14 269 144 -14 air
execute in minecraft:overworld run fill 269 58 -13 269 64 -13 stone
execute in minecraft:overworld run fill 269 65 -13 269 66 -13 dirt
execute in minecraft:overworld run setblock 269 67 -13 coarse_dirt
execute in minecraft:overworld run fill 269 68 -13 269 144 -13 air
execute in minecraft:overworld run fill 269 58 -12 269 63 -12 stone
execute in minecraft:overworld run fill 269 64 -12 269 65 -12 dirt
execute in minecraft:overworld run setblock 269 66 -12 coarse_dirt
execute in minecraft:overworld run fill 269 67 -12 269 144 -12 air
execute in minecraft:overworld run setblock 269 67 -12 grass
execute in minecraft:overworld run fill 269 58 -11 269 62 -11 stone
execute in minecraft:overworld run fill 269 63 -11 269 64 -11 dirt
execute in minecraft:overworld run setblock 269 65 -11 coarse_dirt
execute in minecraft:overworld run fill 269 66 -11 269 144 -11 air
execute in minecraft:overworld run fill 269 58 -10 269 62 -10 stone
execute in minecraft:overworld run fill 269 63 -10 269 64 -10 dirt
execute in minecraft:overworld run setblock 269 65 -10 coarse_dirt
execute in minecraft:overworld run fill 269 66 -10 269 144 -10 air
execute in minecraft:overworld run fill 269 58 -9 269 61 -9 stone
execute in minecraft:overworld run fill 269 62 -9 269 63 -9 dirt
execute in minecraft:overworld run setblock 269 64 -9 grass_block
execute in minecraft:overworld run fill 269 65 -9 269 144 -9 air
execute in minecraft:overworld run fill 269 58 -8 269 61 -8 stone
execute in minecraft:overworld run fill 269 62 -8 269 63 -8 dirt
execute in minecraft:overworld run setblock 269 64 -8 coarse_dirt
execute in minecraft:overworld run fill 269 65 -8 269 144 -8 air
execute in minecraft:overworld run fill 269 58 -7 269 60 -7 stone
execute in minecraft:overworld run fill 269 61 -7 269 62 -7 dirt
execute in minecraft:overworld run setblock 269 63 -7 gravel
execute in minecraft:overworld run fill 269 64 -7 269 144 -7 air
execute in minecraft:overworld run fill 269 64 -7 269 64 -7 water
execute in minecraft:overworld run fill 269 58 -6 269 59 -6 stone
execute in minecraft:overworld run fill 269 60 -6 269 61 -6 dirt
execute in minecraft:overworld run setblock 269 62 -6 gravel
execute in minecraft:overworld run fill 269 63 -6 269 144 -6 air
execute in minecraft:overworld run fill 269 63 -6 269 64 -6 water
execute in minecraft:overworld run fill 269 58 -5 269 59 -5 stone
execute in minecraft:overworld run fill 269 60 -5 269 61 -5 dirt
execute in minecraft:overworld run setblock 269 62 -5 gravel
execute in minecraft:overworld run fill 269 63 -5 269 144 -5 air
execute in minecraft:overworld run fill 269 63 -5 269 64 -5 water
execute in minecraft:overworld run fill 269 58 -4 269 58 -4 stone
execute in minecraft:overworld run fill 269 59 -4 269 60 -4 dirt
execute in minecraft:overworld run setblock 269 61 -4 gravel
execute in minecraft:overworld run fill 269 62 -4 269 144 -4 air
execute in minecraft:overworld run fill 269 62 -4 269 64 -4 water
execute in minecraft:overworld run fill 269 58 -3 269 58 -3 stone
execute in minecraft:overworld run fill 269 59 -3 269 60 -3 dirt
execute in minecraft:overworld run setblock 269 61 -3 gravel
execute in minecraft:overworld run fill 269 62 -3 269 144 -3 air
execute in minecraft:overworld run fill 269 62 -3 269 64 -3 water
execute in minecraft:overworld run fill 269 58 -2 269 58 -2 stone
execute in minecraft:overworld run fill 269 59 -2 269 60 -2 dirt
execute in minecraft:overworld run setblock 269 61 -2 gravel
execute in minecraft:overworld run fill 269 62 -2 269 144 -2 air
execute in minecraft:overworld run fill 269 62 -2 269 64 -2 water
execute in minecraft:overworld run fill 269 58 -1 269 57 -1 stone
execute in minecraft:overworld run fill 269 58 -1 269 59 -1 dirt
execute in minecraft:overworld run setblock 269 60 -1 gravel
execute in minecraft:overworld run fill 269 61 -1 269 144 -1 air
execute in minecraft:overworld run fill 269 61 -1 269 64 -1 water
execute in minecraft:overworld run fill 269 58 0 269 57 0 stone
execute in minecraft:overworld run fill 269 58 0 269 59 0 dirt
execute in minecraft:overworld run setblock 269 60 0 gravel
execute in minecraft:overworld run fill 269 61 0 269 144 0 air
execute in minecraft:overworld run fill 269 61 0 269 64 0 water
execute in minecraft:overworld run fill 269 58 1 269 57 1 stone
execute in minecraft:overworld run fill 269 58 1 269 59 1 dirt
execute in minecraft:overworld run setblock 269 60 1 gravel
execute in minecraft:overworld run fill 269 61 1 269 144 1 air
execute in minecraft:overworld run fill 269 61 1 269 64 1 water
execute in minecraft:overworld run fill 269 58 2 269 57 2 stone
execute in minecraft:overworld run fill 269 58 2 269 59 2 dirt
execute in minecraft:overworld run setblock 269 60 2 gravel
execute in minecraft:overworld run fill 269 61 2 269 144 2 air
execute in minecraft:overworld run fill 269 61 2 269 64 2 water
execute in minecraft:overworld run fill 269 58 3 269 57 3 stone
execute in minecraft:overworld run fill 269 58 3 269 59 3 dirt
execute in minecraft:overworld run setblock 269 60 3 gravel
execute in minecraft:overworld run fill 269 61 3 269 144 3 air
execute in minecraft:overworld run fill 269 61 3 269 64 3 water
execute in minecraft:overworld run fill 269 58 4 269 57 4 stone
execute in minecraft:overworld run fill 269 58 4 269 59 4 dirt
execute in minecraft:overworld run setblock 269 60 4 gravel
execute in minecraft:overworld run fill 269 61 4 269 144 4 air
execute in minecraft:overworld run fill 269 61 4 269 64 4 water
execute in minecraft:overworld run fill 269 58 5 269 57 5 stone
execute in minecraft:overworld run fill 269 58 5 269 59 5 dirt
execute in minecraft:overworld run setblock 269 60 5 gravel
execute in minecraft:overworld run fill 269 61 5 269 144 5 air
execute in minecraft:overworld run fill 269 61 5 269 64 5 water
execute in minecraft:overworld run fill 269 58 6 269 57 6 stone
execute in minecraft:overworld run fill 269 58 6 269 59 6 dirt
execute in minecraft:overworld run setblock 269 60 6 gravel
execute in minecraft:overworld run fill 269 61 6 269 144 6 air
execute in minecraft:overworld run fill 269 61 6 269 64 6 water
execute in minecraft:overworld run fill 269 58 7 269 57 7 stone
execute in minecraft:overworld run fill 269 58 7 269 59 7 dirt
execute in minecraft:overworld run setblock 269 60 7 gravel
execute in minecraft:overworld run fill 269 61 7 269 144 7 air
execute in minecraft:overworld run fill 269 61 7 269 64 7 water
execute in minecraft:overworld run fill 269 58 8 269 57 8 stone
execute in minecraft:overworld run fill 269 58 8 269 59 8 dirt
execute in minecraft:overworld run setblock 269 60 8 gravel
execute in minecraft:overworld run fill 269 61 8 269 144 8 air
execute in minecraft:overworld run fill 269 61 8 269 64 8 water
execute in minecraft:overworld run fill 269 58 9 269 57 9 stone
execute in minecraft:overworld run fill 269 58 9 269 59 9 dirt
execute in minecraft:overworld run setblock 269 60 9 gravel
execute in minecraft:overworld run fill 269 61 9 269 144 9 air
execute in minecraft:overworld run fill 269 61 9 269 64 9 water
execute in minecraft:overworld run fill 269 58 10 269 57 10 stone
execute in minecraft:overworld run fill 269 58 10 269 59 10 dirt
execute in minecraft:overworld run setblock 269 60 10 gravel
execute in minecraft:overworld run fill 269 61 10 269 144 10 air
execute in minecraft:overworld run fill 269 61 10 269 64 10 water
execute in minecraft:overworld run fill 269 58 11 269 57 11 stone
execute in minecraft:overworld run fill 269 58 11 269 59 11 dirt
execute in minecraft:overworld run setblock 269 60 11 gravel
execute in minecraft:overworld run fill 269 61 11 269 144 11 air
execute in minecraft:overworld run fill 269 61 11 269 64 11 water
execute in minecraft:overworld run fill 269 58 12 269 57 12 stone
execute in minecraft:overworld run fill 269 58 12 269 59 12 dirt
execute in minecraft:overworld run setblock 269 60 12 gravel
execute in minecraft:overworld run fill 269 61 12 269 144 12 air
execute in minecraft:overworld run fill 269 61 12 269 64 12 water
execute in minecraft:overworld run fill 269 58 13 269 57 13 stone
execute in minecraft:overworld run fill 269 58 13 269 59 13 dirt
execute in minecraft:overworld run setblock 269 60 13 gravel
execute in minecraft:overworld run fill 269 61 13 269 144 13 air
execute in minecraft:overworld run fill 269 61 13 269 64 13 water
execute in minecraft:overworld run fill 269 58 14 269 56 14 stone
execute in minecraft:overworld run fill 269 57 14 269 58 14 dirt
execute in minecraft:overworld run setblock 269 59 14 gravel
execute in minecraft:overworld run fill 269 60 14 269 144 14 air
execute in minecraft:overworld run fill 269 60 14 269 64 14 water
execute in minecraft:overworld run fill 269 58 15 269 56 15 stone
execute in minecraft:overworld run fill 269 57 15 269 58 15 dirt
execute in minecraft:overworld run setblock 269 59 15 gravel
execute in minecraft:overworld run fill 269 60 15 269 144 15 air
execute in minecraft:overworld run fill 269 60 15 269 64 15 water
execute in minecraft:overworld run fill 269 58 16 269 56 16 stone
execute in minecraft:overworld run fill 269 57 16 269 58 16 dirt
execute in minecraft:overworld run setblock 269 59 16 gravel
execute in minecraft:overworld run fill 269 60 16 269 144 16 air
execute in minecraft:overworld run fill 269 60 16 269 64 16 water
execute in minecraft:overworld run fill 269 58 17 269 56 17 stone
execute in minecraft:overworld run fill 269 57 17 269 58 17 dirt
execute in minecraft:overworld run setblock 269 59 17 gravel
execute in minecraft:overworld run fill 269 60 17 269 144 17 air
execute in minecraft:overworld run fill 269 60 17 269 64 17 water
execute in minecraft:overworld run fill 269 58 18 269 56 18 stone
execute in minecraft:overworld run fill 269 57 18 269 58 18 dirt
execute in minecraft:overworld run setblock 269 59 18 gravel
execute in minecraft:overworld run fill 269 60 18 269 144 18 air
execute in minecraft:overworld run fill 269 60 18 269 64 18 water
execute in minecraft:overworld run fill 269 58 19 269 56 19 stone
execute in minecraft:overworld run fill 269 57 19 269 58 19 dirt
execute in minecraft:overworld run setblock 269 59 19 gravel
execute in minecraft:overworld run fill 269 60 19 269 144 19 air
execute in minecraft:overworld run fill 269 60 19 269 64 19 water
execute in minecraft:overworld run fill 269 58 20 269 56 20 stone
execute in minecraft:overworld run fill 269 57 20 269 58 20 dirt
execute in minecraft:overworld run setblock 269 59 20 gravel
execute in minecraft:overworld run fill 269 60 20 269 144 20 air
execute in minecraft:overworld run fill 269 60 20 269 64 20 water
execute in minecraft:overworld run fill 269 58 21 269 56 21 stone
execute in minecraft:overworld run fill 269 57 21 269 58 21 dirt
execute in minecraft:overworld run setblock 269 59 21 gravel
execute in minecraft:overworld run fill 269 60 21 269 144 21 air
execute in minecraft:overworld run fill 269 60 21 269 64 21 water
execute in minecraft:overworld run fill 269 58 22 269 56 22 stone
execute in minecraft:overworld run fill 269 57 22 269 58 22 dirt
execute in minecraft:overworld run setblock 269 59 22 gravel
execute in minecraft:overworld run fill 269 60 22 269 144 22 air
execute in minecraft:overworld run fill 269 60 22 269 64 22 water
execute in minecraft:overworld run fill 269 58 23 269 56 23 stone
execute in minecraft:overworld run fill 269 57 23 269 58 23 dirt
execute in minecraft:overworld run setblock 269 59 23 gravel
execute in minecraft:overworld run fill 269 60 23 269 144 23 air
execute in minecraft:overworld run fill 269 60 23 269 64 23 water
execute in minecraft:overworld run fill 269 58 24 269 56 24 stone
execute in minecraft:overworld run fill 269 57 24 269 58 24 dirt
execute in minecraft:overworld run setblock 269 59 24 gravel
execute in minecraft:overworld run fill 269 60 24 269 144 24 air
execute in minecraft:overworld run fill 269 60 24 269 64 24 water
execute in minecraft:overworld run fill 269 58 25 269 57 25 stone
execute in minecraft:overworld run fill 269 58 25 269 59 25 dirt
execute in minecraft:overworld run setblock 269 60 25 gravel
execute in minecraft:overworld run fill 269 61 25 269 144 25 air
execute in minecraft:overworld run fill 269 61 25 269 64 25 water
execute in minecraft:overworld run fill 269 58 26 269 57 26 stone
execute in minecraft:overworld run fill 269 58 26 269 59 26 dirt
execute in minecraft:overworld run setblock 269 60 26 gravel
execute in minecraft:overworld run fill 269 61 26 269 144 26 air
execute in minecraft:overworld run fill 269 61 26 269 64 26 water
execute in minecraft:overworld run fill 269 58 27 269 57 27 stone
execute in minecraft:overworld run fill 269 58 27 269 59 27 dirt
execute in minecraft:overworld run setblock 269 60 27 gravel
execute in minecraft:overworld run fill 269 61 27 269 144 27 air
execute in minecraft:overworld run fill 269 61 27 269 64 27 water
execute in minecraft:overworld run fill 269 58 28 269 57 28 stone
execute in minecraft:overworld run fill 269 58 28 269 59 28 dirt
execute in minecraft:overworld run setblock 269 60 28 gravel
execute in minecraft:overworld run fill 269 61 28 269 144 28 air
execute in minecraft:overworld run fill 269 61 28 269 64 28 water
execute in minecraft:overworld run fill 269 58 29 269 58 29 stone
execute in minecraft:overworld run fill 269 59 29 269 60 29 dirt
execute in minecraft:overworld run setblock 269 61 29 gravel
execute in minecraft:overworld run fill 269 62 29 269 144 29 air
execute in minecraft:overworld run fill 269 62 29 269 64 29 water
execute in minecraft:overworld run fill 269 58 30 269 58 30 stone
execute in minecraft:overworld run fill 269 59 30 269 60 30 dirt
execute in minecraft:overworld run setblock 269 61 30 gravel
execute in minecraft:overworld run fill 269 62 30 269 144 30 air
execute in minecraft:overworld run fill 269 62 30 269 64 30 water
execute in minecraft:overworld run fill 269 58 31 269 58 31 stone
execute in minecraft:overworld run fill 269 59 31 269 60 31 dirt
execute in minecraft:overworld run setblock 269 61 31 gravel
execute in minecraft:overworld run fill 269 62 31 269 144 31 air
schedule function blade_gallery:random/burned/part_98 1t replace
