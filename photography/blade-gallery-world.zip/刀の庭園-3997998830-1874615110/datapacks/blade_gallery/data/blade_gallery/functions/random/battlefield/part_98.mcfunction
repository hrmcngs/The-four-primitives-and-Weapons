execute in minecraft:overworld run fill 398 66 -15 398 67 -15 dirt
execute in minecraft:overworld run setblock 398 68 -15 grass_block
execute in minecraft:overworld run fill 398 69 -15 398 144 -15 air
execute in minecraft:overworld run fill 398 58 -14 398 64 -14 stone
execute in minecraft:overworld run fill 398 65 -14 398 66 -14 dirt
execute in minecraft:overworld run setblock 398 67 -14 coarse_dirt
execute in minecraft:overworld run fill 398 68 -14 398 144 -14 air
execute in minecraft:overworld run fill 398 58 -13 398 63 -13 stone
execute in minecraft:overworld run fill 398 64 -13 398 65 -13 dirt
execute in minecraft:overworld run setblock 398 66 -13 grass_block
execute in minecraft:overworld run fill 398 67 -13 398 144 -13 air
execute in minecraft:overworld run fill 398 58 -12 398 62 -12 stone
execute in minecraft:overworld run fill 398 63 -12 398 64 -12 dirt
execute in minecraft:overworld run setblock 398 65 -12 coarse_dirt
execute in minecraft:overworld run fill 398 66 -12 398 144 -12 air
execute in minecraft:overworld run fill 398 58 -11 398 62 -11 stone
execute in minecraft:overworld run fill 398 63 -11 398 64 -11 dirt
execute in minecraft:overworld run setblock 398 65 -11 coarse_dirt
execute in minecraft:overworld run fill 398 66 -11 398 144 -11 air
execute in minecraft:overworld run fill 398 58 -10 398 61 -10 stone
execute in minecraft:overworld run fill 398 62 -10 398 63 -10 dirt
execute in minecraft:overworld run setblock 398 64 -10 grass_block
execute in minecraft:overworld run fill 398 65 -10 398 144 -10 air
execute in minecraft:overworld run fill 398 58 -9 398 60 -9 stone
execute in minecraft:overworld run fill 398 61 -9 398 62 -9 dirt
execute in minecraft:overworld run setblock 398 63 -9 gravel
execute in minecraft:overworld run fill 398 64 -9 398 144 -9 air
execute in minecraft:overworld run fill 398 64 -9 398 64 -9 water
execute in minecraft:overworld run fill 398 58 -8 398 60 -8 stone
execute in minecraft:overworld run fill 398 61 -8 398 62 -8 dirt
execute in minecraft:overworld run setblock 398 63 -8 gravel
execute in minecraft:overworld run fill 398 64 -8 398 144 -8 air
execute in minecraft:overworld run fill 398 64 -8 398 64 -8 water
execute in minecraft:overworld run fill 398 58 -7 398 59 -7 stone
execute in minecraft:overworld run fill 398 60 -7 398 61 -7 dirt
execute in minecraft:overworld run setblock 398 62 -7 gravel
execute in minecraft:overworld run fill 398 63 -7 398 144 -7 air
execute in minecraft:overworld run fill 398 63 -7 398 64 -7 water
execute in minecraft:overworld run fill 398 58 -6 398 59 -6 stone
execute in minecraft:overworld run fill 398 60 -6 398 61 -6 dirt
execute in minecraft:overworld run setblock 398 62 -6 gravel
execute in minecraft:overworld run fill 398 63 -6 398 144 -6 air
execute in minecraft:overworld run fill 398 63 -6 398 64 -6 water
execute in minecraft:overworld run fill 398 58 -5 398 58 -5 stone
execute in minecraft:overworld run fill 398 59 -5 398 60 -5 dirt
execute in minecraft:overworld run setblock 398 61 -5 gravel
execute in minecraft:overworld run fill 398 62 -5 398 144 -5 air
execute in minecraft:overworld run fill 398 62 -5 398 64 -5 water
execute in minecraft:overworld run fill 398 58 -4 398 57 -4 stone
execute in minecraft:overworld run fill 398 58 -4 398 59 -4 dirt
execute in minecraft:overworld run setblock 398 60 -4 gravel
execute in minecraft:overworld run fill 398 61 -4 398 144 -4 air
execute in minecraft:overworld run fill 398 61 -4 398 64 -4 water
execute in minecraft:overworld run fill 398 58 -3 398 57 -3 stone
execute in minecraft:overworld run fill 398 58 -3 398 59 -3 dirt
execute in minecraft:overworld run setblock 398 60 -3 gravel
execute in minecraft:overworld run fill 398 61 -3 398 144 -3 air
execute in minecraft:overworld run fill 398 61 -3 398 64 -3 water
execute in minecraft:overworld run fill 398 58 -2 398 56 -2 stone
execute in minecraft:overworld run fill 398 57 -2 398 58 -2 dirt
execute in minecraft:overworld run setblock 398 59 -2 gravel
execute in minecraft:overworld run fill 398 60 -2 398 144 -2 air
execute in minecraft:overworld run fill 398 60 -2 398 64 -2 water
execute in minecraft:overworld run fill 398 58 -1 398 56 -1 stone
execute in minecraft:overworld run fill 398 57 -1 398 58 -1 dirt
execute in minecraft:overworld run setblock 398 59 -1 gravel
execute in minecraft:overworld run fill 398 60 -1 398 144 -1 air
execute in minecraft:overworld run fill 398 60 -1 398 64 -1 water
execute in minecraft:overworld run fill 398 58 0 398 55 0 stone
execute in minecraft:overworld run fill 398 56 0 398 57 0 dirt
execute in minecraft:overworld run setblock 398 58 0 gravel
execute in minecraft:overworld run fill 398 59 0 398 144 0 air
execute in minecraft:overworld run fill 398 59 0 398 64 0 water
execute in minecraft:overworld run fill 398 58 1 398 55 1 stone
execute in minecraft:overworld run fill 398 56 1 398 57 1 dirt
execute in minecraft:overworld run setblock 398 58 1 gravel
execute in minecraft:overworld run fill 398 59 1 398 144 1 air
execute in minecraft:overworld run fill 398 59 1 398 64 1 water
execute in minecraft:overworld run fill 398 58 2 398 55 2 stone
execute in minecraft:overworld run fill 398 56 2 398 57 2 dirt
execute in minecraft:overworld run setblock 398 58 2 gravel
execute in minecraft:overworld run fill 398 59 2 398 144 2 air
execute in minecraft:overworld run fill 398 59 2 398 64 2 water
execute in minecraft:overworld run fill 398 58 3 398 55 3 stone
execute in minecraft:overworld run fill 398 56 3 398 57 3 dirt
execute in minecraft:overworld run setblock 398 58 3 gravel
execute in minecraft:overworld run fill 398 59 3 398 144 3 air
execute in minecraft:overworld run fill 398 59 3 398 64 3 water
execute in minecraft:overworld run fill 398 58 4 398 55 4 stone
execute in minecraft:overworld run fill 398 56 4 398 57 4 dirt
execute in minecraft:overworld run setblock 398 58 4 gravel
execute in minecraft:overworld run fill 398 59 4 398 144 4 air
execute in minecraft:overworld run fill 398 59 4 398 64 4 water
execute in minecraft:overworld run fill 398 58 5 398 55 5 stone
execute in minecraft:overworld run fill 398 56 5 398 57 5 dirt
execute in minecraft:overworld run setblock 398 58 5 gravel
execute in minecraft:overworld run fill 398 59 5 398 144 5 air
execute in minecraft:overworld run fill 398 59 5 398 64 5 water
execute in minecraft:overworld run fill 398 58 6 398 55 6 stone
execute in minecraft:overworld run fill 398 56 6 398 57 6 dirt
execute in minecraft:overworld run setblock 398 58 6 gravel
execute in minecraft:overworld run fill 398 59 6 398 144 6 air
execute in minecraft:overworld run fill 398 59 6 398 64 6 water
execute in minecraft:overworld run fill 398 58 7 398 55 7 stone
execute in minecraft:overworld run fill 398 56 7 398 57 7 dirt
execute in minecraft:overworld run setblock 398 58 7 gravel
execute in minecraft:overworld run fill 398 59 7 398 144 7 air
execute in minecraft:overworld run fill 398 59 7 398 64 7 water
execute in minecraft:overworld run fill 398 58 8 398 55 8 stone
execute in minecraft:overworld run fill 398 56 8 398 57 8 dirt
execute in minecraft:overworld run setblock 398 58 8 gravel
execute in minecraft:overworld run fill 398 59 8 398 144 8 air
execute in minecraft:overworld run fill 398 59 8 398 64 8 water
execute in minecraft:overworld run fill 398 58 9 398 55 9 stone
execute in minecraft:overworld run fill 398 56 9 398 57 9 dirt
execute in minecraft:overworld run setblock 398 58 9 gravel
execute in minecraft:overworld run fill 398 59 9 398 144 9 air
execute in minecraft:overworld run fill 398 59 9 398 64 9 water
execute in minecraft:overworld run fill 398 58 10 398 55 10 stone
execute in minecraft:overworld run fill 398 56 10 398 57 10 dirt
execute in minecraft:overworld run setblock 398 58 10 gravel
execute in minecraft:overworld run fill 398 59 10 398 144 10 air
execute in minecraft:overworld run fill 398 59 10 398 64 10 water
execute in minecraft:overworld run fill 398 58 11 398 55 11 stone
execute in minecraft:overworld run fill 398 56 11 398 57 11 dirt
execute in minecraft:overworld run setblock 398 58 11 gravel
execute in minecraft:overworld run fill 398 59 11 398 144 11 air
execute in minecraft:overworld run fill 398 59 11 398 64 11 water
execute in minecraft:overworld run fill 398 58 12 398 56 12 stone
execute in minecraft:overworld run fill 398 57 12 398 58 12 dirt
execute in minecraft:overworld run setblock 398 59 12 gravel
execute in minecraft:overworld run fill 398 60 12 398 144 12 air
execute in minecraft:overworld run fill 398 60 12 398 64 12 water
execute in minecraft:overworld run fill 398 58 13 398 56 13 stone
execute in minecraft:overworld run fill 398 57 13 398 58 13 dirt
execute in minecraft:overworld run setblock 398 59 13 gravel
execute in minecraft:overworld run fill 398 60 13 398 144 13 air
execute in minecraft:overworld run fill 398 60 13 398 64 13 water
execute in minecraft:overworld run fill 398 58 14 398 57 14 stone
execute in minecraft:overworld run fill 398 58 14 398 59 14 dirt
execute in minecraft:overworld run setblock 398 60 14 gravel
execute in minecraft:overworld run fill 398 61 14 398 144 14 air
execute in minecraft:overworld run fill 398 61 14 398 64 14 water
execute in minecraft:overworld run fill 398 58 15 398 57 15 stone
execute in minecraft:overworld run fill 398 58 15 398 59 15 dirt
execute in minecraft:overworld run setblock 398 60 15 gravel
execute in minecraft:overworld run fill 398 61 15 398 144 15 air
execute in minecraft:overworld run fill 398 61 15 398 64 15 water
execute in minecraft:overworld run fill 398 58 16 398 58 16 stone
execute in minecraft:overworld run fill 398 59 16 398 60 16 dirt
execute in minecraft:overworld run setblock 398 61 16 gravel
execute in minecraft:overworld run fill 398 62 16 398 144 16 air
execute in minecraft:overworld run fill 398 62 16 398 64 16 water
execute in minecraft:overworld run fill 398 58 17 398 58 17 stone
execute in minecraft:overworld run fill 398 59 17 398 60 17 dirt
execute in minecraft:overworld run setblock 398 61 17 gravel
execute in minecraft:overworld run fill 398 62 17 398 144 17 air
execute in minecraft:overworld run fill 398 62 17 398 64 17 water
execute in minecraft:overworld run fill 398 58 18 398 58 18 stone
execute in minecraft:overworld run fill 398 59 18 398 60 18 dirt
execute in minecraft:overworld run setblock 398 61 18 gravel
execute in minecraft:overworld run fill 398 62 18 398 144 18 air
execute in minecraft:overworld run fill 398 62 18 398 64 18 water
execute in minecraft:overworld run fill 398 58 19 398 59 19 stone
execute in minecraft:overworld run fill 398 60 19 398 61 19 dirt
execute in minecraft:overworld run setblock 398 62 19 gravel
execute in minecraft:overworld run fill 398 63 19 398 144 19 air
execute in minecraft:overworld run fill 398 63 19 398 64 19 water
execute in minecraft:overworld run fill 398 58 20 398 59 20 stone
execute in minecraft:overworld run fill 398 60 20 398 61 20 dirt
execute in minecraft:overworld run setblock 398 62 20 gravel
execute in minecraft:overworld run fill 398 63 20 398 144 20 air
execute in minecraft:overworld run fill 398 63 20 398 64 20 water
execute in minecraft:overworld run fill 398 58 21 398 59 21 stone
execute in minecraft:overworld run fill 398 60 21 398 61 21 dirt
execute in minecraft:overworld run setblock 398 62 21 gravel
execute in minecraft:overworld run fill 398 63 21 398 144 21 air
execute in minecraft:overworld run fill 398 63 21 398 64 21 water
execute in minecraft:overworld run fill 398 58 22 398 59 22 stone
execute in minecraft:overworld run fill 398 60 22 398 61 22 dirt
execute in minecraft:overworld run setblock 398 62 22 gravel
execute in minecraft:overworld run fill 398 63 22 398 144 22 air
execute in minecraft:overworld run fill 398 63 22 398 64 22 water
execute in minecraft:overworld run fill 398 58 23 398 59 23 stone
execute in minecraft:overworld run fill 398 60 23 398 61 23 dirt
execute in minecraft:overworld run setblock 398 62 23 gravel
execute in minecraft:overworld run fill 398 63 23 398 144 23 air
execute in minecraft:overworld run fill 398 63 23 398 64 23 water
execute in minecraft:overworld run fill 398 58 24 398 60 24 stone
execute in minecraft:overworld run fill 398 61 24 398 62 24 dirt
execute in minecraft:overworld run setblock 398 63 24 gravel
execute in minecraft:overworld run fill 398 64 24 398 144 24 air
execute in minecraft:overworld run fill 398 64 24 398 64 24 water
execute in minecraft:overworld run fill 398 58 25 398 60 25 stone
execute in minecraft:overworld run fill 398 61 25 398 62 25 dirt
execute in minecraft:overworld run setblock 398 63 25 gravel
execute in minecraft:overworld run fill 398 64 25 398 144 25 air
execute in minecraft:overworld run fill 398 64 25 398 64 25 water
execute in minecraft:overworld run fill 398 58 26 398 60 26 stone
execute in minecraft:overworld run fill 398 61 26 398 62 26 dirt
execute in minecraft:overworld run setblock 398 63 26 gravel
execute in minecraft:overworld run fill 398 64 26 398 144 26 air
execute in minecraft:overworld run fill 398 64 26 398 64 26 water
execute in minecraft:overworld run fill 398 58 27 398 60 27 stone
execute in minecraft:overworld run fill 398 61 27 398 62 27 dirt
execute in minecraft:overworld run setblock 398 63 27 gravel
execute in minecraft:overworld run fill 398 64 27 398 144 27 air
execute in minecraft:overworld run fill 398 64 27 398 64 27 water
execute in minecraft:overworld run fill 398 58 28 398 61 28 stone
execute in minecraft:overworld run fill 398 62 28 398 63 28 dirt
execute in minecraft:overworld run setblock 398 64 28 coarse_dirt
execute in minecraft:overworld run fill 398 65 28 398 144 28 air
execute in minecraft:overworld run fill 398 58 29 398 61 29 stone
execute in minecraft:overworld run fill 398 62 29 398 63 29 dirt
execute in minecraft:overworld run setblock 398 64 29 grass_block
execute in minecraft:overworld run fill 398 65 29 398 144 29 air
execute in minecraft:overworld run fill 398 58 30 398 61 30 stone
execute in minecraft:overworld run fill 398 62 30 398 63 30 dirt
execute in minecraft:overworld run setblock 398 64 30 coarse_dirt
execute in minecraft:overworld run fill 398 65 30 398 144 30 air
execute in minecraft:overworld run fill 398 58 31 398 62 31 stone
execute in minecraft:overworld run fill 398 63 31 398 64 31 dirt
execute in minecraft:overworld run setblock 398 65 31 grass_block
execute in minecraft:overworld run fill 398 66 31 398 144 31 air
execute in minecraft:overworld run fill 398 58 32 398 62 32 stone
execute in minecraft:overworld run fill 398 63 32 398 64 32 dirt
execute in minecraft:overworld run setblock 398 65 32 grass_block
execute in minecraft:overworld run fill 398 66 32 398 144 32 air
execute in minecraft:overworld run setblock 398 66 32 grass
execute in minecraft:overworld run fill 398 58 33 398 62 33 stone
execute in minecraft:overworld run fill 398 63 33 398 64 33 dirt
execute in minecraft:overworld run setblock 398 65 33 coarse_dirt
execute in minecraft:overworld run fill 398 66 33 398 144 33 air
execute in minecraft:overworld run fill 398 58 34 398 63 34 stone
execute in minecraft:overworld run fill 398 64 34 398 65 34 dirt
execute in minecraft:overworld run setblock 398 66 34 coarse_dirt
execute in minecraft:overworld run fill 398 67 34 398 144 34 air
execute in minecraft:overworld run fill 398 58 35 398 63 35 stone
execute in minecraft:overworld run fill 398 64 35 398 65 35 dirt
execute in minecraft:overworld run setblock 398 66 35 coarse_dirt
execute in minecraft:overworld run fill 398 67 35 398 144 35 air
execute in minecraft:overworld run fill 398 58 36 398 64 36 stone
execute in minecraft:overworld run fill 398 65 36 398 66 36 dirt
execute in minecraft:overworld run setblock 398 67 36 coarse_dirt
execute in minecraft:overworld run fill 398 68 36 398 144 36 air
execute in minecraft:overworld run fill 398 58 37 398 64 37 stone
execute in minecraft:overworld run fill 398 65 37 398 66 37 dirt
execute in minecraft:overworld run setblock 398 67 37 grass_block
execute in minecraft:overworld run fill 398 68 37 398 144 37 air
execute in minecraft:overworld run fill 398 58 38 398 65 38 stone
execute in minecraft:overworld run fill 398 66 38 398 67 38 dirt
execute in minecraft:overworld run setblock 398 68 38 coarse_dirt
execute in minecraft:overworld run fill 398 69 38 398 144 38 air
execute in minecraft:overworld run fill 398 58 39 398 65 39 stone
execute in minecraft:overworld run fill 398 66 39 398 67 39 dirt
execute in minecraft:overworld run setblock 398 68 39 coarse_dirt
schedule function blade_gallery:random/battlefield/part_99 1t replace
