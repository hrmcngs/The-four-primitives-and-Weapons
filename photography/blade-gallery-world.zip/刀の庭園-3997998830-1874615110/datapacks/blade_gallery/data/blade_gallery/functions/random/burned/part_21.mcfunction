execute in minecraft:overworld run fill 221 74 26 221 144 26 air
execute in minecraft:overworld run fill 221 58 27 221 70 27 stone
execute in minecraft:overworld run fill 221 71 27 221 72 27 dirt
execute in minecraft:overworld run setblock 221 73 27 coarse_dirt
execute in minecraft:overworld run fill 221 74 27 221 144 27 air
execute in minecraft:overworld run fill 221 58 28 221 71 28 stone
execute in minecraft:overworld run fill 221 72 28 221 73 28 dirt
execute in minecraft:overworld run setblock 221 74 28 coarse_dirt
execute in minecraft:overworld run fill 221 75 28 221 144 28 air
execute in minecraft:overworld run fill 221 58 29 221 71 29 stone
execute in minecraft:overworld run fill 221 72 29 221 73 29 dirt
execute in minecraft:overworld run setblock 221 74 29 coarse_dirt
execute in minecraft:overworld run fill 221 75 29 221 144 29 air
execute in minecraft:overworld run fill 221 58 30 221 70 30 stone
execute in minecraft:overworld run fill 221 71 30 221 72 30 dirt
execute in minecraft:overworld run setblock 221 73 30 coarse_dirt
execute in minecraft:overworld run fill 221 74 30 221 144 30 air
execute in minecraft:overworld run setblock 221 74 30 grass
execute in minecraft:overworld run fill 221 58 31 221 70 31 stone
execute in minecraft:overworld run fill 221 71 31 221 72 31 dirt
execute in minecraft:overworld run setblock 221 73 31 coarse_dirt
execute in minecraft:overworld run fill 221 74 31 221 144 31 air
execute in minecraft:overworld run fill 221 58 32 221 70 32 stone
execute in minecraft:overworld run fill 221 71 32 221 72 32 dirt
execute in minecraft:overworld run setblock 221 73 32 grass_block
execute in minecraft:overworld run fill 221 74 32 221 144 32 air
execute in minecraft:overworld run fill 221 58 33 221 70 33 stone
execute in minecraft:overworld run fill 221 71 33 221 72 33 dirt
execute in minecraft:overworld run setblock 221 73 33 coarse_dirt
execute in minecraft:overworld run fill 221 74 33 221 144 33 air
execute in minecraft:overworld run setblock 221 74 33 grass
execute in minecraft:overworld run fill 221 58 34 221 70 34 stone
execute in minecraft:overworld run fill 221 71 34 221 72 34 dirt
execute in minecraft:overworld run setblock 221 73 34 grass_block
execute in minecraft:overworld run fill 221 74 34 221 144 34 air
execute in minecraft:overworld run fill 221 58 35 221 69 35 stone
execute in minecraft:overworld run fill 221 70 35 221 71 35 dirt
execute in minecraft:overworld run setblock 221 72 35 grass_block
execute in minecraft:overworld run fill 221 73 35 221 144 35 air
execute in minecraft:overworld run fill 221 58 36 221 69 36 stone
execute in minecraft:overworld run fill 221 70 36 221 71 36 dirt
execute in minecraft:overworld run setblock 221 72 36 coarse_dirt
execute in minecraft:overworld run fill 221 73 36 221 144 36 air
execute in minecraft:overworld run setblock 221 73 36 grass
execute in minecraft:overworld run fill 221 58 37 221 69 37 stone
execute in minecraft:overworld run fill 221 70 37 221 71 37 dirt
execute in minecraft:overworld run setblock 221 72 37 coarse_dirt
execute in minecraft:overworld run fill 221 73 37 221 144 37 air
execute in minecraft:overworld run fill 221 58 38 221 68 38 stone
execute in minecraft:overworld run fill 221 69 38 221 70 38 dirt
execute in minecraft:overworld run setblock 221 71 38 grass_block
execute in minecraft:overworld run fill 221 72 38 221 144 38 air
execute in minecraft:overworld run fill 221 58 39 221 67 39 stone
execute in minecraft:overworld run fill 221 68 39 221 69 39 dirt
execute in minecraft:overworld run setblock 221 70 39 coarse_dirt
execute in minecraft:overworld run fill 221 71 39 221 144 39 air
execute in minecraft:overworld run fill 221 58 40 221 66 40 stone
execute in minecraft:overworld run fill 221 67 40 221 68 40 dirt
execute in minecraft:overworld run setblock 221 69 40 grass_block
execute in minecraft:overworld run fill 221 70 40 221 144 40 air
execute in minecraft:overworld run fill 221 58 41 221 65 41 stone
execute in minecraft:overworld run fill 221 66 41 221 67 41 dirt
execute in minecraft:overworld run setblock 221 68 41 grass_block
execute in minecraft:overworld run fill 221 69 41 221 144 41 air
execute in minecraft:overworld run fill 221 58 42 221 64 42 stone
execute in minecraft:overworld run fill 221 65 42 221 66 42 dirt
execute in minecraft:overworld run setblock 221 67 42 coarse_dirt
execute in minecraft:overworld run fill 221 68 42 221 144 42 air
execute in minecraft:overworld run fill 221 58 43 221 63 43 stone
execute in minecraft:overworld run fill 221 64 43 221 65 43 dirt
execute in minecraft:overworld run setblock 221 66 43 grass_block
execute in minecraft:overworld run fill 221 67 43 221 144 43 air
execute in minecraft:overworld run fill 221 58 44 221 63 44 stone
execute in minecraft:overworld run fill 221 64 44 221 65 44 dirt
execute in minecraft:overworld run setblock 221 66 44 coarse_dirt
execute in minecraft:overworld run fill 221 67 44 221 144 44 air
execute in minecraft:overworld run fill 221 58 45 221 62 45 stone
execute in minecraft:overworld run fill 221 63 45 221 64 45 dirt
execute in minecraft:overworld run setblock 221 65 45 grass_block
execute in minecraft:overworld run fill 221 66 45 221 144 45 air
execute in minecraft:overworld run fill 221 58 46 221 62 46 stone
execute in minecraft:overworld run fill 221 63 46 221 64 46 dirt
execute in minecraft:overworld run setblock 221 65 46 coarse_dirt
execute in minecraft:overworld run fill 221 66 46 221 144 46 air
execute in minecraft:overworld run fill 221 58 47 221 61 47 stone
execute in minecraft:overworld run fill 221 62 47 221 63 47 dirt
execute in minecraft:overworld run setblock 221 64 47 coarse_dirt
execute in minecraft:overworld run fill 221 65 47 221 144 47 air
execute in minecraft:overworld run fill 222 58 -48 222 61 -48 stone
execute in minecraft:overworld run fill 222 62 -48 222 63 -48 dirt
execute in minecraft:overworld run setblock 222 64 -48 coarse_dirt
execute in minecraft:overworld run fill 222 65 -48 222 144 -48 air
execute in minecraft:overworld run fill 222 58 -47 222 63 -47 stone
execute in minecraft:overworld run fill 222 64 -47 222 65 -47 dirt
execute in minecraft:overworld run setblock 222 66 -47 grass_block
execute in minecraft:overworld run fill 222 67 -47 222 144 -47 air
execute in minecraft:overworld run fill 222 58 -46 222 64 -46 stone
execute in minecraft:overworld run fill 222 65 -46 222 66 -46 dirt
execute in minecraft:overworld run setblock 222 67 -46 coarse_dirt
execute in minecraft:overworld run fill 222 68 -46 222 144 -46 air
execute in minecraft:overworld run fill 222 58 -45 222 66 -45 stone
execute in minecraft:overworld run fill 222 67 -45 222 68 -45 dirt
execute in minecraft:overworld run setblock 222 69 -45 grass_block
execute in minecraft:overworld run fill 222 70 -45 222 144 -45 air
execute in minecraft:overworld run fill 222 58 -44 222 67 -44 stone
execute in minecraft:overworld run fill 222 68 -44 222 69 -44 dirt
execute in minecraft:overworld run setblock 222 70 -44 grass_block
execute in minecraft:overworld run fill 222 71 -44 222 144 -44 air
execute in minecraft:overworld run fill 222 58 -43 222 68 -43 stone
execute in minecraft:overworld run fill 222 69 -43 222 70 -43 dirt
execute in minecraft:overworld run setblock 222 71 -43 grass_block
execute in minecraft:overworld run fill 222 72 -43 222 144 -43 air
execute in minecraft:overworld run fill 222 58 -42 222 69 -42 stone
execute in minecraft:overworld run fill 222 70 -42 222 71 -42 dirt
execute in minecraft:overworld run setblock 222 72 -42 coarse_dirt
execute in minecraft:overworld run fill 222 73 -42 222 144 -42 air
execute in minecraft:overworld run fill 222 58 -41 222 70 -41 stone
execute in minecraft:overworld run fill 222 71 -41 222 72 -41 dirt
execute in minecraft:overworld run setblock 222 73 -41 grass_block
execute in minecraft:overworld run fill 222 74 -41 222 144 -41 air
execute in minecraft:overworld run fill 222 58 -40 222 70 -40 stone
execute in minecraft:overworld run fill 222 71 -40 222 72 -40 dirt
execute in minecraft:overworld run setblock 222 73 -40 coarse_dirt
execute in minecraft:overworld run fill 222 74 -40 222 144 -40 air
execute in minecraft:overworld run fill 222 58 -39 222 71 -39 stone
execute in minecraft:overworld run fill 222 72 -39 222 73 -39 dirt
execute in minecraft:overworld run setblock 222 74 -39 coarse_dirt
execute in minecraft:overworld run fill 222 75 -39 222 144 -39 air
execute in minecraft:overworld run fill 222 58 -38 222 71 -38 stone
execute in minecraft:overworld run fill 222 72 -38 222 73 -38 dirt
execute in minecraft:overworld run setblock 222 74 -38 grass_block
execute in minecraft:overworld run fill 222 75 -38 222 144 -38 air
execute in minecraft:overworld run fill 222 58 -37 222 70 -37 stone
execute in minecraft:overworld run fill 222 71 -37 222 72 -37 dirt
execute in minecraft:overworld run setblock 222 73 -37 grass_block
execute in minecraft:overworld run fill 222 74 -37 222 144 -37 air
execute in minecraft:overworld run fill 222 58 -36 222 70 -36 stone
execute in minecraft:overworld run fill 222 71 -36 222 72 -36 dirt
execute in minecraft:overworld run setblock 222 73 -36 grass_block
execute in minecraft:overworld run fill 222 74 -36 222 144 -36 air
execute in minecraft:overworld run fill 222 58 -35 222 69 -35 stone
execute in minecraft:overworld run fill 222 70 -35 222 71 -35 dirt
execute in minecraft:overworld run setblock 222 72 -35 coarse_dirt
execute in minecraft:overworld run fill 222 73 -35 222 144 -35 air
execute in minecraft:overworld run fill 222 58 -34 222 68 -34 stone
execute in minecraft:overworld run fill 222 69 -34 222 70 -34 dirt
execute in minecraft:overworld run setblock 222 71 -34 coarse_dirt
execute in minecraft:overworld run fill 222 72 -34 222 144 -34 air
execute in minecraft:overworld run fill 222 58 -33 222 68 -33 stone
execute in minecraft:overworld run fill 222 69 -33 222 70 -33 dirt
execute in minecraft:overworld run setblock 222 71 -33 coarse_dirt
execute in minecraft:overworld run fill 222 72 -33 222 144 -33 air
execute in minecraft:overworld run fill 222 58 -32 222 67 -32 stone
execute in minecraft:overworld run fill 222 68 -32 222 69 -32 dirt
execute in minecraft:overworld run setblock 222 70 -32 coarse_dirt
execute in minecraft:overworld run fill 222 71 -32 222 144 -32 air
execute in minecraft:overworld run fill 222 58 -31 222 67 -31 stone
execute in minecraft:overworld run fill 222 68 -31 222 69 -31 dirt
execute in minecraft:overworld run setblock 222 70 -31 grass_block
execute in minecraft:overworld run fill 222 71 -31 222 144 -31 air
execute in minecraft:overworld run fill 222 58 -30 222 67 -30 stone
execute in minecraft:overworld run fill 222 68 -30 222 69 -30 dirt
execute in minecraft:overworld run setblock 222 70 -30 grass_block
execute in minecraft:overworld run fill 222 71 -30 222 144 -30 air
execute in minecraft:overworld run fill 222 58 -29 222 66 -29 stone
execute in minecraft:overworld run fill 222 67 -29 222 68 -29 dirt
execute in minecraft:overworld run setblock 222 69 -29 coarse_dirt
execute in minecraft:overworld run fill 222 70 -29 222 144 -29 air
execute in minecraft:overworld run fill 222 58 -28 222 66 -28 stone
execute in minecraft:overworld run fill 222 67 -28 222 68 -28 dirt
execute in minecraft:overworld run setblock 222 69 -28 coarse_dirt
execute in minecraft:overworld run fill 222 70 -28 222 144 -28 air
execute in minecraft:overworld run fill 222 58 -27 222 66 -27 stone
execute in minecraft:overworld run fill 222 67 -27 222 68 -27 dirt
execute in minecraft:overworld run setblock 222 69 -27 coarse_dirt
execute in minecraft:overworld run fill 222 70 -27 222 144 -27 air
execute in minecraft:overworld run fill 222 58 -26 222 66 -26 stone
execute in minecraft:overworld run fill 222 67 -26 222 68 -26 dirt
execute in minecraft:overworld run setblock 222 69 -26 coarse_dirt
execute in minecraft:overworld run fill 222 70 -26 222 144 -26 air
execute in minecraft:overworld run fill 222 58 -25 222 65 -25 stone
execute in minecraft:overworld run fill 222 66 -25 222 67 -25 dirt
execute in minecraft:overworld run setblock 222 68 -25 grass_block
execute in minecraft:overworld run fill 222 69 -25 222 144 -25 air
execute in minecraft:overworld run fill 222 58 -24 222 65 -24 stone
execute in minecraft:overworld run fill 222 66 -24 222 67 -24 dirt
execute in minecraft:overworld run setblock 222 68 -24 coarse_dirt
execute in minecraft:overworld run fill 222 69 -24 222 144 -24 air
execute in minecraft:overworld run fill 222 58 -23 222 66 -23 stone
execute in minecraft:overworld run fill 222 67 -23 222 68 -23 dirt
execute in minecraft:overworld run setblock 222 69 -23 grass_block
execute in minecraft:overworld run fill 222 70 -23 222 144 -23 air
execute in minecraft:overworld run fill 222 58 -22 222 66 -22 stone
execute in minecraft:overworld run fill 222 67 -22 222 68 -22 dirt
execute in minecraft:overworld run setblock 222 69 -22 coarse_dirt
execute in minecraft:overworld run fill 222 70 -22 222 144 -22 air
execute in minecraft:overworld run fill 222 58 -21 222 66 -21 stone
execute in minecraft:overworld run fill 222 67 -21 222 68 -21 dirt
execute in minecraft:overworld run setblock 222 69 -21 coarse_dirt
execute in minecraft:overworld run fill 222 70 -21 222 144 -21 air
execute in minecraft:overworld run fill 222 58 -20 222 66 -20 stone
execute in minecraft:overworld run fill 222 67 -20 222 68 -20 dirt
execute in minecraft:overworld run setblock 222 69 -20 coarse_dirt
execute in minecraft:overworld run fill 222 70 -20 222 144 -20 air
execute in minecraft:overworld run fill 222 58 -19 222 66 -19 stone
execute in minecraft:overworld run fill 222 67 -19 222 68 -19 dirt
execute in minecraft:overworld run setblock 222 69 -19 grass_block
execute in minecraft:overworld run fill 222 70 -19 222 144 -19 air
execute in minecraft:overworld run fill 222 58 -18 222 66 -18 stone
execute in minecraft:overworld run fill 222 67 -18 222 68 -18 dirt
execute in minecraft:overworld run setblock 222 69 -18 grass_block
execute in minecraft:overworld run fill 222 70 -18 222 144 -18 air
execute in minecraft:overworld run setblock 222 70 -18 grass
execute in minecraft:overworld run fill 222 58 -17 222 66 -17 stone
execute in minecraft:overworld run fill 222 67 -17 222 68 -17 dirt
execute in minecraft:overworld run setblock 222 69 -17 coarse_dirt
execute in minecraft:overworld run fill 222 70 -17 222 144 -17 air
execute in minecraft:overworld run fill 222 58 -16 222 66 -16 stone
execute in minecraft:overworld run fill 222 67 -16 222 68 -16 dirt
execute in minecraft:overworld run setblock 222 69 -16 coarse_dirt
execute in minecraft:overworld run fill 222 70 -16 222 144 -16 air
execute in minecraft:overworld run fill 222 58 -15 222 65 -15 stone
execute in minecraft:overworld run fill 222 66 -15 222 67 -15 dirt
execute in minecraft:overworld run setblock 222 68 -15 grass_block
execute in minecraft:overworld run fill 222 69 -15 222 144 -15 air
execute in minecraft:overworld run fill 222 58 -14 222 65 -14 stone
execute in minecraft:overworld run fill 222 66 -14 222 67 -14 dirt
execute in minecraft:overworld run setblock 222 68 -14 coarse_dirt
execute in minecraft:overworld run fill 222 69 -14 222 144 -14 air
execute in minecraft:overworld run fill 222 58 -13 222 65 -13 stone
execute in minecraft:overworld run fill 222 66 -13 222 67 -13 dirt
execute in minecraft:overworld run setblock 222 68 -13 coarse_dirt
execute in minecraft:overworld run fill 222 69 -13 222 144 -13 air
execute in minecraft:overworld run fill 222 58 -12 222 64 -12 stone
execute in minecraft:overworld run fill 222 65 -12 222 66 -12 dirt
execute in minecraft:overworld run setblock 222 67 -12 coarse_dirt
execute in minecraft:overworld run fill 222 68 -12 222 144 -12 air
execute in minecraft:overworld run fill 222 58 -11 222 64 -11 stone
execute in minecraft:overworld run fill 222 65 -11 222 66 -11 dirt
execute in minecraft:overworld run setblock 222 67 -11 grass_block
execute in minecraft:overworld run fill 222 68 -11 222 144 -11 air
execute in minecraft:overworld run setblock 222 68 -11 grass
execute in minecraft:overworld run fill 222 58 -10 222 65 -10 stone
execute in minecraft:overworld run fill 222 66 -10 222 67 -10 dirt
execute in minecraft:overworld run setblock 222 68 -10 coarse_dirt
execute in minecraft:overworld run fill 222 69 -10 222 144 -10 air
execute in minecraft:overworld run fill 222 58 -9 222 65 -9 stone
execute in minecraft:overworld run fill 222 66 -9 222 67 -9 dirt
execute in minecraft:overworld run setblock 222 68 -9 grass_block
execute in minecraft:overworld run fill 222 69 -9 222 144 -9 air
execute in minecraft:overworld run fill 222 58 -8 222 65 -8 stone
execute in minecraft:overworld run fill 222 66 -8 222 67 -8 dirt
execute in minecraft:overworld run setblock 222 68 -8 coarse_dirt
execute in minecraft:overworld run fill 222 69 -8 222 144 -8 air
execute in minecraft:overworld run fill 222 58 -7 222 65 -7 stone
execute in minecraft:overworld run fill 222 66 -7 222 67 -7 dirt
schedule function blade_gallery:random/burned/part_22 1t replace
