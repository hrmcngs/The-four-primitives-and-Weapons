execute in minecraft:overworld run fill 382 58 38 382 63 38 stone
execute in minecraft:overworld run fill 382 64 38 382 65 38 dirt
execute in minecraft:overworld run setblock 382 66 38 grass_block
execute in minecraft:overworld run fill 382 67 38 382 144 38 air
execute in minecraft:overworld run fill 382 58 39 382 63 39 stone
execute in minecraft:overworld run fill 382 64 39 382 65 39 dirt
execute in minecraft:overworld run setblock 382 66 39 coarse_dirt
execute in minecraft:overworld run fill 382 67 39 382 144 39 air
execute in minecraft:overworld run fill 382 58 40 382 62 40 stone
execute in minecraft:overworld run fill 382 63 40 382 64 40 dirt
execute in minecraft:overworld run setblock 382 65 40 coarse_dirt
execute in minecraft:overworld run fill 382 66 40 382 144 40 air
execute in minecraft:overworld run fill 382 58 41 382 62 41 stone
execute in minecraft:overworld run fill 382 63 41 382 64 41 dirt
execute in minecraft:overworld run setblock 382 65 41 coarse_dirt
execute in minecraft:overworld run fill 382 66 41 382 144 41 air
execute in minecraft:overworld run fill 382 58 42 382 61 42 stone
execute in minecraft:overworld run fill 382 62 42 382 63 42 dirt
execute in minecraft:overworld run setblock 382 64 42 grass_block
execute in minecraft:overworld run fill 382 65 42 382 144 42 air
execute in minecraft:overworld run fill 382 58 43 382 61 43 stone
execute in minecraft:overworld run fill 382 62 43 382 63 43 dirt
execute in minecraft:overworld run setblock 382 64 43 coarse_dirt
execute in minecraft:overworld run fill 382 65 43 382 144 43 air
execute in minecraft:overworld run fill 382 58 44 382 61 44 stone
execute in minecraft:overworld run fill 382 62 44 382 63 44 dirt
execute in minecraft:overworld run setblock 382 64 44 coarse_dirt
execute in minecraft:overworld run fill 382 65 44 382 144 44 air
execute in minecraft:overworld run fill 382 58 45 382 61 45 stone
execute in minecraft:overworld run fill 382 62 45 382 63 45 dirt
execute in minecraft:overworld run setblock 382 64 45 coarse_dirt
execute in minecraft:overworld run fill 382 65 45 382 144 45 air
execute in minecraft:overworld run fill 382 58 46 382 61 46 stone
execute in minecraft:overworld run fill 382 62 46 382 63 46 dirt
execute in minecraft:overworld run setblock 382 64 46 coarse_dirt
execute in minecraft:overworld run fill 382 65 46 382 144 46 air
execute in minecraft:overworld run fill 382 58 47 382 61 47 stone
execute in minecraft:overworld run fill 382 62 47 382 63 47 dirt
execute in minecraft:overworld run setblock 382 64 47 coarse_dirt
execute in minecraft:overworld run fill 382 65 47 382 144 47 air
execute in minecraft:overworld run fill 383 58 -48 383 61 -48 stone
execute in minecraft:overworld run fill 383 62 -48 383 63 -48 dirt
execute in minecraft:overworld run setblock 383 64 -48 grass_block
execute in minecraft:overworld run fill 383 65 -48 383 144 -48 air
execute in minecraft:overworld run fill 383 58 -47 383 62 -47 stone
execute in minecraft:overworld run fill 383 63 -47 383 64 -47 dirt
execute in minecraft:overworld run setblock 383 65 -47 grass_block
execute in minecraft:overworld run fill 383 66 -47 383 144 -47 air
execute in minecraft:overworld run fill 383 58 -46 383 64 -46 stone
execute in minecraft:overworld run fill 383 65 -46 383 66 -46 dirt
execute in minecraft:overworld run setblock 383 67 -46 grass_block
execute in minecraft:overworld run fill 383 68 -46 383 144 -46 air
execute in minecraft:overworld run fill 383 58 -45 383 65 -45 stone
execute in minecraft:overworld run fill 383 66 -45 383 67 -45 dirt
execute in minecraft:overworld run setblock 383 68 -45 coarse_dirt
execute in minecraft:overworld run fill 383 69 -45 383 144 -45 air
execute in minecraft:overworld run fill 383 58 -44 383 66 -44 stone
execute in minecraft:overworld run fill 383 67 -44 383 68 -44 dirt
execute in minecraft:overworld run setblock 383 69 -44 grass_block
execute in minecraft:overworld run fill 383 70 -44 383 144 -44 air
execute in minecraft:overworld run fill 383 58 -43 383 67 -43 stone
execute in minecraft:overworld run fill 383 68 -43 383 69 -43 dirt
execute in minecraft:overworld run setblock 383 70 -43 coarse_dirt
execute in minecraft:overworld run fill 383 71 -43 383 144 -43 air
execute in minecraft:overworld run fill 383 58 -42 383 68 -42 stone
execute in minecraft:overworld run fill 383 69 -42 383 70 -42 dirt
execute in minecraft:overworld run setblock 383 71 -42 coarse_dirt
execute in minecraft:overworld run fill 383 72 -42 383 144 -42 air
execute in minecraft:overworld run fill 383 58 -41 383 69 -41 stone
execute in minecraft:overworld run fill 383 70 -41 383 71 -41 dirt
execute in minecraft:overworld run setblock 383 72 -41 grass_block
execute in minecraft:overworld run fill 383 73 -41 383 144 -41 air
execute in minecraft:overworld run fill 383 58 -40 383 69 -40 stone
execute in minecraft:overworld run fill 383 70 -40 383 71 -40 dirt
execute in minecraft:overworld run setblock 383 72 -40 coarse_dirt
execute in minecraft:overworld run fill 383 73 -40 383 144 -40 air
execute in minecraft:overworld run fill 383 58 -39 383 70 -39 stone
execute in minecraft:overworld run fill 383 71 -39 383 72 -39 dirt
execute in minecraft:overworld run setblock 383 73 -39 grass_block
execute in minecraft:overworld run fill 383 74 -39 383 144 -39 air
execute in minecraft:overworld run fill 383 58 -38 383 70 -38 stone
execute in minecraft:overworld run fill 383 71 -38 383 72 -38 dirt
execute in minecraft:overworld run setblock 383 73 -38 coarse_dirt
execute in minecraft:overworld run fill 383 74 -38 383 144 -38 air
execute in minecraft:overworld run setblock 383 74 -38 grass
execute in minecraft:overworld run fill 383 58 -37 383 69 -37 stone
execute in minecraft:overworld run fill 383 70 -37 383 71 -37 dirt
execute in minecraft:overworld run setblock 383 72 -37 coarse_dirt
execute in minecraft:overworld run fill 383 73 -37 383 144 -37 air
execute in minecraft:overworld run fill 383 58 -36 383 69 -36 stone
execute in minecraft:overworld run fill 383 70 -36 383 71 -36 dirt
execute in minecraft:overworld run setblock 383 72 -36 coarse_dirt
execute in minecraft:overworld run fill 383 73 -36 383 144 -36 air
execute in minecraft:overworld run fill 383 58 -35 383 68 -35 stone
execute in minecraft:overworld run fill 383 69 -35 383 70 -35 dirt
execute in minecraft:overworld run setblock 383 71 -35 coarse_dirt
execute in minecraft:overworld run fill 383 72 -35 383 144 -35 air
execute in minecraft:overworld run fill 383 58 -34 383 67 -34 stone
execute in minecraft:overworld run fill 383 68 -34 383 69 -34 dirt
execute in minecraft:overworld run setblock 383 70 -34 grass_block
execute in minecraft:overworld run fill 383 71 -34 383 144 -34 air
execute in minecraft:overworld run setblock 383 71 -34 mossy_cobblestone
execute in minecraft:overworld run fill 383 58 -33 383 67 -33 stone
execute in minecraft:overworld run fill 383 68 -33 383 69 -33 dirt
execute in minecraft:overworld run setblock 383 70 -33 coarse_dirt
execute in minecraft:overworld run fill 383 71 -33 383 144 -33 air
execute in minecraft:overworld run fill 383 58 -32 383 67 -32 stone
execute in minecraft:overworld run fill 383 68 -32 383 69 -32 dirt
execute in minecraft:overworld run setblock 383 70 -32 grass_block
execute in minecraft:overworld run fill 383 71 -32 383 144 -32 air
execute in minecraft:overworld run setblock 383 71 -32 grass
execute in minecraft:overworld run fill 383 58 -31 383 66 -31 stone
execute in minecraft:overworld run fill 383 67 -31 383 68 -31 dirt
execute in minecraft:overworld run setblock 383 69 -31 grass_block
execute in minecraft:overworld run fill 383 70 -31 383 144 -31 air
execute in minecraft:overworld run fill 383 58 -30 383 66 -30 stone
execute in minecraft:overworld run fill 383 67 -30 383 68 -30 dirt
execute in minecraft:overworld run setblock 383 69 -30 coarse_dirt
execute in minecraft:overworld run fill 383 70 -30 383 144 -30 air
execute in minecraft:overworld run fill 383 58 -29 383 65 -29 stone
execute in minecraft:overworld run fill 383 66 -29 383 67 -29 dirt
execute in minecraft:overworld run setblock 383 68 -29 coarse_dirt
execute in minecraft:overworld run fill 383 69 -29 383 144 -29 air
execute in minecraft:overworld run fill 383 58 -28 383 65 -28 stone
execute in minecraft:overworld run fill 383 66 -28 383 67 -28 dirt
execute in minecraft:overworld run setblock 383 68 -28 coarse_dirt
execute in minecraft:overworld run fill 383 69 -28 383 144 -28 air
execute in minecraft:overworld run fill 383 58 -27 383 64 -27 stone
execute in minecraft:overworld run fill 383 65 -27 383 66 -27 dirt
execute in minecraft:overworld run setblock 383 67 -27 coarse_dirt
execute in minecraft:overworld run fill 383 68 -27 383 144 -27 air
execute in minecraft:overworld run fill 383 58 -26 383 64 -26 stone
execute in minecraft:overworld run fill 383 65 -26 383 66 -26 dirt
execute in minecraft:overworld run setblock 383 67 -26 grass_block
execute in minecraft:overworld run fill 383 68 -26 383 144 -26 air
execute in minecraft:overworld run fill 383 58 -25 383 63 -25 stone
execute in minecraft:overworld run fill 383 64 -25 383 65 -25 dirt
execute in minecraft:overworld run setblock 383 66 -25 coarse_dirt
execute in minecraft:overworld run fill 383 67 -25 383 144 -25 air
execute in minecraft:overworld run fill 383 58 -24 383 62 -24 stone
execute in minecraft:overworld run fill 383 63 -24 383 64 -24 dirt
execute in minecraft:overworld run setblock 383 65 -24 coarse_dirt
execute in minecraft:overworld run fill 383 66 -24 383 144 -24 air
execute in minecraft:overworld run fill 383 58 -23 383 62 -23 stone
execute in minecraft:overworld run fill 383 63 -23 383 64 -23 dirt
execute in minecraft:overworld run setblock 383 65 -23 coarse_dirt
execute in minecraft:overworld run fill 383 66 -23 383 144 -23 air
execute in minecraft:overworld run fill 383 58 -22 383 61 -22 stone
execute in minecraft:overworld run fill 383 62 -22 383 63 -22 dirt
execute in minecraft:overworld run setblock 383 64 -22 coarse_dirt
execute in minecraft:overworld run fill 383 65 -22 383 144 -22 air
execute in minecraft:overworld run fill 383 58 -21 383 60 -21 stone
execute in minecraft:overworld run fill 383 61 -21 383 62 -21 dirt
execute in minecraft:overworld run setblock 383 63 -21 gravel
execute in minecraft:overworld run fill 383 64 -21 383 144 -21 air
execute in minecraft:overworld run fill 383 64 -21 383 64 -21 water
execute in minecraft:overworld run fill 383 58 -20 383 60 -20 stone
execute in minecraft:overworld run fill 383 61 -20 383 62 -20 dirt
execute in minecraft:overworld run setblock 383 63 -20 gravel
execute in minecraft:overworld run fill 383 64 -20 383 144 -20 air
execute in minecraft:overworld run fill 383 64 -20 383 64 -20 water
execute in minecraft:overworld run fill 383 58 -19 383 59 -19 stone
execute in minecraft:overworld run fill 383 60 -19 383 61 -19 dirt
execute in minecraft:overworld run setblock 383 62 -19 gravel
execute in minecraft:overworld run fill 383 63 -19 383 144 -19 air
execute in minecraft:overworld run fill 383 63 -19 383 64 -19 water
execute in minecraft:overworld run fill 383 58 -18 383 59 -18 stone
execute in minecraft:overworld run fill 383 60 -18 383 61 -18 dirt
execute in minecraft:overworld run setblock 383 62 -18 gravel
execute in minecraft:overworld run fill 383 63 -18 383 144 -18 air
execute in minecraft:overworld run fill 383 63 -18 383 64 -18 water
execute in minecraft:overworld run fill 383 58 -17 383 59 -17 stone
execute in minecraft:overworld run fill 383 60 -17 383 61 -17 dirt
execute in minecraft:overworld run setblock 383 62 -17 gravel
execute in minecraft:overworld run fill 383 63 -17 383 144 -17 air
execute in minecraft:overworld run fill 383 63 -17 383 64 -17 water
execute in minecraft:overworld run fill 383 58 -16 383 59 -16 stone
execute in minecraft:overworld run fill 383 60 -16 383 61 -16 dirt
execute in minecraft:overworld run setblock 383 62 -16 gravel
execute in minecraft:overworld run fill 383 63 -16 383 144 -16 air
execute in minecraft:overworld run fill 383 63 -16 383 64 -16 water
execute in minecraft:overworld run fill 383 58 -15 383 59 -15 stone
execute in minecraft:overworld run fill 383 60 -15 383 61 -15 dirt
execute in minecraft:overworld run setblock 383 62 -15 gravel
execute in minecraft:overworld run fill 383 63 -15 383 144 -15 air
execute in minecraft:overworld run fill 383 63 -15 383 64 -15 water
execute in minecraft:overworld run fill 383 58 -14 383 59 -14 stone
execute in minecraft:overworld run fill 383 60 -14 383 61 -14 dirt
execute in minecraft:overworld run setblock 383 62 -14 gravel
execute in minecraft:overworld run fill 383 63 -14 383 144 -14 air
execute in minecraft:overworld run fill 383 63 -14 383 64 -14 water
execute in minecraft:overworld run fill 383 58 -13 383 59 -13 stone
execute in minecraft:overworld run fill 383 60 -13 383 61 -13 dirt
execute in minecraft:overworld run setblock 383 62 -13 gravel
execute in minecraft:overworld run fill 383 63 -13 383 144 -13 air
execute in minecraft:overworld run fill 383 63 -13 383 64 -13 water
execute in minecraft:overworld run fill 383 58 -12 383 59 -12 stone
execute in minecraft:overworld run fill 383 60 -12 383 61 -12 dirt
execute in minecraft:overworld run setblock 383 62 -12 gravel
execute in minecraft:overworld run fill 383 63 -12 383 144 -12 air
execute in minecraft:overworld run fill 383 63 -12 383 64 -12 water
execute in minecraft:overworld run fill 383 58 -11 383 60 -11 stone
execute in minecraft:overworld run fill 383 61 -11 383 62 -11 dirt
execute in minecraft:overworld run setblock 383 63 -11 gravel
execute in minecraft:overworld run fill 383 64 -11 383 144 -11 air
execute in minecraft:overworld run fill 383 64 -11 383 64 -11 water
execute in minecraft:overworld run fill 383 58 -10 383 60 -10 stone
execute in minecraft:overworld run fill 383 61 -10 383 62 -10 dirt
execute in minecraft:overworld run setblock 383 63 -10 gravel
execute in minecraft:overworld run fill 383 64 -10 383 144 -10 air
execute in minecraft:overworld run fill 383 64 -10 383 64 -10 water
execute in minecraft:overworld run fill 383 58 -9 383 60 -9 stone
execute in minecraft:overworld run fill 383 61 -9 383 62 -9 dirt
execute in minecraft:overworld run setblock 383 63 -9 gravel
execute in minecraft:overworld run fill 383 64 -9 383 144 -9 air
execute in minecraft:overworld run fill 383 64 -9 383 64 -9 water
execute in minecraft:overworld run fill 383 58 -8 383 61 -8 stone
execute in minecraft:overworld run fill 383 62 -8 383 63 -8 dirt
execute in minecraft:overworld run setblock 383 64 -8 grass_block
execute in minecraft:overworld run fill 383 65 -8 383 144 -8 air
execute in minecraft:overworld run fill 383 58 -7 383 61 -7 stone
execute in minecraft:overworld run fill 383 62 -7 383 63 -7 dirt
execute in minecraft:overworld run setblock 383 64 -7 grass_block
execute in minecraft:overworld run fill 383 65 -7 383 144 -7 air
execute in minecraft:overworld run fill 383 58 -6 383 61 -6 stone
execute in minecraft:overworld run fill 383 62 -6 383 63 -6 dirt
execute in minecraft:overworld run setblock 383 64 -6 coarse_dirt
execute in minecraft:overworld run fill 383 65 -6 383 144 -6 air
execute in minecraft:overworld run fill 383 58 -5 383 61 -5 stone
execute in minecraft:overworld run fill 383 62 -5 383 63 -5 dirt
execute in minecraft:overworld run setblock 383 64 -5 coarse_dirt
execute in minecraft:overworld run fill 383 65 -5 383 144 -5 air
execute in minecraft:overworld run fill 383 58 -4 383 62 -4 stone
execute in minecraft:overworld run fill 383 63 -4 383 64 -4 dirt
execute in minecraft:overworld run setblock 383 65 -4 grass_block
execute in minecraft:overworld run fill 383 66 -4 383 144 -4 air
execute in minecraft:overworld run fill 383 58 -3 383 62 -3 stone
execute in minecraft:overworld run fill 383 63 -3 383 64 -3 dirt
execute in minecraft:overworld run setblock 383 65 -3 coarse_dirt
execute in minecraft:overworld run fill 383 66 -3 383 144 -3 air
execute in minecraft:overworld run fill 383 58 -2 383 62 -2 stone
execute in minecraft:overworld run fill 383 63 -2 383 64 -2 dirt
execute in minecraft:overworld run setblock 383 65 -2 coarse_dirt
execute in minecraft:overworld run fill 383 66 -2 383 144 -2 air
execute in minecraft:overworld run fill 383 58 -1 383 62 -1 stone
execute in minecraft:overworld run fill 383 63 -1 383 64 -1 dirt
execute in minecraft:overworld run setblock 383 65 -1 grass_block
execute in minecraft:overworld run fill 383 66 -1 383 144 -1 air
execute in minecraft:overworld run fill 383 58 0 383 63 0 stone
execute in minecraft:overworld run fill 383 64 0 383 65 0 dirt
execute in minecraft:overworld run setblock 383 66 0 coarse_dirt
execute in minecraft:overworld run fill 383 67 0 383 144 0 air
execute in minecraft:overworld run fill 383 58 1 383 63 1 stone
execute in minecraft:overworld run fill 383 64 1 383 65 1 dirt
execute in minecraft:overworld run setblock 383 66 1 grass_block
execute in minecraft:overworld run fill 383 67 1 383 144 1 air
schedule function blade_gallery:random/battlefield/part_73 1t replace
