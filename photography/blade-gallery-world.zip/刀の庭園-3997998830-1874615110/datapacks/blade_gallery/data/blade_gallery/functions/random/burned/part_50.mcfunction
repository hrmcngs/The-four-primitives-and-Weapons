execute in minecraft:overworld run setblock 240 68 10 coarse_dirt
execute in minecraft:overworld run fill 240 69 10 240 144 10 air
execute in minecraft:overworld run fill 240 58 11 240 65 11 stone
execute in minecraft:overworld run fill 240 66 11 240 67 11 dirt
execute in minecraft:overworld run setblock 240 68 11 grass_block
execute in minecraft:overworld run fill 240 69 11 240 144 11 air
execute in minecraft:overworld run setblock 240 69 11 grass
execute in minecraft:overworld run fill 240 58 12 240 66 12 stone
execute in minecraft:overworld run fill 240 67 12 240 68 12 dirt
execute in minecraft:overworld run setblock 240 69 12 grass_block
execute in minecraft:overworld run fill 240 70 12 240 144 12 air
execute in minecraft:overworld run fill 240 58 13 240 66 13 stone
execute in minecraft:overworld run fill 240 67 13 240 68 13 dirt
execute in minecraft:overworld run setblock 240 69 13 coarse_dirt
execute in minecraft:overworld run fill 240 70 13 240 144 13 air
execute in minecraft:overworld run fill 240 58 14 240 66 14 stone
execute in minecraft:overworld run fill 240 67 14 240 68 14 dirt
execute in minecraft:overworld run setblock 240 69 14 grass_block
execute in minecraft:overworld run fill 240 70 14 240 144 14 air
execute in minecraft:overworld run fill 240 58 15 240 66 15 stone
execute in minecraft:overworld run fill 240 67 15 240 68 15 dirt
execute in minecraft:overworld run setblock 240 69 15 grass_block
execute in minecraft:overworld run fill 240 70 15 240 144 15 air
execute in minecraft:overworld run fill 240 58 16 240 66 16 stone
execute in minecraft:overworld run fill 240 67 16 240 68 16 dirt
execute in minecraft:overworld run setblock 240 69 16 coarse_dirt
execute in minecraft:overworld run fill 240 70 16 240 144 16 air
execute in minecraft:overworld run fill 240 58 17 240 66 17 stone
execute in minecraft:overworld run fill 240 67 17 240 68 17 dirt
execute in minecraft:overworld run setblock 240 69 17 grass_block
execute in minecraft:overworld run fill 240 70 17 240 144 17 air
execute in minecraft:overworld run fill 240 58 18 240 67 18 stone
execute in minecraft:overworld run fill 240 68 18 240 69 18 dirt
execute in minecraft:overworld run setblock 240 70 18 coarse_dirt
execute in minecraft:overworld run fill 240 71 18 240 144 18 air
execute in minecraft:overworld run setblock 240 71 18 mossy_cobblestone
execute in minecraft:overworld run fill 240 58 19 240 67 19 stone
execute in minecraft:overworld run fill 240 68 19 240 69 19 dirt
execute in minecraft:overworld run setblock 240 70 19 coarse_dirt
execute in minecraft:overworld run fill 240 71 19 240 144 19 air
execute in minecraft:overworld run fill 240 58 20 240 67 20 stone
execute in minecraft:overworld run fill 240 68 20 240 69 20 dirt
execute in minecraft:overworld run setblock 240 70 20 coarse_dirt
execute in minecraft:overworld run fill 240 71 20 240 144 20 air
execute in minecraft:overworld run fill 240 58 21 240 67 21 stone
execute in minecraft:overworld run fill 240 68 21 240 69 21 dirt
execute in minecraft:overworld run setblock 240 70 21 coarse_dirt
execute in minecraft:overworld run fill 240 71 21 240 144 21 air
execute in minecraft:overworld run fill 240 58 22 240 67 22 stone
execute in minecraft:overworld run fill 240 68 22 240 69 22 dirt
execute in minecraft:overworld run setblock 240 70 22 coarse_dirt
execute in minecraft:overworld run fill 240 71 22 240 144 22 air
execute in minecraft:overworld run fill 240 58 23 240 67 23 stone
execute in minecraft:overworld run fill 240 68 23 240 69 23 dirt
execute in minecraft:overworld run setblock 240 70 23 coarse_dirt
execute in minecraft:overworld run fill 240 71 23 240 144 23 air
execute in minecraft:overworld run fill 240 58 24 240 67 24 stone
execute in minecraft:overworld run fill 240 68 24 240 69 24 dirt
execute in minecraft:overworld run setblock 240 70 24 coarse_dirt
execute in minecraft:overworld run fill 240 71 24 240 144 24 air
execute in minecraft:overworld run fill 240 58 25 240 67 25 stone
execute in minecraft:overworld run fill 240 68 25 240 69 25 dirt
execute in minecraft:overworld run setblock 240 70 25 coarse_dirt
execute in minecraft:overworld run fill 240 71 25 240 144 25 air
execute in minecraft:overworld run fill 240 58 26 240 67 26 stone
execute in minecraft:overworld run fill 240 68 26 240 69 26 dirt
execute in minecraft:overworld run setblock 240 70 26 coarse_dirt
execute in minecraft:overworld run fill 240 71 26 240 144 26 air
execute in minecraft:overworld run fill 240 58 27 240 67 27 stone
execute in minecraft:overworld run fill 240 68 27 240 69 27 dirt
execute in minecraft:overworld run setblock 240 70 27 grass_block
execute in minecraft:overworld run fill 240 71 27 240 144 27 air
execute in minecraft:overworld run fill 240 58 28 240 67 28 stone
execute in minecraft:overworld run fill 240 68 28 240 69 28 dirt
execute in minecraft:overworld run setblock 240 70 28 grass_block
execute in minecraft:overworld run fill 240 71 28 240 144 28 air
execute in minecraft:overworld run setblock 240 71 28 grass
execute in minecraft:overworld run fill 240 58 29 240 67 29 stone
execute in minecraft:overworld run fill 240 68 29 240 69 29 dirt
execute in minecraft:overworld run setblock 240 70 29 grass_block
execute in minecraft:overworld run fill 240 71 29 240 144 29 air
execute in minecraft:overworld run fill 240 58 30 240 67 30 stone
execute in minecraft:overworld run fill 240 68 30 240 69 30 dirt
execute in minecraft:overworld run setblock 240 70 30 coarse_dirt
execute in minecraft:overworld run fill 240 71 30 240 144 30 air
execute in minecraft:overworld run fill 240 58 31 240 67 31 stone
execute in minecraft:overworld run fill 240 68 31 240 69 31 dirt
execute in minecraft:overworld run setblock 240 70 31 coarse_dirt
execute in minecraft:overworld run fill 240 71 31 240 144 31 air
execute in minecraft:overworld run fill 240 58 32 240 67 32 stone
execute in minecraft:overworld run fill 240 68 32 240 69 32 dirt
execute in minecraft:overworld run setblock 240 70 32 grass_block
execute in minecraft:overworld run fill 240 71 32 240 144 32 air
execute in minecraft:overworld run fill 240 58 33 240 66 33 stone
execute in minecraft:overworld run fill 240 67 33 240 68 33 dirt
execute in minecraft:overworld run setblock 240 69 33 coarse_dirt
execute in minecraft:overworld run fill 240 70 33 240 144 33 air
execute in minecraft:overworld run fill 240 58 34 240 66 34 stone
execute in minecraft:overworld run fill 240 67 34 240 68 34 dirt
execute in minecraft:overworld run setblock 240 69 34 grass_block
execute in minecraft:overworld run fill 240 70 34 240 144 34 air
execute in minecraft:overworld run fill 240 58 35 240 66 35 stone
execute in minecraft:overworld run fill 240 67 35 240 68 35 dirt
execute in minecraft:overworld run setblock 240 69 35 grass_block
execute in minecraft:overworld run fill 240 70 35 240 144 35 air
execute in minecraft:overworld run fill 240 58 36 240 66 36 stone
execute in minecraft:overworld run fill 240 67 36 240 68 36 dirt
execute in minecraft:overworld run setblock 240 69 36 coarse_dirt
execute in minecraft:overworld run fill 240 70 36 240 144 36 air
execute in minecraft:overworld run fill 240 58 37 240 65 37 stone
execute in minecraft:overworld run fill 240 66 37 240 67 37 dirt
execute in minecraft:overworld run setblock 240 68 37 grass_block
execute in minecraft:overworld run fill 240 69 37 240 144 37 air
execute in minecraft:overworld run setblock 240 69 37 grass
execute in minecraft:overworld run fill 240 58 38 240 65 38 stone
execute in minecraft:overworld run fill 240 66 38 240 67 38 dirt
execute in minecraft:overworld run setblock 240 68 38 coarse_dirt
execute in minecraft:overworld run fill 240 69 38 240 144 38 air
execute in minecraft:overworld run fill 240 58 39 240 65 39 stone
execute in minecraft:overworld run fill 240 66 39 240 67 39 dirt
execute in minecraft:overworld run setblock 240 68 39 coarse_dirt
execute in minecraft:overworld run fill 240 69 39 240 144 39 air
execute in minecraft:overworld run fill 240 58 40 240 64 40 stone
execute in minecraft:overworld run fill 240 65 40 240 66 40 dirt
execute in minecraft:overworld run setblock 240 67 40 grass_block
execute in minecraft:overworld run fill 240 68 40 240 144 40 air
execute in minecraft:overworld run fill 240 58 41 240 64 41 stone
execute in minecraft:overworld run fill 240 65 41 240 66 41 dirt
execute in minecraft:overworld run setblock 240 67 41 coarse_dirt
execute in minecraft:overworld run fill 240 68 41 240 144 41 air
execute in minecraft:overworld run fill 240 58 42 240 63 42 stone
execute in minecraft:overworld run fill 240 64 42 240 65 42 dirt
execute in minecraft:overworld run setblock 240 66 42 coarse_dirt
execute in minecraft:overworld run fill 240 67 42 240 144 42 air
execute in minecraft:overworld run fill 240 58 43 240 63 43 stone
execute in minecraft:overworld run fill 240 64 43 240 65 43 dirt
execute in minecraft:overworld run setblock 240 66 43 grass_block
execute in minecraft:overworld run fill 240 67 43 240 144 43 air
execute in minecraft:overworld run fill 240 58 44 240 62 44 stone
execute in minecraft:overworld run fill 240 63 44 240 64 44 dirt
execute in minecraft:overworld run setblock 240 65 44 coarse_dirt
execute in minecraft:overworld run fill 240 66 44 240 144 44 air
execute in minecraft:overworld run fill 240 58 45 240 62 45 stone
execute in minecraft:overworld run fill 240 63 45 240 64 45 dirt
execute in minecraft:overworld run setblock 240 65 45 coarse_dirt
execute in minecraft:overworld run fill 240 66 45 240 144 45 air
execute in minecraft:overworld run fill 240 58 46 240 62 46 stone
execute in minecraft:overworld run fill 240 63 46 240 64 46 dirt
execute in minecraft:overworld run setblock 240 65 46 coarse_dirt
execute in minecraft:overworld run fill 240 66 46 240 144 46 air
execute in minecraft:overworld run fill 240 58 47 240 61 47 stone
execute in minecraft:overworld run fill 240 62 47 240 63 47 dirt
execute in minecraft:overworld run setblock 240 64 47 coarse_dirt
execute in minecraft:overworld run fill 240 65 47 240 144 47 air
execute in minecraft:overworld run fill 241 58 -48 241 61 -48 stone
execute in minecraft:overworld run fill 241 62 -48 241 63 -48 dirt
execute in minecraft:overworld run setblock 241 64 -48 grass_block
execute in minecraft:overworld run fill 241 65 -48 241 144 -48 air
execute in minecraft:overworld run fill 241 58 -47 241 62 -47 stone
execute in minecraft:overworld run fill 241 63 -47 241 64 -47 dirt
execute in minecraft:overworld run setblock 241 65 -47 coarse_dirt
execute in minecraft:overworld run fill 241 66 -47 241 144 -47 air
execute in minecraft:overworld run fill 241 58 -46 241 63 -46 stone
execute in minecraft:overworld run fill 241 64 -46 241 65 -46 dirt
execute in minecraft:overworld run setblock 241 66 -46 coarse_dirt
execute in minecraft:overworld run fill 241 67 -46 241 144 -46 air
execute in minecraft:overworld run fill 241 58 -45 241 64 -45 stone
execute in minecraft:overworld run fill 241 65 -45 241 66 -45 dirt
execute in minecraft:overworld run setblock 241 67 -45 grass_block
execute in minecraft:overworld run fill 241 68 -45 241 144 -45 air
execute in minecraft:overworld run fill 241 58 -44 241 65 -44 stone
execute in minecraft:overworld run fill 241 66 -44 241 67 -44 dirt
execute in minecraft:overworld run setblock 241 68 -44 coarse_dirt
execute in minecraft:overworld run fill 241 69 -44 241 144 -44 air
execute in minecraft:overworld run fill 241 58 -43 241 66 -43 stone
execute in minecraft:overworld run fill 241 67 -43 241 68 -43 dirt
execute in minecraft:overworld run setblock 241 69 -43 coarse_dirt
execute in minecraft:overworld run fill 241 70 -43 241 144 -43 air
execute in minecraft:overworld run fill 241 58 -42 241 67 -42 stone
execute in minecraft:overworld run fill 241 68 -42 241 69 -42 dirt
execute in minecraft:overworld run setblock 241 70 -42 grass_block
execute in minecraft:overworld run fill 241 71 -42 241 144 -42 air
execute in minecraft:overworld run fill 241 58 -41 241 68 -41 stone
execute in minecraft:overworld run fill 241 69 -41 241 70 -41 dirt
execute in minecraft:overworld run setblock 241 71 -41 coarse_dirt
execute in minecraft:overworld run fill 241 72 -41 241 144 -41 air
execute in minecraft:overworld run fill 241 58 -40 241 69 -40 stone
execute in minecraft:overworld run fill 241 70 -40 241 71 -40 dirt
execute in minecraft:overworld run setblock 241 72 -40 coarse_dirt
execute in minecraft:overworld run fill 241 73 -40 241 144 -40 air
execute in minecraft:overworld run fill 241 58 -39 241 70 -39 stone
execute in minecraft:overworld run fill 241 71 -39 241 72 -39 dirt
execute in minecraft:overworld run setblock 241 73 -39 coarse_dirt
execute in minecraft:overworld run fill 241 74 -39 241 144 -39 air
execute in minecraft:overworld run fill 241 58 -38 241 71 -38 stone
execute in minecraft:overworld run fill 241 72 -38 241 73 -38 dirt
execute in minecraft:overworld run setblock 241 74 -38 grass_block
execute in minecraft:overworld run fill 241 75 -38 241 144 -38 air
execute in minecraft:overworld run fill 241 58 -37 241 71 -37 stone
execute in minecraft:overworld run fill 241 72 -37 241 73 -37 dirt
execute in minecraft:overworld run setblock 241 74 -37 grass_block
execute in minecraft:overworld run fill 241 75 -37 241 144 -37 air
execute in minecraft:overworld run fill 241 58 -36 241 71 -36 stone
execute in minecraft:overworld run fill 241 72 -36 241 73 -36 dirt
execute in minecraft:overworld run setblock 241 74 -36 coarse_dirt
execute in minecraft:overworld run fill 241 75 -36 241 144 -36 air
execute in minecraft:overworld run fill 241 58 -35 241 71 -35 stone
execute in minecraft:overworld run fill 241 72 -35 241 73 -35 dirt
execute in minecraft:overworld run setblock 241 74 -35 coarse_dirt
execute in minecraft:overworld run fill 241 75 -35 241 144 -35 air
execute in minecraft:overworld run fill 241 58 -34 241 71 -34 stone
execute in minecraft:overworld run fill 241 72 -34 241 73 -34 dirt
execute in minecraft:overworld run setblock 241 74 -34 coarse_dirt
execute in minecraft:overworld run fill 241 75 -34 241 144 -34 air
execute in minecraft:overworld run fill 241 58 -33 241 71 -33 stone
execute in minecraft:overworld run fill 241 72 -33 241 73 -33 dirt
execute in minecraft:overworld run setblock 241 74 -33 grass_block
execute in minecraft:overworld run fill 241 75 -33 241 144 -33 air
execute in minecraft:overworld run fill 241 58 -32 241 71 -32 stone
execute in minecraft:overworld run fill 241 72 -32 241 73 -32 dirt
execute in minecraft:overworld run setblock 241 74 -32 coarse_dirt
execute in minecraft:overworld run fill 241 75 -32 241 144 -32 air
execute in minecraft:overworld run fill 241 58 -31 241 71 -31 stone
execute in minecraft:overworld run fill 241 72 -31 241 73 -31 dirt
execute in minecraft:overworld run setblock 241 74 -31 grass_block
execute in minecraft:overworld run fill 241 75 -31 241 144 -31 air
execute in minecraft:overworld run fill 241 58 -30 241 71 -30 stone
execute in minecraft:overworld run fill 241 72 -30 241 73 -30 dirt
execute in minecraft:overworld run setblock 241 74 -30 coarse_dirt
execute in minecraft:overworld run fill 241 75 -30 241 144 -30 air
execute in minecraft:overworld run fill 241 58 -29 241 71 -29 stone
execute in minecraft:overworld run fill 241 72 -29 241 73 -29 dirt
execute in minecraft:overworld run setblock 241 74 -29 coarse_dirt
execute in minecraft:overworld run fill 241 75 -29 241 144 -29 air
execute in minecraft:overworld run fill 241 58 -28 241 71 -28 stone
execute in minecraft:overworld run fill 241 72 -28 241 73 -28 dirt
execute in minecraft:overworld run setblock 241 74 -28 coarse_dirt
execute in minecraft:overworld run fill 241 75 -28 241 144 -28 air
execute in minecraft:overworld run fill 241 58 -27 241 71 -27 stone
execute in minecraft:overworld run fill 241 72 -27 241 73 -27 dirt
execute in minecraft:overworld run setblock 241 74 -27 grass_block
execute in minecraft:overworld run fill 241 75 -27 241 144 -27 air
execute in minecraft:overworld run fill 241 58 -26 241 71 -26 stone
execute in minecraft:overworld run fill 241 72 -26 241 73 -26 dirt
execute in minecraft:overworld run setblock 241 74 -26 coarse_dirt
execute in minecraft:overworld run fill 241 75 -26 241 144 -26 air
execute in minecraft:overworld run fill 241 58 -25 241 70 -25 stone
execute in minecraft:overworld run fill 241 71 -25 241 72 -25 dirt
execute in minecraft:overworld run setblock 241 73 -25 grass_block
execute in minecraft:overworld run fill 241 74 -25 241 144 -25 air
execute in minecraft:overworld run fill 241 58 -24 241 70 -24 stone
execute in minecraft:overworld run fill 241 71 -24 241 72 -24 dirt
execute in minecraft:overworld run setblock 241 73 -24 grass_block
execute in minecraft:overworld run fill 241 74 -24 241 144 -24 air
execute in minecraft:overworld run fill 241 58 -23 241 70 -23 stone
execute in minecraft:overworld run fill 241 71 -23 241 72 -23 dirt
schedule function blade_gallery:random/burned/part_51 1t replace
