execute in minecraft:overworld run fill 283 77 -31 283 78 -31 dirt
execute in minecraft:overworld run setblock 283 79 -31 coarse_dirt
execute in minecraft:overworld run fill 283 80 -31 283 144 -31 air
execute in minecraft:overworld run fill 283 58 -30 283 76 -30 stone
execute in minecraft:overworld run fill 283 77 -30 283 78 -30 dirt
execute in minecraft:overworld run setblock 283 79 -30 coarse_dirt
execute in minecraft:overworld run fill 283 80 -30 283 144 -30 air
execute in minecraft:overworld run fill 283 58 -29 283 75 -29 stone
execute in minecraft:overworld run fill 283 76 -29 283 77 -29 dirt
execute in minecraft:overworld run setblock 283 78 -29 coarse_dirt
execute in minecraft:overworld run fill 283 79 -29 283 144 -29 air
execute in minecraft:overworld run fill 283 58 -28 283 75 -28 stone
execute in minecraft:overworld run fill 283 76 -28 283 77 -28 dirt
execute in minecraft:overworld run setblock 283 78 -28 coarse_dirt
execute in minecraft:overworld run fill 283 79 -28 283 144 -28 air
execute in minecraft:overworld run fill 283 58 -27 283 75 -27 stone
execute in minecraft:overworld run fill 283 76 -27 283 77 -27 dirt
execute in minecraft:overworld run setblock 283 78 -27 coarse_dirt
execute in minecraft:overworld run fill 283 79 -27 283 144 -27 air
execute in minecraft:overworld run fill 283 58 -26 283 74 -26 stone
execute in minecraft:overworld run fill 283 75 -26 283 76 -26 dirt
execute in minecraft:overworld run setblock 283 77 -26 coarse_dirt
execute in minecraft:overworld run fill 283 78 -26 283 144 -26 air
execute in minecraft:overworld run fill 283 58 -25 283 74 -25 stone
execute in minecraft:overworld run fill 283 75 -25 283 76 -25 dirt
execute in minecraft:overworld run setblock 283 77 -25 grass_block
execute in minecraft:overworld run fill 283 78 -25 283 144 -25 air
execute in minecraft:overworld run fill 283 58 -24 283 74 -24 stone
execute in minecraft:overworld run fill 283 75 -24 283 76 -24 dirt
execute in minecraft:overworld run setblock 283 77 -24 coarse_dirt
execute in minecraft:overworld run fill 283 78 -24 283 144 -24 air
execute in minecraft:overworld run fill 283 58 -23 283 73 -23 stone
execute in minecraft:overworld run fill 283 74 -23 283 75 -23 dirt
execute in minecraft:overworld run setblock 283 76 -23 coarse_dirt
execute in minecraft:overworld run fill 283 77 -23 283 144 -23 air
execute in minecraft:overworld run fill 283 58 -22 283 73 -22 stone
execute in minecraft:overworld run fill 283 74 -22 283 75 -22 dirt
execute in minecraft:overworld run setblock 283 76 -22 coarse_dirt
execute in minecraft:overworld run fill 283 77 -22 283 144 -22 air
execute in minecraft:overworld run fill 283 58 -21 283 73 -21 stone
execute in minecraft:overworld run fill 283 74 -21 283 75 -21 dirt
execute in minecraft:overworld run setblock 283 76 -21 coarse_dirt
execute in minecraft:overworld run fill 283 77 -21 283 144 -21 air
execute in minecraft:overworld run fill 283 58 -20 283 72 -20 stone
execute in minecraft:overworld run fill 283 73 -20 283 74 -20 dirt
execute in minecraft:overworld run setblock 283 75 -20 coarse_dirt
execute in minecraft:overworld run fill 283 76 -20 283 144 -20 air
execute in minecraft:overworld run fill 283 58 -19 283 72 -19 stone
execute in minecraft:overworld run fill 283 73 -19 283 74 -19 dirt
execute in minecraft:overworld run setblock 283 75 -19 coarse_dirt
execute in minecraft:overworld run fill 283 76 -19 283 144 -19 air
execute in minecraft:overworld run fill 283 58 -18 283 72 -18 stone
execute in minecraft:overworld run fill 283 73 -18 283 74 -18 dirt
execute in minecraft:overworld run setblock 283 75 -18 grass_block
execute in minecraft:overworld run fill 283 76 -18 283 144 -18 air
execute in minecraft:overworld run fill 283 58 -17 283 71 -17 stone
execute in minecraft:overworld run fill 283 72 -17 283 73 -17 dirt
execute in minecraft:overworld run setblock 283 74 -17 grass_block
execute in minecraft:overworld run fill 283 75 -17 283 144 -17 air
execute in minecraft:overworld run fill 283 58 -16 283 71 -16 stone
execute in minecraft:overworld run fill 283 72 -16 283 73 -16 dirt
execute in minecraft:overworld run setblock 283 74 -16 grass_block
execute in minecraft:overworld run fill 283 75 -16 283 144 -16 air
execute in minecraft:overworld run fill 283 58 -15 283 70 -15 stone
execute in minecraft:overworld run fill 283 71 -15 283 72 -15 dirt
execute in minecraft:overworld run setblock 283 73 -15 grass_block
execute in minecraft:overworld run fill 283 74 -15 283 144 -15 air
execute in minecraft:overworld run fill 283 58 -14 283 70 -14 stone
execute in minecraft:overworld run fill 283 71 -14 283 72 -14 dirt
execute in minecraft:overworld run setblock 283 73 -14 coarse_dirt
execute in minecraft:overworld run fill 283 74 -14 283 144 -14 air
execute in minecraft:overworld run fill 283 58 -13 283 69 -13 stone
execute in minecraft:overworld run fill 283 70 -13 283 71 -13 dirt
execute in minecraft:overworld run setblock 283 72 -13 grass_block
execute in minecraft:overworld run fill 283 73 -13 283 144 -13 air
execute in minecraft:overworld run fill 283 58 -12 283 69 -12 stone
execute in minecraft:overworld run fill 283 70 -12 283 71 -12 dirt
execute in minecraft:overworld run setblock 283 72 -12 grass_block
execute in minecraft:overworld run fill 283 73 -12 283 144 -12 air
execute in minecraft:overworld run fill 283 58 -11 283 69 -11 stone
execute in minecraft:overworld run fill 283 70 -11 283 71 -11 dirt
execute in minecraft:overworld run setblock 283 72 -11 coarse_dirt
execute in minecraft:overworld run fill 283 73 -11 283 144 -11 air
execute in minecraft:overworld run fill 283 58 -10 283 69 -10 stone
execute in minecraft:overworld run fill 283 70 -10 283 71 -10 dirt
execute in minecraft:overworld run setblock 283 72 -10 grass_block
execute in minecraft:overworld run fill 283 73 -10 283 144 -10 air
execute in minecraft:overworld run fill 283 58 -9 283 69 -9 stone
execute in minecraft:overworld run fill 283 70 -9 283 71 -9 dirt
execute in minecraft:overworld run setblock 283 72 -9 coarse_dirt
execute in minecraft:overworld run fill 283 73 -9 283 144 -9 air
execute in minecraft:overworld run setblock 283 73 -9 grass
execute in minecraft:overworld run fill 283 58 -8 283 69 -8 stone
execute in minecraft:overworld run fill 283 70 -8 283 71 -8 dirt
execute in minecraft:overworld run setblock 283 72 -8 coarse_dirt
execute in minecraft:overworld run fill 283 73 -8 283 144 -8 air
execute in minecraft:overworld run setblock 283 73 -8 grass
execute in minecraft:overworld run fill 283 58 -7 283 69 -7 stone
execute in minecraft:overworld run fill 283 70 -7 283 71 -7 dirt
execute in minecraft:overworld run setblock 283 72 -7 coarse_dirt
execute in minecraft:overworld run fill 283 73 -7 283 144 -7 air
execute in minecraft:overworld run fill 283 58 -6 283 69 -6 stone
execute in minecraft:overworld run fill 283 70 -6 283 71 -6 dirt
execute in minecraft:overworld run setblock 283 72 -6 coarse_dirt
execute in minecraft:overworld run fill 283 73 -6 283 144 -6 air
execute in minecraft:overworld run setblock 283 73 -6 grass
execute in minecraft:overworld run fill 283 58 -5 283 69 -5 stone
execute in minecraft:overworld run fill 283 70 -5 283 71 -5 dirt
execute in minecraft:overworld run setblock 283 72 -5 grass_block
execute in minecraft:overworld run fill 283 73 -5 283 144 -5 air
execute in minecraft:overworld run setblock 283 73 -5 grass
execute in minecraft:overworld run fill 283 58 -4 283 69 -4 stone
execute in minecraft:overworld run fill 283 70 -4 283 71 -4 dirt
execute in minecraft:overworld run setblock 283 72 -4 coarse_dirt
execute in minecraft:overworld run fill 283 73 -4 283 144 -4 air
execute in minecraft:overworld run setblock 283 73 -4 grass
execute in minecraft:overworld run fill 283 58 -3 283 69 -3 stone
execute in minecraft:overworld run fill 283 70 -3 283 71 -3 dirt
execute in minecraft:overworld run setblock 283 72 -3 grass_block
execute in minecraft:overworld run fill 283 73 -3 283 144 -3 air
execute in minecraft:overworld run fill 283 58 -2 283 69 -2 stone
execute in minecraft:overworld run fill 283 70 -2 283 71 -2 dirt
execute in minecraft:overworld run setblock 283 72 -2 grass_block
execute in minecraft:overworld run fill 283 73 -2 283 144 -2 air
execute in minecraft:overworld run fill 283 58 -1 283 69 -1 stone
execute in minecraft:overworld run fill 283 70 -1 283 71 -1 dirt
execute in minecraft:overworld run setblock 283 72 -1 grass_block
execute in minecraft:overworld run fill 283 73 -1 283 144 -1 air
execute in minecraft:overworld run fill 283 58 0 283 69 0 stone
execute in minecraft:overworld run fill 283 70 0 283 71 0 dirt
execute in minecraft:overworld run setblock 283 72 0 grass_block
execute in minecraft:overworld run fill 283 73 0 283 144 0 air
execute in minecraft:overworld run fill 283 58 1 283 68 1 stone
execute in minecraft:overworld run fill 283 69 1 283 70 1 dirt
execute in minecraft:overworld run setblock 283 71 1 coarse_dirt
execute in minecraft:overworld run fill 283 72 1 283 144 1 air
execute in minecraft:overworld run fill 283 58 2 283 68 2 stone
execute in minecraft:overworld run fill 283 69 2 283 70 2 dirt
execute in minecraft:overworld run setblock 283 71 2 coarse_dirt
execute in minecraft:overworld run fill 283 72 2 283 144 2 air
execute in minecraft:overworld run fill 283 58 3 283 68 3 stone
execute in minecraft:overworld run fill 283 69 3 283 70 3 dirt
execute in minecraft:overworld run setblock 283 71 3 coarse_dirt
execute in minecraft:overworld run fill 283 72 3 283 144 3 air
execute in minecraft:overworld run fill 283 58 4 283 68 4 stone
execute in minecraft:overworld run fill 283 69 4 283 70 4 dirt
execute in minecraft:overworld run setblock 283 71 4 coarse_dirt
execute in minecraft:overworld run fill 283 72 4 283 144 4 air
execute in minecraft:overworld run setblock 283 72 4 grass
execute in minecraft:overworld run fill 283 58 5 283 67 5 stone
execute in minecraft:overworld run fill 283 68 5 283 69 5 dirt
execute in minecraft:overworld run setblock 283 70 5 coarse_dirt
execute in minecraft:overworld run fill 283 71 5 283 144 5 air
execute in minecraft:overworld run fill 283 58 6 283 67 6 stone
execute in minecraft:overworld run fill 283 68 6 283 69 6 dirt
execute in minecraft:overworld run setblock 283 70 6 coarse_dirt
execute in minecraft:overworld run fill 283 71 6 283 144 6 air
execute in minecraft:overworld run fill 283 58 7 283 67 7 stone
execute in minecraft:overworld run fill 283 68 7 283 69 7 dirt
execute in minecraft:overworld run setblock 283 70 7 coarse_dirt
execute in minecraft:overworld run fill 283 71 7 283 144 7 air
execute in minecraft:overworld run fill 283 58 8 283 66 8 stone
execute in minecraft:overworld run fill 283 67 8 283 68 8 dirt
execute in minecraft:overworld run setblock 283 69 8 coarse_dirt
execute in minecraft:overworld run fill 283 70 8 283 144 8 air
execute in minecraft:overworld run fill 283 58 9 283 66 9 stone
execute in minecraft:overworld run fill 283 67 9 283 68 9 dirt
execute in minecraft:overworld run setblock 283 69 9 coarse_dirt
execute in minecraft:overworld run fill 283 70 9 283 144 9 air
execute in minecraft:overworld run fill 283 58 10 283 66 10 stone
execute in minecraft:overworld run fill 283 67 10 283 68 10 dirt
execute in minecraft:overworld run setblock 283 69 10 grass_block
execute in minecraft:overworld run fill 283 70 10 283 144 10 air
execute in minecraft:overworld run fill 283 58 11 283 65 11 stone
execute in minecraft:overworld run fill 283 66 11 283 67 11 dirt
execute in minecraft:overworld run setblock 283 68 11 coarse_dirt
execute in minecraft:overworld run fill 283 69 11 283 144 11 air
execute in minecraft:overworld run fill 283 58 12 283 65 12 stone
execute in minecraft:overworld run fill 283 66 12 283 67 12 dirt
execute in minecraft:overworld run setblock 283 68 12 coarse_dirt
execute in minecraft:overworld run fill 283 69 12 283 144 12 air
execute in minecraft:overworld run fill 283 58 13 283 65 13 stone
execute in minecraft:overworld run fill 283 66 13 283 67 13 dirt
execute in minecraft:overworld run setblock 283 68 13 coarse_dirt
execute in minecraft:overworld run fill 283 69 13 283 144 13 air
execute in minecraft:overworld run setblock 283 69 13 grass
execute in minecraft:overworld run fill 283 58 14 283 65 14 stone
execute in minecraft:overworld run fill 283 66 14 283 67 14 dirt
execute in minecraft:overworld run setblock 283 68 14 grass_block
execute in minecraft:overworld run fill 283 69 14 283 144 14 air
execute in minecraft:overworld run fill 283 58 15 283 65 15 stone
execute in minecraft:overworld run fill 283 66 15 283 67 15 dirt
execute in minecraft:overworld run setblock 283 68 15 grass_block
execute in minecraft:overworld run fill 283 69 15 283 144 15 air
execute in minecraft:overworld run fill 283 58 16 283 65 16 stone
execute in minecraft:overworld run fill 283 66 16 283 67 16 dirt
execute in minecraft:overworld run setblock 283 68 16 coarse_dirt
execute in minecraft:overworld run fill 283 69 16 283 144 16 air
execute in minecraft:overworld run setblock 283 69 16 grass
execute in minecraft:overworld run fill 283 58 17 283 65 17 stone
execute in minecraft:overworld run fill 283 66 17 283 67 17 dirt
execute in minecraft:overworld run setblock 283 68 17 coarse_dirt
execute in minecraft:overworld run fill 283 69 17 283 144 17 air
execute in minecraft:overworld run fill 283 58 18 283 64 18 stone
execute in minecraft:overworld run fill 283 65 18 283 66 18 dirt
execute in minecraft:overworld run setblock 283 67 18 coarse_dirt
execute in minecraft:overworld run fill 283 68 18 283 144 18 air
execute in minecraft:overworld run fill 283 58 19 283 64 19 stone
execute in minecraft:overworld run fill 283 65 19 283 66 19 dirt
execute in minecraft:overworld run setblock 283 67 19 coarse_dirt
execute in minecraft:overworld run fill 283 68 19 283 144 19 air
execute in minecraft:overworld run fill 283 58 20 283 64 20 stone
execute in minecraft:overworld run fill 283 65 20 283 66 20 dirt
execute in minecraft:overworld run setblock 283 67 20 grass_block
execute in minecraft:overworld run fill 283 68 20 283 144 20 air
execute in minecraft:overworld run fill 283 58 21 283 64 21 stone
execute in minecraft:overworld run fill 283 65 21 283 66 21 dirt
execute in minecraft:overworld run setblock 283 67 21 coarse_dirt
execute in minecraft:overworld run fill 283 68 21 283 144 21 air
execute in minecraft:overworld run fill 283 58 22 283 64 22 stone
execute in minecraft:overworld run fill 283 65 22 283 66 22 dirt
execute in minecraft:overworld run setblock 283 67 22 coarse_dirt
execute in minecraft:overworld run fill 283 68 22 283 144 22 air
execute in minecraft:overworld run setblock 283 68 22 mossy_cobblestone
execute in minecraft:overworld run fill 283 58 23 283 64 23 stone
execute in minecraft:overworld run fill 283 65 23 283 66 23 dirt
execute in minecraft:overworld run setblock 283 67 23 coarse_dirt
execute in minecraft:overworld run fill 283 68 23 283 144 23 air
execute in minecraft:overworld run fill 283 58 24 283 64 24 stone
execute in minecraft:overworld run fill 283 65 24 283 66 24 dirt
execute in minecraft:overworld run setblock 283 67 24 coarse_dirt
execute in minecraft:overworld run fill 283 68 24 283 144 24 air
execute in minecraft:overworld run fill 283 58 25 283 64 25 stone
execute in minecraft:overworld run fill 283 65 25 283 66 25 dirt
execute in minecraft:overworld run setblock 283 67 25 coarse_dirt
execute in minecraft:overworld run fill 283 68 25 283 144 25 air
execute in minecraft:overworld run setblock 283 68 25 grass
execute in minecraft:overworld run fill 283 58 26 283 64 26 stone
execute in minecraft:overworld run fill 283 65 26 283 66 26 dirt
execute in minecraft:overworld run setblock 283 67 26 coarse_dirt
execute in minecraft:overworld run fill 283 68 26 283 144 26 air
execute in minecraft:overworld run fill 283 58 27 283 64 27 stone
execute in minecraft:overworld run fill 283 65 27 283 66 27 dirt
execute in minecraft:overworld run setblock 283 67 27 coarse_dirt
execute in minecraft:overworld run fill 283 68 27 283 144 27 air
execute in minecraft:overworld run fill 283 58 28 283 63 28 stone
execute in minecraft:overworld run fill 283 64 28 283 65 28 dirt
execute in minecraft:overworld run setblock 283 66 28 grass_block
execute in minecraft:overworld run fill 283 67 28 283 144 28 air
execute in minecraft:overworld run fill 283 58 29 283 63 29 stone
execute in minecraft:overworld run fill 283 64 29 283 65 29 dirt
execute in minecraft:overworld run setblock 283 66 29 grass_block
execute in minecraft:overworld run fill 283 67 29 283 144 29 air
execute in minecraft:overworld run fill 283 58 30 283 63 30 stone
execute in minecraft:overworld run fill 283 64 30 283 65 30 dirt
execute in minecraft:overworld run setblock 283 66 30 coarse_dirt
schedule function blade_gallery:random/burned/part_120 1t replace
