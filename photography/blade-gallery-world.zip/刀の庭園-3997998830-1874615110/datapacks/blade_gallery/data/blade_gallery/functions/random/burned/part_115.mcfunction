execute in minecraft:overworld run fill 280 58 8 280 66 8 stone
execute in minecraft:overworld run fill 280 67 8 280 68 8 dirt
execute in minecraft:overworld run setblock 280 69 8 coarse_dirt
execute in minecraft:overworld run fill 280 70 8 280 144 8 air
execute in minecraft:overworld run fill 280 58 9 280 65 9 stone
execute in minecraft:overworld run fill 280 66 9 280 67 9 dirt
execute in minecraft:overworld run setblock 280 68 9 grass_block
execute in minecraft:overworld run fill 280 69 9 280 144 9 air
execute in minecraft:overworld run setblock 280 69 9 grass
execute in minecraft:overworld run fill 280 58 10 280 65 10 stone
execute in minecraft:overworld run fill 280 66 10 280 67 10 dirt
execute in minecraft:overworld run setblock 280 68 10 grass_block
execute in minecraft:overworld run fill 280 69 10 280 144 10 air
execute in minecraft:overworld run fill 280 58 11 280 65 11 stone
execute in minecraft:overworld run fill 280 66 11 280 67 11 dirt
execute in minecraft:overworld run setblock 280 68 11 coarse_dirt
execute in minecraft:overworld run fill 280 69 11 280 144 11 air
execute in minecraft:overworld run fill 280 58 12 280 65 12 stone
execute in minecraft:overworld run fill 280 66 12 280 67 12 dirt
execute in minecraft:overworld run setblock 280 68 12 coarse_dirt
execute in minecraft:overworld run fill 280 69 12 280 144 12 air
execute in minecraft:overworld run fill 280 58 13 280 65 13 stone
execute in minecraft:overworld run fill 280 66 13 280 67 13 dirt
execute in minecraft:overworld run setblock 280 68 13 grass_block
execute in minecraft:overworld run fill 280 69 13 280 144 13 air
execute in minecraft:overworld run fill 280 58 14 280 64 14 stone
execute in minecraft:overworld run fill 280 65 14 280 66 14 dirt
execute in minecraft:overworld run setblock 280 67 14 grass_block
execute in minecraft:overworld run fill 280 68 14 280 144 14 air
execute in minecraft:overworld run fill 280 58 15 280 64 15 stone
execute in minecraft:overworld run fill 280 65 15 280 66 15 dirt
execute in minecraft:overworld run setblock 280 67 15 grass_block
execute in minecraft:overworld run fill 280 68 15 280 144 15 air
execute in minecraft:overworld run fill 280 58 16 280 64 16 stone
execute in minecraft:overworld run fill 280 65 16 280 66 16 dirt
execute in minecraft:overworld run setblock 280 67 16 grass_block
execute in minecraft:overworld run fill 280 68 16 280 144 16 air
execute in minecraft:overworld run setblock 280 68 16 grass
execute in minecraft:overworld run fill 280 58 17 280 64 17 stone
execute in minecraft:overworld run fill 280 65 17 280 66 17 dirt
execute in minecraft:overworld run setblock 280 67 17 grass_block
execute in minecraft:overworld run fill 280 68 17 280 144 17 air
execute in minecraft:overworld run fill 280 58 18 280 64 18 stone
execute in minecraft:overworld run fill 280 65 18 280 66 18 dirt
execute in minecraft:overworld run setblock 280 67 18 coarse_dirt
execute in minecraft:overworld run fill 280 68 18 280 144 18 air
execute in minecraft:overworld run fill 280 58 19 280 64 19 stone
execute in minecraft:overworld run fill 280 65 19 280 66 19 dirt
execute in minecraft:overworld run setblock 280 67 19 coarse_dirt
execute in minecraft:overworld run fill 280 68 19 280 144 19 air
execute in minecraft:overworld run setblock 280 68 19 mossy_cobblestone
execute in minecraft:overworld run fill 280 58 20 280 63 20 stone
execute in minecraft:overworld run fill 280 64 20 280 65 20 dirt
execute in minecraft:overworld run setblock 280 66 20 coarse_dirt
execute in minecraft:overworld run fill 280 67 20 280 144 20 air
execute in minecraft:overworld run fill 280 58 21 280 63 21 stone
execute in minecraft:overworld run fill 280 64 21 280 65 21 dirt
execute in minecraft:overworld run setblock 280 66 21 coarse_dirt
execute in minecraft:overworld run fill 280 67 21 280 144 21 air
execute in minecraft:overworld run fill 280 58 22 280 63 22 stone
execute in minecraft:overworld run fill 280 64 22 280 65 22 dirt
execute in minecraft:overworld run setblock 280 66 22 coarse_dirt
execute in minecraft:overworld run fill 280 67 22 280 144 22 air
execute in minecraft:overworld run fill 280 58 23 280 63 23 stone
execute in minecraft:overworld run fill 280 64 23 280 65 23 dirt
execute in minecraft:overworld run setblock 280 66 23 coarse_dirt
execute in minecraft:overworld run fill 280 67 23 280 144 23 air
execute in minecraft:overworld run fill 280 58 24 280 63 24 stone
execute in minecraft:overworld run fill 280 64 24 280 65 24 dirt
execute in minecraft:overworld run setblock 280 66 24 coarse_dirt
execute in minecraft:overworld run fill 280 67 24 280 144 24 air
execute in minecraft:overworld run setblock 280 67 24 mossy_cobblestone
execute in minecraft:overworld run fill 280 58 25 280 63 25 stone
execute in minecraft:overworld run fill 280 64 25 280 65 25 dirt
execute in minecraft:overworld run setblock 280 66 25 grass_block
execute in minecraft:overworld run fill 280 67 25 280 144 25 air
execute in minecraft:overworld run fill 280 58 26 280 63 26 stone
execute in minecraft:overworld run fill 280 64 26 280 65 26 dirt
execute in minecraft:overworld run setblock 280 66 26 grass_block
execute in minecraft:overworld run fill 280 67 26 280 144 26 air
execute in minecraft:overworld run setblock 280 67 26 mossy_cobblestone
execute in minecraft:overworld run fill 280 58 27 280 63 27 stone
execute in minecraft:overworld run fill 280 64 27 280 65 27 dirt
execute in minecraft:overworld run setblock 280 66 27 grass_block
execute in minecraft:overworld run fill 280 67 27 280 144 27 air
execute in minecraft:overworld run fill 280 58 28 280 63 28 stone
execute in minecraft:overworld run fill 280 64 28 280 65 28 dirt
execute in minecraft:overworld run setblock 280 66 28 coarse_dirt
execute in minecraft:overworld run fill 280 67 28 280 144 28 air
execute in minecraft:overworld run setblock 280 67 28 grass
execute in minecraft:overworld run fill 280 58 29 280 63 29 stone
execute in minecraft:overworld run fill 280 64 29 280 65 29 dirt
execute in minecraft:overworld run setblock 280 66 29 coarse_dirt
execute in minecraft:overworld run fill 280 67 29 280 144 29 air
execute in minecraft:overworld run fill 280 58 30 280 62 30 stone
execute in minecraft:overworld run fill 280 63 30 280 64 30 dirt
execute in minecraft:overworld run setblock 280 65 30 coarse_dirt
execute in minecraft:overworld run fill 280 66 30 280 144 30 air
execute in minecraft:overworld run fill 280 58 31 280 62 31 stone
execute in minecraft:overworld run fill 280 63 31 280 64 31 dirt
execute in minecraft:overworld run setblock 280 65 31 coarse_dirt
execute in minecraft:overworld run fill 280 66 31 280 144 31 air
execute in minecraft:overworld run fill 280 58 32 280 62 32 stone
execute in minecraft:overworld run fill 280 63 32 280 64 32 dirt
execute in minecraft:overworld run setblock 280 65 32 coarse_dirt
execute in minecraft:overworld run fill 280 66 32 280 144 32 air
execute in minecraft:overworld run setblock 280 66 32 grass
execute in minecraft:overworld run fill 280 58 33 280 62 33 stone
execute in minecraft:overworld run fill 280 63 33 280 64 33 dirt
execute in minecraft:overworld run setblock 280 65 33 coarse_dirt
execute in minecraft:overworld run fill 280 66 33 280 144 33 air
execute in minecraft:overworld run fill 280 58 34 280 61 34 stone
execute in minecraft:overworld run fill 280 62 34 280 63 34 dirt
execute in minecraft:overworld run setblock 280 64 34 grass_block
execute in minecraft:overworld run fill 280 65 34 280 144 34 air
execute in minecraft:overworld run fill 280 58 35 280 61 35 stone
execute in minecraft:overworld run fill 280 62 35 280 63 35 dirt
execute in minecraft:overworld run setblock 280 64 35 coarse_dirt
execute in minecraft:overworld run fill 280 65 35 280 144 35 air
execute in minecraft:overworld run fill 280 58 36 280 61 36 stone
execute in minecraft:overworld run fill 280 62 36 280 63 36 dirt
execute in minecraft:overworld run setblock 280 64 36 grass_block
execute in minecraft:overworld run fill 280 65 36 280 144 36 air
execute in minecraft:overworld run fill 280 58 37 280 61 37 stone
execute in minecraft:overworld run fill 280 62 37 280 63 37 dirt
execute in minecraft:overworld run setblock 280 64 37 coarse_dirt
execute in minecraft:overworld run fill 280 65 37 280 144 37 air
execute in minecraft:overworld run fill 280 58 38 280 61 38 stone
execute in minecraft:overworld run fill 280 62 38 280 63 38 dirt
execute in minecraft:overworld run setblock 280 64 38 coarse_dirt
execute in minecraft:overworld run fill 280 65 38 280 144 38 air
execute in minecraft:overworld run fill 280 58 39 280 61 39 stone
execute in minecraft:overworld run fill 280 62 39 280 63 39 dirt
execute in minecraft:overworld run setblock 280 64 39 coarse_dirt
execute in minecraft:overworld run fill 280 65 39 280 144 39 air
execute in minecraft:overworld run fill 280 58 40 280 61 40 stone
execute in minecraft:overworld run fill 280 62 40 280 63 40 dirt
execute in minecraft:overworld run setblock 280 64 40 grass_block
execute in minecraft:overworld run fill 280 65 40 280 144 40 air
execute in minecraft:overworld run fill 280 58 41 280 61 41 stone
execute in minecraft:overworld run fill 280 62 41 280 63 41 dirt
execute in minecraft:overworld run setblock 280 64 41 coarse_dirt
execute in minecraft:overworld run fill 280 65 41 280 144 41 air
execute in minecraft:overworld run fill 280 58 42 280 61 42 stone
execute in minecraft:overworld run fill 280 62 42 280 63 42 dirt
execute in minecraft:overworld run setblock 280 64 42 coarse_dirt
execute in minecraft:overworld run fill 280 65 42 280 144 42 air
execute in minecraft:overworld run fill 280 58 43 280 61 43 stone
execute in minecraft:overworld run fill 280 62 43 280 63 43 dirt
execute in minecraft:overworld run setblock 280 64 43 coarse_dirt
execute in minecraft:overworld run fill 280 65 43 280 144 43 air
execute in minecraft:overworld run fill 280 58 44 280 61 44 stone
execute in minecraft:overworld run fill 280 62 44 280 63 44 dirt
execute in minecraft:overworld run setblock 280 64 44 grass_block
execute in minecraft:overworld run fill 280 65 44 280 144 44 air
execute in minecraft:overworld run fill 280 58 45 280 61 45 stone
execute in minecraft:overworld run fill 280 62 45 280 63 45 dirt
execute in minecraft:overworld run setblock 280 64 45 coarse_dirt
execute in minecraft:overworld run fill 280 65 45 280 144 45 air
execute in minecraft:overworld run fill 280 58 46 280 61 46 stone
execute in minecraft:overworld run fill 280 62 46 280 63 46 dirt
execute in minecraft:overworld run setblock 280 64 46 grass_block
execute in minecraft:overworld run fill 280 65 46 280 144 46 air
execute in minecraft:overworld run fill 280 58 47 280 61 47 stone
execute in minecraft:overworld run fill 280 62 47 280 63 47 dirt
execute in minecraft:overworld run setblock 280 64 47 grass_block
execute in minecraft:overworld run fill 280 65 47 280 144 47 air
execute in minecraft:overworld run fill 281 58 -48 281 61 -48 stone
execute in minecraft:overworld run fill 281 62 -48 281 63 -48 dirt
execute in minecraft:overworld run setblock 281 64 -48 grass_block
execute in minecraft:overworld run fill 281 65 -48 281 144 -48 air
execute in minecraft:overworld run fill 281 58 -47 281 63 -47 stone
execute in minecraft:overworld run fill 281 64 -47 281 65 -47 dirt
execute in minecraft:overworld run setblock 281 66 -47 coarse_dirt
execute in minecraft:overworld run fill 281 67 -47 281 144 -47 air
execute in minecraft:overworld run fill 281 58 -46 281 65 -46 stone
execute in minecraft:overworld run fill 281 66 -46 281 67 -46 dirt
execute in minecraft:overworld run setblock 281 68 -46 grass_block
execute in minecraft:overworld run fill 281 69 -46 281 144 -46 air
execute in minecraft:overworld run fill 281 58 -45 281 68 -45 stone
execute in minecraft:overworld run fill 281 69 -45 281 70 -45 dirt
execute in minecraft:overworld run setblock 281 71 -45 coarse_dirt
execute in minecraft:overworld run fill 281 72 -45 281 144 -45 air
execute in minecraft:overworld run fill 281 58 -44 281 70 -44 stone
execute in minecraft:overworld run fill 281 71 -44 281 72 -44 dirt
execute in minecraft:overworld run setblock 281 73 -44 grass_block
execute in minecraft:overworld run fill 281 74 -44 281 144 -44 air
execute in minecraft:overworld run fill 281 58 -43 281 72 -43 stone
execute in minecraft:overworld run fill 281 73 -43 281 74 -43 dirt
execute in minecraft:overworld run setblock 281 75 -43 coarse_dirt
execute in minecraft:overworld run fill 281 76 -43 281 144 -43 air
execute in minecraft:overworld run fill 281 58 -42 281 73 -42 stone
execute in minecraft:overworld run fill 281 74 -42 281 75 -42 dirt
execute in minecraft:overworld run setblock 281 76 -42 coarse_dirt
execute in minecraft:overworld run fill 281 77 -42 281 144 -42 air
execute in minecraft:overworld run fill 281 58 -41 281 75 -41 stone
execute in minecraft:overworld run fill 281 76 -41 281 77 -41 dirt
execute in minecraft:overworld run setblock 281 78 -41 coarse_dirt
execute in minecraft:overworld run fill 281 79 -41 281 144 -41 air
execute in minecraft:overworld run setblock 281 79 -41 grass
execute in minecraft:overworld run fill 281 58 -40 281 77 -40 stone
execute in minecraft:overworld run fill 281 78 -40 281 79 -40 dirt
execute in minecraft:overworld run setblock 281 80 -40 coarse_dirt
execute in minecraft:overworld run fill 281 81 -40 281 144 -40 air
execute in minecraft:overworld run fill 281 58 -39 281 78 -39 stone
execute in minecraft:overworld run fill 281 79 -39 281 80 -39 dirt
execute in minecraft:overworld run setblock 281 81 -39 coarse_dirt
execute in minecraft:overworld run fill 281 82 -39 281 144 -39 air
execute in minecraft:overworld run fill 281 58 -38 281 79 -38 stone
execute in minecraft:overworld run fill 281 80 -38 281 81 -38 dirt
execute in minecraft:overworld run setblock 281 82 -38 grass_block
execute in minecraft:overworld run fill 281 83 -38 281 144 -38 air
execute in minecraft:overworld run fill 281 58 -37 281 79 -37 stone
execute in minecraft:overworld run fill 281 80 -37 281 81 -37 dirt
execute in minecraft:overworld run setblock 281 82 -37 grass_block
execute in minecraft:overworld run fill 281 83 -37 281 144 -37 air
execute in minecraft:overworld run fill 281 58 -36 281 78 -36 stone
execute in minecraft:overworld run fill 281 79 -36 281 80 -36 dirt
execute in minecraft:overworld run setblock 281 81 -36 coarse_dirt
execute in minecraft:overworld run fill 281 82 -36 281 144 -36 air
execute in minecraft:overworld run setblock 281 82 -36 grass
execute in minecraft:overworld run fill 281 58 -35 281 78 -35 stone
execute in minecraft:overworld run fill 281 79 -35 281 80 -35 dirt
execute in minecraft:overworld run setblock 281 81 -35 grass_block
execute in minecraft:overworld run fill 281 82 -35 281 144 -35 air
execute in minecraft:overworld run setblock 281 82 -35 grass
execute in minecraft:overworld run fill 281 58 -34 281 78 -34 stone
execute in minecraft:overworld run fill 281 79 -34 281 80 -34 dirt
execute in minecraft:overworld run setblock 281 81 -34 grass_block
execute in minecraft:overworld run fill 281 82 -34 281 144 -34 air
execute in minecraft:overworld run fill 281 58 -33 281 77 -33 stone
execute in minecraft:overworld run fill 281 78 -33 281 79 -33 dirt
execute in minecraft:overworld run setblock 281 80 -33 coarse_dirt
execute in minecraft:overworld run fill 281 81 -33 281 144 -33 air
execute in minecraft:overworld run fill 281 58 -32 281 77 -32 stone
execute in minecraft:overworld run fill 281 78 -32 281 79 -32 dirt
execute in minecraft:overworld run setblock 281 80 -32 coarse_dirt
execute in minecraft:overworld run fill 281 81 -32 281 144 -32 air
execute in minecraft:overworld run fill 281 58 -31 281 76 -31 stone
execute in minecraft:overworld run fill 281 77 -31 281 78 -31 dirt
execute in minecraft:overworld run setblock 281 79 -31 coarse_dirt
execute in minecraft:overworld run fill 281 80 -31 281 144 -31 air
execute in minecraft:overworld run fill 281 58 -30 281 76 -30 stone
execute in minecraft:overworld run fill 281 77 -30 281 78 -30 dirt
execute in minecraft:overworld run setblock 281 79 -30 grass_block
execute in minecraft:overworld run fill 281 80 -30 281 144 -30 air
execute in minecraft:overworld run fill 281 58 -29 281 76 -29 stone
execute in minecraft:overworld run fill 281 77 -29 281 78 -29 dirt
execute in minecraft:overworld run setblock 281 79 -29 coarse_dirt
execute in minecraft:overworld run fill 281 80 -29 281 144 -29 air
execute in minecraft:overworld run fill 281 58 -28 281 75 -28 stone
execute in minecraft:overworld run fill 281 76 -28 281 77 -28 dirt
execute in minecraft:overworld run setblock 281 78 -28 coarse_dirt
execute in minecraft:overworld run fill 281 79 -28 281 144 -28 air
execute in minecraft:overworld run fill 281 58 -27 281 75 -27 stone
execute in minecraft:overworld run fill 281 76 -27 281 77 -27 dirt
schedule function blade_gallery:random/burned/part_116 1t replace
