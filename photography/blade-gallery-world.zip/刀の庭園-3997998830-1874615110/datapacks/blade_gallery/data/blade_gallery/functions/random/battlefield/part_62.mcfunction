execute in minecraft:overworld run fill 376 69 -6 376 144 -6 air
execute in minecraft:overworld run fill 376 58 -5 376 65 -5 stone
execute in minecraft:overworld run fill 376 66 -5 376 67 -5 dirt
execute in minecraft:overworld run setblock 376 68 -5 coarse_dirt
execute in minecraft:overworld run fill 376 69 -5 376 144 -5 air
execute in minecraft:overworld run fill 376 58 -4 376 65 -4 stone
execute in minecraft:overworld run fill 376 66 -4 376 67 -4 dirt
execute in minecraft:overworld run setblock 376 68 -4 grass_block
execute in minecraft:overworld run fill 376 69 -4 376 144 -4 air
execute in minecraft:overworld run fill 376 58 -3 376 65 -3 stone
execute in minecraft:overworld run fill 376 66 -3 376 67 -3 dirt
execute in minecraft:overworld run setblock 376 68 -3 coarse_dirt
execute in minecraft:overworld run fill 376 69 -3 376 144 -3 air
execute in minecraft:overworld run fill 376 58 -2 376 65 -2 stone
execute in minecraft:overworld run fill 376 66 -2 376 67 -2 dirt
execute in minecraft:overworld run setblock 376 68 -2 grass_block
execute in minecraft:overworld run fill 376 69 -2 376 144 -2 air
execute in minecraft:overworld run fill 376 58 -1 376 65 -1 stone
execute in minecraft:overworld run fill 376 66 -1 376 67 -1 dirt
execute in minecraft:overworld run setblock 376 68 -1 coarse_dirt
execute in minecraft:overworld run fill 376 69 -1 376 144 -1 air
execute in minecraft:overworld run fill 376 58 0 376 65 0 stone
execute in minecraft:overworld run fill 376 66 0 376 67 0 dirt
execute in minecraft:overworld run setblock 376 68 0 coarse_dirt
execute in minecraft:overworld run fill 376 69 0 376 144 0 air
execute in minecraft:overworld run fill 376 58 1 376 65 1 stone
execute in minecraft:overworld run fill 376 66 1 376 67 1 dirt
execute in minecraft:overworld run setblock 376 68 1 coarse_dirt
execute in minecraft:overworld run fill 376 69 1 376 144 1 air
execute in minecraft:overworld run fill 376 58 2 376 65 2 stone
execute in minecraft:overworld run fill 376 66 2 376 67 2 dirt
execute in minecraft:overworld run setblock 376 68 2 coarse_dirt
execute in minecraft:overworld run fill 376 69 2 376 144 2 air
execute in minecraft:overworld run fill 376 58 3 376 65 3 stone
execute in minecraft:overworld run fill 376 66 3 376 67 3 dirt
execute in minecraft:overworld run setblock 376 68 3 coarse_dirt
execute in minecraft:overworld run fill 376 69 3 376 144 3 air
execute in minecraft:overworld run setblock 376 69 3 grass
execute in minecraft:overworld run fill 376 58 4 376 65 4 stone
execute in minecraft:overworld run fill 376 66 4 376 67 4 dirt
execute in minecraft:overworld run setblock 376 68 4 grass_block
execute in minecraft:overworld run fill 376 69 4 376 144 4 air
execute in minecraft:overworld run fill 376 58 5 376 65 5 stone
execute in minecraft:overworld run fill 376 66 5 376 67 5 dirt
execute in minecraft:overworld run setblock 376 68 5 coarse_dirt
execute in minecraft:overworld run fill 376 69 5 376 144 5 air
execute in minecraft:overworld run fill 376 58 6 376 65 6 stone
execute in minecraft:overworld run fill 376 66 6 376 67 6 dirt
execute in minecraft:overworld run setblock 376 68 6 grass_block
execute in minecraft:overworld run fill 376 69 6 376 144 6 air
execute in minecraft:overworld run fill 376 58 7 376 65 7 stone
execute in minecraft:overworld run fill 376 66 7 376 67 7 dirt
execute in minecraft:overworld run setblock 376 68 7 grass_block
execute in minecraft:overworld run fill 376 69 7 376 144 7 air
execute in minecraft:overworld run fill 376 58 8 376 65 8 stone
execute in minecraft:overworld run fill 376 66 8 376 67 8 dirt
execute in minecraft:overworld run setblock 376 68 8 coarse_dirt
execute in minecraft:overworld run fill 376 69 8 376 144 8 air
execute in minecraft:overworld run fill 376 58 9 376 66 9 stone
execute in minecraft:overworld run fill 376 67 9 376 68 9 dirt
execute in minecraft:overworld run setblock 376 69 9 coarse_dirt
execute in minecraft:overworld run fill 376 70 9 376 144 9 air
execute in minecraft:overworld run setblock 376 70 9 grass
execute in minecraft:overworld run fill 376 58 10 376 66 10 stone
execute in minecraft:overworld run fill 376 67 10 376 68 10 dirt
execute in minecraft:overworld run setblock 376 69 10 grass_block
execute in minecraft:overworld run fill 376 70 10 376 144 10 air
execute in minecraft:overworld run fill 376 58 11 376 66 11 stone
execute in minecraft:overworld run fill 376 67 11 376 68 11 dirt
execute in minecraft:overworld run setblock 376 69 11 coarse_dirt
execute in minecraft:overworld run fill 376 70 11 376 144 11 air
execute in minecraft:overworld run fill 376 58 12 376 66 12 stone
execute in minecraft:overworld run fill 376 67 12 376 68 12 dirt
execute in minecraft:overworld run setblock 376 69 12 coarse_dirt
execute in minecraft:overworld run fill 376 70 12 376 144 12 air
execute in minecraft:overworld run fill 376 58 13 376 67 13 stone
execute in minecraft:overworld run fill 376 68 13 376 69 13 dirt
execute in minecraft:overworld run setblock 376 70 13 coarse_dirt
execute in minecraft:overworld run fill 376 71 13 376 144 13 air
execute in minecraft:overworld run setblock 376 71 13 grass
execute in minecraft:overworld run fill 376 58 14 376 67 14 stone
execute in minecraft:overworld run fill 376 68 14 376 69 14 dirt
execute in minecraft:overworld run setblock 376 70 14 grass_block
execute in minecraft:overworld run fill 376 71 14 376 144 14 air
execute in minecraft:overworld run fill 376 58 15 376 67 15 stone
execute in minecraft:overworld run fill 376 68 15 376 69 15 dirt
execute in minecraft:overworld run setblock 376 70 15 coarse_dirt
execute in minecraft:overworld run fill 376 71 15 376 144 15 air
execute in minecraft:overworld run setblock 376 71 15 grass
execute in minecraft:overworld run fill 376 58 16 376 68 16 stone
execute in minecraft:overworld run fill 376 69 16 376 70 16 dirt
execute in minecraft:overworld run setblock 376 71 16 coarse_dirt
execute in minecraft:overworld run fill 376 72 16 376 144 16 air
execute in minecraft:overworld run fill 376 58 17 376 68 17 stone
execute in minecraft:overworld run fill 376 69 17 376 70 17 dirt
execute in minecraft:overworld run setblock 376 71 17 grass_block
execute in minecraft:overworld run fill 376 72 17 376 144 17 air
execute in minecraft:overworld run fill 376 58 18 376 68 18 stone
execute in minecraft:overworld run fill 376 69 18 376 70 18 dirt
execute in minecraft:overworld run setblock 376 71 18 coarse_dirt
execute in minecraft:overworld run fill 376 72 18 376 144 18 air
execute in minecraft:overworld run setblock 376 72 18 grass
execute in minecraft:overworld run fill 376 58 19 376 68 19 stone
execute in minecraft:overworld run fill 376 69 19 376 70 19 dirt
execute in minecraft:overworld run setblock 376 71 19 coarse_dirt
execute in minecraft:overworld run fill 376 72 19 376 144 19 air
execute in minecraft:overworld run fill 376 58 20 376 68 20 stone
execute in minecraft:overworld run fill 376 69 20 376 70 20 dirt
execute in minecraft:overworld run setblock 376 71 20 coarse_dirt
execute in minecraft:overworld run fill 376 72 20 376 144 20 air
execute in minecraft:overworld run fill 376 58 21 376 68 21 stone
execute in minecraft:overworld run fill 376 69 21 376 70 21 dirt
execute in minecraft:overworld run setblock 376 71 21 coarse_dirt
execute in minecraft:overworld run fill 376 72 21 376 144 21 air
execute in minecraft:overworld run fill 376 58 22 376 68 22 stone
execute in minecraft:overworld run fill 376 69 22 376 70 22 dirt
execute in minecraft:overworld run setblock 376 71 22 coarse_dirt
execute in minecraft:overworld run fill 376 72 22 376 144 22 air
execute in minecraft:overworld run fill 376 58 23 376 68 23 stone
execute in minecraft:overworld run fill 376 69 23 376 70 23 dirt
execute in minecraft:overworld run setblock 376 71 23 coarse_dirt
execute in minecraft:overworld run fill 376 72 23 376 144 23 air
execute in minecraft:overworld run fill 376 58 24 376 67 24 stone
execute in minecraft:overworld run fill 376 68 24 376 69 24 dirt
execute in minecraft:overworld run setblock 376 70 24 grass_block
execute in minecraft:overworld run fill 376 71 24 376 144 24 air
execute in minecraft:overworld run fill 376 58 25 376 67 25 stone
execute in minecraft:overworld run fill 376 68 25 376 69 25 dirt
execute in minecraft:overworld run setblock 376 70 25 coarse_dirt
execute in minecraft:overworld run fill 376 71 25 376 144 25 air
execute in minecraft:overworld run fill 376 58 26 376 67 26 stone
execute in minecraft:overworld run fill 376 68 26 376 69 26 dirt
execute in minecraft:overworld run setblock 376 70 26 coarse_dirt
execute in minecraft:overworld run fill 376 71 26 376 144 26 air
execute in minecraft:overworld run setblock 376 71 26 mossy_cobblestone
execute in minecraft:overworld run fill 376 58 27 376 67 27 stone
execute in minecraft:overworld run fill 376 68 27 376 69 27 dirt
execute in minecraft:overworld run setblock 376 70 27 coarse_dirt
execute in minecraft:overworld run fill 376 71 27 376 144 27 air
execute in minecraft:overworld run fill 376 58 28 376 67 28 stone
execute in minecraft:overworld run fill 376 68 28 376 69 28 dirt
execute in minecraft:overworld run setblock 376 70 28 coarse_dirt
execute in minecraft:overworld run fill 376 71 28 376 144 28 air
execute in minecraft:overworld run fill 376 58 29 376 67 29 stone
execute in minecraft:overworld run fill 376 68 29 376 69 29 dirt
execute in minecraft:overworld run setblock 376 70 29 coarse_dirt
execute in minecraft:overworld run fill 376 71 29 376 144 29 air
execute in minecraft:overworld run fill 376 58 30 376 67 30 stone
execute in minecraft:overworld run fill 376 68 30 376 69 30 dirt
execute in minecraft:overworld run setblock 376 70 30 grass_block
execute in minecraft:overworld run fill 376 71 30 376 144 30 air
execute in minecraft:overworld run fill 376 58 31 376 67 31 stone
execute in minecraft:overworld run fill 376 68 31 376 69 31 dirt
execute in minecraft:overworld run setblock 376 70 31 coarse_dirt
execute in minecraft:overworld run fill 376 71 31 376 144 31 air
execute in minecraft:overworld run fill 376 58 32 376 67 32 stone
execute in minecraft:overworld run fill 376 68 32 376 69 32 dirt
execute in minecraft:overworld run setblock 376 70 32 coarse_dirt
execute in minecraft:overworld run fill 376 71 32 376 144 32 air
execute in minecraft:overworld run setblock 376 71 32 grass
execute in minecraft:overworld run fill 376 58 33 376 67 33 stone
execute in minecraft:overworld run fill 376 68 33 376 69 33 dirt
execute in minecraft:overworld run setblock 376 70 33 coarse_dirt
execute in minecraft:overworld run fill 376 71 33 376 144 33 air
execute in minecraft:overworld run fill 376 58 34 376 68 34 stone
execute in minecraft:overworld run fill 376 69 34 376 70 34 dirt
execute in minecraft:overworld run setblock 376 71 34 coarse_dirt
execute in minecraft:overworld run fill 376 72 34 376 144 34 air
execute in minecraft:overworld run fill 376 58 35 376 68 35 stone
execute in minecraft:overworld run fill 376 69 35 376 70 35 dirt
execute in minecraft:overworld run setblock 376 71 35 coarse_dirt
execute in minecraft:overworld run fill 376 72 35 376 144 35 air
execute in minecraft:overworld run fill 376 58 36 376 68 36 stone
execute in minecraft:overworld run fill 376 69 36 376 70 36 dirt
execute in minecraft:overworld run setblock 376 71 36 grass_block
execute in minecraft:overworld run fill 376 72 36 376 144 36 air
execute in minecraft:overworld run setblock 376 72 36 grass
execute in minecraft:overworld run fill 376 58 37 376 68 37 stone
execute in minecraft:overworld run fill 376 69 37 376 70 37 dirt
execute in minecraft:overworld run setblock 376 71 37 coarse_dirt
execute in minecraft:overworld run fill 376 72 37 376 144 37 air
execute in minecraft:overworld run fill 376 58 38 376 68 38 stone
execute in minecraft:overworld run fill 376 69 38 376 70 38 dirt
execute in minecraft:overworld run setblock 376 71 38 coarse_dirt
execute in minecraft:overworld run fill 376 72 38 376 144 38 air
execute in minecraft:overworld run setblock 376 72 38 grass
execute in minecraft:overworld run fill 376 58 39 376 67 39 stone
execute in minecraft:overworld run fill 376 68 39 376 69 39 dirt
execute in minecraft:overworld run setblock 376 70 39 coarse_dirt
execute in minecraft:overworld run fill 376 71 39 376 144 39 air
execute in minecraft:overworld run fill 376 58 40 376 66 40 stone
execute in minecraft:overworld run fill 376 67 40 376 68 40 dirt
execute in minecraft:overworld run setblock 376 69 40 grass_block
execute in minecraft:overworld run fill 376 70 40 376 144 40 air
execute in minecraft:overworld run fill 376 58 41 376 65 41 stone
execute in minecraft:overworld run fill 376 66 41 376 67 41 dirt
execute in minecraft:overworld run setblock 376 68 41 coarse_dirt
execute in minecraft:overworld run fill 376 69 41 376 144 41 air
execute in minecraft:overworld run fill 376 58 42 376 65 42 stone
execute in minecraft:overworld run fill 376 66 42 376 67 42 dirt
execute in minecraft:overworld run setblock 376 68 42 coarse_dirt
execute in minecraft:overworld run fill 376 69 42 376 144 42 air
execute in minecraft:overworld run fill 376 58 43 376 64 43 stone
execute in minecraft:overworld run fill 376 65 43 376 66 43 dirt
execute in minecraft:overworld run setblock 376 67 43 coarse_dirt
execute in minecraft:overworld run fill 376 68 43 376 144 43 air
execute in minecraft:overworld run fill 376 58 44 376 63 44 stone
execute in minecraft:overworld run fill 376 64 44 376 65 44 dirt
execute in minecraft:overworld run setblock 376 66 44 coarse_dirt
execute in minecraft:overworld run fill 376 67 44 376 144 44 air
execute in minecraft:overworld run fill 376 58 45 376 63 45 stone
execute in minecraft:overworld run fill 376 64 45 376 65 45 dirt
execute in minecraft:overworld run setblock 376 66 45 coarse_dirt
execute in minecraft:overworld run fill 376 67 45 376 144 45 air
execute in minecraft:overworld run fill 376 58 46 376 62 46 stone
execute in minecraft:overworld run fill 376 63 46 376 64 46 dirt
execute in minecraft:overworld run setblock 376 65 46 grass_block
execute in minecraft:overworld run fill 376 66 46 376 144 46 air
execute in minecraft:overworld run fill 376 58 47 376 61 47 stone
execute in minecraft:overworld run fill 376 62 47 376 63 47 dirt
execute in minecraft:overworld run setblock 376 64 47 grass_block
execute in minecraft:overworld run fill 376 65 47 376 144 47 air
execute in minecraft:overworld run fill 377 58 -48 377 61 -48 stone
execute in minecraft:overworld run fill 377 62 -48 377 63 -48 dirt
execute in minecraft:overworld run setblock 377 64 -48 coarse_dirt
execute in minecraft:overworld run fill 377 65 -48 377 144 -48 air
execute in minecraft:overworld run fill 377 58 -47 377 62 -47 stone
execute in minecraft:overworld run fill 377 63 -47 377 64 -47 dirt
execute in minecraft:overworld run setblock 377 65 -47 coarse_dirt
execute in minecraft:overworld run fill 377 66 -47 377 144 -47 air
execute in minecraft:overworld run fill 377 58 -46 377 63 -46 stone
execute in minecraft:overworld run fill 377 64 -46 377 65 -46 dirt
execute in minecraft:overworld run setblock 377 66 -46 coarse_dirt
execute in minecraft:overworld run fill 377 67 -46 377 144 -46 air
execute in minecraft:overworld run fill 377 58 -45 377 64 -45 stone
execute in minecraft:overworld run fill 377 65 -45 377 66 -45 dirt
execute in minecraft:overworld run setblock 377 67 -45 coarse_dirt
execute in minecraft:overworld run fill 377 68 -45 377 144 -45 air
execute in minecraft:overworld run fill 377 58 -44 377 64 -44 stone
execute in minecraft:overworld run fill 377 65 -44 377 66 -44 dirt
execute in minecraft:overworld run setblock 377 67 -44 coarse_dirt
execute in minecraft:overworld run fill 377 68 -44 377 144 -44 air
execute in minecraft:overworld run fill 377 58 -43 377 65 -43 stone
execute in minecraft:overworld run fill 377 66 -43 377 67 -43 dirt
execute in minecraft:overworld run setblock 377 68 -43 coarse_dirt
execute in minecraft:overworld run fill 377 69 -43 377 144 -43 air
execute in minecraft:overworld run fill 377 58 -42 377 65 -42 stone
execute in minecraft:overworld run fill 377 66 -42 377 67 -42 dirt
execute in minecraft:overworld run setblock 377 68 -42 coarse_dirt
execute in minecraft:overworld run fill 377 69 -42 377 144 -42 air
execute in minecraft:overworld run fill 377 58 -41 377 66 -41 stone
execute in minecraft:overworld run fill 377 67 -41 377 68 -41 dirt
execute in minecraft:overworld run setblock 377 69 -41 coarse_dirt
execute in minecraft:overworld run fill 377 70 -41 377 144 -41 air
execute in minecraft:overworld run setblock 377 70 -41 mossy_cobblestone
execute in minecraft:overworld run fill 377 58 -40 377 66 -40 stone
schedule function blade_gallery:random/battlefield/part_63 1t replace
