execute in minecraft:overworld run fill 429 68 -26 429 144 -26 air
execute in minecraft:overworld run fill 429 58 -25 429 64 -25 stone
execute in minecraft:overworld run fill 429 65 -25 429 66 -25 dirt
execute in minecraft:overworld run setblock 429 67 -25 coarse_dirt
execute in minecraft:overworld run fill 429 68 -25 429 144 -25 air
execute in minecraft:overworld run fill 429 58 -24 429 63 -24 stone
execute in minecraft:overworld run fill 429 64 -24 429 65 -24 dirt
execute in minecraft:overworld run setblock 429 66 -24 coarse_dirt
execute in minecraft:overworld run fill 429 67 -24 429 144 -24 air
execute in minecraft:overworld run fill 429 58 -23 429 63 -23 stone
execute in minecraft:overworld run fill 429 64 -23 429 65 -23 dirt
execute in minecraft:overworld run setblock 429 66 -23 coarse_dirt
execute in minecraft:overworld run fill 429 67 -23 429 144 -23 air
execute in minecraft:overworld run fill 429 58 -22 429 63 -22 stone
execute in minecraft:overworld run fill 429 64 -22 429 65 -22 dirt
execute in minecraft:overworld run setblock 429 66 -22 coarse_dirt
execute in minecraft:overworld run fill 429 67 -22 429 144 -22 air
execute in minecraft:overworld run fill 429 58 -21 429 63 -21 stone
execute in minecraft:overworld run fill 429 64 -21 429 65 -21 dirt
execute in minecraft:overworld run setblock 429 66 -21 coarse_dirt
execute in minecraft:overworld run fill 429 67 -21 429 144 -21 air
execute in minecraft:overworld run fill 429 58 -20 429 63 -20 stone
execute in minecraft:overworld run fill 429 64 -20 429 65 -20 dirt
execute in minecraft:overworld run setblock 429 66 -20 grass_block
execute in minecraft:overworld run fill 429 67 -20 429 144 -20 air
execute in minecraft:overworld run fill 429 58 -19 429 63 -19 stone
execute in minecraft:overworld run fill 429 64 -19 429 65 -19 dirt
execute in minecraft:overworld run setblock 429 66 -19 grass_block
execute in minecraft:overworld run fill 429 67 -19 429 144 -19 air
execute in minecraft:overworld run fill 429 58 -18 429 63 -18 stone
execute in minecraft:overworld run fill 429 64 -18 429 65 -18 dirt
execute in minecraft:overworld run setblock 429 66 -18 coarse_dirt
execute in minecraft:overworld run fill 429 67 -18 429 144 -18 air
execute in minecraft:overworld run fill 429 58 -17 429 63 -17 stone
execute in minecraft:overworld run fill 429 64 -17 429 65 -17 dirt
execute in minecraft:overworld run setblock 429 66 -17 grass_block
execute in minecraft:overworld run fill 429 67 -17 429 144 -17 air
execute in minecraft:overworld run fill 429 58 -16 429 63 -16 stone
execute in minecraft:overworld run fill 429 64 -16 429 65 -16 dirt
execute in minecraft:overworld run setblock 429 66 -16 grass_block
execute in minecraft:overworld run fill 429 67 -16 429 144 -16 air
execute in minecraft:overworld run fill 429 58 -15 429 63 -15 stone
execute in minecraft:overworld run fill 429 64 -15 429 65 -15 dirt
execute in minecraft:overworld run setblock 429 66 -15 coarse_dirt
execute in minecraft:overworld run fill 429 67 -15 429 144 -15 air
execute in minecraft:overworld run fill 429 58 -14 429 63 -14 stone
execute in minecraft:overworld run fill 429 64 -14 429 65 -14 dirt
execute in minecraft:overworld run setblock 429 66 -14 grass_block
execute in minecraft:overworld run fill 429 67 -14 429 144 -14 air
execute in minecraft:overworld run fill 429 58 -13 429 63 -13 stone
execute in minecraft:overworld run fill 429 64 -13 429 65 -13 dirt
execute in minecraft:overworld run setblock 429 66 -13 grass_block
execute in minecraft:overworld run fill 429 67 -13 429 144 -13 air
execute in minecraft:overworld run fill 429 58 -12 429 62 -12 stone
execute in minecraft:overworld run fill 429 63 -12 429 64 -12 dirt
execute in minecraft:overworld run setblock 429 65 -12 coarse_dirt
execute in minecraft:overworld run fill 429 66 -12 429 144 -12 air
execute in minecraft:overworld run fill 429 58 -11 429 62 -11 stone
execute in minecraft:overworld run fill 429 63 -11 429 64 -11 dirt
execute in minecraft:overworld run setblock 429 65 -11 grass_block
execute in minecraft:overworld run fill 429 66 -11 429 144 -11 air
execute in minecraft:overworld run fill 429 58 -10 429 63 -10 stone
execute in minecraft:overworld run fill 429 64 -10 429 65 -10 dirt
execute in minecraft:overworld run setblock 429 66 -10 coarse_dirt
execute in minecraft:overworld run fill 429 67 -10 429 144 -10 air
execute in minecraft:overworld run fill 429 58 -9 429 63 -9 stone
execute in minecraft:overworld run fill 429 64 -9 429 65 -9 dirt
execute in minecraft:overworld run setblock 429 66 -9 grass_block
execute in minecraft:overworld run fill 429 67 -9 429 144 -9 air
execute in minecraft:overworld run fill 429 58 -8 429 63 -8 stone
execute in minecraft:overworld run fill 429 64 -8 429 65 -8 dirt
execute in minecraft:overworld run setblock 429 66 -8 coarse_dirt
execute in minecraft:overworld run fill 429 67 -8 429 144 -8 air
execute in minecraft:overworld run fill 429 58 -7 429 62 -7 stone
execute in minecraft:overworld run fill 429 63 -7 429 64 -7 dirt
execute in minecraft:overworld run setblock 429 65 -7 coarse_dirt
execute in minecraft:overworld run fill 429 66 -7 429 144 -7 air
execute in minecraft:overworld run fill 429 58 -6 429 62 -6 stone
execute in minecraft:overworld run fill 429 63 -6 429 64 -6 dirt
execute in minecraft:overworld run setblock 429 65 -6 grass_block
execute in minecraft:overworld run fill 429 66 -6 429 144 -6 air
execute in minecraft:overworld run fill 429 58 -5 429 62 -5 stone
execute in minecraft:overworld run fill 429 63 -5 429 64 -5 dirt
execute in minecraft:overworld run setblock 429 65 -5 coarse_dirt
execute in minecraft:overworld run fill 429 66 -5 429 144 -5 air
execute in minecraft:overworld run fill 429 58 -4 429 62 -4 stone
execute in minecraft:overworld run fill 429 63 -4 429 64 -4 dirt
execute in minecraft:overworld run setblock 429 65 -4 coarse_dirt
execute in minecraft:overworld run fill 429 66 -4 429 144 -4 air
execute in minecraft:overworld run fill 429 58 -3 429 62 -3 stone
execute in minecraft:overworld run fill 429 63 -3 429 64 -3 dirt
execute in minecraft:overworld run setblock 429 65 -3 coarse_dirt
execute in minecraft:overworld run fill 429 66 -3 429 144 -3 air
execute in minecraft:overworld run fill 429 58 -2 429 62 -2 stone
execute in minecraft:overworld run fill 429 63 -2 429 64 -2 dirt
execute in minecraft:overworld run setblock 429 65 -2 coarse_dirt
execute in minecraft:overworld run fill 429 66 -2 429 144 -2 air
execute in minecraft:overworld run fill 429 58 -1 429 62 -1 stone
execute in minecraft:overworld run fill 429 63 -1 429 64 -1 dirt
execute in minecraft:overworld run setblock 429 65 -1 grass_block
execute in minecraft:overworld run fill 429 66 -1 429 144 -1 air
execute in minecraft:overworld run fill 429 58 0 429 62 0 stone
execute in minecraft:overworld run fill 429 63 0 429 64 0 dirt
execute in minecraft:overworld run setblock 429 65 0 coarse_dirt
execute in minecraft:overworld run fill 429 66 0 429 144 0 air
execute in minecraft:overworld run fill 429 58 1 429 62 1 stone
execute in minecraft:overworld run fill 429 63 1 429 64 1 dirt
execute in minecraft:overworld run setblock 429 65 1 coarse_dirt
execute in minecraft:overworld run fill 429 66 1 429 144 1 air
execute in minecraft:overworld run fill 429 58 2 429 62 2 stone
execute in minecraft:overworld run fill 429 63 2 429 64 2 dirt
execute in minecraft:overworld run setblock 429 65 2 coarse_dirt
execute in minecraft:overworld run fill 429 66 2 429 144 2 air
execute in minecraft:overworld run fill 429 58 3 429 62 3 stone
execute in minecraft:overworld run fill 429 63 3 429 64 3 dirt
execute in minecraft:overworld run setblock 429 65 3 coarse_dirt
execute in minecraft:overworld run fill 429 66 3 429 144 3 air
execute in minecraft:overworld run fill 429 58 4 429 62 4 stone
execute in minecraft:overworld run fill 429 63 4 429 64 4 dirt
execute in minecraft:overworld run setblock 429 65 4 coarse_dirt
execute in minecraft:overworld run fill 429 66 4 429 144 4 air
execute in minecraft:overworld run fill 429 58 5 429 62 5 stone
execute in minecraft:overworld run fill 429 63 5 429 64 5 dirt
execute in minecraft:overworld run setblock 429 65 5 coarse_dirt
execute in minecraft:overworld run fill 429 66 5 429 144 5 air
execute in minecraft:overworld run fill 429 58 6 429 62 6 stone
execute in minecraft:overworld run fill 429 63 6 429 64 6 dirt
execute in minecraft:overworld run setblock 429 65 6 coarse_dirt
execute in minecraft:overworld run fill 429 66 6 429 144 6 air
execute in minecraft:overworld run fill 429 58 7 429 63 7 stone
execute in minecraft:overworld run fill 429 64 7 429 65 7 dirt
execute in minecraft:overworld run setblock 429 66 7 coarse_dirt
execute in minecraft:overworld run fill 429 67 7 429 144 7 air
execute in minecraft:overworld run fill 429 58 8 429 63 8 stone
execute in minecraft:overworld run fill 429 64 8 429 65 8 dirt
execute in minecraft:overworld run setblock 429 66 8 coarse_dirt
execute in minecraft:overworld run fill 429 67 8 429 144 8 air
execute in minecraft:overworld run fill 429 58 9 429 63 9 stone
execute in minecraft:overworld run fill 429 64 9 429 65 9 dirt
execute in minecraft:overworld run setblock 429 66 9 coarse_dirt
execute in minecraft:overworld run fill 429 67 9 429 144 9 air
execute in minecraft:overworld run fill 429 58 10 429 63 10 stone
execute in minecraft:overworld run fill 429 64 10 429 65 10 dirt
execute in minecraft:overworld run setblock 429 66 10 coarse_dirt
execute in minecraft:overworld run fill 429 67 10 429 144 10 air
execute in minecraft:overworld run fill 429 58 11 429 63 11 stone
execute in minecraft:overworld run fill 429 64 11 429 65 11 dirt
execute in minecraft:overworld run setblock 429 66 11 grass_block
execute in minecraft:overworld run fill 429 67 11 429 144 11 air
execute in minecraft:overworld run fill 429 58 12 429 63 12 stone
execute in minecraft:overworld run fill 429 64 12 429 65 12 dirt
execute in minecraft:overworld run setblock 429 66 12 coarse_dirt
execute in minecraft:overworld run fill 429 67 12 429 144 12 air
execute in minecraft:overworld run fill 429 58 13 429 63 13 stone
execute in minecraft:overworld run fill 429 64 13 429 65 13 dirt
execute in minecraft:overworld run setblock 429 66 13 coarse_dirt
execute in minecraft:overworld run fill 429 67 13 429 144 13 air
execute in minecraft:overworld run fill 429 58 14 429 63 14 stone
execute in minecraft:overworld run fill 429 64 14 429 65 14 dirt
execute in minecraft:overworld run setblock 429 66 14 coarse_dirt
execute in minecraft:overworld run fill 429 67 14 429 144 14 air
execute in minecraft:overworld run fill 429 58 15 429 63 15 stone
execute in minecraft:overworld run fill 429 64 15 429 65 15 dirt
execute in minecraft:overworld run setblock 429 66 15 coarse_dirt
execute in minecraft:overworld run fill 429 67 15 429 144 15 air
execute in minecraft:overworld run fill 429 58 16 429 63 16 stone
execute in minecraft:overworld run fill 429 64 16 429 65 16 dirt
execute in minecraft:overworld run setblock 429 66 16 coarse_dirt
execute in minecraft:overworld run fill 429 67 16 429 144 16 air
execute in minecraft:overworld run fill 429 58 17 429 63 17 stone
execute in minecraft:overworld run fill 429 64 17 429 65 17 dirt
execute in minecraft:overworld run setblock 429 66 17 grass_block
execute in minecraft:overworld run fill 429 67 17 429 144 17 air
execute in minecraft:overworld run fill 429 58 18 429 63 18 stone
execute in minecraft:overworld run fill 429 64 18 429 65 18 dirt
execute in minecraft:overworld run setblock 429 66 18 grass_block
execute in minecraft:overworld run fill 429 67 18 429 144 18 air
execute in minecraft:overworld run fill 429 58 19 429 63 19 stone
execute in minecraft:overworld run fill 429 64 19 429 65 19 dirt
execute in minecraft:overworld run setblock 429 66 19 coarse_dirt
execute in minecraft:overworld run fill 429 67 19 429 144 19 air
execute in minecraft:overworld run fill 429 58 20 429 64 20 stone
execute in minecraft:overworld run fill 429 65 20 429 66 20 dirt
execute in minecraft:overworld run setblock 429 67 20 coarse_dirt
execute in minecraft:overworld run fill 429 68 20 429 144 20 air
execute in minecraft:overworld run fill 429 58 21 429 64 21 stone
execute in minecraft:overworld run fill 429 65 21 429 66 21 dirt
execute in minecraft:overworld run setblock 429 67 21 grass_block
execute in minecraft:overworld run fill 429 68 21 429 144 21 air
execute in minecraft:overworld run fill 429 58 22 429 64 22 stone
execute in minecraft:overworld run fill 429 65 22 429 66 22 dirt
execute in minecraft:overworld run setblock 429 67 22 coarse_dirt
execute in minecraft:overworld run fill 429 68 22 429 144 22 air
execute in minecraft:overworld run fill 429 58 23 429 64 23 stone
execute in minecraft:overworld run fill 429 65 23 429 66 23 dirt
execute in minecraft:overworld run setblock 429 67 23 coarse_dirt
execute in minecraft:overworld run fill 429 68 23 429 144 23 air
execute in minecraft:overworld run fill 429 58 24 429 64 24 stone
execute in minecraft:overworld run fill 429 65 24 429 66 24 dirt
execute in minecraft:overworld run setblock 429 67 24 grass_block
execute in minecraft:overworld run fill 429 68 24 429 144 24 air
execute in minecraft:overworld run fill 429 58 25 429 64 25 stone
execute in minecraft:overworld run fill 429 65 25 429 66 25 dirt
execute in minecraft:overworld run setblock 429 67 25 coarse_dirt
execute in minecraft:overworld run fill 429 68 25 429 144 25 air
execute in minecraft:overworld run fill 429 58 26 429 64 26 stone
execute in minecraft:overworld run fill 429 65 26 429 66 26 dirt
execute in minecraft:overworld run setblock 429 67 26 coarse_dirt
execute in minecraft:overworld run fill 429 68 26 429 144 26 air
execute in minecraft:overworld run fill 429 58 27 429 64 27 stone
execute in minecraft:overworld run fill 429 65 27 429 66 27 dirt
execute in minecraft:overworld run setblock 429 67 27 grass_block
execute in minecraft:overworld run fill 429 68 27 429 144 27 air
execute in minecraft:overworld run fill 429 58 28 429 64 28 stone
execute in minecraft:overworld run fill 429 65 28 429 66 28 dirt
execute in minecraft:overworld run setblock 429 67 28 grass_block
execute in minecraft:overworld run fill 429 68 28 429 144 28 air
execute in minecraft:overworld run fill 429 58 29 429 64 29 stone
execute in minecraft:overworld run fill 429 65 29 429 66 29 dirt
execute in minecraft:overworld run setblock 429 67 29 grass_block
execute in minecraft:overworld run fill 429 68 29 429 144 29 air
execute in minecraft:overworld run fill 429 58 30 429 64 30 stone
execute in minecraft:overworld run fill 429 65 30 429 66 30 dirt
execute in minecraft:overworld run setblock 429 67 30 coarse_dirt
execute in minecraft:overworld run fill 429 68 30 429 144 30 air
execute in minecraft:overworld run fill 429 58 31 429 64 31 stone
execute in minecraft:overworld run fill 429 65 31 429 66 31 dirt
execute in minecraft:overworld run setblock 429 67 31 grass_block
execute in minecraft:overworld run fill 429 68 31 429 144 31 air
execute in minecraft:overworld run fill 429 58 32 429 64 32 stone
execute in minecraft:overworld run fill 429 65 32 429 66 32 dirt
execute in minecraft:overworld run setblock 429 67 32 coarse_dirt
execute in minecraft:overworld run fill 429 68 32 429 144 32 air
execute in minecraft:overworld run fill 429 58 33 429 64 33 stone
execute in minecraft:overworld run fill 429 65 33 429 66 33 dirt
execute in minecraft:overworld run setblock 429 67 33 coarse_dirt
execute in minecraft:overworld run fill 429 68 33 429 144 33 air
execute in minecraft:overworld run fill 429 58 34 429 64 34 stone
execute in minecraft:overworld run fill 429 65 34 429 66 34 dirt
execute in minecraft:overworld run setblock 429 67 34 grass_block
execute in minecraft:overworld run fill 429 68 34 429 144 34 air
execute in minecraft:overworld run fill 429 58 35 429 64 35 stone
execute in minecraft:overworld run fill 429 65 35 429 66 35 dirt
execute in minecraft:overworld run setblock 429 67 35 coarse_dirt
execute in minecraft:overworld run fill 429 68 35 429 144 35 air
execute in minecraft:overworld run fill 429 58 36 429 63 36 stone
execute in minecraft:overworld run fill 429 64 36 429 65 36 dirt
execute in minecraft:overworld run setblock 429 66 36 grass_block
execute in minecraft:overworld run fill 429 67 36 429 144 36 air
execute in minecraft:overworld run fill 429 58 37 429 63 37 stone
execute in minecraft:overworld run fill 429 64 37 429 65 37 dirt
execute in minecraft:overworld run setblock 429 66 37 coarse_dirt
execute in minecraft:overworld run fill 429 67 37 429 144 37 air
execute in minecraft:overworld run fill 429 58 38 429 63 38 stone
execute in minecraft:overworld run fill 429 64 38 429 65 38 dirt
execute in minecraft:overworld run setblock 429 66 38 grass_block
schedule function blade_gallery:random/battlefield/part_147 1t replace
