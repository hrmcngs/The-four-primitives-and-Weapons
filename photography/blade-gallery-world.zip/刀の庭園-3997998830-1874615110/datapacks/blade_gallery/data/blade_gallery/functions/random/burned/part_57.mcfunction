execute in minecraft:overworld run fill 245 73 -33 245 144 -33 air
execute in minecraft:overworld run fill 245 58 -32 245 70 -32 stone
execute in minecraft:overworld run fill 245 71 -32 245 72 -32 dirt
execute in minecraft:overworld run setblock 245 73 -32 coarse_dirt
execute in minecraft:overworld run fill 245 74 -32 245 144 -32 air
execute in minecraft:overworld run fill 245 58 -31 245 70 -31 stone
execute in minecraft:overworld run fill 245 71 -31 245 72 -31 dirt
execute in minecraft:overworld run setblock 245 73 -31 coarse_dirt
execute in minecraft:overworld run fill 245 74 -31 245 144 -31 air
execute in minecraft:overworld run setblock 245 74 -31 grass
execute in minecraft:overworld run fill 245 58 -30 245 70 -30 stone
execute in minecraft:overworld run fill 245 71 -30 245 72 -30 dirt
execute in minecraft:overworld run setblock 245 73 -30 grass_block
execute in minecraft:overworld run fill 245 74 -30 245 144 -30 air
execute in minecraft:overworld run fill 245 58 -29 245 70 -29 stone
execute in minecraft:overworld run fill 245 71 -29 245 72 -29 dirt
execute in minecraft:overworld run setblock 245 73 -29 coarse_dirt
execute in minecraft:overworld run fill 245 74 -29 245 144 -29 air
execute in minecraft:overworld run fill 245 58 -28 245 70 -28 stone
execute in minecraft:overworld run fill 245 71 -28 245 72 -28 dirt
execute in minecraft:overworld run setblock 245 73 -28 coarse_dirt
execute in minecraft:overworld run fill 245 74 -28 245 144 -28 air
execute in minecraft:overworld run fill 245 58 -27 245 70 -27 stone
execute in minecraft:overworld run fill 245 71 -27 245 72 -27 dirt
execute in minecraft:overworld run setblock 245 73 -27 coarse_dirt
execute in minecraft:overworld run fill 245 74 -27 245 144 -27 air
execute in minecraft:overworld run fill 245 58 -26 245 70 -26 stone
execute in minecraft:overworld run fill 245 71 -26 245 72 -26 dirt
execute in minecraft:overworld run setblock 245 73 -26 grass_block
execute in minecraft:overworld run fill 245 74 -26 245 144 -26 air
execute in minecraft:overworld run fill 245 58 -25 245 70 -25 stone
execute in minecraft:overworld run fill 245 71 -25 245 72 -25 dirt
execute in minecraft:overworld run setblock 245 73 -25 grass_block
execute in minecraft:overworld run fill 245 74 -25 245 144 -25 air
execute in minecraft:overworld run fill 245 58 -24 245 70 -24 stone
execute in minecraft:overworld run fill 245 71 -24 245 72 -24 dirt
execute in minecraft:overworld run setblock 245 73 -24 grass_block
execute in minecraft:overworld run fill 245 74 -24 245 144 -24 air
execute in minecraft:overworld run fill 245 58 -23 245 70 -23 stone
execute in minecraft:overworld run fill 245 71 -23 245 72 -23 dirt
execute in minecraft:overworld run setblock 245 73 -23 coarse_dirt
execute in minecraft:overworld run fill 245 74 -23 245 144 -23 air
execute in minecraft:overworld run fill 245 58 -22 245 69 -22 stone
execute in minecraft:overworld run fill 245 70 -22 245 71 -22 dirt
execute in minecraft:overworld run setblock 245 72 -22 grass_block
execute in minecraft:overworld run fill 245 73 -22 245 144 -22 air
execute in minecraft:overworld run fill 245 58 -21 245 69 -21 stone
execute in minecraft:overworld run fill 245 70 -21 245 71 -21 dirt
execute in minecraft:overworld run setblock 245 72 -21 grass_block
execute in minecraft:overworld run fill 245 73 -21 245 144 -21 air
execute in minecraft:overworld run fill 245 58 -20 245 68 -20 stone
execute in minecraft:overworld run fill 245 69 -20 245 70 -20 dirt
execute in minecraft:overworld run setblock 245 71 -20 coarse_dirt
execute in minecraft:overworld run fill 245 72 -20 245 144 -20 air
execute in minecraft:overworld run fill 245 58 -19 245 68 -19 stone
execute in minecraft:overworld run fill 245 69 -19 245 70 -19 dirt
execute in minecraft:overworld run setblock 245 71 -19 grass_block
execute in minecraft:overworld run fill 245 72 -19 245 144 -19 air
execute in minecraft:overworld run fill 245 58 -18 245 67 -18 stone
execute in minecraft:overworld run fill 245 68 -18 245 69 -18 dirt
execute in minecraft:overworld run setblock 245 70 -18 grass_block
execute in minecraft:overworld run fill 245 71 -18 245 144 -18 air
execute in minecraft:overworld run fill 245 58 -17 245 67 -17 stone
execute in minecraft:overworld run fill 245 68 -17 245 69 -17 dirt
execute in minecraft:overworld run setblock 245 70 -17 grass_block
execute in minecraft:overworld run fill 245 71 -17 245 144 -17 air
execute in minecraft:overworld run fill 245 58 -16 245 66 -16 stone
execute in minecraft:overworld run fill 245 67 -16 245 68 -16 dirt
execute in minecraft:overworld run setblock 245 69 -16 grass_block
execute in minecraft:overworld run fill 245 70 -16 245 144 -16 air
execute in minecraft:overworld run fill 245 58 -15 245 66 -15 stone
execute in minecraft:overworld run fill 245 67 -15 245 68 -15 dirt
execute in minecraft:overworld run setblock 245 69 -15 grass_block
execute in minecraft:overworld run fill 245 70 -15 245 144 -15 air
execute in minecraft:overworld run fill 245 58 -14 245 65 -14 stone
execute in minecraft:overworld run fill 245 66 -14 245 67 -14 dirt
execute in minecraft:overworld run setblock 245 68 -14 coarse_dirt
execute in minecraft:overworld run fill 245 69 -14 245 144 -14 air
execute in minecraft:overworld run setblock 245 69 -14 grass
execute in minecraft:overworld run fill 245 58 -13 245 65 -13 stone
execute in minecraft:overworld run fill 245 66 -13 245 67 -13 dirt
execute in minecraft:overworld run setblock 245 68 -13 coarse_dirt
execute in minecraft:overworld run fill 245 69 -13 245 144 -13 air
execute in minecraft:overworld run fill 245 58 -12 245 64 -12 stone
execute in minecraft:overworld run fill 245 65 -12 245 66 -12 dirt
execute in minecraft:overworld run setblock 245 67 -12 coarse_dirt
execute in minecraft:overworld run fill 245 68 -12 245 144 -12 air
execute in minecraft:overworld run fill 245 58 -11 245 64 -11 stone
execute in minecraft:overworld run fill 245 65 -11 245 66 -11 dirt
execute in minecraft:overworld run setblock 245 67 -11 grass_block
execute in minecraft:overworld run fill 245 68 -11 245 144 -11 air
execute in minecraft:overworld run fill 245 58 -10 245 64 -10 stone
execute in minecraft:overworld run fill 245 65 -10 245 66 -10 dirt
execute in minecraft:overworld run setblock 245 67 -10 coarse_dirt
execute in minecraft:overworld run fill 245 68 -10 245 144 -10 air
execute in minecraft:overworld run fill 245 58 -9 245 64 -9 stone
execute in minecraft:overworld run fill 245 65 -9 245 66 -9 dirt
execute in minecraft:overworld run setblock 245 67 -9 coarse_dirt
execute in minecraft:overworld run fill 245 68 -9 245 144 -9 air
execute in minecraft:overworld run fill 245 58 -8 245 63 -8 stone
execute in minecraft:overworld run fill 245 64 -8 245 65 -8 dirt
execute in minecraft:overworld run setblock 245 66 -8 coarse_dirt
execute in minecraft:overworld run fill 245 67 -8 245 144 -8 air
execute in minecraft:overworld run fill 245 58 -7 245 63 -7 stone
execute in minecraft:overworld run fill 245 64 -7 245 65 -7 dirt
execute in minecraft:overworld run setblock 245 66 -7 coarse_dirt
execute in minecraft:overworld run fill 245 67 -7 245 144 -7 air
execute in minecraft:overworld run fill 245 58 -6 245 63 -6 stone
execute in minecraft:overworld run fill 245 64 -6 245 65 -6 dirt
execute in minecraft:overworld run setblock 245 66 -6 grass_block
execute in minecraft:overworld run fill 245 67 -6 245 144 -6 air
execute in minecraft:overworld run fill 245 58 -5 245 62 -5 stone
execute in minecraft:overworld run fill 245 63 -5 245 64 -5 dirt
execute in minecraft:overworld run setblock 245 65 -5 grass_block
execute in minecraft:overworld run fill 245 66 -5 245 144 -5 air
execute in minecraft:overworld run fill 245 58 -4 245 62 -4 stone
execute in minecraft:overworld run fill 245 63 -4 245 64 -4 dirt
execute in minecraft:overworld run setblock 245 65 -4 coarse_dirt
execute in minecraft:overworld run fill 245 66 -4 245 144 -4 air
execute in minecraft:overworld run fill 245 58 -3 245 62 -3 stone
execute in minecraft:overworld run fill 245 63 -3 245 64 -3 dirt
execute in minecraft:overworld run setblock 245 65 -3 coarse_dirt
execute in minecraft:overworld run fill 245 66 -3 245 144 -3 air
execute in minecraft:overworld run setblock 245 66 -3 grass
execute in minecraft:overworld run fill 245 58 -2 245 61 -2 stone
execute in minecraft:overworld run fill 245 62 -2 245 63 -2 dirt
execute in minecraft:overworld run setblock 245 64 -2 coarse_dirt
execute in minecraft:overworld run fill 245 65 -2 245 144 -2 air
execute in minecraft:overworld run fill 245 58 -1 245 61 -1 stone
execute in minecraft:overworld run fill 245 62 -1 245 63 -1 dirt
execute in minecraft:overworld run setblock 245 64 -1 coarse_dirt
execute in minecraft:overworld run fill 245 65 -1 245 144 -1 air
execute in minecraft:overworld run fill 245 58 0 245 61 0 stone
execute in minecraft:overworld run fill 245 62 0 245 63 0 dirt
execute in minecraft:overworld run setblock 245 64 0 grass_block
execute in minecraft:overworld run fill 245 65 0 245 144 0 air
execute in minecraft:overworld run fill 245 58 1 245 61 1 stone
execute in minecraft:overworld run fill 245 62 1 245 63 1 dirt
execute in minecraft:overworld run setblock 245 64 1 grass_block
execute in minecraft:overworld run fill 245 65 1 245 144 1 air
execute in minecraft:overworld run fill 245 58 2 245 61 2 stone
execute in minecraft:overworld run fill 245 62 2 245 63 2 dirt
execute in minecraft:overworld run setblock 245 64 2 grass_block
execute in minecraft:overworld run fill 245 65 2 245 144 2 air
execute in minecraft:overworld run fill 245 58 3 245 62 3 stone
execute in minecraft:overworld run fill 245 63 3 245 64 3 dirt
execute in minecraft:overworld run setblock 245 65 3 coarse_dirt
execute in minecraft:overworld run fill 245 66 3 245 144 3 air
execute in minecraft:overworld run fill 245 58 4 245 62 4 stone
execute in minecraft:overworld run fill 245 63 4 245 64 4 dirt
execute in minecraft:overworld run setblock 245 65 4 grass_block
execute in minecraft:overworld run fill 245 66 4 245 144 4 air
execute in minecraft:overworld run fill 245 58 5 245 63 5 stone
execute in minecraft:overworld run fill 245 64 5 245 65 5 dirt
execute in minecraft:overworld run setblock 245 66 5 coarse_dirt
execute in minecraft:overworld run fill 245 67 5 245 144 5 air
execute in minecraft:overworld run setblock 245 67 5 grass
execute in minecraft:overworld run fill 245 58 6 245 63 6 stone
execute in minecraft:overworld run fill 245 64 6 245 65 6 dirt
execute in minecraft:overworld run setblock 245 66 6 grass_block
execute in minecraft:overworld run fill 245 67 6 245 144 6 air
execute in minecraft:overworld run fill 245 58 7 245 63 7 stone
execute in minecraft:overworld run fill 245 64 7 245 65 7 dirt
execute in minecraft:overworld run setblock 245 66 7 grass_block
execute in minecraft:overworld run fill 245 67 7 245 144 7 air
execute in minecraft:overworld run setblock 245 67 7 grass
execute in minecraft:overworld run fill 245 58 8 245 64 8 stone
execute in minecraft:overworld run fill 245 65 8 245 66 8 dirt
execute in minecraft:overworld run setblock 245 67 8 coarse_dirt
execute in minecraft:overworld run fill 245 68 8 245 144 8 air
execute in minecraft:overworld run fill 245 58 9 245 64 9 stone
execute in minecraft:overworld run fill 245 65 9 245 66 9 dirt
execute in minecraft:overworld run setblock 245 67 9 coarse_dirt
execute in minecraft:overworld run fill 245 68 9 245 144 9 air
execute in minecraft:overworld run fill 245 58 10 245 64 10 stone
execute in minecraft:overworld run fill 245 65 10 245 66 10 dirt
execute in minecraft:overworld run setblock 245 67 10 coarse_dirt
execute in minecraft:overworld run fill 245 68 10 245 144 10 air
execute in minecraft:overworld run fill 245 58 11 245 64 11 stone
execute in minecraft:overworld run fill 245 65 11 245 66 11 dirt
execute in minecraft:overworld run setblock 245 67 11 grass_block
execute in minecraft:overworld run fill 245 68 11 245 144 11 air
execute in minecraft:overworld run fill 245 58 12 245 64 12 stone
execute in minecraft:overworld run fill 245 65 12 245 66 12 dirt
execute in minecraft:overworld run setblock 245 67 12 grass_block
execute in minecraft:overworld run fill 245 68 12 245 144 12 air
execute in minecraft:overworld run fill 245 58 13 245 65 13 stone
execute in minecraft:overworld run fill 245 66 13 245 67 13 dirt
execute in minecraft:overworld run setblock 245 68 13 coarse_dirt
execute in minecraft:overworld run fill 245 69 13 245 144 13 air
execute in minecraft:overworld run fill 245 58 14 245 65 14 stone
execute in minecraft:overworld run fill 245 66 14 245 67 14 dirt
execute in minecraft:overworld run setblock 245 68 14 coarse_dirt
execute in minecraft:overworld run fill 245 69 14 245 144 14 air
execute in minecraft:overworld run fill 245 58 15 245 65 15 stone
execute in minecraft:overworld run fill 245 66 15 245 67 15 dirt
execute in minecraft:overworld run setblock 245 68 15 coarse_dirt
execute in minecraft:overworld run fill 245 69 15 245 144 15 air
execute in minecraft:overworld run fill 245 58 16 245 65 16 stone
execute in minecraft:overworld run fill 245 66 16 245 67 16 dirt
execute in minecraft:overworld run setblock 245 68 16 coarse_dirt
execute in minecraft:overworld run fill 245 69 16 245 144 16 air
execute in minecraft:overworld run fill 245 58 17 245 65 17 stone
execute in minecraft:overworld run fill 245 66 17 245 67 17 dirt
execute in minecraft:overworld run setblock 245 68 17 coarse_dirt
execute in minecraft:overworld run fill 245 69 17 245 144 17 air
execute in minecraft:overworld run setblock 245 69 17 grass
execute in minecraft:overworld run fill 245 58 18 245 65 18 stone
execute in minecraft:overworld run fill 245 66 18 245 67 18 dirt
execute in minecraft:overworld run setblock 245 68 18 coarse_dirt
execute in minecraft:overworld run fill 245 69 18 245 144 18 air
execute in minecraft:overworld run setblock 245 69 18 grass
execute in minecraft:overworld run fill 245 58 19 245 65 19 stone
execute in minecraft:overworld run fill 245 66 19 245 67 19 dirt
execute in minecraft:overworld run setblock 245 68 19 coarse_dirt
execute in minecraft:overworld run fill 245 69 19 245 144 19 air
execute in minecraft:overworld run fill 245 58 20 245 66 20 stone
execute in minecraft:overworld run fill 245 67 20 245 68 20 dirt
execute in minecraft:overworld run setblock 245 69 20 grass_block
execute in minecraft:overworld run fill 245 70 20 245 144 20 air
execute in minecraft:overworld run setblock 245 70 20 grass
execute in minecraft:overworld run fill 245 58 21 245 66 21 stone
execute in minecraft:overworld run fill 245 67 21 245 68 21 dirt
execute in minecraft:overworld run setblock 245 69 21 coarse_dirt
execute in minecraft:overworld run fill 245 70 21 245 144 21 air
execute in minecraft:overworld run fill 245 58 22 245 66 22 stone
execute in minecraft:overworld run fill 245 67 22 245 68 22 dirt
execute in minecraft:overworld run setblock 245 69 22 coarse_dirt
execute in minecraft:overworld run fill 245 70 22 245 144 22 air
execute in minecraft:overworld run fill 245 58 23 245 66 23 stone
execute in minecraft:overworld run fill 245 67 23 245 68 23 dirt
execute in minecraft:overworld run setblock 245 69 23 coarse_dirt
execute in minecraft:overworld run fill 245 70 23 245 144 23 air
execute in minecraft:overworld run fill 245 58 24 245 66 24 stone
execute in minecraft:overworld run fill 245 67 24 245 68 24 dirt
execute in minecraft:overworld run setblock 245 69 24 coarse_dirt
execute in minecraft:overworld run fill 245 70 24 245 144 24 air
execute in minecraft:overworld run setblock 245 70 24 grass
execute in minecraft:overworld run fill 245 58 25 245 66 25 stone
execute in minecraft:overworld run fill 245 67 25 245 68 25 dirt
execute in minecraft:overworld run setblock 245 69 25 coarse_dirt
execute in minecraft:overworld run fill 245 70 25 245 144 25 air
execute in minecraft:overworld run fill 245 58 26 245 66 26 stone
execute in minecraft:overworld run fill 245 67 26 245 68 26 dirt
execute in minecraft:overworld run setblock 245 69 26 grass_block
execute in minecraft:overworld run fill 245 70 26 245 144 26 air
execute in minecraft:overworld run setblock 245 70 26 grass
execute in minecraft:overworld run fill 245 58 27 245 66 27 stone
execute in minecraft:overworld run fill 245 67 27 245 68 27 dirt
execute in minecraft:overworld run setblock 245 69 27 grass_block
execute in minecraft:overworld run fill 245 70 27 245 144 27 air
execute in minecraft:overworld run fill 245 58 28 245 66 28 stone
execute in minecraft:overworld run fill 245 67 28 245 68 28 dirt
execute in minecraft:overworld run setblock 245 69 28 coarse_dirt
execute in minecraft:overworld run fill 245 70 28 245 144 28 air
execute in minecraft:overworld run fill 245 58 29 245 66 29 stone
schedule function blade_gallery:random/burned/part_58 1t replace
