execute in minecraft:overworld run setblock 211 66 -17 coarse_dirt
execute in minecraft:overworld run fill 211 67 -17 211 144 -17 air
execute in minecraft:overworld run fill 211 58 -16 211 63 -16 stone
execute in minecraft:overworld run fill 211 64 -16 211 65 -16 dirt
execute in minecraft:overworld run setblock 211 66 -16 grass_block
execute in minecraft:overworld run fill 211 67 -16 211 144 -16 air
execute in minecraft:overworld run fill 211 58 -15 211 62 -15 stone
execute in minecraft:overworld run fill 211 63 -15 211 64 -15 dirt
execute in minecraft:overworld run setblock 211 65 -15 grass_block
execute in minecraft:overworld run fill 211 66 -15 211 144 -15 air
execute in minecraft:overworld run fill 211 58 -14 211 62 -14 stone
execute in minecraft:overworld run fill 211 63 -14 211 64 -14 dirt
execute in minecraft:overworld run setblock 211 65 -14 grass_block
execute in minecraft:overworld run fill 211 66 -14 211 144 -14 air
execute in minecraft:overworld run fill 211 58 -13 211 62 -13 stone
execute in minecraft:overworld run fill 211 63 -13 211 64 -13 dirt
execute in minecraft:overworld run setblock 211 65 -13 coarse_dirt
execute in minecraft:overworld run fill 211 66 -13 211 144 -13 air
execute in minecraft:overworld run fill 211 58 -12 211 62 -12 stone
execute in minecraft:overworld run fill 211 63 -12 211 64 -12 dirt
execute in minecraft:overworld run setblock 211 65 -12 grass_block
execute in minecraft:overworld run fill 211 66 -12 211 144 -12 air
execute in minecraft:overworld run fill 211 58 -11 211 63 -11 stone
execute in minecraft:overworld run fill 211 64 -11 211 65 -11 dirt
execute in minecraft:overworld run setblock 211 66 -11 grass_block
execute in minecraft:overworld run fill 211 67 -11 211 144 -11 air
execute in minecraft:overworld run fill 211 58 -10 211 63 -10 stone
execute in minecraft:overworld run fill 211 64 -10 211 65 -10 dirt
execute in minecraft:overworld run setblock 211 66 -10 grass_block
execute in minecraft:overworld run fill 211 67 -10 211 144 -10 air
execute in minecraft:overworld run fill 211 58 -9 211 63 -9 stone
execute in minecraft:overworld run fill 211 64 -9 211 65 -9 dirt
execute in minecraft:overworld run setblock 211 66 -9 grass_block
execute in minecraft:overworld run fill 211 67 -9 211 144 -9 air
execute in minecraft:overworld run fill 211 58 -8 211 63 -8 stone
execute in minecraft:overworld run fill 211 64 -8 211 65 -8 dirt
execute in minecraft:overworld run setblock 211 66 -8 coarse_dirt
execute in minecraft:overworld run fill 211 67 -8 211 144 -8 air
execute in minecraft:overworld run fill 211 58 -7 211 63 -7 stone
execute in minecraft:overworld run fill 211 64 -7 211 65 -7 dirt
execute in minecraft:overworld run setblock 211 66 -7 grass_block
execute in minecraft:overworld run fill 211 67 -7 211 144 -7 air
execute in minecraft:overworld run fill 211 58 -6 211 63 -6 stone
execute in minecraft:overworld run fill 211 64 -6 211 65 -6 dirt
execute in minecraft:overworld run setblock 211 66 -6 coarse_dirt
execute in minecraft:overworld run fill 211 67 -6 211 144 -6 air
execute in minecraft:overworld run fill 211 58 -5 211 63 -5 stone
execute in minecraft:overworld run fill 211 64 -5 211 65 -5 dirt
execute in minecraft:overworld run setblock 211 66 -5 coarse_dirt
execute in minecraft:overworld run fill 211 67 -5 211 144 -5 air
execute in minecraft:overworld run fill 211 58 -4 211 63 -4 stone
execute in minecraft:overworld run fill 211 64 -4 211 65 -4 dirt
execute in minecraft:overworld run setblock 211 66 -4 coarse_dirt
execute in minecraft:overworld run fill 211 67 -4 211 144 -4 air
execute in minecraft:overworld run fill 211 58 -3 211 63 -3 stone
execute in minecraft:overworld run fill 211 64 -3 211 65 -3 dirt
execute in minecraft:overworld run setblock 211 66 -3 coarse_dirt
execute in minecraft:overworld run fill 211 67 -3 211 144 -3 air
execute in minecraft:overworld run fill 211 58 -2 211 63 -2 stone
execute in minecraft:overworld run fill 211 64 -2 211 65 -2 dirt
execute in minecraft:overworld run setblock 211 66 -2 coarse_dirt
execute in minecraft:overworld run fill 211 67 -2 211 144 -2 air
execute in minecraft:overworld run fill 211 58 -1 211 63 -1 stone
execute in minecraft:overworld run fill 211 64 -1 211 65 -1 dirt
execute in minecraft:overworld run setblock 211 66 -1 grass_block
execute in minecraft:overworld run fill 211 67 -1 211 144 -1 air
execute in minecraft:overworld run fill 211 58 0 211 63 0 stone
execute in minecraft:overworld run fill 211 64 0 211 65 0 dirt
execute in minecraft:overworld run setblock 211 66 0 grass_block
execute in minecraft:overworld run fill 211 67 0 211 144 0 air
execute in minecraft:overworld run fill 211 58 1 211 63 1 stone
execute in minecraft:overworld run fill 211 64 1 211 65 1 dirt
execute in minecraft:overworld run setblock 211 66 1 grass_block
execute in minecraft:overworld run fill 211 67 1 211 144 1 air
execute in minecraft:overworld run fill 211 58 2 211 63 2 stone
execute in minecraft:overworld run fill 211 64 2 211 65 2 dirt
execute in minecraft:overworld run setblock 211 66 2 grass_block
execute in minecraft:overworld run fill 211 67 2 211 144 2 air
execute in minecraft:overworld run fill 211 58 3 211 63 3 stone
execute in minecraft:overworld run fill 211 64 3 211 65 3 dirt
execute in minecraft:overworld run setblock 211 66 3 grass_block
execute in minecraft:overworld run fill 211 67 3 211 144 3 air
execute in minecraft:overworld run fill 211 58 4 211 63 4 stone
execute in minecraft:overworld run fill 211 64 4 211 65 4 dirt
execute in minecraft:overworld run setblock 211 66 4 coarse_dirt
execute in minecraft:overworld run fill 211 67 4 211 144 4 air
execute in minecraft:overworld run fill 211 58 5 211 63 5 stone
execute in minecraft:overworld run fill 211 64 5 211 65 5 dirt
execute in minecraft:overworld run setblock 211 66 5 grass_block
execute in minecraft:overworld run fill 211 67 5 211 144 5 air
execute in minecraft:overworld run fill 211 58 6 211 63 6 stone
execute in minecraft:overworld run fill 211 64 6 211 65 6 dirt
execute in minecraft:overworld run setblock 211 66 6 coarse_dirt
execute in minecraft:overworld run fill 211 67 6 211 144 6 air
execute in minecraft:overworld run fill 211 58 7 211 63 7 stone
execute in minecraft:overworld run fill 211 64 7 211 65 7 dirt
execute in minecraft:overworld run setblock 211 66 7 coarse_dirt
execute in minecraft:overworld run fill 211 67 7 211 144 7 air
execute in minecraft:overworld run fill 211 58 8 211 63 8 stone
execute in minecraft:overworld run fill 211 64 8 211 65 8 dirt
execute in minecraft:overworld run setblock 211 66 8 coarse_dirt
execute in minecraft:overworld run fill 211 67 8 211 144 8 air
execute in minecraft:overworld run fill 211 58 9 211 63 9 stone
execute in minecraft:overworld run fill 211 64 9 211 65 9 dirt
execute in minecraft:overworld run setblock 211 66 9 grass_block
execute in minecraft:overworld run fill 211 67 9 211 144 9 air
execute in minecraft:overworld run fill 211 58 10 211 63 10 stone
execute in minecraft:overworld run fill 211 64 10 211 65 10 dirt
execute in minecraft:overworld run setblock 211 66 10 coarse_dirt
execute in minecraft:overworld run fill 211 67 10 211 144 10 air
execute in minecraft:overworld run fill 211 58 11 211 63 11 stone
execute in minecraft:overworld run fill 211 64 11 211 65 11 dirt
execute in minecraft:overworld run setblock 211 66 11 grass_block
execute in minecraft:overworld run fill 211 67 11 211 144 11 air
execute in minecraft:overworld run fill 211 58 12 211 63 12 stone
execute in minecraft:overworld run fill 211 64 12 211 65 12 dirt
execute in minecraft:overworld run setblock 211 66 12 coarse_dirt
execute in minecraft:overworld run fill 211 67 12 211 144 12 air
execute in minecraft:overworld run fill 211 58 13 211 63 13 stone
execute in minecraft:overworld run fill 211 64 13 211 65 13 dirt
execute in minecraft:overworld run setblock 211 66 13 coarse_dirt
execute in minecraft:overworld run fill 211 67 13 211 144 13 air
execute in minecraft:overworld run fill 211 58 14 211 63 14 stone
execute in minecraft:overworld run fill 211 64 14 211 65 14 dirt
execute in minecraft:overworld run setblock 211 66 14 grass_block
execute in minecraft:overworld run fill 211 67 14 211 144 14 air
execute in minecraft:overworld run fill 211 58 15 211 63 15 stone
execute in minecraft:overworld run fill 211 64 15 211 65 15 dirt
execute in minecraft:overworld run setblock 211 66 15 coarse_dirt
execute in minecraft:overworld run fill 211 67 15 211 144 15 air
execute in minecraft:overworld run fill 211 58 16 211 63 16 stone
execute in minecraft:overworld run fill 211 64 16 211 65 16 dirt
execute in minecraft:overworld run setblock 211 66 16 coarse_dirt
execute in minecraft:overworld run fill 211 67 16 211 144 16 air
execute in minecraft:overworld run fill 211 58 17 211 63 17 stone
execute in minecraft:overworld run fill 211 64 17 211 65 17 dirt
execute in minecraft:overworld run setblock 211 66 17 coarse_dirt
execute in minecraft:overworld run fill 211 67 17 211 144 17 air
execute in minecraft:overworld run fill 211 58 18 211 63 18 stone
execute in minecraft:overworld run fill 211 64 18 211 65 18 dirt
execute in minecraft:overworld run setblock 211 66 18 grass_block
execute in minecraft:overworld run fill 211 67 18 211 144 18 air
execute in minecraft:overworld run fill 211 58 19 211 63 19 stone
execute in minecraft:overworld run fill 211 64 19 211 65 19 dirt
execute in minecraft:overworld run setblock 211 66 19 grass_block
execute in minecraft:overworld run fill 211 67 19 211 144 19 air
execute in minecraft:overworld run fill 211 58 20 211 63 20 stone
execute in minecraft:overworld run fill 211 64 20 211 65 20 dirt
execute in minecraft:overworld run setblock 211 66 20 coarse_dirt
execute in minecraft:overworld run fill 211 67 20 211 144 20 air
execute in minecraft:overworld run fill 211 58 21 211 63 21 stone
execute in minecraft:overworld run fill 211 64 21 211 65 21 dirt
execute in minecraft:overworld run setblock 211 66 21 coarse_dirt
execute in minecraft:overworld run fill 211 67 21 211 144 21 air
execute in minecraft:overworld run fill 211 58 22 211 63 22 stone
execute in minecraft:overworld run fill 211 64 22 211 65 22 dirt
execute in minecraft:overworld run setblock 211 66 22 coarse_dirt
execute in minecraft:overworld run fill 211 67 22 211 144 22 air
execute in minecraft:overworld run fill 211 58 23 211 63 23 stone
execute in minecraft:overworld run fill 211 64 23 211 65 23 dirt
execute in minecraft:overworld run setblock 211 66 23 coarse_dirt
execute in minecraft:overworld run fill 211 67 23 211 144 23 air
execute in minecraft:overworld run fill 211 58 24 211 63 24 stone
execute in minecraft:overworld run fill 211 64 24 211 65 24 dirt
execute in minecraft:overworld run setblock 211 66 24 coarse_dirt
execute in minecraft:overworld run fill 211 67 24 211 144 24 air
execute in minecraft:overworld run fill 211 58 25 211 63 25 stone
execute in minecraft:overworld run fill 211 64 25 211 65 25 dirt
execute in minecraft:overworld run setblock 211 66 25 coarse_dirt
execute in minecraft:overworld run fill 211 67 25 211 144 25 air
execute in minecraft:overworld run fill 211 58 26 211 63 26 stone
execute in minecraft:overworld run fill 211 64 26 211 65 26 dirt
execute in minecraft:overworld run setblock 211 66 26 grass_block
execute in minecraft:overworld run fill 211 67 26 211 144 26 air
execute in minecraft:overworld run fill 211 58 27 211 63 27 stone
execute in minecraft:overworld run fill 211 64 27 211 65 27 dirt
execute in minecraft:overworld run setblock 211 66 27 coarse_dirt
execute in minecraft:overworld run fill 211 67 27 211 144 27 air
execute in minecraft:overworld run fill 211 58 28 211 63 28 stone
execute in minecraft:overworld run fill 211 64 28 211 65 28 dirt
execute in minecraft:overworld run setblock 211 66 28 coarse_dirt
execute in minecraft:overworld run fill 211 67 28 211 144 28 air
execute in minecraft:overworld run fill 211 58 29 211 63 29 stone
execute in minecraft:overworld run fill 211 64 29 211 65 29 dirt
execute in minecraft:overworld run setblock 211 66 29 coarse_dirt
execute in minecraft:overworld run fill 211 67 29 211 144 29 air
execute in minecraft:overworld run fill 211 58 30 211 63 30 stone
execute in minecraft:overworld run fill 211 64 30 211 65 30 dirt
execute in minecraft:overworld run setblock 211 66 30 coarse_dirt
execute in minecraft:overworld run fill 211 67 30 211 144 30 air
execute in minecraft:overworld run fill 211 58 31 211 63 31 stone
execute in minecraft:overworld run fill 211 64 31 211 65 31 dirt
execute in minecraft:overworld run setblock 211 66 31 coarse_dirt
execute in minecraft:overworld run fill 211 67 31 211 144 31 air
execute in minecraft:overworld run fill 211 58 32 211 63 32 stone
execute in minecraft:overworld run fill 211 64 32 211 65 32 dirt
execute in minecraft:overworld run setblock 211 66 32 grass_block
execute in minecraft:overworld run fill 211 67 32 211 144 32 air
execute in minecraft:overworld run fill 211 58 33 211 63 33 stone
execute in minecraft:overworld run fill 211 64 33 211 65 33 dirt
execute in minecraft:overworld run setblock 211 66 33 coarse_dirt
execute in minecraft:overworld run fill 211 67 33 211 144 33 air
execute in minecraft:overworld run fill 211 58 34 211 63 34 stone
execute in minecraft:overworld run fill 211 64 34 211 65 34 dirt
execute in minecraft:overworld run setblock 211 66 34 grass_block
execute in minecraft:overworld run fill 211 67 34 211 144 34 air
execute in minecraft:overworld run fill 211 58 35 211 63 35 stone
execute in minecraft:overworld run fill 211 64 35 211 65 35 dirt
execute in minecraft:overworld run setblock 211 66 35 grass_block
execute in minecraft:overworld run fill 211 67 35 211 144 35 air
execute in minecraft:overworld run fill 211 58 36 211 63 36 stone
execute in minecraft:overworld run fill 211 64 36 211 65 36 dirt
execute in minecraft:overworld run setblock 211 66 36 coarse_dirt
execute in minecraft:overworld run fill 211 67 36 211 144 36 air
execute in minecraft:overworld run fill 211 58 37 211 63 37 stone
execute in minecraft:overworld run fill 211 64 37 211 65 37 dirt
execute in minecraft:overworld run setblock 211 66 37 coarse_dirt
execute in minecraft:overworld run fill 211 67 37 211 144 37 air
execute in minecraft:overworld run fill 211 58 38 211 63 38 stone
execute in minecraft:overworld run fill 211 64 38 211 65 38 dirt
execute in minecraft:overworld run setblock 211 66 38 coarse_dirt
execute in minecraft:overworld run fill 211 67 38 211 144 38 air
execute in minecraft:overworld run fill 211 58 39 211 63 39 stone
execute in minecraft:overworld run fill 211 64 39 211 65 39 dirt
execute in minecraft:overworld run setblock 211 66 39 grass_block
execute in minecraft:overworld run fill 211 67 39 211 144 39 air
execute in minecraft:overworld run fill 211 58 40 211 63 40 stone
execute in minecraft:overworld run fill 211 64 40 211 65 40 dirt
execute in minecraft:overworld run setblock 211 66 40 grass_block
execute in minecraft:overworld run fill 211 67 40 211 144 40 air
execute in minecraft:overworld run fill 211 58 41 211 63 41 stone
execute in minecraft:overworld run fill 211 64 41 211 65 41 dirt
execute in minecraft:overworld run setblock 211 66 41 grass_block
execute in minecraft:overworld run fill 211 67 41 211 144 41 air
execute in minecraft:overworld run fill 211 58 42 211 63 42 stone
execute in minecraft:overworld run fill 211 64 42 211 65 42 dirt
execute in minecraft:overworld run setblock 211 66 42 coarse_dirt
execute in minecraft:overworld run fill 211 67 42 211 144 42 air
execute in minecraft:overworld run fill 211 58 43 211 62 43 stone
execute in minecraft:overworld run fill 211 63 43 211 64 43 dirt
execute in minecraft:overworld run setblock 211 65 43 coarse_dirt
execute in minecraft:overworld run fill 211 66 43 211 144 43 air
execute in minecraft:overworld run fill 211 58 44 211 62 44 stone
execute in minecraft:overworld run fill 211 63 44 211 64 44 dirt
execute in minecraft:overworld run setblock 211 65 44 coarse_dirt
execute in minecraft:overworld run fill 211 66 44 211 144 44 air
execute in minecraft:overworld run fill 211 58 45 211 62 45 stone
execute in minecraft:overworld run fill 211 63 45 211 64 45 dirt
execute in minecraft:overworld run setblock 211 65 45 grass_block
execute in minecraft:overworld run fill 211 66 45 211 144 45 air
execute in minecraft:overworld run fill 211 58 46 211 62 46 stone
execute in minecraft:overworld run fill 211 63 46 211 64 46 dirt
execute in minecraft:overworld run setblock 211 65 46 grass_block
execute in minecraft:overworld run fill 211 66 46 211 144 46 air
execute in minecraft:overworld run fill 211 58 47 211 61 47 stone
execute in minecraft:overworld run fill 211 62 47 211 63 47 dirt
schedule function blade_gallery:random/burned/part_6 1t replace
