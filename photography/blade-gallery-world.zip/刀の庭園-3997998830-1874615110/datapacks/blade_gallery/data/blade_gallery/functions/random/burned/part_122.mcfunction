execute in minecraft:overworld run fill 285 80 -37 285 81 -37 dirt
execute in minecraft:overworld run setblock 285 82 -37 coarse_dirt
execute in minecraft:overworld run fill 285 83 -37 285 144 -37 air
execute in minecraft:overworld run fill 285 58 -36 285 78 -36 stone
execute in minecraft:overworld run fill 285 79 -36 285 80 -36 dirt
execute in minecraft:overworld run setblock 285 81 -36 coarse_dirt
execute in minecraft:overworld run fill 285 82 -36 285 144 -36 air
execute in minecraft:overworld run setblock 285 82 -36 grass
execute in minecraft:overworld run fill 285 58 -35 285 78 -35 stone
execute in minecraft:overworld run fill 285 79 -35 285 80 -35 dirt
execute in minecraft:overworld run setblock 285 81 -35 grass_block
execute in minecraft:overworld run fill 285 82 -35 285 144 -35 air
execute in minecraft:overworld run setblock 285 82 -35 mossy_cobblestone
execute in minecraft:overworld run fill 285 58 -34 285 78 -34 stone
execute in minecraft:overworld run fill 285 79 -34 285 80 -34 dirt
execute in minecraft:overworld run setblock 285 81 -34 coarse_dirt
execute in minecraft:overworld run fill 285 82 -34 285 144 -34 air
execute in minecraft:overworld run fill 285 58 -33 285 77 -33 stone
execute in minecraft:overworld run fill 285 78 -33 285 79 -33 dirt
execute in minecraft:overworld run setblock 285 80 -33 coarse_dirt
execute in minecraft:overworld run fill 285 81 -33 285 144 -33 air
execute in minecraft:overworld run setblock 285 81 -33 grass
execute in minecraft:overworld run fill 285 58 -32 285 76 -32 stone
execute in minecraft:overworld run fill 285 77 -32 285 78 -32 dirt
execute in minecraft:overworld run setblock 285 79 -32 grass_block
execute in minecraft:overworld run fill 285 80 -32 285 144 -32 air
execute in minecraft:overworld run fill 285 58 -31 285 76 -31 stone
execute in minecraft:overworld run fill 285 77 -31 285 78 -31 dirt
execute in minecraft:overworld run setblock 285 79 -31 coarse_dirt
execute in minecraft:overworld run fill 285 80 -31 285 144 -31 air
execute in minecraft:overworld run fill 285 58 -30 285 75 -30 stone
execute in minecraft:overworld run fill 285 76 -30 285 77 -30 dirt
execute in minecraft:overworld run setblock 285 78 -30 grass_block
execute in minecraft:overworld run fill 285 79 -30 285 144 -30 air
execute in minecraft:overworld run fill 285 58 -29 285 75 -29 stone
execute in minecraft:overworld run fill 285 76 -29 285 77 -29 dirt
execute in minecraft:overworld run setblock 285 78 -29 grass_block
execute in minecraft:overworld run fill 285 79 -29 285 144 -29 air
execute in minecraft:overworld run fill 285 58 -28 285 74 -28 stone
execute in minecraft:overworld run fill 285 75 -28 285 76 -28 dirt
execute in minecraft:overworld run setblock 285 77 -28 grass_block
execute in minecraft:overworld run fill 285 78 -28 285 144 -28 air
execute in minecraft:overworld run fill 285 58 -27 285 74 -27 stone
execute in minecraft:overworld run fill 285 75 -27 285 76 -27 dirt
execute in minecraft:overworld run setblock 285 77 -27 coarse_dirt
execute in minecraft:overworld run fill 285 78 -27 285 144 -27 air
execute in minecraft:overworld run fill 285 58 -26 285 74 -26 stone
execute in minecraft:overworld run fill 285 75 -26 285 76 -26 dirt
execute in minecraft:overworld run setblock 285 77 -26 grass_block
execute in minecraft:overworld run fill 285 78 -26 285 144 -26 air
execute in minecraft:overworld run fill 285 58 -25 285 73 -25 stone
execute in minecraft:overworld run fill 285 74 -25 285 75 -25 dirt
execute in minecraft:overworld run setblock 285 76 -25 coarse_dirt
execute in minecraft:overworld run fill 285 77 -25 285 144 -25 air
execute in minecraft:overworld run fill 285 58 -24 285 73 -24 stone
execute in minecraft:overworld run fill 285 74 -24 285 75 -24 dirt
execute in minecraft:overworld run setblock 285 76 -24 coarse_dirt
execute in minecraft:overworld run fill 285 77 -24 285 144 -24 air
execute in minecraft:overworld run fill 285 58 -23 285 73 -23 stone
execute in minecraft:overworld run fill 285 74 -23 285 75 -23 dirt
execute in minecraft:overworld run setblock 285 76 -23 coarse_dirt
execute in minecraft:overworld run fill 285 77 -23 285 144 -23 air
execute in minecraft:overworld run fill 285 58 -22 285 72 -22 stone
execute in minecraft:overworld run fill 285 73 -22 285 74 -22 dirt
execute in minecraft:overworld run setblock 285 75 -22 coarse_dirt
execute in minecraft:overworld run fill 285 76 -22 285 144 -22 air
execute in minecraft:overworld run fill 285 58 -21 285 72 -21 stone
execute in minecraft:overworld run fill 285 73 -21 285 74 -21 dirt
execute in minecraft:overworld run setblock 285 75 -21 grass_block
execute in minecraft:overworld run fill 285 76 -21 285 144 -21 air
execute in minecraft:overworld run fill 285 58 -20 285 72 -20 stone
execute in minecraft:overworld run fill 285 73 -20 285 74 -20 dirt
execute in minecraft:overworld run setblock 285 75 -20 coarse_dirt
execute in minecraft:overworld run fill 285 76 -20 285 144 -20 air
execute in minecraft:overworld run fill 285 58 -19 285 72 -19 stone
execute in minecraft:overworld run fill 285 73 -19 285 74 -19 dirt
execute in minecraft:overworld run setblock 285 75 -19 coarse_dirt
execute in minecraft:overworld run fill 285 76 -19 285 144 -19 air
execute in minecraft:overworld run fill 285 58 -18 285 71 -18 stone
execute in minecraft:overworld run fill 285 72 -18 285 73 -18 dirt
execute in minecraft:overworld run setblock 285 74 -18 grass_block
execute in minecraft:overworld run fill 285 75 -18 285 144 -18 air
execute in minecraft:overworld run fill 285 58 -17 285 71 -17 stone
execute in minecraft:overworld run fill 285 72 -17 285 73 -17 dirt
execute in minecraft:overworld run setblock 285 74 -17 coarse_dirt
execute in minecraft:overworld run fill 285 75 -17 285 144 -17 air
execute in minecraft:overworld run fill 285 58 -16 285 70 -16 stone
execute in minecraft:overworld run fill 285 71 -16 285 72 -16 dirt
execute in minecraft:overworld run setblock 285 73 -16 coarse_dirt
execute in minecraft:overworld run fill 285 74 -16 285 144 -16 air
execute in minecraft:overworld run fill 285 58 -15 285 70 -15 stone
execute in minecraft:overworld run fill 285 71 -15 285 72 -15 dirt
execute in minecraft:overworld run setblock 285 73 -15 coarse_dirt
execute in minecraft:overworld run fill 285 74 -15 285 144 -15 air
execute in minecraft:overworld run fill 285 58 -14 285 70 -14 stone
execute in minecraft:overworld run fill 285 71 -14 285 72 -14 dirt
execute in minecraft:overworld run setblock 285 73 -14 coarse_dirt
execute in minecraft:overworld run fill 285 74 -14 285 144 -14 air
execute in minecraft:overworld run setblock 285 74 -14 grass
execute in minecraft:overworld run fill 285 58 -13 285 70 -13 stone
execute in minecraft:overworld run fill 285 71 -13 285 72 -13 dirt
execute in minecraft:overworld run setblock 285 73 -13 grass_block
execute in minecraft:overworld run fill 285 74 -13 285 144 -13 air
execute in minecraft:overworld run fill 285 58 -12 285 69 -12 stone
execute in minecraft:overworld run fill 285 70 -12 285 71 -12 dirt
execute in minecraft:overworld run setblock 285 72 -12 coarse_dirt
execute in minecraft:overworld run fill 285 73 -12 285 144 -12 air
execute in minecraft:overworld run fill 285 58 -11 285 69 -11 stone
execute in minecraft:overworld run fill 285 70 -11 285 71 -11 dirt
execute in minecraft:overworld run setblock 285 72 -11 coarse_dirt
execute in minecraft:overworld run fill 285 73 -11 285 144 -11 air
execute in minecraft:overworld run fill 285 58 -10 285 69 -10 stone
execute in minecraft:overworld run fill 285 70 -10 285 71 -10 dirt
execute in minecraft:overworld run setblock 285 72 -10 coarse_dirt
execute in minecraft:overworld run fill 285 73 -10 285 144 -10 air
execute in minecraft:overworld run fill 285 58 -9 285 69 -9 stone
execute in minecraft:overworld run fill 285 70 -9 285 71 -9 dirt
execute in minecraft:overworld run setblock 285 72 -9 coarse_dirt
execute in minecraft:overworld run fill 285 73 -9 285 144 -9 air
execute in minecraft:overworld run fill 285 58 -8 285 69 -8 stone
execute in minecraft:overworld run fill 285 70 -8 285 71 -8 dirt
execute in minecraft:overworld run setblock 285 72 -8 grass_block
execute in minecraft:overworld run fill 285 73 -8 285 144 -8 air
execute in minecraft:overworld run fill 285 58 -7 285 69 -7 stone
execute in minecraft:overworld run fill 285 70 -7 285 71 -7 dirt
execute in minecraft:overworld run setblock 285 72 -7 coarse_dirt
execute in minecraft:overworld run fill 285 73 -7 285 144 -7 air
execute in minecraft:overworld run fill 285 58 -6 285 69 -6 stone
execute in minecraft:overworld run fill 285 70 -6 285 71 -6 dirt
execute in minecraft:overworld run setblock 285 72 -6 coarse_dirt
execute in minecraft:overworld run fill 285 73 -6 285 144 -6 air
execute in minecraft:overworld run setblock 285 73 -6 grass
execute in minecraft:overworld run fill 285 58 -5 285 69 -5 stone
execute in minecraft:overworld run fill 285 70 -5 285 71 -5 dirt
execute in minecraft:overworld run setblock 285 72 -5 coarse_dirt
execute in minecraft:overworld run fill 285 73 -5 285 144 -5 air
execute in minecraft:overworld run setblock 285 73 -5 grass
execute in minecraft:overworld run fill 285 58 -4 285 69 -4 stone
execute in minecraft:overworld run fill 285 70 -4 285 71 -4 dirt
execute in minecraft:overworld run setblock 285 72 -4 grass_block
execute in minecraft:overworld run fill 285 73 -4 285 144 -4 air
execute in minecraft:overworld run fill 285 58 -3 285 69 -3 stone
execute in minecraft:overworld run fill 285 70 -3 285 71 -3 dirt
execute in minecraft:overworld run setblock 285 72 -3 coarse_dirt
execute in minecraft:overworld run fill 285 73 -3 285 144 -3 air
execute in minecraft:overworld run fill 285 58 -2 285 69 -2 stone
execute in minecraft:overworld run fill 285 70 -2 285 71 -2 dirt
execute in minecraft:overworld run setblock 285 72 -2 coarse_dirt
execute in minecraft:overworld run fill 285 73 -2 285 144 -2 air
execute in minecraft:overworld run setblock 285 73 -2 grass
execute in minecraft:overworld run fill 285 58 -1 285 69 -1 stone
execute in minecraft:overworld run fill 285 70 -1 285 71 -1 dirt
execute in minecraft:overworld run setblock 285 72 -1 grass_block
execute in minecraft:overworld run fill 285 73 -1 285 144 -1 air
execute in minecraft:overworld run fill 285 58 0 285 69 0 stone
execute in minecraft:overworld run fill 285 70 0 285 71 0 dirt
execute in minecraft:overworld run setblock 285 72 0 coarse_dirt
execute in minecraft:overworld run fill 285 73 0 285 144 0 air
execute in minecraft:overworld run fill 285 58 1 285 69 1 stone
execute in minecraft:overworld run fill 285 70 1 285 71 1 dirt
execute in minecraft:overworld run setblock 285 72 1 coarse_dirt
execute in minecraft:overworld run fill 285 73 1 285 144 1 air
execute in minecraft:overworld run fill 285 58 2 285 69 2 stone
execute in minecraft:overworld run fill 285 70 2 285 71 2 dirt
execute in minecraft:overworld run setblock 285 72 2 coarse_dirt
execute in minecraft:overworld run fill 285 73 2 285 144 2 air
execute in minecraft:overworld run fill 285 58 3 285 69 3 stone
execute in minecraft:overworld run fill 285 70 3 285 71 3 dirt
execute in minecraft:overworld run setblock 285 72 3 coarse_dirt
execute in minecraft:overworld run fill 285 73 3 285 144 3 air
execute in minecraft:overworld run fill 285 58 4 285 68 4 stone
execute in minecraft:overworld run fill 285 69 4 285 70 4 dirt
execute in minecraft:overworld run setblock 285 71 4 grass_block
execute in minecraft:overworld run fill 285 72 4 285 144 4 air
execute in minecraft:overworld run fill 285 58 5 285 68 5 stone
execute in minecraft:overworld run fill 285 69 5 285 70 5 dirt
execute in minecraft:overworld run setblock 285 71 5 coarse_dirt
execute in minecraft:overworld run fill 285 72 5 285 144 5 air
execute in minecraft:overworld run fill 285 58 6 285 67 6 stone
execute in minecraft:overworld run fill 285 68 6 285 69 6 dirt
execute in minecraft:overworld run setblock 285 70 6 grass_block
execute in minecraft:overworld run fill 285 71 6 285 144 6 air
execute in minecraft:overworld run fill 285 58 7 285 67 7 stone
execute in minecraft:overworld run fill 285 68 7 285 69 7 dirt
execute in minecraft:overworld run setblock 285 70 7 coarse_dirt
execute in minecraft:overworld run fill 285 71 7 285 144 7 air
execute in minecraft:overworld run fill 285 58 8 285 66 8 stone
execute in minecraft:overworld run fill 285 67 8 285 68 8 dirt
execute in minecraft:overworld run setblock 285 69 8 coarse_dirt
execute in minecraft:overworld run fill 285 70 8 285 144 8 air
execute in minecraft:overworld run fill 285 58 9 285 66 9 stone
execute in minecraft:overworld run fill 285 67 9 285 68 9 dirt
execute in minecraft:overworld run setblock 285 69 9 coarse_dirt
execute in minecraft:overworld run fill 285 70 9 285 144 9 air
execute in minecraft:overworld run fill 285 58 10 285 66 10 stone
execute in minecraft:overworld run fill 285 67 10 285 68 10 dirt
execute in minecraft:overworld run setblock 285 69 10 coarse_dirt
execute in minecraft:overworld run fill 285 70 10 285 144 10 air
execute in minecraft:overworld run fill 285 58 11 285 66 11 stone
execute in minecraft:overworld run fill 285 67 11 285 68 11 dirt
execute in minecraft:overworld run setblock 285 69 11 coarse_dirt
execute in minecraft:overworld run fill 285 70 11 285 144 11 air
execute in minecraft:overworld run fill 285 58 12 285 66 12 stone
execute in minecraft:overworld run fill 285 67 12 285 68 12 dirt
execute in minecraft:overworld run setblock 285 69 12 coarse_dirt
execute in minecraft:overworld run fill 285 70 12 285 144 12 air
execute in minecraft:overworld run fill 285 58 13 285 65 13 stone
execute in minecraft:overworld run fill 285 66 13 285 67 13 dirt
execute in minecraft:overworld run setblock 285 68 13 coarse_dirt
execute in minecraft:overworld run fill 285 69 13 285 144 13 air
execute in minecraft:overworld run fill 285 58 14 285 65 14 stone
execute in minecraft:overworld run fill 285 66 14 285 67 14 dirt
execute in minecraft:overworld run setblock 285 68 14 coarse_dirt
execute in minecraft:overworld run fill 285 69 14 285 144 14 air
execute in minecraft:overworld run fill 285 58 15 285 65 15 stone
execute in minecraft:overworld run fill 285 66 15 285 67 15 dirt
execute in minecraft:overworld run setblock 285 68 15 coarse_dirt
execute in minecraft:overworld run fill 285 69 15 285 144 15 air
execute in minecraft:overworld run fill 285 58 16 285 65 16 stone
execute in minecraft:overworld run fill 285 66 16 285 67 16 dirt
execute in minecraft:overworld run setblock 285 68 16 coarse_dirt
execute in minecraft:overworld run fill 285 69 16 285 144 16 air
execute in minecraft:overworld run fill 285 58 17 285 65 17 stone
execute in minecraft:overworld run fill 285 66 17 285 67 17 dirt
execute in minecraft:overworld run setblock 285 68 17 coarse_dirt
execute in minecraft:overworld run fill 285 69 17 285 144 17 air
execute in minecraft:overworld run fill 285 58 18 285 65 18 stone
execute in minecraft:overworld run fill 285 66 18 285 67 18 dirt
execute in minecraft:overworld run setblock 285 68 18 grass_block
execute in minecraft:overworld run fill 285 69 18 285 144 18 air
execute in minecraft:overworld run fill 285 58 19 285 64 19 stone
execute in minecraft:overworld run fill 285 65 19 285 66 19 dirt
execute in minecraft:overworld run setblock 285 67 19 coarse_dirt
execute in minecraft:overworld run fill 285 68 19 285 144 19 air
execute in minecraft:overworld run fill 285 58 20 285 64 20 stone
execute in minecraft:overworld run fill 285 65 20 285 66 20 dirt
execute in minecraft:overworld run setblock 285 67 20 coarse_dirt
execute in minecraft:overworld run fill 285 68 20 285 144 20 air
execute in minecraft:overworld run fill 285 58 21 285 64 21 stone
execute in minecraft:overworld run fill 285 65 21 285 66 21 dirt
execute in minecraft:overworld run setblock 285 67 21 coarse_dirt
execute in minecraft:overworld run fill 285 68 21 285 144 21 air
execute in minecraft:overworld run setblock 285 68 21 grass
execute in minecraft:overworld run fill 285 58 22 285 64 22 stone
execute in minecraft:overworld run fill 285 65 22 285 66 22 dirt
execute in minecraft:overworld run setblock 285 67 22 coarse_dirt
execute in minecraft:overworld run fill 285 68 22 285 144 22 air
execute in minecraft:overworld run fill 285 58 23 285 64 23 stone
execute in minecraft:overworld run fill 285 65 23 285 66 23 dirt
execute in minecraft:overworld run setblock 285 67 23 coarse_dirt
execute in minecraft:overworld run fill 285 68 23 285 144 23 air
execute in minecraft:overworld run fill 285 58 24 285 64 24 stone
execute in minecraft:overworld run fill 285 65 24 285 66 24 dirt
execute in minecraft:overworld run setblock 285 67 24 coarse_dirt
execute in minecraft:overworld run fill 285 68 24 285 144 24 air
execute in minecraft:overworld run fill 285 58 25 285 64 25 stone
schedule function blade_gallery:random/burned/part_123 1t replace
