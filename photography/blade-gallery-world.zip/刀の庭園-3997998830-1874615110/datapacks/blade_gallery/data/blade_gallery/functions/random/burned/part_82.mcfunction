execute in minecraft:overworld run fill 260 63 13 260 144 13 air
execute in minecraft:overworld run fill 260 63 13 260 64 13 water
execute in minecraft:overworld run fill 260 58 14 260 60 14 stone
execute in minecraft:overworld run fill 260 61 14 260 62 14 dirt
execute in minecraft:overworld run setblock 260 63 14 gravel
execute in minecraft:overworld run fill 260 64 14 260 144 14 air
execute in minecraft:overworld run fill 260 64 14 260 64 14 water
execute in minecraft:overworld run fill 260 58 15 260 60 15 stone
execute in minecraft:overworld run fill 260 61 15 260 62 15 dirt
execute in minecraft:overworld run setblock 260 63 15 gravel
execute in minecraft:overworld run fill 260 64 15 260 144 15 air
execute in minecraft:overworld run fill 260 64 15 260 64 15 water
execute in minecraft:overworld run fill 260 58 16 260 61 16 stone
execute in minecraft:overworld run fill 260 62 16 260 63 16 dirt
execute in minecraft:overworld run setblock 260 64 16 grass_block
execute in minecraft:overworld run fill 260 65 16 260 144 16 air
execute in minecraft:overworld run fill 260 58 17 260 61 17 stone
execute in minecraft:overworld run fill 260 62 17 260 63 17 dirt
execute in minecraft:overworld run setblock 260 64 17 grass_block
execute in minecraft:overworld run fill 260 65 17 260 144 17 air
execute in minecraft:overworld run fill 260 58 18 260 61 18 stone
execute in minecraft:overworld run fill 260 62 18 260 63 18 dirt
execute in minecraft:overworld run setblock 260 64 18 grass_block
execute in minecraft:overworld run fill 260 65 18 260 144 18 air
execute in minecraft:overworld run fill 260 58 19 260 61 19 stone
execute in minecraft:overworld run fill 260 62 19 260 63 19 dirt
execute in minecraft:overworld run setblock 260 64 19 grass_block
execute in minecraft:overworld run fill 260 65 19 260 144 19 air
execute in minecraft:overworld run fill 260 58 20 260 61 20 stone
execute in minecraft:overworld run fill 260 62 20 260 63 20 dirt
execute in minecraft:overworld run setblock 260 64 20 coarse_dirt
execute in minecraft:overworld run fill 260 65 20 260 144 20 air
execute in minecraft:overworld run fill 260 58 21 260 61 21 stone
execute in minecraft:overworld run fill 260 62 21 260 63 21 dirt
execute in minecraft:overworld run setblock 260 64 21 grass_block
execute in minecraft:overworld run fill 260 65 21 260 144 21 air
execute in minecraft:overworld run fill 260 58 22 260 60 22 stone
execute in minecraft:overworld run fill 260 61 22 260 62 22 dirt
execute in minecraft:overworld run setblock 260 63 22 gravel
execute in minecraft:overworld run fill 260 64 22 260 144 22 air
execute in minecraft:overworld run fill 260 64 22 260 64 22 water
execute in minecraft:overworld run fill 260 58 23 260 60 23 stone
execute in minecraft:overworld run fill 260 61 23 260 62 23 dirt
execute in minecraft:overworld run setblock 260 63 23 gravel
execute in minecraft:overworld run fill 260 64 23 260 144 23 air
execute in minecraft:overworld run fill 260 64 23 260 64 23 water
execute in minecraft:overworld run fill 260 58 24 260 60 24 stone
execute in minecraft:overworld run fill 260 61 24 260 62 24 dirt
execute in minecraft:overworld run setblock 260 63 24 gravel
execute in minecraft:overworld run fill 260 64 24 260 144 24 air
execute in minecraft:overworld run fill 260 64 24 260 64 24 water
execute in minecraft:overworld run fill 260 58 25 260 59 25 stone
execute in minecraft:overworld run fill 260 60 25 260 61 25 dirt
execute in minecraft:overworld run setblock 260 62 25 gravel
execute in minecraft:overworld run fill 260 63 25 260 144 25 air
execute in minecraft:overworld run fill 260 63 25 260 64 25 water
execute in minecraft:overworld run fill 260 58 26 260 59 26 stone
execute in minecraft:overworld run fill 260 60 26 260 61 26 dirt
execute in minecraft:overworld run setblock 260 62 26 gravel
execute in minecraft:overworld run fill 260 63 26 260 144 26 air
execute in minecraft:overworld run fill 260 63 26 260 64 26 water
execute in minecraft:overworld run fill 260 58 27 260 59 27 stone
execute in minecraft:overworld run fill 260 60 27 260 61 27 dirt
execute in minecraft:overworld run setblock 260 62 27 gravel
execute in minecraft:overworld run fill 260 63 27 260 144 27 air
execute in minecraft:overworld run fill 260 63 27 260 64 27 water
execute in minecraft:overworld run fill 260 58 28 260 58 28 stone
execute in minecraft:overworld run fill 260 59 28 260 60 28 dirt
execute in minecraft:overworld run setblock 260 61 28 gravel
execute in minecraft:overworld run fill 260 62 28 260 144 28 air
execute in minecraft:overworld run fill 260 62 28 260 64 28 water
execute in minecraft:overworld run fill 260 58 29 260 58 29 stone
execute in minecraft:overworld run fill 260 59 29 260 60 29 dirt
execute in minecraft:overworld run setblock 260 61 29 gravel
execute in minecraft:overworld run fill 260 62 29 260 144 29 air
execute in minecraft:overworld run fill 260 62 29 260 64 29 water
execute in minecraft:overworld run fill 260 58 30 260 58 30 stone
execute in minecraft:overworld run fill 260 59 30 260 60 30 dirt
execute in minecraft:overworld run setblock 260 61 30 gravel
execute in minecraft:overworld run fill 260 62 30 260 144 30 air
execute in minecraft:overworld run fill 260 62 30 260 64 30 water
execute in minecraft:overworld run fill 260 58 31 260 57 31 stone
execute in minecraft:overworld run fill 260 58 31 260 59 31 dirt
execute in minecraft:overworld run setblock 260 60 31 gravel
execute in minecraft:overworld run fill 260 61 31 260 144 31 air
execute in minecraft:overworld run fill 260 61 31 260 64 31 water
execute in minecraft:overworld run fill 260 58 32 260 57 32 stone
execute in minecraft:overworld run fill 260 58 32 260 59 32 dirt
execute in minecraft:overworld run setblock 260 60 32 gravel
execute in minecraft:overworld run fill 260 61 32 260 144 32 air
execute in minecraft:overworld run fill 260 61 32 260 64 32 water
execute in minecraft:overworld run fill 260 58 33 260 56 33 stone
execute in minecraft:overworld run fill 260 57 33 260 58 33 dirt
execute in minecraft:overworld run setblock 260 59 33 gravel
execute in minecraft:overworld run fill 260 60 33 260 144 33 air
execute in minecraft:overworld run fill 260 60 33 260 64 33 water
execute in minecraft:overworld run fill 260 58 34 260 56 34 stone
execute in minecraft:overworld run fill 260 57 34 260 58 34 dirt
execute in minecraft:overworld run setblock 260 59 34 gravel
execute in minecraft:overworld run fill 260 60 34 260 144 34 air
execute in minecraft:overworld run fill 260 60 34 260 64 34 water
execute in minecraft:overworld run fill 260 58 35 260 56 35 stone
execute in minecraft:overworld run fill 260 57 35 260 58 35 dirt
execute in minecraft:overworld run setblock 260 59 35 gravel
execute in minecraft:overworld run fill 260 60 35 260 144 35 air
execute in minecraft:overworld run fill 260 60 35 260 64 35 water
execute in minecraft:overworld run fill 260 58 36 260 55 36 stone
execute in minecraft:overworld run fill 260 56 36 260 57 36 dirt
execute in minecraft:overworld run setblock 260 58 36 gravel
execute in minecraft:overworld run fill 260 59 36 260 144 36 air
execute in minecraft:overworld run fill 260 59 36 260 64 36 water
execute in minecraft:overworld run fill 260 58 37 260 55 37 stone
execute in minecraft:overworld run fill 260 56 37 260 57 37 dirt
execute in minecraft:overworld run setblock 260 58 37 gravel
execute in minecraft:overworld run fill 260 59 37 260 144 37 air
execute in minecraft:overworld run fill 260 59 37 260 64 37 water
execute in minecraft:overworld run fill 260 58 38 260 55 38 stone
execute in minecraft:overworld run fill 260 56 38 260 57 38 dirt
execute in minecraft:overworld run setblock 260 58 38 gravel
execute in minecraft:overworld run fill 260 59 38 260 144 38 air
execute in minecraft:overworld run fill 260 59 38 260 64 38 water
execute in minecraft:overworld run fill 260 58 39 260 55 39 stone
execute in minecraft:overworld run fill 260 56 39 260 57 39 dirt
execute in minecraft:overworld run setblock 260 58 39 gravel
execute in minecraft:overworld run fill 260 59 39 260 144 39 air
execute in minecraft:overworld run fill 260 59 39 260 64 39 water
execute in minecraft:overworld run fill 260 58 40 260 56 40 stone
execute in minecraft:overworld run fill 260 57 40 260 58 40 dirt
execute in minecraft:overworld run setblock 260 59 40 gravel
execute in minecraft:overworld run fill 260 60 40 260 144 40 air
execute in minecraft:overworld run fill 260 60 40 260 64 40 water
execute in minecraft:overworld run fill 260 58 41 260 57 41 stone
execute in minecraft:overworld run fill 260 58 41 260 59 41 dirt
execute in minecraft:overworld run setblock 260 60 41 gravel
execute in minecraft:overworld run fill 260 61 41 260 144 41 air
execute in minecraft:overworld run fill 260 61 41 260 64 41 water
execute in minecraft:overworld run fill 260 58 42 260 58 42 stone
execute in minecraft:overworld run fill 260 59 42 260 60 42 dirt
execute in minecraft:overworld run setblock 260 61 42 gravel
execute in minecraft:overworld run fill 260 62 42 260 144 42 air
execute in minecraft:overworld run fill 260 62 42 260 64 42 water
execute in minecraft:overworld run fill 260 58 43 260 58 43 stone
execute in minecraft:overworld run fill 260 59 43 260 60 43 dirt
execute in minecraft:overworld run setblock 260 61 43 gravel
execute in minecraft:overworld run fill 260 62 43 260 144 43 air
execute in minecraft:overworld run fill 260 62 43 260 64 43 water
execute in minecraft:overworld run fill 260 58 44 260 59 44 stone
execute in minecraft:overworld run fill 260 60 44 260 61 44 dirt
execute in minecraft:overworld run setblock 260 62 44 gravel
execute in minecraft:overworld run fill 260 63 44 260 144 44 air
execute in minecraft:overworld run fill 260 63 44 260 64 44 water
execute in minecraft:overworld run fill 260 58 45 260 60 45 stone
execute in minecraft:overworld run fill 260 61 45 260 62 45 dirt
execute in minecraft:overworld run setblock 260 63 45 gravel
execute in minecraft:overworld run fill 260 64 45 260 144 45 air
execute in minecraft:overworld run fill 260 64 45 260 64 45 water
execute in minecraft:overworld run fill 260 58 46 260 60 46 stone
execute in minecraft:overworld run fill 260 61 46 260 62 46 dirt
execute in minecraft:overworld run setblock 260 63 46 gravel
execute in minecraft:overworld run fill 260 64 46 260 144 46 air
execute in minecraft:overworld run fill 260 64 46 260 64 46 water
execute in minecraft:overworld run fill 260 58 47 260 61 47 stone
execute in minecraft:overworld run fill 260 62 47 260 63 47 dirt
execute in minecraft:overworld run setblock 260 64 47 grass_block
execute in minecraft:overworld run fill 260 65 47 260 144 47 air
execute in minecraft:overworld run fill 261 58 -48 261 61 -48 stone
execute in minecraft:overworld run fill 261 62 -48 261 63 -48 dirt
execute in minecraft:overworld run setblock 261 64 -48 grass_block
execute in minecraft:overworld run fill 261 65 -48 261 144 -48 air
execute in minecraft:overworld run fill 261 58 -47 261 63 -47 stone
execute in minecraft:overworld run fill 261 64 -47 261 65 -47 dirt
execute in minecraft:overworld run setblock 261 66 -47 grass_block
execute in minecraft:overworld run fill 261 67 -47 261 144 -47 air
execute in minecraft:overworld run fill 261 58 -46 261 64 -46 stone
execute in minecraft:overworld run fill 261 65 -46 261 66 -46 dirt
execute in minecraft:overworld run setblock 261 67 -46 coarse_dirt
execute in minecraft:overworld run fill 261 68 -46 261 144 -46 air
execute in minecraft:overworld run fill 261 58 -45 261 66 -45 stone
execute in minecraft:overworld run fill 261 67 -45 261 68 -45 dirt
execute in minecraft:overworld run setblock 261 69 -45 grass_block
execute in minecraft:overworld run fill 261 70 -45 261 144 -45 air
execute in minecraft:overworld run fill 261 58 -44 261 68 -44 stone
execute in minecraft:overworld run fill 261 69 -44 261 70 -44 dirt
execute in minecraft:overworld run setblock 261 71 -44 coarse_dirt
execute in minecraft:overworld run fill 261 72 -44 261 144 -44 air
execute in minecraft:overworld run fill 261 58 -43 261 70 -43 stone
execute in minecraft:overworld run fill 261 71 -43 261 72 -43 dirt
execute in minecraft:overworld run setblock 261 73 -43 coarse_dirt
execute in minecraft:overworld run fill 261 74 -43 261 144 -43 air
execute in minecraft:overworld run fill 261 58 -42 261 71 -42 stone
execute in minecraft:overworld run fill 261 72 -42 261 73 -42 dirt
execute in minecraft:overworld run setblock 261 74 -42 coarse_dirt
execute in minecraft:overworld run fill 261 75 -42 261 144 -42 air
execute in minecraft:overworld run fill 261 58 -41 261 73 -41 stone
execute in minecraft:overworld run fill 261 74 -41 261 75 -41 dirt
execute in minecraft:overworld run setblock 261 76 -41 grass_block
execute in minecraft:overworld run fill 261 77 -41 261 144 -41 air
execute in minecraft:overworld run fill 261 58 -40 261 74 -40 stone
execute in minecraft:overworld run fill 261 75 -40 261 76 -40 dirt
execute in minecraft:overworld run setblock 261 77 -40 coarse_dirt
execute in minecraft:overworld run fill 261 78 -40 261 144 -40 air
execute in minecraft:overworld run setblock 261 78 -40 grass
execute in minecraft:overworld run fill 261 58 -39 261 76 -39 stone
execute in minecraft:overworld run fill 261 77 -39 261 78 -39 dirt
execute in minecraft:overworld run setblock 261 79 -39 grass_block
execute in minecraft:overworld run fill 261 80 -39 261 144 -39 air
execute in minecraft:overworld run fill 261 58 -38 261 77 -38 stone
execute in minecraft:overworld run fill 261 78 -38 261 79 -38 dirt
execute in minecraft:overworld run setblock 261 80 -38 coarse_dirt
execute in minecraft:overworld run fill 261 81 -38 261 144 -38 air
execute in minecraft:overworld run fill 261 58 -37 261 77 -37 stone
execute in minecraft:overworld run fill 261 78 -37 261 79 -37 dirt
execute in minecraft:overworld run setblock 261 80 -37 coarse_dirt
execute in minecraft:overworld run fill 261 81 -37 261 144 -37 air
execute in minecraft:overworld run fill 261 58 -36 261 77 -36 stone
execute in minecraft:overworld run fill 261 78 -36 261 79 -36 dirt
execute in minecraft:overworld run setblock 261 80 -36 coarse_dirt
execute in minecraft:overworld run fill 261 81 -36 261 144 -36 air
execute in minecraft:overworld run fill 261 58 -35 261 77 -35 stone
execute in minecraft:overworld run fill 261 78 -35 261 79 -35 dirt
execute in minecraft:overworld run setblock 261 80 -35 coarse_dirt
execute in minecraft:overworld run fill 261 81 -35 261 144 -35 air
execute in minecraft:overworld run fill 261 58 -34 261 77 -34 stone
execute in minecraft:overworld run fill 261 78 -34 261 79 -34 dirt
execute in minecraft:overworld run setblock 261 80 -34 grass_block
execute in minecraft:overworld run fill 261 81 -34 261 144 -34 air
execute in minecraft:overworld run fill 261 58 -33 261 76 -33 stone
execute in minecraft:overworld run fill 261 77 -33 261 78 -33 dirt
execute in minecraft:overworld run setblock 261 79 -33 coarse_dirt
execute in minecraft:overworld run fill 261 80 -33 261 144 -33 air
execute in minecraft:overworld run fill 261 58 -32 261 76 -32 stone
execute in minecraft:overworld run fill 261 77 -32 261 78 -32 dirt
execute in minecraft:overworld run setblock 261 79 -32 grass_block
execute in minecraft:overworld run fill 261 80 -32 261 144 -32 air
execute in minecraft:overworld run fill 261 58 -31 261 76 -31 stone
execute in minecraft:overworld run fill 261 77 -31 261 78 -31 dirt
execute in minecraft:overworld run setblock 261 79 -31 coarse_dirt
execute in minecraft:overworld run fill 261 80 -31 261 144 -31 air
execute in minecraft:overworld run fill 261 58 -30 261 75 -30 stone
execute in minecraft:overworld run fill 261 76 -30 261 77 -30 dirt
execute in minecraft:overworld run setblock 261 78 -30 coarse_dirt
execute in minecraft:overworld run fill 261 79 -30 261 144 -30 air
execute in minecraft:overworld run setblock 261 79 -30 grass
execute in minecraft:overworld run fill 261 58 -29 261 75 -29 stone
execute in minecraft:overworld run fill 261 76 -29 261 77 -29 dirt
execute in minecraft:overworld run setblock 261 78 -29 grass_block
execute in minecraft:overworld run fill 261 79 -29 261 144 -29 air
execute in minecraft:overworld run fill 261 58 -28 261 74 -28 stone
execute in minecraft:overworld run fill 261 75 -28 261 76 -28 dirt
execute in minecraft:overworld run setblock 261 77 -28 grass_block
execute in minecraft:overworld run fill 261 78 -28 261 144 -28 air
execute in minecraft:overworld run fill 261 58 -27 261 73 -27 stone
execute in minecraft:overworld run fill 261 74 -27 261 75 -27 dirt
execute in minecraft:overworld run setblock 261 76 -27 coarse_dirt
execute in minecraft:overworld run fill 261 77 -27 261 144 -27 air
execute in minecraft:overworld run fill 261 58 -26 261 73 -26 stone
schedule function blade_gallery:random/burned/part_83 1t replace
