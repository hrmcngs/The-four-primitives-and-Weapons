execute in minecraft:overworld run fill 352 71 -9 352 144 -9 air
execute in minecraft:overworld run fill 352 58 -8 352 67 -8 stone
execute in minecraft:overworld run fill 352 68 -8 352 69 -8 dirt
execute in minecraft:overworld run setblock 352 70 -8 coarse_dirt
execute in minecraft:overworld run fill 352 71 -8 352 144 -8 air
execute in minecraft:overworld run fill 352 58 -7 352 67 -7 stone
execute in minecraft:overworld run fill 352 68 -7 352 69 -7 dirt
execute in minecraft:overworld run setblock 352 70 -7 coarse_dirt
execute in minecraft:overworld run fill 352 71 -7 352 144 -7 air
execute in minecraft:overworld run fill 352 58 -6 352 67 -6 stone
execute in minecraft:overworld run fill 352 68 -6 352 69 -6 dirt
execute in minecraft:overworld run setblock 352 70 -6 coarse_dirt
execute in minecraft:overworld run fill 352 71 -6 352 144 -6 air
execute in minecraft:overworld run fill 352 58 -5 352 67 -5 stone
execute in minecraft:overworld run fill 352 68 -5 352 69 -5 dirt
execute in minecraft:overworld run setblock 352 70 -5 coarse_dirt
execute in minecraft:overworld run fill 352 71 -5 352 144 -5 air
execute in minecraft:overworld run fill 352 58 -4 352 66 -4 stone
execute in minecraft:overworld run fill 352 67 -4 352 68 -4 dirt
execute in minecraft:overworld run setblock 352 69 -4 grass_block
execute in minecraft:overworld run fill 352 70 -4 352 144 -4 air
execute in minecraft:overworld run fill 352 58 -3 352 66 -3 stone
execute in minecraft:overworld run fill 352 67 -3 352 68 -3 dirt
execute in minecraft:overworld run setblock 352 69 -3 coarse_dirt
execute in minecraft:overworld run fill 352 70 -3 352 144 -3 air
execute in minecraft:overworld run fill 352 58 -2 352 66 -2 stone
execute in minecraft:overworld run fill 352 67 -2 352 68 -2 dirt
execute in minecraft:overworld run setblock 352 69 -2 grass_block
execute in minecraft:overworld run fill 352 70 -2 352 144 -2 air
execute in minecraft:overworld run fill 352 58 -1 352 66 -1 stone
execute in minecraft:overworld run fill 352 67 -1 352 68 -1 dirt
execute in minecraft:overworld run setblock 352 69 -1 coarse_dirt
execute in minecraft:overworld run fill 352 70 -1 352 144 -1 air
execute in minecraft:overworld run fill 352 58 0 352 66 0 stone
execute in minecraft:overworld run fill 352 67 0 352 68 0 dirt
execute in minecraft:overworld run setblock 352 69 0 coarse_dirt
execute in minecraft:overworld run fill 352 70 0 352 144 0 air
execute in minecraft:overworld run fill 352 58 1 352 66 1 stone
execute in minecraft:overworld run fill 352 67 1 352 68 1 dirt
execute in minecraft:overworld run setblock 352 69 1 grass_block
execute in minecraft:overworld run fill 352 70 1 352 144 1 air
execute in minecraft:overworld run fill 352 58 2 352 66 2 stone
execute in minecraft:overworld run fill 352 67 2 352 68 2 dirt
execute in minecraft:overworld run setblock 352 69 2 coarse_dirt
execute in minecraft:overworld run fill 352 70 2 352 144 2 air
execute in minecraft:overworld run fill 352 58 3 352 67 3 stone
execute in minecraft:overworld run fill 352 68 3 352 69 3 dirt
execute in minecraft:overworld run setblock 352 70 3 grass_block
execute in minecraft:overworld run fill 352 71 3 352 144 3 air
execute in minecraft:overworld run fill 352 58 4 352 67 4 stone
execute in minecraft:overworld run fill 352 68 4 352 69 4 dirt
execute in minecraft:overworld run setblock 352 70 4 coarse_dirt
execute in minecraft:overworld run fill 352 71 4 352 144 4 air
execute in minecraft:overworld run fill 352 58 5 352 67 5 stone
execute in minecraft:overworld run fill 352 68 5 352 69 5 dirt
execute in minecraft:overworld run setblock 352 70 5 coarse_dirt
execute in minecraft:overworld run fill 352 71 5 352 144 5 air
execute in minecraft:overworld run fill 352 58 6 352 67 6 stone
execute in minecraft:overworld run fill 352 68 6 352 69 6 dirt
execute in minecraft:overworld run setblock 352 70 6 coarse_dirt
execute in minecraft:overworld run fill 352 71 6 352 144 6 air
execute in minecraft:overworld run fill 352 58 7 352 67 7 stone
execute in minecraft:overworld run fill 352 68 7 352 69 7 dirt
execute in minecraft:overworld run setblock 352 70 7 grass_block
execute in minecraft:overworld run fill 352 71 7 352 144 7 air
execute in minecraft:overworld run fill 352 58 8 352 67 8 stone
execute in minecraft:overworld run fill 352 68 8 352 69 8 dirt
execute in minecraft:overworld run setblock 352 70 8 coarse_dirt
execute in minecraft:overworld run fill 352 71 8 352 144 8 air
execute in minecraft:overworld run fill 352 58 9 352 67 9 stone
execute in minecraft:overworld run fill 352 68 9 352 69 9 dirt
execute in minecraft:overworld run setblock 352 70 9 coarse_dirt
execute in minecraft:overworld run fill 352 71 9 352 144 9 air
execute in minecraft:overworld run fill 352 58 10 352 67 10 stone
execute in minecraft:overworld run fill 352 68 10 352 69 10 dirt
execute in minecraft:overworld run setblock 352 70 10 grass_block
execute in minecraft:overworld run fill 352 71 10 352 144 10 air
execute in minecraft:overworld run fill 352 58 11 352 67 11 stone
execute in minecraft:overworld run fill 352 68 11 352 69 11 dirt
execute in minecraft:overworld run setblock 352 70 11 coarse_dirt
execute in minecraft:overworld run fill 352 71 11 352 144 11 air
execute in minecraft:overworld run fill 352 58 12 352 67 12 stone
execute in minecraft:overworld run fill 352 68 12 352 69 12 dirt
execute in minecraft:overworld run setblock 352 70 12 grass_block
execute in minecraft:overworld run fill 352 71 12 352 144 12 air
execute in minecraft:overworld run setblock 352 71 12 mossy_cobblestone
execute in minecraft:overworld run fill 352 58 13 352 67 13 stone
execute in minecraft:overworld run fill 352 68 13 352 69 13 dirt
execute in minecraft:overworld run setblock 352 70 13 coarse_dirt
execute in minecraft:overworld run fill 352 71 13 352 144 13 air
execute in minecraft:overworld run fill 352 58 14 352 66 14 stone
execute in minecraft:overworld run fill 352 67 14 352 68 14 dirt
execute in minecraft:overworld run setblock 352 69 14 grass_block
execute in minecraft:overworld run fill 352 70 14 352 144 14 air
execute in minecraft:overworld run fill 352 58 15 352 66 15 stone
execute in minecraft:overworld run fill 352 67 15 352 68 15 dirt
execute in minecraft:overworld run setblock 352 69 15 coarse_dirt
execute in minecraft:overworld run fill 352 70 15 352 144 15 air
execute in minecraft:overworld run fill 352 58 16 352 66 16 stone
execute in minecraft:overworld run fill 352 67 16 352 68 16 dirt
execute in minecraft:overworld run setblock 352 69 16 coarse_dirt
execute in minecraft:overworld run fill 352 70 16 352 144 16 air
execute in minecraft:overworld run fill 352 58 17 352 66 17 stone
execute in minecraft:overworld run fill 352 67 17 352 68 17 dirt
execute in minecraft:overworld run setblock 352 69 17 coarse_dirt
execute in minecraft:overworld run fill 352 70 17 352 144 17 air
execute in minecraft:overworld run fill 352 58 18 352 66 18 stone
execute in minecraft:overworld run fill 352 67 18 352 68 18 dirt
execute in minecraft:overworld run setblock 352 69 18 coarse_dirt
execute in minecraft:overworld run fill 352 70 18 352 144 18 air
execute in minecraft:overworld run fill 352 58 19 352 66 19 stone
execute in minecraft:overworld run fill 352 67 19 352 68 19 dirt
execute in minecraft:overworld run setblock 352 69 19 coarse_dirt
execute in minecraft:overworld run fill 352 70 19 352 144 19 air
execute in minecraft:overworld run setblock 352 70 19 grass
execute in minecraft:overworld run fill 352 58 20 352 66 20 stone
execute in minecraft:overworld run fill 352 67 20 352 68 20 dirt
execute in minecraft:overworld run setblock 352 69 20 coarse_dirt
execute in minecraft:overworld run fill 352 70 20 352 144 20 air
execute in minecraft:overworld run fill 352 58 21 352 66 21 stone
execute in minecraft:overworld run fill 352 67 21 352 68 21 dirt
execute in minecraft:overworld run setblock 352 69 21 grass_block
execute in minecraft:overworld run fill 352 70 21 352 144 21 air
execute in minecraft:overworld run fill 352 58 22 352 67 22 stone
execute in minecraft:overworld run fill 352 68 22 352 69 22 dirt
execute in minecraft:overworld run setblock 352 70 22 grass_block
execute in minecraft:overworld run fill 352 71 22 352 144 22 air
execute in minecraft:overworld run fill 352 58 23 352 67 23 stone
execute in minecraft:overworld run fill 352 68 23 352 69 23 dirt
execute in minecraft:overworld run setblock 352 70 23 coarse_dirt
execute in minecraft:overworld run fill 352 71 23 352 144 23 air
execute in minecraft:overworld run fill 352 58 24 352 68 24 stone
execute in minecraft:overworld run fill 352 69 24 352 70 24 dirt
execute in minecraft:overworld run setblock 352 71 24 coarse_dirt
execute in minecraft:overworld run fill 352 72 24 352 144 24 air
execute in minecraft:overworld run setblock 352 72 24 grass
execute in minecraft:overworld run fill 352 58 25 352 68 25 stone
execute in minecraft:overworld run fill 352 69 25 352 70 25 dirt
execute in minecraft:overworld run setblock 352 71 25 coarse_dirt
execute in minecraft:overworld run fill 352 72 25 352 144 25 air
execute in minecraft:overworld run setblock 352 72 25 grass
execute in minecraft:overworld run fill 352 58 26 352 68 26 stone
execute in minecraft:overworld run fill 352 69 26 352 70 26 dirt
execute in minecraft:overworld run setblock 352 71 26 coarse_dirt
execute in minecraft:overworld run fill 352 72 26 352 144 26 air
execute in minecraft:overworld run fill 352 58 27 352 68 27 stone
execute in minecraft:overworld run fill 352 69 27 352 70 27 dirt
execute in minecraft:overworld run setblock 352 71 27 coarse_dirt
execute in minecraft:overworld run fill 352 72 27 352 144 27 air
execute in minecraft:overworld run fill 352 58 28 352 68 28 stone
execute in minecraft:overworld run fill 352 69 28 352 70 28 dirt
execute in minecraft:overworld run setblock 352 71 28 coarse_dirt
execute in minecraft:overworld run fill 352 72 28 352 144 28 air
execute in minecraft:overworld run fill 352 58 29 352 68 29 stone
execute in minecraft:overworld run fill 352 69 29 352 70 29 dirt
execute in minecraft:overworld run setblock 352 71 29 coarse_dirt
execute in minecraft:overworld run fill 352 72 29 352 144 29 air
execute in minecraft:overworld run fill 352 58 30 352 68 30 stone
execute in minecraft:overworld run fill 352 69 30 352 70 30 dirt
execute in minecraft:overworld run setblock 352 71 30 coarse_dirt
execute in minecraft:overworld run fill 352 72 30 352 144 30 air
execute in minecraft:overworld run fill 352 58 31 352 68 31 stone
execute in minecraft:overworld run fill 352 69 31 352 70 31 dirt
execute in minecraft:overworld run setblock 352 71 31 coarse_dirt
execute in minecraft:overworld run fill 352 72 31 352 144 31 air
execute in minecraft:overworld run fill 352 58 32 352 68 32 stone
execute in minecraft:overworld run fill 352 69 32 352 70 32 dirt
execute in minecraft:overworld run setblock 352 71 32 coarse_dirt
execute in minecraft:overworld run fill 352 72 32 352 144 32 air
execute in minecraft:overworld run fill 352 58 33 352 68 33 stone
execute in minecraft:overworld run fill 352 69 33 352 70 33 dirt
execute in minecraft:overworld run setblock 352 71 33 grass_block
execute in minecraft:overworld run fill 352 72 33 352 144 33 air
execute in minecraft:overworld run fill 352 58 34 352 67 34 stone
execute in minecraft:overworld run fill 352 68 34 352 69 34 dirt
execute in minecraft:overworld run setblock 352 70 34 coarse_dirt
execute in minecraft:overworld run fill 352 71 34 352 144 34 air
execute in minecraft:overworld run fill 352 58 35 352 67 35 stone
execute in minecraft:overworld run fill 352 68 35 352 69 35 dirt
execute in minecraft:overworld run setblock 352 70 35 coarse_dirt
execute in minecraft:overworld run fill 352 71 35 352 144 35 air
execute in minecraft:overworld run fill 352 58 36 352 67 36 stone
execute in minecraft:overworld run fill 352 68 36 352 69 36 dirt
execute in minecraft:overworld run setblock 352 70 36 coarse_dirt
execute in minecraft:overworld run fill 352 71 36 352 144 36 air
execute in minecraft:overworld run fill 352 58 37 352 67 37 stone
execute in minecraft:overworld run fill 352 68 37 352 69 37 dirt
execute in minecraft:overworld run setblock 352 70 37 coarse_dirt
execute in minecraft:overworld run fill 352 71 37 352 144 37 air
execute in minecraft:overworld run fill 352 58 38 352 67 38 stone
execute in minecraft:overworld run fill 352 68 38 352 69 38 dirt
execute in minecraft:overworld run setblock 352 70 38 coarse_dirt
execute in minecraft:overworld run fill 352 71 38 352 144 38 air
execute in minecraft:overworld run fill 352 58 39 352 67 39 stone
execute in minecraft:overworld run fill 352 68 39 352 69 39 dirt
execute in minecraft:overworld run setblock 352 70 39 grass_block
execute in minecraft:overworld run fill 352 71 39 352 144 39 air
execute in minecraft:overworld run fill 352 58 40 352 66 40 stone
execute in minecraft:overworld run fill 352 67 40 352 68 40 dirt
execute in minecraft:overworld run setblock 352 69 40 coarse_dirt
execute in minecraft:overworld run fill 352 70 40 352 144 40 air
execute in minecraft:overworld run setblock 352 70 40 grass
execute in minecraft:overworld run fill 352 58 41 352 65 41 stone
execute in minecraft:overworld run fill 352 66 41 352 67 41 dirt
execute in minecraft:overworld run setblock 352 68 41 coarse_dirt
execute in minecraft:overworld run fill 352 69 41 352 144 41 air
execute in minecraft:overworld run fill 352 58 42 352 65 42 stone
execute in minecraft:overworld run fill 352 66 42 352 67 42 dirt
execute in minecraft:overworld run setblock 352 68 42 coarse_dirt
execute in minecraft:overworld run fill 352 69 42 352 144 42 air
execute in minecraft:overworld run fill 352 58 43 352 64 43 stone
execute in minecraft:overworld run fill 352 65 43 352 66 43 dirt
execute in minecraft:overworld run setblock 352 67 43 grass_block
execute in minecraft:overworld run fill 352 68 43 352 144 43 air
execute in minecraft:overworld run fill 352 58 44 352 64 44 stone
execute in minecraft:overworld run fill 352 65 44 352 66 44 dirt
execute in minecraft:overworld run setblock 352 67 44 coarse_dirt
execute in minecraft:overworld run fill 352 68 44 352 144 44 air
execute in minecraft:overworld run fill 352 58 45 352 63 45 stone
execute in minecraft:overworld run fill 352 64 45 352 65 45 dirt
execute in minecraft:overworld run setblock 352 66 45 coarse_dirt
execute in minecraft:overworld run fill 352 67 45 352 144 45 air
execute in minecraft:overworld run fill 352 58 46 352 62 46 stone
execute in minecraft:overworld run fill 352 63 46 352 64 46 dirt
execute in minecraft:overworld run setblock 352 65 46 coarse_dirt
execute in minecraft:overworld run fill 352 66 46 352 144 46 air
execute in minecraft:overworld run fill 352 58 47 352 62 47 stone
execute in minecraft:overworld run fill 352 63 47 352 64 47 dirt
execute in minecraft:overworld run setblock 352 65 47 coarse_dirt
execute in minecraft:overworld run fill 352 66 47 352 144 47 air
execute in minecraft:overworld run fill 353 58 -48 353 61 -48 stone
execute in minecraft:overworld run fill 353 62 -48 353 63 -48 dirt
execute in minecraft:overworld run setblock 353 64 -48 coarse_dirt
execute in minecraft:overworld run fill 353 65 -48 353 144 -48 air
execute in minecraft:overworld run fill 353 58 -47 353 63 -47 stone
execute in minecraft:overworld run fill 353 64 -47 353 65 -47 dirt
execute in minecraft:overworld run setblock 353 66 -47 coarse_dirt
execute in minecraft:overworld run fill 353 67 -47 353 144 -47 air
execute in minecraft:overworld run fill 353 58 -46 353 65 -46 stone
execute in minecraft:overworld run fill 353 66 -46 353 67 -46 dirt
execute in minecraft:overworld run setblock 353 68 -46 grass_block
execute in minecraft:overworld run fill 353 69 -46 353 144 -46 air
execute in minecraft:overworld run fill 353 58 -45 353 67 -45 stone
execute in minecraft:overworld run fill 353 68 -45 353 69 -45 dirt
execute in minecraft:overworld run setblock 353 70 -45 grass_block
execute in minecraft:overworld run fill 353 71 -45 353 144 -45 air
execute in minecraft:overworld run fill 353 58 -44 353 68 -44 stone
execute in minecraft:overworld run fill 353 69 -44 353 70 -44 dirt
execute in minecraft:overworld run setblock 353 71 -44 coarse_dirt
execute in minecraft:overworld run fill 353 72 -44 353 144 -44 air
execute in minecraft:overworld run fill 353 58 -43 353 70 -43 stone
execute in minecraft:overworld run fill 353 71 -43 353 72 -43 dirt
execute in minecraft:overworld run setblock 353 73 -43 grass_block
execute in minecraft:overworld run fill 353 74 -43 353 144 -43 air
execute in minecraft:overworld run fill 353 58 -42 353 71 -42 stone
execute in minecraft:overworld run fill 353 72 -42 353 73 -42 dirt
schedule function blade_gallery:random/battlefield/part_26 1t replace
