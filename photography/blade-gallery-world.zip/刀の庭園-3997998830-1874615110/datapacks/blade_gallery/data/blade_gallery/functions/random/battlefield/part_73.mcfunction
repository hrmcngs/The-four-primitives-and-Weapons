execute in minecraft:overworld run fill 383 58 2 383 63 2 stone
execute in minecraft:overworld run fill 383 64 2 383 65 2 dirt
execute in minecraft:overworld run setblock 383 66 2 coarse_dirt
execute in minecraft:overworld run fill 383 67 2 383 144 2 air
execute in minecraft:overworld run fill 383 58 3 383 63 3 stone
execute in minecraft:overworld run fill 383 64 3 383 65 3 dirt
execute in minecraft:overworld run setblock 383 66 3 coarse_dirt
execute in minecraft:overworld run fill 383 67 3 383 144 3 air
execute in minecraft:overworld run fill 383 58 4 383 63 4 stone
execute in minecraft:overworld run fill 383 64 4 383 65 4 dirt
execute in minecraft:overworld run setblock 383 66 4 coarse_dirt
execute in minecraft:overworld run fill 383 67 4 383 144 4 air
execute in minecraft:overworld run setblock 383 67 4 grass
execute in minecraft:overworld run fill 383 58 5 383 63 5 stone
execute in minecraft:overworld run fill 383 64 5 383 65 5 dirt
execute in minecraft:overworld run setblock 383 66 5 coarse_dirt
execute in minecraft:overworld run fill 383 67 5 383 144 5 air
execute in minecraft:overworld run fill 383 58 6 383 63 6 stone
execute in minecraft:overworld run fill 383 64 6 383 65 6 dirt
execute in minecraft:overworld run setblock 383 66 6 grass_block
execute in minecraft:overworld run fill 383 67 6 383 144 6 air
execute in minecraft:overworld run fill 383 58 7 383 63 7 stone
execute in minecraft:overworld run fill 383 64 7 383 65 7 dirt
execute in minecraft:overworld run setblock 383 66 7 grass_block
execute in minecraft:overworld run fill 383 67 7 383 144 7 air
execute in minecraft:overworld run fill 383 58 8 383 63 8 stone
execute in minecraft:overworld run fill 383 64 8 383 65 8 dirt
execute in minecraft:overworld run setblock 383 66 8 grass_block
execute in minecraft:overworld run fill 383 67 8 383 144 8 air
execute in minecraft:overworld run fill 383 58 9 383 63 9 stone
execute in minecraft:overworld run fill 383 64 9 383 65 9 dirt
execute in minecraft:overworld run setblock 383 66 9 grass_block
execute in minecraft:overworld run fill 383 67 9 383 144 9 air
execute in minecraft:overworld run setblock 383 67 9 mossy_cobblestone
execute in minecraft:overworld run fill 383 58 10 383 63 10 stone
execute in minecraft:overworld run fill 383 64 10 383 65 10 dirt
execute in minecraft:overworld run setblock 383 66 10 grass_block
execute in minecraft:overworld run fill 383 67 10 383 144 10 air
execute in minecraft:overworld run fill 383 58 11 383 64 11 stone
execute in minecraft:overworld run fill 383 65 11 383 66 11 dirt
execute in minecraft:overworld run setblock 383 67 11 grass_block
execute in minecraft:overworld run fill 383 68 11 383 144 11 air
execute in minecraft:overworld run fill 383 58 12 383 64 12 stone
execute in minecraft:overworld run fill 383 65 12 383 66 12 dirt
execute in minecraft:overworld run setblock 383 67 12 coarse_dirt
execute in minecraft:overworld run fill 383 68 12 383 144 12 air
execute in minecraft:overworld run fill 383 58 13 383 64 13 stone
execute in minecraft:overworld run fill 383 65 13 383 66 13 dirt
execute in minecraft:overworld run setblock 383 67 13 coarse_dirt
execute in minecraft:overworld run fill 383 68 13 383 144 13 air
execute in minecraft:overworld run fill 383 58 14 383 64 14 stone
execute in minecraft:overworld run fill 383 65 14 383 66 14 dirt
execute in minecraft:overworld run setblock 383 67 14 grass_block
execute in minecraft:overworld run fill 383 68 14 383 144 14 air
execute in minecraft:overworld run fill 383 58 15 383 65 15 stone
execute in minecraft:overworld run fill 383 66 15 383 67 15 dirt
execute in minecraft:overworld run setblock 383 68 15 coarse_dirt
execute in minecraft:overworld run fill 383 69 15 383 144 15 air
execute in minecraft:overworld run fill 383 58 16 383 65 16 stone
execute in minecraft:overworld run fill 383 66 16 383 67 16 dirt
execute in minecraft:overworld run setblock 383 68 16 grass_block
execute in minecraft:overworld run fill 383 69 16 383 144 16 air
execute in minecraft:overworld run fill 383 58 17 383 65 17 stone
execute in minecraft:overworld run fill 383 66 17 383 67 17 dirt
execute in minecraft:overworld run setblock 383 68 17 coarse_dirt
execute in minecraft:overworld run fill 383 69 17 383 144 17 air
execute in minecraft:overworld run fill 383 58 18 383 65 18 stone
execute in minecraft:overworld run fill 383 66 18 383 67 18 dirt
execute in minecraft:overworld run setblock 383 68 18 coarse_dirt
execute in minecraft:overworld run fill 383 69 18 383 144 18 air
execute in minecraft:overworld run fill 383 58 19 383 65 19 stone
execute in minecraft:overworld run fill 383 66 19 383 67 19 dirt
execute in minecraft:overworld run setblock 383 68 19 coarse_dirt
execute in minecraft:overworld run fill 383 69 19 383 144 19 air
execute in minecraft:overworld run fill 383 58 20 383 65 20 stone
execute in minecraft:overworld run fill 383 66 20 383 67 20 dirt
execute in minecraft:overworld run setblock 383 68 20 coarse_dirt
execute in minecraft:overworld run fill 383 69 20 383 144 20 air
execute in minecraft:overworld run fill 383 58 21 383 65 21 stone
execute in minecraft:overworld run fill 383 66 21 383 67 21 dirt
execute in minecraft:overworld run setblock 383 68 21 coarse_dirt
execute in minecraft:overworld run fill 383 69 21 383 144 21 air
execute in minecraft:overworld run setblock 383 69 21 grass
execute in minecraft:overworld run fill 383 58 22 383 65 22 stone
execute in minecraft:overworld run fill 383 66 22 383 67 22 dirt
execute in minecraft:overworld run setblock 383 68 22 grass_block
execute in minecraft:overworld run fill 383 69 22 383 144 22 air
execute in minecraft:overworld run setblock 383 69 22 grass
execute in minecraft:overworld run fill 383 58 23 383 65 23 stone
execute in minecraft:overworld run fill 383 66 23 383 67 23 dirt
execute in minecraft:overworld run setblock 383 68 23 coarse_dirt
execute in minecraft:overworld run fill 383 69 23 383 144 23 air
execute in minecraft:overworld run fill 383 58 24 383 65 24 stone
execute in minecraft:overworld run fill 383 66 24 383 67 24 dirt
execute in minecraft:overworld run setblock 383 68 24 grass_block
execute in minecraft:overworld run fill 383 69 24 383 144 24 air
execute in minecraft:overworld run fill 383 58 25 383 65 25 stone
execute in minecraft:overworld run fill 383 66 25 383 67 25 dirt
execute in minecraft:overworld run setblock 383 68 25 coarse_dirt
execute in minecraft:overworld run fill 383 69 25 383 144 25 air
execute in minecraft:overworld run setblock 383 69 25 grass
execute in minecraft:overworld run fill 383 58 26 383 64 26 stone
execute in minecraft:overworld run fill 383 65 26 383 66 26 dirt
execute in minecraft:overworld run setblock 383 67 26 coarse_dirt
execute in minecraft:overworld run fill 383 68 26 383 144 26 air
execute in minecraft:overworld run fill 383 58 27 383 64 27 stone
execute in minecraft:overworld run fill 383 65 27 383 66 27 dirt
execute in minecraft:overworld run setblock 383 67 27 coarse_dirt
execute in minecraft:overworld run fill 383 68 27 383 144 27 air
execute in minecraft:overworld run fill 383 58 28 383 64 28 stone
execute in minecraft:overworld run fill 383 65 28 383 66 28 dirt
execute in minecraft:overworld run setblock 383 67 28 coarse_dirt
execute in minecraft:overworld run fill 383 68 28 383 144 28 air
execute in minecraft:overworld run fill 383 58 29 383 64 29 stone
execute in minecraft:overworld run fill 383 65 29 383 66 29 dirt
execute in minecraft:overworld run setblock 383 67 29 grass_block
execute in minecraft:overworld run fill 383 68 29 383 144 29 air
execute in minecraft:overworld run fill 383 58 30 383 64 30 stone
execute in minecraft:overworld run fill 383 65 30 383 66 30 dirt
execute in minecraft:overworld run setblock 383 67 30 coarse_dirt
execute in minecraft:overworld run fill 383 68 30 383 144 30 air
execute in minecraft:overworld run setblock 383 68 30 grass
execute in minecraft:overworld run fill 383 58 31 383 64 31 stone
execute in minecraft:overworld run fill 383 65 31 383 66 31 dirt
execute in minecraft:overworld run setblock 383 67 31 grass_block
execute in minecraft:overworld run fill 383 68 31 383 144 31 air
execute in minecraft:overworld run fill 383 58 32 383 64 32 stone
execute in minecraft:overworld run fill 383 65 32 383 66 32 dirt
execute in minecraft:overworld run setblock 383 67 32 coarse_dirt
execute in minecraft:overworld run fill 383 68 32 383 144 32 air
execute in minecraft:overworld run fill 383 58 33 383 64 33 stone
execute in minecraft:overworld run fill 383 65 33 383 66 33 dirt
execute in minecraft:overworld run setblock 383 67 33 grass_block
execute in minecraft:overworld run fill 383 68 33 383 144 33 air
execute in minecraft:overworld run fill 383 58 34 383 63 34 stone
execute in minecraft:overworld run fill 383 64 34 383 65 34 dirt
execute in minecraft:overworld run setblock 383 66 34 coarse_dirt
execute in minecraft:overworld run fill 383 67 34 383 144 34 air
execute in minecraft:overworld run fill 383 58 35 383 63 35 stone
execute in minecraft:overworld run fill 383 64 35 383 65 35 dirt
execute in minecraft:overworld run setblock 383 66 35 coarse_dirt
execute in minecraft:overworld run fill 383 67 35 383 144 35 air
execute in minecraft:overworld run fill 383 58 36 383 63 36 stone
execute in minecraft:overworld run fill 383 64 36 383 65 36 dirt
execute in minecraft:overworld run setblock 383 66 36 coarse_dirt
execute in minecraft:overworld run fill 383 67 36 383 144 36 air
execute in minecraft:overworld run fill 383 58 37 383 63 37 stone
execute in minecraft:overworld run fill 383 64 37 383 65 37 dirt
execute in minecraft:overworld run setblock 383 66 37 coarse_dirt
execute in minecraft:overworld run fill 383 67 37 383 144 37 air
execute in minecraft:overworld run fill 383 58 38 383 62 38 stone
execute in minecraft:overworld run fill 383 63 38 383 64 38 dirt
execute in minecraft:overworld run setblock 383 65 38 coarse_dirt
execute in minecraft:overworld run fill 383 66 38 383 144 38 air
execute in minecraft:overworld run fill 383 58 39 383 62 39 stone
execute in minecraft:overworld run fill 383 63 39 383 64 39 dirt
execute in minecraft:overworld run setblock 383 65 39 coarse_dirt
execute in minecraft:overworld run fill 383 66 39 383 144 39 air
execute in minecraft:overworld run setblock 383 66 39 grass
execute in minecraft:overworld run fill 383 58 40 383 62 40 stone
execute in minecraft:overworld run fill 383 63 40 383 64 40 dirt
execute in minecraft:overworld run setblock 383 65 40 coarse_dirt
execute in minecraft:overworld run fill 383 66 40 383 144 40 air
execute in minecraft:overworld run fill 383 58 41 383 61 41 stone
execute in minecraft:overworld run fill 383 62 41 383 63 41 dirt
execute in minecraft:overworld run setblock 383 64 41 coarse_dirt
execute in minecraft:overworld run fill 383 65 41 383 144 41 air
execute in minecraft:overworld run fill 383 58 42 383 61 42 stone
execute in minecraft:overworld run fill 383 62 42 383 63 42 dirt
execute in minecraft:overworld run setblock 383 64 42 grass_block
execute in minecraft:overworld run fill 383 65 42 383 144 42 air
execute in minecraft:overworld run fill 383 58 43 383 61 43 stone
execute in minecraft:overworld run fill 383 62 43 383 63 43 dirt
execute in minecraft:overworld run setblock 383 64 43 coarse_dirt
execute in minecraft:overworld run fill 383 65 43 383 144 43 air
execute in minecraft:overworld run fill 383 58 44 383 61 44 stone
execute in minecraft:overworld run fill 383 62 44 383 63 44 dirt
execute in minecraft:overworld run setblock 383 64 44 coarse_dirt
execute in minecraft:overworld run fill 383 65 44 383 144 44 air
execute in minecraft:overworld run fill 383 58 45 383 61 45 stone
execute in minecraft:overworld run fill 383 62 45 383 63 45 dirt
execute in minecraft:overworld run setblock 383 64 45 grass_block
execute in minecraft:overworld run fill 383 65 45 383 144 45 air
execute in minecraft:overworld run fill 383 58 46 383 61 46 stone
execute in minecraft:overworld run fill 383 62 46 383 63 46 dirt
execute in minecraft:overworld run setblock 383 64 46 coarse_dirt
execute in minecraft:overworld run fill 383 65 46 383 144 46 air
execute in minecraft:overworld run fill 383 58 47 383 61 47 stone
execute in minecraft:overworld run fill 383 62 47 383 63 47 dirt
execute in minecraft:overworld run setblock 383 64 47 grass_block
execute in minecraft:overworld run fill 383 65 47 383 144 47 air
execute in minecraft:overworld run fill 384 58 -48 384 61 -48 stone
execute in minecraft:overworld run fill 384 62 -48 384 63 -48 dirt
execute in minecraft:overworld run setblock 384 64 -48 coarse_dirt
execute in minecraft:overworld run fill 384 65 -48 384 144 -48 air
execute in minecraft:overworld run fill 384 58 -47 384 62 -47 stone
execute in minecraft:overworld run fill 384 63 -47 384 64 -47 dirt
execute in minecraft:overworld run setblock 384 65 -47 grass_block
execute in minecraft:overworld run fill 384 66 -47 384 144 -47 air
execute in minecraft:overworld run fill 384 58 -46 384 64 -46 stone
execute in minecraft:overworld run fill 384 65 -46 384 66 -46 dirt
execute in minecraft:overworld run setblock 384 67 -46 grass_block
execute in minecraft:overworld run fill 384 68 -46 384 144 -46 air
execute in minecraft:overworld run fill 384 58 -45 384 65 -45 stone
execute in minecraft:overworld run fill 384 66 -45 384 67 -45 dirt
execute in minecraft:overworld run setblock 384 68 -45 grass_block
execute in minecraft:overworld run fill 384 69 -45 384 144 -45 air
execute in minecraft:overworld run fill 384 58 -44 384 66 -44 stone
execute in minecraft:overworld run fill 384 67 -44 384 68 -44 dirt
execute in minecraft:overworld run setblock 384 69 -44 grass_block
execute in minecraft:overworld run fill 384 70 -44 384 144 -44 air
execute in minecraft:overworld run fill 384 58 -43 384 68 -43 stone
execute in minecraft:overworld run fill 384 69 -43 384 70 -43 dirt
execute in minecraft:overworld run setblock 384 71 -43 grass_block
execute in minecraft:overworld run fill 384 72 -43 384 144 -43 air
execute in minecraft:overworld run fill 384 58 -42 384 68 -42 stone
execute in minecraft:overworld run fill 384 69 -42 384 70 -42 dirt
execute in minecraft:overworld run setblock 384 71 -42 coarse_dirt
execute in minecraft:overworld run fill 384 72 -42 384 144 -42 air
execute in minecraft:overworld run fill 384 58 -41 384 69 -41 stone
execute in minecraft:overworld run fill 384 70 -41 384 71 -41 dirt
execute in minecraft:overworld run setblock 384 72 -41 grass_block
execute in minecraft:overworld run fill 384 73 -41 384 144 -41 air
execute in minecraft:overworld run fill 384 58 -40 384 70 -40 stone
execute in minecraft:overworld run fill 384 71 -40 384 72 -40 dirt
execute in minecraft:overworld run setblock 384 73 -40 grass_block
execute in minecraft:overworld run fill 384 74 -40 384 144 -40 air
execute in minecraft:overworld run fill 384 58 -39 384 70 -39 stone
execute in minecraft:overworld run fill 384 71 -39 384 72 -39 dirt
execute in minecraft:overworld run setblock 384 73 -39 coarse_dirt
execute in minecraft:overworld run fill 384 74 -39 384 144 -39 air
execute in minecraft:overworld run fill 384 58 -38 384 71 -38 stone
execute in minecraft:overworld run fill 384 72 -38 384 73 -38 dirt
execute in minecraft:overworld run setblock 384 74 -38 coarse_dirt
execute in minecraft:overworld run fill 384 75 -38 384 144 -38 air
execute in minecraft:overworld run fill 384 58 -37 384 70 -37 stone
execute in minecraft:overworld run fill 384 71 -37 384 72 -37 dirt
execute in minecraft:overworld run setblock 384 73 -37 grass_block
execute in minecraft:overworld run fill 384 74 -37 384 144 -37 air
execute in minecraft:overworld run fill 384 58 -36 384 69 -36 stone
execute in minecraft:overworld run fill 384 70 -36 384 71 -36 dirt
execute in minecraft:overworld run setblock 384 72 -36 grass_block
execute in minecraft:overworld run fill 384 73 -36 384 144 -36 air
execute in minecraft:overworld run fill 384 58 -35 384 69 -35 stone
execute in minecraft:overworld run fill 384 70 -35 384 71 -35 dirt
execute in minecraft:overworld run setblock 384 72 -35 coarse_dirt
execute in minecraft:overworld run fill 384 73 -35 384 144 -35 air
execute in minecraft:overworld run fill 384 58 -34 384 68 -34 stone
execute in minecraft:overworld run fill 384 69 -34 384 70 -34 dirt
execute in minecraft:overworld run setblock 384 71 -34 coarse_dirt
execute in minecraft:overworld run fill 384 72 -34 384 144 -34 air
execute in minecraft:overworld run fill 384 58 -33 384 68 -33 stone
execute in minecraft:overworld run fill 384 69 -33 384 70 -33 dirt
execute in minecraft:overworld run setblock 384 71 -33 coarse_dirt
execute in minecraft:overworld run fill 384 72 -33 384 144 -33 air
execute in minecraft:overworld run setblock 384 72 -33 grass
schedule function blade_gallery:random/battlefield/part_74 1t replace
