execute in minecraft:overworld run setblock 356 66 45 coarse_dirt
execute in minecraft:overworld run fill 356 67 45 356 144 45 air
execute in minecraft:overworld run fill 356 58 46 356 62 46 stone
execute in minecraft:overworld run fill 356 63 46 356 64 46 dirt
execute in minecraft:overworld run setblock 356 65 46 grass_block
execute in minecraft:overworld run fill 356 66 46 356 144 46 air
execute in minecraft:overworld run fill 356 58 47 356 62 47 stone
execute in minecraft:overworld run fill 356 63 47 356 64 47 dirt
execute in minecraft:overworld run setblock 356 65 47 coarse_dirt
execute in minecraft:overworld run fill 356 66 47 356 144 47 air
execute in minecraft:overworld run fill 357 58 -48 357 61 -48 stone
execute in minecraft:overworld run fill 357 62 -48 357 63 -48 dirt
execute in minecraft:overworld run setblock 357 64 -48 coarse_dirt
execute in minecraft:overworld run fill 357 65 -48 357 144 -48 air
execute in minecraft:overworld run fill 357 58 -47 357 63 -47 stone
execute in minecraft:overworld run fill 357 64 -47 357 65 -47 dirt
execute in minecraft:overworld run setblock 357 66 -47 grass_block
execute in minecraft:overworld run fill 357 67 -47 357 144 -47 air
execute in minecraft:overworld run fill 357 58 -46 357 65 -46 stone
execute in minecraft:overworld run fill 357 66 -46 357 67 -46 dirt
execute in minecraft:overworld run setblock 357 68 -46 coarse_dirt
execute in minecraft:overworld run fill 357 69 -46 357 144 -46 air
execute in minecraft:overworld run fill 357 58 -45 357 67 -45 stone
execute in minecraft:overworld run fill 357 68 -45 357 69 -45 dirt
execute in minecraft:overworld run setblock 357 70 -45 coarse_dirt
execute in minecraft:overworld run fill 357 71 -45 357 144 -45 air
execute in minecraft:overworld run fill 357 58 -44 357 68 -44 stone
execute in minecraft:overworld run fill 357 69 -44 357 70 -44 dirt
execute in minecraft:overworld run setblock 357 71 -44 coarse_dirt
execute in minecraft:overworld run fill 357 72 -44 357 144 -44 air
execute in minecraft:overworld run fill 357 58 -43 357 70 -43 stone
execute in minecraft:overworld run fill 357 71 -43 357 72 -43 dirt
execute in minecraft:overworld run setblock 357 73 -43 grass_block
execute in minecraft:overworld run fill 357 74 -43 357 144 -43 air
execute in minecraft:overworld run fill 357 58 -42 357 71 -42 stone
execute in minecraft:overworld run fill 357 72 -42 357 73 -42 dirt
execute in minecraft:overworld run setblock 357 74 -42 coarse_dirt
execute in minecraft:overworld run fill 357 75 -42 357 144 -42 air
execute in minecraft:overworld run fill 357 58 -41 357 72 -41 stone
execute in minecraft:overworld run fill 357 73 -41 357 74 -41 dirt
execute in minecraft:overworld run setblock 357 75 -41 grass_block
execute in minecraft:overworld run fill 357 76 -41 357 144 -41 air
execute in minecraft:overworld run setblock 357 76 -41 grass
execute in minecraft:overworld run fill 357 58 -40 357 74 -40 stone
execute in minecraft:overworld run fill 357 75 -40 357 76 -40 dirt
execute in minecraft:overworld run setblock 357 77 -40 coarse_dirt
execute in minecraft:overworld run fill 357 78 -40 357 144 -40 air
execute in minecraft:overworld run fill 357 58 -39 357 75 -39 stone
execute in minecraft:overworld run fill 357 76 -39 357 77 -39 dirt
execute in minecraft:overworld run setblock 357 78 -39 coarse_dirt
execute in minecraft:overworld run fill 357 79 -39 357 144 -39 air
execute in minecraft:overworld run fill 357 58 -38 357 75 -38 stone
execute in minecraft:overworld run fill 357 76 -38 357 77 -38 dirt
execute in minecraft:overworld run setblock 357 78 -38 coarse_dirt
execute in minecraft:overworld run fill 357 79 -38 357 144 -38 air
execute in minecraft:overworld run setblock 357 79 -38 grass
execute in minecraft:overworld run fill 357 58 -37 357 75 -37 stone
execute in minecraft:overworld run fill 357 76 -37 357 77 -37 dirt
execute in minecraft:overworld run setblock 357 78 -37 coarse_dirt
execute in minecraft:overworld run fill 357 79 -37 357 144 -37 air
execute in minecraft:overworld run fill 357 58 -36 357 75 -36 stone
execute in minecraft:overworld run fill 357 76 -36 357 77 -36 dirt
execute in minecraft:overworld run setblock 357 78 -36 coarse_dirt
execute in minecraft:overworld run fill 357 79 -36 357 144 -36 air
execute in minecraft:overworld run fill 357 58 -35 357 74 -35 stone
execute in minecraft:overworld run fill 357 75 -35 357 76 -35 dirt
execute in minecraft:overworld run setblock 357 77 -35 coarse_dirt
execute in minecraft:overworld run fill 357 78 -35 357 144 -35 air
execute in minecraft:overworld run fill 357 58 -34 357 74 -34 stone
execute in minecraft:overworld run fill 357 75 -34 357 76 -34 dirt
execute in minecraft:overworld run setblock 357 77 -34 grass_block
execute in minecraft:overworld run fill 357 78 -34 357 144 -34 air
execute in minecraft:overworld run setblock 357 78 -34 grass
execute in minecraft:overworld run fill 357 58 -33 357 74 -33 stone
execute in minecraft:overworld run fill 357 75 -33 357 76 -33 dirt
execute in minecraft:overworld run setblock 357 77 -33 grass_block
execute in minecraft:overworld run fill 357 78 -33 357 144 -33 air
execute in minecraft:overworld run fill 357 58 -32 357 74 -32 stone
execute in minecraft:overworld run fill 357 75 -32 357 76 -32 dirt
execute in minecraft:overworld run setblock 357 77 -32 coarse_dirt
execute in minecraft:overworld run fill 357 78 -32 357 144 -32 air
execute in minecraft:overworld run fill 357 58 -31 357 74 -31 stone
execute in minecraft:overworld run fill 357 75 -31 357 76 -31 dirt
execute in minecraft:overworld run setblock 357 77 -31 grass_block
execute in minecraft:overworld run fill 357 78 -31 357 144 -31 air
execute in minecraft:overworld run fill 357 58 -30 357 74 -30 stone
execute in minecraft:overworld run fill 357 75 -30 357 76 -30 dirt
execute in minecraft:overworld run setblock 357 77 -30 coarse_dirt
execute in minecraft:overworld run fill 357 78 -30 357 144 -30 air
execute in minecraft:overworld run fill 357 58 -29 357 74 -29 stone
execute in minecraft:overworld run fill 357 75 -29 357 76 -29 dirt
execute in minecraft:overworld run setblock 357 77 -29 coarse_dirt
execute in minecraft:overworld run fill 357 78 -29 357 144 -29 air
execute in minecraft:overworld run fill 357 58 -28 357 73 -28 stone
execute in minecraft:overworld run fill 357 74 -28 357 75 -28 dirt
execute in minecraft:overworld run setblock 357 76 -28 grass_block
execute in minecraft:overworld run fill 357 77 -28 357 144 -28 air
execute in minecraft:overworld run fill 357 58 -27 357 73 -27 stone
execute in minecraft:overworld run fill 357 74 -27 357 75 -27 dirt
execute in minecraft:overworld run setblock 357 76 -27 coarse_dirt
execute in minecraft:overworld run fill 357 77 -27 357 144 -27 air
execute in minecraft:overworld run fill 357 58 -26 357 73 -26 stone
execute in minecraft:overworld run fill 357 74 -26 357 75 -26 dirt
execute in minecraft:overworld run setblock 357 76 -26 coarse_dirt
execute in minecraft:overworld run fill 357 77 -26 357 144 -26 air
execute in minecraft:overworld run fill 357 58 -25 357 72 -25 stone
execute in minecraft:overworld run fill 357 73 -25 357 74 -25 dirt
execute in minecraft:overworld run setblock 357 75 -25 grass_block
execute in minecraft:overworld run fill 357 76 -25 357 144 -25 air
execute in minecraft:overworld run fill 357 58 -24 357 72 -24 stone
execute in minecraft:overworld run fill 357 73 -24 357 74 -24 dirt
execute in minecraft:overworld run setblock 357 75 -24 coarse_dirt
execute in minecraft:overworld run fill 357 76 -24 357 144 -24 air
execute in minecraft:overworld run fill 357 58 -23 357 72 -23 stone
execute in minecraft:overworld run fill 357 73 -23 357 74 -23 dirt
execute in minecraft:overworld run setblock 357 75 -23 coarse_dirt
execute in minecraft:overworld run fill 357 76 -23 357 144 -23 air
execute in minecraft:overworld run fill 357 58 -22 357 71 -22 stone
execute in minecraft:overworld run fill 357 72 -22 357 73 -22 dirt
execute in minecraft:overworld run setblock 357 74 -22 coarse_dirt
execute in minecraft:overworld run fill 357 75 -22 357 144 -22 air
execute in minecraft:overworld run fill 357 58 -21 357 71 -21 stone
execute in minecraft:overworld run fill 357 72 -21 357 73 -21 dirt
execute in minecraft:overworld run setblock 357 74 -21 grass_block
execute in minecraft:overworld run fill 357 75 -21 357 144 -21 air
execute in minecraft:overworld run fill 357 58 -20 357 71 -20 stone
execute in minecraft:overworld run fill 357 72 -20 357 73 -20 dirt
execute in minecraft:overworld run setblock 357 74 -20 coarse_dirt
execute in minecraft:overworld run fill 357 75 -20 357 144 -20 air
execute in minecraft:overworld run fill 357 58 -19 357 70 -19 stone
execute in minecraft:overworld run fill 357 71 -19 357 72 -19 dirt
execute in minecraft:overworld run setblock 357 73 -19 coarse_dirt
execute in minecraft:overworld run fill 357 74 -19 357 144 -19 air
execute in minecraft:overworld run setblock 357 74 -19 mossy_cobblestone
execute in minecraft:overworld run fill 357 58 -18 357 70 -18 stone
execute in minecraft:overworld run fill 357 71 -18 357 72 -18 dirt
execute in minecraft:overworld run setblock 357 73 -18 coarse_dirt
execute in minecraft:overworld run fill 357 74 -18 357 144 -18 air
execute in minecraft:overworld run fill 357 58 -17 357 70 -17 stone
execute in minecraft:overworld run fill 357 71 -17 357 72 -17 dirt
execute in minecraft:overworld run setblock 357 73 -17 grass_block
execute in minecraft:overworld run fill 357 74 -17 357 144 -17 air
execute in minecraft:overworld run fill 357 58 -16 357 69 -16 stone
execute in minecraft:overworld run fill 357 70 -16 357 71 -16 dirt
execute in minecraft:overworld run setblock 357 72 -16 coarse_dirt
execute in minecraft:overworld run fill 357 73 -16 357 144 -16 air
execute in minecraft:overworld run fill 357 58 -15 357 68 -15 stone
execute in minecraft:overworld run fill 357 69 -15 357 70 -15 dirt
execute in minecraft:overworld run setblock 357 71 -15 coarse_dirt
execute in minecraft:overworld run fill 357 72 -15 357 144 -15 air
execute in minecraft:overworld run fill 357 58 -14 357 68 -14 stone
execute in minecraft:overworld run fill 357 69 -14 357 70 -14 dirt
execute in minecraft:overworld run setblock 357 71 -14 grass_block
execute in minecraft:overworld run fill 357 72 -14 357 144 -14 air
execute in minecraft:overworld run fill 357 58 -13 357 67 -13 stone
execute in minecraft:overworld run fill 357 68 -13 357 69 -13 dirt
execute in minecraft:overworld run setblock 357 70 -13 coarse_dirt
execute in minecraft:overworld run fill 357 71 -13 357 144 -13 air
execute in minecraft:overworld run fill 357 58 -12 357 66 -12 stone
execute in minecraft:overworld run fill 357 67 -12 357 68 -12 dirt
execute in minecraft:overworld run setblock 357 69 -12 coarse_dirt
execute in minecraft:overworld run fill 357 70 -12 357 144 -12 air
execute in minecraft:overworld run fill 357 58 -11 357 66 -11 stone
execute in minecraft:overworld run fill 357 67 -11 357 68 -11 dirt
execute in minecraft:overworld run setblock 357 69 -11 grass_block
execute in minecraft:overworld run fill 357 70 -11 357 144 -11 air
execute in minecraft:overworld run fill 357 58 -10 357 66 -10 stone
execute in minecraft:overworld run fill 357 67 -10 357 68 -10 dirt
execute in minecraft:overworld run setblock 357 69 -10 coarse_dirt
execute in minecraft:overworld run fill 357 70 -10 357 144 -10 air
execute in minecraft:overworld run fill 357 58 -9 357 66 -9 stone
execute in minecraft:overworld run fill 357 67 -9 357 68 -9 dirt
execute in minecraft:overworld run setblock 357 69 -9 coarse_dirt
execute in minecraft:overworld run fill 357 70 -9 357 144 -9 air
execute in minecraft:overworld run fill 357 58 -8 357 66 -8 stone
execute in minecraft:overworld run fill 357 67 -8 357 68 -8 dirt
execute in minecraft:overworld run setblock 357 69 -8 coarse_dirt
execute in minecraft:overworld run fill 357 70 -8 357 144 -8 air
execute in minecraft:overworld run fill 357 58 -7 357 65 -7 stone
execute in minecraft:overworld run fill 357 66 -7 357 67 -7 dirt
execute in minecraft:overworld run setblock 357 68 -7 grass_block
execute in minecraft:overworld run fill 357 69 -7 357 144 -7 air
execute in minecraft:overworld run fill 357 58 -6 357 65 -6 stone
execute in minecraft:overworld run fill 357 66 -6 357 67 -6 dirt
execute in minecraft:overworld run setblock 357 68 -6 coarse_dirt
execute in minecraft:overworld run fill 357 69 -6 357 144 -6 air
execute in minecraft:overworld run fill 357 58 -5 357 65 -5 stone
execute in minecraft:overworld run fill 357 66 -5 357 67 -5 dirt
execute in minecraft:overworld run setblock 357 68 -5 coarse_dirt
execute in minecraft:overworld run fill 357 69 -5 357 144 -5 air
execute in minecraft:overworld run fill 357 58 -4 357 65 -4 stone
execute in minecraft:overworld run fill 357 66 -4 357 67 -4 dirt
execute in minecraft:overworld run setblock 357 68 -4 coarse_dirt
execute in minecraft:overworld run fill 357 69 -4 357 144 -4 air
execute in minecraft:overworld run fill 357 58 -3 357 65 -3 stone
execute in minecraft:overworld run fill 357 66 -3 357 67 -3 dirt
execute in minecraft:overworld run setblock 357 68 -3 coarse_dirt
execute in minecraft:overworld run fill 357 69 -3 357 144 -3 air
execute in minecraft:overworld run setblock 357 69 -3 grass
execute in minecraft:overworld run fill 357 58 -2 357 65 -2 stone
execute in minecraft:overworld run fill 357 66 -2 357 67 -2 dirt
execute in minecraft:overworld run setblock 357 68 -2 grass_block
execute in minecraft:overworld run fill 357 69 -2 357 144 -2 air
execute in minecraft:overworld run fill 357 58 -1 357 65 -1 stone
execute in minecraft:overworld run fill 357 66 -1 357 67 -1 dirt
execute in minecraft:overworld run setblock 357 68 -1 coarse_dirt
execute in minecraft:overworld run fill 357 69 -1 357 144 -1 air
execute in minecraft:overworld run fill 357 58 0 357 65 0 stone
execute in minecraft:overworld run fill 357 66 0 357 67 0 dirt
execute in minecraft:overworld run setblock 357 68 0 coarse_dirt
execute in minecraft:overworld run fill 357 69 0 357 144 0 air
execute in minecraft:overworld run fill 357 58 1 357 66 1 stone
execute in minecraft:overworld run fill 357 67 1 357 68 1 dirt
execute in minecraft:overworld run setblock 357 69 1 grass_block
execute in minecraft:overworld run fill 357 70 1 357 144 1 air
execute in minecraft:overworld run fill 357 58 2 357 66 2 stone
execute in minecraft:overworld run fill 357 67 2 357 68 2 dirt
execute in minecraft:overworld run setblock 357 69 2 grass_block
execute in minecraft:overworld run fill 357 70 2 357 144 2 air
execute in minecraft:overworld run fill 357 58 3 357 66 3 stone
execute in minecraft:overworld run fill 357 67 3 357 68 3 dirt
execute in minecraft:overworld run setblock 357 69 3 coarse_dirt
execute in minecraft:overworld run fill 357 70 3 357 144 3 air
execute in minecraft:overworld run fill 357 58 4 357 66 4 stone
execute in minecraft:overworld run fill 357 67 4 357 68 4 dirt
execute in minecraft:overworld run setblock 357 69 4 coarse_dirt
execute in minecraft:overworld run fill 357 70 4 357 144 4 air
execute in minecraft:overworld run setblock 357 70 4 grass
execute in minecraft:overworld run fill 357 58 5 357 67 5 stone
execute in minecraft:overworld run fill 357 68 5 357 69 5 dirt
execute in minecraft:overworld run setblock 357 70 5 grass_block
execute in minecraft:overworld run fill 357 71 5 357 144 5 air
execute in minecraft:overworld run fill 357 58 6 357 67 6 stone
execute in minecraft:overworld run fill 357 68 6 357 69 6 dirt
execute in minecraft:overworld run setblock 357 70 6 coarse_dirt
execute in minecraft:overworld run fill 357 71 6 357 144 6 air
execute in minecraft:overworld run fill 357 58 7 357 67 7 stone
execute in minecraft:overworld run fill 357 68 7 357 69 7 dirt
execute in minecraft:overworld run setblock 357 70 7 coarse_dirt
execute in minecraft:overworld run fill 357 71 7 357 144 7 air
execute in minecraft:overworld run fill 357 58 8 357 68 8 stone
execute in minecraft:overworld run fill 357 69 8 357 70 8 dirt
execute in minecraft:overworld run setblock 357 71 8 coarse_dirt
execute in minecraft:overworld run fill 357 72 8 357 144 8 air
execute in minecraft:overworld run fill 357 58 9 357 68 9 stone
execute in minecraft:overworld run fill 357 69 9 357 70 9 dirt
execute in minecraft:overworld run setblock 357 71 9 grass_block
execute in minecraft:overworld run fill 357 72 9 357 144 9 air
execute in minecraft:overworld run fill 357 58 10 357 68 10 stone
execute in minecraft:overworld run fill 357 69 10 357 70 10 dirt
execute in minecraft:overworld run setblock 357 71 10 coarse_dirt
execute in minecraft:overworld run fill 357 72 10 357 144 10 air
execute in minecraft:overworld run fill 357 58 11 357 68 11 stone
execute in minecraft:overworld run fill 357 69 11 357 70 11 dirt
execute in minecraft:overworld run setblock 357 71 11 grass_block
execute in minecraft:overworld run fill 357 72 11 357 144 11 air
schedule function blade_gallery:random/battlefield/part_33 1t replace
