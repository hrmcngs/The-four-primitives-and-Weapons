execute in minecraft:overworld run fill 347 78 -28 347 144 -28 air
execute in minecraft:overworld run setblock 347 78 -28 grass
execute in minecraft:overworld run fill 347 58 -27 347 73 -27 stone
execute in minecraft:overworld run fill 347 74 -27 347 75 -27 dirt
execute in minecraft:overworld run setblock 347 76 -27 coarse_dirt
execute in minecraft:overworld run fill 347 77 -27 347 144 -27 air
execute in minecraft:overworld run fill 347 58 -26 347 73 -26 stone
execute in minecraft:overworld run fill 347 74 -26 347 75 -26 dirt
execute in minecraft:overworld run setblock 347 76 -26 coarse_dirt
execute in minecraft:overworld run fill 347 77 -26 347 144 -26 air
execute in minecraft:overworld run fill 347 58 -25 347 73 -25 stone
execute in minecraft:overworld run fill 347 74 -25 347 75 -25 dirt
execute in minecraft:overworld run setblock 347 76 -25 coarse_dirt
execute in minecraft:overworld run fill 347 77 -25 347 144 -25 air
execute in minecraft:overworld run fill 347 58 -24 347 72 -24 stone
execute in minecraft:overworld run fill 347 73 -24 347 74 -24 dirt
execute in minecraft:overworld run setblock 347 75 -24 grass_block
execute in minecraft:overworld run fill 347 76 -24 347 144 -24 air
execute in minecraft:overworld run setblock 347 76 -24 grass
execute in minecraft:overworld run fill 347 58 -23 347 72 -23 stone
execute in minecraft:overworld run fill 347 73 -23 347 74 -23 dirt
execute in minecraft:overworld run setblock 347 75 -23 coarse_dirt
execute in minecraft:overworld run fill 347 76 -23 347 144 -23 air
execute in minecraft:overworld run fill 347 58 -22 347 72 -22 stone
execute in minecraft:overworld run fill 347 73 -22 347 74 -22 dirt
execute in minecraft:overworld run setblock 347 75 -22 coarse_dirt
execute in minecraft:overworld run fill 347 76 -22 347 144 -22 air
execute in minecraft:overworld run fill 347 58 -21 347 71 -21 stone
execute in minecraft:overworld run fill 347 72 -21 347 73 -21 dirt
execute in minecraft:overworld run setblock 347 74 -21 coarse_dirt
execute in minecraft:overworld run fill 347 75 -21 347 144 -21 air
execute in minecraft:overworld run setblock 347 75 -21 grass
execute in minecraft:overworld run fill 347 58 -20 347 71 -20 stone
execute in minecraft:overworld run fill 347 72 -20 347 73 -20 dirt
execute in minecraft:overworld run setblock 347 74 -20 coarse_dirt
execute in minecraft:overworld run fill 347 75 -20 347 144 -20 air
execute in minecraft:overworld run fill 347 58 -19 347 71 -19 stone
execute in minecraft:overworld run fill 347 72 -19 347 73 -19 dirt
execute in minecraft:overworld run setblock 347 74 -19 coarse_dirt
execute in minecraft:overworld run fill 347 75 -19 347 144 -19 air
execute in minecraft:overworld run fill 347 58 -18 347 70 -18 stone
execute in minecraft:overworld run fill 347 71 -18 347 72 -18 dirt
execute in minecraft:overworld run setblock 347 73 -18 coarse_dirt
execute in minecraft:overworld run fill 347 74 -18 347 144 -18 air
execute in minecraft:overworld run setblock 347 74 -18 grass
execute in minecraft:overworld run fill 347 58 -17 347 70 -17 stone
execute in minecraft:overworld run fill 347 71 -17 347 72 -17 dirt
execute in minecraft:overworld run setblock 347 73 -17 grass_block
execute in minecraft:overworld run fill 347 74 -17 347 144 -17 air
execute in minecraft:overworld run fill 347 58 -16 347 69 -16 stone
execute in minecraft:overworld run fill 347 70 -16 347 71 -16 dirt
execute in minecraft:overworld run setblock 347 72 -16 coarse_dirt
execute in minecraft:overworld run fill 347 73 -16 347 144 -16 air
execute in minecraft:overworld run fill 347 58 -15 347 69 -15 stone
execute in minecraft:overworld run fill 347 70 -15 347 71 -15 dirt
execute in minecraft:overworld run setblock 347 72 -15 grass_block
execute in minecraft:overworld run fill 347 73 -15 347 144 -15 air
execute in minecraft:overworld run fill 347 58 -14 347 68 -14 stone
execute in minecraft:overworld run fill 347 69 -14 347 70 -14 dirt
execute in minecraft:overworld run setblock 347 71 -14 grass_block
execute in minecraft:overworld run fill 347 72 -14 347 144 -14 air
execute in minecraft:overworld run fill 347 58 -13 347 68 -13 stone
execute in minecraft:overworld run fill 347 69 -13 347 70 -13 dirt
execute in minecraft:overworld run setblock 347 71 -13 coarse_dirt
execute in minecraft:overworld run fill 347 72 -13 347 144 -13 air
execute in minecraft:overworld run setblock 347 72 -13 grass
execute in minecraft:overworld run fill 347 58 -12 347 67 -12 stone
execute in minecraft:overworld run fill 347 68 -12 347 69 -12 dirt
execute in minecraft:overworld run setblock 347 70 -12 coarse_dirt
execute in minecraft:overworld run fill 347 71 -12 347 144 -12 air
execute in minecraft:overworld run fill 347 58 -11 347 67 -11 stone
execute in minecraft:overworld run fill 347 68 -11 347 69 -11 dirt
execute in minecraft:overworld run setblock 347 70 -11 coarse_dirt
execute in minecraft:overworld run fill 347 71 -11 347 144 -11 air
execute in minecraft:overworld run fill 347 58 -10 347 67 -10 stone
execute in minecraft:overworld run fill 347 68 -10 347 69 -10 dirt
execute in minecraft:overworld run setblock 347 70 -10 grass_block
execute in minecraft:overworld run fill 347 71 -10 347 144 -10 air
execute in minecraft:overworld run fill 347 58 -9 347 67 -9 stone
execute in minecraft:overworld run fill 347 68 -9 347 69 -9 dirt
execute in minecraft:overworld run setblock 347 70 -9 coarse_dirt
execute in minecraft:overworld run fill 347 71 -9 347 144 -9 air
execute in minecraft:overworld run fill 347 58 -8 347 67 -8 stone
execute in minecraft:overworld run fill 347 68 -8 347 69 -8 dirt
execute in minecraft:overworld run setblock 347 70 -8 grass_block
execute in minecraft:overworld run fill 347 71 -8 347 144 -8 air
execute in minecraft:overworld run fill 347 58 -7 347 67 -7 stone
execute in minecraft:overworld run fill 347 68 -7 347 69 -7 dirt
execute in minecraft:overworld run setblock 347 70 -7 coarse_dirt
execute in minecraft:overworld run fill 347 71 -7 347 144 -7 air
execute in minecraft:overworld run fill 347 58 -6 347 67 -6 stone
execute in minecraft:overworld run fill 347 68 -6 347 69 -6 dirt
execute in minecraft:overworld run setblock 347 70 -6 coarse_dirt
execute in minecraft:overworld run fill 347 71 -6 347 144 -6 air
execute in minecraft:overworld run fill 347 58 -5 347 67 -5 stone
execute in minecraft:overworld run fill 347 68 -5 347 69 -5 dirt
execute in minecraft:overworld run setblock 347 70 -5 grass_block
execute in minecraft:overworld run fill 347 71 -5 347 144 -5 air
execute in minecraft:overworld run fill 347 58 -4 347 67 -4 stone
execute in minecraft:overworld run fill 347 68 -4 347 69 -4 dirt
execute in minecraft:overworld run setblock 347 70 -4 coarse_dirt
execute in minecraft:overworld run fill 347 71 -4 347 144 -4 air
execute in minecraft:overworld run fill 347 58 -3 347 67 -3 stone
execute in minecraft:overworld run fill 347 68 -3 347 69 -3 dirt
execute in minecraft:overworld run setblock 347 70 -3 coarse_dirt
execute in minecraft:overworld run fill 347 71 -3 347 144 -3 air
execute in minecraft:overworld run fill 347 58 -2 347 67 -2 stone
execute in minecraft:overworld run fill 347 68 -2 347 69 -2 dirt
execute in minecraft:overworld run setblock 347 70 -2 coarse_dirt
execute in minecraft:overworld run fill 347 71 -2 347 144 -2 air
execute in minecraft:overworld run fill 347 58 -1 347 67 -1 stone
execute in minecraft:overworld run fill 347 68 -1 347 69 -1 dirt
execute in minecraft:overworld run setblock 347 70 -1 grass_block
execute in minecraft:overworld run fill 347 71 -1 347 144 -1 air
execute in minecraft:overworld run fill 347 58 0 347 67 0 stone
execute in minecraft:overworld run fill 347 68 0 347 69 0 dirt
execute in minecraft:overworld run setblock 347 70 0 coarse_dirt
execute in minecraft:overworld run fill 347 71 0 347 144 0 air
execute in minecraft:overworld run fill 347 58 1 347 67 1 stone
execute in minecraft:overworld run fill 347 68 1 347 69 1 dirt
execute in minecraft:overworld run setblock 347 70 1 coarse_dirt
execute in minecraft:overworld run fill 347 71 1 347 144 1 air
execute in minecraft:overworld run setblock 347 71 1 grass
execute in minecraft:overworld run fill 347 58 2 347 67 2 stone
execute in minecraft:overworld run fill 347 68 2 347 69 2 dirt
execute in minecraft:overworld run setblock 347 70 2 coarse_dirt
execute in minecraft:overworld run fill 347 71 2 347 144 2 air
execute in minecraft:overworld run fill 347 58 3 347 67 3 stone
execute in minecraft:overworld run fill 347 68 3 347 69 3 dirt
execute in minecraft:overworld run setblock 347 70 3 grass_block
execute in minecraft:overworld run fill 347 71 3 347 144 3 air
execute in minecraft:overworld run fill 347 58 4 347 67 4 stone
execute in minecraft:overworld run fill 347 68 4 347 69 4 dirt
execute in minecraft:overworld run setblock 347 70 4 grass_block
execute in minecraft:overworld run fill 347 71 4 347 144 4 air
execute in minecraft:overworld run fill 347 58 5 347 67 5 stone
execute in minecraft:overworld run fill 347 68 5 347 69 5 dirt
execute in minecraft:overworld run setblock 347 70 5 grass_block
execute in minecraft:overworld run fill 347 71 5 347 144 5 air
execute in minecraft:overworld run setblock 347 71 5 mossy_cobblestone
execute in minecraft:overworld run fill 347 58 6 347 67 6 stone
execute in minecraft:overworld run fill 347 68 6 347 69 6 dirt
execute in minecraft:overworld run setblock 347 70 6 grass_block
execute in minecraft:overworld run fill 347 71 6 347 144 6 air
execute in minecraft:overworld run setblock 347 71 6 grass
execute in minecraft:overworld run fill 347 58 7 347 67 7 stone
execute in minecraft:overworld run fill 347 68 7 347 69 7 dirt
execute in minecraft:overworld run setblock 347 70 7 coarse_dirt
execute in minecraft:overworld run fill 347 71 7 347 144 7 air
execute in minecraft:overworld run fill 347 58 8 347 67 8 stone
execute in minecraft:overworld run fill 347 68 8 347 69 8 dirt
execute in minecraft:overworld run setblock 347 70 8 grass_block
execute in minecraft:overworld run fill 347 71 8 347 144 8 air
execute in minecraft:overworld run setblock 347 71 8 grass
execute in minecraft:overworld run fill 347 58 9 347 67 9 stone
execute in minecraft:overworld run fill 347 68 9 347 69 9 dirt
execute in minecraft:overworld run setblock 347 70 9 coarse_dirt
execute in minecraft:overworld run fill 347 71 9 347 144 9 air
execute in minecraft:overworld run fill 347 58 10 347 67 10 stone
execute in minecraft:overworld run fill 347 68 10 347 69 10 dirt
execute in minecraft:overworld run setblock 347 70 10 coarse_dirt
execute in minecraft:overworld run fill 347 71 10 347 144 10 air
execute in minecraft:overworld run fill 347 58 11 347 67 11 stone
execute in minecraft:overworld run fill 347 68 11 347 69 11 dirt
execute in minecraft:overworld run setblock 347 70 11 grass_block
execute in minecraft:overworld run fill 347 71 11 347 144 11 air
execute in minecraft:overworld run fill 347 58 12 347 66 12 stone
execute in minecraft:overworld run fill 347 67 12 347 68 12 dirt
execute in minecraft:overworld run setblock 347 69 12 coarse_dirt
execute in minecraft:overworld run fill 347 70 12 347 144 12 air
execute in minecraft:overworld run fill 347 58 13 347 66 13 stone
execute in minecraft:overworld run fill 347 67 13 347 68 13 dirt
execute in minecraft:overworld run setblock 347 69 13 grass_block
execute in minecraft:overworld run fill 347 70 13 347 144 13 air
execute in minecraft:overworld run setblock 347 70 13 mossy_cobblestone
execute in minecraft:overworld run fill 347 58 14 347 66 14 stone
execute in minecraft:overworld run fill 347 67 14 347 68 14 dirt
execute in minecraft:overworld run setblock 347 69 14 grass_block
execute in minecraft:overworld run fill 347 70 14 347 144 14 air
execute in minecraft:overworld run setblock 347 70 14 grass
execute in minecraft:overworld run fill 347 58 15 347 65 15 stone
execute in minecraft:overworld run fill 347 66 15 347 67 15 dirt
execute in minecraft:overworld run setblock 347 68 15 grass_block
execute in minecraft:overworld run fill 347 69 15 347 144 15 air
execute in minecraft:overworld run fill 347 58 16 347 65 16 stone
execute in minecraft:overworld run fill 347 66 16 347 67 16 dirt
execute in minecraft:overworld run setblock 347 68 16 grass_block
execute in minecraft:overworld run fill 347 69 16 347 144 16 air
execute in minecraft:overworld run fill 347 58 17 347 65 17 stone
execute in minecraft:overworld run fill 347 66 17 347 67 17 dirt
execute in minecraft:overworld run setblock 347 68 17 coarse_dirt
execute in minecraft:overworld run fill 347 69 17 347 144 17 air
execute in minecraft:overworld run fill 347 58 18 347 65 18 stone
execute in minecraft:overworld run fill 347 66 18 347 67 18 dirt
execute in minecraft:overworld run setblock 347 68 18 grass_block
execute in minecraft:overworld run fill 347 69 18 347 144 18 air
execute in minecraft:overworld run fill 347 58 19 347 65 19 stone
execute in minecraft:overworld run fill 347 66 19 347 67 19 dirt
execute in minecraft:overworld run setblock 347 68 19 coarse_dirt
execute in minecraft:overworld run fill 347 69 19 347 144 19 air
execute in minecraft:overworld run fill 347 58 20 347 65 20 stone
execute in minecraft:overworld run fill 347 66 20 347 67 20 dirt
execute in minecraft:overworld run setblock 347 68 20 coarse_dirt
execute in minecraft:overworld run fill 347 69 20 347 144 20 air
execute in minecraft:overworld run fill 347 58 21 347 65 21 stone
execute in minecraft:overworld run fill 347 66 21 347 67 21 dirt
execute in minecraft:overworld run setblock 347 68 21 grass_block
execute in minecraft:overworld run fill 347 69 21 347 144 21 air
execute in minecraft:overworld run fill 347 58 22 347 65 22 stone
execute in minecraft:overworld run fill 347 66 22 347 67 22 dirt
execute in minecraft:overworld run setblock 347 68 22 coarse_dirt
execute in minecraft:overworld run fill 347 69 22 347 144 22 air
execute in minecraft:overworld run fill 347 58 23 347 66 23 stone
execute in minecraft:overworld run fill 347 67 23 347 68 23 dirt
execute in minecraft:overworld run setblock 347 69 23 coarse_dirt
execute in minecraft:overworld run fill 347 70 23 347 144 23 air
execute in minecraft:overworld run fill 347 58 24 347 66 24 stone
execute in minecraft:overworld run fill 347 67 24 347 68 24 dirt
execute in minecraft:overworld run setblock 347 69 24 coarse_dirt
execute in minecraft:overworld run fill 347 70 24 347 144 24 air
execute in minecraft:overworld run fill 347 58 25 347 66 25 stone
execute in minecraft:overworld run fill 347 67 25 347 68 25 dirt
execute in minecraft:overworld run setblock 347 69 25 coarse_dirt
execute in minecraft:overworld run fill 347 70 25 347 144 25 air
execute in minecraft:overworld run fill 347 58 26 347 66 26 stone
execute in minecraft:overworld run fill 347 67 26 347 68 26 dirt
execute in minecraft:overworld run setblock 347 69 26 grass_block
execute in minecraft:overworld run fill 347 70 26 347 144 26 air
execute in minecraft:overworld run fill 347 58 27 347 66 27 stone
execute in minecraft:overworld run fill 347 67 27 347 68 27 dirt
execute in minecraft:overworld run setblock 347 69 27 grass_block
execute in minecraft:overworld run fill 347 70 27 347 144 27 air
execute in minecraft:overworld run fill 347 58 28 347 66 28 stone
execute in minecraft:overworld run fill 347 67 28 347 68 28 dirt
execute in minecraft:overworld run setblock 347 69 28 coarse_dirt
execute in minecraft:overworld run fill 347 70 28 347 144 28 air
execute in minecraft:overworld run fill 347 58 29 347 66 29 stone
execute in minecraft:overworld run fill 347 67 29 347 68 29 dirt
execute in minecraft:overworld run setblock 347 69 29 coarse_dirt
execute in minecraft:overworld run fill 347 70 29 347 144 29 air
execute in minecraft:overworld run fill 347 58 30 347 66 30 stone
execute in minecraft:overworld run fill 347 67 30 347 68 30 dirt
execute in minecraft:overworld run setblock 347 69 30 coarse_dirt
execute in minecraft:overworld run fill 347 70 30 347 144 30 air
execute in minecraft:overworld run fill 347 58 31 347 66 31 stone
execute in minecraft:overworld run fill 347 67 31 347 68 31 dirt
execute in minecraft:overworld run setblock 347 69 31 grass_block
execute in minecraft:overworld run fill 347 70 31 347 144 31 air
execute in minecraft:overworld run fill 347 58 32 347 66 32 stone
execute in minecraft:overworld run fill 347 67 32 347 68 32 dirt
execute in minecraft:overworld run setblock 347 69 32 coarse_dirt
execute in minecraft:overworld run fill 347 70 32 347 144 32 air
execute in minecraft:overworld run fill 347 58 33 347 66 33 stone
execute in minecraft:overworld run fill 347 67 33 347 68 33 dirt
execute in minecraft:overworld run setblock 347 69 33 coarse_dirt
execute in minecraft:overworld run fill 347 70 33 347 144 33 air
schedule function blade_gallery:random/battlefield/part_18 1t replace
