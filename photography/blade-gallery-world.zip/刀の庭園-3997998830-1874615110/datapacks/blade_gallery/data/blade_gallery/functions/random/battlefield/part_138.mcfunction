execute in minecraft:overworld run fill 423 66 44 423 144 44 air
execute in minecraft:overworld run fill 423 58 45 423 62 45 stone
execute in minecraft:overworld run fill 423 63 45 423 64 45 dirt
execute in minecraft:overworld run setblock 423 65 45 coarse_dirt
execute in minecraft:overworld run fill 423 66 45 423 144 45 air
execute in minecraft:overworld run fill 423 58 46 423 61 46 stone
execute in minecraft:overworld run fill 423 62 46 423 63 46 dirt
execute in minecraft:overworld run setblock 423 64 46 grass_block
execute in minecraft:overworld run fill 423 65 46 423 144 46 air
execute in minecraft:overworld run fill 423 58 47 423 61 47 stone
execute in minecraft:overworld run fill 423 62 47 423 63 47 dirt
execute in minecraft:overworld run setblock 423 64 47 coarse_dirt
execute in minecraft:overworld run fill 423 65 47 423 144 47 air
execute in minecraft:overworld run fill 424 58 -48 424 61 -48 stone
execute in minecraft:overworld run fill 424 62 -48 424 63 -48 dirt
execute in minecraft:overworld run setblock 424 64 -48 coarse_dirt
execute in minecraft:overworld run fill 424 65 -48 424 144 -48 air
execute in minecraft:overworld run fill 424 58 -47 424 63 -47 stone
execute in minecraft:overworld run fill 424 64 -47 424 65 -47 dirt
execute in minecraft:overworld run setblock 424 66 -47 coarse_dirt
execute in minecraft:overworld run fill 424 67 -47 424 144 -47 air
execute in minecraft:overworld run fill 424 58 -46 424 64 -46 stone
execute in minecraft:overworld run fill 424 65 -46 424 66 -46 dirt
execute in minecraft:overworld run setblock 424 67 -46 coarse_dirt
execute in minecraft:overworld run fill 424 68 -46 424 144 -46 air
execute in minecraft:overworld run fill 424 58 -45 424 66 -45 stone
execute in minecraft:overworld run fill 424 67 -45 424 68 -45 dirt
execute in minecraft:overworld run setblock 424 69 -45 coarse_dirt
execute in minecraft:overworld run fill 424 70 -45 424 144 -45 air
execute in minecraft:overworld run fill 424 58 -44 424 67 -44 stone
execute in minecraft:overworld run fill 424 68 -44 424 69 -44 dirt
execute in minecraft:overworld run setblock 424 70 -44 grass_block
execute in minecraft:overworld run fill 424 71 -44 424 144 -44 air
execute in minecraft:overworld run fill 424 58 -43 424 69 -43 stone
execute in minecraft:overworld run fill 424 70 -43 424 71 -43 dirt
execute in minecraft:overworld run setblock 424 72 -43 coarse_dirt
execute in minecraft:overworld run fill 424 73 -43 424 144 -43 air
execute in minecraft:overworld run fill 424 58 -42 424 70 -42 stone
execute in minecraft:overworld run fill 424 71 -42 424 72 -42 dirt
execute in minecraft:overworld run setblock 424 73 -42 grass_block
execute in minecraft:overworld run fill 424 74 -42 424 144 -42 air
execute in minecraft:overworld run fill 424 58 -41 424 72 -41 stone
execute in minecraft:overworld run fill 424 73 -41 424 74 -41 dirt
execute in minecraft:overworld run setblock 424 75 -41 coarse_dirt
execute in minecraft:overworld run fill 424 76 -41 424 144 -41 air
execute in minecraft:overworld run fill 424 58 -40 424 73 -40 stone
execute in minecraft:overworld run fill 424 74 -40 424 75 -40 dirt
execute in minecraft:overworld run setblock 424 76 -40 coarse_dirt
execute in minecraft:overworld run fill 424 77 -40 424 144 -40 air
execute in minecraft:overworld run fill 424 58 -39 424 73 -39 stone
execute in minecraft:overworld run fill 424 74 -39 424 75 -39 dirt
execute in minecraft:overworld run setblock 424 76 -39 coarse_dirt
execute in minecraft:overworld run fill 424 77 -39 424 144 -39 air
execute in minecraft:overworld run fill 424 58 -38 424 73 -38 stone
execute in minecraft:overworld run fill 424 74 -38 424 75 -38 dirt
execute in minecraft:overworld run setblock 424 76 -38 coarse_dirt
execute in minecraft:overworld run fill 424 77 -38 424 144 -38 air
execute in minecraft:overworld run fill 424 58 -37 424 73 -37 stone
execute in minecraft:overworld run fill 424 74 -37 424 75 -37 dirt
execute in minecraft:overworld run setblock 424 76 -37 grass_block
execute in minecraft:overworld run fill 424 77 -37 424 144 -37 air
execute in minecraft:overworld run fill 424 58 -36 424 72 -36 stone
execute in minecraft:overworld run fill 424 73 -36 424 74 -36 dirt
execute in minecraft:overworld run setblock 424 75 -36 grass_block
execute in minecraft:overworld run fill 424 76 -36 424 144 -36 air
execute in minecraft:overworld run fill 424 58 -35 424 72 -35 stone
execute in minecraft:overworld run fill 424 73 -35 424 74 -35 dirt
execute in minecraft:overworld run setblock 424 75 -35 coarse_dirt
execute in minecraft:overworld run fill 424 76 -35 424 144 -35 air
execute in minecraft:overworld run fill 424 58 -34 424 72 -34 stone
execute in minecraft:overworld run fill 424 73 -34 424 74 -34 dirt
execute in minecraft:overworld run setblock 424 75 -34 grass_block
execute in minecraft:overworld run fill 424 76 -34 424 144 -34 air
execute in minecraft:overworld run fill 424 58 -33 424 71 -33 stone
execute in minecraft:overworld run fill 424 72 -33 424 73 -33 dirt
execute in minecraft:overworld run setblock 424 74 -33 coarse_dirt
execute in minecraft:overworld run fill 424 75 -33 424 144 -33 air
execute in minecraft:overworld run fill 424 58 -32 424 71 -32 stone
execute in minecraft:overworld run fill 424 72 -32 424 73 -32 dirt
execute in minecraft:overworld run setblock 424 74 -32 coarse_dirt
execute in minecraft:overworld run fill 424 75 -32 424 144 -32 air
execute in minecraft:overworld run setblock 424 75 -32 grass
execute in minecraft:overworld run fill 424 58 -31 424 70 -31 stone
execute in minecraft:overworld run fill 424 71 -31 424 72 -31 dirt
execute in minecraft:overworld run setblock 424 73 -31 coarse_dirt
execute in minecraft:overworld run fill 424 74 -31 424 144 -31 air
execute in minecraft:overworld run fill 424 58 -30 424 70 -30 stone
execute in minecraft:overworld run fill 424 71 -30 424 72 -30 dirt
execute in minecraft:overworld run setblock 424 73 -30 coarse_dirt
execute in minecraft:overworld run fill 424 74 -30 424 144 -30 air
execute in minecraft:overworld run fill 424 58 -29 424 70 -29 stone
execute in minecraft:overworld run fill 424 71 -29 424 72 -29 dirt
execute in minecraft:overworld run setblock 424 73 -29 coarse_dirt
execute in minecraft:overworld run fill 424 74 -29 424 144 -29 air
execute in minecraft:overworld run fill 424 58 -28 424 69 -28 stone
execute in minecraft:overworld run fill 424 70 -28 424 71 -28 dirt
execute in minecraft:overworld run setblock 424 72 -28 grass_block
execute in minecraft:overworld run fill 424 73 -28 424 144 -28 air
execute in minecraft:overworld run fill 424 58 -27 424 69 -27 stone
execute in minecraft:overworld run fill 424 70 -27 424 71 -27 dirt
execute in minecraft:overworld run setblock 424 72 -27 coarse_dirt
execute in minecraft:overworld run fill 424 73 -27 424 144 -27 air
execute in minecraft:overworld run fill 424 58 -26 424 69 -26 stone
execute in minecraft:overworld run fill 424 70 -26 424 71 -26 dirt
execute in minecraft:overworld run setblock 424 72 -26 grass_block
execute in minecraft:overworld run fill 424 73 -26 424 144 -26 air
execute in minecraft:overworld run fill 424 58 -25 424 69 -25 stone
execute in minecraft:overworld run fill 424 70 -25 424 71 -25 dirt
execute in minecraft:overworld run setblock 424 72 -25 coarse_dirt
execute in minecraft:overworld run fill 424 73 -25 424 144 -25 air
execute in minecraft:overworld run setblock 424 73 -25 grass
execute in minecraft:overworld run fill 424 58 -24 424 68 -24 stone
execute in minecraft:overworld run fill 424 69 -24 424 70 -24 dirt
execute in minecraft:overworld run setblock 424 71 -24 grass_block
execute in minecraft:overworld run fill 424 72 -24 424 144 -24 air
execute in minecraft:overworld run fill 424 58 -23 424 68 -23 stone
execute in minecraft:overworld run fill 424 69 -23 424 70 -23 dirt
execute in minecraft:overworld run setblock 424 71 -23 grass_block
execute in minecraft:overworld run fill 424 72 -23 424 144 -23 air
execute in minecraft:overworld run setblock 424 72 -23 grass
execute in minecraft:overworld run fill 424 58 -22 424 68 -22 stone
execute in minecraft:overworld run fill 424 69 -22 424 70 -22 dirt
execute in minecraft:overworld run setblock 424 71 -22 grass_block
execute in minecraft:overworld run fill 424 72 -22 424 144 -22 air
execute in minecraft:overworld run setblock 424 72 -22 grass
execute in minecraft:overworld run fill 424 58 -21 424 68 -21 stone
execute in minecraft:overworld run fill 424 69 -21 424 70 -21 dirt
execute in minecraft:overworld run setblock 424 71 -21 grass_block
execute in minecraft:overworld run fill 424 72 -21 424 144 -21 air
execute in minecraft:overworld run fill 424 58 -20 424 67 -20 stone
execute in minecraft:overworld run fill 424 68 -20 424 69 -20 dirt
execute in minecraft:overworld run setblock 424 70 -20 coarse_dirt
execute in minecraft:overworld run fill 424 71 -20 424 144 -20 air
execute in minecraft:overworld run fill 424 58 -19 424 67 -19 stone
execute in minecraft:overworld run fill 424 68 -19 424 69 -19 dirt
execute in minecraft:overworld run setblock 424 70 -19 coarse_dirt
execute in minecraft:overworld run fill 424 71 -19 424 144 -19 air
execute in minecraft:overworld run fill 424 58 -18 424 67 -18 stone
execute in minecraft:overworld run fill 424 68 -18 424 69 -18 dirt
execute in minecraft:overworld run setblock 424 70 -18 grass_block
execute in minecraft:overworld run fill 424 71 -18 424 144 -18 air
execute in minecraft:overworld run fill 424 58 -17 424 66 -17 stone
execute in minecraft:overworld run fill 424 67 -17 424 68 -17 dirt
execute in minecraft:overworld run setblock 424 69 -17 grass_block
execute in minecraft:overworld run fill 424 70 -17 424 144 -17 air
execute in minecraft:overworld run setblock 424 70 -17 grass
execute in minecraft:overworld run fill 424 58 -16 424 66 -16 stone
execute in minecraft:overworld run fill 424 67 -16 424 68 -16 dirt
execute in minecraft:overworld run setblock 424 69 -16 grass_block
execute in minecraft:overworld run fill 424 70 -16 424 144 -16 air
execute in minecraft:overworld run setblock 424 70 -16 grass
execute in minecraft:overworld run fill 424 58 -15 424 66 -15 stone
execute in minecraft:overworld run fill 424 67 -15 424 68 -15 dirt
execute in minecraft:overworld run setblock 424 69 -15 coarse_dirt
execute in minecraft:overworld run fill 424 70 -15 424 144 -15 air
execute in minecraft:overworld run setblock 424 70 -15 grass
execute in minecraft:overworld run fill 424 58 -14 424 66 -14 stone
execute in minecraft:overworld run fill 424 67 -14 424 68 -14 dirt
execute in minecraft:overworld run setblock 424 69 -14 coarse_dirt
execute in minecraft:overworld run fill 424 70 -14 424 144 -14 air
execute in minecraft:overworld run fill 424 58 -13 424 65 -13 stone
execute in minecraft:overworld run fill 424 66 -13 424 67 -13 dirt
execute in minecraft:overworld run setblock 424 68 -13 grass_block
execute in minecraft:overworld run fill 424 69 -13 424 144 -13 air
execute in minecraft:overworld run fill 424 58 -12 424 65 -12 stone
execute in minecraft:overworld run fill 424 66 -12 424 67 -12 dirt
execute in minecraft:overworld run setblock 424 68 -12 grass_block
execute in minecraft:overworld run fill 424 69 -12 424 144 -12 air
execute in minecraft:overworld run fill 424 58 -11 424 65 -11 stone
execute in minecraft:overworld run fill 424 66 -11 424 67 -11 dirt
execute in minecraft:overworld run setblock 424 68 -11 grass_block
execute in minecraft:overworld run fill 424 69 -11 424 144 -11 air
execute in minecraft:overworld run fill 424 58 -10 424 65 -10 stone
execute in minecraft:overworld run fill 424 66 -10 424 67 -10 dirt
execute in minecraft:overworld run setblock 424 68 -10 grass_block
execute in minecraft:overworld run fill 424 69 -10 424 144 -10 air
execute in minecraft:overworld run fill 424 58 -9 424 65 -9 stone
execute in minecraft:overworld run fill 424 66 -9 424 67 -9 dirt
execute in minecraft:overworld run setblock 424 68 -9 grass_block
execute in minecraft:overworld run fill 424 69 -9 424 144 -9 air
execute in minecraft:overworld run fill 424 58 -8 424 65 -8 stone
execute in minecraft:overworld run fill 424 66 -8 424 67 -8 dirt
execute in minecraft:overworld run setblock 424 68 -8 grass_block
execute in minecraft:overworld run fill 424 69 -8 424 144 -8 air
execute in minecraft:overworld run fill 424 58 -7 424 65 -7 stone
execute in minecraft:overworld run fill 424 66 -7 424 67 -7 dirt
execute in minecraft:overworld run setblock 424 68 -7 coarse_dirt
execute in minecraft:overworld run fill 424 69 -7 424 144 -7 air
execute in minecraft:overworld run setblock 424 69 -7 grass
execute in minecraft:overworld run fill 424 58 -6 424 64 -6 stone
execute in minecraft:overworld run fill 424 65 -6 424 66 -6 dirt
execute in minecraft:overworld run setblock 424 67 -6 grass_block
execute in minecraft:overworld run fill 424 68 -6 424 144 -6 air
execute in minecraft:overworld run fill 424 58 -5 424 64 -5 stone
execute in minecraft:overworld run fill 424 65 -5 424 66 -5 dirt
execute in minecraft:overworld run setblock 424 67 -5 coarse_dirt
execute in minecraft:overworld run fill 424 68 -5 424 144 -5 air
execute in minecraft:overworld run fill 424 58 -4 424 64 -4 stone
execute in minecraft:overworld run fill 424 65 -4 424 66 -4 dirt
execute in minecraft:overworld run setblock 424 67 -4 coarse_dirt
execute in minecraft:overworld run fill 424 68 -4 424 144 -4 air
execute in minecraft:overworld run fill 424 58 -3 424 64 -3 stone
execute in minecraft:overworld run fill 424 65 -3 424 66 -3 dirt
execute in minecraft:overworld run setblock 424 67 -3 coarse_dirt
execute in minecraft:overworld run fill 424 68 -3 424 144 -3 air
execute in minecraft:overworld run fill 424 58 -2 424 64 -2 stone
execute in minecraft:overworld run fill 424 65 -2 424 66 -2 dirt
execute in minecraft:overworld run setblock 424 67 -2 grass_block
execute in minecraft:overworld run fill 424 68 -2 424 144 -2 air
execute in minecraft:overworld run fill 424 58 -1 424 63 -1 stone
execute in minecraft:overworld run fill 424 64 -1 424 65 -1 dirt
execute in minecraft:overworld run setblock 424 66 -1 grass_block
execute in minecraft:overworld run fill 424 67 -1 424 144 -1 air
execute in minecraft:overworld run fill 424 58 0 424 63 0 stone
execute in minecraft:overworld run fill 424 64 0 424 65 0 dirt
execute in minecraft:overworld run setblock 424 66 0 grass_block
execute in minecraft:overworld run fill 424 67 0 424 144 0 air
execute in minecraft:overworld run fill 424 58 1 424 63 1 stone
execute in minecraft:overworld run fill 424 64 1 424 65 1 dirt
execute in minecraft:overworld run setblock 424 66 1 coarse_dirt
execute in minecraft:overworld run fill 424 67 1 424 144 1 air
execute in minecraft:overworld run fill 424 58 2 424 63 2 stone
execute in minecraft:overworld run fill 424 64 2 424 65 2 dirt
execute in minecraft:overworld run setblock 424 66 2 grass_block
execute in minecraft:overworld run fill 424 67 2 424 144 2 air
execute in minecraft:overworld run fill 424 58 3 424 64 3 stone
execute in minecraft:overworld run fill 424 65 3 424 66 3 dirt
execute in minecraft:overworld run setblock 424 67 3 coarse_dirt
execute in minecraft:overworld run fill 424 68 3 424 144 3 air
execute in minecraft:overworld run setblock 424 68 3 grass
execute in minecraft:overworld run fill 424 58 4 424 64 4 stone
execute in minecraft:overworld run fill 424 65 4 424 66 4 dirt
execute in minecraft:overworld run setblock 424 67 4 grass_block
execute in minecraft:overworld run fill 424 68 4 424 144 4 air
execute in minecraft:overworld run fill 424 58 5 424 64 5 stone
execute in minecraft:overworld run fill 424 65 5 424 66 5 dirt
execute in minecraft:overworld run setblock 424 67 5 coarse_dirt
execute in minecraft:overworld run fill 424 68 5 424 144 5 air
execute in minecraft:overworld run fill 424 58 6 424 64 6 stone
execute in minecraft:overworld run fill 424 65 6 424 66 6 dirt
execute in minecraft:overworld run setblock 424 67 6 coarse_dirt
execute in minecraft:overworld run fill 424 68 6 424 144 6 air
execute in minecraft:overworld run setblock 424 68 6 grass
execute in minecraft:overworld run fill 424 58 7 424 64 7 stone
execute in minecraft:overworld run fill 424 65 7 424 66 7 dirt
execute in minecraft:overworld run setblock 424 67 7 coarse_dirt
execute in minecraft:overworld run fill 424 68 7 424 144 7 air
execute in minecraft:overworld run fill 424 58 8 424 65 8 stone
execute in minecraft:overworld run fill 424 66 8 424 67 8 dirt
execute in minecraft:overworld run setblock 424 68 8 coarse_dirt
execute in minecraft:overworld run fill 424 69 8 424 144 8 air
execute in minecraft:overworld run fill 424 58 9 424 65 9 stone
execute in minecraft:overworld run fill 424 66 9 424 67 9 dirt
execute in minecraft:overworld run setblock 424 68 9 grass_block
execute in minecraft:overworld run fill 424 69 9 424 144 9 air
execute in minecraft:overworld run fill 424 58 10 424 65 10 stone
schedule function blade_gallery:random/battlefield/part_139 1t replace
