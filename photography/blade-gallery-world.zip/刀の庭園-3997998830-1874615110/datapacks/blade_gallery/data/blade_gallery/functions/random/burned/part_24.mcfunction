execute in minecraft:overworld run fill 223 71 22 223 72 22 dirt
execute in minecraft:overworld run setblock 223 73 22 coarse_dirt
execute in minecraft:overworld run fill 223 74 22 223 144 22 air
execute in minecraft:overworld run fill 223 58 23 223 70 23 stone
execute in minecraft:overworld run fill 223 71 23 223 72 23 dirt
execute in minecraft:overworld run setblock 223 73 23 grass_block
execute in minecraft:overworld run fill 223 74 23 223 144 23 air
execute in minecraft:overworld run fill 223 58 24 223 70 24 stone
execute in minecraft:overworld run fill 223 71 24 223 72 24 dirt
execute in minecraft:overworld run setblock 223 73 24 coarse_dirt
execute in minecraft:overworld run fill 223 74 24 223 144 24 air
execute in minecraft:overworld run setblock 223 74 24 grass
execute in minecraft:overworld run fill 223 58 25 223 70 25 stone
execute in minecraft:overworld run fill 223 71 25 223 72 25 dirt
execute in minecraft:overworld run setblock 223 73 25 coarse_dirt
execute in minecraft:overworld run fill 223 74 25 223 144 25 air
execute in minecraft:overworld run fill 223 58 26 223 70 26 stone
execute in minecraft:overworld run fill 223 71 26 223 72 26 dirt
execute in minecraft:overworld run setblock 223 73 26 coarse_dirt
execute in minecraft:overworld run fill 223 74 26 223 144 26 air
execute in minecraft:overworld run setblock 223 74 26 mossy_cobblestone
execute in minecraft:overworld run fill 223 58 27 223 70 27 stone
execute in minecraft:overworld run fill 223 71 27 223 72 27 dirt
execute in minecraft:overworld run setblock 223 73 27 coarse_dirt
execute in minecraft:overworld run fill 223 74 27 223 144 27 air
execute in minecraft:overworld run fill 223 58 28 223 70 28 stone
execute in minecraft:overworld run fill 223 71 28 223 72 28 dirt
execute in minecraft:overworld run setblock 223 73 28 grass_block
execute in minecraft:overworld run fill 223 74 28 223 144 28 air
execute in minecraft:overworld run fill 223 58 29 223 70 29 stone
execute in minecraft:overworld run fill 223 71 29 223 72 29 dirt
execute in minecraft:overworld run setblock 223 73 29 coarse_dirt
execute in minecraft:overworld run fill 223 74 29 223 144 29 air
execute in minecraft:overworld run fill 223 58 30 223 70 30 stone
execute in minecraft:overworld run fill 223 71 30 223 72 30 dirt
execute in minecraft:overworld run setblock 223 73 30 coarse_dirt
execute in minecraft:overworld run fill 223 74 30 223 144 30 air
execute in minecraft:overworld run fill 223 58 31 223 70 31 stone
execute in minecraft:overworld run fill 223 71 31 223 72 31 dirt
execute in minecraft:overworld run setblock 223 73 31 coarse_dirt
execute in minecraft:overworld run fill 223 74 31 223 144 31 air
execute in minecraft:overworld run fill 223 58 32 223 70 32 stone
execute in minecraft:overworld run fill 223 71 32 223 72 32 dirt
execute in minecraft:overworld run setblock 223 73 32 coarse_dirt
execute in minecraft:overworld run fill 223 74 32 223 144 32 air
execute in minecraft:overworld run fill 223 58 33 223 70 33 stone
execute in minecraft:overworld run fill 223 71 33 223 72 33 dirt
execute in minecraft:overworld run setblock 223 73 33 grass_block
execute in minecraft:overworld run fill 223 74 33 223 144 33 air
execute in minecraft:overworld run setblock 223 74 33 grass
execute in minecraft:overworld run fill 223 58 34 223 70 34 stone
execute in minecraft:overworld run fill 223 71 34 223 72 34 dirt
execute in minecraft:overworld run setblock 223 73 34 coarse_dirt
execute in minecraft:overworld run fill 223 74 34 223 144 34 air
execute in minecraft:overworld run setblock 223 74 34 grass
execute in minecraft:overworld run fill 223 58 35 223 69 35 stone
execute in minecraft:overworld run fill 223 70 35 223 71 35 dirt
execute in minecraft:overworld run setblock 223 72 35 coarse_dirt
execute in minecraft:overworld run fill 223 73 35 223 144 35 air
execute in minecraft:overworld run fill 223 58 36 223 69 36 stone
execute in minecraft:overworld run fill 223 70 36 223 71 36 dirt
execute in minecraft:overworld run setblock 223 72 36 grass_block
execute in minecraft:overworld run fill 223 73 36 223 144 36 air
execute in minecraft:overworld run setblock 223 73 36 mossy_cobblestone
execute in minecraft:overworld run fill 223 58 37 223 68 37 stone
execute in minecraft:overworld run fill 223 69 37 223 70 37 dirt
execute in minecraft:overworld run setblock 223 71 37 coarse_dirt
execute in minecraft:overworld run fill 223 72 37 223 144 37 air
execute in minecraft:overworld run fill 223 58 38 223 68 38 stone
execute in minecraft:overworld run fill 223 69 38 223 70 38 dirt
execute in minecraft:overworld run setblock 223 71 38 coarse_dirt
execute in minecraft:overworld run fill 223 72 38 223 144 38 air
execute in minecraft:overworld run fill 223 58 39 223 67 39 stone
execute in minecraft:overworld run fill 223 68 39 223 69 39 dirt
execute in minecraft:overworld run setblock 223 70 39 grass_block
execute in minecraft:overworld run fill 223 71 39 223 144 39 air
execute in minecraft:overworld run fill 223 58 40 223 66 40 stone
execute in minecraft:overworld run fill 223 67 40 223 68 40 dirt
execute in minecraft:overworld run setblock 223 69 40 grass_block
execute in minecraft:overworld run fill 223 70 40 223 144 40 air
execute in minecraft:overworld run setblock 223 70 40 grass
execute in minecraft:overworld run fill 223 58 41 223 65 41 stone
execute in minecraft:overworld run fill 223 66 41 223 67 41 dirt
execute in minecraft:overworld run setblock 223 68 41 grass_block
execute in minecraft:overworld run fill 223 69 41 223 144 41 air
execute in minecraft:overworld run fill 223 58 42 223 64 42 stone
execute in minecraft:overworld run fill 223 65 42 223 66 42 dirt
execute in minecraft:overworld run setblock 223 67 42 grass_block
execute in minecraft:overworld run fill 223 68 42 223 144 42 air
execute in minecraft:overworld run fill 223 58 43 223 63 43 stone
execute in minecraft:overworld run fill 223 64 43 223 65 43 dirt
execute in minecraft:overworld run setblock 223 66 43 coarse_dirt
execute in minecraft:overworld run fill 223 67 43 223 144 43 air
execute in minecraft:overworld run fill 223 58 44 223 62 44 stone
execute in minecraft:overworld run fill 223 63 44 223 64 44 dirt
execute in minecraft:overworld run setblock 223 65 44 coarse_dirt
execute in minecraft:overworld run fill 223 66 44 223 144 44 air
execute in minecraft:overworld run fill 223 58 45 223 62 45 stone
execute in minecraft:overworld run fill 223 63 45 223 64 45 dirt
execute in minecraft:overworld run setblock 223 65 45 coarse_dirt
execute in minecraft:overworld run fill 223 66 45 223 144 45 air
execute in minecraft:overworld run fill 223 58 46 223 62 46 stone
execute in minecraft:overworld run fill 223 63 46 223 64 46 dirt
execute in minecraft:overworld run setblock 223 65 46 coarse_dirt
execute in minecraft:overworld run fill 223 66 46 223 144 46 air
execute in minecraft:overworld run fill 223 58 47 223 61 47 stone
execute in minecraft:overworld run fill 223 62 47 223 63 47 dirt
execute in minecraft:overworld run setblock 223 64 47 grass_block
execute in minecraft:overworld run fill 223 65 47 223 144 47 air
execute in minecraft:overworld run fill 224 58 -48 224 61 -48 stone
execute in minecraft:overworld run fill 224 62 -48 224 63 -48 dirt
execute in minecraft:overworld run setblock 224 64 -48 grass_block
execute in minecraft:overworld run fill 224 65 -48 224 144 -48 air
execute in minecraft:overworld run fill 224 58 -47 224 63 -47 stone
execute in minecraft:overworld run fill 224 64 -47 224 65 -47 dirt
execute in minecraft:overworld run setblock 224 66 -47 coarse_dirt
execute in minecraft:overworld run fill 224 67 -47 224 144 -47 air
execute in minecraft:overworld run fill 224 58 -46 224 64 -46 stone
execute in minecraft:overworld run fill 224 65 -46 224 66 -46 dirt
execute in minecraft:overworld run setblock 224 67 -46 grass_block
execute in minecraft:overworld run fill 224 68 -46 224 144 -46 air
execute in minecraft:overworld run fill 224 58 -45 224 66 -45 stone
execute in minecraft:overworld run fill 224 67 -45 224 68 -45 dirt
execute in minecraft:overworld run setblock 224 69 -45 coarse_dirt
execute in minecraft:overworld run fill 224 70 -45 224 144 -45 air
execute in minecraft:overworld run fill 224 58 -44 224 67 -44 stone
execute in minecraft:overworld run fill 224 68 -44 224 69 -44 dirt
execute in minecraft:overworld run setblock 224 70 -44 coarse_dirt
execute in minecraft:overworld run fill 224 71 -44 224 144 -44 air
execute in minecraft:overworld run fill 224 58 -43 224 68 -43 stone
execute in minecraft:overworld run fill 224 69 -43 224 70 -43 dirt
execute in minecraft:overworld run setblock 224 71 -43 coarse_dirt
execute in minecraft:overworld run fill 224 72 -43 224 144 -43 air
execute in minecraft:overworld run fill 224 58 -42 224 69 -42 stone
execute in minecraft:overworld run fill 224 70 -42 224 71 -42 dirt
execute in minecraft:overworld run setblock 224 72 -42 coarse_dirt
execute in minecraft:overworld run fill 224 73 -42 224 144 -42 air
execute in minecraft:overworld run fill 224 58 -41 224 70 -41 stone
execute in minecraft:overworld run fill 224 71 -41 224 72 -41 dirt
execute in minecraft:overworld run setblock 224 73 -41 grass_block
execute in minecraft:overworld run fill 224 74 -41 224 144 -41 air
execute in minecraft:overworld run fill 224 58 -40 224 70 -40 stone
execute in minecraft:overworld run fill 224 71 -40 224 72 -40 dirt
execute in minecraft:overworld run setblock 224 73 -40 coarse_dirt
execute in minecraft:overworld run fill 224 74 -40 224 144 -40 air
execute in minecraft:overworld run fill 224 58 -39 224 71 -39 stone
execute in minecraft:overworld run fill 224 72 -39 224 73 -39 dirt
execute in minecraft:overworld run setblock 224 74 -39 coarse_dirt
execute in minecraft:overworld run fill 224 75 -39 224 144 -39 air
execute in minecraft:overworld run fill 224 58 -38 224 71 -38 stone
execute in minecraft:overworld run fill 224 72 -38 224 73 -38 dirt
execute in minecraft:overworld run setblock 224 74 -38 grass_block
execute in minecraft:overworld run fill 224 75 -38 224 144 -38 air
execute in minecraft:overworld run fill 224 58 -37 224 70 -37 stone
execute in minecraft:overworld run fill 224 71 -37 224 72 -37 dirt
execute in minecraft:overworld run setblock 224 73 -37 coarse_dirt
execute in minecraft:overworld run fill 224 74 -37 224 144 -37 air
execute in minecraft:overworld run setblock 224 74 -37 grass
execute in minecraft:overworld run fill 224 58 -36 224 70 -36 stone
execute in minecraft:overworld run fill 224 71 -36 224 72 -36 dirt
execute in minecraft:overworld run setblock 224 73 -36 coarse_dirt
execute in minecraft:overworld run fill 224 74 -36 224 144 -36 air
execute in minecraft:overworld run fill 224 58 -35 224 69 -35 stone
execute in minecraft:overworld run fill 224 70 -35 224 71 -35 dirt
execute in minecraft:overworld run setblock 224 72 -35 grass_block
execute in minecraft:overworld run fill 224 73 -35 224 144 -35 air
execute in minecraft:overworld run fill 224 58 -34 224 68 -34 stone
execute in minecraft:overworld run fill 224 69 -34 224 70 -34 dirt
execute in minecraft:overworld run setblock 224 71 -34 coarse_dirt
execute in minecraft:overworld run fill 224 72 -34 224 144 -34 air
execute in minecraft:overworld run fill 224 58 -33 224 68 -33 stone
execute in minecraft:overworld run fill 224 69 -33 224 70 -33 dirt
execute in minecraft:overworld run setblock 224 71 -33 coarse_dirt
execute in minecraft:overworld run fill 224 72 -33 224 144 -33 air
execute in minecraft:overworld run setblock 224 72 -33 grass
execute in minecraft:overworld run fill 224 58 -32 224 68 -32 stone
execute in minecraft:overworld run fill 224 69 -32 224 70 -32 dirt
execute in minecraft:overworld run setblock 224 71 -32 coarse_dirt
execute in minecraft:overworld run fill 224 72 -32 224 144 -32 air
execute in minecraft:overworld run fill 224 58 -31 224 67 -31 stone
execute in minecraft:overworld run fill 224 68 -31 224 69 -31 dirt
execute in minecraft:overworld run setblock 224 70 -31 grass_block
execute in minecraft:overworld run fill 224 71 -31 224 144 -31 air
execute in minecraft:overworld run setblock 224 71 -31 grass
execute in minecraft:overworld run fill 224 58 -30 224 67 -30 stone
execute in minecraft:overworld run fill 224 68 -30 224 69 -30 dirt
execute in minecraft:overworld run setblock 224 70 -30 coarse_dirt
execute in minecraft:overworld run fill 224 71 -30 224 144 -30 air
execute in minecraft:overworld run fill 224 58 -29 224 67 -29 stone
execute in minecraft:overworld run fill 224 68 -29 224 69 -29 dirt
execute in minecraft:overworld run setblock 224 70 -29 coarse_dirt
execute in minecraft:overworld run fill 224 71 -29 224 144 -29 air
execute in minecraft:overworld run fill 224 58 -28 224 66 -28 stone
execute in minecraft:overworld run fill 224 67 -28 224 68 -28 dirt
execute in minecraft:overworld run setblock 224 69 -28 grass_block
execute in minecraft:overworld run fill 224 70 -28 224 144 -28 air
execute in minecraft:overworld run fill 224 58 -27 224 66 -27 stone
execute in minecraft:overworld run fill 224 67 -27 224 68 -27 dirt
execute in minecraft:overworld run setblock 224 69 -27 coarse_dirt
execute in minecraft:overworld run fill 224 70 -27 224 144 -27 air
execute in minecraft:overworld run fill 224 58 -26 224 66 -26 stone
execute in minecraft:overworld run fill 224 67 -26 224 68 -26 dirt
execute in minecraft:overworld run setblock 224 69 -26 grass_block
execute in minecraft:overworld run fill 224 70 -26 224 144 -26 air
execute in minecraft:overworld run fill 224 58 -25 224 66 -25 stone
execute in minecraft:overworld run fill 224 67 -25 224 68 -25 dirt
execute in minecraft:overworld run setblock 224 69 -25 coarse_dirt
execute in minecraft:overworld run fill 224 70 -25 224 144 -25 air
execute in minecraft:overworld run fill 224 58 -24 224 66 -24 stone
execute in minecraft:overworld run fill 224 67 -24 224 68 -24 dirt
execute in minecraft:overworld run setblock 224 69 -24 coarse_dirt
execute in minecraft:overworld run fill 224 70 -24 224 144 -24 air
execute in minecraft:overworld run fill 224 58 -23 224 66 -23 stone
execute in minecraft:overworld run fill 224 67 -23 224 68 -23 dirt
execute in minecraft:overworld run setblock 224 69 -23 coarse_dirt
execute in minecraft:overworld run fill 224 70 -23 224 144 -23 air
execute in minecraft:overworld run fill 224 58 -22 224 66 -22 stone
execute in minecraft:overworld run fill 224 67 -22 224 68 -22 dirt
execute in minecraft:overworld run setblock 224 69 -22 grass_block
execute in minecraft:overworld run fill 224 70 -22 224 144 -22 air
execute in minecraft:overworld run fill 224 58 -21 224 66 -21 stone
execute in minecraft:overworld run fill 224 67 -21 224 68 -21 dirt
execute in minecraft:overworld run setblock 224 69 -21 coarse_dirt
execute in minecraft:overworld run fill 224 70 -21 224 144 -21 air
execute in minecraft:overworld run setblock 224 70 -21 grass
execute in minecraft:overworld run fill 224 58 -20 224 66 -20 stone
execute in minecraft:overworld run fill 224 67 -20 224 68 -20 dirt
execute in minecraft:overworld run setblock 224 69 -20 grass_block
execute in minecraft:overworld run fill 224 70 -20 224 144 -20 air
execute in minecraft:overworld run fill 224 58 -19 224 66 -19 stone
execute in minecraft:overworld run fill 224 67 -19 224 68 -19 dirt
execute in minecraft:overworld run setblock 224 69 -19 grass_block
execute in minecraft:overworld run fill 224 70 -19 224 144 -19 air
execute in minecraft:overworld run fill 224 58 -18 224 66 -18 stone
execute in minecraft:overworld run fill 224 67 -18 224 68 -18 dirt
execute in minecraft:overworld run setblock 224 69 -18 coarse_dirt
execute in minecraft:overworld run fill 224 70 -18 224 144 -18 air
execute in minecraft:overworld run fill 224 58 -17 224 66 -17 stone
execute in minecraft:overworld run fill 224 67 -17 224 68 -17 dirt
execute in minecraft:overworld run setblock 224 69 -17 grass_block
execute in minecraft:overworld run fill 224 70 -17 224 144 -17 air
execute in minecraft:overworld run fill 224 58 -16 224 66 -16 stone
execute in minecraft:overworld run fill 224 67 -16 224 68 -16 dirt
execute in minecraft:overworld run setblock 224 69 -16 grass_block
execute in minecraft:overworld run fill 224 70 -16 224 144 -16 air
execute in minecraft:overworld run fill 224 58 -15 224 65 -15 stone
execute in minecraft:overworld run fill 224 66 -15 224 67 -15 dirt
execute in minecraft:overworld run setblock 224 68 -15 coarse_dirt
execute in minecraft:overworld run fill 224 69 -15 224 144 -15 air
execute in minecraft:overworld run fill 224 58 -14 224 65 -14 stone
execute in minecraft:overworld run fill 224 66 -14 224 67 -14 dirt
execute in minecraft:overworld run setblock 224 68 -14 coarse_dirt
execute in minecraft:overworld run fill 224 69 -14 224 144 -14 air
execute in minecraft:overworld run fill 224 58 -13 224 64 -13 stone
execute in minecraft:overworld run fill 224 65 -13 224 66 -13 dirt
execute in minecraft:overworld run setblock 224 67 -13 coarse_dirt
schedule function blade_gallery:random/burned/part_25 1t replace
