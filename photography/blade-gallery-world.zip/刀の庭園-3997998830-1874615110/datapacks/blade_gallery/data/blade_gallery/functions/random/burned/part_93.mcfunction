execute in minecraft:overworld run fill 266 60 40 266 61 40 dirt
execute in minecraft:overworld run setblock 266 62 40 gravel
execute in minecraft:overworld run fill 266 63 40 266 144 40 air
execute in minecraft:overworld run fill 266 63 40 266 64 40 water
execute in minecraft:overworld run fill 266 58 41 266 59 41 stone
execute in minecraft:overworld run fill 266 60 41 266 61 41 dirt
execute in minecraft:overworld run setblock 266 62 41 gravel
execute in minecraft:overworld run fill 266 63 41 266 144 41 air
execute in minecraft:overworld run fill 266 63 41 266 64 41 water
execute in minecraft:overworld run fill 266 58 42 266 60 42 stone
execute in minecraft:overworld run fill 266 61 42 266 62 42 dirt
execute in minecraft:overworld run setblock 266 63 42 gravel
execute in minecraft:overworld run fill 266 64 42 266 144 42 air
execute in minecraft:overworld run fill 266 64 42 266 64 42 water
execute in minecraft:overworld run fill 266 58 43 266 60 43 stone
execute in minecraft:overworld run fill 266 61 43 266 62 43 dirt
execute in minecraft:overworld run setblock 266 63 43 gravel
execute in minecraft:overworld run fill 266 64 43 266 144 43 air
execute in minecraft:overworld run fill 266 64 43 266 64 43 water
execute in minecraft:overworld run fill 266 58 44 266 60 44 stone
execute in minecraft:overworld run fill 266 61 44 266 62 44 dirt
execute in minecraft:overworld run setblock 266 63 44 gravel
execute in minecraft:overworld run fill 266 64 44 266 144 44 air
execute in minecraft:overworld run fill 266 64 44 266 64 44 water
execute in minecraft:overworld run fill 266 58 45 266 61 45 stone
execute in minecraft:overworld run fill 266 62 45 266 63 45 dirt
execute in minecraft:overworld run setblock 266 64 45 grass_block
execute in minecraft:overworld run fill 266 65 45 266 144 45 air
execute in minecraft:overworld run fill 266 58 46 266 61 46 stone
execute in minecraft:overworld run fill 266 62 46 266 63 46 dirt
execute in minecraft:overworld run setblock 266 64 46 coarse_dirt
execute in minecraft:overworld run fill 266 65 46 266 144 46 air
execute in minecraft:overworld run fill 266 58 47 266 61 47 stone
execute in minecraft:overworld run fill 266 62 47 266 63 47 dirt
execute in minecraft:overworld run setblock 266 64 47 coarse_dirt
execute in minecraft:overworld run fill 266 65 47 266 144 47 air
execute in minecraft:overworld run fill 267 58 -48 267 61 -48 stone
execute in minecraft:overworld run fill 267 62 -48 267 63 -48 dirt
execute in minecraft:overworld run setblock 267 64 -48 coarse_dirt
execute in minecraft:overworld run fill 267 65 -48 267 144 -48 air
execute in minecraft:overworld run fill 267 58 -47 267 63 -47 stone
execute in minecraft:overworld run fill 267 64 -47 267 65 -47 dirt
execute in minecraft:overworld run setblock 267 66 -47 coarse_dirt
execute in minecraft:overworld run fill 267 67 -47 267 144 -47 air
execute in minecraft:overworld run fill 267 58 -46 267 65 -46 stone
execute in minecraft:overworld run fill 267 66 -46 267 67 -46 dirt
execute in minecraft:overworld run setblock 267 68 -46 coarse_dirt
execute in minecraft:overworld run fill 267 69 -46 267 144 -46 air
execute in minecraft:overworld run fill 267 58 -45 267 67 -45 stone
execute in minecraft:overworld run fill 267 68 -45 267 69 -45 dirt
execute in minecraft:overworld run setblock 267 70 -45 grass_block
execute in minecraft:overworld run fill 267 71 -45 267 144 -45 air
execute in minecraft:overworld run fill 267 58 -44 267 69 -44 stone
execute in minecraft:overworld run fill 267 70 -44 267 71 -44 dirt
execute in minecraft:overworld run setblock 267 72 -44 coarse_dirt
execute in minecraft:overworld run fill 267 73 -44 267 144 -44 air
execute in minecraft:overworld run fill 267 58 -43 267 70 -43 stone
execute in minecraft:overworld run fill 267 71 -43 267 72 -43 dirt
execute in minecraft:overworld run setblock 267 73 -43 grass_block
execute in minecraft:overworld run fill 267 74 -43 267 144 -43 air
execute in minecraft:overworld run fill 267 58 -42 267 72 -42 stone
execute in minecraft:overworld run fill 267 73 -42 267 74 -42 dirt
execute in minecraft:overworld run setblock 267 75 -42 coarse_dirt
execute in minecraft:overworld run fill 267 76 -42 267 144 -42 air
execute in minecraft:overworld run fill 267 58 -41 267 74 -41 stone
execute in minecraft:overworld run fill 267 75 -41 267 76 -41 dirt
execute in minecraft:overworld run setblock 267 77 -41 coarse_dirt
execute in minecraft:overworld run fill 267 78 -41 267 144 -41 air
execute in minecraft:overworld run setblock 267 78 -41 grass
execute in minecraft:overworld run fill 267 58 -40 267 75 -40 stone
execute in minecraft:overworld run fill 267 76 -40 267 77 -40 dirt
execute in minecraft:overworld run setblock 267 78 -40 coarse_dirt
execute in minecraft:overworld run fill 267 79 -40 267 144 -40 air
execute in minecraft:overworld run fill 267 58 -39 267 77 -39 stone
execute in minecraft:overworld run fill 267 78 -39 267 79 -39 dirt
execute in minecraft:overworld run setblock 267 80 -39 grass_block
execute in minecraft:overworld run fill 267 81 -39 267 144 -39 air
execute in minecraft:overworld run fill 267 58 -38 267 78 -38 stone
execute in minecraft:overworld run fill 267 79 -38 267 80 -38 dirt
execute in minecraft:overworld run setblock 267 81 -38 coarse_dirt
execute in minecraft:overworld run fill 267 82 -38 267 144 -38 air
execute in minecraft:overworld run fill 267 58 -37 267 78 -37 stone
execute in minecraft:overworld run fill 267 79 -37 267 80 -37 dirt
execute in minecraft:overworld run setblock 267 81 -37 grass_block
execute in minecraft:overworld run fill 267 82 -37 267 144 -37 air
execute in minecraft:overworld run fill 267 58 -36 267 77 -36 stone
execute in minecraft:overworld run fill 267 78 -36 267 79 -36 dirt
execute in minecraft:overworld run setblock 267 80 -36 coarse_dirt
execute in minecraft:overworld run fill 267 81 -36 267 144 -36 air
execute in minecraft:overworld run fill 267 58 -35 267 77 -35 stone
execute in minecraft:overworld run fill 267 78 -35 267 79 -35 dirt
execute in minecraft:overworld run setblock 267 80 -35 coarse_dirt
execute in minecraft:overworld run fill 267 81 -35 267 144 -35 air
execute in minecraft:overworld run fill 267 58 -34 267 77 -34 stone
execute in minecraft:overworld run fill 267 78 -34 267 79 -34 dirt
execute in minecraft:overworld run setblock 267 80 -34 coarse_dirt
execute in minecraft:overworld run fill 267 81 -34 267 144 -34 air
execute in minecraft:overworld run fill 267 58 -33 267 77 -33 stone
execute in minecraft:overworld run fill 267 78 -33 267 79 -33 dirt
execute in minecraft:overworld run setblock 267 80 -33 grass_block
execute in minecraft:overworld run fill 267 81 -33 267 144 -33 air
execute in minecraft:overworld run fill 267 58 -32 267 76 -32 stone
execute in minecraft:overworld run fill 267 77 -32 267 78 -32 dirt
execute in minecraft:overworld run setblock 267 79 -32 grass_block
execute in minecraft:overworld run fill 267 80 -32 267 144 -32 air
execute in minecraft:overworld run fill 267 58 -31 267 76 -31 stone
execute in minecraft:overworld run fill 267 77 -31 267 78 -31 dirt
execute in minecraft:overworld run setblock 267 79 -31 grass_block
execute in minecraft:overworld run fill 267 80 -31 267 144 -31 air
execute in minecraft:overworld run fill 267 58 -30 267 76 -30 stone
execute in minecraft:overworld run fill 267 77 -30 267 78 -30 dirt
execute in minecraft:overworld run setblock 267 79 -30 coarse_dirt
execute in minecraft:overworld run fill 267 80 -30 267 144 -30 air
execute in minecraft:overworld run fill 267 58 -29 267 75 -29 stone
execute in minecraft:overworld run fill 267 76 -29 267 77 -29 dirt
execute in minecraft:overworld run setblock 267 78 -29 grass_block
execute in minecraft:overworld run fill 267 79 -29 267 144 -29 air
execute in minecraft:overworld run setblock 267 79 -29 grass
execute in minecraft:overworld run fill 267 58 -28 267 75 -28 stone
execute in minecraft:overworld run fill 267 76 -28 267 77 -28 dirt
execute in minecraft:overworld run setblock 267 78 -28 coarse_dirt
execute in minecraft:overworld run fill 267 79 -28 267 144 -28 air
execute in minecraft:overworld run fill 267 58 -27 267 74 -27 stone
execute in minecraft:overworld run fill 267 75 -27 267 76 -27 dirt
execute in minecraft:overworld run setblock 267 77 -27 coarse_dirt
execute in minecraft:overworld run fill 267 78 -27 267 144 -27 air
execute in minecraft:overworld run fill 267 58 -26 267 74 -26 stone
execute in minecraft:overworld run fill 267 75 -26 267 76 -26 dirt
execute in minecraft:overworld run setblock 267 77 -26 grass_block
execute in minecraft:overworld run fill 267 78 -26 267 144 -26 air
execute in minecraft:overworld run fill 267 58 -25 267 73 -25 stone
execute in minecraft:overworld run fill 267 74 -25 267 75 -25 dirt
execute in minecraft:overworld run setblock 267 76 -25 coarse_dirt
execute in minecraft:overworld run fill 267 77 -25 267 144 -25 air
execute in minecraft:overworld run fill 267 58 -24 267 73 -24 stone
execute in minecraft:overworld run fill 267 74 -24 267 75 -24 dirt
execute in minecraft:overworld run setblock 267 76 -24 coarse_dirt
execute in minecraft:overworld run fill 267 77 -24 267 144 -24 air
execute in minecraft:overworld run fill 267 58 -23 267 72 -23 stone
execute in minecraft:overworld run fill 267 73 -23 267 74 -23 dirt
execute in minecraft:overworld run setblock 267 75 -23 coarse_dirt
execute in minecraft:overworld run fill 267 76 -23 267 144 -23 air
execute in minecraft:overworld run fill 267 58 -22 267 71 -22 stone
execute in minecraft:overworld run fill 267 72 -22 267 73 -22 dirt
execute in minecraft:overworld run setblock 267 74 -22 grass_block
execute in minecraft:overworld run fill 267 75 -22 267 144 -22 air
execute in minecraft:overworld run fill 267 58 -21 267 70 -21 stone
execute in minecraft:overworld run fill 267 71 -21 267 72 -21 dirt
execute in minecraft:overworld run setblock 267 73 -21 coarse_dirt
execute in minecraft:overworld run fill 267 74 -21 267 144 -21 air
execute in minecraft:overworld run fill 267 58 -20 267 70 -20 stone
execute in minecraft:overworld run fill 267 71 -20 267 72 -20 dirt
execute in minecraft:overworld run setblock 267 73 -20 grass_block
execute in minecraft:overworld run fill 267 74 -20 267 144 -20 air
execute in minecraft:overworld run fill 267 58 -19 267 69 -19 stone
execute in minecraft:overworld run fill 267 70 -19 267 71 -19 dirt
execute in minecraft:overworld run setblock 267 72 -19 coarse_dirt
execute in minecraft:overworld run fill 267 73 -19 267 144 -19 air
execute in minecraft:overworld run fill 267 58 -18 267 68 -18 stone
execute in minecraft:overworld run fill 267 69 -18 267 70 -18 dirt
execute in minecraft:overworld run setblock 267 71 -18 grass_block
execute in minecraft:overworld run fill 267 72 -18 267 144 -18 air
execute in minecraft:overworld run fill 267 58 -17 267 67 -17 stone
execute in minecraft:overworld run fill 267 68 -17 267 69 -17 dirt
execute in minecraft:overworld run setblock 267 70 -17 grass_block
execute in minecraft:overworld run fill 267 71 -17 267 144 -17 air
execute in minecraft:overworld run setblock 267 71 -17 grass
execute in minecraft:overworld run fill 267 58 -16 267 66 -16 stone
execute in minecraft:overworld run fill 267 67 -16 267 68 -16 dirt
execute in minecraft:overworld run setblock 267 69 -16 coarse_dirt
execute in minecraft:overworld run fill 267 70 -16 267 144 -16 air
execute in minecraft:overworld run fill 267 58 -15 267 64 -15 stone
execute in minecraft:overworld run fill 267 65 -15 267 66 -15 dirt
execute in minecraft:overworld run setblock 267 67 -15 coarse_dirt
execute in minecraft:overworld run fill 267 68 -15 267 144 -15 air
execute in minecraft:overworld run fill 267 58 -14 267 63 -14 stone
execute in minecraft:overworld run fill 267 64 -14 267 65 -14 dirt
execute in minecraft:overworld run setblock 267 66 -14 coarse_dirt
execute in minecraft:overworld run fill 267 67 -14 267 144 -14 air
execute in minecraft:overworld run fill 267 58 -13 267 62 -13 stone
execute in minecraft:overworld run fill 267 63 -13 267 64 -13 dirt
execute in minecraft:overworld run setblock 267 65 -13 coarse_dirt
execute in minecraft:overworld run fill 267 66 -13 267 144 -13 air
execute in minecraft:overworld run fill 267 58 -12 267 61 -12 stone
execute in minecraft:overworld run fill 267 62 -12 267 63 -12 dirt
execute in minecraft:overworld run setblock 267 64 -12 coarse_dirt
execute in minecraft:overworld run fill 267 65 -12 267 144 -12 air
execute in minecraft:overworld run fill 267 58 -11 267 60 -11 stone
execute in minecraft:overworld run fill 267 61 -11 267 62 -11 dirt
execute in minecraft:overworld run setblock 267 63 -11 gravel
execute in minecraft:overworld run fill 267 64 -11 267 144 -11 air
execute in minecraft:overworld run fill 267 64 -11 267 64 -11 water
execute in minecraft:overworld run fill 267 58 -10 267 60 -10 stone
execute in minecraft:overworld run fill 267 61 -10 267 62 -10 dirt
execute in minecraft:overworld run setblock 267 63 -10 gravel
execute in minecraft:overworld run fill 267 64 -10 267 144 -10 air
execute in minecraft:overworld run fill 267 64 -10 267 64 -10 water
execute in minecraft:overworld run fill 267 58 -9 267 59 -9 stone
execute in minecraft:overworld run fill 267 60 -9 267 61 -9 dirt
execute in minecraft:overworld run setblock 267 62 -9 gravel
execute in minecraft:overworld run fill 267 63 -9 267 144 -9 air
execute in minecraft:overworld run fill 267 63 -9 267 64 -9 water
execute in minecraft:overworld run fill 267 58 -8 267 58 -8 stone
execute in minecraft:overworld run fill 267 59 -8 267 60 -8 dirt
execute in minecraft:overworld run setblock 267 61 -8 gravel
execute in minecraft:overworld run fill 267 62 -8 267 144 -8 air
execute in minecraft:overworld run fill 267 62 -8 267 64 -8 water
execute in minecraft:overworld run fill 267 58 -7 267 58 -7 stone
execute in minecraft:overworld run fill 267 59 -7 267 60 -7 dirt
execute in minecraft:overworld run setblock 267 61 -7 gravel
execute in minecraft:overworld run fill 267 62 -7 267 144 -7 air
execute in minecraft:overworld run fill 267 62 -7 267 64 -7 water
execute in minecraft:overworld run fill 267 58 -6 267 57 -6 stone
execute in minecraft:overworld run fill 267 58 -6 267 59 -6 dirt
execute in minecraft:overworld run setblock 267 60 -6 gravel
execute in minecraft:overworld run fill 267 61 -6 267 144 -6 air
execute in minecraft:overworld run fill 267 61 -6 267 64 -6 water
execute in minecraft:overworld run fill 267 58 -5 267 57 -5 stone
execute in minecraft:overworld run fill 267 58 -5 267 59 -5 dirt
execute in minecraft:overworld run setblock 267 60 -5 gravel
execute in minecraft:overworld run fill 267 61 -5 267 144 -5 air
execute in minecraft:overworld run fill 267 61 -5 267 64 -5 water
execute in minecraft:overworld run fill 267 58 -4 267 56 -4 stone
execute in minecraft:overworld run fill 267 57 -4 267 58 -4 dirt
execute in minecraft:overworld run setblock 267 59 -4 gravel
execute in minecraft:overworld run fill 267 60 -4 267 144 -4 air
execute in minecraft:overworld run fill 267 60 -4 267 64 -4 water
execute in minecraft:overworld run fill 267 58 -3 267 56 -3 stone
execute in minecraft:overworld run fill 267 57 -3 267 58 -3 dirt
execute in minecraft:overworld run setblock 267 59 -3 gravel
execute in minecraft:overworld run fill 267 60 -3 267 144 -3 air
execute in minecraft:overworld run fill 267 60 -3 267 64 -3 water
execute in minecraft:overworld run fill 267 58 -2 267 56 -2 stone
execute in minecraft:overworld run fill 267 57 -2 267 58 -2 dirt
execute in minecraft:overworld run setblock 267 59 -2 gravel
execute in minecraft:overworld run fill 267 60 -2 267 144 -2 air
execute in minecraft:overworld run fill 267 60 -2 267 64 -2 water
execute in minecraft:overworld run fill 267 58 -1 267 55 -1 stone
execute in minecraft:overworld run fill 267 56 -1 267 57 -1 dirt
execute in minecraft:overworld run setblock 267 58 -1 gravel
execute in minecraft:overworld run fill 267 59 -1 267 144 -1 air
execute in minecraft:overworld run fill 267 59 -1 267 64 -1 water
execute in minecraft:overworld run fill 267 58 0 267 55 0 stone
execute in minecraft:overworld run fill 267 56 0 267 57 0 dirt
execute in minecraft:overworld run setblock 267 58 0 gravel
execute in minecraft:overworld run fill 267 59 0 267 144 0 air
execute in minecraft:overworld run fill 267 59 0 267 64 0 water
execute in minecraft:overworld run fill 267 58 1 267 55 1 stone
execute in minecraft:overworld run fill 267 56 1 267 57 1 dirt
execute in minecraft:overworld run setblock 267 58 1 gravel
execute in minecraft:overworld run fill 267 59 1 267 144 1 air
execute in minecraft:overworld run fill 267 59 1 267 64 1 water
execute in minecraft:overworld run fill 267 58 2 267 55 2 stone
execute in minecraft:overworld run fill 267 56 2 267 57 2 dirt
execute in minecraft:overworld run setblock 267 58 2 gravel
execute in minecraft:overworld run fill 267 59 2 267 144 2 air
schedule function blade_gallery:random/burned/part_94 1t replace
