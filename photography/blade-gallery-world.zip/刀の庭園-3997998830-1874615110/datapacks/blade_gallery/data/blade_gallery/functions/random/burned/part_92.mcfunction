execute in minecraft:overworld run fill 266 58 -11 266 59 -11 stone
execute in minecraft:overworld run fill 266 60 -11 266 61 -11 dirt
execute in minecraft:overworld run setblock 266 62 -11 gravel
execute in minecraft:overworld run fill 266 63 -11 266 144 -11 air
execute in minecraft:overworld run fill 266 63 -11 266 64 -11 water
execute in minecraft:overworld run fill 266 58 -10 266 58 -10 stone
execute in minecraft:overworld run fill 266 59 -10 266 60 -10 dirt
execute in minecraft:overworld run setblock 266 61 -10 gravel
execute in minecraft:overworld run fill 266 62 -10 266 144 -10 air
execute in minecraft:overworld run fill 266 62 -10 266 64 -10 water
execute in minecraft:overworld run fill 266 58 -9 266 58 -9 stone
execute in minecraft:overworld run fill 266 59 -9 266 60 -9 dirt
execute in minecraft:overworld run setblock 266 61 -9 gravel
execute in minecraft:overworld run fill 266 62 -9 266 144 -9 air
execute in minecraft:overworld run fill 266 62 -9 266 64 -9 water
execute in minecraft:overworld run fill 266 58 -8 266 57 -8 stone
execute in minecraft:overworld run fill 266 58 -8 266 59 -8 dirt
execute in minecraft:overworld run setblock 266 60 -8 gravel
execute in minecraft:overworld run fill 266 61 -8 266 144 -8 air
execute in minecraft:overworld run fill 266 61 -8 266 64 -8 water
execute in minecraft:overworld run fill 266 58 -7 266 57 -7 stone
execute in minecraft:overworld run fill 266 58 -7 266 59 -7 dirt
execute in minecraft:overworld run setblock 266 60 -7 gravel
execute in minecraft:overworld run fill 266 61 -7 266 144 -7 air
execute in minecraft:overworld run fill 266 61 -7 266 64 -7 water
execute in minecraft:overworld run fill 266 58 -6 266 56 -6 stone
execute in minecraft:overworld run fill 266 57 -6 266 58 -6 dirt
execute in minecraft:overworld run setblock 266 59 -6 gravel
execute in minecraft:overworld run fill 266 60 -6 266 144 -6 air
execute in minecraft:overworld run fill 266 60 -6 266 64 -6 water
execute in minecraft:overworld run fill 266 58 -5 266 56 -5 stone
execute in minecraft:overworld run fill 266 57 -5 266 58 -5 dirt
execute in minecraft:overworld run setblock 266 59 -5 gravel
execute in minecraft:overworld run fill 266 60 -5 266 144 -5 air
execute in minecraft:overworld run fill 266 60 -5 266 64 -5 water
execute in minecraft:overworld run fill 266 58 -4 266 55 -4 stone
execute in minecraft:overworld run fill 266 56 -4 266 57 -4 dirt
execute in minecraft:overworld run setblock 266 58 -4 gravel
execute in minecraft:overworld run fill 266 59 -4 266 144 -4 air
execute in minecraft:overworld run fill 266 59 -4 266 64 -4 water
execute in minecraft:overworld run fill 266 58 -3 266 55 -3 stone
execute in minecraft:overworld run fill 266 56 -3 266 57 -3 dirt
execute in minecraft:overworld run setblock 266 58 -3 gravel
execute in minecraft:overworld run fill 266 59 -3 266 144 -3 air
execute in minecraft:overworld run fill 266 59 -3 266 64 -3 water
execute in minecraft:overworld run fill 266 58 -2 266 55 -2 stone
execute in minecraft:overworld run fill 266 56 -2 266 57 -2 dirt
execute in minecraft:overworld run setblock 266 58 -2 gravel
execute in minecraft:overworld run fill 266 59 -2 266 144 -2 air
execute in minecraft:overworld run fill 266 59 -2 266 64 -2 water
execute in minecraft:overworld run fill 266 58 -1 266 55 -1 stone
execute in minecraft:overworld run fill 266 56 -1 266 57 -1 dirt
execute in minecraft:overworld run setblock 266 58 -1 gravel
execute in minecraft:overworld run fill 266 59 -1 266 144 -1 air
execute in minecraft:overworld run fill 266 59 -1 266 64 -1 water
execute in minecraft:overworld run fill 266 58 0 266 55 0 stone
execute in minecraft:overworld run fill 266 56 0 266 57 0 dirt
execute in minecraft:overworld run setblock 266 58 0 gravel
execute in minecraft:overworld run fill 266 59 0 266 144 0 air
execute in minecraft:overworld run fill 266 59 0 266 64 0 water
execute in minecraft:overworld run fill 266 58 1 266 55 1 stone
execute in minecraft:overworld run fill 266 56 1 266 57 1 dirt
execute in minecraft:overworld run setblock 266 58 1 gravel
execute in minecraft:overworld run fill 266 59 1 266 144 1 air
execute in minecraft:overworld run fill 266 59 1 266 64 1 water
execute in minecraft:overworld run fill 266 58 2 266 55 2 stone
execute in minecraft:overworld run fill 266 56 2 266 57 2 dirt
execute in minecraft:overworld run setblock 266 58 2 gravel
execute in minecraft:overworld run fill 266 59 2 266 144 2 air
execute in minecraft:overworld run fill 266 59 2 266 64 2 water
execute in minecraft:overworld run fill 266 58 3 266 55 3 stone
execute in minecraft:overworld run fill 266 56 3 266 57 3 dirt
execute in minecraft:overworld run setblock 266 58 3 gravel
execute in minecraft:overworld run fill 266 59 3 266 144 3 air
execute in minecraft:overworld run fill 266 59 3 266 64 3 water
execute in minecraft:overworld run fill 266 58 4 266 55 4 stone
execute in minecraft:overworld run fill 266 56 4 266 57 4 dirt
execute in minecraft:overworld run setblock 266 58 4 gravel
execute in minecraft:overworld run fill 266 59 4 266 144 4 air
execute in minecraft:overworld run fill 266 59 4 266 64 4 water
execute in minecraft:overworld run fill 266 58 5 266 55 5 stone
execute in minecraft:overworld run fill 266 56 5 266 57 5 dirt
execute in minecraft:overworld run setblock 266 58 5 gravel
execute in minecraft:overworld run fill 266 59 5 266 144 5 air
execute in minecraft:overworld run fill 266 59 5 266 64 5 water
execute in minecraft:overworld run fill 266 58 6 266 56 6 stone
execute in minecraft:overworld run fill 266 57 6 266 58 6 dirt
execute in minecraft:overworld run setblock 266 59 6 gravel
execute in minecraft:overworld run fill 266 60 6 266 144 6 air
execute in minecraft:overworld run fill 266 60 6 266 64 6 water
execute in minecraft:overworld run fill 266 58 7 266 56 7 stone
execute in minecraft:overworld run fill 266 57 7 266 58 7 dirt
execute in minecraft:overworld run setblock 266 59 7 gravel
execute in minecraft:overworld run fill 266 60 7 266 144 7 air
execute in minecraft:overworld run fill 266 60 7 266 64 7 water
execute in minecraft:overworld run fill 266 58 8 266 56 8 stone
execute in minecraft:overworld run fill 266 57 8 266 58 8 dirt
execute in minecraft:overworld run setblock 266 59 8 gravel
execute in minecraft:overworld run fill 266 60 8 266 144 8 air
execute in minecraft:overworld run fill 266 60 8 266 64 8 water
execute in minecraft:overworld run fill 266 58 9 266 56 9 stone
execute in minecraft:overworld run fill 266 57 9 266 58 9 dirt
execute in minecraft:overworld run setblock 266 59 9 gravel
execute in minecraft:overworld run fill 266 60 9 266 144 9 air
execute in minecraft:overworld run fill 266 60 9 266 64 9 water
execute in minecraft:overworld run fill 266 58 10 266 56 10 stone
execute in minecraft:overworld run fill 266 57 10 266 58 10 dirt
execute in minecraft:overworld run setblock 266 59 10 gravel
execute in minecraft:overworld run fill 266 60 10 266 144 10 air
execute in minecraft:overworld run fill 266 60 10 266 64 10 water
execute in minecraft:overworld run fill 266 58 11 266 56 11 stone
execute in minecraft:overworld run fill 266 57 11 266 58 11 dirt
execute in minecraft:overworld run setblock 266 59 11 gravel
execute in minecraft:overworld run fill 266 60 11 266 144 11 air
execute in minecraft:overworld run fill 266 60 11 266 64 11 water
execute in minecraft:overworld run fill 266 58 12 266 56 12 stone
execute in minecraft:overworld run fill 266 57 12 266 58 12 dirt
execute in minecraft:overworld run setblock 266 59 12 gravel
execute in minecraft:overworld run fill 266 60 12 266 144 12 air
execute in minecraft:overworld run fill 266 60 12 266 64 12 water
execute in minecraft:overworld run fill 266 58 13 266 56 13 stone
execute in minecraft:overworld run fill 266 57 13 266 58 13 dirt
execute in minecraft:overworld run setblock 266 59 13 gravel
execute in minecraft:overworld run fill 266 60 13 266 144 13 air
execute in minecraft:overworld run fill 266 60 13 266 64 13 water
execute in minecraft:overworld run fill 266 58 14 266 56 14 stone
execute in minecraft:overworld run fill 266 57 14 266 58 14 dirt
execute in minecraft:overworld run setblock 266 59 14 gravel
execute in minecraft:overworld run fill 266 60 14 266 144 14 air
execute in minecraft:overworld run fill 266 60 14 266 64 14 water
execute in minecraft:overworld run fill 266 58 15 266 56 15 stone
execute in minecraft:overworld run fill 266 57 15 266 58 15 dirt
execute in minecraft:overworld run setblock 266 59 15 gravel
execute in minecraft:overworld run fill 266 60 15 266 144 15 air
execute in minecraft:overworld run fill 266 60 15 266 64 15 water
execute in minecraft:overworld run fill 266 58 16 266 56 16 stone
execute in minecraft:overworld run fill 266 57 16 266 58 16 dirt
execute in minecraft:overworld run setblock 266 59 16 gravel
execute in minecraft:overworld run fill 266 60 16 266 144 16 air
execute in minecraft:overworld run fill 266 60 16 266 64 16 water
execute in minecraft:overworld run fill 266 58 17 266 56 17 stone
execute in minecraft:overworld run fill 266 57 17 266 58 17 dirt
execute in minecraft:overworld run setblock 266 59 17 gravel
execute in minecraft:overworld run fill 266 60 17 266 144 17 air
execute in minecraft:overworld run fill 266 60 17 266 64 17 water
execute in minecraft:overworld run fill 266 58 18 266 56 18 stone
execute in minecraft:overworld run fill 266 57 18 266 58 18 dirt
execute in minecraft:overworld run setblock 266 59 18 gravel
execute in minecraft:overworld run fill 266 60 18 266 144 18 air
execute in minecraft:overworld run fill 266 60 18 266 64 18 water
execute in minecraft:overworld run fill 266 58 19 266 56 19 stone
execute in minecraft:overworld run fill 266 57 19 266 58 19 dirt
execute in minecraft:overworld run setblock 266 59 19 gravel
execute in minecraft:overworld run fill 266 60 19 266 144 19 air
execute in minecraft:overworld run fill 266 60 19 266 64 19 water
execute in minecraft:overworld run fill 266 58 20 266 56 20 stone
execute in minecraft:overworld run fill 266 57 20 266 58 20 dirt
execute in minecraft:overworld run setblock 266 59 20 gravel
execute in minecraft:overworld run fill 266 60 20 266 144 20 air
execute in minecraft:overworld run fill 266 60 20 266 64 20 water
execute in minecraft:overworld run fill 266 58 21 266 56 21 stone
execute in minecraft:overworld run fill 266 57 21 266 58 21 dirt
execute in minecraft:overworld run setblock 266 59 21 gravel
execute in minecraft:overworld run fill 266 60 21 266 144 21 air
execute in minecraft:overworld run fill 266 60 21 266 64 21 water
execute in minecraft:overworld run fill 266 58 22 266 56 22 stone
execute in minecraft:overworld run fill 266 57 22 266 58 22 dirt
execute in minecraft:overworld run setblock 266 59 22 gravel
execute in minecraft:overworld run fill 266 60 22 266 144 22 air
execute in minecraft:overworld run fill 266 60 22 266 64 22 water
execute in minecraft:overworld run fill 266 58 23 266 56 23 stone
execute in minecraft:overworld run fill 266 57 23 266 58 23 dirt
execute in minecraft:overworld run setblock 266 59 23 gravel
execute in minecraft:overworld run fill 266 60 23 266 144 23 air
execute in minecraft:overworld run fill 266 60 23 266 64 23 water
execute in minecraft:overworld run fill 266 58 24 266 56 24 stone
execute in minecraft:overworld run fill 266 57 24 266 58 24 dirt
execute in minecraft:overworld run setblock 266 59 24 gravel
execute in minecraft:overworld run fill 266 60 24 266 144 24 air
execute in minecraft:overworld run fill 266 60 24 266 64 24 water
execute in minecraft:overworld run fill 266 58 25 266 56 25 stone
execute in minecraft:overworld run fill 266 57 25 266 58 25 dirt
execute in minecraft:overworld run setblock 266 59 25 gravel
execute in minecraft:overworld run fill 266 60 25 266 144 25 air
execute in minecraft:overworld run fill 266 60 25 266 64 25 water
execute in minecraft:overworld run fill 266 58 26 266 56 26 stone
execute in minecraft:overworld run fill 266 57 26 266 58 26 dirt
execute in minecraft:overworld run setblock 266 59 26 gravel
execute in minecraft:overworld run fill 266 60 26 266 144 26 air
execute in minecraft:overworld run fill 266 60 26 266 64 26 water
execute in minecraft:overworld run fill 266 58 27 266 56 27 stone
execute in minecraft:overworld run fill 266 57 27 266 58 27 dirt
execute in minecraft:overworld run setblock 266 59 27 gravel
execute in minecraft:overworld run fill 266 60 27 266 144 27 air
execute in minecraft:overworld run fill 266 60 27 266 64 27 water
execute in minecraft:overworld run fill 266 58 28 266 56 28 stone
execute in minecraft:overworld run fill 266 57 28 266 58 28 dirt
execute in minecraft:overworld run setblock 266 59 28 gravel
execute in minecraft:overworld run fill 266 60 28 266 144 28 air
execute in minecraft:overworld run fill 266 60 28 266 64 28 water
execute in minecraft:overworld run fill 266 58 29 266 56 29 stone
execute in minecraft:overworld run fill 266 57 29 266 58 29 dirt
execute in minecraft:overworld run setblock 266 59 29 gravel
execute in minecraft:overworld run fill 266 60 29 266 144 29 air
execute in minecraft:overworld run fill 266 60 29 266 64 29 water
execute in minecraft:overworld run fill 266 58 30 266 56 30 stone
execute in minecraft:overworld run fill 266 57 30 266 58 30 dirt
execute in minecraft:overworld run setblock 266 59 30 gravel
execute in minecraft:overworld run fill 266 60 30 266 144 30 air
execute in minecraft:overworld run fill 266 60 30 266 64 30 water
execute in minecraft:overworld run fill 266 58 31 266 56 31 stone
execute in minecraft:overworld run fill 266 57 31 266 58 31 dirt
execute in minecraft:overworld run setblock 266 59 31 gravel
execute in minecraft:overworld run fill 266 60 31 266 144 31 air
execute in minecraft:overworld run fill 266 60 31 266 64 31 water
execute in minecraft:overworld run fill 266 58 32 266 56 32 stone
execute in minecraft:overworld run fill 266 57 32 266 58 32 dirt
execute in minecraft:overworld run setblock 266 59 32 gravel
execute in minecraft:overworld run fill 266 60 32 266 144 32 air
execute in minecraft:overworld run fill 266 60 32 266 64 32 water
execute in minecraft:overworld run fill 266 58 33 266 56 33 stone
execute in minecraft:overworld run fill 266 57 33 266 58 33 dirt
execute in minecraft:overworld run setblock 266 59 33 gravel
execute in minecraft:overworld run fill 266 60 33 266 144 33 air
execute in minecraft:overworld run fill 266 60 33 266 64 33 water
execute in minecraft:overworld run fill 266 58 34 266 56 34 stone
execute in minecraft:overworld run fill 266 57 34 266 58 34 dirt
execute in minecraft:overworld run setblock 266 59 34 gravel
execute in minecraft:overworld run fill 266 60 34 266 144 34 air
execute in minecraft:overworld run fill 266 60 34 266 64 34 water
execute in minecraft:overworld run fill 266 58 35 266 57 35 stone
execute in minecraft:overworld run fill 266 58 35 266 59 35 dirt
execute in minecraft:overworld run setblock 266 60 35 gravel
execute in minecraft:overworld run fill 266 61 35 266 144 35 air
execute in minecraft:overworld run fill 266 61 35 266 64 35 water
execute in minecraft:overworld run fill 266 58 36 266 57 36 stone
execute in minecraft:overworld run fill 266 58 36 266 59 36 dirt
execute in minecraft:overworld run setblock 266 60 36 gravel
execute in minecraft:overworld run fill 266 61 36 266 144 36 air
execute in minecraft:overworld run fill 266 61 36 266 64 36 water
execute in minecraft:overworld run fill 266 58 37 266 57 37 stone
execute in minecraft:overworld run fill 266 58 37 266 59 37 dirt
execute in minecraft:overworld run setblock 266 60 37 gravel
execute in minecraft:overworld run fill 266 61 37 266 144 37 air
execute in minecraft:overworld run fill 266 61 37 266 64 37 water
execute in minecraft:overworld run fill 266 58 38 266 57 38 stone
execute in minecraft:overworld run fill 266 58 38 266 59 38 dirt
execute in minecraft:overworld run setblock 266 60 38 gravel
execute in minecraft:overworld run fill 266 61 38 266 144 38 air
execute in minecraft:overworld run fill 266 61 38 266 64 38 water
execute in minecraft:overworld run fill 266 58 39 266 58 39 stone
execute in minecraft:overworld run fill 266 59 39 266 60 39 dirt
execute in minecraft:overworld run setblock 266 61 39 gravel
execute in minecraft:overworld run fill 266 62 39 266 144 39 air
execute in minecraft:overworld run fill 266 62 39 266 64 39 water
execute in minecraft:overworld run fill 266 58 40 266 59 40 stone
schedule function blade_gallery:random/burned/part_93 1t replace
