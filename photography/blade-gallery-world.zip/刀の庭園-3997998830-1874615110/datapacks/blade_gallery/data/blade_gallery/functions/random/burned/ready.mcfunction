schedule clear blade_gallery:random/burned/wait
execute in minecraft:overworld run function blade_gallery:random/burned/part_0
