execute in minecraft:overworld run setblock 221 73 -36 coarse_dirt
execute in minecraft:overworld run fill 221 74 -36 221 144 -36 air
execute in minecraft:overworld run fill 221 58 -35 221 69 -35 stone
execute in minecraft:overworld run fill 221 70 -35 221 71 -35 dirt
execute in minecraft:overworld run setblock 221 72 -35 grass_block
execute in minecraft:overworld run fill 221 73 -35 221 144 -35 air
execute in minecraft:overworld run fill 221 58 -34 221 69 -34 stone
execute in minecraft:overworld run fill 221 70 -34 221 71 -34 dirt
execute in minecraft:overworld run setblock 221 72 -34 coarse_dirt
execute in minecraft:overworld run fill 221 73 -34 221 144 -34 air
execute in minecraft:overworld run fill 221 58 -33 221 68 -33 stone
execute in minecraft:overworld run fill 221 69 -33 221 70 -33 dirt
execute in minecraft:overworld run setblock 221 71 -33 coarse_dirt
execute in minecraft:overworld run fill 221 72 -33 221 144 -33 air
execute in minecraft:overworld run fill 221 58 -32 221 67 -32 stone
execute in minecraft:overworld run fill 221 68 -32 221 69 -32 dirt
execute in minecraft:overworld run setblock 221 70 -32 coarse_dirt
execute in minecraft:overworld run fill 221 71 -32 221 144 -32 air
execute in minecraft:overworld run fill 221 58 -31 221 67 -31 stone
execute in minecraft:overworld run fill 221 68 -31 221 69 -31 dirt
execute in minecraft:overworld run setblock 221 70 -31 coarse_dirt
execute in minecraft:overworld run fill 221 71 -31 221 144 -31 air
execute in minecraft:overworld run fill 221 58 -30 221 67 -30 stone
execute in minecraft:overworld run fill 221 68 -30 221 69 -30 dirt
execute in minecraft:overworld run setblock 221 70 -30 coarse_dirt
execute in minecraft:overworld run fill 221 71 -30 221 144 -30 air
execute in minecraft:overworld run fill 221 58 -29 221 66 -29 stone
execute in minecraft:overworld run fill 221 67 -29 221 68 -29 dirt
execute in minecraft:overworld run setblock 221 69 -29 coarse_dirt
execute in minecraft:overworld run fill 221 70 -29 221 144 -29 air
execute in minecraft:overworld run fill 221 58 -28 221 66 -28 stone
execute in minecraft:overworld run fill 221 67 -28 221 68 -28 dirt
execute in minecraft:overworld run setblock 221 69 -28 grass_block
execute in minecraft:overworld run fill 221 70 -28 221 144 -28 air
execute in minecraft:overworld run fill 221 58 -27 221 66 -27 stone
execute in minecraft:overworld run fill 221 67 -27 221 68 -27 dirt
execute in minecraft:overworld run setblock 221 69 -27 coarse_dirt
execute in minecraft:overworld run fill 221 70 -27 221 144 -27 air
execute in minecraft:overworld run fill 221 58 -26 221 65 -26 stone
execute in minecraft:overworld run fill 221 66 -26 221 67 -26 dirt
execute in minecraft:overworld run setblock 221 68 -26 grass_block
execute in minecraft:overworld run fill 221 69 -26 221 144 -26 air
execute in minecraft:overworld run fill 221 58 -25 221 65 -25 stone
execute in minecraft:overworld run fill 221 66 -25 221 67 -25 dirt
execute in minecraft:overworld run setblock 221 68 -25 grass_block
execute in minecraft:overworld run fill 221 69 -25 221 144 -25 air
execute in minecraft:overworld run fill 221 58 -24 221 65 -24 stone
execute in minecraft:overworld run fill 221 66 -24 221 67 -24 dirt
execute in minecraft:overworld run setblock 221 68 -24 coarse_dirt
execute in minecraft:overworld run fill 221 69 -24 221 144 -24 air
execute in minecraft:overworld run setblock 221 69 -24 grass
execute in minecraft:overworld run fill 221 58 -23 221 66 -23 stone
execute in minecraft:overworld run fill 221 67 -23 221 68 -23 dirt
execute in minecraft:overworld run setblock 221 69 -23 grass_block
execute in minecraft:overworld run fill 221 70 -23 221 144 -23 air
execute in minecraft:overworld run fill 221 58 -22 221 66 -22 stone
execute in minecraft:overworld run fill 221 67 -22 221 68 -22 dirt
execute in minecraft:overworld run setblock 221 69 -22 grass_block
execute in minecraft:overworld run fill 221 70 -22 221 144 -22 air
execute in minecraft:overworld run fill 221 58 -21 221 66 -21 stone
execute in minecraft:overworld run fill 221 67 -21 221 68 -21 dirt
execute in minecraft:overworld run setblock 221 69 -21 coarse_dirt
execute in minecraft:overworld run fill 221 70 -21 221 144 -21 air
execute in minecraft:overworld run fill 221 58 -20 221 66 -20 stone
execute in minecraft:overworld run fill 221 67 -20 221 68 -20 dirt
execute in minecraft:overworld run setblock 221 69 -20 grass_block
execute in minecraft:overworld run fill 221 70 -20 221 144 -20 air
execute in minecraft:overworld run fill 221 58 -19 221 66 -19 stone
execute in minecraft:overworld run fill 221 67 -19 221 68 -19 dirt
execute in minecraft:overworld run setblock 221 69 -19 grass_block
execute in minecraft:overworld run fill 221 70 -19 221 144 -19 air
execute in minecraft:overworld run fill 221 58 -18 221 66 -18 stone
execute in minecraft:overworld run fill 221 67 -18 221 68 -18 dirt
execute in minecraft:overworld run setblock 221 69 -18 grass_block
execute in minecraft:overworld run fill 221 70 -18 221 144 -18 air
execute in minecraft:overworld run fill 221 58 -17 221 66 -17 stone
execute in minecraft:overworld run fill 221 67 -17 221 68 -17 dirt
execute in minecraft:overworld run setblock 221 69 -17 coarse_dirt
execute in minecraft:overworld run fill 221 70 -17 221 144 -17 air
execute in minecraft:overworld run fill 221 58 -16 221 66 -16 stone
execute in minecraft:overworld run fill 221 67 -16 221 68 -16 dirt
execute in minecraft:overworld run setblock 221 69 -16 coarse_dirt
execute in minecraft:overworld run fill 221 70 -16 221 144 -16 air
execute in minecraft:overworld run fill 221 58 -15 221 66 -15 stone
execute in minecraft:overworld run fill 221 67 -15 221 68 -15 dirt
execute in minecraft:overworld run setblock 221 69 -15 coarse_dirt
execute in minecraft:overworld run fill 221 70 -15 221 144 -15 air
execute in minecraft:overworld run fill 221 58 -14 221 65 -14 stone
execute in minecraft:overworld run fill 221 66 -14 221 67 -14 dirt
execute in minecraft:overworld run setblock 221 68 -14 coarse_dirt
execute in minecraft:overworld run fill 221 69 -14 221 144 -14 air
execute in minecraft:overworld run fill 221 58 -13 221 65 -13 stone
execute in minecraft:overworld run fill 221 66 -13 221 67 -13 dirt
execute in minecraft:overworld run setblock 221 68 -13 coarse_dirt
execute in minecraft:overworld run fill 221 69 -13 221 144 -13 air
execute in minecraft:overworld run fill 221 58 -12 221 65 -12 stone
execute in minecraft:overworld run fill 221 66 -12 221 67 -12 dirt
execute in minecraft:overworld run setblock 221 68 -12 coarse_dirt
execute in minecraft:overworld run fill 221 69 -12 221 144 -12 air
execute in minecraft:overworld run fill 221 58 -11 221 65 -11 stone
execute in minecraft:overworld run fill 221 66 -11 221 67 -11 dirt
execute in minecraft:overworld run setblock 221 68 -11 coarse_dirt
execute in minecraft:overworld run fill 221 69 -11 221 144 -11 air
execute in minecraft:overworld run fill 221 58 -10 221 65 -10 stone
execute in minecraft:overworld run fill 221 66 -10 221 67 -10 dirt
execute in minecraft:overworld run setblock 221 68 -10 coarse_dirt
execute in minecraft:overworld run fill 221 69 -10 221 144 -10 air
execute in minecraft:overworld run fill 221 58 -9 221 65 -9 stone
execute in minecraft:overworld run fill 221 66 -9 221 67 -9 dirt
execute in minecraft:overworld run setblock 221 68 -9 grass_block
execute in minecraft:overworld run fill 221 69 -9 221 144 -9 air
execute in minecraft:overworld run fill 221 58 -8 221 65 -8 stone
execute in minecraft:overworld run fill 221 66 -8 221 67 -8 dirt
execute in minecraft:overworld run setblock 221 68 -8 coarse_dirt
execute in minecraft:overworld run fill 221 69 -8 221 144 -8 air
execute in minecraft:overworld run fill 221 58 -7 221 66 -7 stone
execute in minecraft:overworld run fill 221 67 -7 221 68 -7 dirt
execute in minecraft:overworld run setblock 221 69 -7 coarse_dirt
execute in minecraft:overworld run fill 221 70 -7 221 144 -7 air
execute in minecraft:overworld run fill 221 58 -6 221 66 -6 stone
execute in minecraft:overworld run fill 221 67 -6 221 68 -6 dirt
execute in minecraft:overworld run setblock 221 69 -6 coarse_dirt
execute in minecraft:overworld run fill 221 70 -6 221 144 -6 air
execute in minecraft:overworld run fill 221 58 -5 221 66 -5 stone
execute in minecraft:overworld run fill 221 67 -5 221 68 -5 dirt
execute in minecraft:overworld run setblock 221 69 -5 coarse_dirt
execute in minecraft:overworld run fill 221 70 -5 221 144 -5 air
execute in minecraft:overworld run setblock 221 70 -5 mossy_cobblestone
execute in minecraft:overworld run fill 221 58 -4 221 67 -4 stone
execute in minecraft:overworld run fill 221 68 -4 221 69 -4 dirt
execute in minecraft:overworld run setblock 221 70 -4 coarse_dirt
execute in minecraft:overworld run fill 221 71 -4 221 144 -4 air
execute in minecraft:overworld run fill 221 58 -3 221 67 -3 stone
execute in minecraft:overworld run fill 221 68 -3 221 69 -3 dirt
execute in minecraft:overworld run setblock 221 70 -3 coarse_dirt
execute in minecraft:overworld run fill 221 71 -3 221 144 -3 air
execute in minecraft:overworld run setblock 221 71 -3 grass
execute in minecraft:overworld run fill 221 58 -2 221 67 -2 stone
execute in minecraft:overworld run fill 221 68 -2 221 69 -2 dirt
execute in minecraft:overworld run setblock 221 70 -2 coarse_dirt
execute in minecraft:overworld run fill 221 71 -2 221 144 -2 air
execute in minecraft:overworld run fill 221 58 -1 221 67 -1 stone
execute in minecraft:overworld run fill 221 68 -1 221 69 -1 dirt
execute in minecraft:overworld run setblock 221 70 -1 coarse_dirt
execute in minecraft:overworld run fill 221 71 -1 221 144 -1 air
execute in minecraft:overworld run fill 221 58 0 221 68 0 stone
execute in minecraft:overworld run fill 221 69 0 221 70 0 dirt
execute in minecraft:overworld run setblock 221 71 0 coarse_dirt
execute in minecraft:overworld run fill 221 72 0 221 144 0 air
execute in minecraft:overworld run fill 221 58 1 221 68 1 stone
execute in minecraft:overworld run fill 221 69 1 221 70 1 dirt
execute in minecraft:overworld run setblock 221 71 1 coarse_dirt
execute in minecraft:overworld run fill 221 72 1 221 144 1 air
execute in minecraft:overworld run fill 221 58 2 221 67 2 stone
execute in minecraft:overworld run fill 221 68 2 221 69 2 dirt
execute in minecraft:overworld run setblock 221 70 2 coarse_dirt
execute in minecraft:overworld run fill 221 71 2 221 144 2 air
execute in minecraft:overworld run fill 221 58 3 221 67 3 stone
execute in minecraft:overworld run fill 221 68 3 221 69 3 dirt
execute in minecraft:overworld run setblock 221 70 3 coarse_dirt
execute in minecraft:overworld run fill 221 71 3 221 144 3 air
execute in minecraft:overworld run fill 221 58 4 221 67 4 stone
execute in minecraft:overworld run fill 221 68 4 221 69 4 dirt
execute in minecraft:overworld run setblock 221 70 4 grass_block
execute in minecraft:overworld run fill 221 71 4 221 144 4 air
execute in minecraft:overworld run fill 221 58 5 221 67 5 stone
execute in minecraft:overworld run fill 221 68 5 221 69 5 dirt
execute in minecraft:overworld run setblock 221 70 5 coarse_dirt
execute in minecraft:overworld run fill 221 71 5 221 144 5 air
execute in minecraft:overworld run fill 221 58 6 221 67 6 stone
execute in minecraft:overworld run fill 221 68 6 221 69 6 dirt
execute in minecraft:overworld run setblock 221 70 6 coarse_dirt
execute in minecraft:overworld run fill 221 71 6 221 144 6 air
execute in minecraft:overworld run fill 221 58 7 221 66 7 stone
execute in minecraft:overworld run fill 221 67 7 221 68 7 dirt
execute in minecraft:overworld run setblock 221 69 7 grass_block
execute in minecraft:overworld run fill 221 70 7 221 144 7 air
execute in minecraft:overworld run setblock 221 70 7 grass
execute in minecraft:overworld run fill 221 58 8 221 66 8 stone
execute in minecraft:overworld run fill 221 67 8 221 68 8 dirt
execute in minecraft:overworld run setblock 221 69 8 coarse_dirt
execute in minecraft:overworld run fill 221 70 8 221 144 8 air
execute in minecraft:overworld run fill 221 58 9 221 67 9 stone
execute in minecraft:overworld run fill 221 68 9 221 69 9 dirt
execute in minecraft:overworld run setblock 221 70 9 coarse_dirt
execute in minecraft:overworld run fill 221 71 9 221 144 9 air
execute in minecraft:overworld run fill 221 58 10 221 67 10 stone
execute in minecraft:overworld run fill 221 68 10 221 69 10 dirt
execute in minecraft:overworld run setblock 221 70 10 coarse_dirt
execute in minecraft:overworld run fill 221 71 10 221 144 10 air
execute in minecraft:overworld run fill 221 58 11 221 67 11 stone
execute in minecraft:overworld run fill 221 68 11 221 69 11 dirt
execute in minecraft:overworld run setblock 221 70 11 grass_block
execute in minecraft:overworld run fill 221 71 11 221 144 11 air
execute in minecraft:overworld run setblock 221 71 11 grass
execute in minecraft:overworld run fill 221 58 12 221 68 12 stone
execute in minecraft:overworld run fill 221 69 12 221 70 12 dirt
execute in minecraft:overworld run setblock 221 71 12 grass_block
execute in minecraft:overworld run fill 221 72 12 221 144 12 air
execute in minecraft:overworld run fill 221 58 13 221 68 13 stone
execute in minecraft:overworld run fill 221 69 13 221 70 13 dirt
execute in minecraft:overworld run setblock 221 71 13 coarse_dirt
execute in minecraft:overworld run fill 221 72 13 221 144 13 air
execute in minecraft:overworld run fill 221 58 14 221 68 14 stone
execute in minecraft:overworld run fill 221 69 14 221 70 14 dirt
execute in minecraft:overworld run setblock 221 71 14 grass_block
execute in minecraft:overworld run fill 221 72 14 221 144 14 air
execute in minecraft:overworld run fill 221 58 15 221 69 15 stone
execute in minecraft:overworld run fill 221 70 15 221 71 15 dirt
execute in minecraft:overworld run setblock 221 72 15 coarse_dirt
execute in minecraft:overworld run fill 221 73 15 221 144 15 air
execute in minecraft:overworld run fill 221 58 16 221 69 16 stone
execute in minecraft:overworld run fill 221 70 16 221 71 16 dirt
execute in minecraft:overworld run setblock 221 72 16 coarse_dirt
execute in minecraft:overworld run fill 221 73 16 221 144 16 air
execute in minecraft:overworld run fill 221 58 17 221 70 17 stone
execute in minecraft:overworld run fill 221 71 17 221 72 17 dirt
execute in minecraft:overworld run setblock 221 73 17 grass_block
execute in minecraft:overworld run fill 221 74 17 221 144 17 air
execute in minecraft:overworld run setblock 221 74 17 grass
execute in minecraft:overworld run fill 221 58 18 221 70 18 stone
execute in minecraft:overworld run fill 221 71 18 221 72 18 dirt
execute in minecraft:overworld run setblock 221 73 18 coarse_dirt
execute in minecraft:overworld run fill 221 74 18 221 144 18 air
execute in minecraft:overworld run fill 221 58 19 221 70 19 stone
execute in minecraft:overworld run fill 221 71 19 221 72 19 dirt
execute in minecraft:overworld run setblock 221 73 19 coarse_dirt
execute in minecraft:overworld run fill 221 74 19 221 144 19 air
execute in minecraft:overworld run fill 221 58 20 221 70 20 stone
execute in minecraft:overworld run fill 221 71 20 221 72 20 dirt
execute in minecraft:overworld run setblock 221 73 20 coarse_dirt
execute in minecraft:overworld run fill 221 74 20 221 144 20 air
execute in minecraft:overworld run fill 221 58 21 221 70 21 stone
execute in minecraft:overworld run fill 221 71 21 221 72 21 dirt
execute in minecraft:overworld run setblock 221 73 21 grass_block
execute in minecraft:overworld run fill 221 74 21 221 144 21 air
execute in minecraft:overworld run fill 221 58 22 221 70 22 stone
execute in minecraft:overworld run fill 221 71 22 221 72 22 dirt
execute in minecraft:overworld run setblock 221 73 22 coarse_dirt
execute in minecraft:overworld run fill 221 74 22 221 144 22 air
execute in minecraft:overworld run setblock 221 74 22 grass
execute in minecraft:overworld run fill 221 58 23 221 70 23 stone
execute in minecraft:overworld run fill 221 71 23 221 72 23 dirt
execute in minecraft:overworld run setblock 221 73 23 coarse_dirt
execute in minecraft:overworld run fill 221 74 23 221 144 23 air
execute in minecraft:overworld run fill 221 58 24 221 70 24 stone
execute in minecraft:overworld run fill 221 71 24 221 72 24 dirt
execute in minecraft:overworld run setblock 221 73 24 grass_block
execute in minecraft:overworld run fill 221 74 24 221 144 24 air
execute in minecraft:overworld run fill 221 58 25 221 70 25 stone
execute in minecraft:overworld run fill 221 71 25 221 72 25 dirt
execute in minecraft:overworld run setblock 221 73 25 coarse_dirt
execute in minecraft:overworld run fill 221 74 25 221 144 25 air
execute in minecraft:overworld run fill 221 58 26 221 70 26 stone
execute in minecraft:overworld run fill 221 71 26 221 72 26 dirt
execute in minecraft:overworld run setblock 221 73 26 grass_block
schedule function blade_gallery:random/burned/part_21 1t replace
