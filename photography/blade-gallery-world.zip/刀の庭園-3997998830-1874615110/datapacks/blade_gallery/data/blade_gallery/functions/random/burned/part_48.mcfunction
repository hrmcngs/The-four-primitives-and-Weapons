execute in minecraft:overworld run setblock 239 70 -19 coarse_dirt
execute in minecraft:overworld run fill 239 71 -19 239 144 -19 air
execute in minecraft:overworld run fill 239 58 -18 239 67 -18 stone
execute in minecraft:overworld run fill 239 68 -18 239 69 -18 dirt
execute in minecraft:overworld run setblock 239 70 -18 grass_block
execute in minecraft:overworld run fill 239 71 -18 239 144 -18 air
execute in minecraft:overworld run fill 239 58 -17 239 66 -17 stone
execute in minecraft:overworld run fill 239 67 -17 239 68 -17 dirt
execute in minecraft:overworld run setblock 239 69 -17 grass_block
execute in minecraft:overworld run fill 239 70 -17 239 144 -17 air
execute in minecraft:overworld run fill 239 58 -16 239 66 -16 stone
execute in minecraft:overworld run fill 239 67 -16 239 68 -16 dirt
execute in minecraft:overworld run setblock 239 69 -16 grass_block
execute in minecraft:overworld run fill 239 70 -16 239 144 -16 air
execute in minecraft:overworld run fill 239 58 -15 239 66 -15 stone
execute in minecraft:overworld run fill 239 67 -15 239 68 -15 dirt
execute in minecraft:overworld run setblock 239 69 -15 grass_block
execute in minecraft:overworld run fill 239 70 -15 239 144 -15 air
execute in minecraft:overworld run fill 239 58 -14 239 65 -14 stone
execute in minecraft:overworld run fill 239 66 -14 239 67 -14 dirt
execute in minecraft:overworld run setblock 239 68 -14 grass_block
execute in minecraft:overworld run fill 239 69 -14 239 144 -14 air
execute in minecraft:overworld run fill 239 58 -13 239 65 -13 stone
execute in minecraft:overworld run fill 239 66 -13 239 67 -13 dirt
execute in minecraft:overworld run setblock 239 68 -13 coarse_dirt
execute in minecraft:overworld run fill 239 69 -13 239 144 -13 air
execute in minecraft:overworld run fill 239 58 -12 239 64 -12 stone
execute in minecraft:overworld run fill 239 65 -12 239 66 -12 dirt
execute in minecraft:overworld run setblock 239 67 -12 coarse_dirt
execute in minecraft:overworld run fill 239 68 -12 239 144 -12 air
execute in minecraft:overworld run fill 239 58 -11 239 64 -11 stone
execute in minecraft:overworld run fill 239 65 -11 239 66 -11 dirt
execute in minecraft:overworld run setblock 239 67 -11 coarse_dirt
execute in minecraft:overworld run fill 239 68 -11 239 144 -11 air
execute in minecraft:overworld run setblock 239 68 -11 grass
execute in minecraft:overworld run fill 239 58 -10 239 64 -10 stone
execute in minecraft:overworld run fill 239 65 -10 239 66 -10 dirt
execute in minecraft:overworld run setblock 239 67 -10 grass_block
execute in minecraft:overworld run fill 239 68 -10 239 144 -10 air
execute in minecraft:overworld run fill 239 58 -9 239 64 -9 stone
execute in minecraft:overworld run fill 239 65 -9 239 66 -9 dirt
execute in minecraft:overworld run setblock 239 67 -9 coarse_dirt
execute in minecraft:overworld run fill 239 68 -9 239 144 -9 air
execute in minecraft:overworld run fill 239 58 -8 239 64 -8 stone
execute in minecraft:overworld run fill 239 65 -8 239 66 -8 dirt
execute in minecraft:overworld run setblock 239 67 -8 grass_block
execute in minecraft:overworld run fill 239 68 -8 239 144 -8 air
execute in minecraft:overworld run fill 239 58 -7 239 64 -7 stone
execute in minecraft:overworld run fill 239 65 -7 239 66 -7 dirt
execute in minecraft:overworld run setblock 239 67 -7 coarse_dirt
execute in minecraft:overworld run fill 239 68 -7 239 144 -7 air
execute in minecraft:overworld run fill 239 58 -6 239 64 -6 stone
execute in minecraft:overworld run fill 239 65 -6 239 66 -6 dirt
execute in minecraft:overworld run setblock 239 67 -6 grass_block
execute in minecraft:overworld run fill 239 68 -6 239 144 -6 air
execute in minecraft:overworld run fill 239 58 -5 239 63 -5 stone
execute in minecraft:overworld run fill 239 64 -5 239 65 -5 dirt
execute in minecraft:overworld run setblock 239 66 -5 coarse_dirt
execute in minecraft:overworld run fill 239 67 -5 239 144 -5 air
execute in minecraft:overworld run fill 239 58 -4 239 63 -4 stone
execute in minecraft:overworld run fill 239 64 -4 239 65 -4 dirt
execute in minecraft:overworld run setblock 239 66 -4 coarse_dirt
execute in minecraft:overworld run fill 239 67 -4 239 144 -4 air
execute in minecraft:overworld run fill 239 58 -3 239 63 -3 stone
execute in minecraft:overworld run fill 239 64 -3 239 65 -3 dirt
execute in minecraft:overworld run setblock 239 66 -3 coarse_dirt
execute in minecraft:overworld run fill 239 67 -3 239 144 -3 air
execute in minecraft:overworld run fill 239 58 -2 239 63 -2 stone
execute in minecraft:overworld run fill 239 64 -2 239 65 -2 dirt
execute in minecraft:overworld run setblock 239 66 -2 coarse_dirt
execute in minecraft:overworld run fill 239 67 -2 239 144 -2 air
execute in minecraft:overworld run setblock 239 67 -2 grass
execute in minecraft:overworld run fill 239 58 -1 239 63 -1 stone
execute in minecraft:overworld run fill 239 64 -1 239 65 -1 dirt
execute in minecraft:overworld run setblock 239 66 -1 coarse_dirt
execute in minecraft:overworld run fill 239 67 -1 239 144 -1 air
execute in minecraft:overworld run fill 239 58 0 239 63 0 stone
execute in minecraft:overworld run fill 239 64 0 239 65 0 dirt
execute in minecraft:overworld run setblock 239 66 0 coarse_dirt
execute in minecraft:overworld run fill 239 67 0 239 144 0 air
execute in minecraft:overworld run setblock 239 67 0 mossy_cobblestone
execute in minecraft:overworld run fill 239 58 1 239 63 1 stone
execute in minecraft:overworld run fill 239 64 1 239 65 1 dirt
execute in minecraft:overworld run setblock 239 66 1 grass_block
execute in minecraft:overworld run fill 239 67 1 239 144 1 air
execute in minecraft:overworld run fill 239 58 2 239 63 2 stone
execute in minecraft:overworld run fill 239 64 2 239 65 2 dirt
execute in minecraft:overworld run setblock 239 66 2 coarse_dirt
execute in minecraft:overworld run fill 239 67 2 239 144 2 air
execute in minecraft:overworld run fill 239 58 3 239 63 3 stone
execute in minecraft:overworld run fill 239 64 3 239 65 3 dirt
execute in minecraft:overworld run setblock 239 66 3 coarse_dirt
execute in minecraft:overworld run fill 239 67 3 239 144 3 air
execute in minecraft:overworld run fill 239 58 4 239 64 4 stone
execute in minecraft:overworld run fill 239 65 4 239 66 4 dirt
execute in minecraft:overworld run setblock 239 67 4 grass_block
execute in minecraft:overworld run fill 239 68 4 239 144 4 air
execute in minecraft:overworld run fill 239 58 5 239 64 5 stone
execute in minecraft:overworld run fill 239 65 5 239 66 5 dirt
execute in minecraft:overworld run setblock 239 67 5 coarse_dirt
execute in minecraft:overworld run fill 239 68 5 239 144 5 air
execute in minecraft:overworld run fill 239 58 6 239 64 6 stone
execute in minecraft:overworld run fill 239 65 6 239 66 6 dirt
execute in minecraft:overworld run setblock 239 67 6 coarse_dirt
execute in minecraft:overworld run fill 239 68 6 239 144 6 air
execute in minecraft:overworld run fill 239 58 7 239 65 7 stone
execute in minecraft:overworld run fill 239 66 7 239 67 7 dirt
execute in minecraft:overworld run setblock 239 68 7 coarse_dirt
execute in minecraft:overworld run fill 239 69 7 239 144 7 air
execute in minecraft:overworld run fill 239 58 8 239 65 8 stone
execute in minecraft:overworld run fill 239 66 8 239 67 8 dirt
execute in minecraft:overworld run setblock 239 68 8 coarse_dirt
execute in minecraft:overworld run fill 239 69 8 239 144 8 air
execute in minecraft:overworld run fill 239 58 9 239 65 9 stone
execute in minecraft:overworld run fill 239 66 9 239 67 9 dirt
execute in minecraft:overworld run setblock 239 68 9 grass_block
execute in minecraft:overworld run fill 239 69 9 239 144 9 air
execute in minecraft:overworld run fill 239 58 10 239 65 10 stone
execute in minecraft:overworld run fill 239 66 10 239 67 10 dirt
execute in minecraft:overworld run setblock 239 68 10 coarse_dirt
execute in minecraft:overworld run fill 239 69 10 239 144 10 air
execute in minecraft:overworld run fill 239 58 11 239 66 11 stone
execute in minecraft:overworld run fill 239 67 11 239 68 11 dirt
execute in minecraft:overworld run setblock 239 69 11 grass_block
execute in minecraft:overworld run fill 239 70 11 239 144 11 air
execute in minecraft:overworld run fill 239 58 12 239 66 12 stone
execute in minecraft:overworld run fill 239 67 12 239 68 12 dirt
execute in minecraft:overworld run setblock 239 69 12 coarse_dirt
execute in minecraft:overworld run fill 239 70 12 239 144 12 air
execute in minecraft:overworld run fill 239 58 13 239 66 13 stone
execute in minecraft:overworld run fill 239 67 13 239 68 13 dirt
execute in minecraft:overworld run setblock 239 69 13 coarse_dirt
execute in minecraft:overworld run fill 239 70 13 239 144 13 air
execute in minecraft:overworld run fill 239 58 14 239 66 14 stone
execute in minecraft:overworld run fill 239 67 14 239 68 14 dirt
execute in minecraft:overworld run setblock 239 69 14 coarse_dirt
execute in minecraft:overworld run fill 239 70 14 239 144 14 air
execute in minecraft:overworld run fill 239 58 15 239 66 15 stone
execute in minecraft:overworld run fill 239 67 15 239 68 15 dirt
execute in minecraft:overworld run setblock 239 69 15 coarse_dirt
execute in minecraft:overworld run fill 239 70 15 239 144 15 air
execute in minecraft:overworld run fill 239 58 16 239 66 16 stone
execute in minecraft:overworld run fill 239 67 16 239 68 16 dirt
execute in minecraft:overworld run setblock 239 69 16 coarse_dirt
execute in minecraft:overworld run fill 239 70 16 239 144 16 air
execute in minecraft:overworld run fill 239 58 17 239 67 17 stone
execute in minecraft:overworld run fill 239 68 17 239 69 17 dirt
execute in minecraft:overworld run setblock 239 70 17 coarse_dirt
execute in minecraft:overworld run fill 239 71 17 239 144 17 air
execute in minecraft:overworld run setblock 239 71 17 mossy_cobblestone
execute in minecraft:overworld run fill 239 58 18 239 67 18 stone
execute in minecraft:overworld run fill 239 68 18 239 69 18 dirt
execute in minecraft:overworld run setblock 239 70 18 grass_block
execute in minecraft:overworld run fill 239 71 18 239 144 18 air
execute in minecraft:overworld run fill 239 58 19 239 67 19 stone
execute in minecraft:overworld run fill 239 68 19 239 69 19 dirt
execute in minecraft:overworld run setblock 239 70 19 coarse_dirt
execute in minecraft:overworld run fill 239 71 19 239 144 19 air
execute in minecraft:overworld run fill 239 58 20 239 67 20 stone
execute in minecraft:overworld run fill 239 68 20 239 69 20 dirt
execute in minecraft:overworld run setblock 239 70 20 coarse_dirt
execute in minecraft:overworld run fill 239 71 20 239 144 20 air
execute in minecraft:overworld run fill 239 58 21 239 67 21 stone
execute in minecraft:overworld run fill 239 68 21 239 69 21 dirt
execute in minecraft:overworld run setblock 239 70 21 coarse_dirt
execute in minecraft:overworld run fill 239 71 21 239 144 21 air
execute in minecraft:overworld run setblock 239 71 21 grass
execute in minecraft:overworld run fill 239 58 22 239 67 22 stone
execute in minecraft:overworld run fill 239 68 22 239 69 22 dirt
execute in minecraft:overworld run setblock 239 70 22 coarse_dirt
execute in minecraft:overworld run fill 239 71 22 239 144 22 air
execute in minecraft:overworld run fill 239 58 23 239 67 23 stone
execute in minecraft:overworld run fill 239 68 23 239 69 23 dirt
execute in minecraft:overworld run setblock 239 70 23 coarse_dirt
execute in minecraft:overworld run fill 239 71 23 239 144 23 air
execute in minecraft:overworld run fill 239 58 24 239 67 24 stone
execute in minecraft:overworld run fill 239 68 24 239 69 24 dirt
execute in minecraft:overworld run setblock 239 70 24 grass_block
execute in minecraft:overworld run fill 239 71 24 239 144 24 air
execute in minecraft:overworld run fill 239 58 25 239 67 25 stone
execute in minecraft:overworld run fill 239 68 25 239 69 25 dirt
execute in minecraft:overworld run setblock 239 70 25 grass_block
execute in minecraft:overworld run fill 239 71 25 239 144 25 air
execute in minecraft:overworld run fill 239 58 26 239 67 26 stone
execute in minecraft:overworld run fill 239 68 26 239 69 26 dirt
execute in minecraft:overworld run setblock 239 70 26 grass_block
execute in minecraft:overworld run fill 239 71 26 239 144 26 air
execute in minecraft:overworld run fill 239 58 27 239 67 27 stone
execute in minecraft:overworld run fill 239 68 27 239 69 27 dirt
execute in minecraft:overworld run setblock 239 70 27 grass_block
execute in minecraft:overworld run fill 239 71 27 239 144 27 air
execute in minecraft:overworld run fill 239 58 28 239 67 28 stone
execute in minecraft:overworld run fill 239 68 28 239 69 28 dirt
execute in minecraft:overworld run setblock 239 70 28 grass_block
execute in minecraft:overworld run fill 239 71 28 239 144 28 air
execute in minecraft:overworld run fill 239 58 29 239 67 29 stone
execute in minecraft:overworld run fill 239 68 29 239 69 29 dirt
execute in minecraft:overworld run setblock 239 70 29 coarse_dirt
execute in minecraft:overworld run fill 239 71 29 239 144 29 air
execute in minecraft:overworld run fill 239 58 30 239 67 30 stone
execute in minecraft:overworld run fill 239 68 30 239 69 30 dirt
execute in minecraft:overworld run setblock 239 70 30 grass_block
execute in minecraft:overworld run fill 239 71 30 239 144 30 air
execute in minecraft:overworld run fill 239 58 31 239 67 31 stone
execute in minecraft:overworld run fill 239 68 31 239 69 31 dirt
execute in minecraft:overworld run setblock 239 70 31 grass_block
execute in minecraft:overworld run fill 239 71 31 239 144 31 air
execute in minecraft:overworld run fill 239 58 32 239 67 32 stone
execute in minecraft:overworld run fill 239 68 32 239 69 32 dirt
execute in minecraft:overworld run setblock 239 70 32 grass_block
execute in minecraft:overworld run fill 239 71 32 239 144 32 air
execute in minecraft:overworld run setblock 239 71 32 grass
execute in minecraft:overworld run fill 239 58 33 239 67 33 stone
execute in minecraft:overworld run fill 239 68 33 239 69 33 dirt
execute in minecraft:overworld run setblock 239 70 33 grass_block
execute in minecraft:overworld run fill 239 71 33 239 144 33 air
execute in minecraft:overworld run fill 239 58 34 239 67 34 stone
execute in minecraft:overworld run fill 239 68 34 239 69 34 dirt
execute in minecraft:overworld run setblock 239 70 34 coarse_dirt
execute in minecraft:overworld run fill 239 71 34 239 144 34 air
execute in minecraft:overworld run fill 239 58 35 239 66 35 stone
execute in minecraft:overworld run fill 239 67 35 239 68 35 dirt
execute in minecraft:overworld run setblock 239 69 35 coarse_dirt
execute in minecraft:overworld run fill 239 70 35 239 144 35 air
execute in minecraft:overworld run fill 239 58 36 239 66 36 stone
execute in minecraft:overworld run fill 239 67 36 239 68 36 dirt
execute in minecraft:overworld run setblock 239 69 36 coarse_dirt
execute in minecraft:overworld run fill 239 70 36 239 144 36 air
execute in minecraft:overworld run fill 239 58 37 239 66 37 stone
execute in minecraft:overworld run fill 239 67 37 239 68 37 dirt
execute in minecraft:overworld run setblock 239 69 37 grass_block
execute in minecraft:overworld run fill 239 70 37 239 144 37 air
execute in minecraft:overworld run fill 239 58 38 239 66 38 stone
execute in minecraft:overworld run fill 239 67 38 239 68 38 dirt
execute in minecraft:overworld run setblock 239 69 38 grass_block
execute in minecraft:overworld run fill 239 70 38 239 144 38 air
execute in minecraft:overworld run fill 239 58 39 239 65 39 stone
execute in minecraft:overworld run fill 239 66 39 239 67 39 dirt
execute in minecraft:overworld run setblock 239 68 39 coarse_dirt
execute in minecraft:overworld run fill 239 69 39 239 144 39 air
execute in minecraft:overworld run fill 239 58 40 239 64 40 stone
execute in minecraft:overworld run fill 239 65 40 239 66 40 dirt
execute in minecraft:overworld run setblock 239 67 40 coarse_dirt
execute in minecraft:overworld run fill 239 68 40 239 144 40 air
execute in minecraft:overworld run fill 239 58 41 239 64 41 stone
execute in minecraft:overworld run fill 239 65 41 239 66 41 dirt
execute in minecraft:overworld run setblock 239 67 41 grass_block
execute in minecraft:overworld run fill 239 68 41 239 144 41 air
execute in minecraft:overworld run fill 239 58 42 239 63 42 stone
execute in minecraft:overworld run fill 239 64 42 239 65 42 dirt
execute in minecraft:overworld run setblock 239 66 42 coarse_dirt
execute in minecraft:overworld run fill 239 67 42 239 144 42 air
execute in minecraft:overworld run fill 239 58 43 239 63 43 stone
execute in minecraft:overworld run fill 239 64 43 239 65 43 dirt
execute in minecraft:overworld run setblock 239 66 43 grass_block
execute in minecraft:overworld run fill 239 67 43 239 144 43 air
schedule function blade_gallery:random/burned/part_49 1t replace
