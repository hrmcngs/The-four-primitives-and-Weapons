execute in minecraft:overworld run setblock 289 69 13 grass_block
execute in minecraft:overworld run fill 289 70 13 289 144 13 air
execute in minecraft:overworld run fill 289 58 14 289 66 14 stone
execute in minecraft:overworld run fill 289 67 14 289 68 14 dirt
execute in minecraft:overworld run setblock 289 69 14 coarse_dirt
execute in minecraft:overworld run fill 289 70 14 289 144 14 air
execute in minecraft:overworld run fill 289 58 15 289 66 15 stone
execute in minecraft:overworld run fill 289 67 15 289 68 15 dirt
execute in minecraft:overworld run setblock 289 69 15 grass_block
execute in minecraft:overworld run fill 289 70 15 289 144 15 air
execute in minecraft:overworld run fill 289 58 16 289 65 16 stone
execute in minecraft:overworld run fill 289 66 16 289 67 16 dirt
execute in minecraft:overworld run setblock 289 68 16 grass_block
execute in minecraft:overworld run fill 289 69 16 289 144 16 air
execute in minecraft:overworld run fill 289 58 17 289 65 17 stone
execute in minecraft:overworld run fill 289 66 17 289 67 17 dirt
execute in minecraft:overworld run setblock 289 68 17 grass_block
execute in minecraft:overworld run fill 289 69 17 289 144 17 air
execute in minecraft:overworld run fill 289 58 18 289 65 18 stone
execute in minecraft:overworld run fill 289 66 18 289 67 18 dirt
execute in minecraft:overworld run setblock 289 68 18 coarse_dirt
execute in minecraft:overworld run fill 289 69 18 289 144 18 air
execute in minecraft:overworld run setblock 289 69 18 grass
execute in minecraft:overworld run fill 289 58 19 289 65 19 stone
execute in minecraft:overworld run fill 289 66 19 289 67 19 dirt
execute in minecraft:overworld run setblock 289 68 19 grass_block
execute in minecraft:overworld run fill 289 69 19 289 144 19 air
execute in minecraft:overworld run setblock 289 69 19 mossy_cobblestone
execute in minecraft:overworld run fill 289 58 20 289 65 20 stone
execute in minecraft:overworld run fill 289 66 20 289 67 20 dirt
execute in minecraft:overworld run setblock 289 68 20 coarse_dirt
execute in minecraft:overworld run fill 289 69 20 289 144 20 air
execute in minecraft:overworld run fill 289 58 21 289 65 21 stone
execute in minecraft:overworld run fill 289 66 21 289 67 21 dirt
execute in minecraft:overworld run setblock 289 68 21 grass_block
execute in minecraft:overworld run fill 289 69 21 289 144 21 air
execute in minecraft:overworld run fill 289 58 22 289 65 22 stone
execute in minecraft:overworld run fill 289 66 22 289 67 22 dirt
execute in minecraft:overworld run setblock 289 68 22 grass_block
execute in minecraft:overworld run fill 289 69 22 289 144 22 air
execute in minecraft:overworld run fill 289 58 23 289 65 23 stone
execute in minecraft:overworld run fill 289 66 23 289 67 23 dirt
execute in minecraft:overworld run setblock 289 68 23 coarse_dirt
execute in minecraft:overworld run fill 289 69 23 289 144 23 air
execute in minecraft:overworld run fill 289 58 24 289 65 24 stone
execute in minecraft:overworld run fill 289 66 24 289 67 24 dirt
execute in minecraft:overworld run setblock 289 68 24 coarse_dirt
execute in minecraft:overworld run fill 289 69 24 289 144 24 air
execute in minecraft:overworld run fill 289 58 25 289 65 25 stone
execute in minecraft:overworld run fill 289 66 25 289 67 25 dirt
execute in minecraft:overworld run setblock 289 68 25 grass_block
execute in minecraft:overworld run fill 289 69 25 289 144 25 air
execute in minecraft:overworld run fill 289 58 26 289 65 26 stone
execute in minecraft:overworld run fill 289 66 26 289 67 26 dirt
execute in minecraft:overworld run setblock 289 68 26 grass_block
execute in minecraft:overworld run fill 289 69 26 289 144 26 air
execute in minecraft:overworld run fill 289 58 27 289 65 27 stone
execute in minecraft:overworld run fill 289 66 27 289 67 27 dirt
execute in minecraft:overworld run setblock 289 68 27 grass_block
execute in minecraft:overworld run fill 289 69 27 289 144 27 air
execute in minecraft:overworld run fill 289 58 28 289 65 28 stone
execute in minecraft:overworld run fill 289 66 28 289 67 28 dirt
execute in minecraft:overworld run setblock 289 68 28 coarse_dirt
execute in minecraft:overworld run fill 289 69 28 289 144 28 air
execute in minecraft:overworld run fill 289 58 29 289 65 29 stone
execute in minecraft:overworld run fill 289 66 29 289 67 29 dirt
execute in minecraft:overworld run setblock 289 68 29 coarse_dirt
execute in minecraft:overworld run fill 289 69 29 289 144 29 air
execute in minecraft:overworld run fill 289 58 30 289 64 30 stone
execute in minecraft:overworld run fill 289 65 30 289 66 30 dirt
execute in minecraft:overworld run setblock 289 67 30 grass_block
execute in minecraft:overworld run fill 289 68 30 289 144 30 air
execute in minecraft:overworld run setblock 289 68 30 grass
execute in minecraft:overworld run fill 289 58 31 289 64 31 stone
execute in minecraft:overworld run fill 289 65 31 289 66 31 dirt
execute in minecraft:overworld run setblock 289 67 31 coarse_dirt
execute in minecraft:overworld run fill 289 68 31 289 144 31 air
execute in minecraft:overworld run fill 289 58 32 289 64 32 stone
execute in minecraft:overworld run fill 289 65 32 289 66 32 dirt
execute in minecraft:overworld run setblock 289 67 32 coarse_dirt
execute in minecraft:overworld run fill 289 68 32 289 144 32 air
execute in minecraft:overworld run fill 289 58 33 289 63 33 stone
execute in minecraft:overworld run fill 289 64 33 289 65 33 dirt
execute in minecraft:overworld run setblock 289 66 33 coarse_dirt
execute in minecraft:overworld run fill 289 67 33 289 144 33 air
execute in minecraft:overworld run fill 289 58 34 289 63 34 stone
execute in minecraft:overworld run fill 289 64 34 289 65 34 dirt
execute in minecraft:overworld run setblock 289 66 34 coarse_dirt
execute in minecraft:overworld run fill 289 67 34 289 144 34 air
execute in minecraft:overworld run fill 289 58 35 289 62 35 stone
execute in minecraft:overworld run fill 289 63 35 289 64 35 dirt
execute in minecraft:overworld run setblock 289 65 35 grass_block
execute in minecraft:overworld run fill 289 66 35 289 144 35 air
execute in minecraft:overworld run setblock 289 66 35 grass
execute in minecraft:overworld run fill 289 58 36 289 62 36 stone
execute in minecraft:overworld run fill 289 63 36 289 64 36 dirt
execute in minecraft:overworld run setblock 289 65 36 coarse_dirt
execute in minecraft:overworld run fill 289 66 36 289 144 36 air
execute in minecraft:overworld run fill 289 58 37 289 62 37 stone
execute in minecraft:overworld run fill 289 63 37 289 64 37 dirt
execute in minecraft:overworld run setblock 289 65 37 coarse_dirt
execute in minecraft:overworld run fill 289 66 37 289 144 37 air
execute in minecraft:overworld run fill 289 58 38 289 62 38 stone
execute in minecraft:overworld run fill 289 63 38 289 64 38 dirt
execute in minecraft:overworld run setblock 289 65 38 coarse_dirt
execute in minecraft:overworld run fill 289 66 38 289 144 38 air
execute in minecraft:overworld run fill 289 58 39 289 62 39 stone
execute in minecraft:overworld run fill 289 63 39 289 64 39 dirt
execute in minecraft:overworld run setblock 289 65 39 coarse_dirt
execute in minecraft:overworld run fill 289 66 39 289 144 39 air
execute in minecraft:overworld run fill 289 58 40 289 62 40 stone
execute in minecraft:overworld run fill 289 63 40 289 64 40 dirt
execute in minecraft:overworld run setblock 289 65 40 coarse_dirt
execute in minecraft:overworld run fill 289 66 40 289 144 40 air
execute in minecraft:overworld run fill 289 58 41 289 62 41 stone
execute in minecraft:overworld run fill 289 63 41 289 64 41 dirt
execute in minecraft:overworld run setblock 289 65 41 grass_block
execute in minecraft:overworld run fill 289 66 41 289 144 41 air
execute in minecraft:overworld run fill 289 58 42 289 62 42 stone
execute in minecraft:overworld run fill 289 63 42 289 64 42 dirt
execute in minecraft:overworld run setblock 289 65 42 coarse_dirt
execute in minecraft:overworld run fill 289 66 42 289 144 42 air
execute in minecraft:overworld run fill 289 58 43 289 62 43 stone
execute in minecraft:overworld run fill 289 63 43 289 64 43 dirt
execute in minecraft:overworld run setblock 289 65 43 coarse_dirt
execute in minecraft:overworld run fill 289 66 43 289 144 43 air
execute in minecraft:overworld run fill 289 58 44 289 62 44 stone
execute in minecraft:overworld run fill 289 63 44 289 64 44 dirt
execute in minecraft:overworld run setblock 289 65 44 coarse_dirt
execute in minecraft:overworld run fill 289 66 44 289 144 44 air
execute in minecraft:overworld run fill 289 58 45 289 62 45 stone
execute in minecraft:overworld run fill 289 63 45 289 64 45 dirt
execute in minecraft:overworld run setblock 289 65 45 grass_block
execute in minecraft:overworld run fill 289 66 45 289 144 45 air
execute in minecraft:overworld run fill 289 58 46 289 61 46 stone
execute in minecraft:overworld run fill 289 62 46 289 63 46 dirt
execute in minecraft:overworld run setblock 289 64 46 coarse_dirt
execute in minecraft:overworld run fill 289 65 46 289 144 46 air
execute in minecraft:overworld run fill 289 58 47 289 61 47 stone
execute in minecraft:overworld run fill 289 62 47 289 63 47 dirt
execute in minecraft:overworld run setblock 289 64 47 coarse_dirt
execute in minecraft:overworld run fill 289 65 47 289 144 47 air
execute in minecraft:overworld run fill 290 58 -48 290 61 -48 stone
execute in minecraft:overworld run fill 290 62 -48 290 63 -48 dirt
execute in minecraft:overworld run setblock 290 64 -48 grass_block
execute in minecraft:overworld run fill 290 65 -48 290 144 -48 air
execute in minecraft:overworld run fill 290 58 -47 290 63 -47 stone
execute in minecraft:overworld run fill 290 64 -47 290 65 -47 dirt
execute in minecraft:overworld run setblock 290 66 -47 grass_block
execute in minecraft:overworld run fill 290 67 -47 290 144 -47 air
execute in minecraft:overworld run fill 290 58 -46 290 65 -46 stone
execute in minecraft:overworld run fill 290 66 -46 290 67 -46 dirt
execute in minecraft:overworld run setblock 290 68 -46 grass_block
execute in minecraft:overworld run fill 290 69 -46 290 144 -46 air
execute in minecraft:overworld run fill 290 58 -45 290 67 -45 stone
execute in minecraft:overworld run fill 290 68 -45 290 69 -45 dirt
execute in minecraft:overworld run setblock 290 70 -45 grass_block
execute in minecraft:overworld run fill 290 71 -45 290 144 -45 air
execute in minecraft:overworld run fill 290 58 -44 290 69 -44 stone
execute in minecraft:overworld run fill 290 70 -44 290 71 -44 dirt
execute in minecraft:overworld run setblock 290 72 -44 coarse_dirt
execute in minecraft:overworld run fill 290 73 -44 290 144 -44 air
execute in minecraft:overworld run fill 290 58 -43 290 70 -43 stone
execute in minecraft:overworld run fill 290 71 -43 290 72 -43 dirt
execute in minecraft:overworld run setblock 290 73 -43 coarse_dirt
execute in minecraft:overworld run fill 290 74 -43 290 144 -43 air
execute in minecraft:overworld run fill 290 58 -42 290 72 -42 stone
execute in minecraft:overworld run fill 290 73 -42 290 74 -42 dirt
execute in minecraft:overworld run setblock 290 75 -42 grass_block
execute in minecraft:overworld run fill 290 76 -42 290 144 -42 air
execute in minecraft:overworld run fill 290 58 -41 290 74 -41 stone
execute in minecraft:overworld run fill 290 75 -41 290 76 -41 dirt
execute in minecraft:overworld run setblock 290 77 -41 coarse_dirt
execute in minecraft:overworld run fill 290 78 -41 290 144 -41 air
execute in minecraft:overworld run fill 290 58 -40 290 76 -40 stone
execute in minecraft:overworld run fill 290 77 -40 290 78 -40 dirt
execute in minecraft:overworld run setblock 290 79 -40 coarse_dirt
execute in minecraft:overworld run fill 290 80 -40 290 144 -40 air
execute in minecraft:overworld run fill 290 58 -39 290 77 -39 stone
execute in minecraft:overworld run fill 290 78 -39 290 79 -39 dirt
execute in minecraft:overworld run setblock 290 80 -39 coarse_dirt
execute in minecraft:overworld run fill 290 81 -39 290 144 -39 air
execute in minecraft:overworld run fill 290 58 -38 290 79 -38 stone
execute in minecraft:overworld run fill 290 80 -38 290 81 -38 dirt
execute in minecraft:overworld run setblock 290 82 -38 grass_block
execute in minecraft:overworld run fill 290 83 -38 290 144 -38 air
execute in minecraft:overworld run fill 290 58 -37 290 79 -37 stone
execute in minecraft:overworld run fill 290 80 -37 290 81 -37 dirt
execute in minecraft:overworld run setblock 290 82 -37 coarse_dirt
execute in minecraft:overworld run fill 290 83 -37 290 144 -37 air
execute in minecraft:overworld run fill 290 58 -36 290 78 -36 stone
execute in minecraft:overworld run fill 290 79 -36 290 80 -36 dirt
execute in minecraft:overworld run setblock 290 81 -36 coarse_dirt
execute in minecraft:overworld run fill 290 82 -36 290 144 -36 air
execute in minecraft:overworld run setblock 290 82 -36 grass
execute in minecraft:overworld run fill 290 58 -35 290 78 -35 stone
execute in minecraft:overworld run fill 290 79 -35 290 80 -35 dirt
execute in minecraft:overworld run setblock 290 81 -35 coarse_dirt
execute in minecraft:overworld run fill 290 82 -35 290 144 -35 air
execute in minecraft:overworld run fill 290 58 -34 290 77 -34 stone
execute in minecraft:overworld run fill 290 78 -34 290 79 -34 dirt
execute in minecraft:overworld run setblock 290 80 -34 coarse_dirt
execute in minecraft:overworld run fill 290 81 -34 290 144 -34 air
execute in minecraft:overworld run fill 290 58 -33 290 77 -33 stone
execute in minecraft:overworld run fill 290 78 -33 290 79 -33 dirt
execute in minecraft:overworld run setblock 290 80 -33 coarse_dirt
execute in minecraft:overworld run fill 290 81 -33 290 144 -33 air
execute in minecraft:overworld run fill 290 58 -32 290 76 -32 stone
execute in minecraft:overworld run fill 290 77 -32 290 78 -32 dirt
execute in minecraft:overworld run setblock 290 79 -32 coarse_dirt
execute in minecraft:overworld run fill 290 80 -32 290 144 -32 air
execute in minecraft:overworld run fill 290 58 -31 290 76 -31 stone
execute in minecraft:overworld run fill 290 77 -31 290 78 -31 dirt
execute in minecraft:overworld run setblock 290 79 -31 grass_block
execute in minecraft:overworld run fill 290 80 -31 290 144 -31 air
execute in minecraft:overworld run fill 290 58 -30 290 75 -30 stone
execute in minecraft:overworld run fill 290 76 -30 290 77 -30 dirt
execute in minecraft:overworld run setblock 290 78 -30 coarse_dirt
execute in minecraft:overworld run fill 290 79 -30 290 144 -30 air
execute in minecraft:overworld run fill 290 58 -29 290 75 -29 stone
execute in minecraft:overworld run fill 290 76 -29 290 77 -29 dirt
execute in minecraft:overworld run setblock 290 78 -29 grass_block
execute in minecraft:overworld run fill 290 79 -29 290 144 -29 air
execute in minecraft:overworld run fill 290 58 -28 290 74 -28 stone
execute in minecraft:overworld run fill 290 75 -28 290 76 -28 dirt
execute in minecraft:overworld run setblock 290 77 -28 coarse_dirt
execute in minecraft:overworld run fill 290 78 -28 290 144 -28 air
execute in minecraft:overworld run fill 290 58 -27 290 74 -27 stone
execute in minecraft:overworld run fill 290 75 -27 290 76 -27 dirt
execute in minecraft:overworld run setblock 290 77 -27 coarse_dirt
execute in minecraft:overworld run fill 290 78 -27 290 144 -27 air
execute in minecraft:overworld run fill 290 58 -26 290 73 -26 stone
execute in minecraft:overworld run fill 290 74 -26 290 75 -26 dirt
execute in minecraft:overworld run setblock 290 76 -26 grass_block
execute in minecraft:overworld run fill 290 77 -26 290 144 -26 air
execute in minecraft:overworld run fill 290 58 -25 290 73 -25 stone
execute in minecraft:overworld run fill 290 74 -25 290 75 -25 dirt
execute in minecraft:overworld run setblock 290 76 -25 grass_block
execute in minecraft:overworld run fill 290 77 -25 290 144 -25 air
execute in minecraft:overworld run fill 290 58 -24 290 73 -24 stone
execute in minecraft:overworld run fill 290 74 -24 290 75 -24 dirt
execute in minecraft:overworld run setblock 290 76 -24 coarse_dirt
execute in minecraft:overworld run fill 290 77 -24 290 144 -24 air
execute in minecraft:overworld run fill 290 58 -23 290 72 -23 stone
execute in minecraft:overworld run fill 290 73 -23 290 74 -23 dirt
execute in minecraft:overworld run setblock 290 75 -23 coarse_dirt
execute in minecraft:overworld run fill 290 76 -23 290 144 -23 air
execute in minecraft:overworld run fill 290 58 -22 290 72 -22 stone
execute in minecraft:overworld run fill 290 73 -22 290 74 -22 dirt
execute in minecraft:overworld run setblock 290 75 -22 grass_block
execute in minecraft:overworld run fill 290 76 -22 290 144 -22 air
execute in minecraft:overworld run fill 290 58 -21 290 72 -21 stone
execute in minecraft:overworld run fill 290 73 -21 290 74 -21 dirt
execute in minecraft:overworld run setblock 290 75 -21 grass_block
execute in minecraft:overworld run fill 290 76 -21 290 144 -21 air
execute in minecraft:overworld run fill 290 58 -20 290 71 -20 stone
schedule function blade_gallery:random/burned/part_130 1t replace
