execute in minecraft:overworld run fill 414 73 35 414 144 35 air
execute in minecraft:overworld run fill 414 58 36 414 69 36 stone
execute in minecraft:overworld run fill 414 70 36 414 71 36 dirt
execute in minecraft:overworld run setblock 414 72 36 grass_block
execute in minecraft:overworld run fill 414 73 36 414 144 36 air
execute in minecraft:overworld run fill 414 58 37 414 68 37 stone
execute in minecraft:overworld run fill 414 69 37 414 70 37 dirt
execute in minecraft:overworld run setblock 414 71 37 grass_block
execute in minecraft:overworld run fill 414 72 37 414 144 37 air
execute in minecraft:overworld run fill 414 58 38 414 68 38 stone
execute in minecraft:overworld run fill 414 69 38 414 70 38 dirt
execute in minecraft:overworld run setblock 414 71 38 coarse_dirt
execute in minecraft:overworld run fill 414 72 38 414 144 38 air
execute in minecraft:overworld run fill 414 58 39 414 67 39 stone
execute in minecraft:overworld run fill 414 68 39 414 69 39 dirt
execute in minecraft:overworld run setblock 414 70 39 coarse_dirt
execute in minecraft:overworld run fill 414 71 39 414 144 39 air
execute in minecraft:overworld run fill 414 58 40 414 66 40 stone
execute in minecraft:overworld run fill 414 67 40 414 68 40 dirt
execute in minecraft:overworld run setblock 414 69 40 grass_block
execute in minecraft:overworld run fill 414 70 40 414 144 40 air
execute in minecraft:overworld run fill 414 58 41 414 65 41 stone
execute in minecraft:overworld run fill 414 66 41 414 67 41 dirt
execute in minecraft:overworld run setblock 414 68 41 coarse_dirt
execute in minecraft:overworld run fill 414 69 41 414 144 41 air
execute in minecraft:overworld run fill 414 58 42 414 64 42 stone
execute in minecraft:overworld run fill 414 65 42 414 66 42 dirt
execute in minecraft:overworld run setblock 414 67 42 grass_block
execute in minecraft:overworld run fill 414 68 42 414 144 42 air
execute in minecraft:overworld run fill 414 58 43 414 64 43 stone
execute in minecraft:overworld run fill 414 65 43 414 66 43 dirt
execute in minecraft:overworld run setblock 414 67 43 grass_block
execute in minecraft:overworld run fill 414 68 43 414 144 43 air
execute in minecraft:overworld run fill 414 58 44 414 63 44 stone
execute in minecraft:overworld run fill 414 64 44 414 65 44 dirt
execute in minecraft:overworld run setblock 414 66 44 coarse_dirt
execute in minecraft:overworld run fill 414 67 44 414 144 44 air
execute in minecraft:overworld run fill 414 58 45 414 62 45 stone
execute in minecraft:overworld run fill 414 63 45 414 64 45 dirt
execute in minecraft:overworld run setblock 414 65 45 coarse_dirt
execute in minecraft:overworld run fill 414 66 45 414 144 45 air
execute in minecraft:overworld run fill 414 58 46 414 62 46 stone
execute in minecraft:overworld run fill 414 63 46 414 64 46 dirt
execute in minecraft:overworld run setblock 414 65 46 coarse_dirt
execute in minecraft:overworld run fill 414 66 46 414 144 46 air
execute in minecraft:overworld run fill 414 58 47 414 61 47 stone
execute in minecraft:overworld run fill 414 62 47 414 63 47 dirt
execute in minecraft:overworld run setblock 414 64 47 coarse_dirt
execute in minecraft:overworld run fill 414 65 47 414 144 47 air
execute in minecraft:overworld run fill 415 58 -48 415 61 -48 stone
execute in minecraft:overworld run fill 415 62 -48 415 63 -48 dirt
execute in minecraft:overworld run setblock 415 64 -48 grass_block
execute in minecraft:overworld run fill 415 65 -48 415 144 -48 air
execute in minecraft:overworld run fill 415 58 -47 415 63 -47 stone
execute in minecraft:overworld run fill 415 64 -47 415 65 -47 dirt
execute in minecraft:overworld run setblock 415 66 -47 coarse_dirt
execute in minecraft:overworld run fill 415 67 -47 415 144 -47 air
execute in minecraft:overworld run fill 415 58 -46 415 64 -46 stone
execute in minecraft:overworld run fill 415 65 -46 415 66 -46 dirt
execute in minecraft:overworld run setblock 415 67 -46 grass_block
execute in minecraft:overworld run fill 415 68 -46 415 144 -46 air
execute in minecraft:overworld run fill 415 58 -45 415 66 -45 stone
execute in minecraft:overworld run fill 415 67 -45 415 68 -45 dirt
execute in minecraft:overworld run setblock 415 69 -45 grass_block
execute in minecraft:overworld run fill 415 70 -45 415 144 -45 air
execute in minecraft:overworld run fill 415 58 -44 415 67 -44 stone
execute in minecraft:overworld run fill 415 68 -44 415 69 -44 dirt
execute in minecraft:overworld run setblock 415 70 -44 coarse_dirt
execute in minecraft:overworld run fill 415 71 -44 415 144 -44 air
execute in minecraft:overworld run fill 415 58 -43 415 69 -43 stone
execute in minecraft:overworld run fill 415 70 -43 415 71 -43 dirt
execute in minecraft:overworld run setblock 415 72 -43 coarse_dirt
execute in minecraft:overworld run fill 415 73 -43 415 144 -43 air
execute in minecraft:overworld run fill 415 58 -42 415 70 -42 stone
execute in minecraft:overworld run fill 415 71 -42 415 72 -42 dirt
execute in minecraft:overworld run setblock 415 73 -42 coarse_dirt
execute in minecraft:overworld run fill 415 74 -42 415 144 -42 air
execute in minecraft:overworld run fill 415 58 -41 415 71 -41 stone
execute in minecraft:overworld run fill 415 72 -41 415 73 -41 dirt
execute in minecraft:overworld run setblock 415 74 -41 coarse_dirt
execute in minecraft:overworld run fill 415 75 -41 415 144 -41 air
execute in minecraft:overworld run fill 415 58 -40 415 73 -40 stone
execute in minecraft:overworld run fill 415 74 -40 415 75 -40 dirt
execute in minecraft:overworld run setblock 415 76 -40 coarse_dirt
execute in minecraft:overworld run fill 415 77 -40 415 144 -40 air
execute in minecraft:overworld run fill 415 58 -39 415 74 -39 stone
execute in minecraft:overworld run fill 415 75 -39 415 76 -39 dirt
execute in minecraft:overworld run setblock 415 77 -39 coarse_dirt
execute in minecraft:overworld run fill 415 78 -39 415 144 -39 air
execute in minecraft:overworld run fill 415 58 -38 415 75 -38 stone
execute in minecraft:overworld run fill 415 76 -38 415 77 -38 dirt
execute in minecraft:overworld run setblock 415 78 -38 coarse_dirt
execute in minecraft:overworld run fill 415 79 -38 415 144 -38 air
execute in minecraft:overworld run fill 415 58 -37 415 75 -37 stone
execute in minecraft:overworld run fill 415 76 -37 415 77 -37 dirt
execute in minecraft:overworld run setblock 415 78 -37 coarse_dirt
execute in minecraft:overworld run fill 415 79 -37 415 144 -37 air
execute in minecraft:overworld run fill 415 58 -36 415 74 -36 stone
execute in minecraft:overworld run fill 415 75 -36 415 76 -36 dirt
execute in minecraft:overworld run setblock 415 77 -36 coarse_dirt
execute in minecraft:overworld run fill 415 78 -36 415 144 -36 air
execute in minecraft:overworld run fill 415 58 -35 415 74 -35 stone
execute in minecraft:overworld run fill 415 75 -35 415 76 -35 dirt
execute in minecraft:overworld run setblock 415 77 -35 coarse_dirt
execute in minecraft:overworld run fill 415 78 -35 415 144 -35 air
execute in minecraft:overworld run fill 415 58 -34 415 73 -34 stone
execute in minecraft:overworld run fill 415 74 -34 415 75 -34 dirt
execute in minecraft:overworld run setblock 415 76 -34 coarse_dirt
execute in minecraft:overworld run fill 415 77 -34 415 144 -34 air
execute in minecraft:overworld run fill 415 58 -33 415 73 -33 stone
execute in minecraft:overworld run fill 415 74 -33 415 75 -33 dirt
execute in minecraft:overworld run setblock 415 76 -33 coarse_dirt
execute in minecraft:overworld run fill 415 77 -33 415 144 -33 air
execute in minecraft:overworld run fill 415 58 -32 415 72 -32 stone
execute in minecraft:overworld run fill 415 73 -32 415 74 -32 dirt
execute in minecraft:overworld run setblock 415 75 -32 coarse_dirt
execute in minecraft:overworld run fill 415 76 -32 415 144 -32 air
execute in minecraft:overworld run fill 415 58 -31 415 72 -31 stone
execute in minecraft:overworld run fill 415 73 -31 415 74 -31 dirt
execute in minecraft:overworld run setblock 415 75 -31 coarse_dirt
execute in minecraft:overworld run fill 415 76 -31 415 144 -31 air
execute in minecraft:overworld run fill 415 58 -30 415 72 -30 stone
execute in minecraft:overworld run fill 415 73 -30 415 74 -30 dirt
execute in minecraft:overworld run setblock 415 75 -30 coarse_dirt
execute in minecraft:overworld run fill 415 76 -30 415 144 -30 air
execute in minecraft:overworld run fill 415 58 -29 415 71 -29 stone
execute in minecraft:overworld run fill 415 72 -29 415 73 -29 dirt
execute in minecraft:overworld run setblock 415 74 -29 coarse_dirt
execute in minecraft:overworld run fill 415 75 -29 415 144 -29 air
execute in minecraft:overworld run setblock 415 75 -29 grass
execute in minecraft:overworld run fill 415 58 -28 415 71 -28 stone
execute in minecraft:overworld run fill 415 72 -28 415 73 -28 dirt
execute in minecraft:overworld run setblock 415 74 -28 grass_block
execute in minecraft:overworld run fill 415 75 -28 415 144 -28 air
execute in minecraft:overworld run fill 415 58 -27 415 70 -27 stone
execute in minecraft:overworld run fill 415 71 -27 415 72 -27 dirt
execute in minecraft:overworld run setblock 415 73 -27 grass_block
execute in minecraft:overworld run fill 415 74 -27 415 144 -27 air
execute in minecraft:overworld run setblock 415 74 -27 grass
execute in minecraft:overworld run fill 415 58 -26 415 70 -26 stone
execute in minecraft:overworld run fill 415 71 -26 415 72 -26 dirt
execute in minecraft:overworld run setblock 415 73 -26 coarse_dirt
execute in minecraft:overworld run fill 415 74 -26 415 144 -26 air
execute in minecraft:overworld run fill 415 58 -25 415 70 -25 stone
execute in minecraft:overworld run fill 415 71 -25 415 72 -25 dirt
execute in minecraft:overworld run setblock 415 73 -25 grass_block
execute in minecraft:overworld run fill 415 74 -25 415 144 -25 air
execute in minecraft:overworld run fill 415 58 -24 415 70 -24 stone
execute in minecraft:overworld run fill 415 71 -24 415 72 -24 dirt
execute in minecraft:overworld run setblock 415 73 -24 grass_block
execute in minecraft:overworld run fill 415 74 -24 415 144 -24 air
execute in minecraft:overworld run fill 415 58 -23 415 69 -23 stone
execute in minecraft:overworld run fill 415 70 -23 415 71 -23 dirt
execute in minecraft:overworld run setblock 415 72 -23 coarse_dirt
execute in minecraft:overworld run fill 415 73 -23 415 144 -23 air
execute in minecraft:overworld run fill 415 58 -22 415 69 -22 stone
execute in minecraft:overworld run fill 415 70 -22 415 71 -22 dirt
execute in minecraft:overworld run setblock 415 72 -22 coarse_dirt
execute in minecraft:overworld run fill 415 73 -22 415 144 -22 air
execute in minecraft:overworld run fill 415 58 -21 415 69 -21 stone
execute in minecraft:overworld run fill 415 70 -21 415 71 -21 dirt
execute in minecraft:overworld run setblock 415 72 -21 coarse_dirt
execute in minecraft:overworld run fill 415 73 -21 415 144 -21 air
execute in minecraft:overworld run fill 415 58 -20 415 69 -20 stone
execute in minecraft:overworld run fill 415 70 -20 415 71 -20 dirt
execute in minecraft:overworld run setblock 415 72 -20 coarse_dirt
execute in minecraft:overworld run fill 415 73 -20 415 144 -20 air
execute in minecraft:overworld run fill 415 58 -19 415 68 -19 stone
execute in minecraft:overworld run fill 415 69 -19 415 70 -19 dirt
execute in minecraft:overworld run setblock 415 71 -19 grass_block
execute in minecraft:overworld run fill 415 72 -19 415 144 -19 air
execute in minecraft:overworld run fill 415 58 -18 415 68 -18 stone
execute in minecraft:overworld run fill 415 69 -18 415 70 -18 dirt
execute in minecraft:overworld run setblock 415 71 -18 grass_block
execute in minecraft:overworld run fill 415 72 -18 415 144 -18 air
execute in minecraft:overworld run fill 415 58 -17 415 67 -17 stone
execute in minecraft:overworld run fill 415 68 -17 415 69 -17 dirt
execute in minecraft:overworld run setblock 415 70 -17 grass_block
execute in minecraft:overworld run fill 415 71 -17 415 144 -17 air
execute in minecraft:overworld run fill 415 58 -16 415 67 -16 stone
execute in minecraft:overworld run fill 415 68 -16 415 69 -16 dirt
execute in minecraft:overworld run setblock 415 70 -16 coarse_dirt
execute in minecraft:overworld run fill 415 71 -16 415 144 -16 air
execute in minecraft:overworld run fill 415 58 -15 415 66 -15 stone
execute in minecraft:overworld run fill 415 67 -15 415 68 -15 dirt
execute in minecraft:overworld run setblock 415 69 -15 coarse_dirt
execute in minecraft:overworld run fill 415 70 -15 415 144 -15 air
execute in minecraft:overworld run fill 415 58 -14 415 66 -14 stone
execute in minecraft:overworld run fill 415 67 -14 415 68 -14 dirt
execute in minecraft:overworld run setblock 415 69 -14 grass_block
execute in minecraft:overworld run fill 415 70 -14 415 144 -14 air
execute in minecraft:overworld run fill 415 58 -13 415 65 -13 stone
execute in minecraft:overworld run fill 415 66 -13 415 67 -13 dirt
execute in minecraft:overworld run setblock 415 68 -13 coarse_dirt
execute in minecraft:overworld run fill 415 69 -13 415 144 -13 air
execute in minecraft:overworld run fill 415 58 -12 415 65 -12 stone
execute in minecraft:overworld run fill 415 66 -12 415 67 -12 dirt
execute in minecraft:overworld run setblock 415 68 -12 coarse_dirt
execute in minecraft:overworld run fill 415 69 -12 415 144 -12 air
execute in minecraft:overworld run fill 415 58 -11 415 65 -11 stone
execute in minecraft:overworld run fill 415 66 -11 415 67 -11 dirt
execute in minecraft:overworld run setblock 415 68 -11 coarse_dirt
execute in minecraft:overworld run fill 415 69 -11 415 144 -11 air
execute in minecraft:overworld run fill 415 58 -10 415 65 -10 stone
execute in minecraft:overworld run fill 415 66 -10 415 67 -10 dirt
execute in minecraft:overworld run setblock 415 68 -10 grass_block
execute in minecraft:overworld run fill 415 69 -10 415 144 -10 air
execute in minecraft:overworld run fill 415 58 -9 415 65 -9 stone
execute in minecraft:overworld run fill 415 66 -9 415 67 -9 dirt
execute in minecraft:overworld run setblock 415 68 -9 coarse_dirt
execute in minecraft:overworld run fill 415 69 -9 415 144 -9 air
execute in minecraft:overworld run fill 415 58 -8 415 64 -8 stone
execute in minecraft:overworld run fill 415 65 -8 415 66 -8 dirt
execute in minecraft:overworld run setblock 415 67 -8 coarse_dirt
execute in minecraft:overworld run fill 415 68 -8 415 144 -8 air
execute in minecraft:overworld run setblock 415 68 -8 grass
execute in minecraft:overworld run fill 415 58 -7 415 64 -7 stone
execute in minecraft:overworld run fill 415 65 -7 415 66 -7 dirt
execute in minecraft:overworld run setblock 415 67 -7 grass_block
execute in minecraft:overworld run fill 415 68 -7 415 144 -7 air
execute in minecraft:overworld run fill 415 58 -6 415 64 -6 stone
execute in minecraft:overworld run fill 415 65 -6 415 66 -6 dirt
execute in minecraft:overworld run setblock 415 67 -6 grass_block
execute in minecraft:overworld run fill 415 68 -6 415 144 -6 air
execute in minecraft:overworld run setblock 415 68 -6 mossy_cobblestone
execute in minecraft:overworld run fill 415 58 -5 415 64 -5 stone
execute in minecraft:overworld run fill 415 65 -5 415 66 -5 dirt
execute in minecraft:overworld run setblock 415 67 -5 coarse_dirt
execute in minecraft:overworld run fill 415 68 -5 415 144 -5 air
execute in minecraft:overworld run fill 415 58 -4 415 63 -4 stone
execute in minecraft:overworld run fill 415 64 -4 415 65 -4 dirt
execute in minecraft:overworld run setblock 415 66 -4 coarse_dirt
execute in minecraft:overworld run fill 415 67 -4 415 144 -4 air
execute in minecraft:overworld run fill 415 58 -3 415 63 -3 stone
execute in minecraft:overworld run fill 415 64 -3 415 65 -3 dirt
execute in minecraft:overworld run setblock 415 66 -3 coarse_dirt
execute in minecraft:overworld run fill 415 67 -3 415 144 -3 air
execute in minecraft:overworld run fill 415 58 -2 415 63 -2 stone
execute in minecraft:overworld run fill 415 64 -2 415 65 -2 dirt
execute in minecraft:overworld run setblock 415 66 -2 grass_block
execute in minecraft:overworld run fill 415 67 -2 415 144 -2 air
execute in minecraft:overworld run fill 415 58 -1 415 63 -1 stone
execute in minecraft:overworld run fill 415 64 -1 415 65 -1 dirt
execute in minecraft:overworld run setblock 415 66 -1 coarse_dirt
execute in minecraft:overworld run fill 415 67 -1 415 144 -1 air
execute in minecraft:overworld run fill 415 58 0 415 63 0 stone
execute in minecraft:overworld run fill 415 64 0 415 65 0 dirt
execute in minecraft:overworld run setblock 415 66 0 coarse_dirt
execute in minecraft:overworld run fill 415 67 0 415 144 0 air
execute in minecraft:overworld run fill 415 58 1 415 63 1 stone
execute in minecraft:overworld run fill 415 64 1 415 65 1 dirt
execute in minecraft:overworld run setblock 415 66 1 grass_block
execute in minecraft:overworld run fill 415 67 1 415 144 1 air
execute in minecraft:overworld run fill 415 58 2 415 63 2 stone
execute in minecraft:overworld run fill 415 64 2 415 65 2 dirt
execute in minecraft:overworld run setblock 415 66 2 coarse_dirt
schedule function blade_gallery:random/battlefield/part_125 1t replace
