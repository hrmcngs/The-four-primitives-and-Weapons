execute in minecraft:overworld run fill 427 69 38 427 144 38 air
execute in minecraft:overworld run fill 427 58 39 427 64 39 stone
execute in minecraft:overworld run fill 427 65 39 427 66 39 dirt
execute in minecraft:overworld run setblock 427 67 39 grass_block
execute in minecraft:overworld run fill 427 68 39 427 144 39 air
execute in minecraft:overworld run fill 427 58 40 427 64 40 stone
execute in minecraft:overworld run fill 427 65 40 427 66 40 dirt
execute in minecraft:overworld run setblock 427 67 40 coarse_dirt
execute in minecraft:overworld run fill 427 68 40 427 144 40 air
execute in minecraft:overworld run fill 427 58 41 427 64 41 stone
execute in minecraft:overworld run fill 427 65 41 427 66 41 dirt
execute in minecraft:overworld run setblock 427 67 41 coarse_dirt
execute in minecraft:overworld run fill 427 68 41 427 144 41 air
execute in minecraft:overworld run fill 427 58 42 427 63 42 stone
execute in minecraft:overworld run fill 427 64 42 427 65 42 dirt
execute in minecraft:overworld run setblock 427 66 42 coarse_dirt
execute in minecraft:overworld run fill 427 67 42 427 144 42 air
execute in minecraft:overworld run fill 427 58 43 427 63 43 stone
execute in minecraft:overworld run fill 427 64 43 427 65 43 dirt
execute in minecraft:overworld run setblock 427 66 43 coarse_dirt
execute in minecraft:overworld run fill 427 67 43 427 144 43 air
execute in minecraft:overworld run fill 427 58 44 427 62 44 stone
execute in minecraft:overworld run fill 427 63 44 427 64 44 dirt
execute in minecraft:overworld run setblock 427 65 44 grass_block
execute in minecraft:overworld run fill 427 66 44 427 144 44 air
execute in minecraft:overworld run fill 427 58 45 427 62 45 stone
execute in minecraft:overworld run fill 427 63 45 427 64 45 dirt
execute in minecraft:overworld run setblock 427 65 45 grass_block
execute in minecraft:overworld run fill 427 66 45 427 144 45 air
execute in minecraft:overworld run fill 427 58 46 427 61 46 stone
execute in minecraft:overworld run fill 427 62 46 427 63 46 dirt
execute in minecraft:overworld run setblock 427 64 46 coarse_dirt
execute in minecraft:overworld run fill 427 65 46 427 144 46 air
execute in minecraft:overworld run fill 427 58 47 427 61 47 stone
execute in minecraft:overworld run fill 427 62 47 427 63 47 dirt
execute in minecraft:overworld run setblock 427 64 47 coarse_dirt
execute in minecraft:overworld run fill 427 65 47 427 144 47 air
execute in minecraft:overworld run fill 428 58 -48 428 61 -48 stone
execute in minecraft:overworld run fill 428 62 -48 428 63 -48 dirt
execute in minecraft:overworld run setblock 428 64 -48 grass_block
execute in minecraft:overworld run fill 428 65 -48 428 144 -48 air
execute in minecraft:overworld run fill 428 58 -47 428 63 -47 stone
execute in minecraft:overworld run fill 428 64 -47 428 65 -47 dirt
execute in minecraft:overworld run setblock 428 66 -47 coarse_dirt
execute in minecraft:overworld run fill 428 67 -47 428 144 -47 air
execute in minecraft:overworld run fill 428 58 -46 428 64 -46 stone
execute in minecraft:overworld run fill 428 65 -46 428 66 -46 dirt
execute in minecraft:overworld run setblock 428 67 -46 coarse_dirt
execute in minecraft:overworld run fill 428 68 -46 428 144 -46 air
execute in minecraft:overworld run fill 428 58 -45 428 66 -45 stone
execute in minecraft:overworld run fill 428 67 -45 428 68 -45 dirt
execute in minecraft:overworld run setblock 428 69 -45 coarse_dirt
execute in minecraft:overworld run fill 428 70 -45 428 144 -45 air
execute in minecraft:overworld run fill 428 58 -44 428 68 -44 stone
execute in minecraft:overworld run fill 428 69 -44 428 70 -44 dirt
execute in minecraft:overworld run setblock 428 71 -44 coarse_dirt
execute in minecraft:overworld run fill 428 72 -44 428 144 -44 air
execute in minecraft:overworld run fill 428 58 -43 428 67 -43 stone
execute in minecraft:overworld run fill 428 68 -43 428 69 -43 dirt
execute in minecraft:overworld run setblock 428 70 -43 grass_block
execute in minecraft:overworld run fill 428 71 -43 428 144 -43 air
execute in minecraft:overworld run fill 428 58 -42 428 67 -42 stone
execute in minecraft:overworld run fill 428 68 -42 428 69 -42 dirt
execute in minecraft:overworld run setblock 428 70 -42 coarse_dirt
execute in minecraft:overworld run fill 428 71 -42 428 144 -42 air
execute in minecraft:overworld run fill 428 58 -41 428 67 -41 stone
execute in minecraft:overworld run fill 428 68 -41 428 69 -41 dirt
execute in minecraft:overworld run setblock 428 70 -41 grass_block
execute in minecraft:overworld run fill 428 71 -41 428 144 -41 air
execute in minecraft:overworld run fill 428 58 -40 428 67 -40 stone
execute in minecraft:overworld run fill 428 68 -40 428 69 -40 dirt
execute in minecraft:overworld run setblock 428 70 -40 coarse_dirt
execute in minecraft:overworld run fill 428 71 -40 428 144 -40 air
execute in minecraft:overworld run fill 428 58 -39 428 67 -39 stone
execute in minecraft:overworld run fill 428 68 -39 428 69 -39 dirt
execute in minecraft:overworld run setblock 428 70 -39 grass_block
execute in minecraft:overworld run fill 428 71 -39 428 144 -39 air
execute in minecraft:overworld run fill 428 58 -38 428 67 -38 stone
execute in minecraft:overworld run fill 428 68 -38 428 69 -38 dirt
execute in minecraft:overworld run setblock 428 70 -38 grass_block
execute in minecraft:overworld run fill 428 71 -38 428 144 -38 air
execute in minecraft:overworld run fill 428 58 -37 428 67 -37 stone
execute in minecraft:overworld run fill 428 68 -37 428 69 -37 dirt
execute in minecraft:overworld run setblock 428 70 -37 coarse_dirt
execute in minecraft:overworld run fill 428 71 -37 428 144 -37 air
execute in minecraft:overworld run fill 428 58 -36 428 67 -36 stone
execute in minecraft:overworld run fill 428 68 -36 428 69 -36 dirt
execute in minecraft:overworld run setblock 428 70 -36 coarse_dirt
execute in minecraft:overworld run fill 428 71 -36 428 144 -36 air
execute in minecraft:overworld run fill 428 58 -35 428 67 -35 stone
execute in minecraft:overworld run fill 428 68 -35 428 69 -35 dirt
execute in minecraft:overworld run setblock 428 70 -35 grass_block
execute in minecraft:overworld run fill 428 71 -35 428 144 -35 air
execute in minecraft:overworld run fill 428 58 -34 428 66 -34 stone
execute in minecraft:overworld run fill 428 67 -34 428 68 -34 dirt
execute in minecraft:overworld run setblock 428 69 -34 coarse_dirt
execute in minecraft:overworld run fill 428 70 -34 428 144 -34 air
execute in minecraft:overworld run fill 428 58 -33 428 66 -33 stone
execute in minecraft:overworld run fill 428 67 -33 428 68 -33 dirt
execute in minecraft:overworld run setblock 428 69 -33 grass_block
execute in minecraft:overworld run fill 428 70 -33 428 144 -33 air
execute in minecraft:overworld run fill 428 58 -32 428 66 -32 stone
execute in minecraft:overworld run fill 428 67 -32 428 68 -32 dirt
execute in minecraft:overworld run setblock 428 69 -32 coarse_dirt
execute in minecraft:overworld run fill 428 70 -32 428 144 -32 air
execute in minecraft:overworld run fill 428 58 -31 428 66 -31 stone
execute in minecraft:overworld run fill 428 67 -31 428 68 -31 dirt
execute in minecraft:overworld run setblock 428 69 -31 grass_block
execute in minecraft:overworld run fill 428 70 -31 428 144 -31 air
execute in minecraft:overworld run fill 428 58 -30 428 65 -30 stone
execute in minecraft:overworld run fill 428 66 -30 428 67 -30 dirt
execute in minecraft:overworld run setblock 428 68 -30 grass_block
execute in minecraft:overworld run fill 428 69 -30 428 144 -30 air
execute in minecraft:overworld run fill 428 58 -29 428 65 -29 stone
execute in minecraft:overworld run fill 428 66 -29 428 67 -29 dirt
execute in minecraft:overworld run setblock 428 68 -29 coarse_dirt
execute in minecraft:overworld run fill 428 69 -29 428 144 -29 air
execute in minecraft:overworld run fill 428 58 -28 428 65 -28 stone
execute in minecraft:overworld run fill 428 66 -28 428 67 -28 dirt
execute in minecraft:overworld run setblock 428 68 -28 grass_block
execute in minecraft:overworld run fill 428 69 -28 428 144 -28 air
execute in minecraft:overworld run fill 428 58 -27 428 65 -27 stone
execute in minecraft:overworld run fill 428 66 -27 428 67 -27 dirt
execute in minecraft:overworld run setblock 428 68 -27 coarse_dirt
execute in minecraft:overworld run fill 428 69 -27 428 144 -27 air
execute in minecraft:overworld run fill 428 58 -26 428 65 -26 stone
execute in minecraft:overworld run fill 428 66 -26 428 67 -26 dirt
execute in minecraft:overworld run setblock 428 68 -26 coarse_dirt
execute in minecraft:overworld run fill 428 69 -26 428 144 -26 air
execute in minecraft:overworld run fill 428 58 -25 428 64 -25 stone
execute in minecraft:overworld run fill 428 65 -25 428 66 -25 dirt
execute in minecraft:overworld run setblock 428 67 -25 coarse_dirt
execute in minecraft:overworld run fill 428 68 -25 428 144 -25 air
execute in minecraft:overworld run fill 428 58 -24 428 64 -24 stone
execute in minecraft:overworld run fill 428 65 -24 428 66 -24 dirt
execute in minecraft:overworld run setblock 428 67 -24 coarse_dirt
execute in minecraft:overworld run fill 428 68 -24 428 144 -24 air
execute in minecraft:overworld run fill 428 58 -23 428 64 -23 stone
execute in minecraft:overworld run fill 428 65 -23 428 66 -23 dirt
execute in minecraft:overworld run setblock 428 67 -23 coarse_dirt
execute in minecraft:overworld run fill 428 68 -23 428 144 -23 air
execute in minecraft:overworld run fill 428 58 -22 428 64 -22 stone
execute in minecraft:overworld run fill 428 65 -22 428 66 -22 dirt
execute in minecraft:overworld run setblock 428 67 -22 coarse_dirt
execute in minecraft:overworld run fill 428 68 -22 428 144 -22 air
execute in minecraft:overworld run fill 428 58 -21 428 64 -21 stone
execute in minecraft:overworld run fill 428 65 -21 428 66 -21 dirt
execute in minecraft:overworld run setblock 428 67 -21 grass_block
execute in minecraft:overworld run fill 428 68 -21 428 144 -21 air
execute in minecraft:overworld run fill 428 58 -20 428 64 -20 stone
execute in minecraft:overworld run fill 428 65 -20 428 66 -20 dirt
execute in minecraft:overworld run setblock 428 67 -20 grass_block
execute in minecraft:overworld run fill 428 68 -20 428 144 -20 air
execute in minecraft:overworld run fill 428 58 -19 428 64 -19 stone
execute in minecraft:overworld run fill 428 65 -19 428 66 -19 dirt
execute in minecraft:overworld run setblock 428 67 -19 coarse_dirt
execute in minecraft:overworld run fill 428 68 -19 428 144 -19 air
execute in minecraft:overworld run fill 428 58 -18 428 64 -18 stone
execute in minecraft:overworld run fill 428 65 -18 428 66 -18 dirt
execute in minecraft:overworld run setblock 428 67 -18 coarse_dirt
execute in minecraft:overworld run fill 428 68 -18 428 144 -18 air
execute in minecraft:overworld run fill 428 58 -17 428 63 -17 stone
execute in minecraft:overworld run fill 428 64 -17 428 65 -17 dirt
execute in minecraft:overworld run setblock 428 66 -17 coarse_dirt
execute in minecraft:overworld run fill 428 67 -17 428 144 -17 air
execute in minecraft:overworld run fill 428 58 -16 428 63 -16 stone
execute in minecraft:overworld run fill 428 64 -16 428 65 -16 dirt
execute in minecraft:overworld run setblock 428 66 -16 coarse_dirt
execute in minecraft:overworld run fill 428 67 -16 428 144 -16 air
execute in minecraft:overworld run fill 428 58 -15 428 63 -15 stone
execute in minecraft:overworld run fill 428 64 -15 428 65 -15 dirt
execute in minecraft:overworld run setblock 428 66 -15 coarse_dirt
execute in minecraft:overworld run fill 428 67 -15 428 144 -15 air
execute in minecraft:overworld run fill 428 58 -14 428 63 -14 stone
execute in minecraft:overworld run fill 428 64 -14 428 65 -14 dirt
execute in minecraft:overworld run setblock 428 66 -14 coarse_dirt
execute in minecraft:overworld run fill 428 67 -14 428 144 -14 air
execute in minecraft:overworld run fill 428 58 -13 428 63 -13 stone
execute in minecraft:overworld run fill 428 64 -13 428 65 -13 dirt
execute in minecraft:overworld run setblock 428 66 -13 grass_block
execute in minecraft:overworld run fill 428 67 -13 428 144 -13 air
execute in minecraft:overworld run fill 428 58 -12 428 63 -12 stone
execute in minecraft:overworld run fill 428 64 -12 428 65 -12 dirt
execute in minecraft:overworld run setblock 428 66 -12 grass_block
execute in minecraft:overworld run fill 428 67 -12 428 144 -12 air
execute in minecraft:overworld run fill 428 58 -11 428 63 -11 stone
execute in minecraft:overworld run fill 428 64 -11 428 65 -11 dirt
execute in minecraft:overworld run setblock 428 66 -11 coarse_dirt
execute in minecraft:overworld run fill 428 67 -11 428 144 -11 air
execute in minecraft:overworld run fill 428 58 -10 428 63 -10 stone
execute in minecraft:overworld run fill 428 64 -10 428 65 -10 dirt
execute in minecraft:overworld run setblock 428 66 -10 coarse_dirt
execute in minecraft:overworld run fill 428 67 -10 428 144 -10 air
execute in minecraft:overworld run fill 428 58 -9 428 63 -9 stone
execute in minecraft:overworld run fill 428 64 -9 428 65 -9 dirt
execute in minecraft:overworld run setblock 428 66 -9 grass_block
execute in minecraft:overworld run fill 428 67 -9 428 144 -9 air
execute in minecraft:overworld run fill 428 58 -8 428 63 -8 stone
execute in minecraft:overworld run fill 428 64 -8 428 65 -8 dirt
execute in minecraft:overworld run setblock 428 66 -8 coarse_dirt
execute in minecraft:overworld run fill 428 67 -8 428 144 -8 air
execute in minecraft:overworld run fill 428 58 -7 428 63 -7 stone
execute in minecraft:overworld run fill 428 64 -7 428 65 -7 dirt
execute in minecraft:overworld run setblock 428 66 -7 coarse_dirt
execute in minecraft:overworld run fill 428 67 -7 428 144 -7 air
execute in minecraft:overworld run fill 428 58 -6 428 63 -6 stone
execute in minecraft:overworld run fill 428 64 -6 428 65 -6 dirt
execute in minecraft:overworld run setblock 428 66 -6 grass_block
execute in minecraft:overworld run fill 428 67 -6 428 144 -6 air
execute in minecraft:overworld run fill 428 58 -5 428 63 -5 stone
execute in minecraft:overworld run fill 428 64 -5 428 65 -5 dirt
execute in minecraft:overworld run setblock 428 66 -5 coarse_dirt
execute in minecraft:overworld run fill 428 67 -5 428 144 -5 air
execute in minecraft:overworld run fill 428 58 -4 428 63 -4 stone
execute in minecraft:overworld run fill 428 64 -4 428 65 -4 dirt
execute in minecraft:overworld run setblock 428 66 -4 coarse_dirt
execute in minecraft:overworld run fill 428 67 -4 428 144 -4 air
execute in minecraft:overworld run fill 428 58 -3 428 63 -3 stone
execute in minecraft:overworld run fill 428 64 -3 428 65 -3 dirt
execute in minecraft:overworld run setblock 428 66 -3 grass_block
execute in minecraft:overworld run fill 428 67 -3 428 144 -3 air
execute in minecraft:overworld run fill 428 58 -2 428 62 -2 stone
execute in minecraft:overworld run fill 428 63 -2 428 64 -2 dirt
execute in minecraft:overworld run setblock 428 65 -2 grass_block
execute in minecraft:overworld run fill 428 66 -2 428 144 -2 air
execute in minecraft:overworld run fill 428 58 -1 428 62 -1 stone
execute in minecraft:overworld run fill 428 63 -1 428 64 -1 dirt
execute in minecraft:overworld run setblock 428 65 -1 coarse_dirt
execute in minecraft:overworld run fill 428 66 -1 428 144 -1 air
execute in minecraft:overworld run fill 428 58 0 428 62 0 stone
execute in minecraft:overworld run fill 428 63 0 428 64 0 dirt
execute in minecraft:overworld run setblock 428 65 0 coarse_dirt
execute in minecraft:overworld run fill 428 66 0 428 144 0 air
execute in minecraft:overworld run fill 428 58 1 428 62 1 stone
execute in minecraft:overworld run fill 428 63 1 428 64 1 dirt
execute in minecraft:overworld run setblock 428 65 1 grass_block
execute in minecraft:overworld run fill 428 66 1 428 144 1 air
execute in minecraft:overworld run fill 428 58 2 428 62 2 stone
execute in minecraft:overworld run fill 428 63 2 428 64 2 dirt
execute in minecraft:overworld run setblock 428 65 2 grass_block
execute in minecraft:overworld run fill 428 66 2 428 144 2 air
execute in minecraft:overworld run fill 428 58 3 428 63 3 stone
execute in minecraft:overworld run fill 428 64 3 428 65 3 dirt
execute in minecraft:overworld run setblock 428 66 3 coarse_dirt
execute in minecraft:overworld run fill 428 67 3 428 144 3 air
execute in minecraft:overworld run fill 428 58 4 428 63 4 stone
execute in minecraft:overworld run fill 428 64 4 428 65 4 dirt
execute in minecraft:overworld run setblock 428 66 4 grass_block
execute in minecraft:overworld run fill 428 67 4 428 144 4 air
execute in minecraft:overworld run fill 428 58 5 428 63 5 stone
execute in minecraft:overworld run fill 428 64 5 428 65 5 dirt
execute in minecraft:overworld run setblock 428 66 5 grass_block
execute in minecraft:overworld run fill 428 67 5 428 144 5 air
execute in minecraft:overworld run fill 428 58 6 428 63 6 stone
execute in minecraft:overworld run fill 428 64 6 428 65 6 dirt
execute in minecraft:overworld run setblock 428 66 6 coarse_dirt
schedule function blade_gallery:random/battlefield/part_145 1t replace
