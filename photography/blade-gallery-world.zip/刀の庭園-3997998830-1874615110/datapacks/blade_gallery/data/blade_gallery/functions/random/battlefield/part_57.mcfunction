execute in minecraft:overworld run fill 373 72 -31 373 144 -31 air
execute in minecraft:overworld run fill 373 58 -30 373 68 -30 stone
execute in minecraft:overworld run fill 373 69 -30 373 70 -30 dirt
execute in minecraft:overworld run setblock 373 71 -30 coarse_dirt
execute in minecraft:overworld run fill 373 72 -30 373 144 -30 air
execute in minecraft:overworld run fill 373 58 -29 373 68 -29 stone
execute in minecraft:overworld run fill 373 69 -29 373 70 -29 dirt
execute in minecraft:overworld run setblock 373 71 -29 coarse_dirt
execute in minecraft:overworld run fill 373 72 -29 373 144 -29 air
execute in minecraft:overworld run fill 373 58 -28 373 69 -28 stone
execute in minecraft:overworld run fill 373 70 -28 373 71 -28 dirt
execute in minecraft:overworld run setblock 373 72 -28 coarse_dirt
execute in minecraft:overworld run fill 373 73 -28 373 144 -28 air
execute in minecraft:overworld run fill 373 58 -27 373 69 -27 stone
execute in minecraft:overworld run fill 373 70 -27 373 71 -27 dirt
execute in minecraft:overworld run setblock 373 72 -27 coarse_dirt
execute in minecraft:overworld run fill 373 73 -27 373 144 -27 air
execute in minecraft:overworld run fill 373 58 -26 373 69 -26 stone
execute in minecraft:overworld run fill 373 70 -26 373 71 -26 dirt
execute in minecraft:overworld run setblock 373 72 -26 grass_block
execute in minecraft:overworld run fill 373 73 -26 373 144 -26 air
execute in minecraft:overworld run fill 373 58 -25 373 69 -25 stone
execute in minecraft:overworld run fill 373 70 -25 373 71 -25 dirt
execute in minecraft:overworld run setblock 373 72 -25 coarse_dirt
execute in minecraft:overworld run fill 373 73 -25 373 144 -25 air
execute in minecraft:overworld run fill 373 58 -24 373 68 -24 stone
execute in minecraft:overworld run fill 373 69 -24 373 70 -24 dirt
execute in minecraft:overworld run setblock 373 71 -24 coarse_dirt
execute in minecraft:overworld run fill 373 72 -24 373 144 -24 air
execute in minecraft:overworld run fill 373 58 -23 373 68 -23 stone
execute in minecraft:overworld run fill 373 69 -23 373 70 -23 dirt
execute in minecraft:overworld run setblock 373 71 -23 coarse_dirt
execute in minecraft:overworld run fill 373 72 -23 373 144 -23 air
execute in minecraft:overworld run fill 373 58 -22 373 68 -22 stone
execute in minecraft:overworld run fill 373 69 -22 373 70 -22 dirt
execute in minecraft:overworld run setblock 373 71 -22 coarse_dirt
execute in minecraft:overworld run fill 373 72 -22 373 144 -22 air
execute in minecraft:overworld run fill 373 58 -21 373 67 -21 stone
execute in minecraft:overworld run fill 373 68 -21 373 69 -21 dirt
execute in minecraft:overworld run setblock 373 70 -21 coarse_dirt
execute in minecraft:overworld run fill 373 71 -21 373 144 -21 air
execute in minecraft:overworld run fill 373 58 -20 373 67 -20 stone
execute in minecraft:overworld run fill 373 68 -20 373 69 -20 dirt
execute in minecraft:overworld run setblock 373 70 -20 coarse_dirt
execute in minecraft:overworld run fill 373 71 -20 373 144 -20 air
execute in minecraft:overworld run fill 373 58 -19 373 67 -19 stone
execute in minecraft:overworld run fill 373 68 -19 373 69 -19 dirt
execute in minecraft:overworld run setblock 373 70 -19 grass_block
execute in minecraft:overworld run fill 373 71 -19 373 144 -19 air
execute in minecraft:overworld run fill 373 58 -18 373 67 -18 stone
execute in minecraft:overworld run fill 373 68 -18 373 69 -18 dirt
execute in minecraft:overworld run setblock 373 70 -18 coarse_dirt
execute in minecraft:overworld run fill 373 71 -18 373 144 -18 air
execute in minecraft:overworld run fill 373 58 -17 373 66 -17 stone
execute in minecraft:overworld run fill 373 67 -17 373 68 -17 dirt
execute in minecraft:overworld run setblock 373 69 -17 coarse_dirt
execute in minecraft:overworld run fill 373 70 -17 373 144 -17 air
execute in minecraft:overworld run fill 373 58 -16 373 66 -16 stone
execute in minecraft:overworld run fill 373 67 -16 373 68 -16 dirt
execute in minecraft:overworld run setblock 373 69 -16 grass_block
execute in minecraft:overworld run fill 373 70 -16 373 144 -16 air
execute in minecraft:overworld run fill 373 58 -15 373 66 -15 stone
execute in minecraft:overworld run fill 373 67 -15 373 68 -15 dirt
execute in minecraft:overworld run setblock 373 69 -15 grass_block
execute in minecraft:overworld run fill 373 70 -15 373 144 -15 air
execute in minecraft:overworld run fill 373 58 -14 373 66 -14 stone
execute in minecraft:overworld run fill 373 67 -14 373 68 -14 dirt
execute in minecraft:overworld run setblock 373 69 -14 grass_block
execute in minecraft:overworld run fill 373 70 -14 373 144 -14 air
execute in minecraft:overworld run fill 373 58 -13 373 65 -13 stone
execute in minecraft:overworld run fill 373 66 -13 373 67 -13 dirt
execute in minecraft:overworld run setblock 373 68 -13 grass_block
execute in minecraft:overworld run fill 373 69 -13 373 144 -13 air
execute in minecraft:overworld run fill 373 58 -12 373 65 -12 stone
execute in minecraft:overworld run fill 373 66 -12 373 67 -12 dirt
execute in minecraft:overworld run setblock 373 68 -12 coarse_dirt
execute in minecraft:overworld run fill 373 69 -12 373 144 -12 air
execute in minecraft:overworld run fill 373 58 -11 373 65 -11 stone
execute in minecraft:overworld run fill 373 66 -11 373 67 -11 dirt
execute in minecraft:overworld run setblock 373 68 -11 grass_block
execute in minecraft:overworld run fill 373 69 -11 373 144 -11 air
execute in minecraft:overworld run fill 373 58 -10 373 65 -10 stone
execute in minecraft:overworld run fill 373 66 -10 373 67 -10 dirt
execute in minecraft:overworld run setblock 373 68 -10 grass_block
execute in minecraft:overworld run fill 373 69 -10 373 144 -10 air
execute in minecraft:overworld run setblock 373 69 -10 grass
execute in minecraft:overworld run fill 373 58 -9 373 65 -9 stone
execute in minecraft:overworld run fill 373 66 -9 373 67 -9 dirt
execute in minecraft:overworld run setblock 373 68 -9 grass_block
execute in minecraft:overworld run fill 373 69 -9 373 144 -9 air
execute in minecraft:overworld run fill 373 58 -8 373 65 -8 stone
execute in minecraft:overworld run fill 373 66 -8 373 67 -8 dirt
execute in minecraft:overworld run setblock 373 68 -8 coarse_dirt
execute in minecraft:overworld run fill 373 69 -8 373 144 -8 air
execute in minecraft:overworld run fill 373 58 -7 373 65 -7 stone
execute in minecraft:overworld run fill 373 66 -7 373 67 -7 dirt
execute in minecraft:overworld run setblock 373 68 -7 coarse_dirt
execute in minecraft:overworld run fill 373 69 -7 373 144 -7 air
execute in minecraft:overworld run fill 373 58 -6 373 65 -6 stone
execute in minecraft:overworld run fill 373 66 -6 373 67 -6 dirt
execute in minecraft:overworld run setblock 373 68 -6 coarse_dirt
execute in minecraft:overworld run fill 373 69 -6 373 144 -6 air
execute in minecraft:overworld run fill 373 58 -5 373 65 -5 stone
execute in minecraft:overworld run fill 373 66 -5 373 67 -5 dirt
execute in minecraft:overworld run setblock 373 68 -5 coarse_dirt
execute in minecraft:overworld run fill 373 69 -5 373 144 -5 air
execute in minecraft:overworld run setblock 373 69 -5 grass
execute in minecraft:overworld run fill 373 58 -4 373 65 -4 stone
execute in minecraft:overworld run fill 373 66 -4 373 67 -4 dirt
execute in minecraft:overworld run setblock 373 68 -4 coarse_dirt
execute in minecraft:overworld run fill 373 69 -4 373 144 -4 air
execute in minecraft:overworld run fill 373 58 -3 373 65 -3 stone
execute in minecraft:overworld run fill 373 66 -3 373 67 -3 dirt
execute in minecraft:overworld run setblock 373 68 -3 coarse_dirt
execute in minecraft:overworld run fill 373 69 -3 373 144 -3 air
execute in minecraft:overworld run fill 373 58 -2 373 65 -2 stone
execute in minecraft:overworld run fill 373 66 -2 373 67 -2 dirt
execute in minecraft:overworld run setblock 373 68 -2 coarse_dirt
execute in minecraft:overworld run fill 373 69 -2 373 144 -2 air
execute in minecraft:overworld run setblock 373 69 -2 mossy_cobblestone
execute in minecraft:overworld run fill 373 58 -1 373 65 -1 stone
execute in minecraft:overworld run fill 373 66 -1 373 67 -1 dirt
execute in minecraft:overworld run setblock 373 68 -1 coarse_dirt
execute in minecraft:overworld run fill 373 69 -1 373 144 -1 air
execute in minecraft:overworld run fill 373 58 0 373 65 0 stone
execute in minecraft:overworld run fill 373 66 0 373 67 0 dirt
execute in minecraft:overworld run setblock 373 68 0 coarse_dirt
execute in minecraft:overworld run fill 373 69 0 373 144 0 air
execute in minecraft:overworld run fill 373 58 1 373 65 1 stone
execute in minecraft:overworld run fill 373 66 1 373 67 1 dirt
execute in minecraft:overworld run setblock 373 68 1 coarse_dirt
execute in minecraft:overworld run fill 373 69 1 373 144 1 air
execute in minecraft:overworld run fill 373 58 2 373 65 2 stone
execute in minecraft:overworld run fill 373 66 2 373 67 2 dirt
execute in minecraft:overworld run setblock 373 68 2 coarse_dirt
execute in minecraft:overworld run fill 373 69 2 373 144 2 air
execute in minecraft:overworld run fill 373 58 3 373 65 3 stone
execute in minecraft:overworld run fill 373 66 3 373 67 3 dirt
execute in minecraft:overworld run setblock 373 68 3 grass_block
execute in minecraft:overworld run fill 373 69 3 373 144 3 air
execute in minecraft:overworld run setblock 373 69 3 grass
execute in minecraft:overworld run fill 373 58 4 373 65 4 stone
execute in minecraft:overworld run fill 373 66 4 373 67 4 dirt
execute in minecraft:overworld run setblock 373 68 4 grass_block
execute in minecraft:overworld run fill 373 69 4 373 144 4 air
execute in minecraft:overworld run fill 373 58 5 373 65 5 stone
execute in minecraft:overworld run fill 373 66 5 373 67 5 dirt
execute in minecraft:overworld run setblock 373 68 5 coarse_dirt
execute in minecraft:overworld run fill 373 69 5 373 144 5 air
execute in minecraft:overworld run fill 373 58 6 373 65 6 stone
execute in minecraft:overworld run fill 373 66 6 373 67 6 dirt
execute in minecraft:overworld run setblock 373 68 6 coarse_dirt
execute in minecraft:overworld run fill 373 69 6 373 144 6 air
execute in minecraft:overworld run fill 373 58 7 373 65 7 stone
execute in minecraft:overworld run fill 373 66 7 373 67 7 dirt
execute in minecraft:overworld run setblock 373 68 7 coarse_dirt
execute in minecraft:overworld run fill 373 69 7 373 144 7 air
execute in minecraft:overworld run fill 373 58 8 373 65 8 stone
execute in minecraft:overworld run fill 373 66 8 373 67 8 dirt
execute in minecraft:overworld run setblock 373 68 8 coarse_dirt
execute in minecraft:overworld run fill 373 69 8 373 144 8 air
execute in minecraft:overworld run setblock 373 69 8 grass
execute in minecraft:overworld run fill 373 58 9 373 65 9 stone
execute in minecraft:overworld run fill 373 66 9 373 67 9 dirt
execute in minecraft:overworld run setblock 373 68 9 coarse_dirt
execute in minecraft:overworld run fill 373 69 9 373 144 9 air
execute in minecraft:overworld run fill 373 58 10 373 66 10 stone
execute in minecraft:overworld run fill 373 67 10 373 68 10 dirt
execute in minecraft:overworld run setblock 373 69 10 coarse_dirt
execute in minecraft:overworld run fill 373 70 10 373 144 10 air
execute in minecraft:overworld run fill 373 58 11 373 66 11 stone
execute in minecraft:overworld run fill 373 67 11 373 68 11 dirt
execute in minecraft:overworld run setblock 373 69 11 coarse_dirt
execute in minecraft:overworld run fill 373 70 11 373 144 11 air
execute in minecraft:overworld run fill 373 58 12 373 66 12 stone
execute in minecraft:overworld run fill 373 67 12 373 68 12 dirt
execute in minecraft:overworld run setblock 373 69 12 grass_block
execute in minecraft:overworld run fill 373 70 12 373 144 12 air
execute in minecraft:overworld run fill 373 58 13 373 66 13 stone
execute in minecraft:overworld run fill 373 67 13 373 68 13 dirt
execute in minecraft:overworld run setblock 373 69 13 coarse_dirt
execute in minecraft:overworld run fill 373 70 13 373 144 13 air
execute in minecraft:overworld run fill 373 58 14 373 67 14 stone
execute in minecraft:overworld run fill 373 68 14 373 69 14 dirt
execute in minecraft:overworld run setblock 373 70 14 grass_block
execute in minecraft:overworld run fill 373 71 14 373 144 14 air
execute in minecraft:overworld run setblock 373 71 14 grass
execute in minecraft:overworld run fill 373 58 15 373 67 15 stone
execute in minecraft:overworld run fill 373 68 15 373 69 15 dirt
execute in minecraft:overworld run setblock 373 70 15 coarse_dirt
execute in minecraft:overworld run fill 373 71 15 373 144 15 air
execute in minecraft:overworld run fill 373 58 16 373 67 16 stone
execute in minecraft:overworld run fill 373 68 16 373 69 16 dirt
execute in minecraft:overworld run setblock 373 70 16 grass_block
execute in minecraft:overworld run fill 373 71 16 373 144 16 air
execute in minecraft:overworld run setblock 373 71 16 mossy_cobblestone
execute in minecraft:overworld run fill 373 58 17 373 68 17 stone
execute in minecraft:overworld run fill 373 69 17 373 70 17 dirt
execute in minecraft:overworld run setblock 373 71 17 coarse_dirt
execute in minecraft:overworld run fill 373 72 17 373 144 17 air
execute in minecraft:overworld run fill 373 58 18 373 68 18 stone
execute in minecraft:overworld run fill 373 69 18 373 70 18 dirt
execute in minecraft:overworld run setblock 373 71 18 coarse_dirt
execute in minecraft:overworld run fill 373 72 18 373 144 18 air
execute in minecraft:overworld run fill 373 58 19 373 68 19 stone
execute in minecraft:overworld run fill 373 69 19 373 70 19 dirt
execute in minecraft:overworld run setblock 373 71 19 coarse_dirt
execute in minecraft:overworld run fill 373 72 19 373 144 19 air
execute in minecraft:overworld run fill 373 58 20 373 68 20 stone
execute in minecraft:overworld run fill 373 69 20 373 70 20 dirt
execute in minecraft:overworld run setblock 373 71 20 coarse_dirt
execute in minecraft:overworld run fill 373 72 20 373 144 20 air
execute in minecraft:overworld run setblock 373 72 20 grass
execute in minecraft:overworld run fill 373 58 21 373 68 21 stone
execute in minecraft:overworld run fill 373 69 21 373 70 21 dirt
execute in minecraft:overworld run setblock 373 71 21 coarse_dirt
execute in minecraft:overworld run fill 373 72 21 373 144 21 air
execute in minecraft:overworld run fill 373 58 22 373 68 22 stone
execute in minecraft:overworld run fill 373 69 22 373 70 22 dirt
execute in minecraft:overworld run setblock 373 71 22 coarse_dirt
execute in minecraft:overworld run fill 373 72 22 373 144 22 air
execute in minecraft:overworld run fill 373 58 23 373 68 23 stone
execute in minecraft:overworld run fill 373 69 23 373 70 23 dirt
execute in minecraft:overworld run setblock 373 71 23 coarse_dirt
execute in minecraft:overworld run fill 373 72 23 373 144 23 air
execute in minecraft:overworld run fill 373 58 24 373 68 24 stone
execute in minecraft:overworld run fill 373 69 24 373 70 24 dirt
execute in minecraft:overworld run setblock 373 71 24 grass_block
execute in minecraft:overworld run fill 373 72 24 373 144 24 air
execute in minecraft:overworld run fill 373 58 25 373 68 25 stone
execute in minecraft:overworld run fill 373 69 25 373 70 25 dirt
execute in minecraft:overworld run setblock 373 71 25 grass_block
execute in minecraft:overworld run fill 373 72 25 373 144 25 air
execute in minecraft:overworld run fill 373 58 26 373 68 26 stone
execute in minecraft:overworld run fill 373 69 26 373 70 26 dirt
execute in minecraft:overworld run setblock 373 71 26 grass_block
execute in minecraft:overworld run fill 373 72 26 373 144 26 air
execute in minecraft:overworld run fill 373 58 27 373 68 27 stone
execute in minecraft:overworld run fill 373 69 27 373 70 27 dirt
execute in minecraft:overworld run setblock 373 71 27 grass_block
execute in minecraft:overworld run fill 373 72 27 373 144 27 air
execute in minecraft:overworld run fill 373 58 28 373 68 28 stone
execute in minecraft:overworld run fill 373 69 28 373 70 28 dirt
execute in minecraft:overworld run setblock 373 71 28 coarse_dirt
execute in minecraft:overworld run fill 373 72 28 373 144 28 air
execute in minecraft:overworld run fill 373 58 29 373 68 29 stone
execute in minecraft:overworld run fill 373 69 29 373 70 29 dirt
execute in minecraft:overworld run setblock 373 71 29 coarse_dirt
execute in minecraft:overworld run fill 373 72 29 373 144 29 air
execute in minecraft:overworld run setblock 373 72 29 mossy_cobblestone
execute in minecraft:overworld run fill 373 58 30 373 68 30 stone
execute in minecraft:overworld run fill 373 69 30 373 70 30 dirt
execute in minecraft:overworld run setblock 373 71 30 coarse_dirt
execute in minecraft:overworld run fill 373 72 30 373 144 30 air
execute in minecraft:overworld run fill 373 58 31 373 68 31 stone
execute in minecraft:overworld run fill 373 69 31 373 70 31 dirt
schedule function blade_gallery:random/battlefield/part_58 1t replace
