execute in minecraft:overworld run fill 223 70 -30 223 74 -30 stone_bricks
execute in minecraft:overworld run fill 223 69 -29 223 74 -29 stone_bricks
execute in minecraft:overworld run fill 223 69 -28 223 74 -28 stone_bricks
execute in minecraft:overworld run fill 223 69 -27 223 74 -27 stone_bricks
execute in minecraft:overworld run fill 224 72 -35 224 74 -35 stone_bricks
execute in minecraft:overworld run fill 224 71 -34 224 74 -34 stone_bricks
execute in minecraft:overworld run fill 224 71 -33 224 74 -33 stone_bricks
execute in minecraft:overworld run fill 224 71 -32 224 74 -32 stone_bricks
execute in minecraft:overworld run fill 224 70 -31 224 74 -31 stone_bricks
execute in minecraft:overworld run fill 224 70 -30 224 74 -30 stone_bricks
execute in minecraft:overworld run fill 224 70 -29 224 74 -29 stone_bricks
execute in minecraft:overworld run fill 224 69 -28 224 74 -28 stone_bricks
execute in minecraft:overworld run fill 224 69 -27 224 74 -27 stone_bricks
execute in minecraft:overworld run fill 225 72 -35 225 74 -35 stone_bricks
execute in minecraft:overworld run fill 225 71 -34 225 74 -34 stone_bricks
execute in minecraft:overworld run fill 225 71 -33 225 74 -33 stone_bricks
execute in minecraft:overworld run fill 225 71 -32 225 74 -32 stone_bricks
execute in minecraft:overworld run fill 225 70 -31 225 74 -31 stone_bricks
execute in minecraft:overworld run fill 225 70 -30 225 74 -30 stone_bricks
execute in minecraft:overworld run fill 225 70 -29 225 74 -29 stone_bricks
execute in minecraft:overworld run fill 225 69 -28 225 74 -28 stone_bricks
execute in minecraft:overworld run fill 225 69 -27 225 74 -27 stone_bricks
execute in minecraft:overworld run fill 226 72 -35 226 74 -35 stone_bricks
execute in minecraft:overworld run fill 226 72 -34 226 74 -34 stone_bricks
execute in minecraft:overworld run fill 226 71 -33 226 74 -33 stone_bricks
execute in minecraft:overworld run fill 226 71 -32 226 74 -32 stone_bricks
execute in minecraft:overworld run fill 226 70 -31 226 74 -31 stone_bricks
execute in minecraft:overworld run fill 226 70 -30 226 74 -30 stone_bricks
execute in minecraft:overworld run fill 226 70 -29 226 74 -29 stone_bricks
execute in minecraft:overworld run fill 226 69 -28 226 74 -28 stone_bricks
execute in minecraft:overworld run fill 226 69 -27 226 74 -27 stone_bricks
execute in minecraft:overworld run fill 227 72 -35 227 74 -35 stone_bricks
execute in minecraft:overworld run fill 227 72 -34 227 74 -34 stone_bricks
execute in minecraft:overworld run fill 227 71 -33 227 74 -33 stone_bricks
execute in minecraft:overworld run fill 227 71 -32 227 74 -32 stone_bricks
execute in minecraft:overworld run fill 227 71 -31 227 74 -31 stone_bricks
execute in minecraft:overworld run fill 227 70 -30 227 74 -30 stone_bricks
execute in minecraft:overworld run fill 227 70 -29 227 74 -29 stone_bricks
execute in minecraft:overworld run fill 227 70 -28 227 74 -28 stone_bricks
execute in minecraft:overworld run fill 227 69 -27 227 74 -27 stone_bricks
execute in minecraft:overworld run fill 228 73 -35 228 74 -35 stone_bricks
execute in minecraft:overworld run fill 228 72 -34 228 74 -34 stone_bricks
execute in minecraft:overworld run fill 228 72 -33 228 74 -33 stone_bricks
execute in minecraft:overworld run fill 228 71 -32 228 74 -32 stone_bricks
execute in minecraft:overworld run fill 228 71 -31 228 74 -31 stone_bricks
execute in minecraft:overworld run fill 228 71 -30 228 74 -30 stone_bricks
execute in minecraft:overworld run fill 228 70 -29 228 74 -29 stone_bricks
execute in minecraft:overworld run fill 228 70 -28 228 74 -28 stone_bricks
execute in minecraft:overworld run fill 228 70 -27 228 74 -27 stone_bricks
execute in minecraft:overworld run setblock 220 74 -35 gray_concrete
execute in minecraft:overworld run setblock 220 74 -34 gray_concrete
execute in minecraft:overworld run setblock 220 74 -33 gray_concrete
execute in minecraft:overworld run setblock 220 74 -32 gray_concrete
execute in minecraft:overworld run setblock 220 74 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 74 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 74 -29 gray_concrete
execute in minecraft:overworld run setblock 220 74 -28 gray_concrete
execute in minecraft:overworld run setblock 220 74 -27 gray_concrete
execute in minecraft:overworld run setblock 221 74 -35 gray_concrete
execute in minecraft:overworld run setblock 221 74 -34 gray_concrete
execute in minecraft:overworld run setblock 221 74 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 74 -32 gray_concrete
execute in minecraft:overworld run setblock 221 74 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 74 -30 gray_concrete
execute in minecraft:overworld run setblock 221 74 -29 gray_concrete
execute in minecraft:overworld run setblock 221 74 -28 gray_concrete
execute in minecraft:overworld run setblock 221 74 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 222 74 -35 gray_concrete
execute in minecraft:overworld run setblock 222 74 -34 gray_concrete
execute in minecraft:overworld run setblock 222 74 -33 gray_concrete
execute in minecraft:overworld run setblock 222 74 -32 gray_concrete
execute in minecraft:overworld run setblock 222 74 -31 gray_concrete
execute in minecraft:overworld run setblock 222 74 -30 gray_concrete
execute in minecraft:overworld run setblock 222 74 -29 gray_concrete
execute in minecraft:overworld run setblock 222 74 -28 gray_concrete
execute in minecraft:overworld run setblock 222 74 -27 gray_concrete
execute in minecraft:overworld run setblock 223 74 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 74 -34 gray_concrete
execute in minecraft:overworld run setblock 223 74 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 74 -32 gray_concrete
execute in minecraft:overworld run setblock 223 74 -31 gray_concrete
execute in minecraft:overworld run setblock 223 74 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 74 -29 gray_concrete
execute in minecraft:overworld run setblock 223 74 -28 gray_concrete
execute in minecraft:overworld run setblock 223 74 -27 gray_concrete
execute in minecraft:overworld run setblock 224 74 -35 gray_concrete
execute in minecraft:overworld run setblock 224 74 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 74 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 74 -32 gray_concrete
execute in minecraft:overworld run setblock 224 74 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 74 -30 gray_concrete
execute in minecraft:overworld run setblock 224 74 -29 gray_concrete
execute in minecraft:overworld run setblock 224 74 -28 gray_concrete
execute in minecraft:overworld run setblock 225 74 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 225 74 -34 gray_concrete
execute in minecraft:overworld run setblock 225 74 -33 gray_concrete
execute in minecraft:overworld run setblock 225 74 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 225 74 -31 gray_concrete
execute in minecraft:overworld run setblock 225 74 -30 gray_concrete
execute in minecraft:overworld run setblock 225 74 -29 gray_concrete
execute in minecraft:overworld run setblock 225 74 -28 gray_concrete
execute in minecraft:overworld run setblock 225 74 -27 gray_concrete
execute in minecraft:overworld run setblock 226 74 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 226 74 -34 gray_concrete
execute in minecraft:overworld run setblock 226 74 -33 gray_concrete
execute in minecraft:overworld run setblock 226 74 -31 gray_concrete
execute in minecraft:overworld run setblock 226 74 -30 gray_concrete
execute in minecraft:overworld run setblock 226 74 -29 gray_concrete
execute in minecraft:overworld run setblock 226 74 -28 gray_concrete
execute in minecraft:overworld run setblock 226 74 -27 gray_concrete
execute in minecraft:overworld run setblock 227 74 -35 gray_concrete
execute in minecraft:overworld run setblock 227 74 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 74 -33 gray_concrete
execute in minecraft:overworld run setblock 227 74 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 74 -31 gray_concrete
execute in minecraft:overworld run setblock 227 74 -30 gray_concrete
execute in minecraft:overworld run setblock 227 74 -29 gray_concrete
execute in minecraft:overworld run setblock 227 74 -28 gray_concrete
execute in minecraft:overworld run setblock 227 74 -27 gray_concrete
execute in minecraft:overworld run setblock 228 74 -35 gray_concrete
execute in minecraft:overworld run setblock 228 74 -34 gray_concrete
execute in minecraft:overworld run setblock 228 74 -33 gray_concrete
execute in minecraft:overworld run setblock 228 74 -32 gray_concrete
execute in minecraft:overworld run setblock 228 74 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 74 -30 gray_concrete
execute in minecraft:overworld run setblock 228 74 -29 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 74 -28 gray_concrete
execute in minecraft:overworld run setblock 228 74 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 75 -35 gray_concrete
execute in minecraft:overworld run setblock 220 75 -34 gray_concrete
execute in minecraft:overworld run setblock 220 75 -33 gray_concrete
execute in minecraft:overworld run setblock 220 75 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 75 -31 gray_concrete
execute in minecraft:overworld run setblock 220 75 -30 gray_concrete
execute in minecraft:overworld run setblock 220 75 -29 gray_concrete
execute in minecraft:overworld run setblock 220 75 -27 gray_concrete
execute in minecraft:overworld run setblock 221 75 -35 gray_concrete
execute in minecraft:overworld run setblock 221 75 -27 gray_concrete
execute in minecraft:overworld run setblock 222 75 -35 gray_concrete
execute in minecraft:overworld run setblock 222 75 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 75 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 75 -35 gray_concrete
execute in minecraft:overworld run setblock 224 75 -27 gray_concrete
execute in minecraft:overworld run setblock 225 75 -35 gray_concrete
execute in minecraft:overworld run setblock 225 75 -27 gray_concrete
execute in minecraft:overworld run setblock 226 75 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 226 75 -27 gray_concrete
execute in minecraft:overworld run setblock 227 75 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 75 -27 gray_concrete
execute in minecraft:overworld run setblock 228 75 -35 gray_concrete
execute in minecraft:overworld run setblock 228 75 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 75 -33 gray_concrete
execute in minecraft:overworld run setblock 228 75 -32 gray_concrete
execute in minecraft:overworld run setblock 228 75 -31 gray_concrete
execute in minecraft:overworld run setblock 228 75 -30 gray_concrete
execute in minecraft:overworld run setblock 228 75 -29 gray_concrete
execute in minecraft:overworld run setblock 228 75 -28 gray_concrete
execute in minecraft:overworld run setblock 228 75 -27 gray_concrete
execute in minecraft:overworld run setblock 220 76 -35 gray_concrete
execute in minecraft:overworld run setblock 220 76 -34 gray_concrete
execute in minecraft:overworld run setblock 220 76 -33 gray_concrete
execute in minecraft:overworld run setblock 220 76 -31 gray_concrete
execute in minecraft:overworld run setblock 220 76 -30 gray_concrete
execute in minecraft:overworld run setblock 220 76 -29 gray_concrete
execute in minecraft:overworld run setblock 220 76 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 76 -27 gray_concrete
execute in minecraft:overworld run setblock 221 76 -35 gray_concrete
execute in minecraft:overworld run setblock 221 76 -27 gray_concrete
execute in minecraft:overworld run setblock 222 76 -35 gray_concrete
execute in minecraft:overworld run setblock 222 76 -27 gray_concrete
execute in minecraft:overworld run setblock 223 76 -27 gray_concrete
execute in minecraft:overworld run setblock 224 76 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 76 -27 gray_concrete
execute in minecraft:overworld run setblock 225 76 -35 gray_concrete
execute in minecraft:overworld run setblock 225 76 -27 gray_concrete
execute in minecraft:overworld run setblock 226 76 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 76 -35 gray_concrete
execute in minecraft:overworld run setblock 227 76 -27 gray_concrete
execute in minecraft:overworld run setblock 228 76 -35 gray_concrete
execute in minecraft:overworld run setblock 228 76 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 76 -33 gray_concrete
execute in minecraft:overworld run setblock 228 76 -32 gray_concrete
execute in minecraft:overworld run setblock 228 76 -31 gray_concrete
execute in minecraft:overworld run setblock 228 76 -30 gray_concrete
execute in minecraft:overworld run setblock 228 76 -28 gray_concrete
execute in minecraft:overworld run setblock 228 76 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 77 -35 gray_concrete
execute in minecraft:overworld run setblock 220 77 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 77 -33 gray_concrete
execute in minecraft:overworld run setblock 220 77 -32 gray_concrete
execute in minecraft:overworld run setblock 220 77 -30 gray_concrete
execute in minecraft:overworld run setblock 220 77 -28 gray_concrete
execute in minecraft:overworld run setblock 220 77 -27 gray_concrete
execute in minecraft:overworld run setblock 221 77 -35 gray_concrete
execute in minecraft:overworld run setblock 221 77 -27 gray_concrete
execute in minecraft:overworld run setblock 222 77 -27 gray_concrete
execute in minecraft:overworld run setblock 223 77 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 77 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 77 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 224 77 -27 gray_concrete
execute in minecraft:overworld run setblock 225 77 -35 gray_concrete
execute in minecraft:overworld run setblock 226 77 -35 gray_concrete
execute in minecraft:overworld run setblock 226 77 -27 gray_concrete
execute in minecraft:overworld run setblock 227 77 -35 gray_concrete
execute in minecraft:overworld run setblock 227 77 -27 gray_concrete
execute in minecraft:overworld run setblock 228 77 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 77 -34 gray_concrete
execute in minecraft:overworld run setblock 228 77 -33 gray_concrete
execute in minecraft:overworld run setblock 228 77 -32 gray_concrete
execute in minecraft:overworld run setblock 228 77 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 77 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 77 -29 gray_concrete
execute in minecraft:overworld run setblock 228 77 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 77 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 78 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 78 -34 gray_concrete
execute in minecraft:overworld run setblock 220 78 -33 gray_concrete
execute in minecraft:overworld run setblock 220 78 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 78 -31 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 78 -30 gray_concrete
execute in minecraft:overworld run setblock 220 78 -29 gray_concrete
execute in minecraft:overworld run setblock 220 78 -28 gray_concrete
execute in minecraft:overworld run setblock 220 78 -27 gray_concrete
execute in minecraft:overworld run setblock 221 78 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 222 78 -35 gray_concrete
execute in minecraft:overworld run setblock 222 78 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 223 78 -35 gray_concrete
execute in minecraft:overworld run setblock 223 78 -27 gray_concrete
execute in minecraft:overworld run setblock 224 78 -35 gray_concrete
execute in minecraft:overworld run setblock 224 78 -27 cracked_stone_bricks
execute in minecraft:overworld run setblock 225 78 -35 gray_concrete
execute in minecraft:overworld run setblock 225 78 -27 gray_concrete
execute in minecraft:overworld run setblock 226 78 -35 gray_concrete
execute in minecraft:overworld run setblock 226 78 -27 gray_concrete
execute in minecraft:overworld run setblock 227 78 -35 cracked_stone_bricks
execute in minecraft:overworld run setblock 227 78 -27 gray_concrete
execute in minecraft:overworld run setblock 228 78 -35 gray_concrete
execute in minecraft:overworld run setblock 228 78 -34 gray_concrete
execute in minecraft:overworld run setblock 228 78 -33 gray_concrete
execute in minecraft:overworld run setblock 228 78 -31 gray_concrete
execute in minecraft:overworld run setblock 228 78 -30 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 78 -29 gray_concrete
execute in minecraft:overworld run setblock 228 78 -28 cracked_stone_bricks
execute in minecraft:overworld run setblock 228 78 -27 gray_concrete
execute in minecraft:overworld run setblock 220 79 -35 gray_concrete
execute in minecraft:overworld run setblock 220 79 -34 gray_concrete
execute in minecraft:overworld run setblock 220 79 -33 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 79 -32 cracked_stone_bricks
execute in minecraft:overworld run setblock 220 79 -31 gray_concrete
execute in minecraft:overworld run setblock 220 79 -30 gray_concrete
execute in minecraft:overworld run setblock 220 79 -29 gray_concrete
execute in minecraft:overworld run setblock 220 79 -28 gray_concrete
execute in minecraft:overworld run setblock 220 79 -27 gray_concrete
execute in minecraft:overworld run setblock 221 79 -35 gray_concrete
execute in minecraft:overworld run setblock 221 79 -34 cracked_stone_bricks
execute in minecraft:overworld run setblock 221 79 -33 cracked_stone_bricks
schedule function blade_gallery:random/burned/part_152 1t replace
