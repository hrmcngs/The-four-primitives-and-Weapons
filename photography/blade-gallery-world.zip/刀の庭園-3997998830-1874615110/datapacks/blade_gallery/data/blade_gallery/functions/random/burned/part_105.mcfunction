execute in minecraft:overworld run setblock 274 78 -41 coarse_dirt
execute in minecraft:overworld run fill 274 79 -41 274 144 -41 air
execute in minecraft:overworld run fill 274 58 -40 274 76 -40 stone
execute in minecraft:overworld run fill 274 77 -40 274 78 -40 dirt
execute in minecraft:overworld run setblock 274 79 -40 grass_block
execute in minecraft:overworld run fill 274 80 -40 274 144 -40 air
execute in minecraft:overworld run fill 274 58 -39 274 77 -39 stone
execute in minecraft:overworld run fill 274 78 -39 274 79 -39 dirt
execute in minecraft:overworld run setblock 274 80 -39 coarse_dirt
execute in minecraft:overworld run fill 274 81 -39 274 144 -39 air
execute in minecraft:overworld run fill 274 58 -38 274 79 -38 stone
execute in minecraft:overworld run fill 274 80 -38 274 81 -38 dirt
execute in minecraft:overworld run setblock 274 82 -38 coarse_dirt
execute in minecraft:overworld run fill 274 83 -38 274 144 -38 air
execute in minecraft:overworld run fill 274 58 -37 274 78 -37 stone
execute in minecraft:overworld run fill 274 79 -37 274 80 -37 dirt
execute in minecraft:overworld run setblock 274 81 -37 coarse_dirt
execute in minecraft:overworld run fill 274 82 -37 274 144 -37 air
execute in minecraft:overworld run fill 274 58 -36 274 78 -36 stone
execute in minecraft:overworld run fill 274 79 -36 274 80 -36 dirt
execute in minecraft:overworld run setblock 274 81 -36 coarse_dirt
execute in minecraft:overworld run fill 274 82 -36 274 144 -36 air
execute in minecraft:overworld run fill 274 58 -35 274 77 -35 stone
execute in minecraft:overworld run fill 274 78 -35 274 79 -35 dirt
execute in minecraft:overworld run setblock 274 80 -35 coarse_dirt
execute in minecraft:overworld run fill 274 81 -35 274 144 -35 air
execute in minecraft:overworld run fill 274 58 -34 274 77 -34 stone
execute in minecraft:overworld run fill 274 78 -34 274 79 -34 dirt
execute in minecraft:overworld run setblock 274 80 -34 grass_block
execute in minecraft:overworld run fill 274 81 -34 274 144 -34 air
execute in minecraft:overworld run fill 274 58 -33 274 77 -33 stone
execute in minecraft:overworld run fill 274 78 -33 274 79 -33 dirt
execute in minecraft:overworld run setblock 274 80 -33 coarse_dirt
execute in minecraft:overworld run fill 274 81 -33 274 144 -33 air
execute in minecraft:overworld run fill 274 58 -32 274 76 -32 stone
execute in minecraft:overworld run fill 274 77 -32 274 78 -32 dirt
execute in minecraft:overworld run setblock 274 79 -32 grass_block
execute in minecraft:overworld run fill 274 80 -32 274 144 -32 air
execute in minecraft:overworld run fill 274 58 -31 274 76 -31 stone
execute in minecraft:overworld run fill 274 77 -31 274 78 -31 dirt
execute in minecraft:overworld run setblock 274 79 -31 grass_block
execute in minecraft:overworld run fill 274 80 -31 274 144 -31 air
execute in minecraft:overworld run fill 274 58 -30 274 76 -30 stone
execute in minecraft:overworld run fill 274 77 -30 274 78 -30 dirt
execute in minecraft:overworld run setblock 274 79 -30 grass_block
execute in minecraft:overworld run fill 274 80 -30 274 144 -30 air
execute in minecraft:overworld run fill 274 58 -29 274 75 -29 stone
execute in minecraft:overworld run fill 274 76 -29 274 77 -29 dirt
execute in minecraft:overworld run setblock 274 78 -29 coarse_dirt
execute in minecraft:overworld run fill 274 79 -29 274 144 -29 air
execute in minecraft:overworld run fill 274 58 -28 274 75 -28 stone
execute in minecraft:overworld run fill 274 76 -28 274 77 -28 dirt
execute in minecraft:overworld run setblock 274 78 -28 coarse_dirt
execute in minecraft:overworld run fill 274 79 -28 274 144 -28 air
execute in minecraft:overworld run fill 274 58 -27 274 75 -27 stone
execute in minecraft:overworld run fill 274 76 -27 274 77 -27 dirt
execute in minecraft:overworld run setblock 274 78 -27 grass_block
execute in minecraft:overworld run fill 274 79 -27 274 144 -27 air
execute in minecraft:overworld run fill 274 58 -26 274 74 -26 stone
execute in minecraft:overworld run fill 274 75 -26 274 76 -26 dirt
execute in minecraft:overworld run setblock 274 77 -26 grass_block
execute in minecraft:overworld run fill 274 78 -26 274 144 -26 air
execute in minecraft:overworld run fill 274 58 -25 274 74 -25 stone
execute in minecraft:overworld run fill 274 75 -25 274 76 -25 dirt
execute in minecraft:overworld run setblock 274 77 -25 coarse_dirt
execute in minecraft:overworld run fill 274 78 -25 274 144 -25 air
execute in minecraft:overworld run fill 274 58 -24 274 74 -24 stone
execute in minecraft:overworld run fill 274 75 -24 274 76 -24 dirt
execute in minecraft:overworld run setblock 274 77 -24 coarse_dirt
execute in minecraft:overworld run fill 274 78 -24 274 144 -24 air
execute in minecraft:overworld run fill 274 58 -23 274 73 -23 stone
execute in minecraft:overworld run fill 274 74 -23 274 75 -23 dirt
execute in minecraft:overworld run setblock 274 76 -23 coarse_dirt
execute in minecraft:overworld run fill 274 77 -23 274 144 -23 air
execute in minecraft:overworld run fill 274 58 -22 274 73 -22 stone
execute in minecraft:overworld run fill 274 74 -22 274 75 -22 dirt
execute in minecraft:overworld run setblock 274 76 -22 coarse_dirt
execute in minecraft:overworld run fill 274 77 -22 274 144 -22 air
execute in minecraft:overworld run fill 274 58 -21 274 73 -21 stone
execute in minecraft:overworld run fill 274 74 -21 274 75 -21 dirt
execute in minecraft:overworld run setblock 274 76 -21 coarse_dirt
execute in minecraft:overworld run fill 274 77 -21 274 144 -21 air
execute in minecraft:overworld run fill 274 58 -20 274 72 -20 stone
execute in minecraft:overworld run fill 274 73 -20 274 74 -20 dirt
execute in minecraft:overworld run setblock 274 75 -20 coarse_dirt
execute in minecraft:overworld run fill 274 76 -20 274 144 -20 air
execute in minecraft:overworld run fill 274 58 -19 274 72 -19 stone
execute in minecraft:overworld run fill 274 73 -19 274 74 -19 dirt
execute in minecraft:overworld run setblock 274 75 -19 coarse_dirt
execute in minecraft:overworld run fill 274 76 -19 274 144 -19 air
execute in minecraft:overworld run setblock 274 76 -19 grass
execute in minecraft:overworld run fill 274 58 -18 274 71 -18 stone
execute in minecraft:overworld run fill 274 72 -18 274 73 -18 dirt
execute in minecraft:overworld run setblock 274 74 -18 coarse_dirt
execute in minecraft:overworld run fill 274 75 -18 274 144 -18 air
execute in minecraft:overworld run fill 274 58 -17 274 71 -17 stone
execute in minecraft:overworld run fill 274 72 -17 274 73 -17 dirt
execute in minecraft:overworld run setblock 274 74 -17 coarse_dirt
execute in minecraft:overworld run fill 274 75 -17 274 144 -17 air
execute in minecraft:overworld run fill 274 58 -16 274 70 -16 stone
execute in minecraft:overworld run fill 274 71 -16 274 72 -16 dirt
execute in minecraft:overworld run setblock 274 73 -16 coarse_dirt
execute in minecraft:overworld run fill 274 74 -16 274 144 -16 air
execute in minecraft:overworld run setblock 274 74 -16 mossy_cobblestone
execute in minecraft:overworld run fill 274 58 -15 274 69 -15 stone
execute in minecraft:overworld run fill 274 70 -15 274 71 -15 dirt
execute in minecraft:overworld run setblock 274 72 -15 grass_block
execute in minecraft:overworld run fill 274 73 -15 274 144 -15 air
execute in minecraft:overworld run fill 274 58 -14 274 69 -14 stone
execute in minecraft:overworld run fill 274 70 -14 274 71 -14 dirt
execute in minecraft:overworld run setblock 274 72 -14 grass_block
execute in minecraft:overworld run fill 274 73 -14 274 144 -14 air
execute in minecraft:overworld run fill 274 58 -13 274 68 -13 stone
execute in minecraft:overworld run fill 274 69 -13 274 70 -13 dirt
execute in minecraft:overworld run setblock 274 71 -13 grass_block
execute in minecraft:overworld run fill 274 72 -13 274 144 -13 air
execute in minecraft:overworld run fill 274 58 -12 274 67 -12 stone
execute in minecraft:overworld run fill 274 68 -12 274 69 -12 dirt
execute in minecraft:overworld run setblock 274 70 -12 coarse_dirt
execute in minecraft:overworld run fill 274 71 -12 274 144 -12 air
execute in minecraft:overworld run fill 274 58 -11 274 67 -11 stone
execute in minecraft:overworld run fill 274 68 -11 274 69 -11 dirt
execute in minecraft:overworld run setblock 274 70 -11 coarse_dirt
execute in minecraft:overworld run fill 274 71 -11 274 144 -11 air
execute in minecraft:overworld run fill 274 58 -10 274 66 -10 stone
execute in minecraft:overworld run fill 274 67 -10 274 68 -10 dirt
execute in minecraft:overworld run setblock 274 69 -10 grass_block
execute in minecraft:overworld run fill 274 70 -10 274 144 -10 air
execute in minecraft:overworld run fill 274 58 -9 274 66 -9 stone
execute in minecraft:overworld run fill 274 67 -9 274 68 -9 dirt
execute in minecraft:overworld run setblock 274 69 -9 grass_block
execute in minecraft:overworld run fill 274 70 -9 274 144 -9 air
execute in minecraft:overworld run setblock 274 70 -9 grass
execute in minecraft:overworld run fill 274 58 -8 274 66 -8 stone
execute in minecraft:overworld run fill 274 67 -8 274 68 -8 dirt
execute in minecraft:overworld run setblock 274 69 -8 grass_block
execute in minecraft:overworld run fill 274 70 -8 274 144 -8 air
execute in minecraft:overworld run fill 274 58 -7 274 65 -7 stone
execute in minecraft:overworld run fill 274 66 -7 274 67 -7 dirt
execute in minecraft:overworld run setblock 274 68 -7 coarse_dirt
execute in minecraft:overworld run fill 274 69 -7 274 144 -7 air
execute in minecraft:overworld run fill 274 58 -6 274 65 -6 stone
execute in minecraft:overworld run fill 274 66 -6 274 67 -6 dirt
execute in minecraft:overworld run setblock 274 68 -6 coarse_dirt
execute in minecraft:overworld run fill 274 69 -6 274 144 -6 air
execute in minecraft:overworld run fill 274 58 -5 274 65 -5 stone
execute in minecraft:overworld run fill 274 66 -5 274 67 -5 dirt
execute in minecraft:overworld run setblock 274 68 -5 grass_block
execute in minecraft:overworld run fill 274 69 -5 274 144 -5 air
execute in minecraft:overworld run fill 274 58 -4 274 64 -4 stone
execute in minecraft:overworld run fill 274 65 -4 274 66 -4 dirt
execute in minecraft:overworld run setblock 274 67 -4 coarse_dirt
execute in minecraft:overworld run fill 274 68 -4 274 144 -4 air
execute in minecraft:overworld run fill 274 58 -3 274 64 -3 stone
execute in minecraft:overworld run fill 274 65 -3 274 66 -3 dirt
execute in minecraft:overworld run setblock 274 67 -3 coarse_dirt
execute in minecraft:overworld run fill 274 68 -3 274 144 -3 air
execute in minecraft:overworld run fill 274 58 -2 274 64 -2 stone
execute in minecraft:overworld run fill 274 65 -2 274 66 -2 dirt
execute in minecraft:overworld run setblock 274 67 -2 coarse_dirt
execute in minecraft:overworld run fill 274 68 -2 274 144 -2 air
execute in minecraft:overworld run fill 274 58 -1 274 63 -1 stone
execute in minecraft:overworld run fill 274 64 -1 274 65 -1 dirt
execute in minecraft:overworld run setblock 274 66 -1 coarse_dirt
execute in minecraft:overworld run fill 274 67 -1 274 144 -1 air
execute in minecraft:overworld run fill 274 58 0 274 63 0 stone
execute in minecraft:overworld run fill 274 64 0 274 65 0 dirt
execute in minecraft:overworld run setblock 274 66 0 coarse_dirt
execute in minecraft:overworld run fill 274 67 0 274 144 0 air
execute in minecraft:overworld run fill 274 58 1 274 63 1 stone
execute in minecraft:overworld run fill 274 64 1 274 65 1 dirt
execute in minecraft:overworld run setblock 274 66 1 grass_block
execute in minecraft:overworld run fill 274 67 1 274 144 1 air
execute in minecraft:overworld run fill 274 58 2 274 63 2 stone
execute in minecraft:overworld run fill 274 64 2 274 65 2 dirt
execute in minecraft:overworld run setblock 274 66 2 grass_block
execute in minecraft:overworld run fill 274 67 2 274 144 2 air
execute in minecraft:overworld run fill 274 58 3 274 63 3 stone
execute in minecraft:overworld run fill 274 64 3 274 65 3 dirt
execute in minecraft:overworld run setblock 274 66 3 coarse_dirt
execute in minecraft:overworld run fill 274 67 3 274 144 3 air
execute in minecraft:overworld run fill 274 58 4 274 62 4 stone
execute in minecraft:overworld run fill 274 63 4 274 64 4 dirt
execute in minecraft:overworld run setblock 274 65 4 coarse_dirt
execute in minecraft:overworld run fill 274 66 4 274 144 4 air
execute in minecraft:overworld run fill 274 58 5 274 62 5 stone
execute in minecraft:overworld run fill 274 63 5 274 64 5 dirt
execute in minecraft:overworld run setblock 274 65 5 grass_block
execute in minecraft:overworld run fill 274 66 5 274 144 5 air
execute in minecraft:overworld run fill 274 58 6 274 62 6 stone
execute in minecraft:overworld run fill 274 63 6 274 64 6 dirt
execute in minecraft:overworld run setblock 274 65 6 coarse_dirt
execute in minecraft:overworld run fill 274 66 6 274 144 6 air
execute in minecraft:overworld run fill 274 58 7 274 62 7 stone
execute in minecraft:overworld run fill 274 63 7 274 64 7 dirt
execute in minecraft:overworld run setblock 274 65 7 coarse_dirt
execute in minecraft:overworld run fill 274 66 7 274 144 7 air
execute in minecraft:overworld run fill 274 58 8 274 62 8 stone
execute in minecraft:overworld run fill 274 63 8 274 64 8 dirt
execute in minecraft:overworld run setblock 274 65 8 coarse_dirt
execute in minecraft:overworld run fill 274 66 8 274 144 8 air
execute in minecraft:overworld run fill 274 58 9 274 61 9 stone
execute in minecraft:overworld run fill 274 62 9 274 63 9 dirt
execute in minecraft:overworld run setblock 274 64 9 coarse_dirt
execute in minecraft:overworld run fill 274 65 9 274 144 9 air
execute in minecraft:overworld run fill 274 58 10 274 61 10 stone
execute in minecraft:overworld run fill 274 62 10 274 63 10 dirt
execute in minecraft:overworld run setblock 274 64 10 coarse_dirt
execute in minecraft:overworld run fill 274 65 10 274 144 10 air
execute in minecraft:overworld run fill 274 58 11 274 61 11 stone
execute in minecraft:overworld run fill 274 62 11 274 63 11 dirt
execute in minecraft:overworld run setblock 274 64 11 coarse_dirt
execute in minecraft:overworld run fill 274 65 11 274 144 11 air
execute in minecraft:overworld run fill 274 58 12 274 61 12 stone
execute in minecraft:overworld run fill 274 62 12 274 63 12 dirt
execute in minecraft:overworld run setblock 274 64 12 grass_block
execute in minecraft:overworld run fill 274 65 12 274 144 12 air
execute in minecraft:overworld run fill 274 58 13 274 60 13 stone
execute in minecraft:overworld run fill 274 61 13 274 62 13 dirt
execute in minecraft:overworld run setblock 274 63 13 gravel
execute in minecraft:overworld run fill 274 64 13 274 144 13 air
execute in minecraft:overworld run fill 274 64 13 274 64 13 water
execute in minecraft:overworld run fill 274 58 14 274 60 14 stone
execute in minecraft:overworld run fill 274 61 14 274 62 14 dirt
execute in minecraft:overworld run setblock 274 63 14 gravel
execute in minecraft:overworld run fill 274 64 14 274 144 14 air
execute in minecraft:overworld run fill 274 64 14 274 64 14 water
execute in minecraft:overworld run fill 274 58 15 274 60 15 stone
execute in minecraft:overworld run fill 274 61 15 274 62 15 dirt
execute in minecraft:overworld run setblock 274 63 15 gravel
execute in minecraft:overworld run fill 274 64 15 274 144 15 air
execute in minecraft:overworld run fill 274 64 15 274 64 15 water
execute in minecraft:overworld run fill 274 58 16 274 60 16 stone
execute in minecraft:overworld run fill 274 61 16 274 62 16 dirt
execute in minecraft:overworld run setblock 274 63 16 gravel
execute in minecraft:overworld run fill 274 64 16 274 144 16 air
execute in minecraft:overworld run fill 274 64 16 274 64 16 water
execute in minecraft:overworld run fill 274 58 17 274 60 17 stone
execute in minecraft:overworld run fill 274 61 17 274 62 17 dirt
execute in minecraft:overworld run setblock 274 63 17 gravel
execute in minecraft:overworld run fill 274 64 17 274 144 17 air
execute in minecraft:overworld run fill 274 64 17 274 64 17 water
execute in minecraft:overworld run fill 274 58 18 274 60 18 stone
execute in minecraft:overworld run fill 274 61 18 274 62 18 dirt
execute in minecraft:overworld run setblock 274 63 18 gravel
execute in minecraft:overworld run fill 274 64 18 274 144 18 air
execute in minecraft:overworld run fill 274 64 18 274 64 18 water
execute in minecraft:overworld run fill 274 58 19 274 60 19 stone
execute in minecraft:overworld run fill 274 61 19 274 62 19 dirt
execute in minecraft:overworld run setblock 274 63 19 gravel
execute in minecraft:overworld run fill 274 64 19 274 144 19 air
execute in minecraft:overworld run fill 274 64 19 274 64 19 water
execute in minecraft:overworld run fill 274 58 20 274 60 20 stone
execute in minecraft:overworld run fill 274 61 20 274 62 20 dirt
execute in minecraft:overworld run setblock 274 63 20 gravel
execute in minecraft:overworld run fill 274 64 20 274 144 20 air
schedule function blade_gallery:random/burned/part_106 1t replace
