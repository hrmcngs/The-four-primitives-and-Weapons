execute in minecraft:overworld run fill 391 58 34 391 58 34 stone
execute in minecraft:overworld run fill 391 59 34 391 60 34 dirt
execute in minecraft:overworld run setblock 391 61 34 gravel
execute in minecraft:overworld run fill 391 62 34 391 144 34 air
execute in minecraft:overworld run fill 391 62 34 391 64 34 water
execute in minecraft:overworld run fill 391 58 35 391 58 35 stone
execute in minecraft:overworld run fill 391 59 35 391 60 35 dirt
execute in minecraft:overworld run setblock 391 61 35 gravel
execute in minecraft:overworld run fill 391 62 35 391 144 35 air
execute in minecraft:overworld run fill 391 62 35 391 64 35 water
execute in minecraft:overworld run fill 391 58 36 391 59 36 stone
execute in minecraft:overworld run fill 391 60 36 391 61 36 dirt
execute in minecraft:overworld run setblock 391 62 36 gravel
execute in minecraft:overworld run fill 391 63 36 391 144 36 air
execute in minecraft:overworld run fill 391 63 36 391 64 36 water
execute in minecraft:overworld run fill 391 58 37 391 59 37 stone
execute in minecraft:overworld run fill 391 60 37 391 61 37 dirt
execute in minecraft:overworld run setblock 391 62 37 gravel
execute in minecraft:overworld run fill 391 63 37 391 144 37 air
execute in minecraft:overworld run fill 391 63 37 391 64 37 water
execute in minecraft:overworld run fill 391 58 38 391 59 38 stone
execute in minecraft:overworld run fill 391 60 38 391 61 38 dirt
execute in minecraft:overworld run setblock 391 62 38 gravel
execute in minecraft:overworld run fill 391 63 38 391 144 38 air
execute in minecraft:overworld run fill 391 63 38 391 64 38 water
execute in minecraft:overworld run fill 391 58 39 391 60 39 stone
execute in minecraft:overworld run fill 391 61 39 391 62 39 dirt
execute in minecraft:overworld run setblock 391 63 39 gravel
execute in minecraft:overworld run fill 391 64 39 391 144 39 air
execute in minecraft:overworld run fill 391 64 39 391 64 39 water
execute in minecraft:overworld run fill 391 58 40 391 61 40 stone
execute in minecraft:overworld run fill 391 62 40 391 63 40 dirt
execute in minecraft:overworld run setblock 391 64 40 coarse_dirt
execute in minecraft:overworld run fill 391 65 40 391 144 40 air
execute in minecraft:overworld run fill 391 58 41 391 61 41 stone
execute in minecraft:overworld run fill 391 62 41 391 63 41 dirt
execute in minecraft:overworld run setblock 391 64 41 coarse_dirt
execute in minecraft:overworld run fill 391 65 41 391 144 41 air
execute in minecraft:overworld run fill 391 58 42 391 61 42 stone
execute in minecraft:overworld run fill 391 62 42 391 63 42 dirt
execute in minecraft:overworld run setblock 391 64 42 coarse_dirt
execute in minecraft:overworld run fill 391 65 42 391 144 42 air
execute in minecraft:overworld run fill 391 58 43 391 62 43 stone
execute in minecraft:overworld run fill 391 63 43 391 64 43 dirt
execute in minecraft:overworld run setblock 391 65 43 coarse_dirt
execute in minecraft:overworld run fill 391 66 43 391 144 43 air
execute in minecraft:overworld run fill 391 58 44 391 62 44 stone
execute in minecraft:overworld run fill 391 63 44 391 64 44 dirt
execute in minecraft:overworld run setblock 391 65 44 coarse_dirt
execute in minecraft:overworld run fill 391 66 44 391 144 44 air
execute in minecraft:overworld run fill 391 58 45 391 62 45 stone
execute in minecraft:overworld run fill 391 63 45 391 64 45 dirt
execute in minecraft:overworld run setblock 391 65 45 coarse_dirt
execute in minecraft:overworld run fill 391 66 45 391 144 45 air
execute in minecraft:overworld run fill 391 58 46 391 62 46 stone
execute in minecraft:overworld run fill 391 63 46 391 64 46 dirt
execute in minecraft:overworld run setblock 391 65 46 coarse_dirt
execute in minecraft:overworld run fill 391 66 46 391 144 46 air
execute in minecraft:overworld run fill 391 58 47 391 61 47 stone
execute in minecraft:overworld run fill 391 62 47 391 63 47 dirt
execute in minecraft:overworld run setblock 391 64 47 coarse_dirt
execute in minecraft:overworld run fill 391 65 47 391 144 47 air
execute in minecraft:overworld run fill 392 58 -48 392 61 -48 stone
execute in minecraft:overworld run fill 392 62 -48 392 63 -48 dirt
execute in minecraft:overworld run setblock 392 64 -48 coarse_dirt
execute in minecraft:overworld run fill 392 65 -48 392 144 -48 air
execute in minecraft:overworld run fill 392 58 -47 392 62 -47 stone
execute in minecraft:overworld run fill 392 63 -47 392 64 -47 dirt
execute in minecraft:overworld run setblock 392 65 -47 coarse_dirt
execute in minecraft:overworld run fill 392 66 -47 392 144 -47 air
execute in minecraft:overworld run fill 392 58 -46 392 64 -46 stone
execute in minecraft:overworld run fill 392 65 -46 392 66 -46 dirt
execute in minecraft:overworld run setblock 392 67 -46 coarse_dirt
execute in minecraft:overworld run fill 392 68 -46 392 144 -46 air
execute in minecraft:overworld run fill 392 58 -45 392 65 -45 stone
execute in minecraft:overworld run fill 392 66 -45 392 67 -45 dirt
execute in minecraft:overworld run setblock 392 68 -45 grass_block
execute in minecraft:overworld run fill 392 69 -45 392 144 -45 air
execute in minecraft:overworld run fill 392 58 -44 392 66 -44 stone
execute in minecraft:overworld run fill 392 67 -44 392 68 -44 dirt
execute in minecraft:overworld run setblock 392 69 -44 grass_block
execute in minecraft:overworld run fill 392 70 -44 392 144 -44 air
execute in minecraft:overworld run fill 392 58 -43 392 68 -43 stone
execute in minecraft:overworld run fill 392 69 -43 392 70 -43 dirt
execute in minecraft:overworld run setblock 392 71 -43 coarse_dirt
execute in minecraft:overworld run fill 392 72 -43 392 144 -43 air
execute in minecraft:overworld run fill 392 58 -42 392 69 -42 stone
execute in minecraft:overworld run fill 392 70 -42 392 71 -42 dirt
execute in minecraft:overworld run setblock 392 72 -42 coarse_dirt
execute in minecraft:overworld run fill 392 73 -42 392 144 -42 air
execute in minecraft:overworld run fill 392 58 -41 392 70 -41 stone
execute in minecraft:overworld run fill 392 71 -41 392 72 -41 dirt
execute in minecraft:overworld run setblock 392 73 -41 grass_block
execute in minecraft:overworld run fill 392 74 -41 392 144 -41 air
execute in minecraft:overworld run fill 392 58 -40 392 72 -40 stone
execute in minecraft:overworld run fill 392 73 -40 392 74 -40 dirt
execute in minecraft:overworld run setblock 392 75 -40 coarse_dirt
execute in minecraft:overworld run fill 392 76 -40 392 144 -40 air
execute in minecraft:overworld run fill 392 58 -39 392 73 -39 stone
execute in minecraft:overworld run fill 392 74 -39 392 75 -39 dirt
execute in minecraft:overworld run setblock 392 76 -39 coarse_dirt
execute in minecraft:overworld run fill 392 77 -39 392 144 -39 air
execute in minecraft:overworld run fill 392 58 -38 392 74 -38 stone
execute in minecraft:overworld run fill 392 75 -38 392 76 -38 dirt
execute in minecraft:overworld run setblock 392 77 -38 coarse_dirt
execute in minecraft:overworld run fill 392 78 -38 392 144 -38 air
execute in minecraft:overworld run setblock 392 78 -38 grass
execute in minecraft:overworld run fill 392 58 -37 392 74 -37 stone
execute in minecraft:overworld run fill 392 75 -37 392 76 -37 dirt
execute in minecraft:overworld run setblock 392 77 -37 grass_block
execute in minecraft:overworld run fill 392 78 -37 392 144 -37 air
execute in minecraft:overworld run fill 392 58 -36 392 74 -36 stone
execute in minecraft:overworld run fill 392 75 -36 392 76 -36 dirt
execute in minecraft:overworld run setblock 392 77 -36 grass_block
execute in minecraft:overworld run fill 392 78 -36 392 144 -36 air
execute in minecraft:overworld run fill 392 58 -35 392 73 -35 stone
execute in minecraft:overworld run fill 392 74 -35 392 75 -35 dirt
execute in minecraft:overworld run setblock 392 76 -35 coarse_dirt
execute in minecraft:overworld run fill 392 77 -35 392 144 -35 air
execute in minecraft:overworld run fill 392 58 -34 392 73 -34 stone
execute in minecraft:overworld run fill 392 74 -34 392 75 -34 dirt
execute in minecraft:overworld run setblock 392 76 -34 coarse_dirt
execute in minecraft:overworld run fill 392 77 -34 392 144 -34 air
execute in minecraft:overworld run fill 392 58 -33 392 73 -33 stone
execute in minecraft:overworld run fill 392 74 -33 392 75 -33 dirt
execute in minecraft:overworld run setblock 392 76 -33 coarse_dirt
execute in minecraft:overworld run fill 392 77 -33 392 144 -33 air
execute in minecraft:overworld run fill 392 58 -32 392 73 -32 stone
execute in minecraft:overworld run fill 392 74 -32 392 75 -32 dirt
execute in minecraft:overworld run setblock 392 76 -32 coarse_dirt
execute in minecraft:overworld run fill 392 77 -32 392 144 -32 air
execute in minecraft:overworld run setblock 392 77 -32 mossy_cobblestone
execute in minecraft:overworld run fill 392 58 -31 392 72 -31 stone
execute in minecraft:overworld run fill 392 73 -31 392 74 -31 dirt
execute in minecraft:overworld run setblock 392 75 -31 coarse_dirt
execute in minecraft:overworld run fill 392 76 -31 392 144 -31 air
execute in minecraft:overworld run fill 392 58 -30 392 72 -30 stone
execute in minecraft:overworld run fill 392 73 -30 392 74 -30 dirt
execute in minecraft:overworld run setblock 392 75 -30 coarse_dirt
execute in minecraft:overworld run fill 392 76 -30 392 144 -30 air
execute in minecraft:overworld run fill 392 58 -29 392 71 -29 stone
execute in minecraft:overworld run fill 392 72 -29 392 73 -29 dirt
execute in minecraft:overworld run setblock 392 74 -29 coarse_dirt
execute in minecraft:overworld run fill 392 75 -29 392 144 -29 air
execute in minecraft:overworld run fill 392 58 -28 392 71 -28 stone
execute in minecraft:overworld run fill 392 72 -28 392 73 -28 dirt
execute in minecraft:overworld run setblock 392 74 -28 grass_block
execute in minecraft:overworld run fill 392 75 -28 392 144 -28 air
execute in minecraft:overworld run fill 392 58 -27 392 70 -27 stone
execute in minecraft:overworld run fill 392 71 -27 392 72 -27 dirt
execute in minecraft:overworld run setblock 392 73 -27 coarse_dirt
execute in minecraft:overworld run fill 392 74 -27 392 144 -27 air
execute in minecraft:overworld run fill 392 58 -26 392 69 -26 stone
execute in minecraft:overworld run fill 392 70 -26 392 71 -26 dirt
execute in minecraft:overworld run setblock 392 72 -26 grass_block
execute in minecraft:overworld run fill 392 73 -26 392 144 -26 air
execute in minecraft:overworld run fill 392 58 -25 392 69 -25 stone
execute in minecraft:overworld run fill 392 70 -25 392 71 -25 dirt
execute in minecraft:overworld run setblock 392 72 -25 coarse_dirt
execute in minecraft:overworld run fill 392 73 -25 392 144 -25 air
execute in minecraft:overworld run fill 392 58 -24 392 68 -24 stone
execute in minecraft:overworld run fill 392 69 -24 392 70 -24 dirt
execute in minecraft:overworld run setblock 392 71 -24 grass_block
execute in minecraft:overworld run fill 392 72 -24 392 144 -24 air
execute in minecraft:overworld run setblock 392 72 -24 grass
execute in minecraft:overworld run fill 392 58 -23 392 67 -23 stone
execute in minecraft:overworld run fill 392 68 -23 392 69 -23 dirt
execute in minecraft:overworld run setblock 392 70 -23 coarse_dirt
execute in minecraft:overworld run fill 392 71 -23 392 144 -23 air
execute in minecraft:overworld run fill 392 58 -22 392 66 -22 stone
execute in minecraft:overworld run fill 392 67 -22 392 68 -22 dirt
execute in minecraft:overworld run setblock 392 69 -22 coarse_dirt
execute in minecraft:overworld run fill 392 70 -22 392 144 -22 air
execute in minecraft:overworld run fill 392 58 -21 392 65 -21 stone
execute in minecraft:overworld run fill 392 66 -21 392 67 -21 dirt
execute in minecraft:overworld run setblock 392 68 -21 coarse_dirt
execute in minecraft:overworld run fill 392 69 -21 392 144 -21 air
execute in minecraft:overworld run fill 392 58 -20 392 64 -20 stone
execute in minecraft:overworld run fill 392 65 -20 392 66 -20 dirt
execute in minecraft:overworld run setblock 392 67 -20 coarse_dirt
execute in minecraft:overworld run fill 392 68 -20 392 144 -20 air
execute in minecraft:overworld run fill 392 58 -19 392 63 -19 stone
execute in minecraft:overworld run fill 392 64 -19 392 65 -19 dirt
execute in minecraft:overworld run setblock 392 66 -19 coarse_dirt
execute in minecraft:overworld run fill 392 67 -19 392 144 -19 air
execute in minecraft:overworld run fill 392 58 -18 392 62 -18 stone
execute in minecraft:overworld run fill 392 63 -18 392 64 -18 dirt
execute in minecraft:overworld run setblock 392 65 -18 grass_block
execute in minecraft:overworld run fill 392 66 -18 392 144 -18 air
execute in minecraft:overworld run fill 392 58 -17 392 61 -17 stone
execute in minecraft:overworld run fill 392 62 -17 392 63 -17 dirt
execute in minecraft:overworld run setblock 392 64 -17 grass_block
execute in minecraft:overworld run fill 392 65 -17 392 144 -17 air
execute in minecraft:overworld run fill 392 58 -16 392 60 -16 stone
execute in minecraft:overworld run fill 392 61 -16 392 62 -16 dirt
execute in minecraft:overworld run setblock 392 63 -16 gravel
execute in minecraft:overworld run fill 392 64 -16 392 144 -16 air
execute in minecraft:overworld run fill 392 64 -16 392 64 -16 water
execute in minecraft:overworld run fill 392 58 -15 392 59 -15 stone
execute in minecraft:overworld run fill 392 60 -15 392 61 -15 dirt
execute in minecraft:overworld run setblock 392 62 -15 gravel
execute in minecraft:overworld run fill 392 63 -15 392 144 -15 air
execute in minecraft:overworld run fill 392 63 -15 392 64 -15 water
execute in minecraft:overworld run fill 392 58 -14 392 58 -14 stone
execute in minecraft:overworld run fill 392 59 -14 392 60 -14 dirt
execute in minecraft:overworld run setblock 392 61 -14 gravel
execute in minecraft:overworld run fill 392 62 -14 392 144 -14 air
execute in minecraft:overworld run fill 392 62 -14 392 64 -14 water
execute in minecraft:overworld run fill 392 58 -13 392 58 -13 stone
execute in minecraft:overworld run fill 392 59 -13 392 60 -13 dirt
execute in minecraft:overworld run setblock 392 61 -13 gravel
execute in minecraft:overworld run fill 392 62 -13 392 144 -13 air
execute in minecraft:overworld run fill 392 62 -13 392 64 -13 water
execute in minecraft:overworld run fill 392 58 -12 392 57 -12 stone
execute in minecraft:overworld run fill 392 58 -12 392 59 -12 dirt
execute in minecraft:overworld run setblock 392 60 -12 gravel
execute in minecraft:overworld run fill 392 61 -12 392 144 -12 air
execute in minecraft:overworld run fill 392 61 -12 392 64 -12 water
execute in minecraft:overworld run fill 392 58 -11 392 56 -11 stone
execute in minecraft:overworld run fill 392 57 -11 392 58 -11 dirt
execute in minecraft:overworld run setblock 392 59 -11 gravel
execute in minecraft:overworld run fill 392 60 -11 392 144 -11 air
execute in minecraft:overworld run fill 392 60 -11 392 64 -11 water
execute in minecraft:overworld run fill 392 58 -10 392 56 -10 stone
execute in minecraft:overworld run fill 392 57 -10 392 58 -10 dirt
execute in minecraft:overworld run setblock 392 59 -10 gravel
execute in minecraft:overworld run fill 392 60 -10 392 144 -10 air
execute in minecraft:overworld run fill 392 60 -10 392 64 -10 water
execute in minecraft:overworld run fill 392 58 -9 392 55 -9 stone
execute in minecraft:overworld run fill 392 56 -9 392 57 -9 dirt
execute in minecraft:overworld run setblock 392 58 -9 gravel
execute in minecraft:overworld run fill 392 59 -9 392 144 -9 air
execute in minecraft:overworld run fill 392 59 -9 392 64 -9 water
execute in minecraft:overworld run fill 392 58 -8 392 55 -8 stone
execute in minecraft:overworld run fill 392 56 -8 392 57 -8 dirt
execute in minecraft:overworld run setblock 392 58 -8 gravel
execute in minecraft:overworld run fill 392 59 -8 392 144 -8 air
execute in minecraft:overworld run fill 392 59 -8 392 64 -8 water
execute in minecraft:overworld run fill 392 58 -7 392 55 -7 stone
execute in minecraft:overworld run fill 392 56 -7 392 57 -7 dirt
execute in minecraft:overworld run setblock 392 58 -7 gravel
execute in minecraft:overworld run fill 392 59 -7 392 144 -7 air
execute in minecraft:overworld run fill 392 59 -7 392 64 -7 water
execute in minecraft:overworld run fill 392 58 -6 392 55 -6 stone
execute in minecraft:overworld run fill 392 56 -6 392 57 -6 dirt
execute in minecraft:overworld run setblock 392 58 -6 gravel
execute in minecraft:overworld run fill 392 59 -6 392 144 -6 air
execute in minecraft:overworld run fill 392 59 -6 392 64 -6 water
execute in minecraft:overworld run fill 392 58 -5 392 54 -5 stone
execute in minecraft:overworld run fill 392 55 -5 392 56 -5 dirt
execute in minecraft:overworld run setblock 392 57 -5 gravel
execute in minecraft:overworld run fill 392 58 -5 392 144 -5 air
execute in minecraft:overworld run fill 392 58 -5 392 64 -5 water
execute in minecraft:overworld run fill 392 58 -4 392 54 -4 stone
execute in minecraft:overworld run fill 392 55 -4 392 56 -4 dirt
execute in minecraft:overworld run setblock 392 57 -4 gravel
schedule function blade_gallery:random/battlefield/part_88 1t replace
