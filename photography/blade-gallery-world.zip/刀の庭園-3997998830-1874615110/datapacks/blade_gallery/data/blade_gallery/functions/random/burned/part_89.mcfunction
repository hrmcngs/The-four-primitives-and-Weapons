execute in minecraft:overworld run setblock 264 60 14 gravel
execute in minecraft:overworld run fill 264 61 14 264 144 14 air
execute in minecraft:overworld run fill 264 61 14 264 64 14 water
execute in minecraft:overworld run fill 264 58 15 264 57 15 stone
execute in minecraft:overworld run fill 264 58 15 264 59 15 dirt
execute in minecraft:overworld run setblock 264 60 15 gravel
execute in minecraft:overworld run fill 264 61 15 264 144 15 air
execute in minecraft:overworld run fill 264 61 15 264 64 15 water
execute in minecraft:overworld run fill 264 58 16 264 57 16 stone
execute in minecraft:overworld run fill 264 58 16 264 59 16 dirt
execute in minecraft:overworld run setblock 264 60 16 gravel
execute in minecraft:overworld run fill 264 61 16 264 144 16 air
execute in minecraft:overworld run fill 264 61 16 264 64 16 water
execute in minecraft:overworld run fill 264 58 17 264 57 17 stone
execute in minecraft:overworld run fill 264 58 17 264 59 17 dirt
execute in minecraft:overworld run setblock 264 60 17 gravel
execute in minecraft:overworld run fill 264 61 17 264 144 17 air
execute in minecraft:overworld run fill 264 61 17 264 64 17 water
execute in minecraft:overworld run fill 264 58 18 264 57 18 stone
execute in minecraft:overworld run fill 264 58 18 264 59 18 dirt
execute in minecraft:overworld run setblock 264 60 18 gravel
execute in minecraft:overworld run fill 264 61 18 264 144 18 air
execute in minecraft:overworld run fill 264 61 18 264 64 18 water
execute in minecraft:overworld run fill 264 58 19 264 57 19 stone
execute in minecraft:overworld run fill 264 58 19 264 59 19 dirt
execute in minecraft:overworld run setblock 264 60 19 gravel
execute in minecraft:overworld run fill 264 61 19 264 144 19 air
execute in minecraft:overworld run fill 264 61 19 264 64 19 water
execute in minecraft:overworld run fill 264 58 20 264 57 20 stone
execute in minecraft:overworld run fill 264 58 20 264 59 20 dirt
execute in minecraft:overworld run setblock 264 60 20 gravel
execute in minecraft:overworld run fill 264 61 20 264 144 20 air
execute in minecraft:overworld run fill 264 61 20 264 64 20 water
execute in minecraft:overworld run fill 264 58 21 264 57 21 stone
execute in minecraft:overworld run fill 264 58 21 264 59 21 dirt
execute in minecraft:overworld run setblock 264 60 21 gravel
execute in minecraft:overworld run fill 264 61 21 264 144 21 air
execute in minecraft:overworld run fill 264 61 21 264 64 21 water
execute in minecraft:overworld run fill 264 58 22 264 57 22 stone
execute in minecraft:overworld run fill 264 58 22 264 59 22 dirt
execute in minecraft:overworld run setblock 264 60 22 gravel
execute in minecraft:overworld run fill 264 61 22 264 144 22 air
execute in minecraft:overworld run fill 264 61 22 264 64 22 water
execute in minecraft:overworld run fill 264 58 23 264 56 23 stone
execute in minecraft:overworld run fill 264 57 23 264 58 23 dirt
execute in minecraft:overworld run setblock 264 59 23 gravel
execute in minecraft:overworld run fill 264 60 23 264 144 23 air
execute in minecraft:overworld run fill 264 60 23 264 64 23 water
execute in minecraft:overworld run fill 264 58 24 264 56 24 stone
execute in minecraft:overworld run fill 264 57 24 264 58 24 dirt
execute in minecraft:overworld run setblock 264 59 24 gravel
execute in minecraft:overworld run fill 264 60 24 264 144 24 air
execute in minecraft:overworld run fill 264 60 24 264 64 24 water
execute in minecraft:overworld run fill 264 58 25 264 56 25 stone
execute in minecraft:overworld run fill 264 57 25 264 58 25 dirt
execute in minecraft:overworld run setblock 264 59 25 gravel
execute in minecraft:overworld run fill 264 60 25 264 144 25 air
execute in minecraft:overworld run fill 264 60 25 264 64 25 water
execute in minecraft:overworld run fill 264 58 26 264 56 26 stone
execute in minecraft:overworld run fill 264 57 26 264 58 26 dirt
execute in minecraft:overworld run setblock 264 59 26 gravel
execute in minecraft:overworld run fill 264 60 26 264 144 26 air
execute in minecraft:overworld run fill 264 60 26 264 64 26 water
execute in minecraft:overworld run fill 264 58 27 264 56 27 stone
execute in minecraft:overworld run fill 264 57 27 264 58 27 dirt
execute in minecraft:overworld run setblock 264 59 27 gravel
execute in minecraft:overworld run fill 264 60 27 264 144 27 air
execute in minecraft:overworld run fill 264 60 27 264 64 27 water
execute in minecraft:overworld run fill 264 58 28 264 56 28 stone
execute in minecraft:overworld run fill 264 57 28 264 58 28 dirt
execute in minecraft:overworld run setblock 264 59 28 gravel
execute in minecraft:overworld run fill 264 60 28 264 144 28 air
execute in minecraft:overworld run fill 264 60 28 264 64 28 water
execute in minecraft:overworld run fill 264 58 29 264 55 29 stone
execute in minecraft:overworld run fill 264 56 29 264 57 29 dirt
execute in minecraft:overworld run setblock 264 58 29 gravel
execute in minecraft:overworld run fill 264 59 29 264 144 29 air
execute in minecraft:overworld run fill 264 59 29 264 64 29 water
execute in minecraft:overworld run fill 264 58 30 264 55 30 stone
execute in minecraft:overworld run fill 264 56 30 264 57 30 dirt
execute in minecraft:overworld run setblock 264 58 30 gravel
execute in minecraft:overworld run fill 264 59 30 264 144 30 air
execute in minecraft:overworld run fill 264 59 30 264 64 30 water
execute in minecraft:overworld run fill 264 58 31 264 55 31 stone
execute in minecraft:overworld run fill 264 56 31 264 57 31 dirt
execute in minecraft:overworld run setblock 264 58 31 gravel
execute in minecraft:overworld run fill 264 59 31 264 144 31 air
execute in minecraft:overworld run fill 264 59 31 264 64 31 water
execute in minecraft:overworld run fill 264 58 32 264 55 32 stone
execute in minecraft:overworld run fill 264 56 32 264 57 32 dirt
execute in minecraft:overworld run setblock 264 58 32 gravel
execute in minecraft:overworld run fill 264 59 32 264 144 32 air
execute in minecraft:overworld run fill 264 59 32 264 64 32 water
execute in minecraft:overworld run fill 264 58 33 264 55 33 stone
execute in minecraft:overworld run fill 264 56 33 264 57 33 dirt
execute in minecraft:overworld run setblock 264 58 33 gravel
execute in minecraft:overworld run fill 264 59 33 264 144 33 air
execute in minecraft:overworld run fill 264 59 33 264 64 33 water
execute in minecraft:overworld run fill 264 58 34 264 55 34 stone
execute in minecraft:overworld run fill 264 56 34 264 57 34 dirt
execute in minecraft:overworld run setblock 264 58 34 gravel
execute in minecraft:overworld run fill 264 59 34 264 144 34 air
execute in minecraft:overworld run fill 264 59 34 264 64 34 water
execute in minecraft:overworld run fill 264 58 35 264 55 35 stone
execute in minecraft:overworld run fill 264 56 35 264 57 35 dirt
execute in minecraft:overworld run setblock 264 58 35 gravel
execute in minecraft:overworld run fill 264 59 35 264 144 35 air
execute in minecraft:overworld run fill 264 59 35 264 64 35 water
execute in minecraft:overworld run fill 264 58 36 264 55 36 stone
execute in minecraft:overworld run fill 264 56 36 264 57 36 dirt
execute in minecraft:overworld run setblock 264 58 36 gravel
execute in minecraft:overworld run fill 264 59 36 264 144 36 air
execute in minecraft:overworld run fill 264 59 36 264 64 36 water
execute in minecraft:overworld run fill 264 58 37 264 55 37 stone
execute in minecraft:overworld run fill 264 56 37 264 57 37 dirt
execute in minecraft:overworld run setblock 264 58 37 gravel
execute in minecraft:overworld run fill 264 59 37 264 144 37 air
execute in minecraft:overworld run fill 264 59 37 264 64 37 water
execute in minecraft:overworld run fill 264 58 38 264 56 38 stone
execute in minecraft:overworld run fill 264 57 38 264 58 38 dirt
execute in minecraft:overworld run setblock 264 59 38 gravel
execute in minecraft:overworld run fill 264 60 38 264 144 38 air
execute in minecraft:overworld run fill 264 60 38 264 64 38 water
execute in minecraft:overworld run fill 264 58 39 264 57 39 stone
execute in minecraft:overworld run fill 264 58 39 264 59 39 dirt
execute in minecraft:overworld run setblock 264 60 39 gravel
execute in minecraft:overworld run fill 264 61 39 264 144 39 air
execute in minecraft:overworld run fill 264 61 39 264 64 39 water
execute in minecraft:overworld run fill 264 58 40 264 57 40 stone
execute in minecraft:overworld run fill 264 58 40 264 59 40 dirt
execute in minecraft:overworld run setblock 264 60 40 gravel
execute in minecraft:overworld run fill 264 61 40 264 144 40 air
execute in minecraft:overworld run fill 264 61 40 264 64 40 water
execute in minecraft:overworld run fill 264 58 41 264 58 41 stone
execute in minecraft:overworld run fill 264 59 41 264 60 41 dirt
execute in minecraft:overworld run setblock 264 61 41 gravel
execute in minecraft:overworld run fill 264 62 41 264 144 41 air
execute in minecraft:overworld run fill 264 62 41 264 64 41 water
execute in minecraft:overworld run fill 264 58 42 264 59 42 stone
execute in minecraft:overworld run fill 264 60 42 264 61 42 dirt
execute in minecraft:overworld run setblock 264 62 42 gravel
execute in minecraft:overworld run fill 264 63 42 264 144 42 air
execute in minecraft:overworld run fill 264 63 42 264 64 42 water
execute in minecraft:overworld run fill 264 58 43 264 60 43 stone
execute in minecraft:overworld run fill 264 61 43 264 62 43 dirt
execute in minecraft:overworld run setblock 264 63 43 gravel
execute in minecraft:overworld run fill 264 64 43 264 144 43 air
execute in minecraft:overworld run fill 264 64 43 264 64 43 water
execute in minecraft:overworld run fill 264 58 44 264 60 44 stone
execute in minecraft:overworld run fill 264 61 44 264 62 44 dirt
execute in minecraft:overworld run setblock 264 63 44 gravel
execute in minecraft:overworld run fill 264 64 44 264 144 44 air
execute in minecraft:overworld run fill 264 64 44 264 64 44 water
execute in minecraft:overworld run fill 264 58 45 264 60 45 stone
execute in minecraft:overworld run fill 264 61 45 264 62 45 dirt
execute in minecraft:overworld run setblock 264 63 45 gravel
execute in minecraft:overworld run fill 264 64 45 264 144 45 air
execute in minecraft:overworld run fill 264 64 45 264 64 45 water
execute in minecraft:overworld run fill 264 58 46 264 61 46 stone
execute in minecraft:overworld run fill 264 62 46 264 63 46 dirt
execute in minecraft:overworld run setblock 264 64 46 coarse_dirt
execute in minecraft:overworld run fill 264 65 46 264 144 46 air
execute in minecraft:overworld run fill 264 58 47 264 61 47 stone
execute in minecraft:overworld run fill 264 62 47 264 63 47 dirt
execute in minecraft:overworld run setblock 264 64 47 coarse_dirt
execute in minecraft:overworld run fill 264 65 47 264 144 47 air
execute in minecraft:overworld run fill 265 58 -48 265 61 -48 stone
execute in minecraft:overworld run fill 265 62 -48 265 63 -48 dirt
execute in minecraft:overworld run setblock 265 64 -48 coarse_dirt
execute in minecraft:overworld run fill 265 65 -48 265 144 -48 air
execute in minecraft:overworld run fill 265 58 -47 265 63 -47 stone
execute in minecraft:overworld run fill 265 64 -47 265 65 -47 dirt
execute in minecraft:overworld run setblock 265 66 -47 grass_block
execute in minecraft:overworld run fill 265 67 -47 265 144 -47 air
execute in minecraft:overworld run fill 265 58 -46 265 65 -46 stone
execute in minecraft:overworld run fill 265 66 -46 265 67 -46 dirt
execute in minecraft:overworld run setblock 265 68 -46 grass_block
execute in minecraft:overworld run fill 265 69 -46 265 144 -46 air
execute in minecraft:overworld run fill 265 58 -45 265 67 -45 stone
execute in minecraft:overworld run fill 265 68 -45 265 69 -45 dirt
execute in minecraft:overworld run setblock 265 70 -45 coarse_dirt
execute in minecraft:overworld run fill 265 71 -45 265 144 -45 air
execute in minecraft:overworld run fill 265 58 -44 265 68 -44 stone
execute in minecraft:overworld run fill 265 69 -44 265 70 -44 dirt
execute in minecraft:overworld run setblock 265 71 -44 coarse_dirt
execute in minecraft:overworld run fill 265 72 -44 265 144 -44 air
execute in minecraft:overworld run fill 265 58 -43 265 70 -43 stone
execute in minecraft:overworld run fill 265 71 -43 265 72 -43 dirt
execute in minecraft:overworld run setblock 265 73 -43 grass_block
execute in minecraft:overworld run fill 265 74 -43 265 144 -43 air
execute in minecraft:overworld run fill 265 58 -42 265 72 -42 stone
execute in minecraft:overworld run fill 265 73 -42 265 74 -42 dirt
execute in minecraft:overworld run setblock 265 75 -42 coarse_dirt
execute in minecraft:overworld run fill 265 76 -42 265 144 -42 air
execute in minecraft:overworld run fill 265 58 -41 265 73 -41 stone
execute in minecraft:overworld run fill 265 74 -41 265 75 -41 dirt
execute in minecraft:overworld run setblock 265 76 -41 coarse_dirt
execute in minecraft:overworld run fill 265 77 -41 265 144 -41 air
execute in minecraft:overworld run fill 265 58 -40 265 75 -40 stone
execute in minecraft:overworld run fill 265 76 -40 265 77 -40 dirt
execute in minecraft:overworld run setblock 265 78 -40 grass_block
execute in minecraft:overworld run fill 265 79 -40 265 144 -40 air
execute in minecraft:overworld run fill 265 58 -39 265 77 -39 stone
execute in minecraft:overworld run fill 265 78 -39 265 79 -39 dirt
execute in minecraft:overworld run setblock 265 80 -39 coarse_dirt
execute in minecraft:overworld run fill 265 81 -39 265 144 -39 air
execute in minecraft:overworld run fill 265 58 -38 265 78 -38 stone
execute in minecraft:overworld run fill 265 79 -38 265 80 -38 dirt
execute in minecraft:overworld run setblock 265 81 -38 coarse_dirt
execute in minecraft:overworld run fill 265 82 -38 265 144 -38 air
execute in minecraft:overworld run fill 265 58 -37 265 78 -37 stone
execute in minecraft:overworld run fill 265 79 -37 265 80 -37 dirt
execute in minecraft:overworld run setblock 265 81 -37 grass_block
execute in minecraft:overworld run fill 265 82 -37 265 144 -37 air
execute in minecraft:overworld run fill 265 58 -36 265 78 -36 stone
execute in minecraft:overworld run fill 265 79 -36 265 80 -36 dirt
execute in minecraft:overworld run setblock 265 81 -36 coarse_dirt
execute in minecraft:overworld run fill 265 82 -36 265 144 -36 air
execute in minecraft:overworld run fill 265 58 -35 265 77 -35 stone
execute in minecraft:overworld run fill 265 78 -35 265 79 -35 dirt
execute in minecraft:overworld run setblock 265 80 -35 grass_block
execute in minecraft:overworld run fill 265 81 -35 265 144 -35 air
execute in minecraft:overworld run fill 265 58 -34 265 77 -34 stone
execute in minecraft:overworld run fill 265 78 -34 265 79 -34 dirt
execute in minecraft:overworld run setblock 265 80 -34 grass_block
execute in minecraft:overworld run fill 265 81 -34 265 144 -34 air
execute in minecraft:overworld run fill 265 58 -33 265 77 -33 stone
execute in minecraft:overworld run fill 265 78 -33 265 79 -33 dirt
execute in minecraft:overworld run setblock 265 80 -33 grass_block
execute in minecraft:overworld run fill 265 81 -33 265 144 -33 air
execute in minecraft:overworld run fill 265 58 -32 265 77 -32 stone
execute in minecraft:overworld run fill 265 78 -32 265 79 -32 dirt
execute in minecraft:overworld run setblock 265 80 -32 coarse_dirt
execute in minecraft:overworld run fill 265 81 -32 265 144 -32 air
execute in minecraft:overworld run fill 265 58 -31 265 76 -31 stone
execute in minecraft:overworld run fill 265 77 -31 265 78 -31 dirt
execute in minecraft:overworld run setblock 265 79 -31 coarse_dirt
execute in minecraft:overworld run fill 265 80 -31 265 144 -31 air
execute in minecraft:overworld run fill 265 58 -30 265 76 -30 stone
execute in minecraft:overworld run fill 265 77 -30 265 78 -30 dirt
execute in minecraft:overworld run setblock 265 79 -30 coarse_dirt
execute in minecraft:overworld run fill 265 80 -30 265 144 -30 air
execute in minecraft:overworld run fill 265 58 -29 265 76 -29 stone
execute in minecraft:overworld run fill 265 77 -29 265 78 -29 dirt
execute in minecraft:overworld run setblock 265 79 -29 grass_block
execute in minecraft:overworld run fill 265 80 -29 265 144 -29 air
execute in minecraft:overworld run fill 265 58 -28 265 75 -28 stone
execute in minecraft:overworld run fill 265 76 -28 265 77 -28 dirt
execute in minecraft:overworld run setblock 265 78 -28 grass_block
execute in minecraft:overworld run fill 265 79 -28 265 144 -28 air
execute in minecraft:overworld run fill 265 58 -27 265 75 -27 stone
execute in minecraft:overworld run fill 265 76 -27 265 77 -27 dirt
execute in minecraft:overworld run setblock 265 78 -27 coarse_dirt
execute in minecraft:overworld run fill 265 79 -27 265 144 -27 air
execute in minecraft:overworld run fill 265 58 -26 265 74 -26 stone
execute in minecraft:overworld run fill 265 75 -26 265 76 -26 dirt
schedule function blade_gallery:random/burned/part_90 1t replace
