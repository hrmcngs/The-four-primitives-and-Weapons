execute in minecraft:overworld run fill 348 71 0 348 144 0 air
execute in minecraft:overworld run setblock 348 71 0 grass
execute in minecraft:overworld run fill 348 58 1 348 67 1 stone
execute in minecraft:overworld run fill 348 68 1 348 69 1 dirt
execute in minecraft:overworld run setblock 348 70 1 coarse_dirt
execute in minecraft:overworld run fill 348 71 1 348 144 1 air
execute in minecraft:overworld run fill 348 58 2 348 67 2 stone
execute in minecraft:overworld run fill 348 68 2 348 69 2 dirt
execute in minecraft:overworld run setblock 348 70 2 coarse_dirt
execute in minecraft:overworld run fill 348 71 2 348 144 2 air
execute in minecraft:overworld run fill 348 58 3 348 67 3 stone
execute in minecraft:overworld run fill 348 68 3 348 69 3 dirt
execute in minecraft:overworld run setblock 348 70 3 grass_block
execute in minecraft:overworld run fill 348 71 3 348 144 3 air
execute in minecraft:overworld run fill 348 58 4 348 67 4 stone
execute in minecraft:overworld run fill 348 68 4 348 69 4 dirt
execute in minecraft:overworld run setblock 348 70 4 coarse_dirt
execute in minecraft:overworld run fill 348 71 4 348 144 4 air
execute in minecraft:overworld run fill 348 58 5 348 67 5 stone
execute in minecraft:overworld run fill 348 68 5 348 69 5 dirt
execute in minecraft:overworld run setblock 348 70 5 grass_block
execute in minecraft:overworld run fill 348 71 5 348 144 5 air
execute in minecraft:overworld run fill 348 58 6 348 67 6 stone
execute in minecraft:overworld run fill 348 68 6 348 69 6 dirt
execute in minecraft:overworld run setblock 348 70 6 coarse_dirt
execute in minecraft:overworld run fill 348 71 6 348 144 6 air
execute in minecraft:overworld run setblock 348 71 6 grass
execute in minecraft:overworld run fill 348 58 7 348 67 7 stone
execute in minecraft:overworld run fill 348 68 7 348 69 7 dirt
execute in minecraft:overworld run setblock 348 70 7 coarse_dirt
execute in minecraft:overworld run fill 348 71 7 348 144 7 air
execute in minecraft:overworld run fill 348 58 8 348 67 8 stone
execute in minecraft:overworld run fill 348 68 8 348 69 8 dirt
execute in minecraft:overworld run setblock 348 70 8 grass_block
execute in minecraft:overworld run fill 348 71 8 348 144 8 air
execute in minecraft:overworld run fill 348 58 9 348 67 9 stone
execute in minecraft:overworld run fill 348 68 9 348 69 9 dirt
execute in minecraft:overworld run setblock 348 70 9 grass_block
execute in minecraft:overworld run fill 348 71 9 348 144 9 air
execute in minecraft:overworld run fill 348 58 10 348 67 10 stone
execute in minecraft:overworld run fill 348 68 10 348 69 10 dirt
execute in minecraft:overworld run setblock 348 70 10 coarse_dirt
execute in minecraft:overworld run fill 348 71 10 348 144 10 air
execute in minecraft:overworld run fill 348 58 11 348 67 11 stone
execute in minecraft:overworld run fill 348 68 11 348 69 11 dirt
execute in minecraft:overworld run setblock 348 70 11 coarse_dirt
execute in minecraft:overworld run fill 348 71 11 348 144 11 air
execute in minecraft:overworld run fill 348 58 12 348 66 12 stone
execute in minecraft:overworld run fill 348 67 12 348 68 12 dirt
execute in minecraft:overworld run setblock 348 69 12 grass_block
execute in minecraft:overworld run fill 348 70 12 348 144 12 air
execute in minecraft:overworld run fill 348 58 13 348 66 13 stone
execute in minecraft:overworld run fill 348 67 13 348 68 13 dirt
execute in minecraft:overworld run setblock 348 69 13 coarse_dirt
execute in minecraft:overworld run fill 348 70 13 348 144 13 air
execute in minecraft:overworld run fill 348 58 14 348 66 14 stone
execute in minecraft:overworld run fill 348 67 14 348 68 14 dirt
execute in minecraft:overworld run setblock 348 69 14 coarse_dirt
execute in minecraft:overworld run fill 348 70 14 348 144 14 air
execute in minecraft:overworld run fill 348 58 15 348 65 15 stone
execute in minecraft:overworld run fill 348 66 15 348 67 15 dirt
execute in minecraft:overworld run setblock 348 68 15 coarse_dirt
execute in minecraft:overworld run fill 348 69 15 348 144 15 air
execute in minecraft:overworld run fill 348 58 16 348 65 16 stone
execute in minecraft:overworld run fill 348 66 16 348 67 16 dirt
execute in minecraft:overworld run setblock 348 68 16 grass_block
execute in minecraft:overworld run fill 348 69 16 348 144 16 air
execute in minecraft:overworld run fill 348 58 17 348 65 17 stone
execute in minecraft:overworld run fill 348 66 17 348 67 17 dirt
execute in minecraft:overworld run setblock 348 68 17 grass_block
execute in minecraft:overworld run fill 348 69 17 348 144 17 air
execute in minecraft:overworld run fill 348 58 18 348 65 18 stone
execute in minecraft:overworld run fill 348 66 18 348 67 18 dirt
execute in minecraft:overworld run setblock 348 68 18 grass_block
execute in minecraft:overworld run fill 348 69 18 348 144 18 air
execute in minecraft:overworld run fill 348 58 19 348 65 19 stone
execute in minecraft:overworld run fill 348 66 19 348 67 19 dirt
execute in minecraft:overworld run setblock 348 68 19 coarse_dirt
execute in minecraft:overworld run fill 348 69 19 348 144 19 air
execute in minecraft:overworld run fill 348 58 20 348 65 20 stone
execute in minecraft:overworld run fill 348 66 20 348 67 20 dirt
execute in minecraft:overworld run setblock 348 68 20 coarse_dirt
execute in minecraft:overworld run fill 348 69 20 348 144 20 air
execute in minecraft:overworld run fill 348 58 21 348 65 21 stone
execute in minecraft:overworld run fill 348 66 21 348 67 21 dirt
execute in minecraft:overworld run setblock 348 68 21 coarse_dirt
execute in minecraft:overworld run fill 348 69 21 348 144 21 air
execute in minecraft:overworld run fill 348 58 22 348 66 22 stone
execute in minecraft:overworld run fill 348 67 22 348 68 22 dirt
execute in minecraft:overworld run setblock 348 69 22 grass_block
execute in minecraft:overworld run fill 348 70 22 348 144 22 air
execute in minecraft:overworld run fill 348 58 23 348 66 23 stone
execute in minecraft:overworld run fill 348 67 23 348 68 23 dirt
execute in minecraft:overworld run setblock 348 69 23 coarse_dirt
execute in minecraft:overworld run fill 348 70 23 348 144 23 air
execute in minecraft:overworld run fill 348 58 24 348 66 24 stone
execute in minecraft:overworld run fill 348 67 24 348 68 24 dirt
execute in minecraft:overworld run setblock 348 69 24 coarse_dirt
execute in minecraft:overworld run fill 348 70 24 348 144 24 air
execute in minecraft:overworld run fill 348 58 25 348 67 25 stone
execute in minecraft:overworld run fill 348 68 25 348 69 25 dirt
execute in minecraft:overworld run setblock 348 70 25 coarse_dirt
execute in minecraft:overworld run fill 348 71 25 348 144 25 air
execute in minecraft:overworld run fill 348 58 26 348 67 26 stone
execute in minecraft:overworld run fill 348 68 26 348 69 26 dirt
execute in minecraft:overworld run setblock 348 70 26 coarse_dirt
execute in minecraft:overworld run fill 348 71 26 348 144 26 air
execute in minecraft:overworld run fill 348 58 27 348 67 27 stone
execute in minecraft:overworld run fill 348 68 27 348 69 27 dirt
execute in minecraft:overworld run setblock 348 70 27 grass_block
execute in minecraft:overworld run fill 348 71 27 348 144 27 air
execute in minecraft:overworld run fill 348 58 28 348 67 28 stone
execute in minecraft:overworld run fill 348 68 28 348 69 28 dirt
execute in minecraft:overworld run setblock 348 70 28 coarse_dirt
execute in minecraft:overworld run fill 348 71 28 348 144 28 air
execute in minecraft:overworld run fill 348 58 29 348 67 29 stone
execute in minecraft:overworld run fill 348 68 29 348 69 29 dirt
execute in minecraft:overworld run setblock 348 70 29 coarse_dirt
execute in minecraft:overworld run fill 348 71 29 348 144 29 air
execute in minecraft:overworld run setblock 348 71 29 grass
execute in minecraft:overworld run fill 348 58 30 348 67 30 stone
execute in minecraft:overworld run fill 348 68 30 348 69 30 dirt
execute in minecraft:overworld run setblock 348 70 30 coarse_dirt
execute in minecraft:overworld run fill 348 71 30 348 144 30 air
execute in minecraft:overworld run fill 348 58 31 348 66 31 stone
execute in minecraft:overworld run fill 348 67 31 348 68 31 dirt
execute in minecraft:overworld run setblock 348 69 31 grass_block
execute in minecraft:overworld run fill 348 70 31 348 144 31 air
execute in minecraft:overworld run fill 348 58 32 348 66 32 stone
execute in minecraft:overworld run fill 348 67 32 348 68 32 dirt
execute in minecraft:overworld run setblock 348 69 32 coarse_dirt
execute in minecraft:overworld run fill 348 70 32 348 144 32 air
execute in minecraft:overworld run fill 348 58 33 348 66 33 stone
execute in minecraft:overworld run fill 348 67 33 348 68 33 dirt
execute in minecraft:overworld run setblock 348 69 33 coarse_dirt
execute in minecraft:overworld run fill 348 70 33 348 144 33 air
execute in minecraft:overworld run fill 348 58 34 348 66 34 stone
execute in minecraft:overworld run fill 348 67 34 348 68 34 dirt
execute in minecraft:overworld run setblock 348 69 34 coarse_dirt
execute in minecraft:overworld run fill 348 70 34 348 144 34 air
execute in minecraft:overworld run fill 348 58 35 348 66 35 stone
execute in minecraft:overworld run fill 348 67 35 348 68 35 dirt
execute in minecraft:overworld run setblock 348 69 35 grass_block
execute in minecraft:overworld run fill 348 70 35 348 144 35 air
execute in minecraft:overworld run fill 348 58 36 348 66 36 stone
execute in minecraft:overworld run fill 348 67 36 348 68 36 dirt
execute in minecraft:overworld run setblock 348 69 36 coarse_dirt
execute in minecraft:overworld run fill 348 70 36 348 144 36 air
execute in minecraft:overworld run fill 348 58 37 348 66 37 stone
execute in minecraft:overworld run fill 348 67 37 348 68 37 dirt
execute in minecraft:overworld run setblock 348 69 37 coarse_dirt
execute in minecraft:overworld run fill 348 70 37 348 144 37 air
execute in minecraft:overworld run fill 348 58 38 348 66 38 stone
execute in minecraft:overworld run fill 348 67 38 348 68 38 dirt
execute in minecraft:overworld run setblock 348 69 38 grass_block
execute in minecraft:overworld run fill 348 70 38 348 144 38 air
execute in minecraft:overworld run fill 348 58 39 348 65 39 stone
execute in minecraft:overworld run fill 348 66 39 348 67 39 dirt
execute in minecraft:overworld run setblock 348 68 39 coarse_dirt
execute in minecraft:overworld run fill 348 69 39 348 144 39 air
execute in minecraft:overworld run fill 348 58 40 348 65 40 stone
execute in minecraft:overworld run fill 348 66 40 348 67 40 dirt
execute in minecraft:overworld run setblock 348 68 40 coarse_dirt
execute in minecraft:overworld run fill 348 69 40 348 144 40 air
execute in minecraft:overworld run fill 348 58 41 348 64 41 stone
execute in minecraft:overworld run fill 348 65 41 348 66 41 dirt
execute in minecraft:overworld run setblock 348 67 41 grass_block
execute in minecraft:overworld run fill 348 68 41 348 144 41 air
execute in minecraft:overworld run fill 348 58 42 348 64 42 stone
execute in minecraft:overworld run fill 348 65 42 348 66 42 dirt
execute in minecraft:overworld run setblock 348 67 42 coarse_dirt
execute in minecraft:overworld run fill 348 68 42 348 144 42 air
execute in minecraft:overworld run fill 348 58 43 348 63 43 stone
execute in minecraft:overworld run fill 348 64 43 348 65 43 dirt
execute in minecraft:overworld run setblock 348 66 43 grass_block
execute in minecraft:overworld run fill 348 67 43 348 144 43 air
execute in minecraft:overworld run fill 348 58 44 348 63 44 stone
execute in minecraft:overworld run fill 348 64 44 348 65 44 dirt
execute in minecraft:overworld run setblock 348 66 44 coarse_dirt
execute in minecraft:overworld run fill 348 67 44 348 144 44 air
execute in minecraft:overworld run fill 348 58 45 348 62 45 stone
execute in minecraft:overworld run fill 348 63 45 348 64 45 dirt
execute in minecraft:overworld run setblock 348 65 45 coarse_dirt
execute in minecraft:overworld run fill 348 66 45 348 144 45 air
execute in minecraft:overworld run fill 348 58 46 348 62 46 stone
execute in minecraft:overworld run fill 348 63 46 348 64 46 dirt
execute in minecraft:overworld run setblock 348 65 46 grass_block
execute in minecraft:overworld run fill 348 66 46 348 144 46 air
execute in minecraft:overworld run fill 348 58 47 348 61 47 stone
execute in minecraft:overworld run fill 348 62 47 348 63 47 dirt
execute in minecraft:overworld run setblock 348 64 47 grass_block
execute in minecraft:overworld run fill 348 65 47 348 144 47 air
execute in minecraft:overworld run fill 349 58 -48 349 61 -48 stone
execute in minecraft:overworld run fill 349 62 -48 349 63 -48 dirt
execute in minecraft:overworld run setblock 349 64 -48 coarse_dirt
execute in minecraft:overworld run fill 349 65 -48 349 144 -48 air
execute in minecraft:overworld run fill 349 58 -47 349 63 -47 stone
execute in minecraft:overworld run fill 349 64 -47 349 65 -47 dirt
execute in minecraft:overworld run setblock 349 66 -47 coarse_dirt
execute in minecraft:overworld run fill 349 67 -47 349 144 -47 air
execute in minecraft:overworld run fill 349 58 -46 349 65 -46 stone
execute in minecraft:overworld run fill 349 66 -46 349 67 -46 dirt
execute in minecraft:overworld run setblock 349 68 -46 grass_block
execute in minecraft:overworld run fill 349 69 -46 349 144 -46 air
execute in minecraft:overworld run fill 349 58 -45 349 67 -45 stone
execute in minecraft:overworld run fill 349 68 -45 349 69 -45 dirt
execute in minecraft:overworld run setblock 349 70 -45 coarse_dirt
execute in minecraft:overworld run fill 349 71 -45 349 144 -45 air
execute in minecraft:overworld run fill 349 58 -44 349 68 -44 stone
execute in minecraft:overworld run fill 349 69 -44 349 70 -44 dirt
execute in minecraft:overworld run setblock 349 71 -44 coarse_dirt
execute in minecraft:overworld run fill 349 72 -44 349 144 -44 air
execute in minecraft:overworld run fill 349 58 -43 349 70 -43 stone
execute in minecraft:overworld run fill 349 71 -43 349 72 -43 dirt
execute in minecraft:overworld run setblock 349 73 -43 grass_block
execute in minecraft:overworld run fill 349 74 -43 349 144 -43 air
execute in minecraft:overworld run fill 349 58 -42 349 71 -42 stone
execute in minecraft:overworld run fill 349 72 -42 349 73 -42 dirt
execute in minecraft:overworld run setblock 349 74 -42 coarse_dirt
execute in minecraft:overworld run fill 349 75 -42 349 144 -42 air
execute in minecraft:overworld run fill 349 58 -41 349 73 -41 stone
execute in minecraft:overworld run fill 349 74 -41 349 75 -41 dirt
execute in minecraft:overworld run setblock 349 76 -41 coarse_dirt
execute in minecraft:overworld run fill 349 77 -41 349 144 -41 air
execute in minecraft:overworld run fill 349 58 -40 349 74 -40 stone
execute in minecraft:overworld run fill 349 75 -40 349 76 -40 dirt
execute in minecraft:overworld run setblock 349 77 -40 coarse_dirt
execute in minecraft:overworld run fill 349 78 -40 349 144 -40 air
execute in minecraft:overworld run fill 349 58 -39 349 75 -39 stone
execute in minecraft:overworld run fill 349 76 -39 349 77 -39 dirt
execute in minecraft:overworld run setblock 349 78 -39 coarse_dirt
execute in minecraft:overworld run fill 349 79 -39 349 144 -39 air
execute in minecraft:overworld run fill 349 58 -38 349 76 -38 stone
execute in minecraft:overworld run fill 349 77 -38 349 78 -38 dirt
execute in minecraft:overworld run setblock 349 79 -38 coarse_dirt
execute in minecraft:overworld run fill 349 80 -38 349 144 -38 air
execute in minecraft:overworld run fill 349 58 -37 349 75 -37 stone
execute in minecraft:overworld run fill 349 76 -37 349 77 -37 dirt
execute in minecraft:overworld run setblock 349 78 -37 coarse_dirt
execute in minecraft:overworld run fill 349 79 -37 349 144 -37 air
execute in minecraft:overworld run fill 349 58 -36 349 75 -36 stone
execute in minecraft:overworld run fill 349 76 -36 349 77 -36 dirt
execute in minecraft:overworld run setblock 349 78 -36 grass_block
execute in minecraft:overworld run fill 349 79 -36 349 144 -36 air
execute in minecraft:overworld run fill 349 58 -35 349 75 -35 stone
execute in minecraft:overworld run fill 349 76 -35 349 77 -35 dirt
execute in minecraft:overworld run setblock 349 78 -35 coarse_dirt
execute in minecraft:overworld run fill 349 79 -35 349 144 -35 air
execute in minecraft:overworld run setblock 349 79 -35 grass
execute in minecraft:overworld run fill 349 58 -34 349 74 -34 stone
execute in minecraft:overworld run fill 349 75 -34 349 76 -34 dirt
execute in minecraft:overworld run setblock 349 77 -34 grass_block
execute in minecraft:overworld run fill 349 78 -34 349 144 -34 air
execute in minecraft:overworld run fill 349 58 -33 349 74 -33 stone
execute in minecraft:overworld run fill 349 75 -33 349 76 -33 dirt
execute in minecraft:overworld run setblock 349 77 -33 coarse_dirt
schedule function blade_gallery:random/battlefield/part_20 1t replace
