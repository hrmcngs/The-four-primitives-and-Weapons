execute in minecraft:overworld run setblock 209 64 47 coarse_dirt
execute in minecraft:overworld run fill 209 65 47 209 144 47 air
execute in minecraft:overworld run fill 210 58 -48 210 61 -48 stone
execute in minecraft:overworld run fill 210 62 -48 210 63 -48 dirt
execute in minecraft:overworld run setblock 210 64 -48 grass_block
execute in minecraft:overworld run fill 210 65 -48 210 144 -48 air
execute in minecraft:overworld run fill 210 58 -47 210 63 -47 stone
execute in minecraft:overworld run fill 210 64 -47 210 65 -47 dirt
execute in minecraft:overworld run setblock 210 66 -47 grass_block
execute in minecraft:overworld run fill 210 67 -47 210 144 -47 air
execute in minecraft:overworld run fill 210 58 -46 210 64 -46 stone
execute in minecraft:overworld run fill 210 65 -46 210 66 -46 dirt
execute in minecraft:overworld run setblock 210 67 -46 grass_block
execute in minecraft:overworld run fill 210 68 -46 210 144 -46 air
execute in minecraft:overworld run fill 210 58 -45 210 64 -45 stone
execute in minecraft:overworld run fill 210 65 -45 210 66 -45 dirt
execute in minecraft:overworld run setblock 210 67 -45 coarse_dirt
execute in minecraft:overworld run fill 210 68 -45 210 144 -45 air
execute in minecraft:overworld run fill 210 58 -44 210 64 -44 stone
execute in minecraft:overworld run fill 210 65 -44 210 66 -44 dirt
execute in minecraft:overworld run setblock 210 67 -44 grass_block
execute in minecraft:overworld run fill 210 68 -44 210 144 -44 air
execute in minecraft:overworld run fill 210 58 -43 210 64 -43 stone
execute in minecraft:overworld run fill 210 65 -43 210 66 -43 dirt
execute in minecraft:overworld run setblock 210 67 -43 grass_block
execute in minecraft:overworld run fill 210 68 -43 210 144 -43 air
execute in minecraft:overworld run fill 210 58 -42 210 64 -42 stone
execute in minecraft:overworld run fill 210 65 -42 210 66 -42 dirt
execute in minecraft:overworld run setblock 210 67 -42 grass_block
execute in minecraft:overworld run fill 210 68 -42 210 144 -42 air
execute in minecraft:overworld run fill 210 58 -41 210 64 -41 stone
execute in minecraft:overworld run fill 210 65 -41 210 66 -41 dirt
execute in minecraft:overworld run setblock 210 67 -41 coarse_dirt
execute in minecraft:overworld run fill 210 68 -41 210 144 -41 air
execute in minecraft:overworld run fill 210 58 -40 210 64 -40 stone
execute in minecraft:overworld run fill 210 65 -40 210 66 -40 dirt
execute in minecraft:overworld run setblock 210 67 -40 coarse_dirt
execute in minecraft:overworld run fill 210 68 -40 210 144 -40 air
execute in minecraft:overworld run fill 210 58 -39 210 64 -39 stone
execute in minecraft:overworld run fill 210 65 -39 210 66 -39 dirt
execute in minecraft:overworld run setblock 210 67 -39 coarse_dirt
execute in minecraft:overworld run fill 210 68 -39 210 144 -39 air
execute in minecraft:overworld run fill 210 58 -38 210 63 -38 stone
execute in minecraft:overworld run fill 210 64 -38 210 65 -38 dirt
execute in minecraft:overworld run setblock 210 66 -38 coarse_dirt
execute in minecraft:overworld run fill 210 67 -38 210 144 -38 air
execute in minecraft:overworld run fill 210 58 -37 210 63 -37 stone
execute in minecraft:overworld run fill 210 64 -37 210 65 -37 dirt
execute in minecraft:overworld run setblock 210 66 -37 grass_block
execute in minecraft:overworld run fill 210 67 -37 210 144 -37 air
execute in minecraft:overworld run fill 210 58 -36 210 63 -36 stone
execute in minecraft:overworld run fill 210 64 -36 210 65 -36 dirt
execute in minecraft:overworld run setblock 210 66 -36 grass_block
execute in minecraft:overworld run fill 210 67 -36 210 144 -36 air
execute in minecraft:overworld run fill 210 58 -35 210 63 -35 stone
execute in minecraft:overworld run fill 210 64 -35 210 65 -35 dirt
execute in minecraft:overworld run setblock 210 66 -35 grass_block
execute in minecraft:overworld run fill 210 67 -35 210 144 -35 air
execute in minecraft:overworld run fill 210 58 -34 210 63 -34 stone
execute in minecraft:overworld run fill 210 64 -34 210 65 -34 dirt
execute in minecraft:overworld run setblock 210 66 -34 coarse_dirt
execute in minecraft:overworld run fill 210 67 -34 210 144 -34 air
execute in minecraft:overworld run fill 210 58 -33 210 63 -33 stone
execute in minecraft:overworld run fill 210 64 -33 210 65 -33 dirt
execute in minecraft:overworld run setblock 210 66 -33 coarse_dirt
execute in minecraft:overworld run fill 210 67 -33 210 144 -33 air
execute in minecraft:overworld run fill 210 58 -32 210 63 -32 stone
execute in minecraft:overworld run fill 210 64 -32 210 65 -32 dirt
execute in minecraft:overworld run setblock 210 66 -32 coarse_dirt
execute in minecraft:overworld run fill 210 67 -32 210 144 -32 air
execute in minecraft:overworld run fill 210 58 -31 210 63 -31 stone
execute in minecraft:overworld run fill 210 64 -31 210 65 -31 dirt
execute in minecraft:overworld run setblock 210 66 -31 coarse_dirt
execute in minecraft:overworld run fill 210 67 -31 210 144 -31 air
execute in minecraft:overworld run fill 210 58 -30 210 63 -30 stone
execute in minecraft:overworld run fill 210 64 -30 210 65 -30 dirt
execute in minecraft:overworld run setblock 210 66 -30 coarse_dirt
execute in minecraft:overworld run fill 210 67 -30 210 144 -30 air
execute in minecraft:overworld run fill 210 58 -29 210 62 -29 stone
execute in minecraft:overworld run fill 210 63 -29 210 64 -29 dirt
execute in minecraft:overworld run setblock 210 65 -29 coarse_dirt
execute in minecraft:overworld run fill 210 66 -29 210 144 -29 air
execute in minecraft:overworld run fill 210 58 -28 210 62 -28 stone
execute in minecraft:overworld run fill 210 63 -28 210 64 -28 dirt
execute in minecraft:overworld run setblock 210 65 -28 coarse_dirt
execute in minecraft:overworld run fill 210 66 -28 210 144 -28 air
execute in minecraft:overworld run fill 210 58 -27 210 62 -27 stone
execute in minecraft:overworld run fill 210 63 -27 210 64 -27 dirt
execute in minecraft:overworld run setblock 210 65 -27 grass_block
execute in minecraft:overworld run fill 210 66 -27 210 144 -27 air
execute in minecraft:overworld run fill 210 58 -26 210 62 -26 stone
execute in minecraft:overworld run fill 210 63 -26 210 64 -26 dirt
execute in minecraft:overworld run setblock 210 65 -26 coarse_dirt
execute in minecraft:overworld run fill 210 66 -26 210 144 -26 air
execute in minecraft:overworld run fill 210 58 -25 210 62 -25 stone
execute in minecraft:overworld run fill 210 63 -25 210 64 -25 dirt
execute in minecraft:overworld run setblock 210 65 -25 coarse_dirt
execute in minecraft:overworld run fill 210 66 -25 210 144 -25 air
execute in minecraft:overworld run fill 210 58 -24 210 62 -24 stone
execute in minecraft:overworld run fill 210 63 -24 210 64 -24 dirt
execute in minecraft:overworld run setblock 210 65 -24 coarse_dirt
execute in minecraft:overworld run fill 210 66 -24 210 144 -24 air
execute in minecraft:overworld run fill 210 58 -23 210 62 -23 stone
execute in minecraft:overworld run fill 210 63 -23 210 64 -23 dirt
execute in minecraft:overworld run setblock 210 65 -23 coarse_dirt
execute in minecraft:overworld run fill 210 66 -23 210 144 -23 air
execute in minecraft:overworld run fill 210 58 -22 210 62 -22 stone
execute in minecraft:overworld run fill 210 63 -22 210 64 -22 dirt
execute in minecraft:overworld run setblock 210 65 -22 grass_block
execute in minecraft:overworld run fill 210 66 -22 210 144 -22 air
execute in minecraft:overworld run fill 210 58 -21 210 62 -21 stone
execute in minecraft:overworld run fill 210 63 -21 210 64 -21 dirt
execute in minecraft:overworld run setblock 210 65 -21 coarse_dirt
execute in minecraft:overworld run fill 210 66 -21 210 144 -21 air
execute in minecraft:overworld run fill 210 58 -20 210 62 -20 stone
execute in minecraft:overworld run fill 210 63 -20 210 64 -20 dirt
execute in minecraft:overworld run setblock 210 65 -20 grass_block
execute in minecraft:overworld run fill 210 66 -20 210 144 -20 air
execute in minecraft:overworld run fill 210 58 -19 210 62 -19 stone
execute in minecraft:overworld run fill 210 63 -19 210 64 -19 dirt
execute in minecraft:overworld run setblock 210 65 -19 coarse_dirt
execute in minecraft:overworld run fill 210 66 -19 210 144 -19 air
execute in minecraft:overworld run fill 210 58 -18 210 62 -18 stone
execute in minecraft:overworld run fill 210 63 -18 210 64 -18 dirt
execute in minecraft:overworld run setblock 210 65 -18 coarse_dirt
execute in minecraft:overworld run fill 210 66 -18 210 144 -18 air
execute in minecraft:overworld run fill 210 58 -17 210 62 -17 stone
execute in minecraft:overworld run fill 210 63 -17 210 64 -17 dirt
execute in minecraft:overworld run setblock 210 65 -17 grass_block
execute in minecraft:overworld run fill 210 66 -17 210 144 -17 air
execute in minecraft:overworld run fill 210 58 -16 210 62 -16 stone
execute in minecraft:overworld run fill 210 63 -16 210 64 -16 dirt
execute in minecraft:overworld run setblock 210 65 -16 coarse_dirt
execute in minecraft:overworld run fill 210 66 -16 210 144 -16 air
execute in minecraft:overworld run fill 210 58 -15 210 62 -15 stone
execute in minecraft:overworld run fill 210 63 -15 210 64 -15 dirt
execute in minecraft:overworld run setblock 210 65 -15 grass_block
execute in minecraft:overworld run fill 210 66 -15 210 144 -15 air
execute in minecraft:overworld run fill 210 58 -14 210 62 -14 stone
execute in minecraft:overworld run fill 210 63 -14 210 64 -14 dirt
execute in minecraft:overworld run setblock 210 65 -14 coarse_dirt
execute in minecraft:overworld run fill 210 66 -14 210 144 -14 air
execute in minecraft:overworld run fill 210 58 -13 210 62 -13 stone
execute in minecraft:overworld run fill 210 63 -13 210 64 -13 dirt
execute in minecraft:overworld run setblock 210 65 -13 coarse_dirt
execute in minecraft:overworld run fill 210 66 -13 210 144 -13 air
execute in minecraft:overworld run fill 210 58 -12 210 62 -12 stone
execute in minecraft:overworld run fill 210 63 -12 210 64 -12 dirt
execute in minecraft:overworld run setblock 210 65 -12 coarse_dirt
execute in minecraft:overworld run fill 210 66 -12 210 144 -12 air
execute in minecraft:overworld run fill 210 58 -11 210 62 -11 stone
execute in minecraft:overworld run fill 210 63 -11 210 64 -11 dirt
execute in minecraft:overworld run setblock 210 65 -11 grass_block
execute in minecraft:overworld run fill 210 66 -11 210 144 -11 air
execute in minecraft:overworld run fill 210 58 -10 210 62 -10 stone
execute in minecraft:overworld run fill 210 63 -10 210 64 -10 dirt
execute in minecraft:overworld run setblock 210 65 -10 coarse_dirt
execute in minecraft:overworld run fill 210 66 -10 210 144 -10 air
execute in minecraft:overworld run fill 210 58 -9 210 62 -9 stone
execute in minecraft:overworld run fill 210 63 -9 210 64 -9 dirt
execute in minecraft:overworld run setblock 210 65 -9 coarse_dirt
execute in minecraft:overworld run fill 210 66 -9 210 144 -9 air
execute in minecraft:overworld run fill 210 58 -8 210 62 -8 stone
execute in minecraft:overworld run fill 210 63 -8 210 64 -8 dirt
execute in minecraft:overworld run setblock 210 65 -8 coarse_dirt
execute in minecraft:overworld run fill 210 66 -8 210 144 -8 air
execute in minecraft:overworld run fill 210 58 -7 210 62 -7 stone
execute in minecraft:overworld run fill 210 63 -7 210 64 -7 dirt
execute in minecraft:overworld run setblock 210 65 -7 coarse_dirt
execute in minecraft:overworld run fill 210 66 -7 210 144 -7 air
execute in minecraft:overworld run fill 210 58 -6 210 62 -6 stone
execute in minecraft:overworld run fill 210 63 -6 210 64 -6 dirt
execute in minecraft:overworld run setblock 210 65 -6 coarse_dirt
execute in minecraft:overworld run fill 210 66 -6 210 144 -6 air
execute in minecraft:overworld run fill 210 58 -5 210 62 -5 stone
execute in minecraft:overworld run fill 210 63 -5 210 64 -5 dirt
execute in minecraft:overworld run setblock 210 65 -5 coarse_dirt
execute in minecraft:overworld run fill 210 66 -5 210 144 -5 air
execute in minecraft:overworld run fill 210 58 -4 210 62 -4 stone
execute in minecraft:overworld run fill 210 63 -4 210 64 -4 dirt
execute in minecraft:overworld run setblock 210 65 -4 coarse_dirt
execute in minecraft:overworld run fill 210 66 -4 210 144 -4 air
execute in minecraft:overworld run fill 210 58 -3 210 62 -3 stone
execute in minecraft:overworld run fill 210 63 -3 210 64 -3 dirt
execute in minecraft:overworld run setblock 210 65 -3 grass_block
execute in minecraft:overworld run fill 210 66 -3 210 144 -3 air
execute in minecraft:overworld run fill 210 58 -2 210 62 -2 stone
execute in minecraft:overworld run fill 210 63 -2 210 64 -2 dirt
execute in minecraft:overworld run setblock 210 65 -2 grass_block
execute in minecraft:overworld run fill 210 66 -2 210 144 -2 air
execute in minecraft:overworld run fill 210 58 -1 210 62 -1 stone
execute in minecraft:overworld run fill 210 63 -1 210 64 -1 dirt
execute in minecraft:overworld run setblock 210 65 -1 coarse_dirt
execute in minecraft:overworld run fill 210 66 -1 210 144 -1 air
execute in minecraft:overworld run fill 210 58 0 210 62 0 stone
execute in minecraft:overworld run fill 210 63 0 210 64 0 dirt
execute in minecraft:overworld run setblock 210 65 0 coarse_dirt
execute in minecraft:overworld run fill 210 66 0 210 144 0 air
execute in minecraft:overworld run fill 210 58 1 210 62 1 stone
execute in minecraft:overworld run fill 210 63 1 210 64 1 dirt
execute in minecraft:overworld run setblock 210 65 1 grass_block
execute in minecraft:overworld run fill 210 66 1 210 144 1 air
execute in minecraft:overworld run fill 210 58 2 210 62 2 stone
execute in minecraft:overworld run fill 210 63 2 210 64 2 dirt
execute in minecraft:overworld run setblock 210 65 2 coarse_dirt
execute in minecraft:overworld run fill 210 66 2 210 144 2 air
execute in minecraft:overworld run fill 210 58 3 210 62 3 stone
execute in minecraft:overworld run fill 210 63 3 210 64 3 dirt
execute in minecraft:overworld run setblock 210 65 3 coarse_dirt
execute in minecraft:overworld run fill 210 66 3 210 144 3 air
execute in minecraft:overworld run fill 210 58 4 210 62 4 stone
execute in minecraft:overworld run fill 210 63 4 210 64 4 dirt
execute in minecraft:overworld run setblock 210 65 4 coarse_dirt
execute in minecraft:overworld run fill 210 66 4 210 144 4 air
execute in minecraft:overworld run fill 210 58 5 210 62 5 stone
execute in minecraft:overworld run fill 210 63 5 210 64 5 dirt
execute in minecraft:overworld run setblock 210 65 5 coarse_dirt
execute in minecraft:overworld run fill 210 66 5 210 144 5 air
execute in minecraft:overworld run fill 210 58 6 210 62 6 stone
execute in minecraft:overworld run fill 210 63 6 210 64 6 dirt
execute in minecraft:overworld run setblock 210 65 6 coarse_dirt
execute in minecraft:overworld run fill 210 66 6 210 144 6 air
execute in minecraft:overworld run fill 210 58 7 210 63 7 stone
execute in minecraft:overworld run fill 210 64 7 210 65 7 dirt
execute in minecraft:overworld run setblock 210 66 7 coarse_dirt
execute in minecraft:overworld run fill 210 67 7 210 144 7 air
execute in minecraft:overworld run fill 210 58 8 210 63 8 stone
execute in minecraft:overworld run fill 210 64 8 210 65 8 dirt
execute in minecraft:overworld run setblock 210 66 8 grass_block
execute in minecraft:overworld run fill 210 67 8 210 144 8 air
execute in minecraft:overworld run fill 210 58 9 210 63 9 stone
execute in minecraft:overworld run fill 210 64 9 210 65 9 dirt
execute in minecraft:overworld run setblock 210 66 9 coarse_dirt
execute in minecraft:overworld run fill 210 67 9 210 144 9 air
execute in minecraft:overworld run fill 210 58 10 210 63 10 stone
execute in minecraft:overworld run fill 210 64 10 210 65 10 dirt
execute in minecraft:overworld run setblock 210 66 10 grass_block
execute in minecraft:overworld run fill 210 67 10 210 144 10 air
execute in minecraft:overworld run fill 210 58 11 210 62 11 stone
execute in minecraft:overworld run fill 210 63 11 210 64 11 dirt
execute in minecraft:overworld run setblock 210 65 11 coarse_dirt
execute in minecraft:overworld run fill 210 66 11 210 144 11 air
execute in minecraft:overworld run fill 210 58 12 210 62 12 stone
execute in minecraft:overworld run fill 210 63 12 210 64 12 dirt
execute in minecraft:overworld run setblock 210 65 12 grass_block
execute in minecraft:overworld run fill 210 66 12 210 144 12 air
execute in minecraft:overworld run fill 210 58 13 210 62 13 stone
execute in minecraft:overworld run fill 210 63 13 210 64 13 dirt
execute in minecraft:overworld run setblock 210 65 13 coarse_dirt
execute in minecraft:overworld run fill 210 66 13 210 144 13 air
execute in minecraft:overworld run fill 210 58 14 210 62 14 stone
execute in minecraft:overworld run fill 210 63 14 210 64 14 dirt
execute in minecraft:overworld run setblock 210 65 14 grass_block
execute in minecraft:overworld run fill 210 66 14 210 144 14 air
execute in minecraft:overworld run fill 210 58 15 210 62 15 stone
execute in minecraft:overworld run fill 210 63 15 210 64 15 dirt
schedule function blade_gallery:random/burned/part_4 1t replace
