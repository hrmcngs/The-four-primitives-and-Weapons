execute in minecraft:overworld run fill 354 71 -12 354 144 -12 air
execute in minecraft:overworld run fill 354 58 -11 354 67 -11 stone
execute in minecraft:overworld run fill 354 68 -11 354 69 -11 dirt
execute in minecraft:overworld run setblock 354 70 -11 coarse_dirt
execute in minecraft:overworld run fill 354 71 -11 354 144 -11 air
execute in minecraft:overworld run fill 354 58 -10 354 66 -10 stone
execute in minecraft:overworld run fill 354 67 -10 354 68 -10 dirt
execute in minecraft:overworld run setblock 354 69 -10 coarse_dirt
execute in minecraft:overworld run fill 354 70 -10 354 144 -10 air
execute in minecraft:overworld run fill 354 58 -9 354 66 -9 stone
execute in minecraft:overworld run fill 354 67 -9 354 68 -9 dirt
execute in minecraft:overworld run setblock 354 69 -9 grass_block
execute in minecraft:overworld run fill 354 70 -9 354 144 -9 air
execute in minecraft:overworld run fill 354 58 -8 354 66 -8 stone
execute in minecraft:overworld run fill 354 67 -8 354 68 -8 dirt
execute in minecraft:overworld run setblock 354 69 -8 grass_block
execute in minecraft:overworld run fill 354 70 -8 354 144 -8 air
execute in minecraft:overworld run fill 354 58 -7 354 66 -7 stone
execute in minecraft:overworld run fill 354 67 -7 354 68 -7 dirt
execute in minecraft:overworld run setblock 354 69 -7 grass_block
execute in minecraft:overworld run fill 354 70 -7 354 144 -7 air
execute in minecraft:overworld run fill 354 58 -6 354 66 -6 stone
execute in minecraft:overworld run fill 354 67 -6 354 68 -6 dirt
execute in minecraft:overworld run setblock 354 69 -6 coarse_dirt
execute in minecraft:overworld run fill 354 70 -6 354 144 -6 air
execute in minecraft:overworld run setblock 354 70 -6 grass
execute in minecraft:overworld run fill 354 58 -5 354 66 -5 stone
execute in minecraft:overworld run fill 354 67 -5 354 68 -5 dirt
execute in minecraft:overworld run setblock 354 69 -5 grass_block
execute in minecraft:overworld run fill 354 70 -5 354 144 -5 air
execute in minecraft:overworld run setblock 354 70 -5 grass
execute in minecraft:overworld run fill 354 58 -4 354 66 -4 stone
execute in minecraft:overworld run fill 354 67 -4 354 68 -4 dirt
execute in minecraft:overworld run setblock 354 69 -4 grass_block
execute in minecraft:overworld run fill 354 70 -4 354 144 -4 air
execute in minecraft:overworld run setblock 354 70 -4 grass
execute in minecraft:overworld run fill 354 58 -3 354 66 -3 stone
execute in minecraft:overworld run fill 354 67 -3 354 68 -3 dirt
execute in minecraft:overworld run setblock 354 69 -3 grass_block
execute in minecraft:overworld run fill 354 70 -3 354 144 -3 air
execute in minecraft:overworld run fill 354 58 -2 354 66 -2 stone
execute in minecraft:overworld run fill 354 67 -2 354 68 -2 dirt
execute in minecraft:overworld run setblock 354 69 -2 coarse_dirt
execute in minecraft:overworld run fill 354 70 -2 354 144 -2 air
execute in minecraft:overworld run setblock 354 70 -2 grass
execute in minecraft:overworld run fill 354 58 -1 354 66 -1 stone
execute in minecraft:overworld run fill 354 67 -1 354 68 -1 dirt
execute in minecraft:overworld run setblock 354 69 -1 coarse_dirt
execute in minecraft:overworld run fill 354 70 -1 354 144 -1 air
execute in minecraft:overworld run fill 354 58 0 354 66 0 stone
execute in minecraft:overworld run fill 354 67 0 354 68 0 dirt
execute in minecraft:overworld run setblock 354 69 0 coarse_dirt
execute in minecraft:overworld run fill 354 70 0 354 144 0 air
execute in minecraft:overworld run fill 354 58 1 354 66 1 stone
execute in minecraft:overworld run fill 354 67 1 354 68 1 dirt
execute in minecraft:overworld run setblock 354 69 1 coarse_dirt
execute in minecraft:overworld run fill 354 70 1 354 144 1 air
execute in minecraft:overworld run setblock 354 70 1 grass
execute in minecraft:overworld run fill 354 58 2 354 66 2 stone
execute in minecraft:overworld run fill 354 67 2 354 68 2 dirt
execute in minecraft:overworld run setblock 354 69 2 grass_block
execute in minecraft:overworld run fill 354 70 2 354 144 2 air
execute in minecraft:overworld run fill 354 58 3 354 66 3 stone
execute in minecraft:overworld run fill 354 67 3 354 68 3 dirt
execute in minecraft:overworld run setblock 354 69 3 coarse_dirt
execute in minecraft:overworld run fill 354 70 3 354 144 3 air
execute in minecraft:overworld run fill 354 58 4 354 67 4 stone
execute in minecraft:overworld run fill 354 68 4 354 69 4 dirt
execute in minecraft:overworld run setblock 354 70 4 coarse_dirt
execute in minecraft:overworld run fill 354 71 4 354 144 4 air
execute in minecraft:overworld run fill 354 58 5 354 67 5 stone
execute in minecraft:overworld run fill 354 68 5 354 69 5 dirt
execute in minecraft:overworld run setblock 354 70 5 coarse_dirt
execute in minecraft:overworld run fill 354 71 5 354 144 5 air
execute in minecraft:overworld run fill 354 58 6 354 67 6 stone
execute in minecraft:overworld run fill 354 68 6 354 69 6 dirt
execute in minecraft:overworld run setblock 354 70 6 coarse_dirt
execute in minecraft:overworld run fill 354 71 6 354 144 6 air
execute in minecraft:overworld run setblock 354 71 6 grass
execute in minecraft:overworld run fill 354 58 7 354 67 7 stone
execute in minecraft:overworld run fill 354 68 7 354 69 7 dirt
execute in minecraft:overworld run setblock 354 70 7 coarse_dirt
execute in minecraft:overworld run fill 354 71 7 354 144 7 air
execute in minecraft:overworld run setblock 354 71 7 grass
execute in minecraft:overworld run fill 354 58 8 354 67 8 stone
execute in minecraft:overworld run fill 354 68 8 354 69 8 dirt
execute in minecraft:overworld run setblock 354 70 8 coarse_dirt
execute in minecraft:overworld run fill 354 71 8 354 144 8 air
execute in minecraft:overworld run fill 354 58 9 354 68 9 stone
execute in minecraft:overworld run fill 354 69 9 354 70 9 dirt
execute in minecraft:overworld run setblock 354 71 9 coarse_dirt
execute in minecraft:overworld run fill 354 72 9 354 144 9 air
execute in minecraft:overworld run fill 354 58 10 354 68 10 stone
execute in minecraft:overworld run fill 354 69 10 354 70 10 dirt
execute in minecraft:overworld run setblock 354 71 10 coarse_dirt
execute in minecraft:overworld run fill 354 72 10 354 144 10 air
execute in minecraft:overworld run fill 354 58 11 354 67 11 stone
execute in minecraft:overworld run fill 354 68 11 354 69 11 dirt
execute in minecraft:overworld run setblock 354 70 11 coarse_dirt
execute in minecraft:overworld run fill 354 71 11 354 144 11 air
execute in minecraft:overworld run fill 354 58 12 354 67 12 stone
execute in minecraft:overworld run fill 354 68 12 354 69 12 dirt
execute in minecraft:overworld run setblock 354 70 12 grass_block
execute in minecraft:overworld run fill 354 71 12 354 144 12 air
execute in minecraft:overworld run fill 354 58 13 354 67 13 stone
execute in minecraft:overworld run fill 354 68 13 354 69 13 dirt
execute in minecraft:overworld run setblock 354 70 13 grass_block
execute in minecraft:overworld run fill 354 71 13 354 144 13 air
execute in minecraft:overworld run fill 354 58 14 354 67 14 stone
execute in minecraft:overworld run fill 354 68 14 354 69 14 dirt
execute in minecraft:overworld run setblock 354 70 14 grass_block
execute in minecraft:overworld run fill 354 71 14 354 144 14 air
execute in minecraft:overworld run fill 354 58 15 354 67 15 stone
execute in minecraft:overworld run fill 354 68 15 354 69 15 dirt
execute in minecraft:overworld run setblock 354 70 15 grass_block
execute in minecraft:overworld run fill 354 71 15 354 144 15 air
execute in minecraft:overworld run fill 354 58 16 354 67 16 stone
execute in minecraft:overworld run fill 354 68 16 354 69 16 dirt
execute in minecraft:overworld run setblock 354 70 16 coarse_dirt
execute in minecraft:overworld run fill 354 71 16 354 144 16 air
execute in minecraft:overworld run fill 354 58 17 354 66 17 stone
execute in minecraft:overworld run fill 354 67 17 354 68 17 dirt
execute in minecraft:overworld run setblock 354 69 17 coarse_dirt
execute in minecraft:overworld run fill 354 70 17 354 144 17 air
execute in minecraft:overworld run fill 354 58 18 354 67 18 stone
execute in minecraft:overworld run fill 354 68 18 354 69 18 dirt
execute in minecraft:overworld run setblock 354 70 18 grass_block
execute in minecraft:overworld run fill 354 71 18 354 144 18 air
execute in minecraft:overworld run fill 354 58 19 354 67 19 stone
execute in minecraft:overworld run fill 354 68 19 354 69 19 dirt
execute in minecraft:overworld run setblock 354 70 19 coarse_dirt
execute in minecraft:overworld run fill 354 71 19 354 144 19 air
execute in minecraft:overworld run fill 354 58 20 354 67 20 stone
execute in minecraft:overworld run fill 354 68 20 354 69 20 dirt
execute in minecraft:overworld run setblock 354 70 20 grass_block
execute in minecraft:overworld run fill 354 71 20 354 144 20 air
execute in minecraft:overworld run fill 354 58 21 354 67 21 stone
execute in minecraft:overworld run fill 354 68 21 354 69 21 dirt
execute in minecraft:overworld run setblock 354 70 21 coarse_dirt
execute in minecraft:overworld run fill 354 71 21 354 144 21 air
execute in minecraft:overworld run setblock 354 71 21 grass
execute in minecraft:overworld run fill 354 58 22 354 67 22 stone
execute in minecraft:overworld run fill 354 68 22 354 69 22 dirt
execute in minecraft:overworld run setblock 354 70 22 grass_block
execute in minecraft:overworld run fill 354 71 22 354 144 22 air
execute in minecraft:overworld run fill 354 58 23 354 68 23 stone
execute in minecraft:overworld run fill 354 69 23 354 70 23 dirt
execute in minecraft:overworld run setblock 354 71 23 coarse_dirt
execute in minecraft:overworld run fill 354 72 23 354 144 23 air
execute in minecraft:overworld run fill 354 58 24 354 68 24 stone
execute in minecraft:overworld run fill 354 69 24 354 70 24 dirt
execute in minecraft:overworld run setblock 354 71 24 grass_block
execute in minecraft:overworld run fill 354 72 24 354 144 24 air
execute in minecraft:overworld run fill 354 58 25 354 68 25 stone
execute in minecraft:overworld run fill 354 69 25 354 70 25 dirt
execute in minecraft:overworld run setblock 354 71 25 coarse_dirt
execute in minecraft:overworld run fill 354 72 25 354 144 25 air
execute in minecraft:overworld run fill 354 58 26 354 68 26 stone
execute in minecraft:overworld run fill 354 69 26 354 70 26 dirt
execute in minecraft:overworld run setblock 354 71 26 coarse_dirt
execute in minecraft:overworld run fill 354 72 26 354 144 26 air
execute in minecraft:overworld run setblock 354 72 26 grass
execute in minecraft:overworld run fill 354 58 27 354 68 27 stone
execute in minecraft:overworld run fill 354 69 27 354 70 27 dirt
execute in minecraft:overworld run setblock 354 71 27 coarse_dirt
execute in minecraft:overworld run fill 354 72 27 354 144 27 air
execute in minecraft:overworld run fill 354 58 28 354 68 28 stone
execute in minecraft:overworld run fill 354 69 28 354 70 28 dirt
execute in minecraft:overworld run setblock 354 71 28 coarse_dirt
execute in minecraft:overworld run fill 354 72 28 354 144 28 air
execute in minecraft:overworld run fill 354 58 29 354 68 29 stone
execute in minecraft:overworld run fill 354 69 29 354 70 29 dirt
execute in minecraft:overworld run setblock 354 71 29 coarse_dirt
execute in minecraft:overworld run fill 354 72 29 354 144 29 air
execute in minecraft:overworld run fill 354 58 30 354 68 30 stone
execute in minecraft:overworld run fill 354 69 30 354 70 30 dirt
execute in minecraft:overworld run setblock 354 71 30 grass_block
execute in minecraft:overworld run fill 354 72 30 354 144 30 air
execute in minecraft:overworld run fill 354 58 31 354 68 31 stone
execute in minecraft:overworld run fill 354 69 31 354 70 31 dirt
execute in minecraft:overworld run setblock 354 71 31 grass_block
execute in minecraft:overworld run fill 354 72 31 354 144 31 air
execute in minecraft:overworld run fill 354 58 32 354 68 32 stone
execute in minecraft:overworld run fill 354 69 32 354 70 32 dirt
execute in minecraft:overworld run setblock 354 71 32 coarse_dirt
execute in minecraft:overworld run fill 354 72 32 354 144 32 air
execute in minecraft:overworld run setblock 354 72 32 mossy_cobblestone
execute in minecraft:overworld run fill 354 58 33 354 68 33 stone
execute in minecraft:overworld run fill 354 69 33 354 70 33 dirt
execute in minecraft:overworld run setblock 354 71 33 grass_block
execute in minecraft:overworld run fill 354 72 33 354 144 33 air
execute in minecraft:overworld run fill 354 58 34 354 68 34 stone
execute in minecraft:overworld run fill 354 69 34 354 70 34 dirt
execute in minecraft:overworld run setblock 354 71 34 coarse_dirt
execute in minecraft:overworld run fill 354 72 34 354 144 34 air
execute in minecraft:overworld run fill 354 58 35 354 68 35 stone
execute in minecraft:overworld run fill 354 69 35 354 70 35 dirt
execute in minecraft:overworld run setblock 354 71 35 coarse_dirt
execute in minecraft:overworld run fill 354 72 35 354 144 35 air
execute in minecraft:overworld run fill 354 58 36 354 68 36 stone
execute in minecraft:overworld run fill 354 69 36 354 70 36 dirt
execute in minecraft:overworld run setblock 354 71 36 coarse_dirt
execute in minecraft:overworld run fill 354 72 36 354 144 36 air
execute in minecraft:overworld run fill 354 58 37 354 68 37 stone
execute in minecraft:overworld run fill 354 69 37 354 70 37 dirt
execute in minecraft:overworld run setblock 354 71 37 grass_block
execute in minecraft:overworld run fill 354 72 37 354 144 37 air
execute in minecraft:overworld run fill 354 58 38 354 68 38 stone
execute in minecraft:overworld run fill 354 69 38 354 70 38 dirt
execute in minecraft:overworld run setblock 354 71 38 coarse_dirt
execute in minecraft:overworld run fill 354 72 38 354 144 38 air
execute in minecraft:overworld run fill 354 58 39 354 67 39 stone
execute in minecraft:overworld run fill 354 68 39 354 69 39 dirt
execute in minecraft:overworld run setblock 354 70 39 grass_block
execute in minecraft:overworld run fill 354 71 39 354 144 39 air
execute in minecraft:overworld run fill 354 58 40 354 66 40 stone
execute in minecraft:overworld run fill 354 67 40 354 68 40 dirt
execute in minecraft:overworld run setblock 354 69 40 coarse_dirt
execute in minecraft:overworld run fill 354 70 40 354 144 40 air
execute in minecraft:overworld run setblock 354 70 40 grass
execute in minecraft:overworld run fill 354 58 41 354 66 41 stone
execute in minecraft:overworld run fill 354 67 41 354 68 41 dirt
execute in minecraft:overworld run setblock 354 69 41 coarse_dirt
execute in minecraft:overworld run fill 354 70 41 354 144 41 air
execute in minecraft:overworld run fill 354 58 42 354 65 42 stone
execute in minecraft:overworld run fill 354 66 42 354 67 42 dirt
execute in minecraft:overworld run setblock 354 68 42 coarse_dirt
execute in minecraft:overworld run fill 354 69 42 354 144 42 air
execute in minecraft:overworld run fill 354 58 43 354 64 43 stone
execute in minecraft:overworld run fill 354 65 43 354 66 43 dirt
execute in minecraft:overworld run setblock 354 67 43 coarse_dirt
execute in minecraft:overworld run fill 354 68 43 354 144 43 air
execute in minecraft:overworld run fill 354 58 44 354 64 44 stone
execute in minecraft:overworld run fill 354 65 44 354 66 44 dirt
execute in minecraft:overworld run setblock 354 67 44 coarse_dirt
execute in minecraft:overworld run fill 354 68 44 354 144 44 air
execute in minecraft:overworld run fill 354 58 45 354 63 45 stone
execute in minecraft:overworld run fill 354 64 45 354 65 45 dirt
execute in minecraft:overworld run setblock 354 66 45 grass_block
execute in minecraft:overworld run fill 354 67 45 354 144 45 air
execute in minecraft:overworld run fill 354 58 46 354 62 46 stone
execute in minecraft:overworld run fill 354 63 46 354 64 46 dirt
execute in minecraft:overworld run setblock 354 65 46 coarse_dirt
execute in minecraft:overworld run fill 354 66 46 354 144 46 air
execute in minecraft:overworld run fill 354 58 47 354 62 47 stone
execute in minecraft:overworld run fill 354 63 47 354 64 47 dirt
execute in minecraft:overworld run setblock 354 65 47 grass_block
execute in minecraft:overworld run fill 354 66 47 354 144 47 air
execute in minecraft:overworld run fill 355 58 -48 355 61 -48 stone
execute in minecraft:overworld run fill 355 62 -48 355 63 -48 dirt
execute in minecraft:overworld run setblock 355 64 -48 coarse_dirt
execute in minecraft:overworld run fill 355 65 -48 355 144 -48 air
execute in minecraft:overworld run fill 355 58 -47 355 63 -47 stone
execute in minecraft:overworld run fill 355 64 -47 355 65 -47 dirt
execute in minecraft:overworld run setblock 355 66 -47 grass_block
execute in minecraft:overworld run fill 355 67 -47 355 144 -47 air
schedule function blade_gallery:random/battlefield/part_29 1t replace
