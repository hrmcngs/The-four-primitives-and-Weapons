execute in minecraft:overworld run fill 380 66 -19 380 144 -19 air
execute in minecraft:overworld run fill 380 58 -18 380 62 -18 stone
execute in minecraft:overworld run fill 380 63 -18 380 64 -18 dirt
execute in minecraft:overworld run setblock 380 65 -18 grass_block
execute in minecraft:overworld run fill 380 66 -18 380 144 -18 air
execute in minecraft:overworld run fill 380 58 -17 380 62 -17 stone
execute in minecraft:overworld run fill 380 63 -17 380 64 -17 dirt
execute in minecraft:overworld run setblock 380 65 -17 grass_block
execute in minecraft:overworld run fill 380 66 -17 380 144 -17 air
execute in minecraft:overworld run fill 380 58 -16 380 62 -16 stone
execute in minecraft:overworld run fill 380 63 -16 380 64 -16 dirt
execute in minecraft:overworld run setblock 380 65 -16 grass_block
execute in minecraft:overworld run fill 380 66 -16 380 144 -16 air
execute in minecraft:overworld run fill 380 58 -15 380 62 -15 stone
execute in minecraft:overworld run fill 380 63 -15 380 64 -15 dirt
execute in minecraft:overworld run setblock 380 65 -15 grass_block
execute in minecraft:overworld run fill 380 66 -15 380 144 -15 air
execute in minecraft:overworld run fill 380 58 -14 380 62 -14 stone
execute in minecraft:overworld run fill 380 63 -14 380 64 -14 dirt
execute in minecraft:overworld run setblock 380 65 -14 coarse_dirt
execute in minecraft:overworld run fill 380 66 -14 380 144 -14 air
execute in minecraft:overworld run fill 380 58 -13 380 62 -13 stone
execute in minecraft:overworld run fill 380 63 -13 380 64 -13 dirt
execute in minecraft:overworld run setblock 380 65 -13 coarse_dirt
execute in minecraft:overworld run fill 380 66 -13 380 144 -13 air
execute in minecraft:overworld run fill 380 58 -12 380 62 -12 stone
execute in minecraft:overworld run fill 380 63 -12 380 64 -12 dirt
execute in minecraft:overworld run setblock 380 65 -12 coarse_dirt
execute in minecraft:overworld run fill 380 66 -12 380 144 -12 air
execute in minecraft:overworld run fill 380 58 -11 380 63 -11 stone
execute in minecraft:overworld run fill 380 64 -11 380 65 -11 dirt
execute in minecraft:overworld run setblock 380 66 -11 grass_block
execute in minecraft:overworld run fill 380 67 -11 380 144 -11 air
execute in minecraft:overworld run fill 380 58 -10 380 63 -10 stone
execute in minecraft:overworld run fill 380 64 -10 380 65 -10 dirt
execute in minecraft:overworld run setblock 380 66 -10 coarse_dirt
execute in minecraft:overworld run fill 380 67 -10 380 144 -10 air
execute in minecraft:overworld run fill 380 58 -9 380 63 -9 stone
execute in minecraft:overworld run fill 380 64 -9 380 65 -9 dirt
execute in minecraft:overworld run setblock 380 66 -9 coarse_dirt
execute in minecraft:overworld run fill 380 67 -9 380 144 -9 air
execute in minecraft:overworld run fill 380 58 -8 380 63 -8 stone
execute in minecraft:overworld run fill 380 64 -8 380 65 -8 dirt
execute in minecraft:overworld run setblock 380 66 -8 coarse_dirt
execute in minecraft:overworld run fill 380 67 -8 380 144 -8 air
execute in minecraft:overworld run fill 380 58 -7 380 63 -7 stone
execute in minecraft:overworld run fill 380 64 -7 380 65 -7 dirt
execute in minecraft:overworld run setblock 380 66 -7 coarse_dirt
execute in minecraft:overworld run fill 380 67 -7 380 144 -7 air
execute in minecraft:overworld run fill 380 58 -6 380 64 -6 stone
execute in minecraft:overworld run fill 380 65 -6 380 66 -6 dirt
execute in minecraft:overworld run setblock 380 67 -6 grass_block
execute in minecraft:overworld run fill 380 68 -6 380 144 -6 air
execute in minecraft:overworld run fill 380 58 -5 380 64 -5 stone
execute in minecraft:overworld run fill 380 65 -5 380 66 -5 dirt
execute in minecraft:overworld run setblock 380 67 -5 coarse_dirt
execute in minecraft:overworld run fill 380 68 -5 380 144 -5 air
execute in minecraft:overworld run fill 380 58 -4 380 64 -4 stone
execute in minecraft:overworld run fill 380 65 -4 380 66 -4 dirt
execute in minecraft:overworld run setblock 380 67 -4 grass_block
execute in minecraft:overworld run fill 380 68 -4 380 144 -4 air
execute in minecraft:overworld run fill 380 58 -3 380 64 -3 stone
execute in minecraft:overworld run fill 380 65 -3 380 66 -3 dirt
execute in minecraft:overworld run setblock 380 67 -3 coarse_dirt
execute in minecraft:overworld run fill 380 68 -3 380 144 -3 air
execute in minecraft:overworld run setblock 380 68 -3 grass
execute in minecraft:overworld run fill 380 58 -2 380 64 -2 stone
execute in minecraft:overworld run fill 380 65 -2 380 66 -2 dirt
execute in minecraft:overworld run setblock 380 67 -2 coarse_dirt
execute in minecraft:overworld run fill 380 68 -2 380 144 -2 air
execute in minecraft:overworld run fill 380 58 -1 380 64 -1 stone
execute in minecraft:overworld run fill 380 65 -1 380 66 -1 dirt
execute in minecraft:overworld run setblock 380 67 -1 coarse_dirt
execute in minecraft:overworld run fill 380 68 -1 380 144 -1 air
execute in minecraft:overworld run fill 380 58 0 380 65 0 stone
execute in minecraft:overworld run fill 380 66 0 380 67 0 dirt
execute in minecraft:overworld run setblock 380 68 0 coarse_dirt
execute in minecraft:overworld run fill 380 69 0 380 144 0 air
execute in minecraft:overworld run fill 380 58 1 380 65 1 stone
execute in minecraft:overworld run fill 380 66 1 380 67 1 dirt
execute in minecraft:overworld run setblock 380 68 1 coarse_dirt
execute in minecraft:overworld run fill 380 69 1 380 144 1 air
execute in minecraft:overworld run fill 380 58 2 380 65 2 stone
execute in minecraft:overworld run fill 380 66 2 380 67 2 dirt
execute in minecraft:overworld run setblock 380 68 2 coarse_dirt
execute in minecraft:overworld run fill 380 69 2 380 144 2 air
execute in minecraft:overworld run fill 380 58 3 380 65 3 stone
execute in minecraft:overworld run fill 380 66 3 380 67 3 dirt
execute in minecraft:overworld run setblock 380 68 3 coarse_dirt
execute in minecraft:overworld run fill 380 69 3 380 144 3 air
execute in minecraft:overworld run fill 380 58 4 380 65 4 stone
execute in minecraft:overworld run fill 380 66 4 380 67 4 dirt
execute in minecraft:overworld run setblock 380 68 4 coarse_dirt
execute in minecraft:overworld run fill 380 69 4 380 144 4 air
execute in minecraft:overworld run setblock 380 69 4 grass
execute in minecraft:overworld run fill 380 58 5 380 65 5 stone
execute in minecraft:overworld run fill 380 66 5 380 67 5 dirt
execute in minecraft:overworld run setblock 380 68 5 coarse_dirt
execute in minecraft:overworld run fill 380 69 5 380 144 5 air
execute in minecraft:overworld run setblock 380 69 5 grass
execute in minecraft:overworld run fill 380 58 6 380 65 6 stone
execute in minecraft:overworld run fill 380 66 6 380 67 6 dirt
execute in minecraft:overworld run setblock 380 68 6 coarse_dirt
execute in minecraft:overworld run fill 380 69 6 380 144 6 air
execute in minecraft:overworld run fill 380 58 7 380 65 7 stone
execute in minecraft:overworld run fill 380 66 7 380 67 7 dirt
execute in minecraft:overworld run setblock 380 68 7 coarse_dirt
execute in minecraft:overworld run fill 380 69 7 380 144 7 air
execute in minecraft:overworld run fill 380 58 8 380 65 8 stone
execute in minecraft:overworld run fill 380 66 8 380 67 8 dirt
execute in minecraft:overworld run setblock 380 68 8 grass_block
execute in minecraft:overworld run fill 380 69 8 380 144 8 air
execute in minecraft:overworld run fill 380 58 9 380 65 9 stone
execute in minecraft:overworld run fill 380 66 9 380 67 9 dirt
execute in minecraft:overworld run setblock 380 68 9 grass_block
execute in minecraft:overworld run fill 380 69 9 380 144 9 air
execute in minecraft:overworld run fill 380 58 10 380 65 10 stone
execute in minecraft:overworld run fill 380 66 10 380 67 10 dirt
execute in minecraft:overworld run setblock 380 68 10 coarse_dirt
execute in minecraft:overworld run fill 380 69 10 380 144 10 air
execute in minecraft:overworld run setblock 380 69 10 grass
execute in minecraft:overworld run fill 380 58 11 380 65 11 stone
execute in minecraft:overworld run fill 380 66 11 380 67 11 dirt
execute in minecraft:overworld run setblock 380 68 11 coarse_dirt
execute in minecraft:overworld run fill 380 69 11 380 144 11 air
execute in minecraft:overworld run fill 380 58 12 380 66 12 stone
execute in minecraft:overworld run fill 380 67 12 380 68 12 dirt
execute in minecraft:overworld run setblock 380 69 12 grass_block
execute in minecraft:overworld run fill 380 70 12 380 144 12 air
execute in minecraft:overworld run fill 380 58 13 380 66 13 stone
execute in minecraft:overworld run fill 380 67 13 380 68 13 dirt
execute in minecraft:overworld run setblock 380 69 13 coarse_dirt
execute in minecraft:overworld run fill 380 70 13 380 144 13 air
execute in minecraft:overworld run fill 380 58 14 380 66 14 stone
execute in minecraft:overworld run fill 380 67 14 380 68 14 dirt
execute in minecraft:overworld run setblock 380 69 14 coarse_dirt
execute in minecraft:overworld run fill 380 70 14 380 144 14 air
execute in minecraft:overworld run fill 380 58 15 380 67 15 stone
execute in minecraft:overworld run fill 380 68 15 380 69 15 dirt
execute in minecraft:overworld run setblock 380 70 15 coarse_dirt
execute in minecraft:overworld run fill 380 71 15 380 144 15 air
execute in minecraft:overworld run fill 380 58 16 380 67 16 stone
execute in minecraft:overworld run fill 380 68 16 380 69 16 dirt
execute in minecraft:overworld run setblock 380 70 16 coarse_dirt
execute in minecraft:overworld run fill 380 71 16 380 144 16 air
execute in minecraft:overworld run fill 380 58 17 380 67 17 stone
execute in minecraft:overworld run fill 380 68 17 380 69 17 dirt
execute in minecraft:overworld run setblock 380 70 17 grass_block
execute in minecraft:overworld run fill 380 71 17 380 144 17 air
execute in minecraft:overworld run fill 380 58 18 380 67 18 stone
execute in minecraft:overworld run fill 380 68 18 380 69 18 dirt
execute in minecraft:overworld run setblock 380 70 18 coarse_dirt
execute in minecraft:overworld run fill 380 71 18 380 144 18 air
execute in minecraft:overworld run fill 380 58 19 380 67 19 stone
execute in minecraft:overworld run fill 380 68 19 380 69 19 dirt
execute in minecraft:overworld run setblock 380 70 19 grass_block
execute in minecraft:overworld run fill 380 71 19 380 144 19 air
execute in minecraft:overworld run fill 380 58 20 380 67 20 stone
execute in minecraft:overworld run fill 380 68 20 380 69 20 dirt
execute in minecraft:overworld run setblock 380 70 20 grass_block
execute in minecraft:overworld run fill 380 71 20 380 144 20 air
execute in minecraft:overworld run fill 380 58 21 380 67 21 stone
execute in minecraft:overworld run fill 380 68 21 380 69 21 dirt
execute in minecraft:overworld run setblock 380 70 21 coarse_dirt
execute in minecraft:overworld run fill 380 71 21 380 144 21 air
execute in minecraft:overworld run fill 380 58 22 380 67 22 stone
execute in minecraft:overworld run fill 380 68 22 380 69 22 dirt
execute in minecraft:overworld run setblock 380 70 22 grass_block
execute in minecraft:overworld run fill 380 71 22 380 144 22 air
execute in minecraft:overworld run fill 380 58 23 380 67 23 stone
execute in minecraft:overworld run fill 380 68 23 380 69 23 dirt
execute in minecraft:overworld run setblock 380 70 23 coarse_dirt
execute in minecraft:overworld run fill 380 71 23 380 144 23 air
execute in minecraft:overworld run fill 380 58 24 380 66 24 stone
execute in minecraft:overworld run fill 380 67 24 380 68 24 dirt
execute in minecraft:overworld run setblock 380 69 24 grass_block
execute in minecraft:overworld run fill 380 70 24 380 144 24 air
execute in minecraft:overworld run fill 380 58 25 380 66 25 stone
execute in minecraft:overworld run fill 380 67 25 380 68 25 dirt
execute in minecraft:overworld run setblock 380 69 25 grass_block
execute in minecraft:overworld run fill 380 70 25 380 144 25 air
execute in minecraft:overworld run setblock 380 70 25 mossy_cobblestone
execute in minecraft:overworld run fill 380 58 26 380 66 26 stone
execute in minecraft:overworld run fill 380 67 26 380 68 26 dirt
execute in minecraft:overworld run setblock 380 69 26 coarse_dirt
execute in minecraft:overworld run fill 380 70 26 380 144 26 air
execute in minecraft:overworld run fill 380 58 27 380 66 27 stone
execute in minecraft:overworld run fill 380 67 27 380 68 27 dirt
execute in minecraft:overworld run setblock 380 69 27 grass_block
execute in minecraft:overworld run fill 380 70 27 380 144 27 air
execute in minecraft:overworld run fill 380 58 28 380 66 28 stone
execute in minecraft:overworld run fill 380 67 28 380 68 28 dirt
execute in minecraft:overworld run setblock 380 69 28 grass_block
execute in minecraft:overworld run fill 380 70 28 380 144 28 air
execute in minecraft:overworld run fill 380 58 29 380 66 29 stone
execute in minecraft:overworld run fill 380 67 29 380 68 29 dirt
execute in minecraft:overworld run setblock 380 69 29 grass_block
execute in minecraft:overworld run fill 380 70 29 380 144 29 air
execute in minecraft:overworld run fill 380 58 30 380 66 30 stone
execute in minecraft:overworld run fill 380 67 30 380 68 30 dirt
execute in minecraft:overworld run setblock 380 69 30 coarse_dirt
execute in minecraft:overworld run fill 380 70 30 380 144 30 air
execute in minecraft:overworld run fill 380 58 31 380 66 31 stone
execute in minecraft:overworld run fill 380 67 31 380 68 31 dirt
execute in minecraft:overworld run setblock 380 69 31 coarse_dirt
execute in minecraft:overworld run fill 380 70 31 380 144 31 air
execute in minecraft:overworld run fill 380 58 32 380 66 32 stone
execute in minecraft:overworld run fill 380 67 32 380 68 32 dirt
execute in minecraft:overworld run setblock 380 69 32 coarse_dirt
execute in minecraft:overworld run fill 380 70 32 380 144 32 air
execute in minecraft:overworld run fill 380 58 33 380 66 33 stone
execute in minecraft:overworld run fill 380 67 33 380 68 33 dirt
execute in minecraft:overworld run setblock 380 69 33 coarse_dirt
execute in minecraft:overworld run fill 380 70 33 380 144 33 air
execute in minecraft:overworld run fill 380 58 34 380 66 34 stone
execute in minecraft:overworld run fill 380 67 34 380 68 34 dirt
execute in minecraft:overworld run setblock 380 69 34 grass_block
execute in minecraft:overworld run fill 380 70 34 380 144 34 air
execute in minecraft:overworld run fill 380 58 35 380 65 35 stone
execute in minecraft:overworld run fill 380 66 35 380 67 35 dirt
execute in minecraft:overworld run setblock 380 68 35 coarse_dirt
execute in minecraft:overworld run fill 380 69 35 380 144 35 air
execute in minecraft:overworld run fill 380 58 36 380 65 36 stone
execute in minecraft:overworld run fill 380 66 36 380 67 36 dirt
execute in minecraft:overworld run setblock 380 68 36 grass_block
execute in minecraft:overworld run fill 380 69 36 380 144 36 air
execute in minecraft:overworld run fill 380 58 37 380 65 37 stone
execute in minecraft:overworld run fill 380 66 37 380 67 37 dirt
execute in minecraft:overworld run setblock 380 68 37 coarse_dirt
execute in minecraft:overworld run fill 380 69 37 380 144 37 air
execute in minecraft:overworld run fill 380 58 38 380 65 38 stone
execute in minecraft:overworld run fill 380 66 38 380 67 38 dirt
execute in minecraft:overworld run setblock 380 68 38 grass_block
execute in minecraft:overworld run fill 380 69 38 380 144 38 air
execute in minecraft:overworld run fill 380 58 39 380 64 39 stone
execute in minecraft:overworld run fill 380 65 39 380 66 39 dirt
execute in minecraft:overworld run setblock 380 67 39 coarse_dirt
execute in minecraft:overworld run fill 380 68 39 380 144 39 air
execute in minecraft:overworld run fill 380 58 40 380 64 40 stone
execute in minecraft:overworld run fill 380 65 40 380 66 40 dirt
execute in minecraft:overworld run setblock 380 67 40 coarse_dirt
execute in minecraft:overworld run fill 380 68 40 380 144 40 air
execute in minecraft:overworld run fill 380 58 41 380 63 41 stone
execute in minecraft:overworld run fill 380 64 41 380 65 41 dirt
execute in minecraft:overworld run setblock 380 66 41 grass_block
execute in minecraft:overworld run fill 380 67 41 380 144 41 air
execute in minecraft:overworld run fill 380 58 42 380 63 42 stone
execute in minecraft:overworld run fill 380 64 42 380 65 42 dirt
execute in minecraft:overworld run setblock 380 66 42 grass_block
execute in minecraft:overworld run fill 380 67 42 380 144 42 air
execute in minecraft:overworld run fill 380 58 43 380 62 43 stone
execute in minecraft:overworld run fill 380 63 43 380 64 43 dirt
execute in minecraft:overworld run setblock 380 65 43 grass_block
execute in minecraft:overworld run fill 380 66 43 380 144 43 air
execute in minecraft:overworld run fill 380 58 44 380 62 44 stone
execute in minecraft:overworld run fill 380 63 44 380 64 44 dirt
schedule function blade_gallery:random/battlefield/part_69 1t replace
