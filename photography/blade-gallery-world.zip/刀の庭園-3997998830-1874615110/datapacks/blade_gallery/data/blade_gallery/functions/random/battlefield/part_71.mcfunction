execute in minecraft:overworld run fill 382 62 -22 382 63 -22 dirt
execute in minecraft:overworld run setblock 382 64 -22 coarse_dirt
execute in minecraft:overworld run fill 382 65 -22 382 144 -22 air
execute in minecraft:overworld run fill 382 58 -21 382 61 -21 stone
execute in minecraft:overworld run fill 382 62 -21 382 63 -21 dirt
execute in minecraft:overworld run setblock 382 64 -21 grass_block
execute in minecraft:overworld run fill 382 65 -21 382 144 -21 air
execute in minecraft:overworld run fill 382 58 -20 382 60 -20 stone
execute in minecraft:overworld run fill 382 61 -20 382 62 -20 dirt
execute in minecraft:overworld run setblock 382 63 -20 gravel
execute in minecraft:overworld run fill 382 64 -20 382 144 -20 air
execute in minecraft:overworld run fill 382 64 -20 382 64 -20 water
execute in minecraft:overworld run fill 382 58 -19 382 60 -19 stone
execute in minecraft:overworld run fill 382 61 -19 382 62 -19 dirt
execute in minecraft:overworld run setblock 382 63 -19 gravel
execute in minecraft:overworld run fill 382 64 -19 382 144 -19 air
execute in minecraft:overworld run fill 382 64 -19 382 64 -19 water
execute in minecraft:overworld run fill 382 58 -18 382 60 -18 stone
execute in minecraft:overworld run fill 382 61 -18 382 62 -18 dirt
execute in minecraft:overworld run setblock 382 63 -18 gravel
execute in minecraft:overworld run fill 382 64 -18 382 144 -18 air
execute in minecraft:overworld run fill 382 64 -18 382 64 -18 water
execute in minecraft:overworld run fill 382 58 -17 382 60 -17 stone
execute in minecraft:overworld run fill 382 61 -17 382 62 -17 dirt
execute in minecraft:overworld run setblock 382 63 -17 gravel
execute in minecraft:overworld run fill 382 64 -17 382 144 -17 air
execute in minecraft:overworld run fill 382 64 -17 382 64 -17 water
execute in minecraft:overworld run fill 382 58 -16 382 60 -16 stone
execute in minecraft:overworld run fill 382 61 -16 382 62 -16 dirt
execute in minecraft:overworld run setblock 382 63 -16 gravel
execute in minecraft:overworld run fill 382 64 -16 382 144 -16 air
execute in minecraft:overworld run fill 382 64 -16 382 64 -16 water
execute in minecraft:overworld run fill 382 58 -15 382 60 -15 stone
execute in minecraft:overworld run fill 382 61 -15 382 62 -15 dirt
execute in minecraft:overworld run setblock 382 63 -15 gravel
execute in minecraft:overworld run fill 382 64 -15 382 144 -15 air
execute in minecraft:overworld run fill 382 64 -15 382 64 -15 water
execute in minecraft:overworld run fill 382 58 -14 382 60 -14 stone
execute in minecraft:overworld run fill 382 61 -14 382 62 -14 dirt
execute in minecraft:overworld run setblock 382 63 -14 gravel
execute in minecraft:overworld run fill 382 64 -14 382 144 -14 air
execute in minecraft:overworld run fill 382 64 -14 382 64 -14 water
execute in minecraft:overworld run fill 382 58 -13 382 60 -13 stone
execute in minecraft:overworld run fill 382 61 -13 382 62 -13 dirt
execute in minecraft:overworld run setblock 382 63 -13 gravel
execute in minecraft:overworld run fill 382 64 -13 382 144 -13 air
execute in minecraft:overworld run fill 382 64 -13 382 64 -13 water
execute in minecraft:overworld run fill 382 58 -12 382 60 -12 stone
execute in minecraft:overworld run fill 382 61 -12 382 62 -12 dirt
execute in minecraft:overworld run setblock 382 63 -12 gravel
execute in minecraft:overworld run fill 382 64 -12 382 144 -12 air
execute in minecraft:overworld run fill 382 64 -12 382 64 -12 water
execute in minecraft:overworld run fill 382 58 -11 382 61 -11 stone
execute in minecraft:overworld run fill 382 62 -11 382 63 -11 dirt
execute in minecraft:overworld run setblock 382 64 -11 coarse_dirt
execute in minecraft:overworld run fill 382 65 -11 382 144 -11 air
execute in minecraft:overworld run fill 382 58 -10 382 61 -10 stone
execute in minecraft:overworld run fill 382 62 -10 382 63 -10 dirt
execute in minecraft:overworld run setblock 382 64 -10 coarse_dirt
execute in minecraft:overworld run fill 382 65 -10 382 144 -10 air
execute in minecraft:overworld run fill 382 58 -9 382 61 -9 stone
execute in minecraft:overworld run fill 382 62 -9 382 63 -9 dirt
execute in minecraft:overworld run setblock 382 64 -9 grass_block
execute in minecraft:overworld run fill 382 65 -9 382 144 -9 air
execute in minecraft:overworld run fill 382 58 -8 382 62 -8 stone
execute in minecraft:overworld run fill 382 63 -8 382 64 -8 dirt
execute in minecraft:overworld run setblock 382 65 -8 coarse_dirt
execute in minecraft:overworld run fill 382 66 -8 382 144 -8 air
execute in minecraft:overworld run fill 382 58 -7 382 62 -7 stone
execute in minecraft:overworld run fill 382 63 -7 382 64 -7 dirt
execute in minecraft:overworld run setblock 382 65 -7 grass_block
execute in minecraft:overworld run fill 382 66 -7 382 144 -7 air
execute in minecraft:overworld run setblock 382 66 -7 grass
execute in minecraft:overworld run fill 382 58 -6 382 62 -6 stone
execute in minecraft:overworld run fill 382 63 -6 382 64 -6 dirt
execute in minecraft:overworld run setblock 382 65 -6 coarse_dirt
execute in minecraft:overworld run fill 382 66 -6 382 144 -6 air
execute in minecraft:overworld run fill 382 58 -5 382 62 -5 stone
execute in minecraft:overworld run fill 382 63 -5 382 64 -5 dirt
execute in minecraft:overworld run setblock 382 65 -5 coarse_dirt
execute in minecraft:overworld run fill 382 66 -5 382 144 -5 air
execute in minecraft:overworld run fill 382 58 -4 382 63 -4 stone
execute in minecraft:overworld run fill 382 64 -4 382 65 -4 dirt
execute in minecraft:overworld run setblock 382 66 -4 coarse_dirt
execute in minecraft:overworld run fill 382 67 -4 382 144 -4 air
execute in minecraft:overworld run fill 382 58 -3 382 63 -3 stone
execute in minecraft:overworld run fill 382 64 -3 382 65 -3 dirt
execute in minecraft:overworld run setblock 382 66 -3 coarse_dirt
execute in minecraft:overworld run fill 382 67 -3 382 144 -3 air
execute in minecraft:overworld run fill 382 58 -2 382 63 -2 stone
execute in minecraft:overworld run fill 382 64 -2 382 65 -2 dirt
execute in minecraft:overworld run setblock 382 66 -2 coarse_dirt
execute in minecraft:overworld run fill 382 67 -2 382 144 -2 air
execute in minecraft:overworld run fill 382 58 -1 382 63 -1 stone
execute in minecraft:overworld run fill 382 64 -1 382 65 -1 dirt
execute in minecraft:overworld run setblock 382 66 -1 coarse_dirt
execute in minecraft:overworld run fill 382 67 -1 382 144 -1 air
execute in minecraft:overworld run fill 382 58 0 382 63 0 stone
execute in minecraft:overworld run fill 382 64 0 382 65 0 dirt
execute in minecraft:overworld run setblock 382 66 0 coarse_dirt
execute in minecraft:overworld run fill 382 67 0 382 144 0 air
execute in minecraft:overworld run fill 382 58 1 382 63 1 stone
execute in minecraft:overworld run fill 382 64 1 382 65 1 dirt
execute in minecraft:overworld run setblock 382 66 1 coarse_dirt
execute in minecraft:overworld run fill 382 67 1 382 144 1 air
execute in minecraft:overworld run fill 382 58 2 382 63 2 stone
execute in minecraft:overworld run fill 382 64 2 382 65 2 dirt
execute in minecraft:overworld run setblock 382 66 2 coarse_dirt
execute in minecraft:overworld run fill 382 67 2 382 144 2 air
execute in minecraft:overworld run fill 382 58 3 382 64 3 stone
execute in minecraft:overworld run fill 382 65 3 382 66 3 dirt
execute in minecraft:overworld run setblock 382 67 3 coarse_dirt
execute in minecraft:overworld run fill 382 68 3 382 144 3 air
execute in minecraft:overworld run fill 382 58 4 382 64 4 stone
execute in minecraft:overworld run fill 382 65 4 382 66 4 dirt
execute in minecraft:overworld run setblock 382 67 4 coarse_dirt
execute in minecraft:overworld run fill 382 68 4 382 144 4 air
execute in minecraft:overworld run fill 382 58 5 382 64 5 stone
execute in minecraft:overworld run fill 382 65 5 382 66 5 dirt
execute in minecraft:overworld run setblock 382 67 5 coarse_dirt
execute in minecraft:overworld run fill 382 68 5 382 144 5 air
execute in minecraft:overworld run fill 382 58 6 382 64 6 stone
execute in minecraft:overworld run fill 382 65 6 382 66 6 dirt
execute in minecraft:overworld run setblock 382 67 6 grass_block
execute in minecraft:overworld run fill 382 68 6 382 144 6 air
execute in minecraft:overworld run setblock 382 68 6 grass
execute in minecraft:overworld run fill 382 58 7 382 64 7 stone
execute in minecraft:overworld run fill 382 65 7 382 66 7 dirt
execute in minecraft:overworld run setblock 382 67 7 grass_block
execute in minecraft:overworld run fill 382 68 7 382 144 7 air
execute in minecraft:overworld run fill 382 58 8 382 64 8 stone
execute in minecraft:overworld run fill 382 65 8 382 66 8 dirt
execute in minecraft:overworld run setblock 382 67 8 grass_block
execute in minecraft:overworld run fill 382 68 8 382 144 8 air
execute in minecraft:overworld run fill 382 58 9 382 64 9 stone
execute in minecraft:overworld run fill 382 65 9 382 66 9 dirt
execute in minecraft:overworld run setblock 382 67 9 coarse_dirt
execute in minecraft:overworld run fill 382 68 9 382 144 9 air
execute in minecraft:overworld run fill 382 58 10 382 64 10 stone
execute in minecraft:overworld run fill 382 65 10 382 66 10 dirt
execute in minecraft:overworld run setblock 382 67 10 coarse_dirt
execute in minecraft:overworld run fill 382 68 10 382 144 10 air
execute in minecraft:overworld run fill 382 58 11 382 64 11 stone
execute in minecraft:overworld run fill 382 65 11 382 66 11 dirt
execute in minecraft:overworld run setblock 382 67 11 coarse_dirt
execute in minecraft:overworld run fill 382 68 11 382 144 11 air
execute in minecraft:overworld run fill 382 58 12 382 64 12 stone
execute in minecraft:overworld run fill 382 65 12 382 66 12 dirt
execute in minecraft:overworld run setblock 382 67 12 coarse_dirt
execute in minecraft:overworld run fill 382 68 12 382 144 12 air
execute in minecraft:overworld run fill 382 58 13 382 65 13 stone
execute in minecraft:overworld run fill 382 66 13 382 67 13 dirt
execute in minecraft:overworld run setblock 382 68 13 coarse_dirt
execute in minecraft:overworld run fill 382 69 13 382 144 13 air
execute in minecraft:overworld run fill 382 58 14 382 65 14 stone
execute in minecraft:overworld run fill 382 66 14 382 67 14 dirt
execute in minecraft:overworld run setblock 382 68 14 coarse_dirt
execute in minecraft:overworld run fill 382 69 14 382 144 14 air
execute in minecraft:overworld run fill 382 58 15 382 65 15 stone
execute in minecraft:overworld run fill 382 66 15 382 67 15 dirt
execute in minecraft:overworld run setblock 382 68 15 coarse_dirt
execute in minecraft:overworld run fill 382 69 15 382 144 15 air
execute in minecraft:overworld run fill 382 58 16 382 66 16 stone
execute in minecraft:overworld run fill 382 67 16 382 68 16 dirt
execute in minecraft:overworld run setblock 382 69 16 coarse_dirt
execute in minecraft:overworld run fill 382 70 16 382 144 16 air
execute in minecraft:overworld run setblock 382 70 16 grass
execute in minecraft:overworld run fill 382 58 17 382 66 17 stone
execute in minecraft:overworld run fill 382 67 17 382 68 17 dirt
execute in minecraft:overworld run setblock 382 69 17 coarse_dirt
execute in minecraft:overworld run fill 382 70 17 382 144 17 air
execute in minecraft:overworld run fill 382 58 18 382 66 18 stone
execute in minecraft:overworld run fill 382 67 18 382 68 18 dirt
execute in minecraft:overworld run setblock 382 69 18 coarse_dirt
execute in minecraft:overworld run fill 382 70 18 382 144 18 air
execute in minecraft:overworld run fill 382 58 19 382 66 19 stone
execute in minecraft:overworld run fill 382 67 19 382 68 19 dirt
execute in minecraft:overworld run setblock 382 69 19 grass_block
execute in minecraft:overworld run fill 382 70 19 382 144 19 air
execute in minecraft:overworld run fill 382 58 20 382 66 20 stone
execute in minecraft:overworld run fill 382 67 20 382 68 20 dirt
execute in minecraft:overworld run setblock 382 69 20 grass_block
execute in minecraft:overworld run fill 382 70 20 382 144 20 air
execute in minecraft:overworld run fill 382 58 21 382 66 21 stone
execute in minecraft:overworld run fill 382 67 21 382 68 21 dirt
execute in minecraft:overworld run setblock 382 69 21 grass_block
execute in minecraft:overworld run fill 382 70 21 382 144 21 air
execute in minecraft:overworld run fill 382 58 22 382 66 22 stone
execute in minecraft:overworld run fill 382 67 22 382 68 22 dirt
execute in minecraft:overworld run setblock 382 69 22 grass_block
execute in minecraft:overworld run fill 382 70 22 382 144 22 air
execute in minecraft:overworld run fill 382 58 23 382 66 23 stone
execute in minecraft:overworld run fill 382 67 23 382 68 23 dirt
execute in minecraft:overworld run setblock 382 69 23 coarse_dirt
execute in minecraft:overworld run fill 382 70 23 382 144 23 air
execute in minecraft:overworld run fill 382 58 24 382 65 24 stone
execute in minecraft:overworld run fill 382 66 24 382 67 24 dirt
execute in minecraft:overworld run setblock 382 68 24 coarse_dirt
execute in minecraft:overworld run fill 382 69 24 382 144 24 air
execute in minecraft:overworld run setblock 382 69 24 grass
execute in minecraft:overworld run fill 382 58 25 382 65 25 stone
execute in minecraft:overworld run fill 382 66 25 382 67 25 dirt
execute in minecraft:overworld run setblock 382 68 25 grass_block
execute in minecraft:overworld run fill 382 69 25 382 144 25 air
execute in minecraft:overworld run setblock 382 69 25 grass
execute in minecraft:overworld run fill 382 58 26 382 65 26 stone
execute in minecraft:overworld run fill 382 66 26 382 67 26 dirt
execute in minecraft:overworld run setblock 382 68 26 coarse_dirt
execute in minecraft:overworld run fill 382 69 26 382 144 26 air
execute in minecraft:overworld run fill 382 58 27 382 65 27 stone
execute in minecraft:overworld run fill 382 66 27 382 67 27 dirt
execute in minecraft:overworld run setblock 382 68 27 coarse_dirt
execute in minecraft:overworld run fill 382 69 27 382 144 27 air
execute in minecraft:overworld run setblock 382 69 27 mossy_cobblestone
execute in minecraft:overworld run fill 382 58 28 382 65 28 stone
execute in minecraft:overworld run fill 382 66 28 382 67 28 dirt
execute in minecraft:overworld run setblock 382 68 28 coarse_dirt
execute in minecraft:overworld run fill 382 69 28 382 144 28 air
execute in minecraft:overworld run fill 382 58 29 382 65 29 stone
execute in minecraft:overworld run fill 382 66 29 382 67 29 dirt
execute in minecraft:overworld run setblock 382 68 29 coarse_dirt
execute in minecraft:overworld run fill 382 69 29 382 144 29 air
execute in minecraft:overworld run fill 382 58 30 382 65 30 stone
execute in minecraft:overworld run fill 382 66 30 382 67 30 dirt
execute in minecraft:overworld run setblock 382 68 30 coarse_dirt
execute in minecraft:overworld run fill 382 69 30 382 144 30 air
execute in minecraft:overworld run fill 382 58 31 382 64 31 stone
execute in minecraft:overworld run fill 382 65 31 382 66 31 dirt
execute in minecraft:overworld run setblock 382 67 31 grass_block
execute in minecraft:overworld run fill 382 68 31 382 144 31 air
execute in minecraft:overworld run fill 382 58 32 382 64 32 stone
execute in minecraft:overworld run fill 382 65 32 382 66 32 dirt
execute in minecraft:overworld run setblock 382 67 32 grass_block
execute in minecraft:overworld run fill 382 68 32 382 144 32 air
execute in minecraft:overworld run fill 382 58 33 382 64 33 stone
execute in minecraft:overworld run fill 382 65 33 382 66 33 dirt
execute in minecraft:overworld run setblock 382 67 33 coarse_dirt
execute in minecraft:overworld run fill 382 68 33 382 144 33 air
execute in minecraft:overworld run setblock 382 68 33 grass
execute in minecraft:overworld run fill 382 58 34 382 64 34 stone
execute in minecraft:overworld run fill 382 65 34 382 66 34 dirt
execute in minecraft:overworld run setblock 382 67 34 coarse_dirt
execute in minecraft:overworld run fill 382 68 34 382 144 34 air
execute in minecraft:overworld run fill 382 58 35 382 64 35 stone
execute in minecraft:overworld run fill 382 65 35 382 66 35 dirt
execute in minecraft:overworld run setblock 382 67 35 coarse_dirt
execute in minecraft:overworld run fill 382 68 35 382 144 35 air
execute in minecraft:overworld run setblock 382 68 35 grass
execute in minecraft:overworld run fill 382 58 36 382 64 36 stone
execute in minecraft:overworld run fill 382 65 36 382 66 36 dirt
execute in minecraft:overworld run setblock 382 67 36 coarse_dirt
execute in minecraft:overworld run fill 382 68 36 382 144 36 air
execute in minecraft:overworld run fill 382 58 37 382 64 37 stone
execute in minecraft:overworld run fill 382 65 37 382 66 37 dirt
execute in minecraft:overworld run setblock 382 67 37 coarse_dirt
execute in minecraft:overworld run fill 382 68 37 382 144 37 air
schedule function blade_gallery:random/battlefield/part_72 1t replace
