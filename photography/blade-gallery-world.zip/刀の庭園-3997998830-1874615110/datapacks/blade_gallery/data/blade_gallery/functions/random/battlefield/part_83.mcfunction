execute in minecraft:overworld run fill 389 62 7 389 144 7 air
execute in minecraft:overworld run fill 389 62 7 389 64 7 water
execute in minecraft:overworld run fill 389 58 8 389 58 8 stone
execute in minecraft:overworld run fill 389 59 8 389 60 8 dirt
execute in minecraft:overworld run setblock 389 61 8 gravel
execute in minecraft:overworld run fill 389 62 8 389 144 8 air
execute in minecraft:overworld run fill 389 62 8 389 64 8 water
execute in minecraft:overworld run fill 389 58 9 389 58 9 stone
execute in minecraft:overworld run fill 389 59 9 389 60 9 dirt
execute in minecraft:overworld run setblock 389 61 9 gravel
execute in minecraft:overworld run fill 389 62 9 389 144 9 air
execute in minecraft:overworld run fill 389 62 9 389 64 9 water
execute in minecraft:overworld run fill 389 58 10 389 59 10 stone
execute in minecraft:overworld run fill 389 60 10 389 61 10 dirt
execute in minecraft:overworld run setblock 389 62 10 gravel
execute in minecraft:overworld run fill 389 63 10 389 144 10 air
execute in minecraft:overworld run fill 389 63 10 389 64 10 water
execute in minecraft:overworld run fill 389 58 11 389 59 11 stone
execute in minecraft:overworld run fill 389 60 11 389 61 11 dirt
execute in minecraft:overworld run setblock 389 62 11 gravel
execute in minecraft:overworld run fill 389 63 11 389 144 11 air
execute in minecraft:overworld run fill 389 63 11 389 64 11 water
execute in minecraft:overworld run fill 389 58 12 389 59 12 stone
execute in minecraft:overworld run fill 389 60 12 389 61 12 dirt
execute in minecraft:overworld run setblock 389 62 12 gravel
execute in minecraft:overworld run fill 389 63 12 389 144 12 air
execute in minecraft:overworld run fill 389 63 12 389 64 12 water
execute in minecraft:overworld run fill 389 58 13 389 59 13 stone
execute in minecraft:overworld run fill 389 60 13 389 61 13 dirt
execute in minecraft:overworld run setblock 389 62 13 gravel
execute in minecraft:overworld run fill 389 63 13 389 144 13 air
execute in minecraft:overworld run fill 389 63 13 389 64 13 water
execute in minecraft:overworld run fill 389 58 14 389 59 14 stone
execute in minecraft:overworld run fill 389 60 14 389 61 14 dirt
execute in minecraft:overworld run setblock 389 62 14 gravel
execute in minecraft:overworld run fill 389 63 14 389 144 14 air
execute in minecraft:overworld run fill 389 63 14 389 64 14 water
execute in minecraft:overworld run fill 389 58 15 389 60 15 stone
execute in minecraft:overworld run fill 389 61 15 389 62 15 dirt
execute in minecraft:overworld run setblock 389 63 15 gravel
execute in minecraft:overworld run fill 389 64 15 389 144 15 air
execute in minecraft:overworld run fill 389 64 15 389 64 15 water
execute in minecraft:overworld run fill 389 58 16 389 60 16 stone
execute in minecraft:overworld run fill 389 61 16 389 62 16 dirt
execute in minecraft:overworld run setblock 389 63 16 gravel
execute in minecraft:overworld run fill 389 64 16 389 144 16 air
execute in minecraft:overworld run fill 389 64 16 389 64 16 water
execute in minecraft:overworld run fill 389 58 17 389 60 17 stone
execute in minecraft:overworld run fill 389 61 17 389 62 17 dirt
execute in minecraft:overworld run setblock 389 63 17 gravel
execute in minecraft:overworld run fill 389 64 17 389 144 17 air
execute in minecraft:overworld run fill 389 64 17 389 64 17 water
execute in minecraft:overworld run fill 389 58 18 389 60 18 stone
execute in minecraft:overworld run fill 389 61 18 389 62 18 dirt
execute in minecraft:overworld run setblock 389 63 18 gravel
execute in minecraft:overworld run fill 389 64 18 389 144 18 air
execute in minecraft:overworld run fill 389 64 18 389 64 18 water
execute in minecraft:overworld run fill 389 58 19 389 60 19 stone
execute in minecraft:overworld run fill 389 61 19 389 62 19 dirt
execute in minecraft:overworld run setblock 389 63 19 gravel
execute in minecraft:overworld run fill 389 64 19 389 144 19 air
execute in minecraft:overworld run fill 389 64 19 389 64 19 water
execute in minecraft:overworld run fill 389 58 20 389 60 20 stone
execute in minecraft:overworld run fill 389 61 20 389 62 20 dirt
execute in minecraft:overworld run setblock 389 63 20 gravel
execute in minecraft:overworld run fill 389 64 20 389 144 20 air
execute in minecraft:overworld run fill 389 64 20 389 64 20 water
execute in minecraft:overworld run fill 389 58 21 389 60 21 stone
execute in minecraft:overworld run fill 389 61 21 389 62 21 dirt
execute in minecraft:overworld run setblock 389 63 21 gravel
execute in minecraft:overworld run fill 389 64 21 389 144 21 air
execute in minecraft:overworld run fill 389 64 21 389 64 21 water
execute in minecraft:overworld run fill 389 58 22 389 60 22 stone
execute in minecraft:overworld run fill 389 61 22 389 62 22 dirt
execute in minecraft:overworld run setblock 389 63 22 gravel
execute in minecraft:overworld run fill 389 64 22 389 144 22 air
execute in minecraft:overworld run fill 389 64 22 389 64 22 water
execute in minecraft:overworld run fill 389 58 23 389 60 23 stone
execute in minecraft:overworld run fill 389 61 23 389 62 23 dirt
execute in minecraft:overworld run setblock 389 63 23 gravel
execute in minecraft:overworld run fill 389 64 23 389 144 23 air
execute in minecraft:overworld run fill 389 64 23 389 64 23 water
execute in minecraft:overworld run fill 389 58 24 389 60 24 stone
execute in minecraft:overworld run fill 389 61 24 389 62 24 dirt
execute in minecraft:overworld run setblock 389 63 24 gravel
execute in minecraft:overworld run fill 389 64 24 389 144 24 air
execute in minecraft:overworld run fill 389 64 24 389 64 24 water
execute in minecraft:overworld run fill 389 58 25 389 59 25 stone
execute in minecraft:overworld run fill 389 60 25 389 61 25 dirt
execute in minecraft:overworld run setblock 389 62 25 gravel
execute in minecraft:overworld run fill 389 63 25 389 144 25 air
execute in minecraft:overworld run fill 389 63 25 389 64 25 water
execute in minecraft:overworld run fill 389 58 26 389 59 26 stone
execute in minecraft:overworld run fill 389 60 26 389 61 26 dirt
execute in minecraft:overworld run setblock 389 62 26 gravel
execute in minecraft:overworld run fill 389 63 26 389 144 26 air
execute in minecraft:overworld run fill 389 63 26 389 64 26 water
execute in minecraft:overworld run fill 389 58 27 389 59 27 stone
execute in minecraft:overworld run fill 389 60 27 389 61 27 dirt
execute in minecraft:overworld run setblock 389 62 27 gravel
execute in minecraft:overworld run fill 389 63 27 389 144 27 air
execute in minecraft:overworld run fill 389 63 27 389 64 27 water
execute in minecraft:overworld run fill 389 58 28 389 59 28 stone
execute in minecraft:overworld run fill 389 60 28 389 61 28 dirt
execute in minecraft:overworld run setblock 389 62 28 gravel
execute in minecraft:overworld run fill 389 63 28 389 144 28 air
execute in minecraft:overworld run fill 389 63 28 389 64 28 water
execute in minecraft:overworld run fill 389 58 29 389 59 29 stone
execute in minecraft:overworld run fill 389 60 29 389 61 29 dirt
execute in minecraft:overworld run setblock 389 62 29 gravel
execute in minecraft:overworld run fill 389 63 29 389 144 29 air
execute in minecraft:overworld run fill 389 63 29 389 64 29 water
execute in minecraft:overworld run fill 389 58 30 389 58 30 stone
execute in minecraft:overworld run fill 389 59 30 389 60 30 dirt
execute in minecraft:overworld run setblock 389 61 30 gravel
execute in minecraft:overworld run fill 389 62 30 389 144 30 air
execute in minecraft:overworld run fill 389 62 30 389 64 30 water
execute in minecraft:overworld run fill 389 58 31 389 58 31 stone
execute in minecraft:overworld run fill 389 59 31 389 60 31 dirt
execute in minecraft:overworld run setblock 389 61 31 gravel
execute in minecraft:overworld run fill 389 62 31 389 144 31 air
execute in minecraft:overworld run fill 389 62 31 389 64 31 water
execute in minecraft:overworld run fill 389 58 32 389 58 32 stone
execute in minecraft:overworld run fill 389 59 32 389 60 32 dirt
execute in minecraft:overworld run setblock 389 61 32 gravel
execute in minecraft:overworld run fill 389 62 32 389 144 32 air
execute in minecraft:overworld run fill 389 62 32 389 64 32 water
execute in minecraft:overworld run fill 389 58 33 389 58 33 stone
execute in minecraft:overworld run fill 389 59 33 389 60 33 dirt
execute in minecraft:overworld run setblock 389 61 33 gravel
execute in minecraft:overworld run fill 389 62 33 389 144 33 air
execute in minecraft:overworld run fill 389 62 33 389 64 33 water
execute in minecraft:overworld run fill 389 58 34 389 58 34 stone
execute in minecraft:overworld run fill 389 59 34 389 60 34 dirt
execute in minecraft:overworld run setblock 389 61 34 gravel
execute in minecraft:overworld run fill 389 62 34 389 144 34 air
execute in minecraft:overworld run fill 389 62 34 389 64 34 water
execute in minecraft:overworld run fill 389 58 35 389 58 35 stone
execute in minecraft:overworld run fill 389 59 35 389 60 35 dirt
execute in minecraft:overworld run setblock 389 61 35 gravel
execute in minecraft:overworld run fill 389 62 35 389 144 35 air
execute in minecraft:overworld run fill 389 62 35 389 64 35 water
execute in minecraft:overworld run fill 389 58 36 389 59 36 stone
execute in minecraft:overworld run fill 389 60 36 389 61 36 dirt
execute in minecraft:overworld run setblock 389 62 36 gravel
execute in minecraft:overworld run fill 389 63 36 389 144 36 air
execute in minecraft:overworld run fill 389 63 36 389 64 36 water
execute in minecraft:overworld run fill 389 58 37 389 59 37 stone
execute in minecraft:overworld run fill 389 60 37 389 61 37 dirt
execute in minecraft:overworld run setblock 389 62 37 gravel
execute in minecraft:overworld run fill 389 63 37 389 144 37 air
execute in minecraft:overworld run fill 389 63 37 389 64 37 water
execute in minecraft:overworld run fill 389 58 38 389 59 38 stone
execute in minecraft:overworld run fill 389 60 38 389 61 38 dirt
execute in minecraft:overworld run setblock 389 62 38 gravel
execute in minecraft:overworld run fill 389 63 38 389 144 38 air
execute in minecraft:overworld run fill 389 63 38 389 64 38 water
execute in minecraft:overworld run fill 389 58 39 389 59 39 stone
execute in minecraft:overworld run fill 389 60 39 389 61 39 dirt
execute in minecraft:overworld run setblock 389 62 39 gravel
execute in minecraft:overworld run fill 389 63 39 389 144 39 air
execute in minecraft:overworld run fill 389 63 39 389 64 39 water
execute in minecraft:overworld run fill 389 58 40 389 60 40 stone
execute in minecraft:overworld run fill 389 61 40 389 62 40 dirt
execute in minecraft:overworld run setblock 389 63 40 gravel
execute in minecraft:overworld run fill 389 64 40 389 144 40 air
execute in minecraft:overworld run fill 389 64 40 389 64 40 water
execute in minecraft:overworld run fill 389 58 41 389 60 41 stone
execute in minecraft:overworld run fill 389 61 41 389 62 41 dirt
execute in minecraft:overworld run setblock 389 63 41 gravel
execute in minecraft:overworld run fill 389 64 41 389 144 41 air
execute in minecraft:overworld run fill 389 64 41 389 64 41 water
execute in minecraft:overworld run fill 389 58 42 389 60 42 stone
execute in minecraft:overworld run fill 389 61 42 389 62 42 dirt
execute in minecraft:overworld run setblock 389 63 42 gravel
execute in minecraft:overworld run fill 389 64 42 389 144 42 air
execute in minecraft:overworld run fill 389 64 42 389 64 42 water
execute in minecraft:overworld run fill 389 58 43 389 61 43 stone
execute in minecraft:overworld run fill 389 62 43 389 63 43 dirt
execute in minecraft:overworld run setblock 389 64 43 grass_block
execute in minecraft:overworld run fill 389 65 43 389 144 43 air
execute in minecraft:overworld run fill 389 58 44 389 61 44 stone
execute in minecraft:overworld run fill 389 62 44 389 63 44 dirt
execute in minecraft:overworld run setblock 389 64 44 coarse_dirt
execute in minecraft:overworld run fill 389 65 44 389 144 44 air
execute in minecraft:overworld run fill 389 58 45 389 61 45 stone
execute in minecraft:overworld run fill 389 62 45 389 63 45 dirt
execute in minecraft:overworld run setblock 389 64 45 coarse_dirt
execute in minecraft:overworld run fill 389 65 45 389 144 45 air
execute in minecraft:overworld run fill 389 58 46 389 61 46 stone
execute in minecraft:overworld run fill 389 62 46 389 63 46 dirt
execute in minecraft:overworld run setblock 389 64 46 coarse_dirt
execute in minecraft:overworld run fill 389 65 46 389 144 46 air
execute in minecraft:overworld run fill 389 58 47 389 61 47 stone
execute in minecraft:overworld run fill 389 62 47 389 63 47 dirt
execute in minecraft:overworld run setblock 389 64 47 grass_block
execute in minecraft:overworld run fill 389 65 47 389 144 47 air
execute in minecraft:overworld run fill 390 58 -48 390 61 -48 stone
execute in minecraft:overworld run fill 390 62 -48 390 63 -48 dirt
execute in minecraft:overworld run setblock 390 64 -48 coarse_dirt
execute in minecraft:overworld run fill 390 65 -48 390 144 -48 air
execute in minecraft:overworld run fill 390 58 -47 390 62 -47 stone
execute in minecraft:overworld run fill 390 63 -47 390 64 -47 dirt
execute in minecraft:overworld run setblock 390 65 -47 coarse_dirt
execute in minecraft:overworld run fill 390 66 -47 390 144 -47 air
execute in minecraft:overworld run fill 390 58 -46 390 64 -46 stone
execute in minecraft:overworld run fill 390 65 -46 390 66 -46 dirt
execute in minecraft:overworld run setblock 390 67 -46 coarse_dirt
execute in minecraft:overworld run fill 390 68 -46 390 144 -46 air
execute in minecraft:overworld run fill 390 58 -45 390 65 -45 stone
execute in minecraft:overworld run fill 390 66 -45 390 67 -45 dirt
execute in minecraft:overworld run setblock 390 68 -45 coarse_dirt
execute in minecraft:overworld run fill 390 69 -45 390 144 -45 air
execute in minecraft:overworld run fill 390 58 -44 390 67 -44 stone
execute in minecraft:overworld run fill 390 68 -44 390 69 -44 dirt
execute in minecraft:overworld run setblock 390 70 -44 coarse_dirt
execute in minecraft:overworld run fill 390 71 -44 390 144 -44 air
execute in minecraft:overworld run fill 390 58 -43 390 68 -43 stone
execute in minecraft:overworld run fill 390 69 -43 390 70 -43 dirt
execute in minecraft:overworld run setblock 390 71 -43 grass_block
execute in minecraft:overworld run fill 390 72 -43 390 144 -43 air
execute in minecraft:overworld run fill 390 58 -42 390 69 -42 stone
execute in minecraft:overworld run fill 390 70 -42 390 71 -42 dirt
execute in minecraft:overworld run setblock 390 72 -42 coarse_dirt
execute in minecraft:overworld run fill 390 73 -42 390 144 -42 air
execute in minecraft:overworld run fill 390 58 -41 390 71 -41 stone
execute in minecraft:overworld run fill 390 72 -41 390 73 -41 dirt
execute in minecraft:overworld run setblock 390 74 -41 coarse_dirt
execute in minecraft:overworld run fill 390 75 -41 390 144 -41 air
execute in minecraft:overworld run fill 390 58 -40 390 72 -40 stone
execute in minecraft:overworld run fill 390 73 -40 390 74 -40 dirt
execute in minecraft:overworld run setblock 390 75 -40 grass_block
execute in minecraft:overworld run fill 390 76 -40 390 144 -40 air
execute in minecraft:overworld run setblock 390 76 -40 mossy_cobblestone
execute in minecraft:overworld run fill 390 58 -39 390 73 -39 stone
execute in minecraft:overworld run fill 390 74 -39 390 75 -39 dirt
execute in minecraft:overworld run setblock 390 76 -39 grass_block
execute in minecraft:overworld run fill 390 77 -39 390 144 -39 air
execute in minecraft:overworld run fill 390 58 -38 390 74 -38 stone
execute in minecraft:overworld run fill 390 75 -38 390 76 -38 dirt
execute in minecraft:overworld run setblock 390 77 -38 coarse_dirt
execute in minecraft:overworld run fill 390 78 -38 390 144 -38 air
execute in minecraft:overworld run fill 390 58 -37 390 73 -37 stone
execute in minecraft:overworld run fill 390 74 -37 390 75 -37 dirt
execute in minecraft:overworld run setblock 390 76 -37 grass_block
execute in minecraft:overworld run fill 390 77 -37 390 144 -37 air
execute in minecraft:overworld run fill 390 58 -36 390 73 -36 stone
execute in minecraft:overworld run fill 390 74 -36 390 75 -36 dirt
execute in minecraft:overworld run setblock 390 76 -36 coarse_dirt
execute in minecraft:overworld run fill 390 77 -36 390 144 -36 air
execute in minecraft:overworld run fill 390 58 -35 390 73 -35 stone
execute in minecraft:overworld run fill 390 74 -35 390 75 -35 dirt
execute in minecraft:overworld run setblock 390 76 -35 coarse_dirt
execute in minecraft:overworld run fill 390 77 -35 390 144 -35 air
execute in minecraft:overworld run fill 390 58 -34 390 73 -34 stone
execute in minecraft:overworld run fill 390 74 -34 390 75 -34 dirt
schedule function blade_gallery:random/battlefield/part_84 1t replace
