data modify storage blade_gallery:state random_all set value 1b
function blade_gallery:random/rubble/start
