execute in minecraft:overworld run fill 422 70 16 422 71 16 dirt
execute in minecraft:overworld run setblock 422 72 16 coarse_dirt
execute in minecraft:overworld run fill 422 73 16 422 144 16 air
execute in minecraft:overworld run fill 422 58 17 422 69 17 stone
execute in minecraft:overworld run fill 422 70 17 422 71 17 dirt
execute in minecraft:overworld run setblock 422 72 17 grass_block
execute in minecraft:overworld run fill 422 73 17 422 144 17 air
execute in minecraft:overworld run fill 422 58 18 422 70 18 stone
execute in minecraft:overworld run fill 422 71 18 422 72 18 dirt
execute in minecraft:overworld run setblock 422 73 18 grass_block
execute in minecraft:overworld run fill 422 74 18 422 144 18 air
execute in minecraft:overworld run fill 422 58 19 422 70 19 stone
execute in minecraft:overworld run fill 422 71 19 422 72 19 dirt
execute in minecraft:overworld run setblock 422 73 19 coarse_dirt
execute in minecraft:overworld run fill 422 74 19 422 144 19 air
execute in minecraft:overworld run fill 422 58 20 422 70 20 stone
execute in minecraft:overworld run fill 422 71 20 422 72 20 dirt
execute in minecraft:overworld run setblock 422 73 20 grass_block
execute in minecraft:overworld run fill 422 74 20 422 144 20 air
execute in minecraft:overworld run fill 422 58 21 422 70 21 stone
execute in minecraft:overworld run fill 422 71 21 422 72 21 dirt
execute in minecraft:overworld run setblock 422 73 21 coarse_dirt
execute in minecraft:overworld run fill 422 74 21 422 144 21 air
execute in minecraft:overworld run fill 422 58 22 422 71 22 stone
execute in minecraft:overworld run fill 422 72 22 422 73 22 dirt
execute in minecraft:overworld run setblock 422 74 22 grass_block
execute in minecraft:overworld run fill 422 75 22 422 144 22 air
execute in minecraft:overworld run fill 422 58 23 422 71 23 stone
execute in minecraft:overworld run fill 422 72 23 422 73 23 dirt
execute in minecraft:overworld run setblock 422 74 23 grass_block
execute in minecraft:overworld run fill 422 75 23 422 144 23 air
execute in minecraft:overworld run fill 422 58 24 422 71 24 stone
execute in minecraft:overworld run fill 422 72 24 422 73 24 dirt
execute in minecraft:overworld run setblock 422 74 24 coarse_dirt
execute in minecraft:overworld run fill 422 75 24 422 144 24 air
execute in minecraft:overworld run setblock 422 75 24 grass
execute in minecraft:overworld run fill 422 58 25 422 71 25 stone
execute in minecraft:overworld run fill 422 72 25 422 73 25 dirt
execute in minecraft:overworld run setblock 422 74 25 coarse_dirt
execute in minecraft:overworld run fill 422 75 25 422 144 25 air
execute in minecraft:overworld run fill 422 58 26 422 71 26 stone
execute in minecraft:overworld run fill 422 72 26 422 73 26 dirt
execute in minecraft:overworld run setblock 422 74 26 coarse_dirt
execute in minecraft:overworld run fill 422 75 26 422 144 26 air
execute in minecraft:overworld run setblock 422 75 26 grass
execute in minecraft:overworld run fill 422 58 27 422 71 27 stone
execute in minecraft:overworld run fill 422 72 27 422 73 27 dirt
execute in minecraft:overworld run setblock 422 74 27 grass_block
execute in minecraft:overworld run fill 422 75 27 422 144 27 air
execute in minecraft:overworld run fill 422 58 28 422 72 28 stone
execute in minecraft:overworld run fill 422 73 28 422 74 28 dirt
execute in minecraft:overworld run setblock 422 75 28 coarse_dirt
execute in minecraft:overworld run fill 422 76 28 422 144 28 air
execute in minecraft:overworld run fill 422 58 29 422 72 29 stone
execute in minecraft:overworld run fill 422 73 29 422 74 29 dirt
execute in minecraft:overworld run setblock 422 75 29 coarse_dirt
execute in minecraft:overworld run fill 422 76 29 422 144 29 air
execute in minecraft:overworld run fill 422 58 30 422 71 30 stone
execute in minecraft:overworld run fill 422 72 30 422 73 30 dirt
execute in minecraft:overworld run setblock 422 74 30 coarse_dirt
execute in minecraft:overworld run fill 422 75 30 422 144 30 air
execute in minecraft:overworld run fill 422 58 31 422 71 31 stone
execute in minecraft:overworld run fill 422 72 31 422 73 31 dirt
execute in minecraft:overworld run setblock 422 74 31 grass_block
execute in minecraft:overworld run fill 422 75 31 422 144 31 air
execute in minecraft:overworld run fill 422 58 32 422 71 32 stone
execute in minecraft:overworld run fill 422 72 32 422 73 32 dirt
execute in minecraft:overworld run setblock 422 74 32 coarse_dirt
execute in minecraft:overworld run fill 422 75 32 422 144 32 air
execute in minecraft:overworld run fill 422 58 33 422 71 33 stone
execute in minecraft:overworld run fill 422 72 33 422 73 33 dirt
execute in minecraft:overworld run setblock 422 74 33 coarse_dirt
execute in minecraft:overworld run fill 422 75 33 422 144 33 air
execute in minecraft:overworld run setblock 422 75 33 grass
execute in minecraft:overworld run fill 422 58 34 422 71 34 stone
execute in minecraft:overworld run fill 422 72 34 422 73 34 dirt
execute in minecraft:overworld run setblock 422 74 34 coarse_dirt
execute in minecraft:overworld run fill 422 75 34 422 144 34 air
execute in minecraft:overworld run fill 422 58 35 422 70 35 stone
execute in minecraft:overworld run fill 422 71 35 422 72 35 dirt
execute in minecraft:overworld run setblock 422 73 35 coarse_dirt
execute in minecraft:overworld run fill 422 74 35 422 144 35 air
execute in minecraft:overworld run fill 422 58 36 422 70 36 stone
execute in minecraft:overworld run fill 422 71 36 422 72 36 dirt
execute in minecraft:overworld run setblock 422 73 36 coarse_dirt
execute in minecraft:overworld run fill 422 74 36 422 144 36 air
execute in minecraft:overworld run fill 422 58 37 422 69 37 stone
execute in minecraft:overworld run fill 422 70 37 422 71 37 dirt
execute in minecraft:overworld run setblock 422 72 37 grass_block
execute in minecraft:overworld run fill 422 73 37 422 144 37 air
execute in minecraft:overworld run fill 422 58 38 422 69 38 stone
execute in minecraft:overworld run fill 422 70 38 422 71 38 dirt
execute in minecraft:overworld run setblock 422 72 38 grass_block
execute in minecraft:overworld run fill 422 73 38 422 144 38 air
execute in minecraft:overworld run fill 422 58 39 422 67 39 stone
execute in minecraft:overworld run fill 422 68 39 422 69 39 dirt
execute in minecraft:overworld run setblock 422 70 39 grass_block
execute in minecraft:overworld run fill 422 71 39 422 144 39 air
execute in minecraft:overworld run fill 422 58 40 422 66 40 stone
execute in minecraft:overworld run fill 422 67 40 422 68 40 dirt
execute in minecraft:overworld run setblock 422 69 40 coarse_dirt
execute in minecraft:overworld run fill 422 70 40 422 144 40 air
execute in minecraft:overworld run setblock 422 70 40 grass
execute in minecraft:overworld run fill 422 58 41 422 65 41 stone
execute in minecraft:overworld run fill 422 66 41 422 67 41 dirt
execute in minecraft:overworld run setblock 422 68 41 coarse_dirt
execute in minecraft:overworld run fill 422 69 41 422 144 41 air
execute in minecraft:overworld run setblock 422 69 41 grass
execute in minecraft:overworld run fill 422 58 42 422 64 42 stone
execute in minecraft:overworld run fill 422 65 42 422 66 42 dirt
execute in minecraft:overworld run setblock 422 67 42 coarse_dirt
execute in minecraft:overworld run fill 422 68 42 422 144 42 air
execute in minecraft:overworld run fill 422 58 43 422 63 43 stone
execute in minecraft:overworld run fill 422 64 43 422 65 43 dirt
execute in minecraft:overworld run setblock 422 66 43 grass_block
execute in minecraft:overworld run fill 422 67 43 422 144 43 air
execute in minecraft:overworld run fill 422 58 44 422 62 44 stone
execute in minecraft:overworld run fill 422 63 44 422 64 44 dirt
execute in minecraft:overworld run setblock 422 65 44 grass_block
execute in minecraft:overworld run fill 422 66 44 422 144 44 air
execute in minecraft:overworld run fill 422 58 45 422 62 45 stone
execute in minecraft:overworld run fill 422 63 45 422 64 45 dirt
execute in minecraft:overworld run setblock 422 65 45 coarse_dirt
execute in minecraft:overworld run fill 422 66 45 422 144 45 air
execute in minecraft:overworld run fill 422 58 46 422 61 46 stone
execute in minecraft:overworld run fill 422 62 46 422 63 46 dirt
execute in minecraft:overworld run setblock 422 64 46 coarse_dirt
execute in minecraft:overworld run fill 422 65 46 422 144 46 air
execute in minecraft:overworld run fill 422 58 47 422 61 47 stone
execute in minecraft:overworld run fill 422 62 47 422 63 47 dirt
execute in minecraft:overworld run setblock 422 64 47 grass_block
execute in minecraft:overworld run fill 422 65 47 422 144 47 air
execute in minecraft:overworld run fill 423 58 -48 423 61 -48 stone
execute in minecraft:overworld run fill 423 62 -48 423 63 -48 dirt
execute in minecraft:overworld run setblock 423 64 -48 coarse_dirt
execute in minecraft:overworld run fill 423 65 -48 423 144 -48 air
execute in minecraft:overworld run fill 423 58 -47 423 63 -47 stone
execute in minecraft:overworld run fill 423 64 -47 423 65 -47 dirt
execute in minecraft:overworld run setblock 423 66 -47 coarse_dirt
execute in minecraft:overworld run fill 423 67 -47 423 144 -47 air
execute in minecraft:overworld run fill 423 58 -46 423 64 -46 stone
execute in minecraft:overworld run fill 423 65 -46 423 66 -46 dirt
execute in minecraft:overworld run setblock 423 67 -46 coarse_dirt
execute in minecraft:overworld run fill 423 68 -46 423 144 -46 air
execute in minecraft:overworld run fill 423 58 -45 423 66 -45 stone
execute in minecraft:overworld run fill 423 67 -45 423 68 -45 dirt
execute in minecraft:overworld run setblock 423 69 -45 coarse_dirt
execute in minecraft:overworld run fill 423 70 -45 423 144 -45 air
execute in minecraft:overworld run fill 423 58 -44 423 67 -44 stone
execute in minecraft:overworld run fill 423 68 -44 423 69 -44 dirt
execute in minecraft:overworld run setblock 423 70 -44 coarse_dirt
execute in minecraft:overworld run fill 423 71 -44 423 144 -44 air
execute in minecraft:overworld run fill 423 58 -43 423 69 -43 stone
execute in minecraft:overworld run fill 423 70 -43 423 71 -43 dirt
execute in minecraft:overworld run setblock 423 72 -43 coarse_dirt
execute in minecraft:overworld run fill 423 73 -43 423 144 -43 air
execute in minecraft:overworld run fill 423 58 -42 423 70 -42 stone
execute in minecraft:overworld run fill 423 71 -42 423 72 -42 dirt
execute in minecraft:overworld run setblock 423 73 -42 coarse_dirt
execute in minecraft:overworld run fill 423 74 -42 423 144 -42 air
execute in minecraft:overworld run fill 423 58 -41 423 72 -41 stone
execute in minecraft:overworld run fill 423 73 -41 423 74 -41 dirt
execute in minecraft:overworld run setblock 423 75 -41 grass_block
execute in minecraft:overworld run fill 423 76 -41 423 144 -41 air
execute in minecraft:overworld run fill 423 58 -40 423 73 -40 stone
execute in minecraft:overworld run fill 423 74 -40 423 75 -40 dirt
execute in minecraft:overworld run setblock 423 76 -40 grass_block
execute in minecraft:overworld run fill 423 77 -40 423 144 -40 air
execute in minecraft:overworld run fill 423 58 -39 423 74 -39 stone
execute in minecraft:overworld run fill 423 75 -39 423 76 -39 dirt
execute in minecraft:overworld run setblock 423 77 -39 grass_block
execute in minecraft:overworld run fill 423 78 -39 423 144 -39 air
execute in minecraft:overworld run fill 423 58 -38 423 74 -38 stone
execute in minecraft:overworld run fill 423 75 -38 423 76 -38 dirt
execute in minecraft:overworld run setblock 423 77 -38 grass_block
execute in minecraft:overworld run fill 423 78 -38 423 144 -38 air
execute in minecraft:overworld run fill 423 58 -37 423 74 -37 stone
execute in minecraft:overworld run fill 423 75 -37 423 76 -37 dirt
execute in minecraft:overworld run setblock 423 77 -37 grass_block
execute in minecraft:overworld run fill 423 78 -37 423 144 -37 air
execute in minecraft:overworld run fill 423 58 -36 423 74 -36 stone
execute in minecraft:overworld run fill 423 75 -36 423 76 -36 dirt
execute in minecraft:overworld run setblock 423 77 -36 coarse_dirt
execute in minecraft:overworld run fill 423 78 -36 423 144 -36 air
execute in minecraft:overworld run fill 423 58 -35 423 73 -35 stone
execute in minecraft:overworld run fill 423 74 -35 423 75 -35 dirt
execute in minecraft:overworld run setblock 423 76 -35 coarse_dirt
execute in minecraft:overworld run fill 423 77 -35 423 144 -35 air
execute in minecraft:overworld run fill 423 58 -34 423 73 -34 stone
execute in minecraft:overworld run fill 423 74 -34 423 75 -34 dirt
execute in minecraft:overworld run setblock 423 76 -34 grass_block
execute in minecraft:overworld run fill 423 77 -34 423 144 -34 air
execute in minecraft:overworld run fill 423 58 -33 423 72 -33 stone
execute in minecraft:overworld run fill 423 73 -33 423 74 -33 dirt
execute in minecraft:overworld run setblock 423 75 -33 grass_block
execute in minecraft:overworld run fill 423 76 -33 423 144 -33 air
execute in minecraft:overworld run fill 423 58 -32 423 72 -32 stone
execute in minecraft:overworld run fill 423 73 -32 423 74 -32 dirt
execute in minecraft:overworld run setblock 423 75 -32 coarse_dirt
execute in minecraft:overworld run fill 423 76 -32 423 144 -32 air
execute in minecraft:overworld run fill 423 58 -31 423 72 -31 stone
execute in minecraft:overworld run fill 423 73 -31 423 74 -31 dirt
execute in minecraft:overworld run setblock 423 75 -31 coarse_dirt
execute in minecraft:overworld run fill 423 76 -31 423 144 -31 air
execute in minecraft:overworld run fill 423 58 -30 423 71 -30 stone
execute in minecraft:overworld run fill 423 72 -30 423 73 -30 dirt
execute in minecraft:overworld run setblock 423 74 -30 grass_block
execute in minecraft:overworld run fill 423 75 -30 423 144 -30 air
execute in minecraft:overworld run fill 423 58 -29 423 71 -29 stone
execute in minecraft:overworld run fill 423 72 -29 423 73 -29 dirt
execute in minecraft:overworld run setblock 423 74 -29 coarse_dirt
execute in minecraft:overworld run fill 423 75 -29 423 144 -29 air
execute in minecraft:overworld run setblock 423 75 -29 mossy_cobblestone
execute in minecraft:overworld run fill 423 58 -28 423 71 -28 stone
execute in minecraft:overworld run fill 423 72 -28 423 73 -28 dirt
execute in minecraft:overworld run setblock 423 74 -28 coarse_dirt
execute in minecraft:overworld run fill 423 75 -28 423 144 -28 air
execute in minecraft:overworld run fill 423 58 -27 423 70 -27 stone
execute in minecraft:overworld run fill 423 71 -27 423 72 -27 dirt
execute in minecraft:overworld run setblock 423 73 -27 coarse_dirt
execute in minecraft:overworld run fill 423 74 -27 423 144 -27 air
execute in minecraft:overworld run setblock 423 74 -27 grass
execute in minecraft:overworld run fill 423 58 -26 423 70 -26 stone
execute in minecraft:overworld run fill 423 71 -26 423 72 -26 dirt
execute in minecraft:overworld run setblock 423 73 -26 coarse_dirt
execute in minecraft:overworld run fill 423 74 -26 423 144 -26 air
execute in minecraft:overworld run setblock 423 74 -26 grass
execute in minecraft:overworld run fill 423 58 -25 423 70 -25 stone
execute in minecraft:overworld run fill 423 71 -25 423 72 -25 dirt
execute in minecraft:overworld run setblock 423 73 -25 grass_block
execute in minecraft:overworld run fill 423 74 -25 423 144 -25 air
execute in minecraft:overworld run fill 423 58 -24 423 69 -24 stone
execute in minecraft:overworld run fill 423 70 -24 423 71 -24 dirt
execute in minecraft:overworld run setblock 423 72 -24 coarse_dirt
execute in minecraft:overworld run fill 423 73 -24 423 144 -24 air
execute in minecraft:overworld run fill 423 58 -23 423 69 -23 stone
execute in minecraft:overworld run fill 423 70 -23 423 71 -23 dirt
execute in minecraft:overworld run setblock 423 72 -23 grass_block
execute in minecraft:overworld run fill 423 73 -23 423 144 -23 air
execute in minecraft:overworld run fill 423 58 -22 423 69 -22 stone
execute in minecraft:overworld run fill 423 70 -22 423 71 -22 dirt
execute in minecraft:overworld run setblock 423 72 -22 grass_block
execute in minecraft:overworld run fill 423 73 -22 423 144 -22 air
execute in minecraft:overworld run fill 423 58 -21 423 69 -21 stone
execute in minecraft:overworld run fill 423 70 -21 423 71 -21 dirt
execute in minecraft:overworld run setblock 423 72 -21 grass_block
execute in minecraft:overworld run fill 423 73 -21 423 144 -21 air
execute in minecraft:overworld run fill 423 58 -20 423 68 -20 stone
execute in minecraft:overworld run fill 423 69 -20 423 70 -20 dirt
execute in minecraft:overworld run setblock 423 71 -20 grass_block
execute in minecraft:overworld run fill 423 72 -20 423 144 -20 air
execute in minecraft:overworld run fill 423 58 -19 423 68 -19 stone
execute in minecraft:overworld run fill 423 69 -19 423 70 -19 dirt
execute in minecraft:overworld run setblock 423 71 -19 coarse_dirt
execute in minecraft:overworld run fill 423 72 -19 423 144 -19 air
execute in minecraft:overworld run fill 423 58 -18 423 68 -18 stone
schedule function blade_gallery:random/battlefield/part_137 1t replace
