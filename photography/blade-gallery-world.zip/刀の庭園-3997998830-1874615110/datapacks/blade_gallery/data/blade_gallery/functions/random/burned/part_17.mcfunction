execute in minecraft:overworld run fill 219 68 -31 219 69 -31 dirt
execute in minecraft:overworld run setblock 219 70 -31 coarse_dirt
execute in minecraft:overworld run fill 219 71 -31 219 144 -31 air
execute in minecraft:overworld run fill 219 58 -30 219 67 -30 stone
execute in minecraft:overworld run fill 219 68 -30 219 69 -30 dirt
execute in minecraft:overworld run setblock 219 70 -30 coarse_dirt
execute in minecraft:overworld run fill 219 71 -30 219 144 -30 air
execute in minecraft:overworld run fill 219 58 -29 219 66 -29 stone
execute in minecraft:overworld run fill 219 67 -29 219 68 -29 dirt
execute in minecraft:overworld run setblock 219 69 -29 coarse_dirt
execute in minecraft:overworld run fill 219 70 -29 219 144 -29 air
execute in minecraft:overworld run fill 219 58 -28 219 66 -28 stone
execute in minecraft:overworld run fill 219 67 -28 219 68 -28 dirt
execute in minecraft:overworld run setblock 219 69 -28 coarse_dirt
execute in minecraft:overworld run fill 219 70 -28 219 144 -28 air
execute in minecraft:overworld run fill 219 58 -27 219 65 -27 stone
execute in minecraft:overworld run fill 219 66 -27 219 67 -27 dirt
execute in minecraft:overworld run setblock 219 68 -27 coarse_dirt
execute in minecraft:overworld run fill 219 69 -27 219 144 -27 air
execute in minecraft:overworld run fill 219 58 -26 219 65 -26 stone
execute in minecraft:overworld run fill 219 66 -26 219 67 -26 dirt
execute in minecraft:overworld run setblock 219 68 -26 grass_block
execute in minecraft:overworld run fill 219 69 -26 219 144 -26 air
execute in minecraft:overworld run fill 219 58 -25 219 65 -25 stone
execute in minecraft:overworld run fill 219 66 -25 219 67 -25 dirt
execute in minecraft:overworld run setblock 219 68 -25 coarse_dirt
execute in minecraft:overworld run fill 219 69 -25 219 144 -25 air
execute in minecraft:overworld run fill 219 58 -24 219 65 -24 stone
execute in minecraft:overworld run fill 219 66 -24 219 67 -24 dirt
execute in minecraft:overworld run setblock 219 68 -24 grass_block
execute in minecraft:overworld run fill 219 69 -24 219 144 -24 air
execute in minecraft:overworld run fill 219 58 -23 219 65 -23 stone
execute in minecraft:overworld run fill 219 66 -23 219 67 -23 dirt
execute in minecraft:overworld run setblock 219 68 -23 coarse_dirt
execute in minecraft:overworld run fill 219 69 -23 219 144 -23 air
execute in minecraft:overworld run fill 219 58 -22 219 66 -22 stone
execute in minecraft:overworld run fill 219 67 -22 219 68 -22 dirt
execute in minecraft:overworld run setblock 219 69 -22 coarse_dirt
execute in minecraft:overworld run fill 219 70 -22 219 144 -22 air
execute in minecraft:overworld run fill 219 58 -21 219 66 -21 stone
execute in minecraft:overworld run fill 219 67 -21 219 68 -21 dirt
execute in minecraft:overworld run setblock 219 69 -21 coarse_dirt
execute in minecraft:overworld run fill 219 70 -21 219 144 -21 air
execute in minecraft:overworld run fill 219 58 -20 219 66 -20 stone
execute in minecraft:overworld run fill 219 67 -20 219 68 -20 dirt
execute in minecraft:overworld run setblock 219 69 -20 coarse_dirt
execute in minecraft:overworld run fill 219 70 -20 219 144 -20 air
execute in minecraft:overworld run fill 219 58 -19 219 66 -19 stone
execute in minecraft:overworld run fill 219 67 -19 219 68 -19 dirt
execute in minecraft:overworld run setblock 219 69 -19 coarse_dirt
execute in minecraft:overworld run fill 219 70 -19 219 144 -19 air
execute in minecraft:overworld run fill 219 58 -18 219 66 -18 stone
execute in minecraft:overworld run fill 219 67 -18 219 68 -18 dirt
execute in minecraft:overworld run setblock 219 69 -18 coarse_dirt
execute in minecraft:overworld run fill 219 70 -18 219 144 -18 air
execute in minecraft:overworld run fill 219 58 -17 219 66 -17 stone
execute in minecraft:overworld run fill 219 67 -17 219 68 -17 dirt
execute in minecraft:overworld run setblock 219 69 -17 coarse_dirt
execute in minecraft:overworld run fill 219 70 -17 219 144 -17 air
execute in minecraft:overworld run fill 219 58 -16 219 66 -16 stone
execute in minecraft:overworld run fill 219 67 -16 219 68 -16 dirt
execute in minecraft:overworld run setblock 219 69 -16 grass_block
execute in minecraft:overworld run fill 219 70 -16 219 144 -16 air
execute in minecraft:overworld run fill 219 58 -15 219 66 -15 stone
execute in minecraft:overworld run fill 219 67 -15 219 68 -15 dirt
execute in minecraft:overworld run setblock 219 69 -15 grass_block
execute in minecraft:overworld run fill 219 70 -15 219 144 -15 air
execute in minecraft:overworld run fill 219 58 -14 219 66 -14 stone
execute in minecraft:overworld run fill 219 67 -14 219 68 -14 dirt
execute in minecraft:overworld run setblock 219 69 -14 grass_block
execute in minecraft:overworld run fill 219 70 -14 219 144 -14 air
execute in minecraft:overworld run fill 219 58 -13 219 65 -13 stone
execute in minecraft:overworld run fill 219 66 -13 219 67 -13 dirt
execute in minecraft:overworld run setblock 219 68 -13 coarse_dirt
execute in minecraft:overworld run fill 219 69 -13 219 144 -13 air
execute in minecraft:overworld run fill 219 58 -12 219 65 -12 stone
execute in minecraft:overworld run fill 219 66 -12 219 67 -12 dirt
execute in minecraft:overworld run setblock 219 68 -12 grass_block
execute in minecraft:overworld run fill 219 69 -12 219 144 -12 air
execute in minecraft:overworld run setblock 219 69 -12 grass
execute in minecraft:overworld run fill 219 58 -11 219 65 -11 stone
execute in minecraft:overworld run fill 219 66 -11 219 67 -11 dirt
execute in minecraft:overworld run setblock 219 68 -11 coarse_dirt
execute in minecraft:overworld run fill 219 69 -11 219 144 -11 air
execute in minecraft:overworld run fill 219 58 -10 219 66 -10 stone
execute in minecraft:overworld run fill 219 67 -10 219 68 -10 dirt
execute in minecraft:overworld run setblock 219 69 -10 coarse_dirt
execute in minecraft:overworld run fill 219 70 -10 219 144 -10 air
execute in minecraft:overworld run fill 219 58 -9 219 66 -9 stone
execute in minecraft:overworld run fill 219 67 -9 219 68 -9 dirt
execute in minecraft:overworld run setblock 219 69 -9 coarse_dirt
execute in minecraft:overworld run fill 219 70 -9 219 144 -9 air
execute in minecraft:overworld run fill 219 58 -8 219 66 -8 stone
execute in minecraft:overworld run fill 219 67 -8 219 68 -8 dirt
execute in minecraft:overworld run setblock 219 69 -8 coarse_dirt
execute in minecraft:overworld run fill 219 70 -8 219 144 -8 air
execute in minecraft:overworld run fill 219 58 -7 219 66 -7 stone
execute in minecraft:overworld run fill 219 67 -7 219 68 -7 dirt
execute in minecraft:overworld run setblock 219 69 -7 grass_block
execute in minecraft:overworld run fill 219 70 -7 219 144 -7 air
execute in minecraft:overworld run fill 219 58 -6 219 67 -6 stone
execute in minecraft:overworld run fill 219 68 -6 219 69 -6 dirt
execute in minecraft:overworld run setblock 219 70 -6 coarse_dirt
execute in minecraft:overworld run fill 219 71 -6 219 144 -6 air
execute in minecraft:overworld run fill 219 58 -5 219 67 -5 stone
execute in minecraft:overworld run fill 219 68 -5 219 69 -5 dirt
execute in minecraft:overworld run setblock 219 70 -5 coarse_dirt
execute in minecraft:overworld run fill 219 71 -5 219 144 -5 air
execute in minecraft:overworld run setblock 219 71 -5 grass
execute in minecraft:overworld run fill 219 58 -4 219 67 -4 stone
execute in minecraft:overworld run fill 219 68 -4 219 69 -4 dirt
execute in minecraft:overworld run setblock 219 70 -4 grass_block
execute in minecraft:overworld run fill 219 71 -4 219 144 -4 air
execute in minecraft:overworld run fill 219 58 -3 219 67 -3 stone
execute in minecraft:overworld run fill 219 68 -3 219 69 -3 dirt
execute in minecraft:overworld run setblock 219 70 -3 coarse_dirt
execute in minecraft:overworld run fill 219 71 -3 219 144 -3 air
execute in minecraft:overworld run fill 219 58 -2 219 67 -2 stone
execute in minecraft:overworld run fill 219 68 -2 219 69 -2 dirt
execute in minecraft:overworld run setblock 219 70 -2 grass_block
execute in minecraft:overworld run fill 219 71 -2 219 144 -2 air
execute in minecraft:overworld run fill 219 58 -1 219 67 -1 stone
execute in minecraft:overworld run fill 219 68 -1 219 69 -1 dirt
execute in minecraft:overworld run setblock 219 70 -1 coarse_dirt
execute in minecraft:overworld run fill 219 71 -1 219 144 -1 air
execute in minecraft:overworld run fill 219 58 0 219 67 0 stone
execute in minecraft:overworld run fill 219 68 0 219 69 0 dirt
execute in minecraft:overworld run setblock 219 70 0 grass_block
execute in minecraft:overworld run fill 219 71 0 219 144 0 air
execute in minecraft:overworld run setblock 219 71 0 grass
execute in minecraft:overworld run fill 219 58 1 219 67 1 stone
execute in minecraft:overworld run fill 219 68 1 219 69 1 dirt
execute in minecraft:overworld run setblock 219 70 1 coarse_dirt
execute in minecraft:overworld run fill 219 71 1 219 144 1 air
execute in minecraft:overworld run fill 219 58 2 219 67 2 stone
execute in minecraft:overworld run fill 219 68 2 219 69 2 dirt
execute in minecraft:overworld run setblock 219 70 2 grass_block
execute in minecraft:overworld run fill 219 71 2 219 144 2 air
execute in minecraft:overworld run fill 219 58 3 219 67 3 stone
execute in minecraft:overworld run fill 219 68 3 219 69 3 dirt
execute in minecraft:overworld run setblock 219 70 3 grass_block
execute in minecraft:overworld run fill 219 71 3 219 144 3 air
execute in minecraft:overworld run fill 219 58 4 219 67 4 stone
execute in minecraft:overworld run fill 219 68 4 219 69 4 dirt
execute in minecraft:overworld run setblock 219 70 4 coarse_dirt
execute in minecraft:overworld run fill 219 71 4 219 144 4 air
execute in minecraft:overworld run fill 219 58 5 219 67 5 stone
execute in minecraft:overworld run fill 219 68 5 219 69 5 dirt
execute in minecraft:overworld run setblock 219 70 5 grass_block
execute in minecraft:overworld run fill 219 71 5 219 144 5 air
execute in minecraft:overworld run fill 219 58 6 219 67 6 stone
execute in minecraft:overworld run fill 219 68 6 219 69 6 dirt
execute in minecraft:overworld run setblock 219 70 6 grass_block
execute in minecraft:overworld run fill 219 71 6 219 144 6 air
execute in minecraft:overworld run fill 219 58 7 219 67 7 stone
execute in minecraft:overworld run fill 219 68 7 219 69 7 dirt
execute in minecraft:overworld run setblock 219 70 7 coarse_dirt
execute in minecraft:overworld run fill 219 71 7 219 144 7 air
execute in minecraft:overworld run fill 219 58 8 219 67 8 stone
execute in minecraft:overworld run fill 219 68 8 219 69 8 dirt
execute in minecraft:overworld run setblock 219 70 8 grass_block
execute in minecraft:overworld run fill 219 71 8 219 144 8 air
execute in minecraft:overworld run fill 219 58 9 219 67 9 stone
execute in minecraft:overworld run fill 219 68 9 219 69 9 dirt
execute in minecraft:overworld run setblock 219 70 9 coarse_dirt
execute in minecraft:overworld run fill 219 71 9 219 144 9 air
execute in minecraft:overworld run fill 219 58 10 219 67 10 stone
execute in minecraft:overworld run fill 219 68 10 219 69 10 dirt
execute in minecraft:overworld run setblock 219 70 10 grass_block
execute in minecraft:overworld run fill 219 71 10 219 144 10 air
execute in minecraft:overworld run fill 219 58 11 219 67 11 stone
execute in minecraft:overworld run fill 219 68 11 219 69 11 dirt
execute in minecraft:overworld run setblock 219 70 11 grass_block
execute in minecraft:overworld run fill 219 71 11 219 144 11 air
execute in minecraft:overworld run fill 219 58 12 219 68 12 stone
execute in minecraft:overworld run fill 219 69 12 219 70 12 dirt
execute in minecraft:overworld run setblock 219 71 12 coarse_dirt
execute in minecraft:overworld run fill 219 72 12 219 144 12 air
execute in minecraft:overworld run fill 219 58 13 219 68 13 stone
execute in minecraft:overworld run fill 219 69 13 219 70 13 dirt
execute in minecraft:overworld run setblock 219 71 13 grass_block
execute in minecraft:overworld run fill 219 72 13 219 144 13 air
execute in minecraft:overworld run fill 219 58 14 219 69 14 stone
execute in minecraft:overworld run fill 219 70 14 219 71 14 dirt
execute in minecraft:overworld run setblock 219 72 14 coarse_dirt
execute in minecraft:overworld run fill 219 73 14 219 144 14 air
execute in minecraft:overworld run fill 219 58 15 219 69 15 stone
execute in minecraft:overworld run fill 219 70 15 219 71 15 dirt
execute in minecraft:overworld run setblock 219 72 15 coarse_dirt
execute in minecraft:overworld run fill 219 73 15 219 144 15 air
execute in minecraft:overworld run fill 219 58 16 219 69 16 stone
execute in minecraft:overworld run fill 219 70 16 219 71 16 dirt
execute in minecraft:overworld run setblock 219 72 16 coarse_dirt
execute in minecraft:overworld run fill 219 73 16 219 144 16 air
execute in minecraft:overworld run fill 219 58 17 219 70 17 stone
execute in minecraft:overworld run fill 219 71 17 219 72 17 dirt
execute in minecraft:overworld run setblock 219 73 17 coarse_dirt
execute in minecraft:overworld run fill 219 74 17 219 144 17 air
execute in minecraft:overworld run fill 219 58 18 219 70 18 stone
execute in minecraft:overworld run fill 219 71 18 219 72 18 dirt
execute in minecraft:overworld run setblock 219 73 18 grass_block
execute in minecraft:overworld run fill 219 74 18 219 144 18 air
execute in minecraft:overworld run fill 219 58 19 219 70 19 stone
execute in minecraft:overworld run fill 219 71 19 219 72 19 dirt
execute in minecraft:overworld run setblock 219 73 19 grass_block
execute in minecraft:overworld run fill 219 74 19 219 144 19 air
execute in minecraft:overworld run fill 219 58 20 219 70 20 stone
execute in minecraft:overworld run fill 219 71 20 219 72 20 dirt
execute in minecraft:overworld run setblock 219 73 20 coarse_dirt
execute in minecraft:overworld run fill 219 74 20 219 144 20 air
execute in minecraft:overworld run fill 219 58 21 219 70 21 stone
execute in minecraft:overworld run fill 219 71 21 219 72 21 dirt
execute in minecraft:overworld run setblock 219 73 21 grass_block
execute in minecraft:overworld run fill 219 74 21 219 144 21 air
execute in minecraft:overworld run fill 219 58 22 219 71 22 stone
execute in minecraft:overworld run fill 219 72 22 219 73 22 dirt
execute in minecraft:overworld run setblock 219 74 22 coarse_dirt
execute in minecraft:overworld run fill 219 75 22 219 144 22 air
execute in minecraft:overworld run fill 219 58 23 219 71 23 stone
execute in minecraft:overworld run fill 219 72 23 219 73 23 dirt
execute in minecraft:overworld run setblock 219 74 23 grass_block
execute in minecraft:overworld run fill 219 75 23 219 144 23 air
execute in minecraft:overworld run fill 219 58 24 219 71 24 stone
execute in minecraft:overworld run fill 219 72 24 219 73 24 dirt
execute in minecraft:overworld run setblock 219 74 24 coarse_dirt
execute in minecraft:overworld run fill 219 75 24 219 144 24 air
execute in minecraft:overworld run fill 219 58 25 219 71 25 stone
execute in minecraft:overworld run fill 219 72 25 219 73 25 dirt
execute in minecraft:overworld run setblock 219 74 25 grass_block
execute in minecraft:overworld run fill 219 75 25 219 144 25 air
execute in minecraft:overworld run setblock 219 75 25 grass
execute in minecraft:overworld run fill 219 58 26 219 71 26 stone
execute in minecraft:overworld run fill 219 72 26 219 73 26 dirt
execute in minecraft:overworld run setblock 219 74 26 coarse_dirt
execute in minecraft:overworld run fill 219 75 26 219 144 26 air
execute in minecraft:overworld run fill 219 58 27 219 71 27 stone
execute in minecraft:overworld run fill 219 72 27 219 73 27 dirt
execute in minecraft:overworld run setblock 219 74 27 coarse_dirt
execute in minecraft:overworld run fill 219 75 27 219 144 27 air
execute in minecraft:overworld run fill 219 58 28 219 71 28 stone
execute in minecraft:overworld run fill 219 72 28 219 73 28 dirt
execute in minecraft:overworld run setblock 219 74 28 coarse_dirt
execute in minecraft:overworld run fill 219 75 28 219 144 28 air
execute in minecraft:overworld run fill 219 58 29 219 71 29 stone
execute in minecraft:overworld run fill 219 72 29 219 73 29 dirt
execute in minecraft:overworld run setblock 219 74 29 coarse_dirt
execute in minecraft:overworld run fill 219 75 29 219 144 29 air
execute in minecraft:overworld run fill 219 58 30 219 71 30 stone
execute in minecraft:overworld run fill 219 72 30 219 73 30 dirt
execute in minecraft:overworld run setblock 219 74 30 coarse_dirt
execute in minecraft:overworld run fill 219 75 30 219 144 30 air
execute in minecraft:overworld run fill 219 58 31 219 71 31 stone
execute in minecraft:overworld run fill 219 72 31 219 73 31 dirt
execute in minecraft:overworld run setblock 219 74 31 coarse_dirt
execute in minecraft:overworld run fill 219 75 31 219 144 31 air
execute in minecraft:overworld run fill 219 58 32 219 70 32 stone
schedule function blade_gallery:random/burned/part_18 1t replace
