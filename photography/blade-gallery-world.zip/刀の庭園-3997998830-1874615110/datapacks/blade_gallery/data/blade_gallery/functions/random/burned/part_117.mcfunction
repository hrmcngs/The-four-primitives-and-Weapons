execute in minecraft:overworld run fill 281 62 36 281 63 36 dirt
execute in minecraft:overworld run setblock 281 64 36 grass_block
execute in minecraft:overworld run fill 281 65 36 281 144 36 air
execute in minecraft:overworld run fill 281 58 37 281 61 37 stone
execute in minecraft:overworld run fill 281 62 37 281 63 37 dirt
execute in minecraft:overworld run setblock 281 64 37 coarse_dirt
execute in minecraft:overworld run fill 281 65 37 281 144 37 air
execute in minecraft:overworld run fill 281 58 38 281 61 38 stone
execute in minecraft:overworld run fill 281 62 38 281 63 38 dirt
execute in minecraft:overworld run setblock 281 64 38 coarse_dirt
execute in minecraft:overworld run fill 281 65 38 281 144 38 air
execute in minecraft:overworld run fill 281 58 39 281 61 39 stone
execute in minecraft:overworld run fill 281 62 39 281 63 39 dirt
execute in minecraft:overworld run setblock 281 64 39 coarse_dirt
execute in minecraft:overworld run fill 281 65 39 281 144 39 air
execute in minecraft:overworld run fill 281 58 40 281 61 40 stone
execute in minecraft:overworld run fill 281 62 40 281 63 40 dirt
execute in minecraft:overworld run setblock 281 64 40 grass_block
execute in minecraft:overworld run fill 281 65 40 281 144 40 air
execute in minecraft:overworld run fill 281 58 41 281 61 41 stone
execute in minecraft:overworld run fill 281 62 41 281 63 41 dirt
execute in minecraft:overworld run setblock 281 64 41 grass_block
execute in minecraft:overworld run fill 281 65 41 281 144 41 air
execute in minecraft:overworld run fill 281 58 42 281 61 42 stone
execute in minecraft:overworld run fill 281 62 42 281 63 42 dirt
execute in minecraft:overworld run setblock 281 64 42 grass_block
execute in minecraft:overworld run fill 281 65 42 281 144 42 air
execute in minecraft:overworld run fill 281 58 43 281 61 43 stone
execute in minecraft:overworld run fill 281 62 43 281 63 43 dirt
execute in minecraft:overworld run setblock 281 64 43 coarse_dirt
execute in minecraft:overworld run fill 281 65 43 281 144 43 air
execute in minecraft:overworld run fill 281 58 44 281 61 44 stone
execute in minecraft:overworld run fill 281 62 44 281 63 44 dirt
execute in minecraft:overworld run setblock 281 64 44 coarse_dirt
execute in minecraft:overworld run fill 281 65 44 281 144 44 air
execute in minecraft:overworld run fill 281 58 45 281 61 45 stone
execute in minecraft:overworld run fill 281 62 45 281 63 45 dirt
execute in minecraft:overworld run setblock 281 64 45 coarse_dirt
execute in minecraft:overworld run fill 281 65 45 281 144 45 air
execute in minecraft:overworld run fill 281 58 46 281 61 46 stone
execute in minecraft:overworld run fill 281 62 46 281 63 46 dirt
execute in minecraft:overworld run setblock 281 64 46 grass_block
execute in minecraft:overworld run fill 281 65 46 281 144 46 air
execute in minecraft:overworld run fill 281 58 47 281 61 47 stone
execute in minecraft:overworld run fill 281 62 47 281 63 47 dirt
execute in minecraft:overworld run setblock 281 64 47 grass_block
execute in minecraft:overworld run fill 281 65 47 281 144 47 air
execute in minecraft:overworld run fill 282 58 -48 282 61 -48 stone
execute in minecraft:overworld run fill 282 62 -48 282 63 -48 dirt
execute in minecraft:overworld run setblock 282 64 -48 coarse_dirt
execute in minecraft:overworld run fill 282 65 -48 282 144 -48 air
execute in minecraft:overworld run fill 282 58 -47 282 63 -47 stone
execute in minecraft:overworld run fill 282 64 -47 282 65 -47 dirt
execute in minecraft:overworld run setblock 282 66 -47 grass_block
execute in minecraft:overworld run fill 282 67 -47 282 144 -47 air
execute in minecraft:overworld run fill 282 58 -46 282 65 -46 stone
execute in minecraft:overworld run fill 282 66 -46 282 67 -46 dirt
execute in minecraft:overworld run setblock 282 68 -46 grass_block
execute in minecraft:overworld run fill 282 69 -46 282 144 -46 air
execute in minecraft:overworld run fill 282 58 -45 282 68 -45 stone
execute in minecraft:overworld run fill 282 69 -45 282 70 -45 dirt
execute in minecraft:overworld run setblock 282 71 -45 coarse_dirt
execute in minecraft:overworld run fill 282 72 -45 282 144 -45 air
execute in minecraft:overworld run fill 282 58 -44 282 70 -44 stone
execute in minecraft:overworld run fill 282 71 -44 282 72 -44 dirt
execute in minecraft:overworld run setblock 282 73 -44 grass_block
execute in minecraft:overworld run fill 282 74 -44 282 144 -44 air
execute in minecraft:overworld run fill 282 58 -43 282 71 -43 stone
execute in minecraft:overworld run fill 282 72 -43 282 73 -43 dirt
execute in minecraft:overworld run setblock 282 74 -43 coarse_dirt
execute in minecraft:overworld run fill 282 75 -43 282 144 -43 air
execute in minecraft:overworld run fill 282 58 -42 282 73 -42 stone
execute in minecraft:overworld run fill 282 74 -42 282 75 -42 dirt
execute in minecraft:overworld run setblock 282 76 -42 grass_block
execute in minecraft:overworld run fill 282 77 -42 282 144 -42 air
execute in minecraft:overworld run fill 282 58 -41 282 75 -41 stone
execute in minecraft:overworld run fill 282 76 -41 282 77 -41 dirt
execute in minecraft:overworld run setblock 282 78 -41 grass_block
execute in minecraft:overworld run fill 282 79 -41 282 144 -41 air
execute in minecraft:overworld run setblock 282 79 -41 grass
execute in minecraft:overworld run fill 282 58 -40 282 76 -40 stone
execute in minecraft:overworld run fill 282 77 -40 282 78 -40 dirt
execute in minecraft:overworld run setblock 282 79 -40 coarse_dirt
execute in minecraft:overworld run fill 282 80 -40 282 144 -40 air
execute in minecraft:overworld run fill 282 58 -39 282 78 -39 stone
execute in minecraft:overworld run fill 282 79 -39 282 80 -39 dirt
execute in minecraft:overworld run setblock 282 81 -39 coarse_dirt
execute in minecraft:overworld run fill 282 82 -39 282 144 -39 air
execute in minecraft:overworld run fill 282 58 -38 282 79 -38 stone
execute in minecraft:overworld run fill 282 80 -38 282 81 -38 dirt
execute in minecraft:overworld run setblock 282 82 -38 grass_block
execute in minecraft:overworld run fill 282 83 -38 282 144 -38 air
execute in minecraft:overworld run fill 282 58 -37 282 79 -37 stone
execute in minecraft:overworld run fill 282 80 -37 282 81 -37 dirt
execute in minecraft:overworld run setblock 282 82 -37 coarse_dirt
execute in minecraft:overworld run fill 282 83 -37 282 144 -37 air
execute in minecraft:overworld run fill 282 58 -36 282 78 -36 stone
execute in minecraft:overworld run fill 282 79 -36 282 80 -36 dirt
execute in minecraft:overworld run setblock 282 81 -36 coarse_dirt
execute in minecraft:overworld run fill 282 82 -36 282 144 -36 air
execute in minecraft:overworld run fill 282 58 -35 282 78 -35 stone
execute in minecraft:overworld run fill 282 79 -35 282 80 -35 dirt
execute in minecraft:overworld run setblock 282 81 -35 coarse_dirt
execute in minecraft:overworld run fill 282 82 -35 282 144 -35 air
execute in minecraft:overworld run fill 282 58 -34 282 78 -34 stone
execute in minecraft:overworld run fill 282 79 -34 282 80 -34 dirt
execute in minecraft:overworld run setblock 282 81 -34 coarse_dirt
execute in minecraft:overworld run fill 282 82 -34 282 144 -34 air
execute in minecraft:overworld run fill 282 58 -33 282 77 -33 stone
execute in minecraft:overworld run fill 282 78 -33 282 79 -33 dirt
execute in minecraft:overworld run setblock 282 80 -33 grass_block
execute in minecraft:overworld run fill 282 81 -33 282 144 -33 air
execute in minecraft:overworld run setblock 282 81 -33 grass
execute in minecraft:overworld run fill 282 58 -32 282 77 -32 stone
execute in minecraft:overworld run fill 282 78 -32 282 79 -32 dirt
execute in minecraft:overworld run setblock 282 80 -32 coarse_dirt
execute in minecraft:overworld run fill 282 81 -32 282 144 -32 air
execute in minecraft:overworld run fill 282 58 -31 282 76 -31 stone
execute in minecraft:overworld run fill 282 77 -31 282 78 -31 dirt
execute in minecraft:overworld run setblock 282 79 -31 coarse_dirt
execute in minecraft:overworld run fill 282 80 -31 282 144 -31 air
execute in minecraft:overworld run fill 282 58 -30 282 76 -30 stone
execute in minecraft:overworld run fill 282 77 -30 282 78 -30 dirt
execute in minecraft:overworld run setblock 282 79 -30 grass_block
execute in minecraft:overworld run fill 282 80 -30 282 144 -30 air
execute in minecraft:overworld run fill 282 58 -29 282 76 -29 stone
execute in minecraft:overworld run fill 282 77 -29 282 78 -29 dirt
execute in minecraft:overworld run setblock 282 79 -29 coarse_dirt
execute in minecraft:overworld run fill 282 80 -29 282 144 -29 air
execute in minecraft:overworld run setblock 282 80 -29 grass
execute in minecraft:overworld run fill 282 58 -28 282 75 -28 stone
execute in minecraft:overworld run fill 282 76 -28 282 77 -28 dirt
execute in minecraft:overworld run setblock 282 78 -28 grass_block
execute in minecraft:overworld run fill 282 79 -28 282 144 -28 air
execute in minecraft:overworld run fill 282 58 -27 282 75 -27 stone
execute in minecraft:overworld run fill 282 76 -27 282 77 -27 dirt
execute in minecraft:overworld run setblock 282 78 -27 coarse_dirt
execute in minecraft:overworld run fill 282 79 -27 282 144 -27 air
execute in minecraft:overworld run fill 282 58 -26 282 75 -26 stone
execute in minecraft:overworld run fill 282 76 -26 282 77 -26 dirt
execute in minecraft:overworld run setblock 282 78 -26 coarse_dirt
execute in minecraft:overworld run fill 282 79 -26 282 144 -26 air
execute in minecraft:overworld run fill 282 58 -25 282 74 -25 stone
execute in minecraft:overworld run fill 282 75 -25 282 76 -25 dirt
execute in minecraft:overworld run setblock 282 77 -25 coarse_dirt
execute in minecraft:overworld run fill 282 78 -25 282 144 -25 air
execute in minecraft:overworld run setblock 282 78 -25 grass
execute in minecraft:overworld run fill 282 58 -24 282 74 -24 stone
execute in minecraft:overworld run fill 282 75 -24 282 76 -24 dirt
execute in minecraft:overworld run setblock 282 77 -24 coarse_dirt
execute in minecraft:overworld run fill 282 78 -24 282 144 -24 air
execute in minecraft:overworld run fill 282 58 -23 282 74 -23 stone
execute in minecraft:overworld run fill 282 75 -23 282 76 -23 dirt
execute in minecraft:overworld run setblock 282 77 -23 grass_block
execute in minecraft:overworld run fill 282 78 -23 282 144 -23 air
execute in minecraft:overworld run fill 282 58 -22 282 73 -22 stone
execute in minecraft:overworld run fill 282 74 -22 282 75 -22 dirt
execute in minecraft:overworld run setblock 282 76 -22 grass_block
execute in minecraft:overworld run fill 282 77 -22 282 144 -22 air
execute in minecraft:overworld run setblock 282 77 -22 grass
execute in minecraft:overworld run fill 282 58 -21 282 73 -21 stone
execute in minecraft:overworld run fill 282 74 -21 282 75 -21 dirt
execute in minecraft:overworld run setblock 282 76 -21 coarse_dirt
execute in minecraft:overworld run fill 282 77 -21 282 144 -21 air
execute in minecraft:overworld run fill 282 58 -20 282 73 -20 stone
execute in minecraft:overworld run fill 282 74 -20 282 75 -20 dirt
execute in minecraft:overworld run setblock 282 76 -20 grass_block
execute in minecraft:overworld run fill 282 77 -20 282 144 -20 air
execute in minecraft:overworld run fill 282 58 -19 282 72 -19 stone
execute in minecraft:overworld run fill 282 73 -19 282 74 -19 dirt
execute in minecraft:overworld run setblock 282 75 -19 coarse_dirt
execute in minecraft:overworld run fill 282 76 -19 282 144 -19 air
execute in minecraft:overworld run fill 282 58 -18 282 72 -18 stone
execute in minecraft:overworld run fill 282 73 -18 282 74 -18 dirt
execute in minecraft:overworld run setblock 282 75 -18 coarse_dirt
execute in minecraft:overworld run fill 282 76 -18 282 144 -18 air
execute in minecraft:overworld run fill 282 58 -17 282 72 -17 stone
execute in minecraft:overworld run fill 282 73 -17 282 74 -17 dirt
execute in minecraft:overworld run setblock 282 75 -17 grass_block
execute in minecraft:overworld run fill 282 76 -17 282 144 -17 air
execute in minecraft:overworld run fill 282 58 -16 282 71 -16 stone
execute in minecraft:overworld run fill 282 72 -16 282 73 -16 dirt
execute in minecraft:overworld run setblock 282 74 -16 grass_block
execute in minecraft:overworld run fill 282 75 -16 282 144 -16 air
execute in minecraft:overworld run fill 282 58 -15 282 71 -15 stone
execute in minecraft:overworld run fill 282 72 -15 282 73 -15 dirt
execute in minecraft:overworld run setblock 282 74 -15 grass_block
execute in minecraft:overworld run fill 282 75 -15 282 144 -15 air
execute in minecraft:overworld run fill 282 58 -14 282 70 -14 stone
execute in minecraft:overworld run fill 282 71 -14 282 72 -14 dirt
execute in minecraft:overworld run setblock 282 73 -14 coarse_dirt
execute in minecraft:overworld run fill 282 74 -14 282 144 -14 air
execute in minecraft:overworld run fill 282 58 -13 282 69 -13 stone
execute in minecraft:overworld run fill 282 70 -13 282 71 -13 dirt
execute in minecraft:overworld run setblock 282 72 -13 coarse_dirt
execute in minecraft:overworld run fill 282 73 -13 282 144 -13 air
execute in minecraft:overworld run fill 282 58 -12 282 69 -12 stone
execute in minecraft:overworld run fill 282 70 -12 282 71 -12 dirt
execute in minecraft:overworld run setblock 282 72 -12 coarse_dirt
execute in minecraft:overworld run fill 282 73 -12 282 144 -12 air
execute in minecraft:overworld run fill 282 58 -11 282 69 -11 stone
execute in minecraft:overworld run fill 282 70 -11 282 71 -11 dirt
execute in minecraft:overworld run setblock 282 72 -11 coarse_dirt
execute in minecraft:overworld run fill 282 73 -11 282 144 -11 air
execute in minecraft:overworld run fill 282 58 -10 282 68 -10 stone
execute in minecraft:overworld run fill 282 69 -10 282 70 -10 dirt
execute in minecraft:overworld run setblock 282 71 -10 grass_block
execute in minecraft:overworld run fill 282 72 -10 282 144 -10 air
execute in minecraft:overworld run setblock 282 72 -10 grass
execute in minecraft:overworld run fill 282 58 -9 282 68 -9 stone
execute in minecraft:overworld run fill 282 69 -9 282 70 -9 dirt
execute in minecraft:overworld run setblock 282 71 -9 coarse_dirt
execute in minecraft:overworld run fill 282 72 -9 282 144 -9 air
execute in minecraft:overworld run fill 282 58 -8 282 68 -8 stone
execute in minecraft:overworld run fill 282 69 -8 282 70 -8 dirt
execute in minecraft:overworld run setblock 282 71 -8 grass_block
execute in minecraft:overworld run fill 282 72 -8 282 144 -8 air
execute in minecraft:overworld run fill 282 58 -7 282 68 -7 stone
execute in minecraft:overworld run fill 282 69 -7 282 70 -7 dirt
execute in minecraft:overworld run setblock 282 71 -7 grass_block
execute in minecraft:overworld run fill 282 72 -7 282 144 -7 air
execute in minecraft:overworld run setblock 282 72 -7 grass
execute in minecraft:overworld run fill 282 58 -6 282 68 -6 stone
execute in minecraft:overworld run fill 282 69 -6 282 70 -6 dirt
execute in minecraft:overworld run setblock 282 71 -6 coarse_dirt
execute in minecraft:overworld run fill 282 72 -6 282 144 -6 air
execute in minecraft:overworld run fill 282 58 -5 282 68 -5 stone
execute in minecraft:overworld run fill 282 69 -5 282 70 -5 dirt
execute in minecraft:overworld run setblock 282 71 -5 coarse_dirt
execute in minecraft:overworld run fill 282 72 -5 282 144 -5 air
execute in minecraft:overworld run fill 282 58 -4 282 68 -4 stone
execute in minecraft:overworld run fill 282 69 -4 282 70 -4 dirt
execute in minecraft:overworld run setblock 282 71 -4 coarse_dirt
execute in minecraft:overworld run fill 282 72 -4 282 144 -4 air
execute in minecraft:overworld run fill 282 58 -3 282 68 -3 stone
execute in minecraft:overworld run fill 282 69 -3 282 70 -3 dirt
execute in minecraft:overworld run setblock 282 71 -3 coarse_dirt
execute in minecraft:overworld run fill 282 72 -3 282 144 -3 air
execute in minecraft:overworld run fill 282 58 -2 282 68 -2 stone
execute in minecraft:overworld run fill 282 69 -2 282 70 -2 dirt
execute in minecraft:overworld run setblock 282 71 -2 coarse_dirt
execute in minecraft:overworld run fill 282 72 -2 282 144 -2 air
execute in minecraft:overworld run fill 282 58 -1 282 68 -1 stone
execute in minecraft:overworld run fill 282 69 -1 282 70 -1 dirt
execute in minecraft:overworld run setblock 282 71 -1 grass_block
execute in minecraft:overworld run fill 282 72 -1 282 144 -1 air
execute in minecraft:overworld run setblock 282 72 -1 grass
execute in minecraft:overworld run fill 282 58 0 282 68 0 stone
execute in minecraft:overworld run fill 282 69 0 282 70 0 dirt
execute in minecraft:overworld run setblock 282 71 0 coarse_dirt
execute in minecraft:overworld run fill 282 72 0 282 144 0 air
execute in minecraft:overworld run fill 282 58 1 282 68 1 stone
execute in minecraft:overworld run fill 282 69 1 282 70 1 dirt
execute in minecraft:overworld run setblock 282 71 1 coarse_dirt
execute in minecraft:overworld run fill 282 72 1 282 144 1 air
execute in minecraft:overworld run fill 282 58 2 282 68 2 stone
schedule function blade_gallery:random/burned/part_118 1t replace
