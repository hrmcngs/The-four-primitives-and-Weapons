execute in minecraft:overworld run fill 286 58 -8 286 69 -8 stone
execute in minecraft:overworld run fill 286 70 -8 286 71 -8 dirt
execute in minecraft:overworld run setblock 286 72 -8 grass_block
execute in minecraft:overworld run fill 286 73 -8 286 144 -8 air
execute in minecraft:overworld run fill 286 58 -7 286 69 -7 stone
execute in minecraft:overworld run fill 286 70 -7 286 71 -7 dirt
execute in minecraft:overworld run setblock 286 72 -7 coarse_dirt
execute in minecraft:overworld run fill 286 73 -7 286 144 -7 air
execute in minecraft:overworld run setblock 286 73 -7 grass
execute in minecraft:overworld run fill 286 58 -6 286 69 -6 stone
execute in minecraft:overworld run fill 286 70 -6 286 71 -6 dirt
execute in minecraft:overworld run setblock 286 72 -6 coarse_dirt
execute in minecraft:overworld run fill 286 73 -6 286 144 -6 air
execute in minecraft:overworld run fill 286 58 -5 286 69 -5 stone
execute in minecraft:overworld run fill 286 70 -5 286 71 -5 dirt
execute in minecraft:overworld run setblock 286 72 -5 coarse_dirt
execute in minecraft:overworld run fill 286 73 -5 286 144 -5 air
execute in minecraft:overworld run fill 286 58 -4 286 69 -4 stone
execute in minecraft:overworld run fill 286 70 -4 286 71 -4 dirt
execute in minecraft:overworld run setblock 286 72 -4 coarse_dirt
execute in minecraft:overworld run fill 286 73 -4 286 144 -4 air
execute in minecraft:overworld run setblock 286 73 -4 grass
execute in minecraft:overworld run fill 286 58 -3 286 69 -3 stone
execute in minecraft:overworld run fill 286 70 -3 286 71 -3 dirt
execute in minecraft:overworld run setblock 286 72 -3 grass_block
execute in minecraft:overworld run fill 286 73 -3 286 144 -3 air
execute in minecraft:overworld run setblock 286 73 -3 grass
execute in minecraft:overworld run fill 286 58 -2 286 69 -2 stone
execute in minecraft:overworld run fill 286 70 -2 286 71 -2 dirt
execute in minecraft:overworld run setblock 286 72 -2 coarse_dirt
execute in minecraft:overworld run fill 286 73 -2 286 144 -2 air
execute in minecraft:overworld run fill 286 58 -1 286 70 -1 stone
execute in minecraft:overworld run fill 286 71 -1 286 72 -1 dirt
execute in minecraft:overworld run setblock 286 73 -1 grass_block
execute in minecraft:overworld run fill 286 74 -1 286 144 -1 air
execute in minecraft:overworld run fill 286 58 0 286 70 0 stone
execute in minecraft:overworld run fill 286 71 0 286 72 0 dirt
execute in minecraft:overworld run setblock 286 73 0 grass_block
execute in minecraft:overworld run fill 286 74 0 286 144 0 air
execute in minecraft:overworld run fill 286 58 1 286 69 1 stone
execute in minecraft:overworld run fill 286 70 1 286 71 1 dirt
execute in minecraft:overworld run setblock 286 72 1 grass_block
execute in minecraft:overworld run fill 286 73 1 286 144 1 air
execute in minecraft:overworld run fill 286 58 2 286 69 2 stone
execute in minecraft:overworld run fill 286 70 2 286 71 2 dirt
execute in minecraft:overworld run setblock 286 72 2 grass_block
execute in minecraft:overworld run fill 286 73 2 286 144 2 air
execute in minecraft:overworld run fill 286 58 3 286 69 3 stone
execute in minecraft:overworld run fill 286 70 3 286 71 3 dirt
execute in minecraft:overworld run setblock 286 72 3 grass_block
execute in minecraft:overworld run fill 286 73 3 286 144 3 air
execute in minecraft:overworld run setblock 286 73 3 grass
execute in minecraft:overworld run fill 286 58 4 286 68 4 stone
execute in minecraft:overworld run fill 286 69 4 286 70 4 dirt
execute in minecraft:overworld run setblock 286 71 4 coarse_dirt
execute in minecraft:overworld run fill 286 72 4 286 144 4 air
execute in minecraft:overworld run fill 286 58 5 286 68 5 stone
execute in minecraft:overworld run fill 286 69 5 286 70 5 dirt
execute in minecraft:overworld run setblock 286 71 5 coarse_dirt
execute in minecraft:overworld run fill 286 72 5 286 144 5 air
execute in minecraft:overworld run setblock 286 72 5 grass
execute in minecraft:overworld run fill 286 58 6 286 67 6 stone
execute in minecraft:overworld run fill 286 68 6 286 69 6 dirt
execute in minecraft:overworld run setblock 286 70 6 grass_block
execute in minecraft:overworld run fill 286 71 6 286 144 6 air
execute in minecraft:overworld run fill 286 58 7 286 67 7 stone
execute in minecraft:overworld run fill 286 68 7 286 69 7 dirt
execute in minecraft:overworld run setblock 286 70 7 coarse_dirt
execute in minecraft:overworld run fill 286 71 7 286 144 7 air
execute in minecraft:overworld run fill 286 58 8 286 66 8 stone
execute in minecraft:overworld run fill 286 67 8 286 68 8 dirt
execute in minecraft:overworld run setblock 286 69 8 coarse_dirt
execute in minecraft:overworld run fill 286 70 8 286 144 8 air
execute in minecraft:overworld run fill 286 58 9 286 66 9 stone
execute in minecraft:overworld run fill 286 67 9 286 68 9 dirt
execute in minecraft:overworld run setblock 286 69 9 grass_block
execute in minecraft:overworld run fill 286 70 9 286 144 9 air
execute in minecraft:overworld run fill 286 58 10 286 66 10 stone
execute in minecraft:overworld run fill 286 67 10 286 68 10 dirt
execute in minecraft:overworld run setblock 286 69 10 coarse_dirt
execute in minecraft:overworld run fill 286 70 10 286 144 10 air
execute in minecraft:overworld run fill 286 58 11 286 66 11 stone
execute in minecraft:overworld run fill 286 67 11 286 68 11 dirt
execute in minecraft:overworld run setblock 286 69 11 coarse_dirt
execute in minecraft:overworld run fill 286 70 11 286 144 11 air
execute in minecraft:overworld run fill 286 58 12 286 66 12 stone
execute in minecraft:overworld run fill 286 67 12 286 68 12 dirt
execute in minecraft:overworld run setblock 286 69 12 coarse_dirt
execute in minecraft:overworld run fill 286 70 12 286 144 12 air
execute in minecraft:overworld run fill 286 58 13 286 65 13 stone
execute in minecraft:overworld run fill 286 66 13 286 67 13 dirt
execute in minecraft:overworld run setblock 286 68 13 grass_block
execute in minecraft:overworld run fill 286 69 13 286 144 13 air
execute in minecraft:overworld run fill 286 58 14 286 65 14 stone
execute in minecraft:overworld run fill 286 66 14 286 67 14 dirt
execute in minecraft:overworld run setblock 286 68 14 coarse_dirt
execute in minecraft:overworld run fill 286 69 14 286 144 14 air
execute in minecraft:overworld run setblock 286 69 14 grass
execute in minecraft:overworld run fill 286 58 15 286 65 15 stone
execute in minecraft:overworld run fill 286 66 15 286 67 15 dirt
execute in minecraft:overworld run setblock 286 68 15 coarse_dirt
execute in minecraft:overworld run fill 286 69 15 286 144 15 air
execute in minecraft:overworld run fill 286 58 16 286 65 16 stone
execute in minecraft:overworld run fill 286 66 16 286 67 16 dirt
execute in minecraft:overworld run setblock 286 68 16 coarse_dirt
execute in minecraft:overworld run fill 286 69 16 286 144 16 air
execute in minecraft:overworld run fill 286 58 17 286 65 17 stone
execute in minecraft:overworld run fill 286 66 17 286 67 17 dirt
execute in minecraft:overworld run setblock 286 68 17 coarse_dirt
execute in minecraft:overworld run fill 286 69 17 286 144 17 air
execute in minecraft:overworld run fill 286 58 18 286 65 18 stone
execute in minecraft:overworld run fill 286 66 18 286 67 18 dirt
execute in minecraft:overworld run setblock 286 68 18 coarse_dirt
execute in minecraft:overworld run fill 286 69 18 286 144 18 air
execute in minecraft:overworld run fill 286 58 19 286 64 19 stone
execute in minecraft:overworld run fill 286 65 19 286 66 19 dirt
execute in minecraft:overworld run setblock 286 67 19 grass_block
execute in minecraft:overworld run fill 286 68 19 286 144 19 air
execute in minecraft:overworld run fill 286 58 20 286 64 20 stone
execute in minecraft:overworld run fill 286 65 20 286 66 20 dirt
execute in minecraft:overworld run setblock 286 67 20 grass_block
execute in minecraft:overworld run fill 286 68 20 286 144 20 air
execute in minecraft:overworld run fill 286 58 21 286 64 21 stone
execute in minecraft:overworld run fill 286 65 21 286 66 21 dirt
execute in minecraft:overworld run setblock 286 67 21 coarse_dirt
execute in minecraft:overworld run fill 286 68 21 286 144 21 air
execute in minecraft:overworld run fill 286 58 22 286 64 22 stone
execute in minecraft:overworld run fill 286 65 22 286 66 22 dirt
execute in minecraft:overworld run setblock 286 67 22 coarse_dirt
execute in minecraft:overworld run fill 286 68 22 286 144 22 air
execute in minecraft:overworld run fill 286 58 23 286 64 23 stone
execute in minecraft:overworld run fill 286 65 23 286 66 23 dirt
execute in minecraft:overworld run setblock 286 67 23 coarse_dirt
execute in minecraft:overworld run fill 286 68 23 286 144 23 air
execute in minecraft:overworld run fill 286 58 24 286 64 24 stone
execute in minecraft:overworld run fill 286 65 24 286 66 24 dirt
execute in minecraft:overworld run setblock 286 67 24 coarse_dirt
execute in minecraft:overworld run fill 286 68 24 286 144 24 air
execute in minecraft:overworld run setblock 286 68 24 grass
execute in minecraft:overworld run fill 286 58 25 286 64 25 stone
execute in minecraft:overworld run fill 286 65 25 286 66 25 dirt
execute in minecraft:overworld run setblock 286 67 25 coarse_dirt
execute in minecraft:overworld run fill 286 68 25 286 144 25 air
execute in minecraft:overworld run fill 286 58 26 286 64 26 stone
execute in minecraft:overworld run fill 286 65 26 286 66 26 dirt
execute in minecraft:overworld run setblock 286 67 26 coarse_dirt
execute in minecraft:overworld run fill 286 68 26 286 144 26 air
execute in minecraft:overworld run fill 286 58 27 286 64 27 stone
execute in minecraft:overworld run fill 286 65 27 286 66 27 dirt
execute in minecraft:overworld run setblock 286 67 27 coarse_dirt
execute in minecraft:overworld run fill 286 68 27 286 144 27 air
execute in minecraft:overworld run fill 286 58 28 286 64 28 stone
execute in minecraft:overworld run fill 286 65 28 286 66 28 dirt
execute in minecraft:overworld run setblock 286 67 28 coarse_dirt
execute in minecraft:overworld run fill 286 68 28 286 144 28 air
execute in minecraft:overworld run fill 286 58 29 286 64 29 stone
execute in minecraft:overworld run fill 286 65 29 286 66 29 dirt
execute in minecraft:overworld run setblock 286 67 29 grass_block
execute in minecraft:overworld run fill 286 68 29 286 144 29 air
execute in minecraft:overworld run fill 286 58 30 286 64 30 stone
execute in minecraft:overworld run fill 286 65 30 286 66 30 dirt
execute in minecraft:overworld run setblock 286 67 30 grass_block
execute in minecraft:overworld run fill 286 68 30 286 144 30 air
execute in minecraft:overworld run fill 286 58 31 286 63 31 stone
execute in minecraft:overworld run fill 286 64 31 286 65 31 dirt
execute in minecraft:overworld run setblock 286 66 31 grass_block
execute in minecraft:overworld run fill 286 67 31 286 144 31 air
execute in minecraft:overworld run fill 286 58 32 286 63 32 stone
execute in minecraft:overworld run fill 286 64 32 286 65 32 dirt
execute in minecraft:overworld run setblock 286 66 32 coarse_dirt
execute in minecraft:overworld run fill 286 67 32 286 144 32 air
execute in minecraft:overworld run fill 286 58 33 286 63 33 stone
execute in minecraft:overworld run fill 286 64 33 286 65 33 dirt
execute in minecraft:overworld run setblock 286 66 33 coarse_dirt
execute in minecraft:overworld run fill 286 67 33 286 144 33 air
execute in minecraft:overworld run fill 286 58 34 286 62 34 stone
execute in minecraft:overworld run fill 286 63 34 286 64 34 dirt
execute in minecraft:overworld run setblock 286 65 34 coarse_dirt
execute in minecraft:overworld run fill 286 66 34 286 144 34 air
execute in minecraft:overworld run setblock 286 66 34 mossy_cobblestone
execute in minecraft:overworld run fill 286 58 35 286 62 35 stone
execute in minecraft:overworld run fill 286 63 35 286 64 35 dirt
execute in minecraft:overworld run setblock 286 65 35 coarse_dirt
execute in minecraft:overworld run fill 286 66 35 286 144 35 air
execute in minecraft:overworld run setblock 286 66 35 grass
execute in minecraft:overworld run fill 286 58 36 286 62 36 stone
execute in minecraft:overworld run fill 286 63 36 286 64 36 dirt
execute in minecraft:overworld run setblock 286 65 36 grass_block
execute in minecraft:overworld run fill 286 66 36 286 144 36 air
execute in minecraft:overworld run fill 286 58 37 286 62 37 stone
execute in minecraft:overworld run fill 286 63 37 286 64 37 dirt
execute in minecraft:overworld run setblock 286 65 37 grass_block
execute in minecraft:overworld run fill 286 66 37 286 144 37 air
execute in minecraft:overworld run fill 286 58 38 286 62 38 stone
execute in minecraft:overworld run fill 286 63 38 286 64 38 dirt
execute in minecraft:overworld run setblock 286 65 38 grass_block
execute in minecraft:overworld run fill 286 66 38 286 144 38 air
execute in minecraft:overworld run fill 286 58 39 286 62 39 stone
execute in minecraft:overworld run fill 286 63 39 286 64 39 dirt
execute in minecraft:overworld run setblock 286 65 39 coarse_dirt
execute in minecraft:overworld run fill 286 66 39 286 144 39 air
execute in minecraft:overworld run fill 286 58 40 286 62 40 stone
execute in minecraft:overworld run fill 286 63 40 286 64 40 dirt
execute in minecraft:overworld run setblock 286 65 40 grass_block
execute in minecraft:overworld run fill 286 66 40 286 144 40 air
execute in minecraft:overworld run fill 286 58 41 286 62 41 stone
execute in minecraft:overworld run fill 286 63 41 286 64 41 dirt
execute in minecraft:overworld run setblock 286 65 41 grass_block
execute in minecraft:overworld run fill 286 66 41 286 144 41 air
execute in minecraft:overworld run fill 286 58 42 286 62 42 stone
execute in minecraft:overworld run fill 286 63 42 286 64 42 dirt
execute in minecraft:overworld run setblock 286 65 42 grass_block
execute in minecraft:overworld run fill 286 66 42 286 144 42 air
execute in minecraft:overworld run fill 286 58 43 286 62 43 stone
execute in minecraft:overworld run fill 286 63 43 286 64 43 dirt
execute in minecraft:overworld run setblock 286 65 43 coarse_dirt
execute in minecraft:overworld run fill 286 66 43 286 144 43 air
execute in minecraft:overworld run fill 286 58 44 286 62 44 stone
execute in minecraft:overworld run fill 286 63 44 286 64 44 dirt
execute in minecraft:overworld run setblock 286 65 44 grass_block
execute in minecraft:overworld run fill 286 66 44 286 144 44 air
execute in minecraft:overworld run fill 286 58 45 286 62 45 stone
execute in minecraft:overworld run fill 286 63 45 286 64 45 dirt
execute in minecraft:overworld run setblock 286 65 45 coarse_dirt
execute in minecraft:overworld run fill 286 66 45 286 144 45 air
execute in minecraft:overworld run fill 286 58 46 286 61 46 stone
execute in minecraft:overworld run fill 286 62 46 286 63 46 dirt
execute in minecraft:overworld run setblock 286 64 46 coarse_dirt
execute in minecraft:overworld run fill 286 65 46 286 144 46 air
execute in minecraft:overworld run fill 286 58 47 286 61 47 stone
execute in minecraft:overworld run fill 286 62 47 286 63 47 dirt
execute in minecraft:overworld run setblock 286 64 47 coarse_dirt
execute in minecraft:overworld run fill 286 65 47 286 144 47 air
execute in minecraft:overworld run fill 287 58 -48 287 61 -48 stone
execute in minecraft:overworld run fill 287 62 -48 287 63 -48 dirt
execute in minecraft:overworld run setblock 287 64 -48 coarse_dirt
execute in minecraft:overworld run fill 287 65 -48 287 144 -48 air
execute in minecraft:overworld run fill 287 58 -47 287 63 -47 stone
execute in minecraft:overworld run fill 287 64 -47 287 65 -47 dirt
execute in minecraft:overworld run setblock 287 66 -47 coarse_dirt
execute in minecraft:overworld run fill 287 67 -47 287 144 -47 air
execute in minecraft:overworld run fill 287 58 -46 287 65 -46 stone
execute in minecraft:overworld run fill 287 66 -46 287 67 -46 dirt
execute in minecraft:overworld run setblock 287 68 -46 coarse_dirt
execute in minecraft:overworld run fill 287 69 -46 287 144 -46 air
execute in minecraft:overworld run fill 287 58 -45 287 67 -45 stone
execute in minecraft:overworld run fill 287 68 -45 287 69 -45 dirt
execute in minecraft:overworld run setblock 287 70 -45 grass_block
execute in minecraft:overworld run fill 287 71 -45 287 144 -45 air
execute in minecraft:overworld run fill 287 58 -44 287 69 -44 stone
execute in minecraft:overworld run fill 287 70 -44 287 71 -44 dirt
execute in minecraft:overworld run setblock 287 72 -44 coarse_dirt
execute in minecraft:overworld run fill 287 73 -44 287 144 -44 air
execute in minecraft:overworld run fill 287 58 -43 287 71 -43 stone
execute in minecraft:overworld run fill 287 72 -43 287 73 -43 dirt
execute in minecraft:overworld run setblock 287 74 -43 grass_block
schedule function blade_gallery:random/burned/part_125 1t replace
