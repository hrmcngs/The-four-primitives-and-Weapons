execute in minecraft:overworld run fill 387 58 -23 387 63 -23 stone
execute in minecraft:overworld run fill 387 64 -23 387 65 -23 dirt
execute in minecraft:overworld run setblock 387 66 -23 coarse_dirt
execute in minecraft:overworld run fill 387 67 -23 387 144 -23 air
execute in minecraft:overworld run setblock 387 67 -23 grass
execute in minecraft:overworld run fill 387 58 -22 387 62 -22 stone
execute in minecraft:overworld run fill 387 63 -22 387 64 -22 dirt
execute in minecraft:overworld run setblock 387 65 -22 coarse_dirt
execute in minecraft:overworld run fill 387 66 -22 387 144 -22 air
execute in minecraft:overworld run setblock 387 66 -22 grass
execute in minecraft:overworld run fill 387 58 -21 387 61 -21 stone
execute in minecraft:overworld run fill 387 62 -21 387 63 -21 dirt
execute in minecraft:overworld run setblock 387 64 -21 coarse_dirt
execute in minecraft:overworld run fill 387 65 -21 387 144 -21 air
execute in minecraft:overworld run fill 387 58 -20 387 60 -20 stone
execute in minecraft:overworld run fill 387 61 -20 387 62 -20 dirt
execute in minecraft:overworld run setblock 387 63 -20 gravel
execute in minecraft:overworld run fill 387 64 -20 387 144 -20 air
execute in minecraft:overworld run fill 387 64 -20 387 64 -20 water
execute in minecraft:overworld run fill 387 58 -19 387 59 -19 stone
execute in minecraft:overworld run fill 387 60 -19 387 61 -19 dirt
execute in minecraft:overworld run setblock 387 62 -19 gravel
execute in minecraft:overworld run fill 387 63 -19 387 144 -19 air
execute in minecraft:overworld run fill 387 63 -19 387 64 -19 water
execute in minecraft:overworld run fill 387 58 -18 387 58 -18 stone
execute in minecraft:overworld run fill 387 59 -18 387 60 -18 dirt
execute in minecraft:overworld run setblock 387 61 -18 gravel
execute in minecraft:overworld run fill 387 62 -18 387 144 -18 air
execute in minecraft:overworld run fill 387 62 -18 387 64 -18 water
execute in minecraft:overworld run fill 387 58 -17 387 58 -17 stone
execute in minecraft:overworld run fill 387 59 -17 387 60 -17 dirt
execute in minecraft:overworld run setblock 387 61 -17 gravel
execute in minecraft:overworld run fill 387 62 -17 387 144 -17 air
execute in minecraft:overworld run fill 387 62 -17 387 64 -17 water
execute in minecraft:overworld run fill 387 58 -16 387 57 -16 stone
execute in minecraft:overworld run fill 387 58 -16 387 59 -16 dirt
execute in minecraft:overworld run setblock 387 60 -16 gravel
execute in minecraft:overworld run fill 387 61 -16 387 144 -16 air
execute in minecraft:overworld run fill 387 61 -16 387 64 -16 water
execute in minecraft:overworld run fill 387 58 -15 387 57 -15 stone
execute in minecraft:overworld run fill 387 58 -15 387 59 -15 dirt
execute in minecraft:overworld run setblock 387 60 -15 gravel
execute in minecraft:overworld run fill 387 61 -15 387 144 -15 air
execute in minecraft:overworld run fill 387 61 -15 387 64 -15 water
execute in minecraft:overworld run fill 387 58 -14 387 56 -14 stone
execute in minecraft:overworld run fill 387 57 -14 387 58 -14 dirt
execute in minecraft:overworld run setblock 387 59 -14 gravel
execute in minecraft:overworld run fill 387 60 -14 387 144 -14 air
execute in minecraft:overworld run fill 387 60 -14 387 64 -14 water
execute in minecraft:overworld run fill 387 58 -13 387 56 -13 stone
execute in minecraft:overworld run fill 387 57 -13 387 58 -13 dirt
execute in minecraft:overworld run setblock 387 59 -13 gravel
execute in minecraft:overworld run fill 387 60 -13 387 144 -13 air
execute in minecraft:overworld run fill 387 60 -13 387 64 -13 water
execute in minecraft:overworld run fill 387 58 -12 387 56 -12 stone
execute in minecraft:overworld run fill 387 57 -12 387 58 -12 dirt
execute in minecraft:overworld run setblock 387 59 -12 gravel
execute in minecraft:overworld run fill 387 60 -12 387 144 -12 air
execute in minecraft:overworld run fill 387 60 -12 387 64 -12 water
execute in minecraft:overworld run fill 387 58 -11 387 56 -11 stone
execute in minecraft:overworld run fill 387 57 -11 387 58 -11 dirt
execute in minecraft:overworld run setblock 387 59 -11 gravel
execute in minecraft:overworld run fill 387 60 -11 387 144 -11 air
execute in minecraft:overworld run fill 387 60 -11 387 64 -11 water
execute in minecraft:overworld run fill 387 58 -10 387 56 -10 stone
execute in minecraft:overworld run fill 387 57 -10 387 58 -10 dirt
execute in minecraft:overworld run setblock 387 59 -10 gravel
execute in minecraft:overworld run fill 387 60 -10 387 144 -10 air
execute in minecraft:overworld run fill 387 60 -10 387 64 -10 water
execute in minecraft:overworld run fill 387 58 -9 387 56 -9 stone
execute in minecraft:overworld run fill 387 57 -9 387 58 -9 dirt
execute in minecraft:overworld run setblock 387 59 -9 gravel
execute in minecraft:overworld run fill 387 60 -9 387 144 -9 air
execute in minecraft:overworld run fill 387 60 -9 387 64 -9 water
execute in minecraft:overworld run fill 387 58 -8 387 56 -8 stone
execute in minecraft:overworld run fill 387 57 -8 387 58 -8 dirt
execute in minecraft:overworld run setblock 387 59 -8 gravel
execute in minecraft:overworld run fill 387 60 -8 387 144 -8 air
execute in minecraft:overworld run fill 387 60 -8 387 64 -8 water
execute in minecraft:overworld run fill 387 58 -7 387 57 -7 stone
execute in minecraft:overworld run fill 387 58 -7 387 59 -7 dirt
execute in minecraft:overworld run setblock 387 60 -7 gravel
execute in minecraft:overworld run fill 387 61 -7 387 144 -7 air
execute in minecraft:overworld run fill 387 61 -7 387 64 -7 water
execute in minecraft:overworld run fill 387 58 -6 387 57 -6 stone
execute in minecraft:overworld run fill 387 58 -6 387 59 -6 dirt
execute in minecraft:overworld run setblock 387 60 -6 gravel
execute in minecraft:overworld run fill 387 61 -6 387 144 -6 air
execute in minecraft:overworld run fill 387 61 -6 387 64 -6 water
execute in minecraft:overworld run fill 387 58 -5 387 57 -5 stone
execute in minecraft:overworld run fill 387 58 -5 387 59 -5 dirt
execute in minecraft:overworld run setblock 387 60 -5 gravel
execute in minecraft:overworld run fill 387 61 -5 387 144 -5 air
execute in minecraft:overworld run fill 387 61 -5 387 64 -5 water
execute in minecraft:overworld run fill 387 58 -4 387 58 -4 stone
execute in minecraft:overworld run fill 387 59 -4 387 60 -4 dirt
execute in minecraft:overworld run setblock 387 61 -4 gravel
execute in minecraft:overworld run fill 387 62 -4 387 144 -4 air
execute in minecraft:overworld run fill 387 62 -4 387 64 -4 water
execute in minecraft:overworld run fill 387 58 -3 387 58 -3 stone
execute in minecraft:overworld run fill 387 59 -3 387 60 -3 dirt
execute in minecraft:overworld run setblock 387 61 -3 gravel
execute in minecraft:overworld run fill 387 62 -3 387 144 -3 air
execute in minecraft:overworld run fill 387 62 -3 387 64 -3 water
execute in minecraft:overworld run fill 387 58 -2 387 58 -2 stone
execute in minecraft:overworld run fill 387 59 -2 387 60 -2 dirt
execute in minecraft:overworld run setblock 387 61 -2 gravel
execute in minecraft:overworld run fill 387 62 -2 387 144 -2 air
execute in minecraft:overworld run fill 387 62 -2 387 64 -2 water
execute in minecraft:overworld run fill 387 58 -1 387 59 -1 stone
execute in minecraft:overworld run fill 387 60 -1 387 61 -1 dirt
execute in minecraft:overworld run setblock 387 62 -1 gravel
execute in minecraft:overworld run fill 387 63 -1 387 144 -1 air
execute in minecraft:overworld run fill 387 63 -1 387 64 -1 water
execute in minecraft:overworld run fill 387 58 0 387 59 0 stone
execute in minecraft:overworld run fill 387 60 0 387 61 0 dirt
execute in minecraft:overworld run setblock 387 62 0 gravel
execute in minecraft:overworld run fill 387 63 0 387 144 0 air
execute in minecraft:overworld run fill 387 63 0 387 64 0 water
execute in minecraft:overworld run fill 387 58 1 387 59 1 stone
execute in minecraft:overworld run fill 387 60 1 387 61 1 dirt
execute in minecraft:overworld run setblock 387 62 1 gravel
execute in minecraft:overworld run fill 387 63 1 387 144 1 air
execute in minecraft:overworld run fill 387 63 1 387 64 1 water
execute in minecraft:overworld run fill 387 58 2 387 59 2 stone
execute in minecraft:overworld run fill 387 60 2 387 61 2 dirt
execute in minecraft:overworld run setblock 387 62 2 gravel
execute in minecraft:overworld run fill 387 63 2 387 144 2 air
execute in minecraft:overworld run fill 387 63 2 387 64 2 water
execute in minecraft:overworld run fill 387 58 3 387 59 3 stone
execute in minecraft:overworld run fill 387 60 3 387 61 3 dirt
execute in minecraft:overworld run setblock 387 62 3 gravel
execute in minecraft:overworld run fill 387 63 3 387 144 3 air
execute in minecraft:overworld run fill 387 63 3 387 64 3 water
execute in minecraft:overworld run fill 387 58 4 387 60 4 stone
execute in minecraft:overworld run fill 387 61 4 387 62 4 dirt
execute in minecraft:overworld run setblock 387 63 4 gravel
execute in minecraft:overworld run fill 387 64 4 387 144 4 air
execute in minecraft:overworld run fill 387 64 4 387 64 4 water
execute in minecraft:overworld run fill 387 58 5 387 60 5 stone
execute in minecraft:overworld run fill 387 61 5 387 62 5 dirt
execute in minecraft:overworld run setblock 387 63 5 gravel
execute in minecraft:overworld run fill 387 64 5 387 144 5 air
execute in minecraft:overworld run fill 387 64 5 387 64 5 water
execute in minecraft:overworld run fill 387 58 6 387 60 6 stone
execute in minecraft:overworld run fill 387 61 6 387 62 6 dirt
execute in minecraft:overworld run setblock 387 63 6 gravel
execute in minecraft:overworld run fill 387 64 6 387 144 6 air
execute in minecraft:overworld run fill 387 64 6 387 64 6 water
execute in minecraft:overworld run fill 387 58 7 387 60 7 stone
execute in minecraft:overworld run fill 387 61 7 387 62 7 dirt
execute in minecraft:overworld run setblock 387 63 7 gravel
execute in minecraft:overworld run fill 387 64 7 387 144 7 air
execute in minecraft:overworld run fill 387 64 7 387 64 7 water
execute in minecraft:overworld run fill 387 58 8 387 60 8 stone
execute in minecraft:overworld run fill 387 61 8 387 62 8 dirt
execute in minecraft:overworld run setblock 387 63 8 gravel
execute in minecraft:overworld run fill 387 64 8 387 144 8 air
execute in minecraft:overworld run fill 387 64 8 387 64 8 water
execute in minecraft:overworld run fill 387 58 9 387 60 9 stone
execute in minecraft:overworld run fill 387 61 9 387 62 9 dirt
execute in minecraft:overworld run setblock 387 63 9 gravel
execute in minecraft:overworld run fill 387 64 9 387 144 9 air
execute in minecraft:overworld run fill 387 64 9 387 64 9 water
execute in minecraft:overworld run fill 387 58 10 387 60 10 stone
execute in minecraft:overworld run fill 387 61 10 387 62 10 dirt
execute in minecraft:overworld run setblock 387 63 10 gravel
execute in minecraft:overworld run fill 387 64 10 387 144 10 air
execute in minecraft:overworld run fill 387 64 10 387 64 10 water
execute in minecraft:overworld run fill 387 58 11 387 61 11 stone
execute in minecraft:overworld run fill 387 62 11 387 63 11 dirt
execute in minecraft:overworld run setblock 387 64 11 coarse_dirt
execute in minecraft:overworld run fill 387 65 11 387 144 11 air
execute in minecraft:overworld run fill 387 58 12 387 61 12 stone
execute in minecraft:overworld run fill 387 62 12 387 63 12 dirt
execute in minecraft:overworld run setblock 387 64 12 coarse_dirt
execute in minecraft:overworld run fill 387 65 12 387 144 12 air
execute in minecraft:overworld run fill 387 58 13 387 61 13 stone
execute in minecraft:overworld run fill 387 62 13 387 63 13 dirt
execute in minecraft:overworld run setblock 387 64 13 grass_block
execute in minecraft:overworld run fill 387 65 13 387 144 13 air
execute in minecraft:overworld run fill 387 58 14 387 61 14 stone
execute in minecraft:overworld run fill 387 62 14 387 63 14 dirt
execute in minecraft:overworld run setblock 387 64 14 coarse_dirt
execute in minecraft:overworld run fill 387 65 14 387 144 14 air
execute in minecraft:overworld run fill 387 58 15 387 61 15 stone
execute in minecraft:overworld run fill 387 62 15 387 63 15 dirt
execute in minecraft:overworld run setblock 387 64 15 coarse_dirt
execute in minecraft:overworld run fill 387 65 15 387 144 15 air
execute in minecraft:overworld run fill 387 58 16 387 61 16 stone
execute in minecraft:overworld run fill 387 62 16 387 63 16 dirt
execute in minecraft:overworld run setblock 387 64 16 grass_block
execute in minecraft:overworld run fill 387 65 16 387 144 16 air
execute in minecraft:overworld run fill 387 58 17 387 61 17 stone
execute in minecraft:overworld run fill 387 62 17 387 63 17 dirt
execute in minecraft:overworld run setblock 387 64 17 grass_block
execute in minecraft:overworld run fill 387 65 17 387 144 17 air
execute in minecraft:overworld run fill 387 58 18 387 61 18 stone
execute in minecraft:overworld run fill 387 62 18 387 63 18 dirt
execute in minecraft:overworld run setblock 387 64 18 coarse_dirt
execute in minecraft:overworld run fill 387 65 18 387 144 18 air
execute in minecraft:overworld run fill 387 58 19 387 62 19 stone
execute in minecraft:overworld run fill 387 63 19 387 64 19 dirt
execute in minecraft:overworld run setblock 387 65 19 coarse_dirt
execute in minecraft:overworld run fill 387 66 19 387 144 19 air
execute in minecraft:overworld run fill 387 58 20 387 62 20 stone
execute in minecraft:overworld run fill 387 63 20 387 64 20 dirt
execute in minecraft:overworld run setblock 387 65 20 coarse_dirt
execute in minecraft:overworld run fill 387 66 20 387 144 20 air
execute in minecraft:overworld run fill 387 58 21 387 62 21 stone
execute in minecraft:overworld run fill 387 63 21 387 64 21 dirt
execute in minecraft:overworld run setblock 387 65 21 coarse_dirt
execute in minecraft:overworld run fill 387 66 21 387 144 21 air
execute in minecraft:overworld run fill 387 58 22 387 62 22 stone
execute in minecraft:overworld run fill 387 63 22 387 64 22 dirt
execute in minecraft:overworld run setblock 387 65 22 grass_block
execute in minecraft:overworld run fill 387 66 22 387 144 22 air
execute in minecraft:overworld run fill 387 58 23 387 62 23 stone
execute in minecraft:overworld run fill 387 63 23 387 64 23 dirt
execute in minecraft:overworld run setblock 387 65 23 grass_block
execute in minecraft:overworld run fill 387 66 23 387 144 23 air
execute in minecraft:overworld run fill 387 58 24 387 61 24 stone
execute in minecraft:overworld run fill 387 62 24 387 63 24 dirt
execute in minecraft:overworld run setblock 387 64 24 grass_block
execute in minecraft:overworld run fill 387 65 24 387 144 24 air
execute in minecraft:overworld run fill 387 58 25 387 61 25 stone
execute in minecraft:overworld run fill 387 62 25 387 63 25 dirt
execute in minecraft:overworld run setblock 387 64 25 coarse_dirt
execute in minecraft:overworld run fill 387 65 25 387 144 25 air
execute in minecraft:overworld run fill 387 58 26 387 61 26 stone
execute in minecraft:overworld run fill 387 62 26 387 63 26 dirt
execute in minecraft:overworld run setblock 387 64 26 coarse_dirt
execute in minecraft:overworld run fill 387 65 26 387 144 26 air
execute in minecraft:overworld run fill 387 58 27 387 61 27 stone
execute in minecraft:overworld run fill 387 62 27 387 63 27 dirt
execute in minecraft:overworld run setblock 387 64 27 coarse_dirt
execute in minecraft:overworld run fill 387 65 27 387 144 27 air
execute in minecraft:overworld run fill 387 58 28 387 61 28 stone
execute in minecraft:overworld run fill 387 62 28 387 63 28 dirt
execute in minecraft:overworld run setblock 387 64 28 grass_block
execute in minecraft:overworld run fill 387 65 28 387 144 28 air
execute in minecraft:overworld run fill 387 58 29 387 60 29 stone
execute in minecraft:overworld run fill 387 61 29 387 62 29 dirt
execute in minecraft:overworld run setblock 387 63 29 gravel
execute in minecraft:overworld run fill 387 64 29 387 144 29 air
execute in minecraft:overworld run fill 387 64 29 387 64 29 water
execute in minecraft:overworld run fill 387 58 30 387 60 30 stone
execute in minecraft:overworld run fill 387 61 30 387 62 30 dirt
execute in minecraft:overworld run setblock 387 63 30 gravel
execute in minecraft:overworld run fill 387 64 30 387 144 30 air
execute in minecraft:overworld run fill 387 64 30 387 64 30 water
execute in minecraft:overworld run fill 387 58 31 387 60 31 stone
execute in minecraft:overworld run fill 387 61 31 387 62 31 dirt
execute in minecraft:overworld run setblock 387 63 31 gravel
execute in minecraft:overworld run fill 387 64 31 387 144 31 air
execute in minecraft:overworld run fill 387 64 31 387 64 31 water
schedule function blade_gallery:random/battlefield/part_80 1t replace
