execute in minecraft:overworld run fill 356 58 -17 356 69 -17 stone
execute in minecraft:overworld run fill 356 70 -17 356 71 -17 dirt
execute in minecraft:overworld run setblock 356 72 -17 coarse_dirt
execute in minecraft:overworld run fill 356 73 -17 356 144 -17 air
execute in minecraft:overworld run fill 356 58 -16 356 69 -16 stone
execute in minecraft:overworld run fill 356 70 -16 356 71 -16 dirt
execute in minecraft:overworld run setblock 356 72 -16 coarse_dirt
execute in minecraft:overworld run fill 356 73 -16 356 144 -16 air
execute in minecraft:overworld run fill 356 58 -15 356 68 -15 stone
execute in minecraft:overworld run fill 356 69 -15 356 70 -15 dirt
execute in minecraft:overworld run setblock 356 71 -15 coarse_dirt
execute in minecraft:overworld run fill 356 72 -15 356 144 -15 air
execute in minecraft:overworld run fill 356 58 -14 356 68 -14 stone
execute in minecraft:overworld run fill 356 69 -14 356 70 -14 dirt
execute in minecraft:overworld run setblock 356 71 -14 coarse_dirt
execute in minecraft:overworld run fill 356 72 -14 356 144 -14 air
execute in minecraft:overworld run fill 356 58 -13 356 67 -13 stone
execute in minecraft:overworld run fill 356 68 -13 356 69 -13 dirt
execute in minecraft:overworld run setblock 356 70 -13 coarse_dirt
execute in minecraft:overworld run fill 356 71 -13 356 144 -13 air
execute in minecraft:overworld run fill 356 58 -12 356 66 -12 stone
execute in minecraft:overworld run fill 356 67 -12 356 68 -12 dirt
execute in minecraft:overworld run setblock 356 69 -12 coarse_dirt
execute in minecraft:overworld run fill 356 70 -12 356 144 -12 air
execute in minecraft:overworld run fill 356 58 -11 356 66 -11 stone
execute in minecraft:overworld run fill 356 67 -11 356 68 -11 dirt
execute in minecraft:overworld run setblock 356 69 -11 grass_block
execute in minecraft:overworld run fill 356 70 -11 356 144 -11 air
execute in minecraft:overworld run fill 356 58 -10 356 66 -10 stone
execute in minecraft:overworld run fill 356 67 -10 356 68 -10 dirt
execute in minecraft:overworld run setblock 356 69 -10 coarse_dirt
execute in minecraft:overworld run fill 356 70 -10 356 144 -10 air
execute in minecraft:overworld run setblock 356 70 -10 grass
execute in minecraft:overworld run fill 356 58 -9 356 66 -9 stone
execute in minecraft:overworld run fill 356 67 -9 356 68 -9 dirt
execute in minecraft:overworld run setblock 356 69 -9 coarse_dirt
execute in minecraft:overworld run fill 356 70 -9 356 144 -9 air
execute in minecraft:overworld run setblock 356 70 -9 grass
execute in minecraft:overworld run fill 356 58 -8 356 66 -8 stone
execute in minecraft:overworld run fill 356 67 -8 356 68 -8 dirt
execute in minecraft:overworld run setblock 356 69 -8 coarse_dirt
execute in minecraft:overworld run fill 356 70 -8 356 144 -8 air
execute in minecraft:overworld run fill 356 58 -7 356 66 -7 stone
execute in minecraft:overworld run fill 356 67 -7 356 68 -7 dirt
execute in minecraft:overworld run setblock 356 69 -7 coarse_dirt
execute in minecraft:overworld run fill 356 70 -7 356 144 -7 air
execute in minecraft:overworld run fill 356 58 -6 356 66 -6 stone
execute in minecraft:overworld run fill 356 67 -6 356 68 -6 dirt
execute in minecraft:overworld run setblock 356 69 -6 grass_block
execute in minecraft:overworld run fill 356 70 -6 356 144 -6 air
execute in minecraft:overworld run fill 356 58 -5 356 66 -5 stone
execute in minecraft:overworld run fill 356 67 -5 356 68 -5 dirt
execute in minecraft:overworld run setblock 356 69 -5 coarse_dirt
execute in minecraft:overworld run fill 356 70 -5 356 144 -5 air
execute in minecraft:overworld run fill 356 58 -4 356 66 -4 stone
execute in minecraft:overworld run fill 356 67 -4 356 68 -4 dirt
execute in minecraft:overworld run setblock 356 69 -4 coarse_dirt
execute in minecraft:overworld run fill 356 70 -4 356 144 -4 air
execute in minecraft:overworld run fill 356 58 -3 356 66 -3 stone
execute in minecraft:overworld run fill 356 67 -3 356 68 -3 dirt
execute in minecraft:overworld run setblock 356 69 -3 coarse_dirt
execute in minecraft:overworld run fill 356 70 -3 356 144 -3 air
execute in minecraft:overworld run fill 356 58 -2 356 66 -2 stone
execute in minecraft:overworld run fill 356 67 -2 356 68 -2 dirt
execute in minecraft:overworld run setblock 356 69 -2 coarse_dirt
execute in minecraft:overworld run fill 356 70 -2 356 144 -2 air
execute in minecraft:overworld run fill 356 58 -1 356 66 -1 stone
execute in minecraft:overworld run fill 356 67 -1 356 68 -1 dirt
execute in minecraft:overworld run setblock 356 69 -1 coarse_dirt
execute in minecraft:overworld run fill 356 70 -1 356 144 -1 air
execute in minecraft:overworld run fill 356 58 0 356 66 0 stone
execute in minecraft:overworld run fill 356 67 0 356 68 0 dirt
execute in minecraft:overworld run setblock 356 69 0 coarse_dirt
execute in minecraft:overworld run fill 356 70 0 356 144 0 air
execute in minecraft:overworld run fill 356 58 1 356 66 1 stone
execute in minecraft:overworld run fill 356 67 1 356 68 1 dirt
execute in minecraft:overworld run setblock 356 69 1 coarse_dirt
execute in minecraft:overworld run fill 356 70 1 356 144 1 air
execute in minecraft:overworld run fill 356 58 2 356 66 2 stone
execute in minecraft:overworld run fill 356 67 2 356 68 2 dirt
execute in minecraft:overworld run setblock 356 69 2 coarse_dirt
execute in minecraft:overworld run fill 356 70 2 356 144 2 air
execute in minecraft:overworld run fill 356 58 3 356 66 3 stone
execute in minecraft:overworld run fill 356 67 3 356 68 3 dirt
execute in minecraft:overworld run setblock 356 69 3 coarse_dirt
execute in minecraft:overworld run fill 356 70 3 356 144 3 air
execute in minecraft:overworld run fill 356 58 4 356 66 4 stone
execute in minecraft:overworld run fill 356 67 4 356 68 4 dirt
execute in minecraft:overworld run setblock 356 69 4 coarse_dirt
execute in minecraft:overworld run fill 356 70 4 356 144 4 air
execute in minecraft:overworld run fill 356 58 5 356 67 5 stone
execute in minecraft:overworld run fill 356 68 5 356 69 5 dirt
execute in minecraft:overworld run setblock 356 70 5 coarse_dirt
execute in minecraft:overworld run fill 356 71 5 356 144 5 air
execute in minecraft:overworld run setblock 356 71 5 grass
execute in minecraft:overworld run fill 356 58 6 356 67 6 stone
execute in minecraft:overworld run fill 356 68 6 356 69 6 dirt
execute in minecraft:overworld run setblock 356 70 6 grass_block
execute in minecraft:overworld run fill 356 71 6 356 144 6 air
execute in minecraft:overworld run fill 356 58 7 356 67 7 stone
execute in minecraft:overworld run fill 356 68 7 356 69 7 dirt
execute in minecraft:overworld run setblock 356 70 7 coarse_dirt
execute in minecraft:overworld run fill 356 71 7 356 144 7 air
execute in minecraft:overworld run fill 356 58 8 356 68 8 stone
execute in minecraft:overworld run fill 356 69 8 356 70 8 dirt
execute in minecraft:overworld run setblock 356 71 8 grass_block
execute in minecraft:overworld run fill 356 72 8 356 144 8 air
execute in minecraft:overworld run fill 356 58 9 356 68 9 stone
execute in minecraft:overworld run fill 356 69 9 356 70 9 dirt
execute in minecraft:overworld run setblock 356 71 9 grass_block
execute in minecraft:overworld run fill 356 72 9 356 144 9 air
execute in minecraft:overworld run setblock 356 72 9 grass
execute in minecraft:overworld run fill 356 58 10 356 68 10 stone
execute in minecraft:overworld run fill 356 69 10 356 70 10 dirt
execute in minecraft:overworld run setblock 356 71 10 grass_block
execute in minecraft:overworld run fill 356 72 10 356 144 10 air
execute in minecraft:overworld run fill 356 58 11 356 68 11 stone
execute in minecraft:overworld run fill 356 69 11 356 70 11 dirt
execute in minecraft:overworld run setblock 356 71 11 grass_block
execute in minecraft:overworld run fill 356 72 11 356 144 11 air
execute in minecraft:overworld run fill 356 58 12 356 68 12 stone
execute in minecraft:overworld run fill 356 69 12 356 70 12 dirt
execute in minecraft:overworld run setblock 356 71 12 grass_block
execute in minecraft:overworld run fill 356 72 12 356 144 12 air
execute in minecraft:overworld run fill 356 58 13 356 68 13 stone
execute in minecraft:overworld run fill 356 69 13 356 70 13 dirt
execute in minecraft:overworld run setblock 356 71 13 grass_block
execute in minecraft:overworld run fill 356 72 13 356 144 13 air
execute in minecraft:overworld run fill 356 58 14 356 68 14 stone
execute in minecraft:overworld run fill 356 69 14 356 70 14 dirt
execute in minecraft:overworld run setblock 356 71 14 coarse_dirt
execute in minecraft:overworld run fill 356 72 14 356 144 14 air
execute in minecraft:overworld run fill 356 58 15 356 68 15 stone
execute in minecraft:overworld run fill 356 69 15 356 70 15 dirt
execute in minecraft:overworld run setblock 356 71 15 grass_block
execute in minecraft:overworld run fill 356 72 15 356 144 15 air
execute in minecraft:overworld run fill 356 58 16 356 68 16 stone
execute in minecraft:overworld run fill 356 69 16 356 70 16 dirt
execute in minecraft:overworld run setblock 356 71 16 grass_block
execute in minecraft:overworld run fill 356 72 16 356 144 16 air
execute in minecraft:overworld run fill 356 58 17 356 68 17 stone
execute in minecraft:overworld run fill 356 69 17 356 70 17 dirt
execute in minecraft:overworld run setblock 356 71 17 coarse_dirt
execute in minecraft:overworld run fill 356 72 17 356 144 17 air
execute in minecraft:overworld run fill 356 58 18 356 68 18 stone
execute in minecraft:overworld run fill 356 69 18 356 70 18 dirt
execute in minecraft:overworld run setblock 356 71 18 coarse_dirt
execute in minecraft:overworld run fill 356 72 18 356 144 18 air
execute in minecraft:overworld run fill 356 58 19 356 68 19 stone
execute in minecraft:overworld run fill 356 69 19 356 70 19 dirt
execute in minecraft:overworld run setblock 356 71 19 grass_block
execute in minecraft:overworld run fill 356 72 19 356 144 19 air
execute in minecraft:overworld run fill 356 58 20 356 68 20 stone
execute in minecraft:overworld run fill 356 69 20 356 70 20 dirt
execute in minecraft:overworld run setblock 356 71 20 coarse_dirt
execute in minecraft:overworld run fill 356 72 20 356 144 20 air
execute in minecraft:overworld run fill 356 58 21 356 68 21 stone
execute in minecraft:overworld run fill 356 69 21 356 70 21 dirt
execute in minecraft:overworld run setblock 356 71 21 coarse_dirt
execute in minecraft:overworld run fill 356 72 21 356 144 21 air
execute in minecraft:overworld run fill 356 58 22 356 68 22 stone
execute in minecraft:overworld run fill 356 69 22 356 70 22 dirt
execute in minecraft:overworld run setblock 356 71 22 coarse_dirt
execute in minecraft:overworld run fill 356 72 22 356 144 22 air
execute in minecraft:overworld run fill 356 58 23 356 68 23 stone
execute in minecraft:overworld run fill 356 69 23 356 70 23 dirt
execute in minecraft:overworld run setblock 356 71 23 grass_block
execute in minecraft:overworld run fill 356 72 23 356 144 23 air
execute in minecraft:overworld run fill 356 58 24 356 68 24 stone
execute in minecraft:overworld run fill 356 69 24 356 70 24 dirt
execute in minecraft:overworld run setblock 356 71 24 coarse_dirt
execute in minecraft:overworld run fill 356 72 24 356 144 24 air
execute in minecraft:overworld run fill 356 58 25 356 68 25 stone
execute in minecraft:overworld run fill 356 69 25 356 70 25 dirt
execute in minecraft:overworld run setblock 356 71 25 coarse_dirt
execute in minecraft:overworld run fill 356 72 25 356 144 25 air
execute in minecraft:overworld run fill 356 58 26 356 68 26 stone
execute in minecraft:overworld run fill 356 69 26 356 70 26 dirt
execute in minecraft:overworld run setblock 356 71 26 coarse_dirt
execute in minecraft:overworld run fill 356 72 26 356 144 26 air
execute in minecraft:overworld run fill 356 58 27 356 68 27 stone
execute in minecraft:overworld run fill 356 69 27 356 70 27 dirt
execute in minecraft:overworld run setblock 356 71 27 coarse_dirt
execute in minecraft:overworld run fill 356 72 27 356 144 27 air
execute in minecraft:overworld run setblock 356 72 27 grass
execute in minecraft:overworld run fill 356 58 28 356 68 28 stone
execute in minecraft:overworld run fill 356 69 28 356 70 28 dirt
execute in minecraft:overworld run setblock 356 71 28 coarse_dirt
execute in minecraft:overworld run fill 356 72 28 356 144 28 air
execute in minecraft:overworld run fill 356 58 29 356 68 29 stone
execute in minecraft:overworld run fill 356 69 29 356 70 29 dirt
execute in minecraft:overworld run setblock 356 71 29 coarse_dirt
execute in minecraft:overworld run fill 356 72 29 356 144 29 air
execute in minecraft:overworld run fill 356 58 30 356 68 30 stone
execute in minecraft:overworld run fill 356 69 30 356 70 30 dirt
execute in minecraft:overworld run setblock 356 71 30 coarse_dirt
execute in minecraft:overworld run fill 356 72 30 356 144 30 air
execute in minecraft:overworld run fill 356 58 31 356 68 31 stone
execute in minecraft:overworld run fill 356 69 31 356 70 31 dirt
execute in minecraft:overworld run setblock 356 71 31 coarse_dirt
execute in minecraft:overworld run fill 356 72 31 356 144 31 air
execute in minecraft:overworld run fill 356 58 32 356 68 32 stone
execute in minecraft:overworld run fill 356 69 32 356 70 32 dirt
execute in minecraft:overworld run setblock 356 71 32 coarse_dirt
execute in minecraft:overworld run fill 356 72 32 356 144 32 air
execute in minecraft:overworld run fill 356 58 33 356 68 33 stone
execute in minecraft:overworld run fill 356 69 33 356 70 33 dirt
execute in minecraft:overworld run setblock 356 71 33 grass_block
execute in minecraft:overworld run fill 356 72 33 356 144 33 air
execute in minecraft:overworld run fill 356 58 34 356 68 34 stone
execute in minecraft:overworld run fill 356 69 34 356 70 34 dirt
execute in minecraft:overworld run setblock 356 71 34 coarse_dirt
execute in minecraft:overworld run fill 356 72 34 356 144 34 air
execute in minecraft:overworld run setblock 356 72 34 grass
execute in minecraft:overworld run fill 356 58 35 356 69 35 stone
execute in minecraft:overworld run fill 356 70 35 356 71 35 dirt
execute in minecraft:overworld run setblock 356 72 35 grass_block
execute in minecraft:overworld run fill 356 73 35 356 144 35 air
execute in minecraft:overworld run fill 356 58 36 356 69 36 stone
execute in minecraft:overworld run fill 356 70 36 356 71 36 dirt
execute in minecraft:overworld run setblock 356 72 36 coarse_dirt
execute in minecraft:overworld run fill 356 73 36 356 144 36 air
execute in minecraft:overworld run fill 356 58 37 356 69 37 stone
execute in minecraft:overworld run fill 356 70 37 356 71 37 dirt
execute in minecraft:overworld run setblock 356 72 37 coarse_dirt
execute in minecraft:overworld run fill 356 73 37 356 144 37 air
execute in minecraft:overworld run fill 356 58 38 356 68 38 stone
execute in minecraft:overworld run fill 356 69 38 356 70 38 dirt
execute in minecraft:overworld run setblock 356 71 38 coarse_dirt
execute in minecraft:overworld run fill 356 72 38 356 144 38 air
execute in minecraft:overworld run fill 356 58 39 356 68 39 stone
execute in minecraft:overworld run fill 356 69 39 356 70 39 dirt
execute in minecraft:overworld run setblock 356 71 39 coarse_dirt
execute in minecraft:overworld run fill 356 72 39 356 144 39 air
execute in minecraft:overworld run fill 356 58 40 356 67 40 stone
execute in minecraft:overworld run fill 356 68 40 356 69 40 dirt
execute in minecraft:overworld run setblock 356 70 40 coarse_dirt
execute in minecraft:overworld run fill 356 71 40 356 144 40 air
execute in minecraft:overworld run fill 356 58 41 356 66 41 stone
execute in minecraft:overworld run fill 356 67 41 356 68 41 dirt
execute in minecraft:overworld run setblock 356 69 41 coarse_dirt
execute in minecraft:overworld run fill 356 70 41 356 144 41 air
execute in minecraft:overworld run fill 356 58 42 356 65 42 stone
execute in minecraft:overworld run fill 356 66 42 356 67 42 dirt
execute in minecraft:overworld run setblock 356 68 42 grass_block
execute in minecraft:overworld run fill 356 69 42 356 144 42 air
execute in minecraft:overworld run fill 356 58 43 356 64 43 stone
execute in minecraft:overworld run fill 356 65 43 356 66 43 dirt
execute in minecraft:overworld run setblock 356 67 43 coarse_dirt
execute in minecraft:overworld run fill 356 68 43 356 144 43 air
execute in minecraft:overworld run fill 356 58 44 356 64 44 stone
execute in minecraft:overworld run fill 356 65 44 356 66 44 dirt
execute in minecraft:overworld run setblock 356 67 44 coarse_dirt
execute in minecraft:overworld run fill 356 68 44 356 144 44 air
execute in minecraft:overworld run fill 356 58 45 356 63 45 stone
execute in minecraft:overworld run fill 356 64 45 356 65 45 dirt
schedule function blade_gallery:random/battlefield/part_32 1t replace
