execute in minecraft:overworld run fill 282 69 2 282 70 2 dirt
execute in minecraft:overworld run setblock 282 71 2 coarse_dirt
execute in minecraft:overworld run fill 282 72 2 282 144 2 air
execute in minecraft:overworld run fill 282 58 3 282 68 3 stone
execute in minecraft:overworld run fill 282 69 3 282 70 3 dirt
execute in minecraft:overworld run setblock 282 71 3 coarse_dirt
execute in minecraft:overworld run fill 282 72 3 282 144 3 air
execute in minecraft:overworld run fill 282 58 4 282 67 4 stone
execute in minecraft:overworld run fill 282 68 4 282 69 4 dirt
execute in minecraft:overworld run setblock 282 70 4 coarse_dirt
execute in minecraft:overworld run fill 282 71 4 282 144 4 air
execute in minecraft:overworld run fill 282 58 5 282 67 5 stone
execute in minecraft:overworld run fill 282 68 5 282 69 5 dirt
execute in minecraft:overworld run setblock 282 70 5 coarse_dirt
execute in minecraft:overworld run fill 282 71 5 282 144 5 air
execute in minecraft:overworld run setblock 282 71 5 grass
execute in minecraft:overworld run fill 282 58 6 282 67 6 stone
execute in minecraft:overworld run fill 282 68 6 282 69 6 dirt
execute in minecraft:overworld run setblock 282 70 6 coarse_dirt
execute in minecraft:overworld run fill 282 71 6 282 144 6 air
execute in minecraft:overworld run fill 282 58 7 282 66 7 stone
execute in minecraft:overworld run fill 282 67 7 282 68 7 dirt
execute in minecraft:overworld run setblock 282 69 7 coarse_dirt
execute in minecraft:overworld run fill 282 70 7 282 144 7 air
execute in minecraft:overworld run fill 282 58 8 282 66 8 stone
execute in minecraft:overworld run fill 282 67 8 282 68 8 dirt
execute in minecraft:overworld run setblock 282 69 8 coarse_dirt
execute in minecraft:overworld run fill 282 70 8 282 144 8 air
execute in minecraft:overworld run fill 282 58 9 282 66 9 stone
execute in minecraft:overworld run fill 282 67 9 282 68 9 dirt
execute in minecraft:overworld run setblock 282 69 9 coarse_dirt
execute in minecraft:overworld run fill 282 70 9 282 144 9 air
execute in minecraft:overworld run fill 282 58 10 282 65 10 stone
execute in minecraft:overworld run fill 282 66 10 282 67 10 dirt
execute in minecraft:overworld run setblock 282 68 10 coarse_dirt
execute in minecraft:overworld run fill 282 69 10 282 144 10 air
execute in minecraft:overworld run fill 282 58 11 282 65 11 stone
execute in minecraft:overworld run fill 282 66 11 282 67 11 dirt
execute in minecraft:overworld run setblock 282 68 11 coarse_dirt
execute in minecraft:overworld run fill 282 69 11 282 144 11 air
execute in minecraft:overworld run fill 282 58 12 282 65 12 stone
execute in minecraft:overworld run fill 282 66 12 282 67 12 dirt
execute in minecraft:overworld run setblock 282 68 12 coarse_dirt
execute in minecraft:overworld run fill 282 69 12 282 144 12 air
execute in minecraft:overworld run fill 282 58 13 282 65 13 stone
execute in minecraft:overworld run fill 282 66 13 282 67 13 dirt
execute in minecraft:overworld run setblock 282 68 13 grass_block
execute in minecraft:overworld run fill 282 69 13 282 144 13 air
execute in minecraft:overworld run fill 282 58 14 282 65 14 stone
execute in minecraft:overworld run fill 282 66 14 282 67 14 dirt
execute in minecraft:overworld run setblock 282 68 14 coarse_dirt
execute in minecraft:overworld run fill 282 69 14 282 144 14 air
execute in minecraft:overworld run fill 282 58 15 282 65 15 stone
execute in minecraft:overworld run fill 282 66 15 282 67 15 dirt
execute in minecraft:overworld run setblock 282 68 15 coarse_dirt
execute in minecraft:overworld run fill 282 69 15 282 144 15 air
execute in minecraft:overworld run fill 282 58 16 282 65 16 stone
execute in minecraft:overworld run fill 282 66 16 282 67 16 dirt
execute in minecraft:overworld run setblock 282 68 16 coarse_dirt
execute in minecraft:overworld run fill 282 69 16 282 144 16 air
execute in minecraft:overworld run fill 282 58 17 282 65 17 stone
execute in minecraft:overworld run fill 282 66 17 282 67 17 dirt
execute in minecraft:overworld run setblock 282 68 17 grass_block
execute in minecraft:overworld run fill 282 69 17 282 144 17 air
execute in minecraft:overworld run fill 282 58 18 282 64 18 stone
execute in minecraft:overworld run fill 282 65 18 282 66 18 dirt
execute in minecraft:overworld run setblock 282 67 18 coarse_dirt
execute in minecraft:overworld run fill 282 68 18 282 144 18 air
execute in minecraft:overworld run fill 282 58 19 282 64 19 stone
execute in minecraft:overworld run fill 282 65 19 282 66 19 dirt
execute in minecraft:overworld run setblock 282 67 19 coarse_dirt
execute in minecraft:overworld run fill 282 68 19 282 144 19 air
execute in minecraft:overworld run setblock 282 68 19 grass
execute in minecraft:overworld run fill 282 58 20 282 64 20 stone
execute in minecraft:overworld run fill 282 65 20 282 66 20 dirt
execute in minecraft:overworld run setblock 282 67 20 grass_block
execute in minecraft:overworld run fill 282 68 20 282 144 20 air
execute in minecraft:overworld run fill 282 58 21 282 64 21 stone
execute in minecraft:overworld run fill 282 65 21 282 66 21 dirt
execute in minecraft:overworld run setblock 282 67 21 coarse_dirt
execute in minecraft:overworld run fill 282 68 21 282 144 21 air
execute in minecraft:overworld run fill 282 58 22 282 64 22 stone
execute in minecraft:overworld run fill 282 65 22 282 66 22 dirt
execute in minecraft:overworld run setblock 282 67 22 coarse_dirt
execute in minecraft:overworld run fill 282 68 22 282 144 22 air
execute in minecraft:overworld run fill 282 58 23 282 64 23 stone
execute in minecraft:overworld run fill 282 65 23 282 66 23 dirt
execute in minecraft:overworld run setblock 282 67 23 grass_block
execute in minecraft:overworld run fill 282 68 23 282 144 23 air
execute in minecraft:overworld run setblock 282 68 23 grass
execute in minecraft:overworld run fill 282 58 24 282 63 24 stone
execute in minecraft:overworld run fill 282 64 24 282 65 24 dirt
execute in minecraft:overworld run setblock 282 66 24 grass_block
execute in minecraft:overworld run fill 282 67 24 282 144 24 air
execute in minecraft:overworld run fill 282 58 25 282 63 25 stone
execute in minecraft:overworld run fill 282 64 25 282 65 25 dirt
execute in minecraft:overworld run setblock 282 66 25 grass_block
execute in minecraft:overworld run fill 282 67 25 282 144 25 air
execute in minecraft:overworld run fill 282 58 26 282 63 26 stone
execute in minecraft:overworld run fill 282 64 26 282 65 26 dirt
execute in minecraft:overworld run setblock 282 66 26 grass_block
execute in minecraft:overworld run fill 282 67 26 282 144 26 air
execute in minecraft:overworld run fill 282 58 27 282 63 27 stone
execute in minecraft:overworld run fill 282 64 27 282 65 27 dirt
execute in minecraft:overworld run setblock 282 66 27 coarse_dirt
execute in minecraft:overworld run fill 282 67 27 282 144 27 air
execute in minecraft:overworld run fill 282 58 28 282 63 28 stone
execute in minecraft:overworld run fill 282 64 28 282 65 28 dirt
execute in minecraft:overworld run setblock 282 66 28 coarse_dirt
execute in minecraft:overworld run fill 282 67 28 282 144 28 air
execute in minecraft:overworld run fill 282 58 29 282 63 29 stone
execute in minecraft:overworld run fill 282 64 29 282 65 29 dirt
execute in minecraft:overworld run setblock 282 66 29 grass_block
execute in minecraft:overworld run fill 282 67 29 282 144 29 air
execute in minecraft:overworld run fill 282 58 30 282 63 30 stone
execute in minecraft:overworld run fill 282 64 30 282 65 30 dirt
execute in minecraft:overworld run setblock 282 66 30 coarse_dirt
execute in minecraft:overworld run fill 282 67 30 282 144 30 air
execute in minecraft:overworld run fill 282 58 31 282 63 31 stone
execute in minecraft:overworld run fill 282 64 31 282 65 31 dirt
execute in minecraft:overworld run setblock 282 66 31 coarse_dirt
execute in minecraft:overworld run fill 282 67 31 282 144 31 air
execute in minecraft:overworld run fill 282 58 32 282 62 32 stone
execute in minecraft:overworld run fill 282 63 32 282 64 32 dirt
execute in minecraft:overworld run setblock 282 65 32 grass_block
execute in minecraft:overworld run fill 282 66 32 282 144 32 air
execute in minecraft:overworld run fill 282 58 33 282 62 33 stone
execute in minecraft:overworld run fill 282 63 33 282 64 33 dirt
execute in minecraft:overworld run setblock 282 65 33 grass_block
execute in minecraft:overworld run fill 282 66 33 282 144 33 air
execute in minecraft:overworld run fill 282 58 34 282 62 34 stone
execute in minecraft:overworld run fill 282 63 34 282 64 34 dirt
execute in minecraft:overworld run setblock 282 65 34 grass_block
execute in minecraft:overworld run fill 282 66 34 282 144 34 air
execute in minecraft:overworld run fill 282 58 35 282 61 35 stone
execute in minecraft:overworld run fill 282 62 35 282 63 35 dirt
execute in minecraft:overworld run setblock 282 64 35 coarse_dirt
execute in minecraft:overworld run fill 282 65 35 282 144 35 air
execute in minecraft:overworld run fill 282 58 36 282 61 36 stone
execute in minecraft:overworld run fill 282 62 36 282 63 36 dirt
execute in minecraft:overworld run setblock 282 64 36 grass_block
execute in minecraft:overworld run fill 282 65 36 282 144 36 air
execute in minecraft:overworld run fill 282 58 37 282 61 37 stone
execute in minecraft:overworld run fill 282 62 37 282 63 37 dirt
execute in minecraft:overworld run setblock 282 64 37 grass_block
execute in minecraft:overworld run fill 282 65 37 282 144 37 air
execute in minecraft:overworld run fill 282 58 38 282 61 38 stone
execute in minecraft:overworld run fill 282 62 38 282 63 38 dirt
execute in minecraft:overworld run setblock 282 64 38 grass_block
execute in minecraft:overworld run fill 282 65 38 282 144 38 air
execute in minecraft:overworld run fill 282 58 39 282 61 39 stone
execute in minecraft:overworld run fill 282 62 39 282 63 39 dirt
execute in minecraft:overworld run setblock 282 64 39 grass_block
execute in minecraft:overworld run fill 282 65 39 282 144 39 air
execute in minecraft:overworld run fill 282 58 40 282 61 40 stone
execute in minecraft:overworld run fill 282 62 40 282 63 40 dirt
execute in minecraft:overworld run setblock 282 64 40 coarse_dirt
execute in minecraft:overworld run fill 282 65 40 282 144 40 air
execute in minecraft:overworld run fill 282 58 41 282 62 41 stone
execute in minecraft:overworld run fill 282 63 41 282 64 41 dirt
execute in minecraft:overworld run setblock 282 65 41 coarse_dirt
execute in minecraft:overworld run fill 282 66 41 282 144 41 air
execute in minecraft:overworld run fill 282 58 42 282 62 42 stone
execute in minecraft:overworld run fill 282 63 42 282 64 42 dirt
execute in minecraft:overworld run setblock 282 65 42 grass_block
execute in minecraft:overworld run fill 282 66 42 282 144 42 air
execute in minecraft:overworld run fill 282 58 43 282 62 43 stone
execute in minecraft:overworld run fill 282 63 43 282 64 43 dirt
execute in minecraft:overworld run setblock 282 65 43 coarse_dirt
execute in minecraft:overworld run fill 282 66 43 282 144 43 air
execute in minecraft:overworld run fill 282 58 44 282 61 44 stone
execute in minecraft:overworld run fill 282 62 44 282 63 44 dirt
execute in minecraft:overworld run setblock 282 64 44 grass_block
execute in minecraft:overworld run fill 282 65 44 282 144 44 air
execute in minecraft:overworld run fill 282 58 45 282 61 45 stone
execute in minecraft:overworld run fill 282 62 45 282 63 45 dirt
execute in minecraft:overworld run setblock 282 64 45 coarse_dirt
execute in minecraft:overworld run fill 282 65 45 282 144 45 air
execute in minecraft:overworld run fill 282 58 46 282 61 46 stone
execute in minecraft:overworld run fill 282 62 46 282 63 46 dirt
execute in minecraft:overworld run setblock 282 64 46 coarse_dirt
execute in minecraft:overworld run fill 282 65 46 282 144 46 air
execute in minecraft:overworld run fill 282 58 47 282 61 47 stone
execute in minecraft:overworld run fill 282 62 47 282 63 47 dirt
execute in minecraft:overworld run setblock 282 64 47 coarse_dirt
execute in minecraft:overworld run fill 282 65 47 282 144 47 air
execute in minecraft:overworld run fill 283 58 -48 283 61 -48 stone
execute in minecraft:overworld run fill 283 62 -48 283 63 -48 dirt
execute in minecraft:overworld run setblock 283 64 -48 coarse_dirt
execute in minecraft:overworld run fill 283 65 -48 283 144 -48 air
execute in minecraft:overworld run fill 283 58 -47 283 63 -47 stone
execute in minecraft:overworld run fill 283 64 -47 283 65 -47 dirt
execute in minecraft:overworld run setblock 283 66 -47 coarse_dirt
execute in minecraft:overworld run fill 283 67 -47 283 144 -47 air
execute in minecraft:overworld run fill 283 58 -46 283 65 -46 stone
execute in minecraft:overworld run fill 283 66 -46 283 67 -46 dirt
execute in minecraft:overworld run setblock 283 68 -46 coarse_dirt
execute in minecraft:overworld run fill 283 69 -46 283 144 -46 air
execute in minecraft:overworld run fill 283 58 -45 283 67 -45 stone
execute in minecraft:overworld run fill 283 68 -45 283 69 -45 dirt
execute in minecraft:overworld run setblock 283 70 -45 grass_block
execute in minecraft:overworld run fill 283 71 -45 283 144 -45 air
execute in minecraft:overworld run fill 283 58 -44 283 69 -44 stone
execute in minecraft:overworld run fill 283 70 -44 283 71 -44 dirt
execute in minecraft:overworld run setblock 283 72 -44 coarse_dirt
execute in minecraft:overworld run fill 283 73 -44 283 144 -44 air
execute in minecraft:overworld run fill 283 58 -43 283 71 -43 stone
execute in minecraft:overworld run fill 283 72 -43 283 73 -43 dirt
execute in minecraft:overworld run setblock 283 74 -43 grass_block
execute in minecraft:overworld run fill 283 75 -43 283 144 -43 air
execute in minecraft:overworld run fill 283 58 -42 283 73 -42 stone
execute in minecraft:overworld run fill 283 74 -42 283 75 -42 dirt
execute in minecraft:overworld run setblock 283 76 -42 coarse_dirt
execute in minecraft:overworld run fill 283 77 -42 283 144 -42 air
execute in minecraft:overworld run fill 283 58 -41 283 75 -41 stone
execute in minecraft:overworld run fill 283 76 -41 283 77 -41 dirt
execute in minecraft:overworld run setblock 283 78 -41 grass_block
execute in minecraft:overworld run fill 283 79 -41 283 144 -41 air
execute in minecraft:overworld run fill 283 58 -40 283 76 -40 stone
execute in minecraft:overworld run fill 283 77 -40 283 78 -40 dirt
execute in minecraft:overworld run setblock 283 79 -40 coarse_dirt
execute in minecraft:overworld run fill 283 80 -40 283 144 -40 air
execute in minecraft:overworld run fill 283 58 -39 283 78 -39 stone
execute in minecraft:overworld run fill 283 79 -39 283 80 -39 dirt
execute in minecraft:overworld run setblock 283 81 -39 coarse_dirt
execute in minecraft:overworld run fill 283 82 -39 283 144 -39 air
execute in minecraft:overworld run setblock 283 82 -39 grass
execute in minecraft:overworld run fill 283 58 -38 283 79 -38 stone
execute in minecraft:overworld run fill 283 80 -38 283 81 -38 dirt
execute in minecraft:overworld run setblock 283 82 -38 coarse_dirt
execute in minecraft:overworld run fill 283 83 -38 283 144 -38 air
execute in minecraft:overworld run fill 283 58 -37 283 79 -37 stone
execute in minecraft:overworld run fill 283 80 -37 283 81 -37 dirt
execute in minecraft:overworld run setblock 283 82 -37 coarse_dirt
execute in minecraft:overworld run fill 283 83 -37 283 144 -37 air
execute in minecraft:overworld run fill 283 58 -36 283 78 -36 stone
execute in minecraft:overworld run fill 283 79 -36 283 80 -36 dirt
execute in minecraft:overworld run setblock 283 81 -36 coarse_dirt
execute in minecraft:overworld run fill 283 82 -36 283 144 -36 air
execute in minecraft:overworld run fill 283 58 -35 283 78 -35 stone
execute in minecraft:overworld run fill 283 79 -35 283 80 -35 dirt
execute in minecraft:overworld run setblock 283 81 -35 coarse_dirt
execute in minecraft:overworld run fill 283 82 -35 283 144 -35 air
execute in minecraft:overworld run fill 283 58 -34 283 78 -34 stone
execute in minecraft:overworld run fill 283 79 -34 283 80 -34 dirt
execute in minecraft:overworld run setblock 283 81 -34 coarse_dirt
execute in minecraft:overworld run fill 283 82 -34 283 144 -34 air
execute in minecraft:overworld run fill 283 58 -33 283 77 -33 stone
execute in minecraft:overworld run fill 283 78 -33 283 79 -33 dirt
execute in minecraft:overworld run setblock 283 80 -33 coarse_dirt
execute in minecraft:overworld run fill 283 81 -33 283 144 -33 air
execute in minecraft:overworld run fill 283 58 -32 283 77 -32 stone
execute in minecraft:overworld run fill 283 78 -32 283 79 -32 dirt
execute in minecraft:overworld run setblock 283 80 -32 coarse_dirt
execute in minecraft:overworld run fill 283 81 -32 283 144 -32 air
execute in minecraft:overworld run fill 283 58 -31 283 76 -31 stone
schedule function blade_gallery:random/burned/part_119 1t replace
