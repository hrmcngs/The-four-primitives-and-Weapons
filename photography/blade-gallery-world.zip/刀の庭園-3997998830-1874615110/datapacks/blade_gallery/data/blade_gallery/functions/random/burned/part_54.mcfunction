execute in minecraft:overworld run fill 243 72 -28 243 73 -28 dirt
execute in minecraft:overworld run setblock 243 74 -28 coarse_dirt
execute in minecraft:overworld run fill 243 75 -28 243 144 -28 air
execute in minecraft:overworld run fill 243 58 -27 243 71 -27 stone
execute in minecraft:overworld run fill 243 72 -27 243 73 -27 dirt
execute in minecraft:overworld run setblock 243 74 -27 grass_block
execute in minecraft:overworld run fill 243 75 -27 243 144 -27 air
execute in minecraft:overworld run fill 243 58 -26 243 71 -26 stone
execute in minecraft:overworld run fill 243 72 -26 243 73 -26 dirt
execute in minecraft:overworld run setblock 243 74 -26 coarse_dirt
execute in minecraft:overworld run fill 243 75 -26 243 144 -26 air
execute in minecraft:overworld run fill 243 58 -25 243 70 -25 stone
execute in minecraft:overworld run fill 243 71 -25 243 72 -25 dirt
execute in minecraft:overworld run setblock 243 73 -25 coarse_dirt
execute in minecraft:overworld run fill 243 74 -25 243 144 -25 air
execute in minecraft:overworld run fill 243 58 -24 243 70 -24 stone
execute in minecraft:overworld run fill 243 71 -24 243 72 -24 dirt
execute in minecraft:overworld run setblock 243 73 -24 coarse_dirt
execute in minecraft:overworld run fill 243 74 -24 243 144 -24 air
execute in minecraft:overworld run fill 243 58 -23 243 70 -23 stone
execute in minecraft:overworld run fill 243 71 -23 243 72 -23 dirt
execute in minecraft:overworld run setblock 243 73 -23 coarse_dirt
execute in minecraft:overworld run fill 243 74 -23 243 144 -23 air
execute in minecraft:overworld run fill 243 58 -22 243 69 -22 stone
execute in minecraft:overworld run fill 243 70 -22 243 71 -22 dirt
execute in minecraft:overworld run setblock 243 72 -22 coarse_dirt
execute in minecraft:overworld run fill 243 73 -22 243 144 -22 air
execute in minecraft:overworld run fill 243 58 -21 243 69 -21 stone
execute in minecraft:overworld run fill 243 70 -21 243 71 -21 dirt
execute in minecraft:overworld run setblock 243 72 -21 coarse_dirt
execute in minecraft:overworld run fill 243 73 -21 243 144 -21 air
execute in minecraft:overworld run fill 243 58 -20 243 68 -20 stone
execute in minecraft:overworld run fill 243 69 -20 243 70 -20 dirt
execute in minecraft:overworld run setblock 243 71 -20 grass_block
execute in minecraft:overworld run fill 243 72 -20 243 144 -20 air
execute in minecraft:overworld run fill 243 58 -19 243 68 -19 stone
execute in minecraft:overworld run fill 243 69 -19 243 70 -19 dirt
execute in minecraft:overworld run setblock 243 71 -19 grass_block
execute in minecraft:overworld run fill 243 72 -19 243 144 -19 air
execute in minecraft:overworld run fill 243 58 -18 243 67 -18 stone
execute in minecraft:overworld run fill 243 68 -18 243 69 -18 dirt
execute in minecraft:overworld run setblock 243 70 -18 coarse_dirt
execute in minecraft:overworld run fill 243 71 -18 243 144 -18 air
execute in minecraft:overworld run fill 243 58 -17 243 67 -17 stone
execute in minecraft:overworld run fill 243 68 -17 243 69 -17 dirt
execute in minecraft:overworld run setblock 243 70 -17 coarse_dirt
execute in minecraft:overworld run fill 243 71 -17 243 144 -17 air
execute in minecraft:overworld run fill 243 58 -16 243 66 -16 stone
execute in minecraft:overworld run fill 243 67 -16 243 68 -16 dirt
execute in minecraft:overworld run setblock 243 69 -16 coarse_dirt
execute in minecraft:overworld run fill 243 70 -16 243 144 -16 air
execute in minecraft:overworld run fill 243 58 -15 243 66 -15 stone
execute in minecraft:overworld run fill 243 67 -15 243 68 -15 dirt
execute in minecraft:overworld run setblock 243 69 -15 grass_block
execute in minecraft:overworld run fill 243 70 -15 243 144 -15 air
execute in minecraft:overworld run fill 243 58 -14 243 65 -14 stone
execute in minecraft:overworld run fill 243 66 -14 243 67 -14 dirt
execute in minecraft:overworld run setblock 243 68 -14 coarse_dirt
execute in minecraft:overworld run fill 243 69 -14 243 144 -14 air
execute in minecraft:overworld run fill 243 58 -13 243 65 -13 stone
execute in minecraft:overworld run fill 243 66 -13 243 67 -13 dirt
execute in minecraft:overworld run setblock 243 68 -13 grass_block
execute in minecraft:overworld run fill 243 69 -13 243 144 -13 air
execute in minecraft:overworld run setblock 243 69 -13 grass
execute in minecraft:overworld run fill 243 58 -12 243 64 -12 stone
execute in minecraft:overworld run fill 243 65 -12 243 66 -12 dirt
execute in minecraft:overworld run setblock 243 67 -12 coarse_dirt
execute in minecraft:overworld run fill 243 68 -12 243 144 -12 air
execute in minecraft:overworld run fill 243 58 -11 243 64 -11 stone
execute in minecraft:overworld run fill 243 65 -11 243 66 -11 dirt
execute in minecraft:overworld run setblock 243 67 -11 coarse_dirt
execute in minecraft:overworld run fill 243 68 -11 243 144 -11 air
execute in minecraft:overworld run setblock 243 68 -11 mossy_cobblestone
execute in minecraft:overworld run fill 243 58 -10 243 64 -10 stone
execute in minecraft:overworld run fill 243 65 -10 243 66 -10 dirt
execute in minecraft:overworld run setblock 243 67 -10 coarse_dirt
execute in minecraft:overworld run fill 243 68 -10 243 144 -10 air
execute in minecraft:overworld run fill 243 58 -9 243 64 -9 stone
execute in minecraft:overworld run fill 243 65 -9 243 66 -9 dirt
execute in minecraft:overworld run setblock 243 67 -9 coarse_dirt
execute in minecraft:overworld run fill 243 68 -9 243 144 -9 air
execute in minecraft:overworld run setblock 243 68 -9 grass
execute in minecraft:overworld run fill 243 58 -8 243 64 -8 stone
execute in minecraft:overworld run fill 243 65 -8 243 66 -8 dirt
execute in minecraft:overworld run setblock 243 67 -8 coarse_dirt
execute in minecraft:overworld run fill 243 68 -8 243 144 -8 air
execute in minecraft:overworld run fill 243 58 -7 243 63 -7 stone
execute in minecraft:overworld run fill 243 64 -7 243 65 -7 dirt
execute in minecraft:overworld run setblock 243 66 -7 coarse_dirt
execute in minecraft:overworld run fill 243 67 -7 243 144 -7 air
execute in minecraft:overworld run setblock 243 67 -7 grass
execute in minecraft:overworld run fill 243 58 -6 243 63 -6 stone
execute in minecraft:overworld run fill 243 64 -6 243 65 -6 dirt
execute in minecraft:overworld run setblock 243 66 -6 coarse_dirt
execute in minecraft:overworld run fill 243 67 -6 243 144 -6 air
execute in minecraft:overworld run fill 243 58 -5 243 63 -5 stone
execute in minecraft:overworld run fill 243 64 -5 243 65 -5 dirt
execute in minecraft:overworld run setblock 243 66 -5 coarse_dirt
execute in minecraft:overworld run fill 243 67 -5 243 144 -5 air
execute in minecraft:overworld run fill 243 58 -4 243 62 -4 stone
execute in minecraft:overworld run fill 243 63 -4 243 64 -4 dirt
execute in minecraft:overworld run setblock 243 65 -4 grass_block
execute in minecraft:overworld run fill 243 66 -4 243 144 -4 air
execute in minecraft:overworld run fill 243 58 -3 243 62 -3 stone
execute in minecraft:overworld run fill 243 63 -3 243 64 -3 dirt
execute in minecraft:overworld run setblock 243 65 -3 coarse_dirt
execute in minecraft:overworld run fill 243 66 -3 243 144 -3 air
execute in minecraft:overworld run fill 243 58 -2 243 62 -2 stone
execute in minecraft:overworld run fill 243 63 -2 243 64 -2 dirt
execute in minecraft:overworld run setblock 243 65 -2 coarse_dirt
execute in minecraft:overworld run fill 243 66 -2 243 144 -2 air
execute in minecraft:overworld run fill 243 58 -1 243 62 -1 stone
execute in minecraft:overworld run fill 243 63 -1 243 64 -1 dirt
execute in minecraft:overworld run setblock 243 65 -1 coarse_dirt
execute in minecraft:overworld run fill 243 66 -1 243 144 -1 air
execute in minecraft:overworld run fill 243 58 0 243 62 0 stone
execute in minecraft:overworld run fill 243 63 0 243 64 0 dirt
execute in minecraft:overworld run setblock 243 65 0 coarse_dirt
execute in minecraft:overworld run fill 243 66 0 243 144 0 air
execute in minecraft:overworld run fill 243 58 1 243 62 1 stone
execute in minecraft:overworld run fill 243 63 1 243 64 1 dirt
execute in minecraft:overworld run setblock 243 65 1 grass_block
execute in minecraft:overworld run fill 243 66 1 243 144 1 air
execute in minecraft:overworld run fill 243 58 2 243 62 2 stone
execute in minecraft:overworld run fill 243 63 2 243 64 2 dirt
execute in minecraft:overworld run setblock 243 65 2 coarse_dirt
execute in minecraft:overworld run fill 243 66 2 243 144 2 air
execute in minecraft:overworld run fill 243 58 3 243 62 3 stone
execute in minecraft:overworld run fill 243 63 3 243 64 3 dirt
execute in minecraft:overworld run setblock 243 65 3 coarse_dirt
execute in minecraft:overworld run fill 243 66 3 243 144 3 air
execute in minecraft:overworld run fill 243 58 4 243 63 4 stone
execute in minecraft:overworld run fill 243 64 4 243 65 4 dirt
execute in minecraft:overworld run setblock 243 66 4 grass_block
execute in minecraft:overworld run fill 243 67 4 243 144 4 air
execute in minecraft:overworld run fill 243 58 5 243 63 5 stone
execute in minecraft:overworld run fill 243 64 5 243 65 5 dirt
execute in minecraft:overworld run setblock 243 66 5 grass_block
execute in minecraft:overworld run fill 243 67 5 243 144 5 air
execute in minecraft:overworld run fill 243 58 6 243 64 6 stone
execute in minecraft:overworld run fill 243 65 6 243 66 6 dirt
execute in minecraft:overworld run setblock 243 67 6 grass_block
execute in minecraft:overworld run fill 243 68 6 243 144 6 air
execute in minecraft:overworld run fill 243 58 7 243 64 7 stone
execute in minecraft:overworld run fill 243 65 7 243 66 7 dirt
execute in minecraft:overworld run setblock 243 67 7 coarse_dirt
execute in minecraft:overworld run fill 243 68 7 243 144 7 air
execute in minecraft:overworld run fill 243 58 8 243 64 8 stone
execute in minecraft:overworld run fill 243 65 8 243 66 8 dirt
execute in minecraft:overworld run setblock 243 67 8 coarse_dirt
execute in minecraft:overworld run fill 243 68 8 243 144 8 air
execute in minecraft:overworld run fill 243 58 9 243 65 9 stone
execute in minecraft:overworld run fill 243 66 9 243 67 9 dirt
execute in minecraft:overworld run setblock 243 68 9 coarse_dirt
execute in minecraft:overworld run fill 243 69 9 243 144 9 air
execute in minecraft:overworld run fill 243 58 10 243 65 10 stone
execute in minecraft:overworld run fill 243 66 10 243 67 10 dirt
execute in minecraft:overworld run setblock 243 68 10 grass_block
execute in minecraft:overworld run fill 243 69 10 243 144 10 air
execute in minecraft:overworld run fill 243 58 11 243 65 11 stone
execute in minecraft:overworld run fill 243 66 11 243 67 11 dirt
execute in minecraft:overworld run setblock 243 68 11 coarse_dirt
execute in minecraft:overworld run fill 243 69 11 243 144 11 air
execute in minecraft:overworld run fill 243 58 12 243 65 12 stone
execute in minecraft:overworld run fill 243 66 12 243 67 12 dirt
execute in minecraft:overworld run setblock 243 68 12 coarse_dirt
execute in minecraft:overworld run fill 243 69 12 243 144 12 air
execute in minecraft:overworld run fill 243 58 13 243 65 13 stone
execute in minecraft:overworld run fill 243 66 13 243 67 13 dirt
execute in minecraft:overworld run setblock 243 68 13 coarse_dirt
execute in minecraft:overworld run fill 243 69 13 243 144 13 air
execute in minecraft:overworld run fill 243 58 14 243 65 14 stone
execute in minecraft:overworld run fill 243 66 14 243 67 14 dirt
execute in minecraft:overworld run setblock 243 68 14 grass_block
execute in minecraft:overworld run fill 243 69 14 243 144 14 air
execute in minecraft:overworld run setblock 243 69 14 grass
execute in minecraft:overworld run fill 243 58 15 243 65 15 stone
execute in minecraft:overworld run fill 243 66 15 243 67 15 dirt
execute in minecraft:overworld run setblock 243 68 15 coarse_dirt
execute in minecraft:overworld run fill 243 69 15 243 144 15 air
execute in minecraft:overworld run fill 243 58 16 243 65 16 stone
execute in minecraft:overworld run fill 243 66 16 243 67 16 dirt
execute in minecraft:overworld run setblock 243 68 16 coarse_dirt
execute in minecraft:overworld run fill 243 69 16 243 144 16 air
execute in minecraft:overworld run fill 243 58 17 243 66 17 stone
execute in minecraft:overworld run fill 243 67 17 243 68 17 dirt
execute in minecraft:overworld run setblock 243 69 17 grass_block
execute in minecraft:overworld run fill 243 70 17 243 144 17 air
execute in minecraft:overworld run fill 243 58 18 243 66 18 stone
execute in minecraft:overworld run fill 243 67 18 243 68 18 dirt
execute in minecraft:overworld run setblock 243 69 18 coarse_dirt
execute in minecraft:overworld run fill 243 70 18 243 144 18 air
execute in minecraft:overworld run fill 243 58 19 243 66 19 stone
execute in minecraft:overworld run fill 243 67 19 243 68 19 dirt
execute in minecraft:overworld run setblock 243 69 19 grass_block
execute in minecraft:overworld run fill 243 70 19 243 144 19 air
execute in minecraft:overworld run fill 243 58 20 243 66 20 stone
execute in minecraft:overworld run fill 243 67 20 243 68 20 dirt
execute in minecraft:overworld run setblock 243 69 20 coarse_dirt
execute in minecraft:overworld run fill 243 70 20 243 144 20 air
execute in minecraft:overworld run fill 243 58 21 243 66 21 stone
execute in minecraft:overworld run fill 243 67 21 243 68 21 dirt
execute in minecraft:overworld run setblock 243 69 21 coarse_dirt
execute in minecraft:overworld run fill 243 70 21 243 144 21 air
execute in minecraft:overworld run fill 243 58 22 243 66 22 stone
execute in minecraft:overworld run fill 243 67 22 243 68 22 dirt
execute in minecraft:overworld run setblock 243 69 22 coarse_dirt
execute in minecraft:overworld run fill 243 70 22 243 144 22 air
execute in minecraft:overworld run fill 243 58 23 243 66 23 stone
execute in minecraft:overworld run fill 243 67 23 243 68 23 dirt
execute in minecraft:overworld run setblock 243 69 23 grass_block
execute in minecraft:overworld run fill 243 70 23 243 144 23 air
execute in minecraft:overworld run fill 243 58 24 243 66 24 stone
execute in minecraft:overworld run fill 243 67 24 243 68 24 dirt
execute in minecraft:overworld run setblock 243 69 24 coarse_dirt
execute in minecraft:overworld run fill 243 70 24 243 144 24 air
execute in minecraft:overworld run fill 243 58 25 243 66 25 stone
execute in minecraft:overworld run fill 243 67 25 243 68 25 dirt
execute in minecraft:overworld run setblock 243 69 25 grass_block
execute in minecraft:overworld run fill 243 70 25 243 144 25 air
execute in minecraft:overworld run fill 243 58 26 243 66 26 stone
execute in minecraft:overworld run fill 243 67 26 243 68 26 dirt
execute in minecraft:overworld run setblock 243 69 26 coarse_dirt
execute in minecraft:overworld run fill 243 70 26 243 144 26 air
execute in minecraft:overworld run fill 243 58 27 243 66 27 stone
execute in minecraft:overworld run fill 243 67 27 243 68 27 dirt
execute in minecraft:overworld run setblock 243 69 27 grass_block
execute in minecraft:overworld run fill 243 70 27 243 144 27 air
execute in minecraft:overworld run fill 243 58 28 243 66 28 stone
execute in minecraft:overworld run fill 243 67 28 243 68 28 dirt
execute in minecraft:overworld run setblock 243 69 28 coarse_dirt
execute in minecraft:overworld run fill 243 70 28 243 144 28 air
execute in minecraft:overworld run fill 243 58 29 243 66 29 stone
execute in minecraft:overworld run fill 243 67 29 243 68 29 dirt
execute in minecraft:overworld run setblock 243 69 29 grass_block
execute in minecraft:overworld run fill 243 70 29 243 144 29 air
execute in minecraft:overworld run fill 243 58 30 243 66 30 stone
execute in minecraft:overworld run fill 243 67 30 243 68 30 dirt
execute in minecraft:overworld run setblock 243 69 30 coarse_dirt
execute in minecraft:overworld run fill 243 70 30 243 144 30 air
execute in minecraft:overworld run fill 243 58 31 243 66 31 stone
execute in minecraft:overworld run fill 243 67 31 243 68 31 dirt
execute in minecraft:overworld run setblock 243 69 31 coarse_dirt
execute in minecraft:overworld run fill 243 70 31 243 144 31 air
execute in minecraft:overworld run setblock 243 70 31 grass
execute in minecraft:overworld run fill 243 58 32 243 65 32 stone
execute in minecraft:overworld run fill 243 66 32 243 67 32 dirt
execute in minecraft:overworld run setblock 243 68 32 coarse_dirt
execute in minecraft:overworld run fill 243 69 32 243 144 32 air
execute in minecraft:overworld run fill 243 58 33 243 65 33 stone
execute in minecraft:overworld run fill 243 66 33 243 67 33 dirt
execute in minecraft:overworld run setblock 243 68 33 coarse_dirt
execute in minecraft:overworld run fill 243 69 33 243 144 33 air
execute in minecraft:overworld run setblock 243 69 33 grass
execute in minecraft:overworld run fill 243 58 34 243 65 34 stone
execute in minecraft:overworld run fill 243 66 34 243 67 34 dirt
schedule function blade_gallery:random/burned/part_55 1t replace
