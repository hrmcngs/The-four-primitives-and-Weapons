execute in minecraft:overworld run fill 386 58 -45 386 65 -45 stone
execute in minecraft:overworld run fill 386 66 -45 386 67 -45 dirt
execute in minecraft:overworld run setblock 386 68 -45 coarse_dirt
execute in minecraft:overworld run fill 386 69 -45 386 144 -45 air
execute in minecraft:overworld run fill 386 58 -44 386 67 -44 stone
execute in minecraft:overworld run fill 386 68 -44 386 69 -44 dirt
execute in minecraft:overworld run setblock 386 70 -44 grass_block
execute in minecraft:overworld run fill 386 71 -44 386 144 -44 air
execute in minecraft:overworld run fill 386 58 -43 386 68 -43 stone
execute in minecraft:overworld run fill 386 69 -43 386 70 -43 dirt
execute in minecraft:overworld run setblock 386 71 -43 coarse_dirt
execute in minecraft:overworld run fill 386 72 -43 386 144 -43 air
execute in minecraft:overworld run fill 386 58 -42 386 69 -42 stone
execute in minecraft:overworld run fill 386 70 -42 386 71 -42 dirt
execute in minecraft:overworld run setblock 386 72 -42 grass_block
execute in minecraft:overworld run fill 386 73 -42 386 144 -42 air
execute in minecraft:overworld run fill 386 58 -41 386 70 -41 stone
execute in minecraft:overworld run fill 386 71 -41 386 72 -41 dirt
execute in minecraft:overworld run setblock 386 73 -41 grass_block
execute in minecraft:overworld run fill 386 74 -41 386 144 -41 air
execute in minecraft:overworld run fill 386 58 -40 386 71 -40 stone
execute in minecraft:overworld run fill 386 72 -40 386 73 -40 dirt
execute in minecraft:overworld run setblock 386 74 -40 coarse_dirt
execute in minecraft:overworld run fill 386 75 -40 386 144 -40 air
execute in minecraft:overworld run fill 386 58 -39 386 72 -39 stone
execute in minecraft:overworld run fill 386 73 -39 386 74 -39 dirt
execute in minecraft:overworld run setblock 386 75 -39 coarse_dirt
execute in minecraft:overworld run fill 386 76 -39 386 144 -39 air
execute in minecraft:overworld run fill 386 58 -38 386 72 -38 stone
execute in minecraft:overworld run fill 386 73 -38 386 74 -38 dirt
execute in minecraft:overworld run setblock 386 75 -38 coarse_dirt
execute in minecraft:overworld run fill 386 76 -38 386 144 -38 air
execute in minecraft:overworld run fill 386 58 -37 386 72 -37 stone
execute in minecraft:overworld run fill 386 73 -37 386 74 -37 dirt
execute in minecraft:overworld run setblock 386 75 -37 coarse_dirt
execute in minecraft:overworld run fill 386 76 -37 386 144 -37 air
execute in minecraft:overworld run setblock 386 76 -37 grass
execute in minecraft:overworld run fill 386 58 -36 386 71 -36 stone
execute in minecraft:overworld run fill 386 72 -36 386 73 -36 dirt
execute in minecraft:overworld run setblock 386 74 -36 coarse_dirt
execute in minecraft:overworld run fill 386 75 -36 386 144 -36 air
execute in minecraft:overworld run fill 386 58 -35 386 71 -35 stone
execute in minecraft:overworld run fill 386 72 -35 386 73 -35 dirt
execute in minecraft:overworld run setblock 386 74 -35 coarse_dirt
execute in minecraft:overworld run fill 386 75 -35 386 144 -35 air
execute in minecraft:overworld run setblock 386 75 -35 mossy_cobblestone
execute in minecraft:overworld run fill 386 58 -34 386 70 -34 stone
execute in minecraft:overworld run fill 386 71 -34 386 72 -34 dirt
execute in minecraft:overworld run setblock 386 73 -34 coarse_dirt
execute in minecraft:overworld run fill 386 74 -34 386 144 -34 air
execute in minecraft:overworld run fill 386 58 -33 386 70 -33 stone
execute in minecraft:overworld run fill 386 71 -33 386 72 -33 dirt
execute in minecraft:overworld run setblock 386 73 -33 grass_block
execute in minecraft:overworld run fill 386 74 -33 386 144 -33 air
execute in minecraft:overworld run fill 386 58 -32 386 70 -32 stone
execute in minecraft:overworld run fill 386 71 -32 386 72 -32 dirt
execute in minecraft:overworld run setblock 386 73 -32 grass_block
execute in minecraft:overworld run fill 386 74 -32 386 144 -32 air
execute in minecraft:overworld run fill 386 58 -31 386 69 -31 stone
execute in minecraft:overworld run fill 386 70 -31 386 71 -31 dirt
execute in minecraft:overworld run setblock 386 72 -31 coarse_dirt
execute in minecraft:overworld run fill 386 73 -31 386 144 -31 air
execute in minecraft:overworld run fill 386 58 -30 386 69 -30 stone
execute in minecraft:overworld run fill 386 70 -30 386 71 -30 dirt
execute in minecraft:overworld run setblock 386 72 -30 coarse_dirt
execute in minecraft:overworld run fill 386 73 -30 386 144 -30 air
execute in minecraft:overworld run fill 386 58 -29 386 68 -29 stone
execute in minecraft:overworld run fill 386 69 -29 386 70 -29 dirt
execute in minecraft:overworld run setblock 386 71 -29 coarse_dirt
execute in minecraft:overworld run fill 386 72 -29 386 144 -29 air
execute in minecraft:overworld run fill 386 58 -28 386 67 -28 stone
execute in minecraft:overworld run fill 386 68 -28 386 69 -28 dirt
execute in minecraft:overworld run setblock 386 70 -28 coarse_dirt
execute in minecraft:overworld run fill 386 71 -28 386 144 -28 air
execute in minecraft:overworld run fill 386 58 -27 386 66 -27 stone
execute in minecraft:overworld run fill 386 67 -27 386 68 -27 dirt
execute in minecraft:overworld run setblock 386 69 -27 coarse_dirt
execute in minecraft:overworld run fill 386 70 -27 386 144 -27 air
execute in minecraft:overworld run fill 386 58 -26 386 66 -26 stone
execute in minecraft:overworld run fill 386 67 -26 386 68 -26 dirt
execute in minecraft:overworld run setblock 386 69 -26 coarse_dirt
execute in minecraft:overworld run fill 386 70 -26 386 144 -26 air
execute in minecraft:overworld run fill 386 58 -25 386 65 -25 stone
execute in minecraft:overworld run fill 386 66 -25 386 67 -25 dirt
execute in minecraft:overworld run setblock 386 68 -25 grass_block
execute in minecraft:overworld run fill 386 69 -25 386 144 -25 air
execute in minecraft:overworld run fill 386 58 -24 386 64 -24 stone
execute in minecraft:overworld run fill 386 65 -24 386 66 -24 dirt
execute in minecraft:overworld run setblock 386 67 -24 grass_block
execute in minecraft:overworld run fill 386 68 -24 386 144 -24 air
execute in minecraft:overworld run fill 386 58 -23 386 62 -23 stone
execute in minecraft:overworld run fill 386 63 -23 386 64 -23 dirt
execute in minecraft:overworld run setblock 386 65 -23 coarse_dirt
execute in minecraft:overworld run fill 386 66 -23 386 144 -23 air
execute in minecraft:overworld run fill 386 58 -22 386 61 -22 stone
execute in minecraft:overworld run fill 386 62 -22 386 63 -22 dirt
execute in minecraft:overworld run setblock 386 64 -22 coarse_dirt
execute in minecraft:overworld run fill 386 65 -22 386 144 -22 air
execute in minecraft:overworld run fill 386 58 -21 386 60 -21 stone
execute in minecraft:overworld run fill 386 61 -21 386 62 -21 dirt
execute in minecraft:overworld run setblock 386 63 -21 gravel
execute in minecraft:overworld run fill 386 64 -21 386 144 -21 air
execute in minecraft:overworld run fill 386 64 -21 386 64 -21 water
execute in minecraft:overworld run fill 386 58 -20 386 60 -20 stone
execute in minecraft:overworld run fill 386 61 -20 386 62 -20 dirt
execute in minecraft:overworld run setblock 386 63 -20 gravel
execute in minecraft:overworld run fill 386 64 -20 386 144 -20 air
execute in minecraft:overworld run fill 386 64 -20 386 64 -20 water
execute in minecraft:overworld run fill 386 58 -19 386 59 -19 stone
execute in minecraft:overworld run fill 386 60 -19 386 61 -19 dirt
execute in minecraft:overworld run setblock 386 62 -19 gravel
execute in minecraft:overworld run fill 386 63 -19 386 144 -19 air
execute in minecraft:overworld run fill 386 63 -19 386 64 -19 water
execute in minecraft:overworld run fill 386 58 -18 386 58 -18 stone
execute in minecraft:overworld run fill 386 59 -18 386 60 -18 dirt
execute in minecraft:overworld run setblock 386 61 -18 gravel
execute in minecraft:overworld run fill 386 62 -18 386 144 -18 air
execute in minecraft:overworld run fill 386 62 -18 386 64 -18 water
execute in minecraft:overworld run fill 386 58 -17 386 58 -17 stone
execute in minecraft:overworld run fill 386 59 -17 386 60 -17 dirt
execute in minecraft:overworld run setblock 386 61 -17 gravel
execute in minecraft:overworld run fill 386 62 -17 386 144 -17 air
execute in minecraft:overworld run fill 386 62 -17 386 64 -17 water
execute in minecraft:overworld run fill 386 58 -16 386 57 -16 stone
execute in minecraft:overworld run fill 386 58 -16 386 59 -16 dirt
execute in minecraft:overworld run setblock 386 60 -16 gravel
execute in minecraft:overworld run fill 386 61 -16 386 144 -16 air
execute in minecraft:overworld run fill 386 61 -16 386 64 -16 water
execute in minecraft:overworld run fill 386 58 -15 386 57 -15 stone
execute in minecraft:overworld run fill 386 58 -15 386 59 -15 dirt
execute in minecraft:overworld run setblock 386 60 -15 gravel
execute in minecraft:overworld run fill 386 61 -15 386 144 -15 air
execute in minecraft:overworld run fill 386 61 -15 386 64 -15 water
execute in minecraft:overworld run fill 386 58 -14 386 57 -14 stone
execute in minecraft:overworld run fill 386 58 -14 386 59 -14 dirt
execute in minecraft:overworld run setblock 386 60 -14 gravel
execute in minecraft:overworld run fill 386 61 -14 386 144 -14 air
execute in minecraft:overworld run fill 386 61 -14 386 64 -14 water
execute in minecraft:overworld run fill 386 58 -13 386 57 -13 stone
execute in minecraft:overworld run fill 386 58 -13 386 59 -13 dirt
execute in minecraft:overworld run setblock 386 60 -13 gravel
execute in minecraft:overworld run fill 386 61 -13 386 144 -13 air
execute in minecraft:overworld run fill 386 61 -13 386 64 -13 water
execute in minecraft:overworld run fill 386 58 -12 386 56 -12 stone
execute in minecraft:overworld run fill 386 57 -12 386 58 -12 dirt
execute in minecraft:overworld run setblock 386 59 -12 gravel
execute in minecraft:overworld run fill 386 60 -12 386 144 -12 air
execute in minecraft:overworld run fill 386 60 -12 386 64 -12 water
execute in minecraft:overworld run fill 386 58 -11 386 57 -11 stone
execute in minecraft:overworld run fill 386 58 -11 386 59 -11 dirt
execute in minecraft:overworld run setblock 386 60 -11 gravel
execute in minecraft:overworld run fill 386 61 -11 386 144 -11 air
execute in minecraft:overworld run fill 386 61 -11 386 64 -11 water
execute in minecraft:overworld run fill 386 58 -10 386 57 -10 stone
execute in minecraft:overworld run fill 386 58 -10 386 59 -10 dirt
execute in minecraft:overworld run setblock 386 60 -10 gravel
execute in minecraft:overworld run fill 386 61 -10 386 144 -10 air
execute in minecraft:overworld run fill 386 61 -10 386 64 -10 water
execute in minecraft:overworld run fill 386 58 -9 386 57 -9 stone
execute in minecraft:overworld run fill 386 58 -9 386 59 -9 dirt
execute in minecraft:overworld run setblock 386 60 -9 gravel
execute in minecraft:overworld run fill 386 61 -9 386 144 -9 air
execute in minecraft:overworld run fill 386 61 -9 386 64 -9 water
execute in minecraft:overworld run fill 386 58 -8 386 57 -8 stone
execute in minecraft:overworld run fill 386 58 -8 386 59 -8 dirt
execute in minecraft:overworld run setblock 386 60 -8 gravel
execute in minecraft:overworld run fill 386 61 -8 386 144 -8 air
execute in minecraft:overworld run fill 386 61 -8 386 64 -8 water
execute in minecraft:overworld run fill 386 58 -7 386 58 -7 stone
execute in minecraft:overworld run fill 386 59 -7 386 60 -7 dirt
execute in minecraft:overworld run setblock 386 61 -7 gravel
execute in minecraft:overworld run fill 386 62 -7 386 144 -7 air
execute in minecraft:overworld run fill 386 62 -7 386 64 -7 water
execute in minecraft:overworld run fill 386 58 -6 386 58 -6 stone
execute in minecraft:overworld run fill 386 59 -6 386 60 -6 dirt
execute in minecraft:overworld run setblock 386 61 -6 gravel
execute in minecraft:overworld run fill 386 62 -6 386 144 -6 air
execute in minecraft:overworld run fill 386 62 -6 386 64 -6 water
execute in minecraft:overworld run fill 386 58 -5 386 58 -5 stone
execute in minecraft:overworld run fill 386 59 -5 386 60 -5 dirt
execute in minecraft:overworld run setblock 386 61 -5 gravel
execute in minecraft:overworld run fill 386 62 -5 386 144 -5 air
execute in minecraft:overworld run fill 386 62 -5 386 64 -5 water
execute in minecraft:overworld run fill 386 58 -4 386 59 -4 stone
execute in minecraft:overworld run fill 386 60 -4 386 61 -4 dirt
execute in minecraft:overworld run setblock 386 62 -4 gravel
execute in minecraft:overworld run fill 386 63 -4 386 144 -4 air
execute in minecraft:overworld run fill 386 63 -4 386 64 -4 water
execute in minecraft:overworld run fill 386 58 -3 386 59 -3 stone
execute in minecraft:overworld run fill 386 60 -3 386 61 -3 dirt
execute in minecraft:overworld run setblock 386 62 -3 gravel
execute in minecraft:overworld run fill 386 63 -3 386 144 -3 air
execute in minecraft:overworld run fill 386 63 -3 386 64 -3 water
execute in minecraft:overworld run fill 386 58 -2 386 59 -2 stone
execute in minecraft:overworld run fill 386 60 -2 386 61 -2 dirt
execute in minecraft:overworld run setblock 386 62 -2 gravel
execute in minecraft:overworld run fill 386 63 -2 386 144 -2 air
execute in minecraft:overworld run fill 386 63 -2 386 64 -2 water
execute in minecraft:overworld run fill 386 58 -1 386 60 -1 stone
execute in minecraft:overworld run fill 386 61 -1 386 62 -1 dirt
execute in minecraft:overworld run setblock 386 63 -1 gravel
execute in minecraft:overworld run fill 386 64 -1 386 144 -1 air
execute in minecraft:overworld run fill 386 64 -1 386 64 -1 water
execute in minecraft:overworld run fill 386 58 0 386 60 0 stone
execute in minecraft:overworld run fill 386 61 0 386 62 0 dirt
execute in minecraft:overworld run setblock 386 63 0 gravel
execute in minecraft:overworld run fill 386 64 0 386 144 0 air
execute in minecraft:overworld run fill 386 64 0 386 64 0 water
execute in minecraft:overworld run fill 386 58 1 386 60 1 stone
execute in minecraft:overworld run fill 386 61 1 386 62 1 dirt
execute in minecraft:overworld run setblock 386 63 1 gravel
execute in minecraft:overworld run fill 386 64 1 386 144 1 air
execute in minecraft:overworld run fill 386 64 1 386 64 1 water
execute in minecraft:overworld run fill 386 58 2 386 60 2 stone
execute in minecraft:overworld run fill 386 61 2 386 62 2 dirt
execute in minecraft:overworld run setblock 386 63 2 gravel
execute in minecraft:overworld run fill 386 64 2 386 144 2 air
execute in minecraft:overworld run fill 386 64 2 386 64 2 water
execute in minecraft:overworld run fill 386 58 3 386 60 3 stone
execute in minecraft:overworld run fill 386 61 3 386 62 3 dirt
execute in minecraft:overworld run setblock 386 63 3 gravel
execute in minecraft:overworld run fill 386 64 3 386 144 3 air
execute in minecraft:overworld run fill 386 64 3 386 64 3 water
execute in minecraft:overworld run fill 386 58 4 386 60 4 stone
execute in minecraft:overworld run fill 386 61 4 386 62 4 dirt
execute in minecraft:overworld run setblock 386 63 4 gravel
execute in minecraft:overworld run fill 386 64 4 386 144 4 air
execute in minecraft:overworld run fill 386 64 4 386 64 4 water
execute in minecraft:overworld run fill 386 58 5 386 61 5 stone
execute in minecraft:overworld run fill 386 62 5 386 63 5 dirt
execute in minecraft:overworld run setblock 386 64 5 coarse_dirt
execute in minecraft:overworld run fill 386 65 5 386 144 5 air
execute in minecraft:overworld run fill 386 58 6 386 61 6 stone
execute in minecraft:overworld run fill 386 62 6 386 63 6 dirt
execute in minecraft:overworld run setblock 386 64 6 coarse_dirt
execute in minecraft:overworld run fill 386 65 6 386 144 6 air
execute in minecraft:overworld run fill 386 58 7 386 61 7 stone
execute in minecraft:overworld run fill 386 62 7 386 63 7 dirt
execute in minecraft:overworld run setblock 386 64 7 grass_block
execute in minecraft:overworld run fill 386 65 7 386 144 7 air
execute in minecraft:overworld run fill 386 58 8 386 61 8 stone
execute in minecraft:overworld run fill 386 62 8 386 63 8 dirt
execute in minecraft:overworld run setblock 386 64 8 coarse_dirt
execute in minecraft:overworld run fill 386 65 8 386 144 8 air
execute in minecraft:overworld run fill 386 58 9 386 61 9 stone
execute in minecraft:overworld run fill 386 62 9 386 63 9 dirt
execute in minecraft:overworld run setblock 386 64 9 grass_block
execute in minecraft:overworld run fill 386 65 9 386 144 9 air
execute in minecraft:overworld run fill 386 58 10 386 61 10 stone
execute in minecraft:overworld run fill 386 62 10 386 63 10 dirt
execute in minecraft:overworld run setblock 386 64 10 coarse_dirt
execute in minecraft:overworld run fill 386 65 10 386 144 10 air
execute in minecraft:overworld run fill 386 58 11 386 61 11 stone
execute in minecraft:overworld run fill 386 62 11 386 63 11 dirt
execute in minecraft:overworld run setblock 386 64 11 coarse_dirt
execute in minecraft:overworld run fill 386 65 11 386 144 11 air
schedule function blade_gallery:random/battlefield/part_78 1t replace
