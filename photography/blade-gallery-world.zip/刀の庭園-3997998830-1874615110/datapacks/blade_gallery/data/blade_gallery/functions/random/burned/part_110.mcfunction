execute in minecraft:overworld run fill 277 58 -17 277 72 -17 stone
execute in minecraft:overworld run fill 277 73 -17 277 74 -17 dirt
execute in minecraft:overworld run setblock 277 75 -17 coarse_dirt
execute in minecraft:overworld run fill 277 76 -17 277 144 -17 air
execute in minecraft:overworld run fill 277 58 -16 277 71 -16 stone
execute in minecraft:overworld run fill 277 72 -16 277 73 -16 dirt
execute in minecraft:overworld run setblock 277 74 -16 coarse_dirt
execute in minecraft:overworld run fill 277 75 -16 277 144 -16 air
execute in minecraft:overworld run setblock 277 75 -16 grass
execute in minecraft:overworld run fill 277 58 -15 277 70 -15 stone
execute in minecraft:overworld run fill 277 71 -15 277 72 -15 dirt
execute in minecraft:overworld run setblock 277 73 -15 grass_block
execute in minecraft:overworld run fill 277 74 -15 277 144 -15 air
execute in minecraft:overworld run fill 277 58 -14 277 70 -14 stone
execute in minecraft:overworld run fill 277 71 -14 277 72 -14 dirt
execute in minecraft:overworld run setblock 277 73 -14 grass_block
execute in minecraft:overworld run fill 277 74 -14 277 144 -14 air
execute in minecraft:overworld run fill 277 58 -13 277 69 -13 stone
execute in minecraft:overworld run fill 277 70 -13 277 71 -13 dirt
execute in minecraft:overworld run setblock 277 72 -13 coarse_dirt
execute in minecraft:overworld run fill 277 73 -13 277 144 -13 air
execute in minecraft:overworld run setblock 277 73 -13 grass
execute in minecraft:overworld run fill 277 58 -12 277 68 -12 stone
execute in minecraft:overworld run fill 277 69 -12 277 70 -12 dirt
execute in minecraft:overworld run setblock 277 71 -12 coarse_dirt
execute in minecraft:overworld run fill 277 72 -12 277 144 -12 air
execute in minecraft:overworld run fill 277 58 -11 277 68 -11 stone
execute in minecraft:overworld run fill 277 69 -11 277 70 -11 dirt
execute in minecraft:overworld run setblock 277 71 -11 coarse_dirt
execute in minecraft:overworld run fill 277 72 -11 277 144 -11 air
execute in minecraft:overworld run fill 277 58 -10 277 67 -10 stone
execute in minecraft:overworld run fill 277 68 -10 277 69 -10 dirt
execute in minecraft:overworld run setblock 277 70 -10 grass_block
execute in minecraft:overworld run fill 277 71 -10 277 144 -10 air
execute in minecraft:overworld run setblock 277 71 -10 grass
execute in minecraft:overworld run fill 277 58 -9 277 67 -9 stone
execute in minecraft:overworld run fill 277 68 -9 277 69 -9 dirt
execute in minecraft:overworld run setblock 277 70 -9 grass_block
execute in minecraft:overworld run fill 277 71 -9 277 144 -9 air
execute in minecraft:overworld run fill 277 58 -8 277 67 -8 stone
execute in minecraft:overworld run fill 277 68 -8 277 69 -8 dirt
execute in minecraft:overworld run setblock 277 70 -8 grass_block
execute in minecraft:overworld run fill 277 71 -8 277 144 -8 air
execute in minecraft:overworld run fill 277 58 -7 277 67 -7 stone
execute in minecraft:overworld run fill 277 68 -7 277 69 -7 dirt
execute in minecraft:overworld run setblock 277 70 -7 grass_block
execute in minecraft:overworld run fill 277 71 -7 277 144 -7 air
execute in minecraft:overworld run fill 277 58 -6 277 67 -6 stone
execute in minecraft:overworld run fill 277 68 -6 277 69 -6 dirt
execute in minecraft:overworld run setblock 277 70 -6 coarse_dirt
execute in minecraft:overworld run fill 277 71 -6 277 144 -6 air
execute in minecraft:overworld run fill 277 58 -5 277 67 -5 stone
execute in minecraft:overworld run fill 277 68 -5 277 69 -5 dirt
execute in minecraft:overworld run setblock 277 70 -5 coarse_dirt
execute in minecraft:overworld run fill 277 71 -5 277 144 -5 air
execute in minecraft:overworld run fill 277 58 -4 277 66 -4 stone
execute in minecraft:overworld run fill 277 67 -4 277 68 -4 dirt
execute in minecraft:overworld run setblock 277 69 -4 coarse_dirt
execute in minecraft:overworld run fill 277 70 -4 277 144 -4 air
execute in minecraft:overworld run fill 277 58 -3 277 66 -3 stone
execute in minecraft:overworld run fill 277 67 -3 277 68 -3 dirt
execute in minecraft:overworld run setblock 277 69 -3 coarse_dirt
execute in minecraft:overworld run fill 277 70 -3 277 144 -3 air
execute in minecraft:overworld run fill 277 58 -2 277 66 -2 stone
execute in minecraft:overworld run fill 277 67 -2 277 68 -2 dirt
execute in minecraft:overworld run setblock 277 69 -2 coarse_dirt
execute in minecraft:overworld run fill 277 70 -2 277 144 -2 air
execute in minecraft:overworld run fill 277 58 -1 277 66 -1 stone
execute in minecraft:overworld run fill 277 67 -1 277 68 -1 dirt
execute in minecraft:overworld run setblock 277 69 -1 coarse_dirt
execute in minecraft:overworld run fill 277 70 -1 277 144 -1 air
execute in minecraft:overworld run fill 277 58 0 277 66 0 stone
execute in minecraft:overworld run fill 277 67 0 277 68 0 dirt
execute in minecraft:overworld run setblock 277 69 0 coarse_dirt
execute in minecraft:overworld run fill 277 70 0 277 144 0 air
execute in minecraft:overworld run fill 277 58 1 277 66 1 stone
execute in minecraft:overworld run fill 277 67 1 277 68 1 dirt
execute in minecraft:overworld run setblock 277 69 1 grass_block
execute in minecraft:overworld run fill 277 70 1 277 144 1 air
execute in minecraft:overworld run fill 277 58 2 277 66 2 stone
execute in minecraft:overworld run fill 277 67 2 277 68 2 dirt
execute in minecraft:overworld run setblock 277 69 2 coarse_dirt
execute in minecraft:overworld run fill 277 70 2 277 144 2 air
execute in minecraft:overworld run fill 277 58 3 277 65 3 stone
execute in minecraft:overworld run fill 277 66 3 277 67 3 dirt
execute in minecraft:overworld run setblock 277 68 3 grass_block
execute in minecraft:overworld run fill 277 69 3 277 144 3 air
execute in minecraft:overworld run fill 277 58 4 277 65 4 stone
execute in minecraft:overworld run fill 277 66 4 277 67 4 dirt
execute in minecraft:overworld run setblock 277 68 4 grass_block
execute in minecraft:overworld run fill 277 69 4 277 144 4 air
execute in minecraft:overworld run setblock 277 69 4 grass
execute in minecraft:overworld run fill 277 58 5 277 65 5 stone
execute in minecraft:overworld run fill 277 66 5 277 67 5 dirt
execute in minecraft:overworld run setblock 277 68 5 grass_block
execute in minecraft:overworld run fill 277 69 5 277 144 5 air
execute in minecraft:overworld run fill 277 58 6 277 65 6 stone
execute in minecraft:overworld run fill 277 66 6 277 67 6 dirt
execute in minecraft:overworld run setblock 277 68 6 grass_block
execute in minecraft:overworld run fill 277 69 6 277 144 6 air
execute in minecraft:overworld run fill 277 58 7 277 64 7 stone
execute in minecraft:overworld run fill 277 65 7 277 66 7 dirt
execute in minecraft:overworld run setblock 277 67 7 coarse_dirt
execute in minecraft:overworld run fill 277 68 7 277 144 7 air
execute in minecraft:overworld run fill 277 58 8 277 64 8 stone
execute in minecraft:overworld run fill 277 65 8 277 66 8 dirt
execute in minecraft:overworld run setblock 277 67 8 coarse_dirt
execute in minecraft:overworld run fill 277 68 8 277 144 8 air
execute in minecraft:overworld run fill 277 58 9 277 64 9 stone
execute in minecraft:overworld run fill 277 65 9 277 66 9 dirt
execute in minecraft:overworld run setblock 277 67 9 grass_block
execute in minecraft:overworld run fill 277 68 9 277 144 9 air
execute in minecraft:overworld run fill 277 58 10 277 63 10 stone
execute in minecraft:overworld run fill 277 64 10 277 65 10 dirt
execute in minecraft:overworld run setblock 277 66 10 coarse_dirt
execute in minecraft:overworld run fill 277 67 10 277 144 10 air
execute in minecraft:overworld run fill 277 58 11 277 63 11 stone
execute in minecraft:overworld run fill 277 64 11 277 65 11 dirt
execute in minecraft:overworld run setblock 277 66 11 grass_block
execute in minecraft:overworld run fill 277 67 11 277 144 11 air
execute in minecraft:overworld run fill 277 58 12 277 63 12 stone
execute in minecraft:overworld run fill 277 64 12 277 65 12 dirt
execute in minecraft:overworld run setblock 277 66 12 coarse_dirt
execute in minecraft:overworld run fill 277 67 12 277 144 12 air
execute in minecraft:overworld run fill 277 58 13 277 63 13 stone
execute in minecraft:overworld run fill 277 64 13 277 65 13 dirt
execute in minecraft:overworld run setblock 277 66 13 grass_block
execute in minecraft:overworld run fill 277 67 13 277 144 13 air
execute in minecraft:overworld run setblock 277 67 13 grass
execute in minecraft:overworld run fill 277 58 14 277 63 14 stone
execute in minecraft:overworld run fill 277 64 14 277 65 14 dirt
execute in minecraft:overworld run setblock 277 66 14 coarse_dirt
execute in minecraft:overworld run fill 277 67 14 277 144 14 air
execute in minecraft:overworld run setblock 277 67 14 grass
execute in minecraft:overworld run fill 277 58 15 277 63 15 stone
execute in minecraft:overworld run fill 277 64 15 277 65 15 dirt
execute in minecraft:overworld run setblock 277 66 15 grass_block
execute in minecraft:overworld run fill 277 67 15 277 144 15 air
execute in minecraft:overworld run fill 277 58 16 277 63 16 stone
execute in minecraft:overworld run fill 277 64 16 277 65 16 dirt
execute in minecraft:overworld run setblock 277 66 16 coarse_dirt
execute in minecraft:overworld run fill 277 67 16 277 144 16 air
execute in minecraft:overworld run fill 277 58 17 277 63 17 stone
execute in minecraft:overworld run fill 277 64 17 277 65 17 dirt
execute in minecraft:overworld run setblock 277 66 17 coarse_dirt
execute in minecraft:overworld run fill 277 67 17 277 144 17 air
execute in minecraft:overworld run fill 277 58 18 277 62 18 stone
execute in minecraft:overworld run fill 277 63 18 277 64 18 dirt
execute in minecraft:overworld run setblock 277 65 18 grass_block
execute in minecraft:overworld run fill 277 66 18 277 144 18 air
execute in minecraft:overworld run fill 277 58 19 277 62 19 stone
execute in minecraft:overworld run fill 277 63 19 277 64 19 dirt
execute in minecraft:overworld run setblock 277 65 19 coarse_dirt
execute in minecraft:overworld run fill 277 66 19 277 144 19 air
execute in minecraft:overworld run fill 277 58 20 277 62 20 stone
execute in minecraft:overworld run fill 277 63 20 277 64 20 dirt
execute in minecraft:overworld run setblock 277 65 20 grass_block
execute in minecraft:overworld run fill 277 66 20 277 144 20 air
execute in minecraft:overworld run fill 277 58 21 277 62 21 stone
execute in minecraft:overworld run fill 277 63 21 277 64 21 dirt
execute in minecraft:overworld run setblock 277 65 21 coarse_dirt
execute in minecraft:overworld run fill 277 66 21 277 144 21 air
execute in minecraft:overworld run fill 277 58 22 277 62 22 stone
execute in minecraft:overworld run fill 277 63 22 277 64 22 dirt
execute in minecraft:overworld run setblock 277 65 22 coarse_dirt
execute in minecraft:overworld run fill 277 66 22 277 144 22 air
execute in minecraft:overworld run fill 277 58 23 277 62 23 stone
execute in minecraft:overworld run fill 277 63 23 277 64 23 dirt
execute in minecraft:overworld run setblock 277 65 23 coarse_dirt
execute in minecraft:overworld run fill 277 66 23 277 144 23 air
execute in minecraft:overworld run fill 277 58 24 277 62 24 stone
execute in minecraft:overworld run fill 277 63 24 277 64 24 dirt
execute in minecraft:overworld run setblock 277 65 24 coarse_dirt
execute in minecraft:overworld run fill 277 66 24 277 144 24 air
execute in minecraft:overworld run fill 277 58 25 277 62 25 stone
execute in minecraft:overworld run fill 277 63 25 277 64 25 dirt
execute in minecraft:overworld run setblock 277 65 25 coarse_dirt
execute in minecraft:overworld run fill 277 66 25 277 144 25 air
execute in minecraft:overworld run fill 277 58 26 277 62 26 stone
execute in minecraft:overworld run fill 277 63 26 277 64 26 dirt
execute in minecraft:overworld run setblock 277 65 26 grass_block
execute in minecraft:overworld run fill 277 66 26 277 144 26 air
execute in minecraft:overworld run fill 277 58 27 277 62 27 stone
execute in minecraft:overworld run fill 277 63 27 277 64 27 dirt
execute in minecraft:overworld run setblock 277 65 27 coarse_dirt
execute in minecraft:overworld run fill 277 66 27 277 144 27 air
execute in minecraft:overworld run fill 277 58 28 277 62 28 stone
execute in minecraft:overworld run fill 277 63 28 277 64 28 dirt
execute in minecraft:overworld run setblock 277 65 28 coarse_dirt
execute in minecraft:overworld run fill 277 66 28 277 144 28 air
execute in minecraft:overworld run fill 277 58 29 277 62 29 stone
execute in minecraft:overworld run fill 277 63 29 277 64 29 dirt
execute in minecraft:overworld run setblock 277 65 29 coarse_dirt
execute in minecraft:overworld run fill 277 66 29 277 144 29 air
execute in minecraft:overworld run fill 277 58 30 277 62 30 stone
execute in minecraft:overworld run fill 277 63 30 277 64 30 dirt
execute in minecraft:overworld run setblock 277 65 30 grass_block
execute in minecraft:overworld run fill 277 66 30 277 144 30 air
execute in minecraft:overworld run fill 277 58 31 277 62 31 stone
execute in minecraft:overworld run fill 277 63 31 277 64 31 dirt
execute in minecraft:overworld run setblock 277 65 31 coarse_dirt
execute in minecraft:overworld run fill 277 66 31 277 144 31 air
execute in minecraft:overworld run fill 277 58 32 277 62 32 stone
execute in minecraft:overworld run fill 277 63 32 277 64 32 dirt
execute in minecraft:overworld run setblock 277 65 32 coarse_dirt
execute in minecraft:overworld run fill 277 66 32 277 144 32 air
execute in minecraft:overworld run fill 277 58 33 277 62 33 stone
execute in minecraft:overworld run fill 277 63 33 277 64 33 dirt
execute in minecraft:overworld run setblock 277 65 33 grass_block
execute in minecraft:overworld run fill 277 66 33 277 144 33 air
execute in minecraft:overworld run fill 277 58 34 277 61 34 stone
execute in minecraft:overworld run fill 277 62 34 277 63 34 dirt
execute in minecraft:overworld run setblock 277 64 34 coarse_dirt
execute in minecraft:overworld run fill 277 65 34 277 144 34 air
execute in minecraft:overworld run fill 277 58 35 277 61 35 stone
execute in minecraft:overworld run fill 277 62 35 277 63 35 dirt
execute in minecraft:overworld run setblock 277 64 35 coarse_dirt
execute in minecraft:overworld run fill 277 65 35 277 144 35 air
execute in minecraft:overworld run fill 277 58 36 277 61 36 stone
execute in minecraft:overworld run fill 277 62 36 277 63 36 dirt
execute in minecraft:overworld run setblock 277 64 36 grass_block
execute in minecraft:overworld run fill 277 65 36 277 144 36 air
execute in minecraft:overworld run fill 277 58 37 277 61 37 stone
execute in minecraft:overworld run fill 277 62 37 277 63 37 dirt
execute in minecraft:overworld run setblock 277 64 37 coarse_dirt
execute in minecraft:overworld run fill 277 65 37 277 144 37 air
execute in minecraft:overworld run fill 277 58 38 277 61 38 stone
execute in minecraft:overworld run fill 277 62 38 277 63 38 dirt
execute in minecraft:overworld run setblock 277 64 38 grass_block
execute in minecraft:overworld run fill 277 65 38 277 144 38 air
execute in minecraft:overworld run fill 277 58 39 277 61 39 stone
execute in minecraft:overworld run fill 277 62 39 277 63 39 dirt
execute in minecraft:overworld run setblock 277 64 39 coarse_dirt
execute in minecraft:overworld run fill 277 65 39 277 144 39 air
execute in minecraft:overworld run fill 277 58 40 277 61 40 stone
execute in minecraft:overworld run fill 277 62 40 277 63 40 dirt
execute in minecraft:overworld run setblock 277 64 40 coarse_dirt
execute in minecraft:overworld run fill 277 65 40 277 144 40 air
execute in minecraft:overworld run fill 277 58 41 277 61 41 stone
execute in minecraft:overworld run fill 277 62 41 277 63 41 dirt
execute in minecraft:overworld run setblock 277 64 41 grass_block
execute in minecraft:overworld run fill 277 65 41 277 144 41 air
execute in minecraft:overworld run fill 277 58 42 277 61 42 stone
execute in minecraft:overworld run fill 277 62 42 277 63 42 dirt
execute in minecraft:overworld run setblock 277 64 42 coarse_dirt
execute in minecraft:overworld run fill 277 65 42 277 144 42 air
execute in minecraft:overworld run fill 277 58 43 277 61 43 stone
execute in minecraft:overworld run fill 277 62 43 277 63 43 dirt
execute in minecraft:overworld run setblock 277 64 43 coarse_dirt
execute in minecraft:overworld run fill 277 65 43 277 144 43 air
execute in minecraft:overworld run fill 277 58 44 277 61 44 stone
execute in minecraft:overworld run fill 277 62 44 277 63 44 dirt
execute in minecraft:overworld run setblock 277 64 44 coarse_dirt
execute in minecraft:overworld run fill 277 65 44 277 144 44 air
execute in minecraft:overworld run fill 277 58 45 277 61 45 stone
execute in minecraft:overworld run fill 277 62 45 277 63 45 dirt
schedule function blade_gallery:random/burned/part_111 1t replace
