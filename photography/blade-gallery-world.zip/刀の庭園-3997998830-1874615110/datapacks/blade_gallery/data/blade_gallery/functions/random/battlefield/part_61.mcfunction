execute in minecraft:overworld run fill 375 58 28 375 67 28 stone
execute in minecraft:overworld run fill 375 68 28 375 69 28 dirt
execute in minecraft:overworld run setblock 375 70 28 coarse_dirt
execute in minecraft:overworld run fill 375 71 28 375 144 28 air
execute in minecraft:overworld run fill 375 58 29 375 67 29 stone
execute in minecraft:overworld run fill 375 68 29 375 69 29 dirt
execute in minecraft:overworld run setblock 375 70 29 coarse_dirt
execute in minecraft:overworld run fill 375 71 29 375 144 29 air
execute in minecraft:overworld run fill 375 58 30 375 67 30 stone
execute in minecraft:overworld run fill 375 68 30 375 69 30 dirt
execute in minecraft:overworld run setblock 375 70 30 coarse_dirt
execute in minecraft:overworld run fill 375 71 30 375 144 30 air
execute in minecraft:overworld run fill 375 58 31 375 68 31 stone
execute in minecraft:overworld run fill 375 69 31 375 70 31 dirt
execute in minecraft:overworld run setblock 375 71 31 coarse_dirt
execute in minecraft:overworld run fill 375 72 31 375 144 31 air
execute in minecraft:overworld run fill 375 58 32 375 68 32 stone
execute in minecraft:overworld run fill 375 69 32 375 70 32 dirt
execute in minecraft:overworld run setblock 375 71 32 coarse_dirt
execute in minecraft:overworld run fill 375 72 32 375 144 32 air
execute in minecraft:overworld run fill 375 58 33 375 68 33 stone
execute in minecraft:overworld run fill 375 69 33 375 70 33 dirt
execute in minecraft:overworld run setblock 375 71 33 coarse_dirt
execute in minecraft:overworld run fill 375 72 33 375 144 33 air
execute in minecraft:overworld run fill 375 58 34 375 68 34 stone
execute in minecraft:overworld run fill 375 69 34 375 70 34 dirt
execute in minecraft:overworld run setblock 375 71 34 grass_block
execute in minecraft:overworld run fill 375 72 34 375 144 34 air
execute in minecraft:overworld run setblock 375 72 34 grass
execute in minecraft:overworld run fill 375 58 35 375 68 35 stone
execute in minecraft:overworld run fill 375 69 35 375 70 35 dirt
execute in minecraft:overworld run setblock 375 71 35 coarse_dirt
execute in minecraft:overworld run fill 375 72 35 375 144 35 air
execute in minecraft:overworld run fill 375 58 36 375 68 36 stone
execute in minecraft:overworld run fill 375 69 36 375 70 36 dirt
execute in minecraft:overworld run setblock 375 71 36 coarse_dirt
execute in minecraft:overworld run fill 375 72 36 375 144 36 air
execute in minecraft:overworld run fill 375 58 37 375 68 37 stone
execute in minecraft:overworld run fill 375 69 37 375 70 37 dirt
execute in minecraft:overworld run setblock 375 71 37 grass_block
execute in minecraft:overworld run fill 375 72 37 375 144 37 air
execute in minecraft:overworld run setblock 375 72 37 grass
execute in minecraft:overworld run fill 375 58 38 375 68 38 stone
execute in minecraft:overworld run fill 375 69 38 375 70 38 dirt
execute in minecraft:overworld run setblock 375 71 38 coarse_dirt
execute in minecraft:overworld run fill 375 72 38 375 144 38 air
execute in minecraft:overworld run fill 375 58 39 375 67 39 stone
execute in minecraft:overworld run fill 375 68 39 375 69 39 dirt
execute in minecraft:overworld run setblock 375 70 39 coarse_dirt
execute in minecraft:overworld run fill 375 71 39 375 144 39 air
execute in minecraft:overworld run fill 375 58 40 375 67 40 stone
execute in minecraft:overworld run fill 375 68 40 375 69 40 dirt
execute in minecraft:overworld run setblock 375 70 40 coarse_dirt
execute in minecraft:overworld run fill 375 71 40 375 144 40 air
execute in minecraft:overworld run fill 375 58 41 375 66 41 stone
execute in minecraft:overworld run fill 375 67 41 375 68 41 dirt
execute in minecraft:overworld run setblock 375 69 41 coarse_dirt
execute in minecraft:overworld run fill 375 70 41 375 144 41 air
execute in minecraft:overworld run setblock 375 70 41 grass
execute in minecraft:overworld run fill 375 58 42 375 65 42 stone
execute in minecraft:overworld run fill 375 66 42 375 67 42 dirt
execute in minecraft:overworld run setblock 375 68 42 coarse_dirt
execute in minecraft:overworld run fill 375 69 42 375 144 42 air
execute in minecraft:overworld run fill 375 58 43 375 64 43 stone
execute in minecraft:overworld run fill 375 65 43 375 66 43 dirt
execute in minecraft:overworld run setblock 375 67 43 coarse_dirt
execute in minecraft:overworld run fill 375 68 43 375 144 43 air
execute in minecraft:overworld run fill 375 58 44 375 64 44 stone
execute in minecraft:overworld run fill 375 65 44 375 66 44 dirt
execute in minecraft:overworld run setblock 375 67 44 grass_block
execute in minecraft:overworld run fill 375 68 44 375 144 44 air
execute in minecraft:overworld run fill 375 58 45 375 63 45 stone
execute in minecraft:overworld run fill 375 64 45 375 65 45 dirt
execute in minecraft:overworld run setblock 375 66 45 grass_block
execute in minecraft:overworld run fill 375 67 45 375 144 45 air
execute in minecraft:overworld run fill 375 58 46 375 62 46 stone
execute in minecraft:overworld run fill 375 63 46 375 64 46 dirt
execute in minecraft:overworld run setblock 375 65 46 grass_block
execute in minecraft:overworld run fill 375 66 46 375 144 46 air
execute in minecraft:overworld run fill 375 58 47 375 62 47 stone
execute in minecraft:overworld run fill 375 63 47 375 64 47 dirt
execute in minecraft:overworld run setblock 375 65 47 coarse_dirt
execute in minecraft:overworld run fill 375 66 47 375 144 47 air
execute in minecraft:overworld run fill 376 58 -48 376 61 -48 stone
execute in minecraft:overworld run fill 376 62 -48 376 63 -48 dirt
execute in minecraft:overworld run setblock 376 64 -48 grass_block
execute in minecraft:overworld run fill 376 65 -48 376 144 -48 air
execute in minecraft:overworld run fill 376 58 -47 376 62 -47 stone
execute in minecraft:overworld run fill 376 63 -47 376 64 -47 dirt
execute in minecraft:overworld run setblock 376 65 -47 grass_block
execute in minecraft:overworld run fill 376 66 -47 376 144 -47 air
execute in minecraft:overworld run fill 376 58 -46 376 63 -46 stone
execute in minecraft:overworld run fill 376 64 -46 376 65 -46 dirt
execute in minecraft:overworld run setblock 376 66 -46 coarse_dirt
execute in minecraft:overworld run fill 376 67 -46 376 144 -46 air
execute in minecraft:overworld run fill 376 58 -45 376 63 -45 stone
execute in minecraft:overworld run fill 376 64 -45 376 65 -45 dirt
execute in minecraft:overworld run setblock 376 66 -45 grass_block
execute in minecraft:overworld run fill 376 67 -45 376 144 -45 air
execute in minecraft:overworld run fill 376 58 -44 376 64 -44 stone
execute in minecraft:overworld run fill 376 65 -44 376 66 -44 dirt
execute in minecraft:overworld run setblock 376 67 -44 coarse_dirt
execute in minecraft:overworld run fill 376 68 -44 376 144 -44 air
execute in minecraft:overworld run fill 376 58 -43 376 65 -43 stone
execute in minecraft:overworld run fill 376 66 -43 376 67 -43 dirt
execute in minecraft:overworld run setblock 376 68 -43 coarse_dirt
execute in minecraft:overworld run fill 376 69 -43 376 144 -43 air
execute in minecraft:overworld run fill 376 58 -42 376 65 -42 stone
execute in minecraft:overworld run fill 376 66 -42 376 67 -42 dirt
execute in minecraft:overworld run setblock 376 68 -42 coarse_dirt
execute in minecraft:overworld run fill 376 69 -42 376 144 -42 air
execute in minecraft:overworld run fill 376 58 -41 376 65 -41 stone
execute in minecraft:overworld run fill 376 66 -41 376 67 -41 dirt
execute in minecraft:overworld run setblock 376 68 -41 grass_block
execute in minecraft:overworld run fill 376 69 -41 376 144 -41 air
execute in minecraft:overworld run fill 376 58 -40 376 65 -40 stone
execute in minecraft:overworld run fill 376 66 -40 376 67 -40 dirt
execute in minecraft:overworld run setblock 376 68 -40 coarse_dirt
execute in minecraft:overworld run fill 376 69 -40 376 144 -40 air
execute in minecraft:overworld run fill 376 58 -39 376 66 -39 stone
execute in minecraft:overworld run fill 376 67 -39 376 68 -39 dirt
execute in minecraft:overworld run setblock 376 69 -39 coarse_dirt
execute in minecraft:overworld run fill 376 70 -39 376 144 -39 air
execute in minecraft:overworld run fill 376 58 -38 376 66 -38 stone
execute in minecraft:overworld run fill 376 67 -38 376 68 -38 dirt
execute in minecraft:overworld run setblock 376 69 -38 coarse_dirt
execute in minecraft:overworld run fill 376 70 -38 376 144 -38 air
execute in minecraft:overworld run fill 376 58 -37 376 65 -37 stone
execute in minecraft:overworld run fill 376 66 -37 376 67 -37 dirt
execute in minecraft:overworld run setblock 376 68 -37 coarse_dirt
execute in minecraft:overworld run fill 376 69 -37 376 144 -37 air
execute in minecraft:overworld run fill 376 58 -36 376 65 -36 stone
execute in minecraft:overworld run fill 376 66 -36 376 67 -36 dirt
execute in minecraft:overworld run setblock 376 68 -36 grass_block
execute in minecraft:overworld run fill 376 69 -36 376 144 -36 air
execute in minecraft:overworld run fill 376 58 -35 376 65 -35 stone
execute in minecraft:overworld run fill 376 66 -35 376 67 -35 dirt
execute in minecraft:overworld run setblock 376 68 -35 coarse_dirt
execute in minecraft:overworld run fill 376 69 -35 376 144 -35 air
execute in minecraft:overworld run fill 376 58 -34 376 65 -34 stone
execute in minecraft:overworld run fill 376 66 -34 376 67 -34 dirt
execute in minecraft:overworld run setblock 376 68 -34 grass_block
execute in minecraft:overworld run fill 376 69 -34 376 144 -34 air
execute in minecraft:overworld run fill 376 58 -33 376 65 -33 stone
execute in minecraft:overworld run fill 376 66 -33 376 67 -33 dirt
execute in minecraft:overworld run setblock 376 68 -33 coarse_dirt
execute in minecraft:overworld run fill 376 69 -33 376 144 -33 air
execute in minecraft:overworld run fill 376 58 -32 376 65 -32 stone
execute in minecraft:overworld run fill 376 66 -32 376 67 -32 dirt
execute in minecraft:overworld run setblock 376 68 -32 coarse_dirt
execute in minecraft:overworld run fill 376 69 -32 376 144 -32 air
execute in minecraft:overworld run fill 376 58 -31 376 66 -31 stone
execute in minecraft:overworld run fill 376 67 -31 376 68 -31 dirt
execute in minecraft:overworld run setblock 376 69 -31 grass_block
execute in minecraft:overworld run fill 376 70 -31 376 144 -31 air
execute in minecraft:overworld run fill 376 58 -30 376 66 -30 stone
execute in minecraft:overworld run fill 376 67 -30 376 68 -30 dirt
execute in minecraft:overworld run setblock 376 69 -30 coarse_dirt
execute in minecraft:overworld run fill 376 70 -30 376 144 -30 air
execute in minecraft:overworld run fill 376 58 -29 376 66 -29 stone
execute in minecraft:overworld run fill 376 67 -29 376 68 -29 dirt
execute in minecraft:overworld run setblock 376 69 -29 coarse_dirt
execute in minecraft:overworld run fill 376 70 -29 376 144 -29 air
execute in minecraft:overworld run fill 376 58 -28 376 66 -28 stone
execute in minecraft:overworld run fill 376 67 -28 376 68 -28 dirt
execute in minecraft:overworld run setblock 376 69 -28 grass_block
execute in minecraft:overworld run fill 376 70 -28 376 144 -28 air
execute in minecraft:overworld run setblock 376 70 -28 grass
execute in minecraft:overworld run fill 376 58 -27 376 67 -27 stone
execute in minecraft:overworld run fill 376 68 -27 376 69 -27 dirt
execute in minecraft:overworld run setblock 376 70 -27 coarse_dirt
execute in minecraft:overworld run fill 376 71 -27 376 144 -27 air
execute in minecraft:overworld run fill 376 58 -26 376 67 -26 stone
execute in minecraft:overworld run fill 376 68 -26 376 69 -26 dirt
execute in minecraft:overworld run setblock 376 70 -26 grass_block
execute in minecraft:overworld run fill 376 71 -26 376 144 -26 air
execute in minecraft:overworld run fill 376 58 -25 376 67 -25 stone
execute in minecraft:overworld run fill 376 68 -25 376 69 -25 dirt
execute in minecraft:overworld run setblock 376 70 -25 coarse_dirt
execute in minecraft:overworld run fill 376 71 -25 376 144 -25 air
execute in minecraft:overworld run fill 376 58 -24 376 66 -24 stone
execute in minecraft:overworld run fill 376 67 -24 376 68 -24 dirt
execute in minecraft:overworld run setblock 376 69 -24 coarse_dirt
execute in minecraft:overworld run fill 376 70 -24 376 144 -24 air
execute in minecraft:overworld run fill 376 58 -23 376 66 -23 stone
execute in minecraft:overworld run fill 376 67 -23 376 68 -23 dirt
execute in minecraft:overworld run setblock 376 69 -23 coarse_dirt
execute in minecraft:overworld run fill 376 70 -23 376 144 -23 air
execute in minecraft:overworld run fill 376 58 -22 376 66 -22 stone
execute in minecraft:overworld run fill 376 67 -22 376 68 -22 dirt
execute in minecraft:overworld run setblock 376 69 -22 coarse_dirt
execute in minecraft:overworld run fill 376 70 -22 376 144 -22 air
execute in minecraft:overworld run fill 376 58 -21 376 66 -21 stone
execute in minecraft:overworld run fill 376 67 -21 376 68 -21 dirt
execute in minecraft:overworld run setblock 376 69 -21 coarse_dirt
execute in minecraft:overworld run fill 376 70 -21 376 144 -21 air
execute in minecraft:overworld run fill 376 58 -20 376 65 -20 stone
execute in minecraft:overworld run fill 376 66 -20 376 67 -20 dirt
execute in minecraft:overworld run setblock 376 68 -20 coarse_dirt
execute in minecraft:overworld run fill 376 69 -20 376 144 -20 air
execute in minecraft:overworld run fill 376 58 -19 376 65 -19 stone
execute in minecraft:overworld run fill 376 66 -19 376 67 -19 dirt
execute in minecraft:overworld run setblock 376 68 -19 coarse_dirt
execute in minecraft:overworld run fill 376 69 -19 376 144 -19 air
execute in minecraft:overworld run fill 376 58 -18 376 65 -18 stone
execute in minecraft:overworld run fill 376 66 -18 376 67 -18 dirt
execute in minecraft:overworld run setblock 376 68 -18 coarse_dirt
execute in minecraft:overworld run fill 376 69 -18 376 144 -18 air
execute in minecraft:overworld run fill 376 58 -17 376 65 -17 stone
execute in minecraft:overworld run fill 376 66 -17 376 67 -17 dirt
execute in minecraft:overworld run setblock 376 68 -17 coarse_dirt
execute in minecraft:overworld run fill 376 69 -17 376 144 -17 air
execute in minecraft:overworld run fill 376 58 -16 376 65 -16 stone
execute in minecraft:overworld run fill 376 66 -16 376 67 -16 dirt
execute in minecraft:overworld run setblock 376 68 -16 grass_block
execute in minecraft:overworld run fill 376 69 -16 376 144 -16 air
execute in minecraft:overworld run fill 376 58 -15 376 65 -15 stone
execute in minecraft:overworld run fill 376 66 -15 376 67 -15 dirt
execute in minecraft:overworld run setblock 376 68 -15 coarse_dirt
execute in minecraft:overworld run fill 376 69 -15 376 144 -15 air
execute in minecraft:overworld run fill 376 58 -14 376 65 -14 stone
execute in minecraft:overworld run fill 376 66 -14 376 67 -14 dirt
execute in minecraft:overworld run setblock 376 68 -14 coarse_dirt
execute in minecraft:overworld run fill 376 69 -14 376 144 -14 air
execute in minecraft:overworld run fill 376 58 -13 376 65 -13 stone
execute in minecraft:overworld run fill 376 66 -13 376 67 -13 dirt
execute in minecraft:overworld run setblock 376 68 -13 grass_block
execute in minecraft:overworld run fill 376 69 -13 376 144 -13 air
execute in minecraft:overworld run fill 376 58 -12 376 64 -12 stone
execute in minecraft:overworld run fill 376 65 -12 376 66 -12 dirt
execute in minecraft:overworld run setblock 376 67 -12 coarse_dirt
execute in minecraft:overworld run fill 376 68 -12 376 144 -12 air
execute in minecraft:overworld run fill 376 58 -11 376 65 -11 stone
execute in minecraft:overworld run fill 376 66 -11 376 67 -11 dirt
execute in minecraft:overworld run setblock 376 68 -11 coarse_dirt
execute in minecraft:overworld run fill 376 69 -11 376 144 -11 air
execute in minecraft:overworld run setblock 376 69 -11 grass
execute in minecraft:overworld run fill 376 58 -10 376 65 -10 stone
execute in minecraft:overworld run fill 376 66 -10 376 67 -10 dirt
execute in minecraft:overworld run setblock 376 68 -10 grass_block
execute in minecraft:overworld run fill 376 69 -10 376 144 -10 air
execute in minecraft:overworld run fill 376 58 -9 376 65 -9 stone
execute in minecraft:overworld run fill 376 66 -9 376 67 -9 dirt
execute in minecraft:overworld run setblock 376 68 -9 coarse_dirt
execute in minecraft:overworld run fill 376 69 -9 376 144 -9 air
execute in minecraft:overworld run fill 376 58 -8 376 65 -8 stone
execute in minecraft:overworld run fill 376 66 -8 376 67 -8 dirt
execute in minecraft:overworld run setblock 376 68 -8 coarse_dirt
execute in minecraft:overworld run fill 376 69 -8 376 144 -8 air
execute in minecraft:overworld run fill 376 58 -7 376 65 -7 stone
execute in minecraft:overworld run fill 376 66 -7 376 67 -7 dirt
execute in minecraft:overworld run setblock 376 68 -7 grass_block
execute in minecraft:overworld run fill 376 69 -7 376 144 -7 air
execute in minecraft:overworld run fill 376 58 -6 376 65 -6 stone
execute in minecraft:overworld run fill 376 66 -6 376 67 -6 dirt
execute in minecraft:overworld run setblock 376 68 -6 grass_block
schedule function blade_gallery:random/battlefield/part_62 1t replace
