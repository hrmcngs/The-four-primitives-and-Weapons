execute in minecraft:overworld run fill 428 67 6 428 144 6 air
execute in minecraft:overworld run fill 428 58 7 428 63 7 stone
execute in minecraft:overworld run fill 428 64 7 428 65 7 dirt
execute in minecraft:overworld run setblock 428 66 7 grass_block
execute in minecraft:overworld run fill 428 67 7 428 144 7 air
execute in minecraft:overworld run fill 428 58 8 428 63 8 stone
execute in minecraft:overworld run fill 428 64 8 428 65 8 dirt
execute in minecraft:overworld run setblock 428 66 8 coarse_dirt
execute in minecraft:overworld run fill 428 67 8 428 144 8 air
execute in minecraft:overworld run fill 428 58 9 428 63 9 stone
execute in minecraft:overworld run fill 428 64 9 428 65 9 dirt
execute in minecraft:overworld run setblock 428 66 9 grass_block
execute in minecraft:overworld run fill 428 67 9 428 144 9 air
execute in minecraft:overworld run fill 428 58 10 428 63 10 stone
execute in minecraft:overworld run fill 428 64 10 428 65 10 dirt
execute in minecraft:overworld run setblock 428 66 10 grass_block
execute in minecraft:overworld run fill 428 67 10 428 144 10 air
execute in minecraft:overworld run fill 428 58 11 428 63 11 stone
execute in minecraft:overworld run fill 428 64 11 428 65 11 dirt
execute in minecraft:overworld run setblock 428 66 11 grass_block
execute in minecraft:overworld run fill 428 67 11 428 144 11 air
execute in minecraft:overworld run fill 428 58 12 428 63 12 stone
execute in minecraft:overworld run fill 428 64 12 428 65 12 dirt
execute in minecraft:overworld run setblock 428 66 12 grass_block
execute in minecraft:overworld run fill 428 67 12 428 144 12 air
execute in minecraft:overworld run fill 428 58 13 428 64 13 stone
execute in minecraft:overworld run fill 428 65 13 428 66 13 dirt
execute in minecraft:overworld run setblock 428 67 13 coarse_dirt
execute in minecraft:overworld run fill 428 68 13 428 144 13 air
execute in minecraft:overworld run fill 428 58 14 428 64 14 stone
execute in minecraft:overworld run fill 428 65 14 428 66 14 dirt
execute in minecraft:overworld run setblock 428 67 14 coarse_dirt
execute in minecraft:overworld run fill 428 68 14 428 144 14 air
execute in minecraft:overworld run fill 428 58 15 428 64 15 stone
execute in minecraft:overworld run fill 428 65 15 428 66 15 dirt
execute in minecraft:overworld run setblock 428 67 15 coarse_dirt
execute in minecraft:overworld run fill 428 68 15 428 144 15 air
execute in minecraft:overworld run fill 428 58 16 428 64 16 stone
execute in minecraft:overworld run fill 428 65 16 428 66 16 dirt
execute in minecraft:overworld run setblock 428 67 16 coarse_dirt
execute in minecraft:overworld run fill 428 68 16 428 144 16 air
execute in minecraft:overworld run fill 428 58 17 428 64 17 stone
execute in minecraft:overworld run fill 428 65 17 428 66 17 dirt
execute in minecraft:overworld run setblock 428 67 17 grass_block
execute in minecraft:overworld run fill 428 68 17 428 144 17 air
execute in minecraft:overworld run fill 428 58 18 428 64 18 stone
execute in minecraft:overworld run fill 428 65 18 428 66 18 dirt
execute in minecraft:overworld run setblock 428 67 18 grass_block
execute in minecraft:overworld run fill 428 68 18 428 144 18 air
execute in minecraft:overworld run fill 428 58 19 428 64 19 stone
execute in minecraft:overworld run fill 428 65 19 428 66 19 dirt
execute in minecraft:overworld run setblock 428 67 19 coarse_dirt
execute in minecraft:overworld run fill 428 68 19 428 144 19 air
execute in minecraft:overworld run fill 428 58 20 428 64 20 stone
execute in minecraft:overworld run fill 428 65 20 428 66 20 dirt
execute in minecraft:overworld run setblock 428 67 20 grass_block
execute in minecraft:overworld run fill 428 68 20 428 144 20 air
execute in minecraft:overworld run fill 428 58 21 428 65 21 stone
execute in minecraft:overworld run fill 428 66 21 428 67 21 dirt
execute in minecraft:overworld run setblock 428 68 21 grass_block
execute in minecraft:overworld run fill 428 69 21 428 144 21 air
execute in minecraft:overworld run fill 428 58 22 428 65 22 stone
execute in minecraft:overworld run fill 428 66 22 428 67 22 dirt
execute in minecraft:overworld run setblock 428 68 22 coarse_dirt
execute in minecraft:overworld run fill 428 69 22 428 144 22 air
execute in minecraft:overworld run fill 428 58 23 428 65 23 stone
execute in minecraft:overworld run fill 428 66 23 428 67 23 dirt
execute in minecraft:overworld run setblock 428 68 23 grass_block
execute in minecraft:overworld run fill 428 69 23 428 144 23 air
execute in minecraft:overworld run fill 428 58 24 428 65 24 stone
execute in minecraft:overworld run fill 428 66 24 428 67 24 dirt
execute in minecraft:overworld run setblock 428 68 24 grass_block
execute in minecraft:overworld run fill 428 69 24 428 144 24 air
execute in minecraft:overworld run fill 428 58 25 428 65 25 stone
execute in minecraft:overworld run fill 428 66 25 428 67 25 dirt
execute in minecraft:overworld run setblock 428 68 25 grass_block
execute in minecraft:overworld run fill 428 69 25 428 144 25 air
execute in minecraft:overworld run fill 428 58 26 428 65 26 stone
execute in minecraft:overworld run fill 428 66 26 428 67 26 dirt
execute in minecraft:overworld run setblock 428 68 26 coarse_dirt
execute in minecraft:overworld run fill 428 69 26 428 144 26 air
execute in minecraft:overworld run fill 428 58 27 428 65 27 stone
execute in minecraft:overworld run fill 428 66 27 428 67 27 dirt
execute in minecraft:overworld run setblock 428 68 27 coarse_dirt
execute in minecraft:overworld run fill 428 69 27 428 144 27 air
execute in minecraft:overworld run fill 428 58 28 428 65 28 stone
execute in minecraft:overworld run fill 428 66 28 428 67 28 dirt
execute in minecraft:overworld run setblock 428 68 28 grass_block
execute in minecraft:overworld run fill 428 69 28 428 144 28 air
execute in minecraft:overworld run fill 428 58 29 428 65 29 stone
execute in minecraft:overworld run fill 428 66 29 428 67 29 dirt
execute in minecraft:overworld run setblock 428 68 29 coarse_dirt
execute in minecraft:overworld run fill 428 69 29 428 144 29 air
execute in minecraft:overworld run fill 428 58 30 428 65 30 stone
execute in minecraft:overworld run fill 428 66 30 428 67 30 dirt
execute in minecraft:overworld run setblock 428 68 30 coarse_dirt
execute in minecraft:overworld run fill 428 69 30 428 144 30 air
execute in minecraft:overworld run fill 428 58 31 428 65 31 stone
execute in minecraft:overworld run fill 428 66 31 428 67 31 dirt
execute in minecraft:overworld run setblock 428 68 31 coarse_dirt
execute in minecraft:overworld run fill 428 69 31 428 144 31 air
execute in minecraft:overworld run fill 428 58 32 428 65 32 stone
execute in minecraft:overworld run fill 428 66 32 428 67 32 dirt
execute in minecraft:overworld run setblock 428 68 32 coarse_dirt
execute in minecraft:overworld run fill 428 69 32 428 144 32 air
execute in minecraft:overworld run fill 428 58 33 428 65 33 stone
execute in minecraft:overworld run fill 428 66 33 428 67 33 dirt
execute in minecraft:overworld run setblock 428 68 33 grass_block
execute in minecraft:overworld run fill 428 69 33 428 144 33 air
execute in minecraft:overworld run fill 428 58 34 428 65 34 stone
execute in minecraft:overworld run fill 428 66 34 428 67 34 dirt
execute in minecraft:overworld run setblock 428 68 34 coarse_dirt
execute in minecraft:overworld run fill 428 69 34 428 144 34 air
execute in minecraft:overworld run fill 428 58 35 428 65 35 stone
execute in minecraft:overworld run fill 428 66 35 428 67 35 dirt
execute in minecraft:overworld run setblock 428 68 35 grass_block
execute in minecraft:overworld run fill 428 69 35 428 144 35 air
execute in minecraft:overworld run fill 428 58 36 428 64 36 stone
execute in minecraft:overworld run fill 428 65 36 428 66 36 dirt
execute in minecraft:overworld run setblock 428 67 36 grass_block
execute in minecraft:overworld run fill 428 68 36 428 144 36 air
execute in minecraft:overworld run fill 428 58 37 428 64 37 stone
execute in minecraft:overworld run fill 428 65 37 428 66 37 dirt
execute in minecraft:overworld run setblock 428 67 37 grass_block
execute in minecraft:overworld run fill 428 68 37 428 144 37 air
execute in minecraft:overworld run fill 428 58 38 428 64 38 stone
execute in minecraft:overworld run fill 428 65 38 428 66 38 dirt
execute in minecraft:overworld run setblock 428 67 38 coarse_dirt
execute in minecraft:overworld run fill 428 68 38 428 144 38 air
execute in minecraft:overworld run fill 428 58 39 428 64 39 stone
execute in minecraft:overworld run fill 428 65 39 428 66 39 dirt
execute in minecraft:overworld run setblock 428 67 39 coarse_dirt
execute in minecraft:overworld run fill 428 68 39 428 144 39 air
execute in minecraft:overworld run fill 428 58 40 428 63 40 stone
execute in minecraft:overworld run fill 428 64 40 428 65 40 dirt
execute in minecraft:overworld run setblock 428 66 40 coarse_dirt
execute in minecraft:overworld run fill 428 67 40 428 144 40 air
execute in minecraft:overworld run fill 428 58 41 428 63 41 stone
execute in minecraft:overworld run fill 428 64 41 428 65 41 dirt
execute in minecraft:overworld run setblock 428 66 41 grass_block
execute in minecraft:overworld run fill 428 67 41 428 144 41 air
execute in minecraft:overworld run fill 428 58 42 428 63 42 stone
execute in minecraft:overworld run fill 428 64 42 428 65 42 dirt
execute in minecraft:overworld run setblock 428 66 42 grass_block
execute in minecraft:overworld run fill 428 67 42 428 144 42 air
execute in minecraft:overworld run fill 428 58 43 428 63 43 stone
execute in minecraft:overworld run fill 428 64 43 428 65 43 dirt
execute in minecraft:overworld run setblock 428 66 43 grass_block
execute in minecraft:overworld run fill 428 67 43 428 144 43 air
execute in minecraft:overworld run fill 428 58 44 428 62 44 stone
execute in minecraft:overworld run fill 428 63 44 428 64 44 dirt
execute in minecraft:overworld run setblock 428 65 44 coarse_dirt
execute in minecraft:overworld run fill 428 66 44 428 144 44 air
execute in minecraft:overworld run fill 428 58 45 428 62 45 stone
execute in minecraft:overworld run fill 428 63 45 428 64 45 dirt
execute in minecraft:overworld run setblock 428 65 45 coarse_dirt
execute in minecraft:overworld run fill 428 66 45 428 144 45 air
execute in minecraft:overworld run fill 428 58 46 428 61 46 stone
execute in minecraft:overworld run fill 428 62 46 428 63 46 dirt
execute in minecraft:overworld run setblock 428 64 46 coarse_dirt
execute in minecraft:overworld run fill 428 65 46 428 144 46 air
execute in minecraft:overworld run fill 428 58 47 428 61 47 stone
execute in minecraft:overworld run fill 428 62 47 428 63 47 dirt
execute in minecraft:overworld run setblock 428 64 47 grass_block
execute in minecraft:overworld run fill 428 65 47 428 144 47 air
execute in minecraft:overworld run fill 429 58 -48 429 61 -48 stone
execute in minecraft:overworld run fill 429 62 -48 429 63 -48 dirt
execute in minecraft:overworld run setblock 429 64 -48 grass_block
execute in minecraft:overworld run fill 429 65 -48 429 144 -48 air
execute in minecraft:overworld run fill 429 58 -47 429 63 -47 stone
execute in minecraft:overworld run fill 429 64 -47 429 65 -47 dirt
execute in minecraft:overworld run setblock 429 66 -47 coarse_dirt
execute in minecraft:overworld run fill 429 67 -47 429 144 -47 air
execute in minecraft:overworld run fill 429 58 -46 429 64 -46 stone
execute in minecraft:overworld run fill 429 65 -46 429 66 -46 dirt
execute in minecraft:overworld run setblock 429 67 -46 coarse_dirt
execute in minecraft:overworld run fill 429 68 -46 429 144 -46 air
execute in minecraft:overworld run fill 429 58 -45 429 66 -45 stone
execute in minecraft:overworld run fill 429 67 -45 429 68 -45 dirt
execute in minecraft:overworld run setblock 429 69 -45 grass_block
execute in minecraft:overworld run fill 429 70 -45 429 144 -45 air
execute in minecraft:overworld run fill 429 58 -44 429 66 -44 stone
execute in minecraft:overworld run fill 429 67 -44 429 68 -44 dirt
execute in minecraft:overworld run setblock 429 69 -44 coarse_dirt
execute in minecraft:overworld run fill 429 70 -44 429 144 -44 air
execute in minecraft:overworld run fill 429 58 -43 429 66 -43 stone
execute in minecraft:overworld run fill 429 67 -43 429 68 -43 dirt
execute in minecraft:overworld run setblock 429 69 -43 coarse_dirt
execute in minecraft:overworld run fill 429 70 -43 429 144 -43 air
execute in minecraft:overworld run fill 429 58 -42 429 66 -42 stone
execute in minecraft:overworld run fill 429 67 -42 429 68 -42 dirt
execute in minecraft:overworld run setblock 429 69 -42 coarse_dirt
execute in minecraft:overworld run fill 429 70 -42 429 144 -42 air
execute in minecraft:overworld run fill 429 58 -41 429 66 -41 stone
execute in minecraft:overworld run fill 429 67 -41 429 68 -41 dirt
execute in minecraft:overworld run setblock 429 69 -41 coarse_dirt
execute in minecraft:overworld run fill 429 70 -41 429 144 -41 air
execute in minecraft:overworld run fill 429 58 -40 429 66 -40 stone
execute in minecraft:overworld run fill 429 67 -40 429 68 -40 dirt
execute in minecraft:overworld run setblock 429 69 -40 grass_block
execute in minecraft:overworld run fill 429 70 -40 429 144 -40 air
execute in minecraft:overworld run fill 429 58 -39 429 66 -39 stone
execute in minecraft:overworld run fill 429 67 -39 429 68 -39 dirt
execute in minecraft:overworld run setblock 429 69 -39 coarse_dirt
execute in minecraft:overworld run fill 429 70 -39 429 144 -39 air
execute in minecraft:overworld run fill 429 58 -38 429 66 -38 stone
execute in minecraft:overworld run fill 429 67 -38 429 68 -38 dirt
execute in minecraft:overworld run setblock 429 69 -38 coarse_dirt
execute in minecraft:overworld run fill 429 70 -38 429 144 -38 air
execute in minecraft:overworld run fill 429 58 -37 429 65 -37 stone
execute in minecraft:overworld run fill 429 66 -37 429 67 -37 dirt
execute in minecraft:overworld run setblock 429 68 -37 coarse_dirt
execute in minecraft:overworld run fill 429 69 -37 429 144 -37 air
execute in minecraft:overworld run fill 429 58 -36 429 65 -36 stone
execute in minecraft:overworld run fill 429 66 -36 429 67 -36 dirt
execute in minecraft:overworld run setblock 429 68 -36 grass_block
execute in minecraft:overworld run fill 429 69 -36 429 144 -36 air
execute in minecraft:overworld run fill 429 58 -35 429 65 -35 stone
execute in minecraft:overworld run fill 429 66 -35 429 67 -35 dirt
execute in minecraft:overworld run setblock 429 68 -35 coarse_dirt
execute in minecraft:overworld run fill 429 69 -35 429 144 -35 air
execute in minecraft:overworld run fill 429 58 -34 429 65 -34 stone
execute in minecraft:overworld run fill 429 66 -34 429 67 -34 dirt
execute in minecraft:overworld run setblock 429 68 -34 coarse_dirt
execute in minecraft:overworld run fill 429 69 -34 429 144 -34 air
execute in minecraft:overworld run fill 429 58 -33 429 65 -33 stone
execute in minecraft:overworld run fill 429 66 -33 429 67 -33 dirt
execute in minecraft:overworld run setblock 429 68 -33 coarse_dirt
execute in minecraft:overworld run fill 429 69 -33 429 144 -33 air
execute in minecraft:overworld run fill 429 58 -32 429 65 -32 stone
execute in minecraft:overworld run fill 429 66 -32 429 67 -32 dirt
execute in minecraft:overworld run setblock 429 68 -32 coarse_dirt
execute in minecraft:overworld run fill 429 69 -32 429 144 -32 air
execute in minecraft:overworld run fill 429 58 -31 429 64 -31 stone
execute in minecraft:overworld run fill 429 65 -31 429 66 -31 dirt
execute in minecraft:overworld run setblock 429 67 -31 grass_block
execute in minecraft:overworld run fill 429 68 -31 429 144 -31 air
execute in minecraft:overworld run fill 429 58 -30 429 64 -30 stone
execute in minecraft:overworld run fill 429 65 -30 429 66 -30 dirt
execute in minecraft:overworld run setblock 429 67 -30 coarse_dirt
execute in minecraft:overworld run fill 429 68 -30 429 144 -30 air
execute in minecraft:overworld run fill 429 58 -29 429 64 -29 stone
execute in minecraft:overworld run fill 429 65 -29 429 66 -29 dirt
execute in minecraft:overworld run setblock 429 67 -29 grass_block
execute in minecraft:overworld run fill 429 68 -29 429 144 -29 air
execute in minecraft:overworld run fill 429 58 -28 429 64 -28 stone
execute in minecraft:overworld run fill 429 65 -28 429 66 -28 dirt
execute in minecraft:overworld run setblock 429 67 -28 coarse_dirt
execute in minecraft:overworld run fill 429 68 -28 429 144 -28 air
execute in minecraft:overworld run fill 429 58 -27 429 64 -27 stone
execute in minecraft:overworld run fill 429 65 -27 429 66 -27 dirt
execute in minecraft:overworld run setblock 429 67 -27 grass_block
execute in minecraft:overworld run fill 429 68 -27 429 144 -27 air
execute in minecraft:overworld run fill 429 58 -26 429 64 -26 stone
execute in minecraft:overworld run fill 429 65 -26 429 66 -26 dirt
execute in minecraft:overworld run setblock 429 67 -26 grass_block
schedule function blade_gallery:random/battlefield/part_146 1t replace
