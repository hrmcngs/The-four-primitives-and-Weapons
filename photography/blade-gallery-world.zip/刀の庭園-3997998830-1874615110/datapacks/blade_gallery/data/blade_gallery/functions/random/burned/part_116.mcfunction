execute in minecraft:overworld run setblock 281 78 -27 grass_block
execute in minecraft:overworld run fill 281 79 -27 281 144 -27 air
execute in minecraft:overworld run fill 281 58 -26 281 75 -26 stone
execute in minecraft:overworld run fill 281 76 -26 281 77 -26 dirt
execute in minecraft:overworld run setblock 281 78 -26 coarse_dirt
execute in minecraft:overworld run fill 281 79 -26 281 144 -26 air
execute in minecraft:overworld run fill 281 58 -25 281 74 -25 stone
execute in minecraft:overworld run fill 281 75 -25 281 76 -25 dirt
execute in minecraft:overworld run setblock 281 77 -25 coarse_dirt
execute in minecraft:overworld run fill 281 78 -25 281 144 -25 air
execute in minecraft:overworld run fill 281 58 -24 281 74 -24 stone
execute in minecraft:overworld run fill 281 75 -24 281 76 -24 dirt
execute in minecraft:overworld run setblock 281 77 -24 coarse_dirt
execute in minecraft:overworld run fill 281 78 -24 281 144 -24 air
execute in minecraft:overworld run fill 281 58 -23 281 74 -23 stone
execute in minecraft:overworld run fill 281 75 -23 281 76 -23 dirt
execute in minecraft:overworld run setblock 281 77 -23 grass_block
execute in minecraft:overworld run fill 281 78 -23 281 144 -23 air
execute in minecraft:overworld run fill 281 58 -22 281 74 -22 stone
execute in minecraft:overworld run fill 281 75 -22 281 76 -22 dirt
execute in minecraft:overworld run setblock 281 77 -22 grass_block
execute in minecraft:overworld run fill 281 78 -22 281 144 -22 air
execute in minecraft:overworld run fill 281 58 -21 281 73 -21 stone
execute in minecraft:overworld run fill 281 74 -21 281 75 -21 dirt
execute in minecraft:overworld run setblock 281 76 -21 coarse_dirt
execute in minecraft:overworld run fill 281 77 -21 281 144 -21 air
execute in minecraft:overworld run fill 281 58 -20 281 73 -20 stone
execute in minecraft:overworld run fill 281 74 -20 281 75 -20 dirt
execute in minecraft:overworld run setblock 281 76 -20 coarse_dirt
execute in minecraft:overworld run fill 281 77 -20 281 144 -20 air
execute in minecraft:overworld run fill 281 58 -19 281 73 -19 stone
execute in minecraft:overworld run fill 281 74 -19 281 75 -19 dirt
execute in minecraft:overworld run setblock 281 76 -19 coarse_dirt
execute in minecraft:overworld run fill 281 77 -19 281 144 -19 air
execute in minecraft:overworld run fill 281 58 -18 281 72 -18 stone
execute in minecraft:overworld run fill 281 73 -18 281 74 -18 dirt
execute in minecraft:overworld run setblock 281 75 -18 grass_block
execute in minecraft:overworld run fill 281 76 -18 281 144 -18 air
execute in minecraft:overworld run fill 281 58 -17 281 72 -17 stone
execute in minecraft:overworld run fill 281 73 -17 281 74 -17 dirt
execute in minecraft:overworld run setblock 281 75 -17 grass_block
execute in minecraft:overworld run fill 281 76 -17 281 144 -17 air
execute in minecraft:overworld run fill 281 58 -16 281 71 -16 stone
execute in minecraft:overworld run fill 281 72 -16 281 73 -16 dirt
execute in minecraft:overworld run setblock 281 74 -16 coarse_dirt
execute in minecraft:overworld run fill 281 75 -16 281 144 -16 air
execute in minecraft:overworld run fill 281 58 -15 281 71 -15 stone
execute in minecraft:overworld run fill 281 72 -15 281 73 -15 dirt
execute in minecraft:overworld run setblock 281 74 -15 coarse_dirt
execute in minecraft:overworld run fill 281 75 -15 281 144 -15 air
execute in minecraft:overworld run fill 281 58 -14 281 70 -14 stone
execute in minecraft:overworld run fill 281 71 -14 281 72 -14 dirt
execute in minecraft:overworld run setblock 281 73 -14 coarse_dirt
execute in minecraft:overworld run fill 281 74 -14 281 144 -14 air
execute in minecraft:overworld run fill 281 58 -13 281 69 -13 stone
execute in minecraft:overworld run fill 281 70 -13 281 71 -13 dirt
execute in minecraft:overworld run setblock 281 72 -13 grass_block
execute in minecraft:overworld run fill 281 73 -13 281 144 -13 air
execute in minecraft:overworld run fill 281 58 -12 281 69 -12 stone
execute in minecraft:overworld run fill 281 70 -12 281 71 -12 dirt
execute in minecraft:overworld run setblock 281 72 -12 grass_block
execute in minecraft:overworld run fill 281 73 -12 281 144 -12 air
execute in minecraft:overworld run fill 281 58 -11 281 68 -11 stone
execute in minecraft:overworld run fill 281 69 -11 281 70 -11 dirt
execute in minecraft:overworld run setblock 281 71 -11 coarse_dirt
execute in minecraft:overworld run fill 281 72 -11 281 144 -11 air
execute in minecraft:overworld run fill 281 58 -10 281 68 -10 stone
execute in minecraft:overworld run fill 281 69 -10 281 70 -10 dirt
execute in minecraft:overworld run setblock 281 71 -10 grass_block
execute in minecraft:overworld run fill 281 72 -10 281 144 -10 air
execute in minecraft:overworld run fill 281 58 -9 281 68 -9 stone
execute in minecraft:overworld run fill 281 69 -9 281 70 -9 dirt
execute in minecraft:overworld run setblock 281 71 -9 coarse_dirt
execute in minecraft:overworld run fill 281 72 -9 281 144 -9 air
execute in minecraft:overworld run fill 281 58 -8 281 68 -8 stone
execute in minecraft:overworld run fill 281 69 -8 281 70 -8 dirt
execute in minecraft:overworld run setblock 281 71 -8 coarse_dirt
execute in minecraft:overworld run fill 281 72 -8 281 144 -8 air
execute in minecraft:overworld run fill 281 58 -7 281 68 -7 stone
execute in minecraft:overworld run fill 281 69 -7 281 70 -7 dirt
execute in minecraft:overworld run setblock 281 71 -7 coarse_dirt
execute in minecraft:overworld run fill 281 72 -7 281 144 -7 air
execute in minecraft:overworld run fill 281 58 -6 281 68 -6 stone
execute in minecraft:overworld run fill 281 69 -6 281 70 -6 dirt
execute in minecraft:overworld run setblock 281 71 -6 coarse_dirt
execute in minecraft:overworld run fill 281 72 -6 281 144 -6 air
execute in minecraft:overworld run fill 281 58 -5 281 68 -5 stone
execute in minecraft:overworld run fill 281 69 -5 281 70 -5 dirt
execute in minecraft:overworld run setblock 281 71 -5 grass_block
execute in minecraft:overworld run fill 281 72 -5 281 144 -5 air
execute in minecraft:overworld run setblock 281 72 -5 grass
execute in minecraft:overworld run fill 281 58 -4 281 68 -4 stone
execute in minecraft:overworld run fill 281 69 -4 281 70 -4 dirt
execute in minecraft:overworld run setblock 281 71 -4 grass_block
execute in minecraft:overworld run fill 281 72 -4 281 144 -4 air
execute in minecraft:overworld run fill 281 58 -3 281 68 -3 stone
execute in minecraft:overworld run fill 281 69 -3 281 70 -3 dirt
execute in minecraft:overworld run setblock 281 71 -3 grass_block
execute in minecraft:overworld run fill 281 72 -3 281 144 -3 air
execute in minecraft:overworld run fill 281 58 -2 281 68 -2 stone
execute in minecraft:overworld run fill 281 69 -2 281 70 -2 dirt
execute in minecraft:overworld run setblock 281 71 -2 coarse_dirt
execute in minecraft:overworld run fill 281 72 -2 281 144 -2 air
execute in minecraft:overworld run fill 281 58 -1 281 68 -1 stone
execute in minecraft:overworld run fill 281 69 -1 281 70 -1 dirt
execute in minecraft:overworld run setblock 281 71 -1 coarse_dirt
execute in minecraft:overworld run fill 281 72 -1 281 144 -1 air
execute in minecraft:overworld run setblock 281 72 -1 mossy_cobblestone
execute in minecraft:overworld run fill 281 58 0 281 68 0 stone
execute in minecraft:overworld run fill 281 69 0 281 70 0 dirt
execute in minecraft:overworld run setblock 281 71 0 coarse_dirt
execute in minecraft:overworld run fill 281 72 0 281 144 0 air
execute in minecraft:overworld run fill 281 58 1 281 68 1 stone
execute in minecraft:overworld run fill 281 69 1 281 70 1 dirt
execute in minecraft:overworld run setblock 281 71 1 grass_block
execute in minecraft:overworld run fill 281 72 1 281 144 1 air
execute in minecraft:overworld run fill 281 58 2 281 67 2 stone
execute in minecraft:overworld run fill 281 68 2 281 69 2 dirt
execute in minecraft:overworld run setblock 281 70 2 grass_block
execute in minecraft:overworld run fill 281 71 2 281 144 2 air
execute in minecraft:overworld run fill 281 58 3 281 67 3 stone
execute in minecraft:overworld run fill 281 68 3 281 69 3 dirt
execute in minecraft:overworld run setblock 281 70 3 coarse_dirt
execute in minecraft:overworld run fill 281 71 3 281 144 3 air
execute in minecraft:overworld run setblock 281 71 3 grass
execute in minecraft:overworld run fill 281 58 4 281 67 4 stone
execute in minecraft:overworld run fill 281 68 4 281 69 4 dirt
execute in minecraft:overworld run setblock 281 70 4 coarse_dirt
execute in minecraft:overworld run fill 281 71 4 281 144 4 air
execute in minecraft:overworld run fill 281 58 5 281 67 5 stone
execute in minecraft:overworld run fill 281 68 5 281 69 5 dirt
execute in minecraft:overworld run setblock 281 70 5 coarse_dirt
execute in minecraft:overworld run fill 281 71 5 281 144 5 air
execute in minecraft:overworld run fill 281 58 6 281 66 6 stone
execute in minecraft:overworld run fill 281 67 6 281 68 6 dirt
execute in minecraft:overworld run setblock 281 69 6 coarse_dirt
execute in minecraft:overworld run fill 281 70 6 281 144 6 air
execute in minecraft:overworld run fill 281 58 7 281 66 7 stone
execute in minecraft:overworld run fill 281 67 7 281 68 7 dirt
execute in minecraft:overworld run setblock 281 69 7 grass_block
execute in minecraft:overworld run fill 281 70 7 281 144 7 air
execute in minecraft:overworld run fill 281 58 8 281 66 8 stone
execute in minecraft:overworld run fill 281 67 8 281 68 8 dirt
execute in minecraft:overworld run setblock 281 69 8 coarse_dirt
execute in minecraft:overworld run fill 281 70 8 281 144 8 air
execute in minecraft:overworld run fill 281 58 9 281 66 9 stone
execute in minecraft:overworld run fill 281 67 9 281 68 9 dirt
execute in minecraft:overworld run setblock 281 69 9 coarse_dirt
execute in minecraft:overworld run fill 281 70 9 281 144 9 air
execute in minecraft:overworld run fill 281 58 10 281 65 10 stone
execute in minecraft:overworld run fill 281 66 10 281 67 10 dirt
execute in minecraft:overworld run setblock 281 68 10 coarse_dirt
execute in minecraft:overworld run fill 281 69 10 281 144 10 air
execute in minecraft:overworld run fill 281 58 11 281 65 11 stone
execute in minecraft:overworld run fill 281 66 11 281 67 11 dirt
execute in minecraft:overworld run setblock 281 68 11 grass_block
execute in minecraft:overworld run fill 281 69 11 281 144 11 air
execute in minecraft:overworld run fill 281 58 12 281 65 12 stone
execute in minecraft:overworld run fill 281 66 12 281 67 12 dirt
execute in minecraft:overworld run setblock 281 68 12 coarse_dirt
execute in minecraft:overworld run fill 281 69 12 281 144 12 air
execute in minecraft:overworld run fill 281 58 13 281 65 13 stone
execute in minecraft:overworld run fill 281 66 13 281 67 13 dirt
execute in minecraft:overworld run setblock 281 68 13 grass_block
execute in minecraft:overworld run fill 281 69 13 281 144 13 air
execute in minecraft:overworld run fill 281 58 14 281 65 14 stone
execute in minecraft:overworld run fill 281 66 14 281 67 14 dirt
execute in minecraft:overworld run setblock 281 68 14 grass_block
execute in minecraft:overworld run fill 281 69 14 281 144 14 air
execute in minecraft:overworld run fill 281 58 15 281 65 15 stone
execute in minecraft:overworld run fill 281 66 15 281 67 15 dirt
execute in minecraft:overworld run setblock 281 68 15 coarse_dirt
execute in minecraft:overworld run fill 281 69 15 281 144 15 air
execute in minecraft:overworld run fill 281 58 16 281 65 16 stone
execute in minecraft:overworld run fill 281 66 16 281 67 16 dirt
execute in minecraft:overworld run setblock 281 68 16 grass_block
execute in minecraft:overworld run fill 281 69 16 281 144 16 air
execute in minecraft:overworld run fill 281 58 17 281 64 17 stone
execute in minecraft:overworld run fill 281 65 17 281 66 17 dirt
execute in minecraft:overworld run setblock 281 67 17 coarse_dirt
execute in minecraft:overworld run fill 281 68 17 281 144 17 air
execute in minecraft:overworld run fill 281 58 18 281 64 18 stone
execute in minecraft:overworld run fill 281 65 18 281 66 18 dirt
execute in minecraft:overworld run setblock 281 67 18 coarse_dirt
execute in minecraft:overworld run fill 281 68 18 281 144 18 air
execute in minecraft:overworld run fill 281 58 19 281 64 19 stone
execute in minecraft:overworld run fill 281 65 19 281 66 19 dirt
execute in minecraft:overworld run setblock 281 67 19 coarse_dirt
execute in minecraft:overworld run fill 281 68 19 281 144 19 air
execute in minecraft:overworld run fill 281 58 20 281 64 20 stone
execute in minecraft:overworld run fill 281 65 20 281 66 20 dirt
execute in minecraft:overworld run setblock 281 67 20 grass_block
execute in minecraft:overworld run fill 281 68 20 281 144 20 air
execute in minecraft:overworld run fill 281 58 21 281 64 21 stone
execute in minecraft:overworld run fill 281 65 21 281 66 21 dirt
execute in minecraft:overworld run setblock 281 67 21 coarse_dirt
execute in minecraft:overworld run fill 281 68 21 281 144 21 air
execute in minecraft:overworld run setblock 281 68 21 grass
execute in minecraft:overworld run fill 281 58 22 281 63 22 stone
execute in minecraft:overworld run fill 281 64 22 281 65 22 dirt
execute in minecraft:overworld run setblock 281 66 22 grass_block
execute in minecraft:overworld run fill 281 67 22 281 144 22 air
execute in minecraft:overworld run fill 281 58 23 281 63 23 stone
execute in minecraft:overworld run fill 281 64 23 281 65 23 dirt
execute in minecraft:overworld run setblock 281 66 23 coarse_dirt
execute in minecraft:overworld run fill 281 67 23 281 144 23 air
execute in minecraft:overworld run fill 281 58 24 281 63 24 stone
execute in minecraft:overworld run fill 281 64 24 281 65 24 dirt
execute in minecraft:overworld run setblock 281 66 24 coarse_dirt
execute in minecraft:overworld run fill 281 67 24 281 144 24 air
execute in minecraft:overworld run fill 281 58 25 281 63 25 stone
execute in minecraft:overworld run fill 281 64 25 281 65 25 dirt
execute in minecraft:overworld run setblock 281 66 25 coarse_dirt
execute in minecraft:overworld run fill 281 67 25 281 144 25 air
execute in minecraft:overworld run fill 281 58 26 281 63 26 stone
execute in minecraft:overworld run fill 281 64 26 281 65 26 dirt
execute in minecraft:overworld run setblock 281 66 26 coarse_dirt
execute in minecraft:overworld run fill 281 67 26 281 144 26 air
execute in minecraft:overworld run fill 281 58 27 281 63 27 stone
execute in minecraft:overworld run fill 281 64 27 281 65 27 dirt
execute in minecraft:overworld run setblock 281 66 27 coarse_dirt
execute in minecraft:overworld run fill 281 67 27 281 144 27 air
execute in minecraft:overworld run fill 281 58 28 281 63 28 stone
execute in minecraft:overworld run fill 281 64 28 281 65 28 dirt
execute in minecraft:overworld run setblock 281 66 28 coarse_dirt
execute in minecraft:overworld run fill 281 67 28 281 144 28 air
execute in minecraft:overworld run fill 281 58 29 281 63 29 stone
execute in minecraft:overworld run fill 281 64 29 281 65 29 dirt
execute in minecraft:overworld run setblock 281 66 29 coarse_dirt
execute in minecraft:overworld run fill 281 67 29 281 144 29 air
execute in minecraft:overworld run fill 281 58 30 281 63 30 stone
execute in minecraft:overworld run fill 281 64 30 281 65 30 dirt
execute in minecraft:overworld run setblock 281 66 30 coarse_dirt
execute in minecraft:overworld run fill 281 67 30 281 144 30 air
execute in minecraft:overworld run fill 281 58 31 281 62 31 stone
execute in minecraft:overworld run fill 281 63 31 281 64 31 dirt
execute in minecraft:overworld run setblock 281 65 31 coarse_dirt
execute in minecraft:overworld run fill 281 66 31 281 144 31 air
execute in minecraft:overworld run fill 281 58 32 281 62 32 stone
execute in minecraft:overworld run fill 281 63 32 281 64 32 dirt
execute in minecraft:overworld run setblock 281 65 32 grass_block
execute in minecraft:overworld run fill 281 66 32 281 144 32 air
execute in minecraft:overworld run fill 281 58 33 281 62 33 stone
execute in minecraft:overworld run fill 281 63 33 281 64 33 dirt
execute in minecraft:overworld run setblock 281 65 33 coarse_dirt
execute in minecraft:overworld run fill 281 66 33 281 144 33 air
execute in minecraft:overworld run setblock 281 66 33 grass
execute in minecraft:overworld run fill 281 58 34 281 62 34 stone
execute in minecraft:overworld run fill 281 63 34 281 64 34 dirt
execute in minecraft:overworld run setblock 281 65 34 grass_block
execute in minecraft:overworld run fill 281 66 34 281 144 34 air
execute in minecraft:overworld run fill 281 58 35 281 61 35 stone
execute in minecraft:overworld run fill 281 62 35 281 63 35 dirt
execute in minecraft:overworld run setblock 281 64 35 coarse_dirt
execute in minecraft:overworld run fill 281 65 35 281 144 35 air
execute in minecraft:overworld run fill 281 58 36 281 61 36 stone
schedule function blade_gallery:random/burned/part_117 1t replace
