execute in minecraft:overworld run setblock 293 72 2 coarse_dirt
execute in minecraft:overworld run fill 293 73 2 293 144 2 air
execute in minecraft:overworld run fill 293 58 3 293 69 3 stone
execute in minecraft:overworld run fill 293 70 3 293 71 3 dirt
execute in minecraft:overworld run setblock 293 72 3 coarse_dirt
execute in minecraft:overworld run fill 293 73 3 293 144 3 air
execute in minecraft:overworld run fill 293 58 4 293 69 4 stone
execute in minecraft:overworld run fill 293 70 4 293 71 4 dirt
execute in minecraft:overworld run setblock 293 72 4 coarse_dirt
execute in minecraft:overworld run fill 293 73 4 293 144 4 air
execute in minecraft:overworld run fill 293 58 5 293 68 5 stone
execute in minecraft:overworld run fill 293 69 5 293 70 5 dirt
execute in minecraft:overworld run setblock 293 71 5 coarse_dirt
execute in minecraft:overworld run fill 293 72 5 293 144 5 air
execute in minecraft:overworld run fill 293 58 6 293 68 6 stone
execute in minecraft:overworld run fill 293 69 6 293 70 6 dirt
execute in minecraft:overworld run setblock 293 71 6 coarse_dirt
execute in minecraft:overworld run fill 293 72 6 293 144 6 air
execute in minecraft:overworld run fill 293 58 7 293 67 7 stone
execute in minecraft:overworld run fill 293 68 7 293 69 7 dirt
execute in minecraft:overworld run setblock 293 70 7 grass_block
execute in minecraft:overworld run fill 293 71 7 293 144 7 air
execute in minecraft:overworld run fill 293 58 8 293 67 8 stone
execute in minecraft:overworld run fill 293 68 8 293 69 8 dirt
execute in minecraft:overworld run setblock 293 70 8 grass_block
execute in minecraft:overworld run fill 293 71 8 293 144 8 air
execute in minecraft:overworld run fill 293 58 9 293 67 9 stone
execute in minecraft:overworld run fill 293 68 9 293 69 9 dirt
execute in minecraft:overworld run setblock 293 70 9 grass_block
execute in minecraft:overworld run fill 293 71 9 293 144 9 air
execute in minecraft:overworld run fill 293 58 10 293 67 10 stone
execute in minecraft:overworld run fill 293 68 10 293 69 10 dirt
execute in minecraft:overworld run setblock 293 70 10 grass_block
execute in minecraft:overworld run fill 293 71 10 293 144 10 air
execute in minecraft:overworld run fill 293 58 11 293 66 11 stone
execute in minecraft:overworld run fill 293 67 11 293 68 11 dirt
execute in minecraft:overworld run setblock 293 69 11 grass_block
execute in minecraft:overworld run fill 293 70 11 293 144 11 air
execute in minecraft:overworld run fill 293 58 12 293 66 12 stone
execute in minecraft:overworld run fill 293 67 12 293 68 12 dirt
execute in minecraft:overworld run setblock 293 69 12 coarse_dirt
execute in minecraft:overworld run fill 293 70 12 293 144 12 air
execute in minecraft:overworld run setblock 293 70 12 mossy_cobblestone
execute in minecraft:overworld run fill 293 58 13 293 66 13 stone
execute in minecraft:overworld run fill 293 67 13 293 68 13 dirt
execute in minecraft:overworld run setblock 293 69 13 grass_block
execute in minecraft:overworld run fill 293 70 13 293 144 13 air
execute in minecraft:overworld run fill 293 58 14 293 66 14 stone
execute in minecraft:overworld run fill 293 67 14 293 68 14 dirt
execute in minecraft:overworld run setblock 293 69 14 grass_block
execute in minecraft:overworld run fill 293 70 14 293 144 14 air
execute in minecraft:overworld run fill 293 58 15 293 66 15 stone
execute in minecraft:overworld run fill 293 67 15 293 68 15 dirt
execute in minecraft:overworld run setblock 293 69 15 grass_block
execute in minecraft:overworld run fill 293 70 15 293 144 15 air
execute in minecraft:overworld run fill 293 58 16 293 65 16 stone
execute in minecraft:overworld run fill 293 66 16 293 67 16 dirt
execute in minecraft:overworld run setblock 293 68 16 coarse_dirt
execute in minecraft:overworld run fill 293 69 16 293 144 16 air
execute in minecraft:overworld run fill 293 58 17 293 65 17 stone
execute in minecraft:overworld run fill 293 66 17 293 67 17 dirt
execute in minecraft:overworld run setblock 293 68 17 coarse_dirt
execute in minecraft:overworld run fill 293 69 17 293 144 17 air
execute in minecraft:overworld run fill 293 58 18 293 65 18 stone
execute in minecraft:overworld run fill 293 66 18 293 67 18 dirt
execute in minecraft:overworld run setblock 293 68 18 coarse_dirt
execute in minecraft:overworld run fill 293 69 18 293 144 18 air
execute in minecraft:overworld run fill 293 58 19 293 65 19 stone
execute in minecraft:overworld run fill 293 66 19 293 67 19 dirt
execute in minecraft:overworld run setblock 293 68 19 coarse_dirt
execute in minecraft:overworld run fill 293 69 19 293 144 19 air
execute in minecraft:overworld run fill 293 58 20 293 65 20 stone
execute in minecraft:overworld run fill 293 66 20 293 67 20 dirt
execute in minecraft:overworld run setblock 293 68 20 grass_block
execute in minecraft:overworld run fill 293 69 20 293 144 20 air
execute in minecraft:overworld run fill 293 58 21 293 65 21 stone
execute in minecraft:overworld run fill 293 66 21 293 67 21 dirt
execute in minecraft:overworld run setblock 293 68 21 coarse_dirt
execute in minecraft:overworld run fill 293 69 21 293 144 21 air
execute in minecraft:overworld run fill 293 58 22 293 65 22 stone
execute in minecraft:overworld run fill 293 66 22 293 67 22 dirt
execute in minecraft:overworld run setblock 293 68 22 coarse_dirt
execute in minecraft:overworld run fill 293 69 22 293 144 22 air
execute in minecraft:overworld run fill 293 58 23 293 65 23 stone
execute in minecraft:overworld run fill 293 66 23 293 67 23 dirt
execute in minecraft:overworld run setblock 293 68 23 grass_block
execute in minecraft:overworld run fill 293 69 23 293 144 23 air
execute in minecraft:overworld run fill 293 58 24 293 65 24 stone
execute in minecraft:overworld run fill 293 66 24 293 67 24 dirt
execute in minecraft:overworld run setblock 293 68 24 grass_block
execute in minecraft:overworld run fill 293 69 24 293 144 24 air
execute in minecraft:overworld run setblock 293 69 24 grass
execute in minecraft:overworld run fill 293 58 25 293 65 25 stone
execute in minecraft:overworld run fill 293 66 25 293 67 25 dirt
execute in minecraft:overworld run setblock 293 68 25 grass_block
execute in minecraft:overworld run fill 293 69 25 293 144 25 air
execute in minecraft:overworld run fill 293 58 26 293 65 26 stone
execute in minecraft:overworld run fill 293 66 26 293 67 26 dirt
execute in minecraft:overworld run setblock 293 68 26 grass_block
execute in minecraft:overworld run fill 293 69 26 293 144 26 air
execute in minecraft:overworld run fill 293 58 27 293 65 27 stone
execute in minecraft:overworld run fill 293 66 27 293 67 27 dirt
execute in minecraft:overworld run setblock 293 68 27 grass_block
execute in minecraft:overworld run fill 293 69 27 293 144 27 air
execute in minecraft:overworld run fill 293 58 28 293 65 28 stone
execute in minecraft:overworld run fill 293 66 28 293 67 28 dirt
execute in minecraft:overworld run setblock 293 68 28 grass_block
execute in minecraft:overworld run fill 293 69 28 293 144 28 air
execute in minecraft:overworld run fill 293 58 29 293 65 29 stone
execute in minecraft:overworld run fill 293 66 29 293 67 29 dirt
execute in minecraft:overworld run setblock 293 68 29 grass_block
execute in minecraft:overworld run fill 293 69 29 293 144 29 air
execute in minecraft:overworld run fill 293 58 30 293 65 30 stone
execute in minecraft:overworld run fill 293 66 30 293 67 30 dirt
execute in minecraft:overworld run setblock 293 68 30 grass_block
execute in minecraft:overworld run fill 293 69 30 293 144 30 air
execute in minecraft:overworld run fill 293 58 31 293 65 31 stone
execute in minecraft:overworld run fill 293 66 31 293 67 31 dirt
execute in minecraft:overworld run setblock 293 68 31 grass_block
execute in minecraft:overworld run fill 293 69 31 293 144 31 air
execute in minecraft:overworld run fill 293 58 32 293 65 32 stone
execute in minecraft:overworld run fill 293 66 32 293 67 32 dirt
execute in minecraft:overworld run setblock 293 68 32 grass_block
execute in minecraft:overworld run fill 293 69 32 293 144 32 air
execute in minecraft:overworld run fill 293 58 33 293 64 33 stone
execute in minecraft:overworld run fill 293 65 33 293 66 33 dirt
execute in minecraft:overworld run setblock 293 67 33 coarse_dirt
execute in minecraft:overworld run fill 293 68 33 293 144 33 air
execute in minecraft:overworld run fill 293 58 34 293 64 34 stone
execute in minecraft:overworld run fill 293 65 34 293 66 34 dirt
execute in minecraft:overworld run setblock 293 67 34 grass_block
execute in minecraft:overworld run fill 293 68 34 293 144 34 air
execute in minecraft:overworld run fill 293 58 35 293 64 35 stone
execute in minecraft:overworld run fill 293 65 35 293 66 35 dirt
execute in minecraft:overworld run setblock 293 67 35 coarse_dirt
execute in minecraft:overworld run fill 293 68 35 293 144 35 air
execute in minecraft:overworld run fill 293 58 36 293 64 36 stone
execute in minecraft:overworld run fill 293 65 36 293 66 36 dirt
execute in minecraft:overworld run setblock 293 67 36 coarse_dirt
execute in minecraft:overworld run fill 293 68 36 293 144 36 air
execute in minecraft:overworld run fill 293 58 37 293 64 37 stone
execute in minecraft:overworld run fill 293 65 37 293 66 37 dirt
execute in minecraft:overworld run setblock 293 67 37 coarse_dirt
execute in minecraft:overworld run fill 293 68 37 293 144 37 air
execute in minecraft:overworld run fill 293 58 38 293 64 38 stone
execute in minecraft:overworld run fill 293 65 38 293 66 38 dirt
execute in minecraft:overworld run setblock 293 67 38 grass_block
execute in minecraft:overworld run fill 293 68 38 293 144 38 air
execute in minecraft:overworld run setblock 293 68 38 grass
execute in minecraft:overworld run fill 293 58 39 293 63 39 stone
execute in minecraft:overworld run fill 293 64 39 293 65 39 dirt
execute in minecraft:overworld run setblock 293 66 39 coarse_dirt
execute in minecraft:overworld run fill 293 67 39 293 144 39 air
execute in minecraft:overworld run setblock 293 67 39 grass
execute in minecraft:overworld run fill 293 58 40 293 63 40 stone
execute in minecraft:overworld run fill 293 64 40 293 65 40 dirt
execute in minecraft:overworld run setblock 293 66 40 grass_block
execute in minecraft:overworld run fill 293 67 40 293 144 40 air
execute in minecraft:overworld run fill 293 58 41 293 63 41 stone
execute in minecraft:overworld run fill 293 64 41 293 65 41 dirt
execute in minecraft:overworld run setblock 293 66 41 coarse_dirt
execute in minecraft:overworld run fill 293 67 41 293 144 41 air
execute in minecraft:overworld run fill 293 58 42 293 63 42 stone
execute in minecraft:overworld run fill 293 64 42 293 65 42 dirt
execute in minecraft:overworld run setblock 293 66 42 grass_block
execute in minecraft:overworld run fill 293 67 42 293 144 42 air
execute in minecraft:overworld run fill 293 58 43 293 62 43 stone
execute in minecraft:overworld run fill 293 63 43 293 64 43 dirt
execute in minecraft:overworld run setblock 293 65 43 coarse_dirt
execute in minecraft:overworld run fill 293 66 43 293 144 43 air
execute in minecraft:overworld run fill 293 58 44 293 62 44 stone
execute in minecraft:overworld run fill 293 63 44 293 64 44 dirt
execute in minecraft:overworld run setblock 293 65 44 coarse_dirt
execute in minecraft:overworld run fill 293 66 44 293 144 44 air
execute in minecraft:overworld run fill 293 58 45 293 62 45 stone
execute in minecraft:overworld run fill 293 63 45 293 64 45 dirt
execute in minecraft:overworld run setblock 293 65 45 grass_block
execute in minecraft:overworld run fill 293 66 45 293 144 45 air
execute in minecraft:overworld run fill 293 58 46 293 61 46 stone
execute in minecraft:overworld run fill 293 62 46 293 63 46 dirt
execute in minecraft:overworld run setblock 293 64 46 coarse_dirt
execute in minecraft:overworld run fill 293 65 46 293 144 46 air
execute in minecraft:overworld run fill 293 58 47 293 61 47 stone
execute in minecraft:overworld run fill 293 62 47 293 63 47 dirt
execute in minecraft:overworld run setblock 293 64 47 grass_block
execute in minecraft:overworld run fill 293 65 47 293 144 47 air
execute in minecraft:overworld run fill 294 58 -48 294 61 -48 stone
execute in minecraft:overworld run fill 294 62 -48 294 63 -48 dirt
execute in minecraft:overworld run setblock 294 64 -48 coarse_dirt
execute in minecraft:overworld run fill 294 65 -48 294 144 -48 air
execute in minecraft:overworld run fill 294 58 -47 294 63 -47 stone
execute in minecraft:overworld run fill 294 64 -47 294 65 -47 dirt
execute in minecraft:overworld run setblock 294 66 -47 coarse_dirt
execute in minecraft:overworld run fill 294 67 -47 294 144 -47 air
execute in minecraft:overworld run fill 294 58 -46 294 65 -46 stone
execute in minecraft:overworld run fill 294 66 -46 294 67 -46 dirt
execute in minecraft:overworld run setblock 294 68 -46 grass_block
execute in minecraft:overworld run fill 294 69 -46 294 144 -46 air
execute in minecraft:overworld run fill 294 58 -45 294 67 -45 stone
execute in minecraft:overworld run fill 294 68 -45 294 69 -45 dirt
execute in minecraft:overworld run setblock 294 70 -45 coarse_dirt
execute in minecraft:overworld run fill 294 71 -45 294 144 -45 air
execute in minecraft:overworld run fill 294 58 -44 294 69 -44 stone
execute in minecraft:overworld run fill 294 70 -44 294 71 -44 dirt
execute in minecraft:overworld run setblock 294 72 -44 grass_block
execute in minecraft:overworld run fill 294 73 -44 294 144 -44 air
execute in minecraft:overworld run fill 294 58 -43 294 71 -43 stone
execute in minecraft:overworld run fill 294 72 -43 294 73 -43 dirt
execute in minecraft:overworld run setblock 294 74 -43 grass_block
execute in minecraft:overworld run fill 294 75 -43 294 144 -43 air
execute in minecraft:overworld run fill 294 58 -42 294 72 -42 stone
execute in minecraft:overworld run fill 294 73 -42 294 74 -42 dirt
execute in minecraft:overworld run setblock 294 75 -42 grass_block
execute in minecraft:overworld run fill 294 76 -42 294 144 -42 air
execute in minecraft:overworld run fill 294 58 -41 294 74 -41 stone
execute in minecraft:overworld run fill 294 75 -41 294 76 -41 dirt
execute in minecraft:overworld run setblock 294 77 -41 coarse_dirt
execute in minecraft:overworld run fill 294 78 -41 294 144 -41 air
execute in minecraft:overworld run fill 294 58 -40 294 76 -40 stone
execute in minecraft:overworld run fill 294 77 -40 294 78 -40 dirt
execute in minecraft:overworld run setblock 294 79 -40 coarse_dirt
execute in minecraft:overworld run fill 294 80 -40 294 144 -40 air
execute in minecraft:overworld run fill 294 58 -39 294 78 -39 stone
execute in minecraft:overworld run fill 294 79 -39 294 80 -39 dirt
execute in minecraft:overworld run setblock 294 81 -39 grass_block
execute in minecraft:overworld run fill 294 82 -39 294 144 -39 air
execute in minecraft:overworld run fill 294 58 -38 294 79 -38 stone
execute in minecraft:overworld run fill 294 80 -38 294 81 -38 dirt
execute in minecraft:overworld run setblock 294 82 -38 grass_block
execute in minecraft:overworld run fill 294 83 -38 294 144 -38 air
execute in minecraft:overworld run fill 294 58 -37 294 79 -37 stone
execute in minecraft:overworld run fill 294 80 -37 294 81 -37 dirt
execute in minecraft:overworld run setblock 294 82 -37 coarse_dirt
execute in minecraft:overworld run fill 294 83 -37 294 144 -37 air
execute in minecraft:overworld run fill 294 58 -36 294 79 -36 stone
execute in minecraft:overworld run fill 294 80 -36 294 81 -36 dirt
execute in minecraft:overworld run setblock 294 82 -36 grass_block
execute in minecraft:overworld run fill 294 83 -36 294 144 -36 air
execute in minecraft:overworld run fill 294 58 -35 294 78 -35 stone
execute in minecraft:overworld run fill 294 79 -35 294 80 -35 dirt
execute in minecraft:overworld run setblock 294 81 -35 grass_block
execute in minecraft:overworld run fill 294 82 -35 294 144 -35 air
execute in minecraft:overworld run fill 294 58 -34 294 78 -34 stone
execute in minecraft:overworld run fill 294 79 -34 294 80 -34 dirt
execute in minecraft:overworld run setblock 294 81 -34 coarse_dirt
execute in minecraft:overworld run fill 294 82 -34 294 144 -34 air
execute in minecraft:overworld run fill 294 58 -33 294 77 -33 stone
execute in minecraft:overworld run fill 294 78 -33 294 79 -33 dirt
execute in minecraft:overworld run setblock 294 80 -33 coarse_dirt
execute in minecraft:overworld run fill 294 81 -33 294 144 -33 air
execute in minecraft:overworld run fill 294 58 -32 294 77 -32 stone
execute in minecraft:overworld run fill 294 78 -32 294 79 -32 dirt
execute in minecraft:overworld run setblock 294 80 -32 coarse_dirt
execute in minecraft:overworld run fill 294 81 -32 294 144 -32 air
execute in minecraft:overworld run setblock 294 81 -32 mossy_cobblestone
execute in minecraft:overworld run fill 294 58 -31 294 77 -31 stone
schedule function blade_gallery:random/burned/part_136 1t replace
