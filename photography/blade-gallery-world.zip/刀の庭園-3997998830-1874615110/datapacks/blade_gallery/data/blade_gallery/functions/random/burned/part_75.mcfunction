execute in minecraft:overworld run fill 256 58 2 256 59 2 stone
execute in minecraft:overworld run fill 256 60 2 256 61 2 dirt
execute in minecraft:overworld run setblock 256 62 2 gravel
execute in minecraft:overworld run fill 256 63 2 256 144 2 air
execute in minecraft:overworld run fill 256 63 2 256 64 2 water
execute in minecraft:overworld run fill 256 58 3 256 59 3 stone
execute in minecraft:overworld run fill 256 60 3 256 61 3 dirt
execute in minecraft:overworld run setblock 256 62 3 gravel
execute in minecraft:overworld run fill 256 63 3 256 144 3 air
execute in minecraft:overworld run fill 256 63 3 256 64 3 water
execute in minecraft:overworld run fill 256 58 4 256 59 4 stone
execute in minecraft:overworld run fill 256 60 4 256 61 4 dirt
execute in minecraft:overworld run setblock 256 62 4 gravel
execute in minecraft:overworld run fill 256 63 4 256 144 4 air
execute in minecraft:overworld run fill 256 63 4 256 64 4 water
execute in minecraft:overworld run fill 256 58 5 256 60 5 stone
execute in minecraft:overworld run fill 256 61 5 256 62 5 dirt
execute in minecraft:overworld run setblock 256 63 5 gravel
execute in minecraft:overworld run fill 256 64 5 256 144 5 air
execute in minecraft:overworld run fill 256 64 5 256 64 5 water
execute in minecraft:overworld run fill 256 58 6 256 60 6 stone
execute in minecraft:overworld run fill 256 61 6 256 62 6 dirt
execute in minecraft:overworld run setblock 256 63 6 gravel
execute in minecraft:overworld run fill 256 64 6 256 144 6 air
execute in minecraft:overworld run fill 256 64 6 256 64 6 water
execute in minecraft:overworld run fill 256 58 7 256 60 7 stone
execute in minecraft:overworld run fill 256 61 7 256 62 7 dirt
execute in minecraft:overworld run setblock 256 63 7 gravel
execute in minecraft:overworld run fill 256 64 7 256 144 7 air
execute in minecraft:overworld run fill 256 64 7 256 64 7 water
execute in minecraft:overworld run fill 256 58 8 256 61 8 stone
execute in minecraft:overworld run fill 256 62 8 256 63 8 dirt
execute in minecraft:overworld run setblock 256 64 8 grass_block
execute in minecraft:overworld run fill 256 65 8 256 144 8 air
execute in minecraft:overworld run fill 256 58 9 256 61 9 stone
execute in minecraft:overworld run fill 256 62 9 256 63 9 dirt
execute in minecraft:overworld run setblock 256 64 9 grass_block
execute in minecraft:overworld run fill 256 65 9 256 144 9 air
execute in minecraft:overworld run fill 256 58 10 256 61 10 stone
execute in minecraft:overworld run fill 256 62 10 256 63 10 dirt
execute in minecraft:overworld run setblock 256 64 10 coarse_dirt
execute in minecraft:overworld run fill 256 65 10 256 144 10 air
execute in minecraft:overworld run fill 256 58 11 256 61 11 stone
execute in minecraft:overworld run fill 256 62 11 256 63 11 dirt
execute in minecraft:overworld run setblock 256 64 11 coarse_dirt
execute in minecraft:overworld run fill 256 65 11 256 144 11 air
execute in minecraft:overworld run fill 256 58 12 256 62 12 stone
execute in minecraft:overworld run fill 256 63 12 256 64 12 dirt
execute in minecraft:overworld run setblock 256 65 12 grass_block
execute in minecraft:overworld run fill 256 66 12 256 144 12 air
execute in minecraft:overworld run fill 256 58 13 256 62 13 stone
execute in minecraft:overworld run fill 256 63 13 256 64 13 dirt
execute in minecraft:overworld run setblock 256 65 13 coarse_dirt
execute in minecraft:overworld run fill 256 66 13 256 144 13 air
execute in minecraft:overworld run fill 256 58 14 256 62 14 stone
execute in minecraft:overworld run fill 256 63 14 256 64 14 dirt
execute in minecraft:overworld run setblock 256 65 14 coarse_dirt
execute in minecraft:overworld run fill 256 66 14 256 144 14 air
execute in minecraft:overworld run fill 256 58 15 256 63 15 stone
execute in minecraft:overworld run fill 256 64 15 256 65 15 dirt
execute in minecraft:overworld run setblock 256 66 15 coarse_dirt
execute in minecraft:overworld run fill 256 67 15 256 144 15 air
execute in minecraft:overworld run fill 256 58 16 256 63 16 stone
execute in minecraft:overworld run fill 256 64 16 256 65 16 dirt
execute in minecraft:overworld run setblock 256 66 16 coarse_dirt
execute in minecraft:overworld run fill 256 67 16 256 144 16 air
execute in minecraft:overworld run fill 256 58 17 256 63 17 stone
execute in minecraft:overworld run fill 256 64 17 256 65 17 dirt
execute in minecraft:overworld run setblock 256 66 17 coarse_dirt
execute in minecraft:overworld run fill 256 67 17 256 144 17 air
execute in minecraft:overworld run setblock 256 67 17 grass
execute in minecraft:overworld run fill 256 58 18 256 63 18 stone
execute in minecraft:overworld run fill 256 64 18 256 65 18 dirt
execute in minecraft:overworld run setblock 256 66 18 coarse_dirt
execute in minecraft:overworld run fill 256 67 18 256 144 18 air
execute in minecraft:overworld run fill 256 58 19 256 64 19 stone
execute in minecraft:overworld run fill 256 65 19 256 66 19 dirt
execute in minecraft:overworld run setblock 256 67 19 coarse_dirt
execute in minecraft:overworld run fill 256 68 19 256 144 19 air
execute in minecraft:overworld run fill 256 58 20 256 64 20 stone
execute in minecraft:overworld run fill 256 65 20 256 66 20 dirt
execute in minecraft:overworld run setblock 256 67 20 grass_block
execute in minecraft:overworld run fill 256 68 20 256 144 20 air
execute in minecraft:overworld run fill 256 58 21 256 64 21 stone
execute in minecraft:overworld run fill 256 65 21 256 66 21 dirt
execute in minecraft:overworld run setblock 256 67 21 grass_block
execute in minecraft:overworld run fill 256 68 21 256 144 21 air
execute in minecraft:overworld run fill 256 58 22 256 63 22 stone
execute in minecraft:overworld run fill 256 64 22 256 65 22 dirt
execute in minecraft:overworld run setblock 256 66 22 coarse_dirt
execute in minecraft:overworld run fill 256 67 22 256 144 22 air
execute in minecraft:overworld run fill 256 58 23 256 63 23 stone
execute in minecraft:overworld run fill 256 64 23 256 65 23 dirt
execute in minecraft:overworld run setblock 256 66 23 coarse_dirt
execute in minecraft:overworld run fill 256 67 23 256 144 23 air
execute in minecraft:overworld run fill 256 58 24 256 63 24 stone
execute in minecraft:overworld run fill 256 64 24 256 65 24 dirt
execute in minecraft:overworld run setblock 256 66 24 grass_block
execute in minecraft:overworld run fill 256 67 24 256 144 24 air
execute in minecraft:overworld run setblock 256 67 24 grass
execute in minecraft:overworld run fill 256 58 25 256 63 25 stone
execute in minecraft:overworld run fill 256 64 25 256 65 25 dirt
execute in minecraft:overworld run setblock 256 66 25 grass_block
execute in minecraft:overworld run fill 256 67 25 256 144 25 air
execute in minecraft:overworld run fill 256 58 26 256 63 26 stone
execute in minecraft:overworld run fill 256 64 26 256 65 26 dirt
execute in minecraft:overworld run setblock 256 66 26 coarse_dirt
execute in minecraft:overworld run fill 256 67 26 256 144 26 air
execute in minecraft:overworld run fill 256 58 27 256 63 27 stone
execute in minecraft:overworld run fill 256 64 27 256 65 27 dirt
execute in minecraft:overworld run setblock 256 66 27 coarse_dirt
execute in minecraft:overworld run fill 256 67 27 256 144 27 air
execute in minecraft:overworld run fill 256 58 28 256 63 28 stone
execute in minecraft:overworld run fill 256 64 28 256 65 28 dirt
execute in minecraft:overworld run setblock 256 66 28 coarse_dirt
execute in minecraft:overworld run fill 256 67 28 256 144 28 air
execute in minecraft:overworld run setblock 256 67 28 grass
execute in minecraft:overworld run fill 256 58 29 256 62 29 stone
execute in minecraft:overworld run fill 256 63 29 256 64 29 dirt
execute in minecraft:overworld run setblock 256 65 29 coarse_dirt
execute in minecraft:overworld run fill 256 66 29 256 144 29 air
execute in minecraft:overworld run setblock 256 66 29 grass
execute in minecraft:overworld run fill 256 58 30 256 62 30 stone
execute in minecraft:overworld run fill 256 63 30 256 64 30 dirt
execute in minecraft:overworld run setblock 256 65 30 coarse_dirt
execute in minecraft:overworld run fill 256 66 30 256 144 30 air
execute in minecraft:overworld run fill 256 58 31 256 62 31 stone
execute in minecraft:overworld run fill 256 63 31 256 64 31 dirt
execute in minecraft:overworld run setblock 256 65 31 grass_block
execute in minecraft:overworld run fill 256 66 31 256 144 31 air
execute in minecraft:overworld run fill 256 58 32 256 62 32 stone
execute in minecraft:overworld run fill 256 63 32 256 64 32 dirt
execute in minecraft:overworld run setblock 256 65 32 grass_block
execute in minecraft:overworld run fill 256 66 32 256 144 32 air
execute in minecraft:overworld run fill 256 58 33 256 61 33 stone
execute in minecraft:overworld run fill 256 62 33 256 63 33 dirt
execute in minecraft:overworld run setblock 256 64 33 coarse_dirt
execute in minecraft:overworld run fill 256 65 33 256 144 33 air
execute in minecraft:overworld run fill 256 58 34 256 61 34 stone
execute in minecraft:overworld run fill 256 62 34 256 63 34 dirt
execute in minecraft:overworld run setblock 256 64 34 grass_block
execute in minecraft:overworld run fill 256 65 34 256 144 34 air
execute in minecraft:overworld run fill 256 58 35 256 60 35 stone
execute in minecraft:overworld run fill 256 61 35 256 62 35 dirt
execute in minecraft:overworld run setblock 256 63 35 gravel
execute in minecraft:overworld run fill 256 64 35 256 144 35 air
execute in minecraft:overworld run fill 256 64 35 256 64 35 water
execute in minecraft:overworld run fill 256 58 36 256 60 36 stone
execute in minecraft:overworld run fill 256 61 36 256 62 36 dirt
execute in minecraft:overworld run setblock 256 63 36 gravel
execute in minecraft:overworld run fill 256 64 36 256 144 36 air
execute in minecraft:overworld run fill 256 64 36 256 64 36 water
execute in minecraft:overworld run fill 256 58 37 256 59 37 stone
execute in minecraft:overworld run fill 256 60 37 256 61 37 dirt
execute in minecraft:overworld run setblock 256 62 37 gravel
execute in minecraft:overworld run fill 256 63 37 256 144 37 air
execute in minecraft:overworld run fill 256 63 37 256 64 37 water
execute in minecraft:overworld run fill 256 58 38 256 59 38 stone
execute in minecraft:overworld run fill 256 60 38 256 61 38 dirt
execute in minecraft:overworld run setblock 256 62 38 gravel
execute in minecraft:overworld run fill 256 63 38 256 144 38 air
execute in minecraft:overworld run fill 256 63 38 256 64 38 water
execute in minecraft:overworld run fill 256 58 39 256 58 39 stone
execute in minecraft:overworld run fill 256 59 39 256 60 39 dirt
execute in minecraft:overworld run setblock 256 61 39 gravel
execute in minecraft:overworld run fill 256 62 39 256 144 39 air
execute in minecraft:overworld run fill 256 62 39 256 64 39 water
execute in minecraft:overworld run fill 256 58 40 256 58 40 stone
execute in minecraft:overworld run fill 256 59 40 256 60 40 dirt
execute in minecraft:overworld run setblock 256 61 40 gravel
execute in minecraft:overworld run fill 256 62 40 256 144 40 air
execute in minecraft:overworld run fill 256 62 40 256 64 40 water
execute in minecraft:overworld run fill 256 58 41 256 58 41 stone
execute in minecraft:overworld run fill 256 59 41 256 60 41 dirt
execute in minecraft:overworld run setblock 256 61 41 gravel
execute in minecraft:overworld run fill 256 62 41 256 144 41 air
execute in minecraft:overworld run fill 256 62 41 256 64 41 water
execute in minecraft:overworld run fill 256 58 42 256 58 42 stone
execute in minecraft:overworld run fill 256 59 42 256 60 42 dirt
execute in minecraft:overworld run setblock 256 61 42 gravel
execute in minecraft:overworld run fill 256 62 42 256 144 42 air
execute in minecraft:overworld run fill 256 62 42 256 64 42 water
execute in minecraft:overworld run fill 256 58 43 256 59 43 stone
execute in minecraft:overworld run fill 256 60 43 256 61 43 dirt
execute in minecraft:overworld run setblock 256 62 43 gravel
execute in minecraft:overworld run fill 256 63 43 256 144 43 air
execute in minecraft:overworld run fill 256 63 43 256 64 43 water
execute in minecraft:overworld run fill 256 58 44 256 59 44 stone
execute in minecraft:overworld run fill 256 60 44 256 61 44 dirt
execute in minecraft:overworld run setblock 256 62 44 gravel
execute in minecraft:overworld run fill 256 63 44 256 144 44 air
execute in minecraft:overworld run fill 256 63 44 256 64 44 water
execute in minecraft:overworld run fill 256 58 45 256 59 45 stone
execute in minecraft:overworld run fill 256 60 45 256 61 45 dirt
execute in minecraft:overworld run setblock 256 62 45 gravel
execute in minecraft:overworld run fill 256 63 45 256 144 45 air
execute in minecraft:overworld run fill 256 63 45 256 64 45 water
execute in minecraft:overworld run fill 256 58 46 256 60 46 stone
execute in minecraft:overworld run fill 256 61 46 256 62 46 dirt
execute in minecraft:overworld run setblock 256 63 46 gravel
execute in minecraft:overworld run fill 256 64 46 256 144 46 air
execute in minecraft:overworld run fill 256 64 46 256 64 46 water
execute in minecraft:overworld run fill 256 58 47 256 60 47 stone
execute in minecraft:overworld run fill 256 61 47 256 62 47 dirt
execute in minecraft:overworld run setblock 256 63 47 gravel
execute in minecraft:overworld run fill 256 64 47 256 144 47 air
execute in minecraft:overworld run fill 256 64 47 256 64 47 water
execute in minecraft:overworld run fill 257 58 -48 257 61 -48 stone
execute in minecraft:overworld run fill 257 62 -48 257 63 -48 dirt
execute in minecraft:overworld run setblock 257 64 -48 coarse_dirt
execute in minecraft:overworld run fill 257 65 -48 257 144 -48 air
execute in minecraft:overworld run fill 257 58 -47 257 63 -47 stone
execute in minecraft:overworld run fill 257 64 -47 257 65 -47 dirt
execute in minecraft:overworld run setblock 257 66 -47 grass_block
execute in minecraft:overworld run fill 257 67 -47 257 144 -47 air
execute in minecraft:overworld run fill 257 58 -46 257 64 -46 stone
execute in minecraft:overworld run fill 257 65 -46 257 66 -46 dirt
execute in minecraft:overworld run setblock 257 67 -46 coarse_dirt
execute in minecraft:overworld run fill 257 68 -46 257 144 -46 air
execute in minecraft:overworld run fill 257 58 -45 257 66 -45 stone
execute in minecraft:overworld run fill 257 67 -45 257 68 -45 dirt
execute in minecraft:overworld run setblock 257 69 -45 coarse_dirt
execute in minecraft:overworld run fill 257 70 -45 257 144 -45 air
execute in minecraft:overworld run fill 257 58 -44 257 67 -44 stone
execute in minecraft:overworld run fill 257 68 -44 257 69 -44 dirt
execute in minecraft:overworld run setblock 257 70 -44 grass_block
execute in minecraft:overworld run fill 257 71 -44 257 144 -44 air
execute in minecraft:overworld run fill 257 58 -43 257 68 -43 stone
execute in minecraft:overworld run fill 257 69 -43 257 70 -43 dirt
execute in minecraft:overworld run setblock 257 71 -43 grass_block
execute in minecraft:overworld run fill 257 72 -43 257 144 -43 air
execute in minecraft:overworld run fill 257 58 -42 257 70 -42 stone
execute in minecraft:overworld run fill 257 71 -42 257 72 -42 dirt
execute in minecraft:overworld run setblock 257 73 -42 coarse_dirt
execute in minecraft:overworld run fill 257 74 -42 257 144 -42 air
execute in minecraft:overworld run fill 257 58 -41 257 71 -41 stone
execute in minecraft:overworld run fill 257 72 -41 257 73 -41 dirt
execute in minecraft:overworld run setblock 257 74 -41 coarse_dirt
execute in minecraft:overworld run fill 257 75 -41 257 144 -41 air
execute in minecraft:overworld run fill 257 58 -40 257 73 -40 stone
execute in minecraft:overworld run fill 257 74 -40 257 75 -40 dirt
execute in minecraft:overworld run setblock 257 76 -40 coarse_dirt
execute in minecraft:overworld run fill 257 77 -40 257 144 -40 air
execute in minecraft:overworld run fill 257 58 -39 257 74 -39 stone
execute in minecraft:overworld run fill 257 75 -39 257 76 -39 dirt
execute in minecraft:overworld run setblock 257 77 -39 coarse_dirt
execute in minecraft:overworld run fill 257 78 -39 257 144 -39 air
execute in minecraft:overworld run fill 257 58 -38 257 75 -38 stone
execute in minecraft:overworld run fill 257 76 -38 257 77 -38 dirt
execute in minecraft:overworld run setblock 257 78 -38 coarse_dirt
execute in minecraft:overworld run fill 257 79 -38 257 144 -38 air
execute in minecraft:overworld run setblock 257 79 -38 mossy_cobblestone
execute in minecraft:overworld run fill 257 58 -37 257 75 -37 stone
execute in minecraft:overworld run fill 257 76 -37 257 77 -37 dirt
execute in minecraft:overworld run setblock 257 78 -37 coarse_dirt
execute in minecraft:overworld run fill 257 79 -37 257 144 -37 air
schedule function blade_gallery:random/burned/part_76 1t replace
